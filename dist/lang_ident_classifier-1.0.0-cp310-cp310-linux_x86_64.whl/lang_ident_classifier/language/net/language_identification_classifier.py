# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the authora if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import OrderedDict
import copy
import numpy as np
import torch
import lightning as pl
import bitsandbytes
from torchmetrics import Accuracy, Precision, Recall, F1Score
from torch.amp import autocast
from cachetools import LRUCache
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset
from lang_ident_classifier.language.loss.class_weighted_focal_loss_with_adaptive_focus import ClassWeightedFocalLossWithAdaptiveFocus
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
from transformers import AutoModelForSeq2SeqLM
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# Global cache (NOT in model class)
FROZEN_EMBEDDING = None  
# MAX_OLD_EMBS = 1000  # Limit the cache size

# class LRUCacheDict(OrderedDict):
#     def __init__(self, max_size):
#         self.max_size = max_size
#         super().__init__()

#     def __getitem__(self, key):
#         value = super().__getitem__(key)
#         self.move_to_end(key)
#         return value

#     def __setitem__(self, key, value):
#         if key in self:
#             self.move_to_end(key)
#         elif len(self) >= self.max_size:
#             self.popitem(last=False)  # Remove LRU item
#         super().__setitem__(key, value)

# OLD_EMB_TRAIN = LRUCacheDict(max_size=MAX_OLD_EMBS)
# OLD_EMB_VAL = LRUCacheDict(max_size=MAX_OLD_EMBS)

class SafeModuleWrapper(torch.nn.Module):
    def __init__(self, module, clamp_min=-5, clamp_max=5):
        super().__init__()
        self.module = module
        # self.module = module.to(dtype=torch.float32)  # Convert module to FP32
        # for param in self.module.parameters():
        #     param.data = param.data.to(torch.float32)
        # for buffer in self.module.buffers():
        #     buffer.data = buffer.data.to(torch.float32)
        
        self.clamp_min = clamp_min
        self.clamp_max = clamp_max

    # def forward(self, *inputs, **kwargs):
    #     # Ensure all inputs are float32 if they are tensors
    #     inputs = tuple(inp.float() if isinstance(inp, torch.Tensor) else inp for inp in inputs)
        
    #     # Logging dtype info
    #     # param_dtypes = {name: param.dtype for name, param in self.module.named_parameters()}
    #     # buffer_dtypes = {name: buffer.dtype for name, buffer in self.module.named_buffers()}
    #     # print(f"[Forward Pass] {self.module.__class__.__name__} running")
    #     # print(f"  - Parameters Dtype: {param_dtypes if param_dtypes else 'No Parameters'}")
    #     # print(f"  - Buffers Dtype: {buffer_dtypes if buffer_dtypes else 'No Buffers'}")

    #     # Forward pass
    #     output = self.module(*inputs, **kwargs)
        
    #     # Convert output to FP32 and clamp if necessary
    #     if isinstance(output, torch.Tensor):
    #         output = torch.clamp(output.float(), min=self.clamp_min, max=self.clamp_max)
    #         return torch.nan_to_num(output)
    #     return output  # If it's not a tensor, return as is

    def forward(self, *inputs, **kwargs):
        # Efficient input dtype conversion
        inputs = tuple(inp.to(torch.float32) if isinstance(inp, torch.Tensor) and inp.dtype != torch.float32 else inp
                       for inp in inputs)

        # Forward pass
        output = self.module(*inputs, **kwargs)

        # Apply clamping efficiently
        if isinstance(output, torch.Tensor):
            output = output.to(torch.float32)  # Ensure float32
            output.clamp_(self.clamp_min, self.clamp_max)  # In-place clamping
            if torch.isnan(output).any():
                output = torch.nan_to_num(output)  # Handle NaNs only if they exist
            return output

        return output  # Return non-tensor outputs as is
    
class LanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        pretrained_embedding_model,
        num_classes,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_embedding_layers_unfrozen,
        loss_type,
        num_fc_layers,
        activation_function_for_layer,
        add_dropout_after_embedding,
        is_train,
        tokenizer,
        random_seed: int = 20,
        pretrained_model_embedding_name = None,
    ):
        super(LanguageIdentificationClassifier, self).__init__()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self.save_hyperparameters({
            "device_dict": device_dict,
            "optimizer": optimizer,
            "num_embedding_layers_unfrozen": num_embedding_layers_unfrozen,
            "loss_type": loss_type,
            "num_fc_layers": num_fc_layers,
            "activation_function_for_layer": activation_function_for_layer,
            "add_dropout_after_embedding": add_dropout_after_embedding,
            "lr": lr,
            "is_train": is_train,
            "random_seed": random_seed,
        })
        print(f"HPARAMS {self.hparams}")
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
        np.random.seed(random_seed)
        self.tokenizer = tokenizer
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.pretrained_model_embedding_name = pretrained_model_embedding_name
        self.num_classes = num_classes
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.ignore_padding_token_idx = tokenizer.pad_token_id

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self.embedding = pretrained_embedding_model
        # # Convert LayerNorm inside self.embedding to FP32
        # for module in self.modules():
        #     if isinstance(module, torch.nn.LayerNorm):
        #         module.to(torch.float32)  # Convert weights & buffers to FP32
        #         module.weight.data = module.weight.data.to(torch.float32)
        #         if module.bias is not None:
        #             module.bias.data = module.bias.data.to(torch.float32)
        self.embedding.requires_grad_(False).to(self.curr_device)

        self.num_fc_layers = num_fc_layers
        self.activation_function_for_layer = activation_function_for_layer
        
        # Unfreeze specific layers of the encoder
        if num_embedding_layers_unfrozen > 0:
            if "mt5" in self.pretrained_model_embedding_name:
                for param in self.embedding.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = False  # Freeze all layers initially
                
                if num_embedding_layers_unfrozen > 0:
                    for block in self.embedding.encoder.block[-num_embedding_layers_unfrozen:]:  # <-- Fix here
                        # for name, submodule in block.named_modules():
                        #     if "dropout" in name.lower():  # Check if "dropout" is in the module name
                        #         submodule.train()  # Ensure Dropout layers are not frozen
                        for param in block.parameters():
                            if not param.is_leaf:
                                param = param.detach()
                            if isinstance(param, torch.Tensor) and (param.is_floating_point() or torch.is_complex(param)):
                                param.requires_grad = True

            # elif "mbart" in self.pretrained_model_embedding_name:
            #     for param in self.embedding.parameters():
            #         if not param.is_leaf:
            #             param = param.detach()
            #         param.requires_grad = False  # Freeze all layers initially
                
            #     if num_embedding_layers_unfrozen > 0:
            #         for param in self.embedding.model.encoder.layers[-(num_embedding_layers_unfrozen)].parameters():
            #             if not param.is_leaf:
            #                 param = param.detach()
            #             param.requires_grad = True
            elif "mbart" in self.pretrained_model_embedding_name:
                for param in self.embedding.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = False  # Freeze all layers initially
                
                if num_embedding_layers_unfrozen > 0:
                    for layer in self.embedding.model.encoder.layers[-num_embedding_layers_unfrozen:]:  # ✅ Fix
                        # for name, submodule in layer.named_modules():
                        #     if "dropout" in name.lower():  # Check if "dropout" is in the module name
                        #         submodule.train()  # Ensure Dropout layers are not frozen
                        for param in layer.parameters():
                            if not param.is_leaf:
                                param = param.detach()
                            param.requires_grad = True
            else:
                for param in self.embedding.pooler.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = True
                if num_embedding_layers_unfrozen > 1:
                    for param in self.embedding.encoder.layer[-(num_embedding_layers_unfrozen-1)].parameters():
                        if not param.is_leaf:
                            param = param.detach()
                        param.requires_grad = True

        self.add_dropout_after_embedding = add_dropout_after_embedding
        if add_dropout_after_embedding:
            self.dropout = torch.nn.Dropout(0.1, inplace=False)
        
        # Define FC layers
        if num_fc_layers == 1:
            start_input_features = self.embedding.config.hidden_size
            end_output_features = self.num_classes
            if activation_function_for_layer:
                setattr(self, f"fc_with_{activation_function_for_layer}_activation_1", torch.nn.Sequential(
                    # torch.nn.LayerNorm(start_input_features, dtype=torch.float32),
                    torch.nn.Linear(start_input_features, end_output_features),
                    torch.nn.LayerNorm(end_output_features),
                    self._get_activation_function_instance(activation_function_for_layer,end_output_features)
                ))
            else:
                setattr(self, f"fc_1", torch.nn.Linear(start_input_features, end_output_features))
        else:
            start_input_features = self.embedding.config.hidden_size
            end_output_features = self.num_classes
            for layer_idx in range(num_fc_layers):
                if layer_idx == 0:
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 != num_fc_layers:
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 == num_fc_layers:
                    in_features = start_input_features
                    out_features = end_output_features
                # setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
                # if activation_function_for_layer and layer_idx+1 < num_fc_layers:
                #     setattr(self, f"{activation_function_for_layer}_{layer_idx+1}", self._get_activation_function_instance(activation_function_for_layer, out_features))
                if activation_function_for_layer and layer_idx+1 < num_fc_layers:
                    setattr(self, f"fc_with_{activation_function_for_layer}_activation_{layer_idx+1}", torch.nn.Sequential(
                        # torch.nn.LayerNorm(start_input_features, dtype=torch.float32),
                        torch.nn.Linear(start_input_features, out_features),
                        torch.nn.LayerNorm(out_features),
                        self._get_activation_function_instance(activation_function_for_layer, out_features) if activation_function_for_layer and layer_idx+1 < num_fc_layers else torch.nn.Identity()
                    ))
                else:
                    setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
                start_input_features = out_features

        # Loss function initialization
        if loss_type.casefold() == "class_weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, device=self.curr_device, ignore_index=self.ignore_padding_token_idx)
        elif loss_type.casefold() == "focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=0.25, device=self.curr_device, ignore_index=self.ignore_padding_token_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, device=self.curr_device, ignore_index=self.ignore_padding_token_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type1', device=self.curr_device, ignore_index=self.ignore_padding_token_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type2', device=self.curr_device, ignore_index=self.ignore_padding_token_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type3', device=self.curr_device, ignore_index=self.ignore_padding_token_idx)
        else:
            self._criterion = ClassWeightedCrossEntropyLoss(device=self.curr_device, ignore_index=self.ignore_padding_token_idx)
        
        self._accuracy = Accuracy(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
            ignore_index=self.ignore_padding_token_idx,
        ).to(self.curr_device)
        self._precision = Precision(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
            ignore_index=self.ignore_padding_token_idx,
        ).to(self.curr_device)
        self._recall = Recall(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
            ignore_index=self.ignore_padding_token_idx,
        ).to(self.curr_device)
        self._f1 = F1Score(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
            ignore_index=self.ignore_padding_token_idx,
        ).to(self.curr_device)
        
        self.optimizer_name = optimizer.casefold()
        self.fix_embedding_layers()
        # Load old model ONCE but prevent PyTorch from tracking it
        global FROZEN_EMBEDDING 
        FROZEN_EMBEDDING = copy.deepcopy(self.embedding).eval()
        # for param in OLD_EMBEDDING_CACHE.parameters():
        #     param.requires_grad = False  # Ensure it's frozen

        # self.amp_hooks = []
        # self.register_amp_hooks()
        # self.fix_layernorm(self.embedding)
        # Clone and freeze old embeddings
        self.register_nan_hooks(self.embedding)
        self.initialize_weights(self.curr_device, num_fc_layers)
    
    def register_nan_hooks(self, module, prefix=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for name, child in module.named_children():
            full_name = f"{prefix}.{name}" if prefix else name  # Keep full layer path

            # Hook function to check for NaNs in forward pass
            def detect_nan_hook(mod, inp, out):
                if isinstance(out, torch.Tensor) and out.isnan().any():
                    print(f"NaN detected in {full_name} ({mod.__class__.__name__}) ({out.dtype})")

            child.register_forward_hook(detect_nan_hook)

            # Recursively apply to children
            self.register_nan_hooks(child, full_name)
    
    def has_trainable_params(self, module):
        return any(p.requires_grad for p in module.parameters())  # Includes submodules
    
    def fix_embedding_layers(self):
        """Convert LayerNorm, activations, dropout, and attention layers to float32 and wrap them safely."""

        updates = []

        for name, module in self.named_modules():
            if not self.has_trainable_params(module):
                continue  # Skip frozen layers

            # Identify LayerNorm modules
            is_norm = "norm" in name.lower() or isinstance(module, (torch.nn.LayerNorm, getattr(torch.nn, "MT5LayerNorm", torch.nn.LayerNorm)))
            
            # Identify common activation functions
            is_act = any(act in name.lower() for act in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh"])
            
            # Identify dropout layers
            is_dropout = "dropout" in name.lower() or isinstance(module, torch.nn.Dropout)
            
            # Identify attention modules
            is_attention = "attention" in name.lower()

            if is_norm:
                module.eps = 1e-5  # Ensure stability for LayerNorm

            if is_norm or is_act:
                module.to(torch.float32)  # Use float32 for stability
                if not isinstance(module, SafeModuleWrapper):
                    updates.append((name, SafeModuleWrapper(module)))  # Wrap for safe forward pass

        # Apply wrapped modules
        for name, new_module in updates:
            parent_module, attr = self.get_parent_and_attr(name)
            if parent_module is not None:
                setattr(parent_module, attr, new_module)


    def get_parent_and_attr(self, module_name):
        """Finds the parent module and attribute name given the full module path."""
        parts = module_name.split('.')
        parent = self  # Start from the main model
        for part in parts[:-1]:  # Traverse down but stop at the parent
            parent = getattr(parent, part, None)
            if parent is None:
                return None, None
        return parent, parts[-1]  # Return parent module and final attribute

    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            # return torch.nn.PReLU(num_parameters=num_parameters)
            return torch.nn.PReLU(num_parameters=1)
        elif activation_function_for_layer.casefold() == "leaky_relu":
            return torch.nn.LeakyReLU(inplace=False)
        else:
            return torch.nn.ReLU(inplace=False) # in place tensor modifications disabled due to issues in gradient 

    def initialize_weights(self, device, num_fc_layers):
        def _initialize_weights(m):
            if hasattr(m, "weight") and m.weight.dim() > 1:
                # print(f"Initializing {m}")
                m.to(device)
                torch.nn.init.xavier_uniform_(m.weight.data)
                # if m.bias is not None:  # Initialize bias as well
                #     torch.nn.init.zeros_(m.bias.data)
        
        # for layer_idx in range(num_fc_layers):
        #     layer = getattr(self, f"fc_{layer_idx+1}")
        #     layer.apply(_initialize_weights)
        fc_layers = [layer for name, layer in self._modules.items() if name.startswith("fc_")]
        # print(f"Initializing layers {fc_layers}")
        for layer in fc_layers:
            layer.apply(_initialize_weights)

    def forward(self, input_ids, attention_mask):
        """Optimized forward pass with minimal GPU memory usage."""

        # Move inputs to the correct device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        attention_mask = attention_mask.to(self.curr_device, non_blocking=True)

        frozen_embedding_output = None  # Initialize to avoid referencing uninitialized variables

        with torch.no_grad():  # Disable gradient tracking for frozen embeddings
            if "mt5" in self.pretrained_model_embedding_name:
                embedding_output = self.embedding.encoder(input_ids, attention_mask).last_hidden_state
                # old_embedding_output = self.compute_frozen_embeddings(input_ids, attention_mask)
                if self.trainer.training or self.trainer.validating:
                    frozen_embedding_output = FROZEN_EMBEDDING.encoder(input_ids, attention_mask).last_hidden_state

            elif "mbart" in self.pretrained_model_embedding_name:
                embedding_output = self.embedding.model.encoder(input_ids, attention_mask).last_hidden_state
                if self.trainer.training or self.trainer.validating:
                    frozen_embedding_output = FROZEN_EMBEDDING.model.encoder(input_ids, attention_mask).last_hidden_state
            else:
                embedding_output = self.embedding(input_ids, attention_mask).last_hidden_state
                if self.trainer.training or self.trainer.validating:
                    frozen_embedding_output = FROZEN_EMBEDDING(input_ids, attention_mask).last_hidden_state

        # Compute KL and contrastive loss efficiently (offloaded to CPU when possible)
        kl_loss = torch.tensor(0.0, device=self.curr_device)
        contrastive_loss = torch.tensor(0.0, device=self.curr_device)
        if self.trainer.training or self.trainer.validating:
            kl_loss, contrastive_loss = self.compute_kl_contrastive_loss(
                embedding_output, frozen_embedding_output, device=self.curr_device
            )

        # Dropout layer if enabled
        output = self.dropout(embedding_output) if self.add_dropout_after_embedding else embedding_output

        # Fully connected layers (loop efficiently)
        for layer_idx in range(self.num_fc_layers):
            layer = getattr(self, f"fc_with_{self.activation_function_for_layer}_activation_{layer_idx+1}", None) or \
                    getattr(self, f"fc_{layer_idx+1}")
            output = layer(output)

        # Explicitly remove large tensors from memory to free up GPU
        del input_ids, attention_mask, embedding_output, frozen_embedding_output  
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free unused memory

        return output, kl_loss, contrastive_loss

    def register_amp_hooks(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def hook_fn(module, inputs, outputs):
            if any(inp.dtype == torch.float16 for inp in inputs if isinstance(inp, torch.Tensor)):
                print(f"Layer {module.__class__.__name__} is using float16!")

        # Attach hooks to all layers in self.model
        for submodule in self.modules():
            hook = submodule.register_forward_hook(hook_fn)
            self.amp_hooks.append(hook)  # Store hooks to remove them later if needed

    def remove_hooks(self):
        """Remove all registered forward hooks."""
        for hook in getattr(self, "amp_hooks", []):
            hook.remove()
        self.amp_hooks = []

    def align_tokens_to_words(self, input_ids, token_preds, token_labels):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        tokens = [self.tokenizer.convert_ids_to_tokens(ids) for ids in input_ids]
        word_preds, word_labels = [], []
        
        for token_seq, pred_seq, label_seq in zip(tokens, token_preds, token_labels):
            for token, pred, label in zip(token_seq, pred_seq, label_seq):
                if token == self.tokenizer.pad_token or label == -100:
                    continue  # Skip padding & ignored labels

                # Detect subword tokens (model-specific handling)
                is_subword = (
                    token.startswith("##") or  # BERT/RoBERTa (WordPiece)
                    token.startswith("▁") or   # IndicBERT/mT5 (SentencePiece)
                    token in ["<unk>", "<pad>"]  # Generic unknown/padding tokens
                )

                if is_subword:
                    continue  # Ignore subword parts, keep only first part's label
                
                # Store the first subword’s label as word-level
                word_preds.append(pred.item())
                word_labels.append(label.item())

        return torch.tensor(word_preds), torch.tensor(word_labels)

    def compute_kl_contrastive_loss(self, new_emb_cpu, old_emb_cpu, device="cuda"):
        """Computes KL divergence and contrastive loss efficiently with minimal GPU usage."""
        
        # Ensure tensors are detached and moved to CPU for lightweight loss computation
        # new_emb_cpu = new_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)
        # old_emb_cpu = old_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)

        # Compute KL divergence using more stable log-softmax
        new_emb_log = torch.nn.functional.log_softmax(new_emb_cpu, dim=-1)
        old_emb_prob = torch.nn.functional.softmax(old_emb_cpu, dim=-1)
        kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean")

        # Compute cosine similarity for contrastive loss
        embedding_drift = torch.nn.functional.cosine_similarity(new_emb_cpu, old_emb_cpu, dim=-1).mean()
        contrastive_loss = 1 - embedding_drift

        # Free CPU memory after computation
        del new_emb_cpu, old_emb_cpu
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Ensure GPU stays clean

        # Move results back to GPU if necessary
        return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    
    def training_step(self, batch, batch_idx):
        """Optimized training step with reduced memory footprint and improved stability."""

        input_ids, attention_mask, labels = batch

        # Ensure data is on the correct device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        attention_mask = attention_mask.to(self.curr_device, non_blocking=True)
        labels = labels.to(self.curr_device, non_blocking=True)

        # Forward pass
        outputs, kl_loss, contrastive_loss = self(input_ids, attention_mask)

        # Flatten outputs and labels for loss computation
        outputs = outputs.contiguous().view(-1, outputs.shape[-1])
        labels = labels.contiguous().view(-1)

        # Compute classification loss
        loss = self._criterion(outputs, labels)

        # Ensure KL and contrastive loss values are finite
        kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
        contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)

        # Combine losses with scaling factors
        loss += 0.05 * kl_loss + 0.05 * contrastive_loss

        # Convert logits to predicted labels
        with torch.no_grad():  # Prevent gradient tracking for metrics
            predicted_labels = torch.argmax(outputs, dim=1)
            accuracy = self._accuracy(predicted_labels, labels)
            precision = self._precision(predicted_labels, labels)
            recall = self._recall(predicted_labels, labels)
            f1 = self._f1(predicted_labels, labels)

        # Check for NaN loss and log issue
        if torch.isnan(loss):
            print(f"Step {batch_idx}: NaN loss detected!")

        # Store training metrics
        train_metrics = {
            "epoch": float(self.current_epoch),  # Ensure rounding for distributed training
            "train_kl_loss": kl_loss.detach(),
            "train_contrastive_loss": contrastive_loss.detach(),
            "train_loss": loss.detach(),
            "train_accuracy": accuracy,
            "train_precision": precision,
            "train_recall": recall,
            "train_f1": f1,
        }

        # Log metrics without unnecessary sync overhead
        self.log_dict(
            train_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,  # Sync across GPUs in distributed training
        )

        # Explicitly delete tensors to free memory
        del input_ids, attention_mask, labels, outputs, predicted_labels
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free GPU memory

        return loss

    
    def validation_step(self, batch, batch_idx):
        """Optimized validation step with better memory handling and stability."""

        input_ids, attention_mask, labels = batch

        # Move tensors to device efficiently
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        attention_mask = attention_mask.to(self.curr_device, non_blocking=True)
        labels = labels.to(self.curr_device, non_blocking=True)

        # Forward pass
        outputs, kl_loss, contrastive_loss = self(input_ids, attention_mask)

        # Flatten outputs and labels for loss computation
        outputs = outputs.contiguous().view(-1, outputs.shape[-1])
        labels = labels.contiguous().view(-1)

        # Handle NaN/Inf values in logits
        if torch.isnan(outputs).any() or torch.isinf(outputs).any():
            print(f"Validation Step {batch_idx}: NaN detected in logits!\n{outputs}")

        # Compute classification loss
        loss = self._criterion(outputs, labels)

        # Ensure KL and contrastive loss values are finite
        kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
        contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)

        # Combine losses with scaling factors
        loss += 0.05 * kl_loss + 0.05 * contrastive_loss

        # Detect NaN loss and log issue
        if torch.isnan(loss):
            print(f"Validation Step {batch_idx}: NaN loss detected!\nInput IDs: {input_ids}\nLabels: {labels}\nOutputs: {outputs}")

        # Convert logits to predicted labels
        with torch.no_grad():  # Avoid tracking gradients for metrics
            predicted_labels = torch.argmax(outputs, dim=1)
            accuracy = self._accuracy(predicted_labels, labels)
            precision = self._precision(predicted_labels, labels)
            recall = self._recall(predicted_labels, labels)
            f1 = self._f1(predicted_labels, labels)

        # Store validation metrics
        val_metrics = {
            "val_kl_loss": kl_loss.detach(),
            "val_contrastive_loss": contrastive_loss.detach(),
            "val_loss": loss.detach(),
            "val_accuracy": accuracy,
            "val_precision": precision,
            "val_recall": recall,
            "val_f1": f1,
        }

        # Log metrics without unnecessary sync overhead
        self.log_dict(
            val_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,  # Sync across GPUs in distributed training
        )

        # Explicitly delete tensors to free memory
        del input_ids, attention_mask, labels, outputs, predicted_labels
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free GPU memory

        return loss

    def test_step(self, batch, batch_idx):
        """Optimized test step for memory-efficient evaluation."""

        with torch.inference_mode():  # More efficient than torch.no_grad()
            # Move batch to GPU with non_blocking
            input_ids, attention_mask, labels = (
                batch[0].to(self.curr_device, non_blocking=True),
                batch[1].to(self.curr_device, non_blocking=True),
                batch[2].to(self.curr_device, non_blocking=True),
            )

            # Forward pass (without KL and contrastive loss)
            outputs, _, _ = self(input_ids, attention_mask)
            predicted_labels = torch.argmax(outputs, dim=-1)

            # Flatten tensors once to avoid repeated `.view(-1)`
            predicted_labels = predicted_labels.view(-1)
            labels = labels.view(-1)

            # Compute evaluation metrics
            accuracy = self._accuracy(predicted_labels, labels)
            precision = self._precision(predicted_labels, labels)
            recall = self._recall(predicted_labels, labels)
            f1 = self._f1(predicted_labels, labels)

            # Log test metrics
            self.log_dict(
                {
                    "test_accuracy": accuracy,
                    "test_precision": precision,
                    "test_recall": recall,
                    "test_f1": f1,
                },
                on_epoch=True,
                sync_dist=True,  # Sync across distributed devices
            )

            # Explicitly delete tensors to free memory
            del input_ids, attention_mask, labels, outputs
            # if batch_idx % 50 == 0 and torch.cuda.is_available():  # Empty cache less frequently
            if torch.cuda.is_available():  # Empty cache less frequently
                torch.cuda.empty_cache()

            return {"predictions": predicted_labels}  # Kept on GPU for batch processing



    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        """Optimized prediction step with efficient memory handling."""

        input_ids, attention_mask, _ = batch  # Labels are not needed

        # Move tensors to device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        attention_mask = attention_mask.to(self.curr_device, non_blocking=True)

        # Forward pass (without computing KL or contrastive loss)
        outputs, _, _ = self(input_ids, attention_mask)
        predicted_labels = torch.argmax(outputs, dim=-1)

        # Explicitly delete tensors to free memory
        del input_ids, attention_mask, outputs
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free GPU memory

        return {"predictions": predicted_labels.cpu()}

    
    def on_before_optimizer_step(self, optimizer):
        # Compute gradient norm before clipping
        # grad_norm_before = self._compute_grad_norm()

        # Clip gradients
        # self.clip_gradients(
        #     optimizer, gradient_clip_val=1.0, gradient_clip_algorithm="value"
        # )
        # Manual clipping
        # torch.nn.utils.clip_grad_value_(self.parameters(), clip_value=1.0)
        torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)


        # Compute gradient norm after clipping
        # grad_norm_after = self._compute_grad_norm()

        # # Log both norms
        # self.log("grad_norm/before", grad_norm_before, prog_bar=True, on_step=True)
        # self.log("grad_norm/after", grad_norm_after, prog_bar=True, on_step=True)

    def _compute_grad_norm(self):
        total_norm = 0
        for param in self.parameters():
            if param.grad is not None:
                param_norm = param.grad.detach().data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5  # L2 norm

    def configure_optimizers(self):
        """Configures optimizer and learning rate scheduler."""
        
        # Filter trainable parameters
        model_parameters = filter(lambda p: p.requires_grad, self.parameters())

        # Select optimizer
        optimizers = {
            "adamw": torch.optim.AdamW,
            "adamax": torch.optim.Adamax,
            "adam": torch.optim.Adam,
        }
        optimizer_class = optimizers.get(self.optimizer_name.lower(), torch.optim.Adam)  # Default to Adam

        optimizer = optimizer_class(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Uncomment if using bitsandbytes optimizers
        # if self.optimizer_name == "adamw":
        #     optimizer = bitsandbytes.optim.AdamW(model_parameters, lr=self.hparams.lr, weight_decay=0.001)
        # elif self.optimizer_name == "adam":
        #     optimizer = bitsandbytes.optim.Adam(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Learning rate scheduler
        lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer, mode="min", factor=0.1, patience=3, cooldown=3, min_lr=1e-8, verbose=True
        )

        # Debugging/logging (if needed)
        # print(f"Using optimizer: {self.optimizer_name}")
        # print(f"Initial learning rate: {self.hparams.lr}")
        # print(f"Weight decay: 0.001")
        
        return {"optimizer": optimizer, "lr_scheduler": {"scheduler": lr_scheduler, "monitor": "val_loss"}}


