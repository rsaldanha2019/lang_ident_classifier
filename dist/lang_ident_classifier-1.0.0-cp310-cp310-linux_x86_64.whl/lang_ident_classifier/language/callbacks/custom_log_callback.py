import csv
import os.path
import re
import subprocess
import socket
import torch
import torch.distributed
from language.utils import date_time_utils as dtu
# import pytorch_lightning as pl
# from pytorch_lightning.utilities.rank_zero import rank_zero_only
# from pytorch_lightning.strategies import SingleDeviceStrategy
import lightning as pl
from lightning.pytorch.utilities.rank_zero import rank_zero_only
from lightning.pytorch.strategies import SingleDeviceStrategy
import optuna

class LoggingCallback(pl.Callback):
    def __init__(self, log, model_summary_callback, metrics_summary_dict, metrics_dir, model_epoch_metrics_file,
                 model_metrics_summary_file, random_seed: int = 20, trial: optuna.trial.Trial = None):
        self.metrics_dict = None
        self.logger = log
        self.trial = trial
        self.model_summary_callback = model_summary_callback
        self.model_epoch_metrics_file = model_epoch_metrics_file
        self.metrics_dir = metrics_dir
        self.model_metrics_summary_file = model_metrics_summary_file
        self.metrics_summary_dict = metrics_summary_dict
        self.start_epoch = None
        self.dtu = dtu.DateTimeUtils()
        self.collection = []
        self.interrupt_flag = False
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 

    def on_train_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        msg = ""
        if torch.cuda.is_available():
            msg += "World Size {} Global Rank {} Local Rank {}\n".format(trainer.world_size, trainer.global_rank,
                                                                         trainer.local_rank)
            msg += "Running on {} with {}\n".format(socket.gethostname(),
                                                    subprocess.check_output(["nvidia-smi", "-L"]).decode("utf8").split(
                                                        "\n")[trainer.local_rank])
            if not isinstance(trainer.strategy, SingleDeviceStrategy):
                msg += "Sampler :: {} created {} number of training samples on node out of {} total samples \n".format(
                    type(trainer.train_dataloader.sampler), trainer.train_dataloader.sampler.num_samples,
                    trainer.train_dataloader.sampler.total_size)
        else:
            msg += "No GPU available using cpu as accelerator\n"

        self.logger.info(msg)


    @rank_zero_only
    def on_train_epoch_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        self.metrics_dict = trainer.callback_metrics
        if self.start_epoch is None:
            start_epoch = self.metrics_dict['epoch'].item()
            self.metrics_summary_dict['start_epoch'] = start_epoch
            self.start_epoch = start_epoch

        metrics_info = ""
        sorted_metrics_dict = dict()
        for key in sorted(self.metrics_dict):
            metrics_info += " {}:{},".format(key, self.metrics_dict[key].item())
            sorted_metrics_dict[key] = self.metrics_dict[key].item()

        self.logger.info(metrics_info)
        if not os.path.exists(self.metrics_dir):
            os.makedirs(self.metrics_dir, exist_ok=True)  # exists_ok used for distributed scenario
        metrics_file_path = os.path.join(self.metrics_dir, self.model_epoch_metrics_file)
        with open(metrics_file_path, 'a+', encoding="utf8") as mdl_metrics_file:
            writer = csv.DictWriter(mdl_metrics_file, fieldnames=sorted_metrics_dict.keys())
            if os.path.getsize(metrics_file_path) == 0:  # File is empty
                writer.writeheader()
            writer.writerows([sorted_metrics_dict])
        
        # Example: Early stopping message
        if trainer.should_stop:
            self.logger.info("Early stopping activated.")

        # Example: Learning rate change message
        for optimizer in trainer.optimizers:
            for param_group in optimizer.param_groups:
                lr = param_group['lr']
                self.logger.info(f"Current learning rate: {lr}")

    # def _filter_summary(self, model_summary):
    #     model_summary = str(model_summary)
    #     # List of attributes to exclude from the summary
    #     exclude = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

    #     # Split into lines for better processing
    #     lines = model_summary.splitlines()
    #     filtered_lines = []
        
    #     for line in lines:
    #         # Check if any of the excluded names are in the current line
    #         if any(name in line for name in exclude):
    #             continue  # Skip this line entirely

    #         filtered_lines.append(line)

    #     # Reconstruct the summary after removing excluded lines
    #     return "\n".join(filtered_lines)

    # def _filter_summary(self, trainer, model_summary):
    #     model_summary = str(model_summary)
    #     return model_summary

    # def _filter_summary(self, trainer, model_summary):
    #     model_summary = str(model_summary)
    #     exclude = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

    #     # Split summary into lines
    #     lines = model_summary.splitlines()
    #     filtered_lines = []
        
    #     trainable_params = None
    #     non_trainable_params = None

    #     def parse_param_count(param_str):
    #         """ Convert human-readable params (e.g., '414 K', '1.2 B') into integers """
    #         param_str = param_str.replace(",", "").strip()
    #         match = re.search(r"([\d\.]+)\s*([KMGTB]?)", param_str)
    #         if match:
    #             num, suffix = match.groups()
    #             num = float(num)
    #             multiplier = {"K": 1e3, "M": 1e6, "B": 1e9, "T": 1e12}.get(suffix, 1)
    #             return int(num * multiplier)
    #         return None  # Ensure None is returned for missing values

    #     for line in lines:
    #         if any(name in line for name in exclude):
    #             continue  # Remove metric and criterion lines
            
    #         if "Trainable params" in line:
    #             trainable_params = parse_param_count(line)
    #         elif "Non-trainable params" in line:
    #             non_trainable_params = parse_param_count(line)

    #         filtered_lines.append(line)

    #     # Compute corrected total params only if both values exist
    #     if trainable_params is not None and non_trainable_params is not None:
    #         total_params = trainable_params + non_trainable_params
    #         total_params_str = f"{total_params:,} Total params"  # Format with commas

    #         # Update total params line
    #         for i, line in enumerate(filtered_lines):
    #             if "Total params" in line:
    #                 filtered_lines[i] = total_params_str
    #                 break  

    #     return "\n".join(filtered_lines)

    def _filter_summary(self, trainer, model_summary):
        model_summary = str(model_summary)
        exclude = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

        # Split summary into lines
        lines = model_summary.splitlines()
        filtered_lines = []
        
        # Variables to store the total params
        trainable_params = 0
        non_trainable_params = 0
        total_params = 0
        model_size = 0
        header_added = False

        def parse_param_count(param_str):
            """ Convert human-readable params (e.g., '414 K', '1.2 B') into integers """
            param_str = param_str.replace(",", "").strip()
            match = re.search(r"([\d\.]+)\s*([KMGTB]?)", param_str)
            if match:
                num, suffix = match.groups()
                num = float(num)
                multiplier = {"K": 1e3, "M": 1e6, "B": 1e9, "T": 1e12}.get(suffix, 1)
                return int(num * multiplier)
            return 0  # Return 0 if parsing fails

        def count_params(layer):
            """Count params for a given layer, differentiating between trainable and non-trainable."""
            total_params = 0
            trainable = 0
            non_trainable = 0
            
            # Iterate through parameters of the layer
            for p in layer.parameters():
                param_count = p.numel()
                total_params += param_count
                if p.requires_grad:
                    trainable += param_count
                else:
                    non_trainable += param_count
                    
            return total_params, trainable, non_trainable

        # Table header format
        header = "| {:<20} | {:<40} | {:>15} | {:>15} | {:>15} |".format(
            "Layer Name", "Type", "Params", "Trainable", "Non-Trainable"
        )
        separator = "-" * len(header)

        # Iterate through lines to capture the summary
        for line in lines:
            if any(name in line for name in exclude):
                continue  # Remove metric and criterion lines
            
            # Extract the layer name and type
            match = re.match(r"(\d+)\s+\|\s+([\w\.]+)\s+\|\s+([\w\d]+)\s+\|\s+(.+)", line)
            if match:
                _, layer_name, layer_type, param_str = match.groups()
                layer_total = parse_param_count(param_str)  # Convert readable params to integer
                
                # Get the layer object by name
                layer = getattr(trainer.model, layer_name, None)
                if layer:
                    # Get trainable and non-trainable params per layer
                    layer_total, layer_trainable, layer_non_trainable = count_params(layer)
                    
                    # Add the counts to global totals
                    trainable_params += layer_trainable
                    non_trainable_params += layer_non_trainable
                    total_params += layer_total
                    model_size += layer_total

                    # Format the line with the calculated params
                    formatted_line = "| {:<20} | {:<40} | {:>15,} | {:>15,} | {:>15,} |".format(
                        layer_name, layer_type, layer_total, layer_trainable, layer_non_trainable
                    )
                    
                    if not header_added:
                        # Add headers only once
                        filtered_lines.append(separator)
                        filtered_lines.append(header)
                        filtered_lines.append(separator)
                        header_added = True

                    filtered_lines.append(formatted_line)

        # Convert size to MB/GB dynamically
        model_size_gb = model_size * 4 / (1024 ** 3)  # Convert to GB
        model_size_mb = model_size * 4 / (1024 ** 2)  # Convert to MB
        size_str = f"{model_size_gb:.2f} GB" if model_size_gb >= 1 else f"{model_size_mb:.2f} MB"

        # Add final summary of total params
        filtered_lines.append(separator)
        filtered_lines.append(f"| {'Total params:':<64} | {total_params:>15,} |")
        filtered_lines.append(f"| {'Trainable params:':<64} | {trainable_params:>15,} |")
        filtered_lines.append(f"| {'Non-Trainable params:':<64} | {non_trainable_params:>15,} |")
        filtered_lines.append(f"| {'Model size:':<64} | {size_str:>15} |")
        filtered_lines.append(separator)

        return "\n".join(filtered_lines)


    # @rank_zero_only
    def on_fit_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        # self.metrics_dict = trainer.callback_metrics
        training_start_time = self.dtu.get_current_time_in_milliseconds()
        training_start_date_time = self.dtu.get_utc_date_time()
        self.logger.info("Model Training started at {}".format(training_start_date_time))
        if trainer.global_rank == 0:
            self.metrics_dict = trainer.callback_metrics
            self.metrics_summary_dict['training_start_time'] = training_start_time
            self.metrics_summary_dict['training_start_date_time'] = training_start_date_time
        # print model summary trainable params
        model_summary = self.model_summary_callback._summary(trainer, pl_module)
        # Exclude unnecessary attributes like metrics and criterion
        model_summary = self._filter_summary(trainer, model_summary)
        self.logger.info(f"Model Training Parameters Summary on Rank {trainer.global_rank} \n{model_summary}")
    
    @rank_zero_only
    def on_test_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        # print model summary trainable params
        model_summary = self.model_summary_callback._summary(trainer, pl_module)
        # Exclude unnecessary attributes like metrics and criterion
        model_summary = self._filter_summary(trainer, model_summary)
        self.logger.info("Model Training Parameters Summary \n{}".format(
            # self.model_summary_callback._summary(trainer=trainer, pl_module=pl_module)))
            model_summary))
    
    @rank_zero_only
    def on_exception(self, trainer: pl.Trainer, pl_module: pl.LightningModule, exception: BaseException) -> None:
        self._log_model_training_info(trainer=trainer, pl_module=pl_module, 
                                      message="Abnormal Termination due to Exception or an explicit interruption in program")
    
    @rank_zero_only
    def on_fit_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        self.logger.info(f"After Fit Model Summary")
        self._log_model_training_info(trainer, pl_module, message="Training Completed Normally ")

    def _log_model_training_info(self, trainer: pl.Trainer, pl_module: pl.LightningModule, message: str):
        if self.trial:
            self.metrics_summary_dict['trial_number'] = self.trial.number
        if self.start_epoch is None:
            self.metrics_summary_dict['start_epoch'] = float(trainer.current_epoch)
        end_epoch = trainer.callback_metrics['epoch'] if 'epoch' in trainer.callback_metrics else trainer.current_epoch
        self.metrics_summary_dict["end_epoch"] = float(end_epoch) if isinstance(end_epoch, int) else end_epoch.item()
        training_end_time = self.dtu.get_current_time_in_milliseconds()
        self.metrics_summary_dict["training_end_time"] = training_end_time
        training_end_date_time = self.dtu.get_utc_date_time()
        self.logger.info("Training completed at {}".format(training_end_date_time))
        self.metrics_summary_dict["training_end_date_time"] = training_end_date_time
        model_training_time = training_end_time - self.metrics_summary_dict["training_start_time"]
        self.metrics_summary_dict["model_training_time"] = model_training_time
        # Example: Early stopping message
        if trainer.should_stop:
            self.logger.info(f"Early stopping activated. {trainer.callback_metrics['epoch']+1} epochs have been completed.")
            message += " Early Stopping Implemented."
        self.logger.info(
            "Total Training Time {} hours {} minutes {} seconds".format(
                *self.dtu.get_hms_from_milliseconds(model_training_time)))
        self.metrics_summary_dict["model_training_time_details"] = "{} hours {} minutes {} seconds".format(
            *self.dtu.get_hms_from_milliseconds(model_training_time))
        self.metrics_summary_dict["model_training_status"] = message
        if not os.path.exists(self.metrics_dir):
            os.mkdir(self.metrics_dir)
        metrics_file_path = os.path.join(self.metrics_dir, self.model_metrics_summary_file)
        with open(metrics_file_path, 'a+', encoding="utf8") as mdl_metrics_file:
            writer = csv.DictWriter(mdl_metrics_file, fieldnames=self.metrics_summary_dict.keys())
            if os.path.getsize(metrics_file_path) == 0:  # File is empty
                writer.writeheader()
            writer.writerows([self.metrics_summary_dict])

        # print model summary trainable params
        model_summary = self.model_summary_callback._summary(trainer, pl_module)
        # Exclude unnecessary attributes like metrics and criterion
        model_summary = self._filter_summary(trainer, model_summary)
        self.logger.info(f"Model Training Parameters Summary on Rank {trainer.global_rank} \n{model_summary}")
