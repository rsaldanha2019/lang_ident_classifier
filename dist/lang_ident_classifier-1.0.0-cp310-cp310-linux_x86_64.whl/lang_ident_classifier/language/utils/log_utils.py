# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : log_utils
# @Time             : 18/12/23 9:04 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import os
import logging as lg
import time
import zipfile
from logging import Logger
from logging.handlers import TimedRotatingFileHandler
from lang_ident_classifier.language.utils.property_utils import Properties
from lang_ident_classifier.language.utils.file_dir_utils import FileDirUtils
from lang_ident_classifier.language.utils.date_time_utils import DateTimeUtils


class LogUtils:
    """
    Operations for Logging.
    """

    def __init__(self):
        self.fdu = FileDirUtils()
        self.dtu = DateTimeUtils()

    def get_time_rotated_log(self, props: Properties) -> Logger:
        """
        Takes a properties object and returns a logger.
        :param props: properties file object
        :return: logger object
        """
        log_config_name = props.app.model_config_name
        log_dir_path = os.path.join(props.app.logs_dir, log_config_name)

        # Ensure log directory exists
        if not self.fdu.check_file_or_dir_exists(file_dir_path=log_dir_path):
            self.fdu.create_dir(dir_path=log_dir_path)

        log_datetime_prefix_format = props.logs.prefix
        log_prefix = self.dtu.get_utc_datetime_timestamp_string(
            datetime_format=log_datetime_prefix_format)
        log_suffix = props.logs.suffix
        log_file_name = "_".join([log_prefix, log_suffix])
        log_file_path = os.path.join(log_dir_path, log_file_name)

        lg.getLogger()
        lg.Formatter.converter = time.gmtime

        # Set up TimedRotatingFileHandler for log rotation at midnight
        time_handler = TimedRotatingFileHandler(
            log_file_path, utc=True, when='midnight', encoding='utf-8', backupCount=30)

        # Set up stream handler for console output
        stream_handler = lg.StreamHandler()

        # Basic configuration of logging with added module and timestamp in format
        lg.basicConfig(format='%(asctime)s %(module)s %(levelname)s: %(message)s',
                       level=lg.INFO,
                       handlers=[time_handler, stream_handler])

        # Force the log rotation to happen immediately after midnight
        time_handler.doRollover()

        return lg

    def zip_logs_with_prefix(self, archive_log_path: str, prefix: str) -> None:
        """
        Takes in archive log path and prefix and archives log with same prefix.
        :param archive_log_path: location of archive for logs
        :param prefix: prefix of the log files
        :return:
        """
        with zipfile.ZipFile(f'{prefix}_archive.zip', 'w') as zipf:
            for filename in os.listdir(archive_log_path):
                if filename.startswith(prefix) and filename.endswith('.log'):
                    file_path = os.path.join(archive_log_path, filename)
                    zipf.write(file_path, arcname=filename)
                    os.remove(file_path)
