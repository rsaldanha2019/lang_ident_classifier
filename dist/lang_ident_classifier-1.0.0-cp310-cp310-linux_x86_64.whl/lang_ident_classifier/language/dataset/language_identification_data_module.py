# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_data_module
# @Time             : 19/12/23 12:11 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import math
import os
import random
import lightning as pl
import numpy as np
from lightning.pytorch.utilities.data import DataLoader
from lightning.pytorch.utilities.types import TRAIN_DATALOADERS, EVAL_DATALOADERS
import torch
import torch.utils
import torch.utils.data
import torch.utils.data.distributed
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset

class LanguageIdentificationDataModule(pl.LightningDataModule):
    """
    contains methods for dataloader operations for
    the lightning data module
    """
    def __init__(self,
                 train_dataset: LanguageIdentificationDataset = None,
                 val_dataset: LanguageIdentificationDataset = None,
                 test_dataset: LanguageIdentificationDataset = None,
                 predict_dataset: LanguageIdentificationDataset = None,
                 batch_size: int = 8,
                 train_data_shuffle: bool = True,
                 random_seed: int = 20):
        super(LanguageIdentificationDataModule, self).__init__()
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        np.random.seed(random_seed)
        self.random_seed = random_seed
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.test_dataset = test_dataset
        self.predict_dataset = predict_dataset
        self.batch_size = batch_size
        self.num_workers = math.ceil(os.cpu_count()*0.4) # uses 40% of cpus available
        self.train_data_shuffle = train_data_shuffle
        self.gen = torch.Generator()
        self.gen.manual_seed(random_seed)
    
    def worker_init_fn(self, worker_id):
        # np.random.seed(self.random_seed + worker_id)  # Use the global seed for initialization
        worker_seed = self.random_seed + worker_id
        np.random.seed(worker_seed)
        random.seed(worker_seed)
    
    def train_dataloader(self) -> TRAIN_DATALOADERS:
        """
        using the class instance params, creates a
        train dataloader instance
        :return: train dataloader instance
        """
        if self.train_dataset is not None:
            return DataLoader(self.train_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.num_workers,
                              persistent_workers=True,
                              shuffle=self.train_data_shuffle,
                              worker_init_fn=self.worker_init_fn,
                              generator=self.gen,
                              prefetch_factor=self.num_workers*2,
                              pin_memory=True)

    def val_dataloader(self) -> EVAL_DATALOADERS:
        """
        using the class instance params, creates a
        validation dataloader instance
        :return: val dataloader instance
        """
        if self.val_dataset is not None:
            return DataLoader(self.val_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.num_workers,
                              persistent_workers=True,
                              shuffle=False,
                              worker_init_fn=self.worker_init_fn,
                              generator=self.gen,
                              prefetch_factor=self.num_workers*2,
                              pin_memory=True)

    def test_dataloader(self) -> EVAL_DATALOADERS:
        """
        Creates a test DataLoader that handles both single-device and multi-device setups dynamically.
        """
        is_single_device = torch.cuda.device_count() <= 1 or not torch.distributed.is_initialized()
        
        sampler = None
        if not is_single_device:
            sampler = torch.utils.data.distributed.DistributedSampler(
                self.test_dataset,
                shuffle=False,  # No shuffling for testing
                seed=self.random_seed
            )
        
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            persistent_workers=True if self.num_workers > 0 else False, # prevent None check in distributed setup
            shuffle=False,  # Shuffle only in single-device setup
            sampler=sampler,
            worker_init_fn=self.worker_init_fn,
            generator=self.gen,
            prefetch_factor=self.num_workers*2,
            pin_memory=True)


    def predict_dataloader(self) -> EVAL_DATALOADERS:
        """
        using the class instance params, creates a
        predict dataloader instance
        :return: predict data loader instance
        """
        if self.predict_dataset is not None:
            return DataLoader(self.predict_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.num_workers,
                              persistent_workers=True,
                              shuffle=False,
                              worker_init_fn=self.worker_init_fn,
                              generator=self.gen)



