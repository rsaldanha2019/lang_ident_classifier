# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_dataset
# @Time             : 18/12/23 2:34 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor
import functools
from itertools import chain
import json
from multiprocessing import Pool, cpu_count
import os
from difflib import SequenceMatcher
from logging import Logger
import random
import re
from typing import Any
import unicodedata
import numpy as np
import torch
from torch.utils.data import Dataset

class LanguageIdentificationDataset(Dataset):
    """
    contains methods for Dataset related operations
    """

    def __init__(self, data_dir: str, files_have__header: bool,
                 pretrained_embedding_tokenizer: Any, max_output_length: int,
                 classes_config_path: str, log: Logger,
                 is_train: bool, sample_dataset_share: float = 1.0,
                 random_seed: int = 20):
        """
        initializes the class instance with default parameters
        :param data_dir: path of the data directory
        :param files_have__header: if True, indicates that
        files have header and will skip 1 line
        :param log: instance of a Logger object for logging
        """
        super(LanguageIdentificationDataset, self).__init__()
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        random.seed(random_seed)
        np.random.seed(random_seed)
        self.log = log
        self.is_train = is_train
        self.files_have_header = files_have__header
        self.data_dir = data_dir
        self.max_seq_length = max_output_length
        self.tokenizer = pretrained_embedding_tokenizer
        self.src_data = []
        self.tgt_data = []
        self.file_stats = {}
        self.sample_dataset_share = sample_dataset_share
        self._validate_and_load_file_data()
        self.classes, self.class_weights = self._get_classes_dict(classes_config_path, is_train)

    def __len__(self):
        """
        method to obtain number of samples in the dataset
        :return: length of the dataset
        """
        return len(self.tgt_data)

    def _get_class_id_from_lang_code(self, lang_code):
        for lang_id, lang_info in self.classes.items():
            if lang_info["lang_code"] == lang_code.strip():
                return lang_id

    def _get_lang_code_from_class_id(self, class_id):
        return self.classes[class_id]["lang_code"]

    def get_num_classes(self):
        return len(self.classes)

    def _add_languages(self, lang_code_dict):
        # Create dictionary with counts using dictionary comprehension
        # new_languages_dict = {value: self.tgt_data.count(value) for value in set(self.tgt_data)}
        # Count occurrences of unique languages per sample
        # new_languages_dict = dict(Counter(
        #     lang.strip()  # Remove extra spaces
        #     for entry in self.tgt_data 
        #     for lang in set(entry.split(","))  # Ensure unique languages per sample
        # ))
        # Optimized Counting
        new_languages_dict = defaultdict(int)

        for lang in map(str.strip, chain.from_iterable(entry.split(",") for entry in self.tgt_data)):
            new_languages_dict[lang] += 1  # Direct increment (avoids key checks)

        # Convert to a regular dict if needed
        new_languages_dict = dict(new_languages_dict)

        if next((key for key, value in lang_code_dict.items() if value['lang_code'] == "unk"), None) is None:
            new_lang_id = 0
            lang_code_dict[new_lang_id] = {"lang_code": "unk", "lang_samples": 0, "lang_files": []}

        for lang in new_languages_dict:
            lang = lang.strip()
            key_for_lang_code = next((key for key, value in lang_code_dict.items() if value['lang_code'] == lang), None)
            if key_for_lang_code is None:
                new_lang_id = len(lang_code_dict)
                lang_code_dict[new_lang_id] = {"lang_code": lang, "lang_samples": new_languages_dict[lang], "lang_files": self.file_stats[lang]}
            else:
                new_lang_id = key_for_lang_code
                samples_lang_code = lang_code_dict[key_for_lang_code]["lang_samples"]
                files_lang_code = lang_code_dict[key_for_lang_code]["lang_files"]
                if samples_lang_code < new_languages_dict[lang]:
                    new_samples = samples_lang_code + new_languages_dict[lang]
                    lang_code_dict[new_lang_id] = {"lang_code": lang, "lang_samples": new_samples, "lang_files": files_lang_code + self.file_stats[lang]}
        return lang_code_dict
    
    def _normalize_class_weights(self, weights):
        total_weight = np.sum(weights)
        normalized_weights = weights / total_weight
        return normalized_weights

    def _get_class_weights(self, classes_dict):
        # Calculate class weights based on lang_samples
        total_samples = sum(entry['lang_samples'] for entry in classes_dict.values())

        class_weights = {}
        for lang_code, lang_data in classes_dict.items():
            class_samples = lang_data['lang_samples']
            if class_samples > 0:
                # weights are inversely proportional to number of samples
                class_weight = total_samples / (class_samples * len(classes_dict))
            else:
                class_weight = 0  # Set weight to 0 if there are no samples
            classes_dict[lang_code].update({"lang_weight":class_weight})
        class_weights = [entry['lang_weight'] for entry in classes_dict.values()]
        # class_weights = self._normalize_class_weights(class_weights)
        # Update the lang_weights with normalized class weights
        for i, (lang_code, lang_data) in enumerate(classes_dict.items()):
            lang_data["lang_weight"] = class_weights[i]
        return class_weights, classes_dict

    def _get_classes_dict(self, classes_config_path, is_train):
        classes_dict = {}
        class_weights = {}
        if os.path.exists(classes_config_path):
            with open(classes_config_path, mode='r+', encoding='utf8') as ccp:
                # classes_dict = json.load(ccp)
                raw_dict = json.load(ccp)  # Load JSON normally (keys are strings)
    
                classes_dict = {
                    float(k) if "." in k else int(k): v  # Convert only top-level keys
                    for k, v in raw_dict.items()
                }

        if is_train:
            classes_dict = self._add_languages(lang_code_dict=classes_dict)
            class_weights, classes_dict = self._get_class_weights(classes_dict=classes_dict)

            with open(classes_config_path, mode='w+', encoding='utf8') as ccp_w:
                json.dump(classes_dict, ccp_w, indent=2)

        return classes_dict, class_weights
    
    def get_labels(self):
        return [self._get_class_id_from_lang_code(lang_code) for lang_code in self.tgt_data]

    def __getitem__(self, idx: int) -> Any:
        """
        method to take an index value and return
        the source text and its target label
        :param idx: index value
        :return: source text and target label
        """
        # tokenized_input = self.tokenizer.encode_plus(self.src_data[idx],
        #                                             truncation=True,
        #                                             padding='max_length',
        #                                             max_length=self.max_seq_length,
        #                                             return_tensors='pt')
        # input_ids = tokenized_input['input_ids'].squeeze(0)
        # attention_mask = tokenized_input['attention_mask'].squeeze(0)
        input_ids = torch.tensor(self.src_data[idx], dtype=torch.long)  

        attention_mask = torch.tensor(
            [1 if token != self.tokenizer.pad_token_id else 0 for token in self.src_data[idx]], 
            dtype=torch.long
        )

        target_id = int(self._get_class_id_from_lang_code(self.tgt_data[idx]))
        if target_id is None:
            print(f'Language not present check {idx}, {self.tgt_data[idx]}')
            target_id = 0  # Default to 0 if None

        # Match `target_ids` padding structure exactly with `input_ids`
        target_ids = torch.tensor([
            target_id if token != self.tokenizer.pad_token_id else self.tokenizer.pad_token_id
            for token in self.src_data[idx]
        ] + [self.tokenizer.pad_token_id] * (self.max_seq_length - len(self.src_data[idx])),
        dtype=torch.long)

        # print(f"Shapes {input_ids.shape} {target_ids.shape} {attention_mask.shape} and Src :: {input_ids} and target ids {target_ids} and attn mask {attention_mask}")
        return input_ids, attention_mask, target_ids



    def _similar_name(self, name_1: str, name_2: str) -> float:
        """
        takes two filenames, compares and returns the match score
        :param name_1: file name of file 1
        :param name_2: file name of file 2
        :return: match score
        """
        return SequenceMatcher(None, name_1, name_2).ratio()

    # Function to calculate overlap length based on percentage
    def _calculate_overlap(self, overlap_percentage):
        return int(self.max_seq_length * overlap_percentage)

    # Function to split line into overlapping windows
    @staticmethod
    def _split_into_windows(src_line, overlap_length, max_seq_length):
        windows = []
        for i in range(0, len(src_line), max_seq_length - overlap_length):
            windows.append(src_line[i:i + max_seq_length])
        return windows
    
    @staticmethod
    def _is_arabic(text):
        for char in text:
            if 'ARABIC' not in unicodedata.name(char, ''):
                return False
        return True

    @staticmethod
    def _reverse_arabic_sentence(sentence):
        if LanguageIdentificationDataset._is_arabic(sentence):
            # If the sentence is in Arabic script, reverse it
            # reversed_sentence = sentence[::-1]
            # Step 1: Split the sentence into words
            words = sentence.strip().split()

            # Step 2: Reverse the order of words (keeping characters in place)
            reversed_sentence = " ".join(reversed(words))
            # reversed_sentence = sentence
            return reversed_sentence
        else:
            return sentence
    
    @staticmethod
    def _is_english_string(input_string):
        # Function to check if a character is part of the English alphabet
        def is_english_char(char):
            return 'a' <= char.lower() <= 'z'

        # Convert the string to a list of characters
        characters = list(input_string)

        # Count the English alphabet characters
        english_chars_count = sum(1 for char in characters if is_english_char(char))

        # Calculate the percentage of English alphabet characters
        percentage_english = english_chars_count / len(characters)

        # Check if more than 50% of characters are from the English alphabet
        return percentage_english > 0.5
    
    @staticmethod
    def process_line(args):
        """
        Process a single line: clean, check language, tokenize, and split.
        Returns (src_tokens, tgt_line) if valid, else None.
        """
        (src_line, tgt_line, max_seq_length, overlap_percentage, pad_token_id, 
         is_english_func, reverse_arabic_func, split_windows_func, tokenizer_encode_func) = args

        tgt_line = tgt_line.strip()
        src_line = ' '.join(src_line.split())  # Remove extra spaces

        # Check language constraints
        is_english = is_english_func(src_line)
        if ("_en" in tgt_line and not is_english) or ("_en" not in tgt_line and is_english):
            return None  # Skip mismatched languages

        src_line = reverse_arabic_func(src_line).strip()  # Reverse Arabic if needed

        # Tokenize
        src_tokens = tokenizer_encode_func(src_line)

        # Handle long sequences
        if len(src_tokens) > max_seq_length:
            overlap_len = int(overlap_percentage * max_seq_length)
            windows = split_windows_func(src_tokens, overlap_len, max_seq_length)
            windows = [win + [pad_token_id] * (max_seq_length - len(win)) for win in windows]
            return [(win, tgt_line) for win in windows]
        else:
            # Pad shorter sequences to max_seq_length
            src_tokens += [pad_token_id] * (max_seq_length - len(src_tokens))
            return [(src_tokens, tgt_line)]

    @staticmethod
    def encode_text(text, tokenizer):
        """Static method for tokenization to avoid pickling errors."""
        return tokenizer.encode_plus(text, truncation=False, return_tensors=None)["input_ids"]

    def _process_file_data(self, src_file, tgt_file):
        with open(src_file, mode='r', encoding='utf8') as sfile, open(tgt_file, mode='r', encoding='utf8') as tfile:
            if self.files_have_header:
                src_file_lines = sfile.readlines()[1:]
                tgt_file_lines = tfile.readlines()[1:]
            else:
                src_file_lines = sfile.readlines()
                tgt_file_lines = tfile.readlines()

        lang_code = list(set(tgt_file_lines))[0].strip()
        num_of_samples_to_use = int(len(src_file_lines) * self.sample_dataset_share)

        # Randomly select some share of data from the list
        src_file_lines = random.sample(src_file_lines, num_of_samples_to_use)
        tgt_file_lines = random.sample(tgt_file_lines, num_of_samples_to_use)
        self.log.info(f"Sampled {self.sample_dataset_share*100} percent of {src_file} dataset with {len(src_file_lines)} samples.")

        num_workers = max(1, int(cpu_count() * 0.4))  # Use 40% of available CPU cores

        # Prepare multiprocessing arguments
        args_list = [
            (src_line, tgt_line, self.max_seq_length, 0.5, self.tokenizer.pad_token_id,
             LanguageIdentificationDataset._is_english_string, LanguageIdentificationDataset._reverse_arabic_sentence, 
             LanguageIdentificationDataset._split_into_windows,
             functools.partial(LanguageIdentificationDataset.encode_text, tokenizer=self.tokenizer))  # Pass method reference
            for src_line, tgt_line in zip(src_file_lines, tgt_file_lines)
        ]

        # Use multiprocessing with safer settings
        with Pool(processes=num_workers) as pool:
            results = pool.map(LanguageIdentificationDataset.process_line, args_list)

        # Flatten results and remove None values
        processed_pairs = [pair for sublist in results if sublist for pair in sublist]

        # Separate into source and target lists
        new_src_file_lines, new_tgt_file_lines = zip(*processed_pairs) if processed_pairs else ([], [])

        return lang_code, list(new_src_file_lines), list(new_tgt_file_lines)

    def _validate_and_load_file_data(self):
        """
        validates, loads and processes data
        :return: None
        """
        # filename_match_threshold = 0.99
        src_files_list = []
        tgt_files_list = []

        for lang_dir in os.listdir(self.data_dir):
            self.log.info(f"Now processing {os.path.join(self.data_dir, lang_dir)} directory.")
            src_data_dir = os.path.join(self.data_dir, lang_dir, 'src')
            tgt_data_dir = os.path.join(self.data_dir, lang_dir, 'tgt')
            for src_file in os.listdir(src_data_dir):
                matched = False
                for tgt_file in os.listdir(tgt_data_dir):
                    # sim_score = self._similar_name(src_file, tgt_file)
                    # if sim_score >= filename_match_threshold:
                    if src_file.split(".")[0] == tgt_file.split(".")[0]:
                        src_files_list.append(src_file)
                        tgt_files_list.append(tgt_file)
                        matched = True
                        break
                if matched:
                    continue  # continue to next loop
                else:
                    self.log.info(f"Skipping file {src_file} since matching label file not found in {tgt_data_dir}.")
            # Validate files and content
            src_filtered_files = [os.path.join(src_data_dir, file) for file in src_files_list if
                                  os.path.isfile(os.path.join(src_data_dir, file))]
            tgt_filtered_files = [os.path.join(tgt_data_dir, file) for file in tgt_files_list if
                                  os.path.isfile(os.path.join(tgt_data_dir, file))]
            if len(src_filtered_files) != len(tgt_filtered_files):
                msg_err_num_files = f"Number of files in {src_data_dir} is {len(src_filtered_files)} does not match" \
                                    f"with {len(tgt_filtered_files)} files present in {tgt_data_dir}"
                raise ValueError(msg_err_num_files)
            else:
                for src_file, tgt_file in zip(src_filtered_files, tgt_filtered_files):
                    new_src_file_lines = []
                    new_tgt_file_lines = []
                    src_num_lines = sum(1 for _ in open(src_file))
                    tgt_num_lines = sum(1 for _ in open(tgt_file))
                    src_num_lines = src_num_lines - 1 if self.files_have_header else src_num_lines
                    tgt_num_lines = tgt_num_lines - 1 if self.files_have_header else tgt_num_lines
                    if src_num_lines != tgt_num_lines:
                        self.log.info(f"{src_num_lines} lines in {src_file} "
                                      f"do not match with {tgt_num_lines} in {tgt_file}, skipping processing these files")
                    else:
                        self.log.info(f"Processing {src_file} and {tgt_file} with {tgt_num_lines} samples.")
                        lang_code, new_src_file_lines , new_tgt_file_lines = self._process_file_data(src_file, tgt_file)
                            
                        # num_of_samples_to_use = int(len(new_src_file_lines) * self.sample_dataset_share)

                        # # Randomly select some share of data from the list
                        # new_src_file_lines = random.sample(new_src_file_lines, num_of_samples_to_use)
                        # new_tgt_file_lines = random.sample(new_tgt_file_lines, num_of_samples_to_use)
                        # self.log.info(f"Sampled {self.sample_dataset_share*100} percent of this dataset")

                        # any further preprocessing here and then append
                        self.src_data.extend(new_src_file_lines)
                        self.tgt_data.extend(new_tgt_file_lines)
                        
                        if self.is_train:
                            if lang_code not in self.file_stats:
                                self.file_stats.update({lang_code : [{"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)}]})
                            else:
                                self.file_stats[lang_code].append({"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)})
                        self.log.info(f"Files {src_file} and {tgt_file} have {len(new_tgt_file_lines)} samples after processing.")



