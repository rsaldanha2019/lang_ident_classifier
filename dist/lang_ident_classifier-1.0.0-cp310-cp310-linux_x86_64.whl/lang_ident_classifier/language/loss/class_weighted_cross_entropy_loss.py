# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : custom_loss
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import lightning as pl
import torch

class ClassWeightedCrossEntropyLoss(pl.LightningModule):
    def __init__(self, device='cpu', class_weights=None, reduction="mean", random_seed:int = 20, ignore_index: int= -100):
        super(ClassWeightedCrossEntropyLoss, self).__init__()
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        self.curr_device = device
        self.reduction = reduction
        self.ignore_index = ignore_index
        if class_weights is not None:
            self.class_weights = torch.tensor(class_weights).to(device)
            self.ce_loss = torch.nn.CrossEntropyLoss(weight=self.class_weights, reduction="none", ignore_index=self.ignore_index)
        else:
            self.class_weights = class_weights
            self.ce_loss = torch.nn.CrossEntropyLoss(reduction="none", ignore_index=ignore_index)

    def forward(self, logits, targets):
        # Flatten logits and targets
        logits = logits.view(-1, logits.size(-1))
        targets = targets.view(-1)

        # Mask out ignored indices
        valid_mask = targets != self.ignore_index
        if not valid_mask.any():
            return torch.tensor(0.0, device=logits.device, requires_grad=True)

        logits, targets = logits[valid_mask], targets[valid_mask]

        # Check for extreme logits
        # if (logits > 10).any() or (logits < -10).any():
        #     print(f"Warning: Extreme logits found! min={logits.min().item()}, max={logits.max().item()}")
        #     # Clamp logits to prevent extreme values
        #     logits = torch.clamp(logits, min=-10, max=10)

        # Compute cross-entropy loss
        weighted_cross_entropy_loss = self.ce_loss(logits, targets)

        # Replace NaN/Inf with a small value
        # if torch.isnan(weighted_cross_entropy_loss).any() or torch.isinf(weighted_cross_entropy_loss).any():
        #     weighted_cross_entropy_loss = torch.tensor(1e-6, device=logits.device, requires_grad=True)

        # # Apply reduction
        if self.reduction == "mean":
            loss = weighted_cross_entropy_loss.mean()
        elif self.reduction == "sum":
            loss = weighted_cross_entropy_loss.sum()
        else:
            loss = weighted_cross_entropy_loss
        return loss
    
    # def forward(self, logits, targets):
    #     print("\n==== Forward Pass Debugging ====")

    #     # Print initial logits and targets
    #     print(f"Initial logits - min: {logits.min().item()}, max: {logits.max().item()}, NaNs: {torch.isnan(logits).sum().item()}")
    #     print(f"Initial targets - min: {targets.min().item()}, max: {targets.max().item()}, NaNs: {torch.isnan(targets).sum().item()}")

    #     # Flatten logits and targets
    #     logits = logits.view(-1, logits.size(-1))
    #     targets = targets.view(-1)

    #     print(f"Flattened logits shape: {logits.shape}, Flattened targets shape: {targets.shape}")

    #     # Mask out ignored indices
    #     valid_mask = targets != self.ignore_index
    #     print(f"Valid mask sum (should be >0): {valid_mask.sum().item()}")

    #     if not valid_mask.any():
    #         print("No valid targets found, returning 0 loss.")
    #         return torch.tensor(0.0, device=logits.device, requires_grad=True)

    #     logits, targets = logits[valid_mask], targets[valid_mask]

    #     # Check for NaNs and extremes after masking
    #     print(f"Post-masking logits - min: {logits.min().item()}, max: {logits.max().item()}, NaNs: {torch.isnan(logits).sum().item()}")
    #     print(f"Post-masking targets - min: {targets.min().item()}, max: {targets.max().item()}, NaNs: {torch.isnan(targets).sum().item()}")

    #     # Check for extreme logits
    #     if (logits > 10).any() or (logits < -10).any():
    #         print(f"Warning: Extreme logits found! min={logits.min().item()}, max={logits.max().item()}")
    #         # Clamp logits to prevent extreme values
    #         logits = torch.clamp(logits, min=-10, max=10)

    #     # Check for NaNs after clamping
    #     print(f"After clamping - min: {logits.min().item()}, max: {logits.max().item()}, NaNs: {torch.isnan(logits).sum().item()}")

    #     # Compute cross-entropy loss
    #     weighted_cross_entropy_loss = self.ce_loss(logits, targets)

    #     # Check for NaN loss
    #     print(f"Loss shape: {weighted_cross_entropy_loss.shape}, NaNs in loss: {torch.isnan(weighted_cross_entropy_loss).sum().item()}")

    #     # # Apply reduction
    #     if self.reduction == "mean":
    #         loss = weighted_cross_entropy_loss.mean()
    #     elif self.reduction == "sum":
    #         loss = weighted_cross_entropy_loss.sum()
    #     else:
    #         loss = weighted_cross_entropy_loss
    #     return loss

