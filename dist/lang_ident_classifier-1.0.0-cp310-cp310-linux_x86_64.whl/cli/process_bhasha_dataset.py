# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : bhasha_dataset_to_csv
# @Time             : 20/12/23 9:45 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import argparse
import csv
import math
import os
from logging import Logger
from pandarallel import pandarallel
import pandas as pd
import json
from transformers import AutoTokenizer
from langcodes import Language
from language.utils.property_utils import PropertyUtils
from language.utils.log_utils import LogUtils
from language.utils.file_dir_utils import FileDirUtils


class BhashaDatasetProcessing:
    """
    contains methods specific to Bhasha Abhijanaanam Dataset
    creates language specific data folder
    """

    def __init__(
        self,
        json_file_path: str,
        target_data_dir: str,
        log: Logger,
        props: PropertyUtils,
        val_split_ratio: float = 0.0,
        data_sample_percent: float = 1.0,
    ):
        self.source_name = os.path.basename(json_file_path).split(".")[0]
        self.src_data_dir = os.path.dirname(json_file_path)
        self.target_data_dir = target_data_dir
        self.log = log
        self.props = props
        for script_type in ["native", "romanized"]:
            self._process_bhasha_dataset(
                script_type, val_split_ratio, data_sample_percent
            )

    def _get_iso_code(self, language_name: str):
        """

        :param language_name:
        :return:
        """
        try:
            lang = Language.get(language_name)
            return lang.to_alpha3()
        except Exception as e:
            code = str(language_name).lower()[:2]  # Get first 2 letters as backup
            original_code = code  # Store the original code
            # Check if the generated code conflicts with existing language codes
            while True:
                try:
                    # Attempt to get the language object for the generated code
                    lang = Language.get(code)
                    if lang:
                        code += "x"  # Add a character if conflicts arise
                    else:
                        return code[:2]  # Return the unique 2-letter code
                except ValueError:
                    return original_code[
                        :3
                    ]  # Return first 3 letters as a fallback if no unique code found

    def _split_dataframe(self, df_data: pd.DataFrame, split_ratio: float):
        # Randomly shuffle the dataframe with random seed also need frac =1 is needed to consider whole dataset
        df_shuffled = df_data.sample(frac=1, random_state=self.props.app.random_seed)

        # Calculate the split index
        split_index = int(split_ratio * len(df_shuffled))

        # Split the dataframe based on the ratio
        df_val = df_shuffled[:split_index]
        df_train = df_shuffled[split_index:]

        return df_train, df_val

    def _process_bhasha_dataset(
        self,
        script_type: str,
        split_ratio: float = 0.0,
        data_sample_percent: float = 1.0,
    ):
        fdu = FileDirUtils()
        prefix = self.source_name
        src_file_path = os.path.join(self.src_data_dir, self.source_name + ".json")
        # tgt_file_path = os.path.join(self.src_data_dir, self.source_name + ".csv")
        # Read JSON data from file
        with open(src_file_path, "r+", encoding="utf8") as file:
            json_data = json.load(file)

        # Convert JSON to pandas DataFrame
        df = pd.json_normalize(json_data["data"])
        # df['lang_code'] = df["language"].parallel_apply(lambda x: self._get_iso_code(x))
        df["lang_code"] = df["unique_identifier"].parallel_apply(
            lambda x: "_".join(str(x).split("_")[:-1])
        )
        fdu.create_dir(dir_path="metrics/data")

        if script_type.casefold() == "romanized":
            df["lang_code"] = df["lang_code"].apply(lambda x : str(x)+"_en")
            df["language"] = df["language"].apply(lambda x : "Romanized "+str(x))

        self._get_data_metrics(df, script_type, data_sample_percent, action="original")

        # Drop rows with empty or NaN values in the 'text' column
        # df = df[df[f'{script_type} sentence'].astype(str).str.strip() != '']

        # Save Complete DataFrame to CSV
        # df.to_csv(tgt_file_path, mode='w+', encoding="utf8", index=False, quoting=csv.QUOTE_ALL, escapechar='\\')
        # Get list of columns to drop
        subsrting_to_drop = "romanized" if script_type == "native" else "native"
        columns_to_drop = [col for col in df.columns if subsrting_to_drop in col]

        # Drop columns containing specified substring
        df.drop(columns_to_drop, axis=1, inplace=True)

        # Drop rows with empty or NaN values in the 'text' column
        df = df[df[f'{script_type} sentence'].astype(str).str.strip() != '']

        # Save language-wise data to CSV
        for lang_code, lang_group in df.groupby("lang_code"):
            dir_path = f"data/original/{lang_code}"
            fdu.create_dir(dir_path=dir_path)
            lang_tgt_file_path = f"{dir_path}/{self.source_name}_{lang_code}_{script_type}_original_data.csv"
            lang_group.to_csv(
                lang_tgt_file_path,
                mode="w+",
                encoding="utf8",
                index=False,
                quoting=csv.QUOTE_ALL,
                escapechar="\\",
            )
            self.log.info(f"{lang_code} data written to {lang_tgt_file_path}")

        if self.target_data_dir == "train" and data_sample_percent not in [0.0, 1.0]:
            # Sample specified percentage of rows from each group based on token count length and update the original DataFrame
            sampled_df = df.groupby('lang_code', group_keys=False).apply(lambda x: x.groupby(f'{script_type}_length', group_keys=False).apply(lambda y: y.sample(frac=data_sample_percent)))

            # Reset index if needed
            sampled_df.reset_index(drop=True, inplace=True)

            # Assign sampled data to the original DataFrame
            df = sampled_df.copy()

            # Reset index
            df.reset_index(drop=True, inplace=True)

        self._get_data_metrics(df, script_type, data_sample_percent, action="processed")

        if split_ratio == 0:
            self.log.info(
                f"Started Processing {self.source_name} for {script_type} sentences for {self.target_data_dir} data."
            )
            dest_dir = os.path.join("data", self.target_data_dir)
            self._write_data_to_files(dest_dir, df, prefix, script_type)
            self.log.info(
                f"Completed Processing {self.source_name} for {script_type} sentences for {self.target_data_dir} data."
            )
        else:
            df_train, df_val = self._split_dataframe(
                df_data=df, split_ratio=split_ratio
            )
            self.log.info(
                f"Started Processing {self.source_name} for {script_type} sentences for train data."
            )
            dest_dir = os.path.join("data", "train")
            self._write_data_to_files(dest_dir, df_train, prefix, script_type)
            self.log.info(
                f"Completed Processing {self.source_name} for {script_type} sentences for train data."
            )
            self.log.info(
                f"Started Processing {self.source_name} for {script_type} sentences for val data."
            )
            dest_dir = os.path.join("data", "val")
            self._write_data_to_files(dest_dir, df_val, prefix, script_type)
            self.log.info(
                f"Completed Processing {self.source_name} for {script_type} sentences for val data."
            )

    def _get_data_metrics(self, df, script_type, data_sample_percent, action):
        df[f"{script_type}_length"] = df[f"{script_type} sentence"].apply(
            lambda x: len(str(x).split())
        )
        embedding_name = "xlm-roberta-base"
        tokenizer = AutoTokenizer.from_pretrained("xlm-roberta-base")

        df[f"{embedding_name}_tokens"] = df[f'{script_type} sentence'].apply(lambda x: 
                                                                             tokenizer.tokenize(str(x), add_special_tokens=False))
        # metrics for non-zero length samples
        grouped_df = df.groupby(["lang_code", "language"]).agg(
            {
                f"{script_type}_length": [
                    lambda x: x[x != 0].mean() if (x != 0).any() else 0,
                    lambda x: x[x != 0].median() if (x != 0).any() else 0,
                    lambda x: (x != 0).sum(),
                ],
            }
        )

        # Rename columns for clarity
        grouped_df.columns = [
            f"{script_type}_mean",
            f"{script_type}_median",
            f"{script_type}_count",
        ]

        # Write grouped_df to CSV file
        PROCESSED_DATA_METRICS_FILE = (
            f"metrics/data/{self.source_name}_{script_type}_{action}_{data_sample_percent*100}_data_file_metrics.csv"
        )
        grouped_df.to_csv(PROCESSED_DATA_METRICS_FILE, mode="w+", encoding="utf8")

    def _write_data_to_files(self, dest_dir, df, prefix, script_type):
        for language in df["language"].unique():
            self.log.info(f"Now Processing {self.source_name} for {language} language.")
            # lang_code = self._get_iso_code(language)
            first_idx = df["language"].eq(language).idxmax()
            lang_code = df.loc[first_idx, "lang_code"]
            
            lang_folder = os.path.join(dest_dir, lang_code)
            os.makedirs(lang_folder, exist_ok=True)  # Create folder if it doesn't exist

            # # Filter rows with the current language code
            filtered_data = df[df["lang_code"] == lang_code][f"{script_type} sentence"]

            # # Remove empty lines from the selected column
            filtered_data = filtered_data.dropna()

            # # If you also want to remove rows with empty strings (''), use the str.strip() method
            filtered_data = filtered_data[filtered_data.astype(str).str.strip() != ""]

            # Write data to a text file
            src_dir = os.path.join(lang_folder, "src")
            os.makedirs(src_dir, exist_ok=True)  # Create folder if it doesn't exist
            tgt_dir = os.path.join(lang_folder, "tgt")
            os.makedirs(tgt_dir, exist_ok=True)  # Create folder if it doesn't exist
            src_file_path = os.path.join(src_dir, f"{lang_code}_{prefix}.src")
            tgt_file_path = os.path.join(tgt_dir, f"{lang_code}_{prefix}.tgt")

            # Cleaning and aligning src and tgt data
            cleaned_src_data = filtered_data.str.replace(r"\n{2,}", "\n").str.strip()
            cleaned_src_data = filtered_data

            filtered_lang_codes = [lang_code] * len(cleaned_src_data)
            cleaned_tgt_data = filtered_lang_codes

            # Write aligned src and tgt data to files
            with open(src_file_path, "w", encoding="utf8") as src_file, open(
                tgt_file_path, "w", encoding="utf8"
            ) as tgt_file:
                src_file.write("text\n")
                tgt_file.write("lang_code\n")

                for src_text, tgt_text in zip(cleaned_src_data, cleaned_tgt_data):
                    src_text = src_text.strip()  # Remove leading/trailing whitespaces
                    if (
                        src_text and src_text != "\n"
                    ):  # Check if the text is not empty and not just a newline character
                        src_file.write(f"{src_text}\n")
                        tgt_file.write(f"{tgt_text}\n")

            self.log.info(
                f"Files {src_file_path} and {tgt_file_path} with {len(filtered_lang_codes)} samples has been created."
            )


def main(args):
    """
    Creates language wise data folders and datasets from args passed
    1. original dataset in json
    2. target data dir which ideally is train, val, test
    :param args: system command line args
    :return: None
    """
    props = PropertyUtils().get_yaml_config_properties(
        config_file=args.config_file_path
    )
    log = LogUtils().get_time_rotated_log(props)
    data_split_ratio = args.data_split_ratio
    data_sample_percent = args.data_sample_percent
    BhashaDatasetProcessing(
        json_file_path=args.dataset_file_path,
        target_data_dir=args.target_data_dir,
        log=log,
        val_split_ratio=data_split_ratio,
        data_sample_percent=data_sample_percent,
        props=props,
    )


if __name__ == "__main__":
    pandarallel.initialize(nb_workers=math.ceil(os.cpu_count() * 0.4))
    parser = argparse.ArgumentParser(description="Process Bhasha Abhijanaanam Dataset")
    parser.add_argument(
        "--config_file_path",
        type=str,
        required=True,
        help="Pass the yaml config file path",
    )
    parser.add_argument(
        "--dataset_file_path",
        type=str,
        required=True,
        help="Pass the dataset file path",
    )
    parser.add_argument(
        "--target_data_dir",
        type=str,
        required=True,
        help="Pass the target data dir name such as train or test, passing train also creates val if data split ratio is given",
    )
    parser.add_argument(
        "--data_split_ratio",
        type=float,
        default=0.0,
        required=False,
        help="Pass the ratio for val data split",
    )
    parser.add_argument(
        "--data_sample_percent",
        type=float,
        default=1.0,
        required=False,
        help="Pass the sampling percent entire data ranges from 0.1 to 1.0 with 1.0 being default",
    )
    try:
        parsed_args = parser.parse_args()
        main(parsed_args)
    except argparse.ArgumentError as e:
        print(f"Error: {e}")
        parser.print_help()
