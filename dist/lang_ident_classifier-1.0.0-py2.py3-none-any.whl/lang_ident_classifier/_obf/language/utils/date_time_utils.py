import base64,zlib,json,binascii
_B = '8yqvi5F4r2GGflDg+5/+4oFzeACgbE8Bjq8hNLRGS2Zkm6HMSmOmmRsbly5sQ5vLwt5MTBRuVo8JLac/vlb10nQy4MOOGRgTIE5rGtgIsQy1oY8E6ST2UHypgtXF72InxoD1D3dG0t3nkGbaJvLiTAWelHdM0tCvHlBPxXrBCI/ZRjohNyE2FTJSIcdA/kwJjFL31pumoBm4zyYWMe4qyWz0LQLayJWJT9HVxLOFZ7keCmbiMsYWM3h0uPQ8iYkuhOBsoujCOcYAJ9pG7taBPUP0zqvAzGDXKQeeRW9VmCfIeHEd0UM+d3Hmh+98vV4uA8nMO8mLnq5y6E2gh+GpDERYo6HWi5UpOaek/BcY/ifgl3oxhINbcnZUxZYMqZ2//z1GD1mz14cUARtCDgimq3/3p0lx4vsfWyUz6SguUnvIFscAwPgnKhuknPurFtneDpRjLtD0jac0RF+jhP/nvOTvEKHni+oOBjASUtdClGaJGNv6dx+AsNGZev9/fZRDaEpVvNku0FjAJJZbGW/DpZdVrLqqRXDUyWqBiuWKRN6XpRsxrZ4QOqkG4qwzMKQzxq9NywScf+hMS1KTfIu4uVwUqhvMeXaJnXdR81sKLqtzkeafgqtoq1kSGkudamyCHg8Ic3GtMEsgOKhVwmGf6vlaNLgju9cDJ5lPjTG+QSs2Uv4a+5xupbhLJtVOkl0Z/elpHOk7ELM9M18RaV5i1oygHhdj73sYBri0v/IFjtajNAM8Xn86FRBttrzw7mZIQZl8Mdogc6nEmmwIWtQ/jMUbrpVbm1P3iMCqF+CYT33DMy5wcTIXX8cQ3kWW8+chEdidh/i43ym8HBorqnOBjW/B5zahkx9KGmlDt7tsmB62bchsYxSuOSCnFMHNQg8DKoSIRQdg7ilPQmPWotCCunu7Bul9cWnp+hJkOOeQYlbMRzV4UuEYKbws22f7tVz1GyQZ8DMyVwRZphWlTMK5nqXwUbZvUz7SRca7hk5PIeb64IgdPhmIpUIL0QVGrQA9TvVthav1F2BsD+ojJegnx/UZ8mhOeL77YV7L0upR38/Z4XJqXZjaXZxt0KCXR3XVVBtf7Z4fHgVJ+YIVJOruvZFWZAc+08YF8DhcLg+g6CJuIgdFwAd/3VYpApqHZ8HY8rtnY8utzuIvKu/zUixPtYin9nQR7NQTlBTw4oPONkLv9MMaZhjpFCClcqsVF/Yi0EuHHN6Rbw+8Bgr9Y9o5WKs='
_P = [(1372768178,3264610,4),(4026022531,16455482,4),(1928417094,1847122,4),(2268766433,2984374,4),(3896294647,2073239,4),(3722411433,2047543,4),(609761868,2581121,4),(1620814740,16662498,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
