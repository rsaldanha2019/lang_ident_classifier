import base64,zlib,json,binascii
_B = 'Ah+2BCUFY2e3kRUbv0pRmBMxiehKWLSZkc8hGrxhAxl8wUX1JFyqeDc75Dx4dlvH6OlJ45vHG1Ati+MhR3fKDE9u7zhdxEqEaDR0rtRC3cwf4LYI3s+MLTwqa+qBxdaKyekduN7vyUlhtFQHFj7Ao8acesWVn4cgUtJVO86J66koNwB6RXbvX0oM8+u3WmASls5dyHgv4UIKFvuFwkvLpuBErCPorgiTV+krgVG8wjplNSkyw9xvANtyGQw1cCZXEyXOqkfkQR/1GUl8VfRw6mmUGQBMO9Sms5gy7JVCtVfo3YGFdqwp9H34+i0XmQzBTnT0ZVbC6VMW0mR5x1us1DReEFKa8zsFZ0RGiK151c7apTcl0kslOs8mR1NGxX4Dsp3Z9ynAXPUh2W2xZEVL+WZJev3cBuRFyn+/Kx1dUi6lTPLw94Y8Gq+TuHir7Qs7sjaO4SlxSb1eILii4eRYcJgU0rDJUKDBijz6bJn9HTIFZr/TdVkgnxV382y53zJiF2Sesyp10Afw9J2FtSPe3rPEujrwkH0voNzYumlsfGuphTX+MxuYS1S/SNopoyy/7hU9BtKe9AHRJV9BshODl5/oQvURcMtXGdjgD128UGhK2Y4UIyoP/RNifhskwupbagKzkKW7OmavRNr70HR+uxj5euoVKgQQ3ERFFNbHzRYiBVHLexLmU0sNdnNEFwECwRAooAgA9mzw6Cb5QOPd8JE8hr7tNzIhy/1BVG24a8Po7wvhdcFC6TneVELWpCZzudyQco9TYkax3RT/rntvzGEF9c3mxHxTUNHiym8liKUjM56hKFdof2zDqh6rb+ou9EjG9Z3mwnCw9+dbDYg3um67CX9yqUixZFuCskn5BP4vGqzvp+WOfd9I6TPDh9Gq2JyIWn6nG5UZ34yvQ6grvdmWpIHYRflpQm2QII+1aFHH0GVOzWF9S2VqWGXd0jZpTlcVtr0G2Co06Z+Th/FXaFXnjQbx61y3sx8gBb/rNsR3GetZNkrpR2xBhvy+D30EtdbEOjDnR9lGKtaDyuXn+sM1N7rEdVQgQHxi+0NJqThkOMfKGa0a8iSQbn5bcAfZiQjW0cOo3yc6gAnzENnutRxkCF4Wqnau+iJt2HcT84ax9mqBcFj3ghAXIZhbjH4V2c7ovvUe20chk/veKUzYz/XWijqvVETZUpfRb4fsytBv/aOG/tLfwXhFKaNkJzZI6ybnHW03EHBDMwNjtUa41vw='
_P = [(2055548563,4210114,4),(1210229270,4725319,4),(2803641710,7541618,4),(2955585387,2298685,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
