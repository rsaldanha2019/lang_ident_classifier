import base64,zlib,json,binascii
_b = 'sV/k2xcozDLPWywRTmYbHFNQXisXAAED7h8njlhADrbEj199K2P0bfV0Hb1QY7sQGZcsK02psWEf2Mr9ZNCT8jGoiWYah4GloeIu3ktuLl6UmsSvcy5cUCqsAD8nRNkRXag3c50ivmW3zt3PPOsKir07EPGNCg1gM5j9s7yaK7+mWiJmBBrLHKA7YaC4YMftxzKr/jQHU2kOghqSmmyH2VROpcw2i08aU4I3uz0kmzYY8pgtvIQwjZCsD/5KSlrZ7LkrrtQ4neb4skfDfhFwqnIGZ5A6vajCoxM9p5tmYLENyqgeGQFNRgRAmVVMgzL5HwrnAr35lvTezRVl0TIem6IIZZqdIOtrXMrDyMZwlYEVwfdwyvaWxMJInY+0v4EDhd1OUk4nlyxqL1bDHYrGmS5F/NGufhYCn7LCW67KaQIQ7HmB4gALvLcnhnzoJRoW4HzxybX3sSAmL70/9ANvcGvoHjzzJCgyF3vIfQYHIMVSXrNyov53IASLpQAcaZJrEcGmsY6by393hQjX5PEGdzMPzX7qfG/q3xyyuhAElZXV26lF2FmxO9UrRlr24FH7PjtoCd7c3mbcH+kF50W9CtrLpe+n0tPMTVtcPUdb2Gjsj1mxd75PH0y7WNYc1uO+8h7CtPZ4LEaSibV6nzc9ZSYl2ndCKuzwifK2iyU5aLfc3fKykF1qfH+ujHJ9NlQXjNq+lcKhcKyW7D1fv8sf3DkV4bq5jtUqrcDXg54mlZoCktq58w3dfqdEX9QCjhm9DHwdYHbBmsliKd2Brk9dJTahcNlVrrGB1BbBZeiEOxVygRaR2ruimbVK/NEN/hVuOsmyOsWmK4ASFsfvn9uV4k5CWQowIrQ2fvli+mlSFerK/xPC2ieyclds5o406xRi4QuArqi0P3sIRtm2ZZArTnL8g2BzoiaPfWRdgUWgxvhih1fmo/yLBN37JNB31AbtMDHJaOY2YdCyYrhGj3z08vkp/d67qsjpManEYVseQtH90P206wdcBLhqzaF5OKRtsymMFuL2jy6fSM9UPWQv+4SoSfxxWuoTt05CcyFjj0JYM0qdx2FHJewcc9uaXod3S1OkOosfkn3nNChLglcL9YnJ40Zghcesqbif1go5Rjw5gdwvV4ZxOaf22O6QbZbclmAVFx8F+oPNgUtp1gVI4601avigJnS9ZHjcsaikD7CYWY4eu7QSCEtsuD9OfrBzMCbt/Upva584LaMQxm89Rw=='
_p = [(82243269,5898869,4),(3206453257,6826514,4),(4249063113,1607827,4),(1783005410,14967002,4),(1210612123,2026705,4),(3945778470,1816920,4),(1591786512,1919156,4),(1604051332,7910430,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
