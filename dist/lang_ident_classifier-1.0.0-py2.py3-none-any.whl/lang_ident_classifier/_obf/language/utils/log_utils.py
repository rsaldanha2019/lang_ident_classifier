import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_39b46c_0 = 'kL/mvSl7cWTc67oNXDueNsblpxG5jMIUDUO130sgwikKLCvBd2pUwXO5'
_39b46c_1 = 'ysGWIvdz+w/WOc9jjNObjR62fk6a2/n7yYhXqUSyw05o9fXmgV4MVZmi'
_39b46c_2 = 'Yb0WfMEE5n+5z+MFo8wLSi4Ro'
_39b46c_3 = 'KuUrsbgIkEwgb/QGg5NW9JOY'
_39b46c_4 = 'LIP/Mk5eULR/iORxyNgbbzTuQVUcvvXhOGf4Qnex/W/fbTrUJ+aC/bi+2E+5Wut'
_39b46c_5 = '+6dlFuOGNh9vKffwl3Jf8jmbstGjreuphh481VS1cnRvEVxbkJD4W0YIlgN'
_39b46c_6 = 'WrJnW9/+/q4YRJaEpiiCFNdhQTFMuIxiukX5++u7RZV+qiJp9l5cuAr9pNwP'
_39b46c_7 = '9PYs0mj4P0hc5jHI7SDkv3h3cMhm6TZb5oPMH/BtnqqeOidQQdu'
_39b46c_8 = '4EvzH+cRYpXvuCS8jgc3q/YzrE2QeFLO7'
_39b46c_9 = 'EaOgjNRwwJpvYFQD17ou64TYAryHduh/+h'
_39b46c_10 = 'bgVEax25nK0FJSH5Gmk45j1E'
_39b46c_11 = 't0wx7jhV/kF+wFwG59PBE72OqdhTVO8nNVw4aJtgNiVOt3sY/5P'
_39b46c_12 = 'i+2YkbvBaYUfqpqQ2OOEa'
_39b46c_13 = 'hIIzXhQ33HtbudJTEdHgRO5RU1AERrnavFbOjoB9R/m+9zVi/D+Pxkj'
_39b46c_14 = 'GgrKZf3CNb2y/HHNTzeIJkTUSMZE5w/uETa5TerL3R9'
_39b46c_15 = 'JCH1Mnpr0Lxm6nWEDoqary0dX4SU+LLx'
_39b46c_16 = 'Txw6kv4lz2gQPq46x0uIZpwjxn/pj6r+8+a2yrUDCws3zqJR4IWGTjoMvDjiSgr'
_39b46c_17 = '/DZdm83IKc2QqbI2LF94nI0mvnZJokmFRa0cQ5aEB9tshKlyUeY9z7F'
_39b46c_18 = 'QKHakDBh85MNQCuqlGTcjlKvgTVhTOW9hlfuBbReT0Jmy5s12V9SbK'
_39b46c_19 = 'lQAJpdRvfITIlhKFkW+e1cIV73Hdq7hsyirScEsLk284XgMbc'
_39b46c_20 = 'ArIHscHHb7n3/sKN8SBBhZuueapJjBJO0lp0UEXeSCtgMVDLKmmti'
_39b46c_21 = 'bPeMTbtMMHCPCQ+NGcKtgTgRP2nCGP6rfyQOziMEBfIMjtxBd'
_39b46c_22 = 'hU5wNxpfi4h7jLOIMAJ5BwAKPRWDZx3BdnHdkJxLID9CLidRp'
_39b46c_23 = 'Tf+l5IO6fs+eJqSIAmPlZ5reLi98WpcQJhJG3YCUodSq0bCakxkUlH//Am9y'
_39b46c_24 = 'g/3UMSflH8dD6XNsRsx7ByzoRLailbdo/Pz'
_39b46c_25 = '4Pfq/Up8Xa44SbJjqLnwnkAaEG'
_39b46c_26 = 'nBrg5vF7dffMo8FbuhOm'
_39b46c_27 = 'J5NhaT9zWeG6w5Rj0SXUFX70LTmkY9cm3cogOYq0Q/QuVYONMpfrA/LPnnDj'
_39b46c_28 = 'aqKfKQ9N7szalQZ/3zo8BtUf'
_39b46c_29 = 'Ak0v+TKVxk10aQqcO/FH9kHK'
_39b46c_30 = 'kNcvIg1eAIjVTeHpaxWjrEKHVchSJfcdKUvP8j4U'
_39b46c_31 = 'GbM+4BIiAzYCvXK/5tY89MqPtnPgoAY4FQrpLq9ShXHbazkubZ'
_39b46c_32 = 'qYjJGZrWnf9hOnmbeaYP70DxSKifrQBrR4mnXiSwOUdxShAf7gYh'
_39b46c_33 = 'oqjlspA2veOdlEqolhWwPghbaBPw9eclIcUxwi1MMnbnB4+Ni6/Cds8M53r84'
_39b46c_34 = 'p8Lg4pG8+GDFqUnQGfZVQ0E'
_39b46c_35 = '7pFD0AiV9Ti92KY3K6NRb6Am0IW6u23W3A3'
_39b46c_36 = '0AVrxEQzM8lzIJtJZr+N'
_39b46c_37 = 'FxZiOAxEK17IBh/riZNSmqzfhTshsOeW8+X8qInEPrRFsiI'
_pls = [_39b46c_0, _39b46c_1, _39b46c_2, _39b46c_3, _39b46c_4, _39b46c_5, _39b46c_6, _39b46c_7, _39b46c_8, _39b46c_9, _39b46c_10, _39b46c_11, _39b46c_12, _39b46c_13, _39b46c_14, _39b46c_15, _39b46c_16, _39b46c_17, _39b46c_18, _39b46c_19, _39b46c_20, _39b46c_21, _39b46c_22, _39b46c_23, _39b46c_24, _39b46c_25, _39b46c_26, _39b46c_27, _39b46c_28, _39b46c_29, _39b46c_30, _39b46c_31, _39b46c_32, _39b46c_33, _39b46c_34, _39b46c_35, _39b46c_36, _39b46c_37]
_e4953e = [(34365,10305,2),(8807,59263,2),(64917,54396,2),(46351,1244,2),(40871,15607,2),(47323,45398,2),(47984,17078,2),(30385,45874,2),(270,15384,2),(24673,27436,2),(55187,54891,2),(21524,51388,2),(54844,24618,2),(18979,52953,2),(515,9244,2),(12461,25902,2),(0,0,0),(0,0,0)]
_03f641 = 'rnzFGA=='
_ad5673 = 'lVqwbWeut/rdEU+N'
_f17707 = 'wybWJ3gxkLc='
_90d0d3 = [3, 13, 4, 2, 29, 15, 27, 30, 35, 0, 6, 10, 28, 22, 14, 20, 17, 32, 21, 11, 31, 24, 5, 18, 12, 33, 37, 23, 8, 1, 9, 36, 19, 16, 7, 34, 25, 26]
_salt = base64.b64decode(_f17707)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _90d0d3
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_dc31b9 = base64.b64decode(_assembled)
_2e7bf6 = 32
_3b6680 = _dc31b9[:-_2e7bf6]
_2e7bf6 = _dc31b9[-_2e7bf6:]
_e66055 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_e4953e)
_hdr = base64.b64decode(_03f641)
_nonce = base64.b64decode(_ad5673)
_km_seed = hashlib.sha256(_e66055 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _3b6680, hashlib.sha256).digest()
if _calc_tag != _2e7bf6:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_3b6680)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_3b6680, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_482ac9'] = mmap
globals()['_ebbcfd'] = lambda i: globals()['_482ac9'][str(i)]
_x = globals()['_ebbcfd']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
