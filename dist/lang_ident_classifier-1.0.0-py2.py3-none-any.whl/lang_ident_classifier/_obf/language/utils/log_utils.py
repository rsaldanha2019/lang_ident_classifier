import base64,zlib,json,binascii
_b = 'm3gvmLqCYpXqOxPSKaLcWh5zg/sVbhywia0HSqBDQEv5kBvpKVPUZCs1JFkNzUOYcDgwV3iwU2wjLA/CeoIARQUT4KWdS84mlWbmHLQLnXFw+mXSN66oTPiQiPzCONrAfgEwModW4/9SfSmPedI40DR5+lL/8J8li1YzmfbXoY91O1+xmQHztcPOV1JWdrdp6YM/dCp6Xnnlkhd4CcXXFQhZdunBt2JEAjro32Q3UpqXP0sNwXYzM3khP8KHfMMmMCrWuU8POM+tAD5iiUfpIeBuArY7fpkqMUe78yJPrktECivdCzJ5IlHnkbeq/VRVjMS6kd5Oksv9e+/fOXUiC+9CTW4uhYCUZoWQYIAVhjR3ypCsDqVV4QotBW8EEktZ47/s4QcvdqMh4msVUuxVugsV1nZPxISBCvtevFeQw+1lqRrpDuqZ1jKFw29qNryxhODPQA3G0Ni3kjnE/2EgK7FA6+gPXlgnIiWO7xDV2h/E1mbnqVzlVUqDHAQuhP4OiKT+4z0V63HCC99VJ1UhQ97i45p+PbPWSKMURVqpRGL7h1xa/GpMP/+JXS4xhciwCxJHNBQtO4fuknE+/q11NRBmYOgJRL6LV21A1DqvHDfyy7U8PlzjGFbql3Y4vz+OSK3M3sQk+N5mfTdjry8a1sgmnseGJ6/T4tL68lWKXJ28k7ATSVnpe/iA2wplDkakEA7UWhJh7O0+P41Q4x6LFmWvnp8QpbUa2tLLAZ6UDtnZTw2t8gKLQ8HOUtNS/N/lh7T5VFazkcBPOEyhzMWif4wnGYUIOs4OCxtADKIItd8tzTwxnj+YQZtWGjWpvJdRQAHu/CaPPUfO09RkBiqsWxTcznldVRdOm8PfEZ0ELXD2Xm84NWKNvBFuNhXG0xKmg/rDcn/Y5UjDOaBDtVamIs7wHzKrOWUZYyr2eAAoiAs3cZ/hqjdPzKC4SZZ0XydQHjoLDquQyysmj8bmJnxtPCAD9iovoSvcDJpeQeveYc5c7L8cWVRZc7kNstCgehmT98oPCi0wOv/kKrE9q4NptlBatZ8z1gMV2s7iC9hYzSkZvZ+ti4mK+4seoU49OJ7aSvJmIxd5JocyeZW5S7wHjS7wUA4Hdhk4aysWRevSsWNFjdvGskcB9ePkpgwJtuI4HWJJW6IpTefntzr4/34CICh/NQBqBs58BuF0BPnQLES4l7V+O1AJ64lmUFarSIY7Lm2jdDK2IW6+If+8din75NFoWZE9b97vYUZ53pW8sdwq6+HyF6eKZWM8F8HDfKeAj4snqdpAxbqiYV/bvFm8Hruh9UNmeCN0vbS0+nFX9pOrVM+aZFnAYCNKv1ZMd3bywns7k1doEvm7Z6+qrJ3AOn39Jzt+VOwKtfDfozxQ+lHLT5vKt0j2YACKe2eB3j16Y07EqOUfQpasEty+W9zQyM60z0dNQG+phIRmJWIlImCSwc05aGf1CoCxnqqoDj0Y3egKlXS5Ff4iHoBLzKgnoRUZtJTYbFJ/PhV9dO0SYaPAjM7/D1N6VK5IAaVKw4xgirDh5RecCudZcBDlNlAZ0czlM7nhVqSjbILQiiWjK0gKRysV3Bk9CW4j8msY+T9FDolLBCJKxx+KNyD1u8b7ikFdCXYfMeK9G0iqDK8eJLFhpuAWo+T0q2L02rZUT8cPPUDwLukIv3KKq4AwQA=='
_p = [(3354383045,9573543,4),(3756506412,7624108,4),(1036356523,8394707,4),(4100779979,13296920,4),(1560201447,1516108,4),(76983178,3488563,4),(3188489349,5310555,4),(3066890287,2197219,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
