import base64,zlib,json,binascii
_B = '90oTwuxGRJI67WhbdnV/xLpMGgO2YXPQDMUvUK/Uf1da26U6r6iRdyoWD+FPe0v5Rzw/TaahWhABjPVpbMNbcZOApuQ6ZHTf8hrGnU3LOBNXukSitsh+ULCcYt/2M+qNWgiwdURWWxaUV76RW19Ei/Oam2Quuyuy+rNMd1ZgL3HatsTAzPgdLXfp980n+k8Awj+BSDZgTZStrsPq+iUyr6iQ7+mEOm+X2uOX441BBH7prcugjKD7NNH1b48Qm3HEi3hz3AURrpDhnKKW1YJNcbdrfe8q//AzefoveKSfUAZc/aoFoRSTJrzmVvdUBlWFzihJQ6x3Q6yw4thkyra0K6hvAn3e/6ZxkaUbikcTm1hFJpux5CTMDC0qHI24Ye6rXSBzlF6OYS7nhC1oxozVZ7E15wcLRNYibZkEciBy0MtNDdNfXVbJL50YyR14C3ERShR725PyiP6DZhVCk7FCjd25CReP9V+tssn+qf3PIpvgHxJTFB/CjWoDMDwOnqsgWDF4AcBcBOVQT0uYEPaz0+6DfTN7Tagz2TJsej4dccYG0GlzKCIE091i0l+SM/sJS6LTH3Iox9ZK8A4PUclyQv6bSb/L+d4XHSJp2sgwtxp57mpZchKKPcDd6gsDYZNjPllvmGvyIcCl/kJHRXGV2kAzMcfIVv9gSH08zfhr0Pf3xraeiDJqSPe93oP8q+lqQ1aL1i+5RuKY3VQpkUzapox1cqHuHvf7VDHpOqyMyLC+5n1PLAno1D+0Vz8JV605YP0mZac1InsEVn7YyNq8egGLHdUb3DntRTM5Axtj/rEIMNY+yocsS0orI8JJ1LRq7UHXpF2nTkCt8eQMDPxJheWE1WHJQqrgt4iRKS79bHynDrnvc3VkmGEpcMjA5qUzL1wVZywPNs8N9yIhtrUPdqIAJyIVJ9fDRbGVnSjZQPa9Y/wtNGKsMCFfhSOBXwdU/kG3obnqC9X2IACbZ9D7fBv1d3JB7qUPNgpKYJl38dNsxmnfrKiq070j/3QCT6JDm86LORuafshkDAy0kPhCsgU2vCk3LKs34YHyLjaKtFaJ+nZmkqs+HV4FGcyR0UELwFm1M+l/omdccl5VvMQqdMUdDHj0Vy01thXxGPhPsXupWGEu5eK+ZreEJXTGaGdm31wDENgVzaFZAePok6oK+PgLkvTF9kf0IXiQXKEu0AExLEXUYUDsH6P7JNsftRS3MRrEFtVDPll7DTGqM3X/PDReKp6zTGSdRWE3swDkhU/UuDAWVd5KCbvz9FWRpYbuKbJADoU3yPhY9qI8mvZ6KmGoHZbs8cLAtn9hGn4/Tp8BCqSpimUCbbqrx6dncagyZrJMQwBWF+QiqjRhdxzDx8tax8gjVWjYVaCoiJLGrVhewY1wvEie+3CMtcwnW+mf/3cfJwsQv/pAIFYBVMP+dotlCb87nh6TM+NFlVnMWbGqlXnkPGWMozToVSM0garkgNp3Km2VBz34LhB7wqYzOi1IXxGVclG7p9leK1tGz1jTtD2RjiWvFl6UxEBil/oGg6DygFr31OD2aY1JjT9PdwKYInf7pG+wfGlaTbgAhMkl75LP161Bl4m2VRzVI5IDRZH+R/Jbc8HFUDajzp39S60QureLmnQCRbncGVG72064I5o0tCMHn7oiwbAA9WKFczXJv/jPMfi1hOjZhg=='
_P = [(4181890796,12165245,4),(80889386,4845016,4),(4016085463,11666692,4),(3555554719,1628922,4),(4261908563,10629120,4),(2917623961,13271792,4),(563058386,4126060,4),(4181555342,2684182,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
