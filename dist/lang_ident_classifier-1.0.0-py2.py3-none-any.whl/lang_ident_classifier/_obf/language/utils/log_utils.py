import base64,zlib,json,binascii
_B = '/rmAp9BLk7h0KejN8tuQGJY9Sq4ZaSXTcOKRj0BRJYn9dteTDi8T7gBMeL9VZqul6gN8n5JJXdjvZySCnf+O/nYWdN4LmxhvBmybth3FPwHTa/JkQOuZBczApxLPSqWeIl/DNBvsXUjWbwu1xu0YlNcVsHSR79mLLxy7SLSoUn+qqnPAPTJWMi4d+5HX8MOl0RKdKI3wDEgyvt+5xxpGk4J5xcFT2Rn1VIFDsDlEG7qbJWV4zt4pmPIjc2MbK6QBFB6jRX5IyO/QkIMhBsSUabOdZGFIxpkO75qZQXUKtgr/kkhIbeSw+9sxOtRaLx3tYtTSu8Mmiq+HYub2k9LMTKDMTYJ1wewDrVxJcSnSEVfTGQDb82LYGDAlU2xCzArA6CcY9vkvGN+Y9Y3TYoN2RlCH0DamT7IY6IjcYnXvEhywMm9TNYA+UDdvpB9yKkRC+HG21XgJN8xNOecNmAoULCJqG1bM64KcdjTRhllTFpIOtTnIHFk2xCGTiqXMFlgEduU00vRjNkbh8e426nBRYdhq5bNr8VgLxMKqINHSHTd5KduhgpW43H31NuMMIexKYCON12il07v0BLLqi/Cb6kQOdtvkSwUzlNrvqlbLibIibo5Jb8cHxaDpi1gJ0GFiOVjlUctt94+KoVOIxA7qqhMPnMPimOqJrzgetcRkLHqrbwKW/1nUzAb4RuHH7QZN3QDxAaH3eeCK8q945CVtGUA55XVkWeLj59r7TwIHD4Ou8wco1R8L4Z67XRjZEiFQYtpNdXS3QH3OI7hgfHnq6t8kU5aMvfGCptuB1Xy6NiZno6j68aXitq92A83fCrD7chW3jiL48DuLUcqObeCov2bFduGiQRnhLqYrD2MuvXqkbOftIqiabgC0GEkB/2qlVu0p+StRx7OqT8pBXQ8LA00/G5Y1B8r/r8zJiGF/zMcyDqbre4M6G/p8olyxjFIaR2ouAZQ8K8uHSs8bTru8+/FQDPwVEvsAZ524SK/TEv2NDleICn9eUzAUYbs6LoRvZMbdbf7H2lroOxJq5Nw3uOhsVbL6wFd6qsPkkHxLVhTrzahzF7ysSl0O/vZ73oK1IxAT0Fgywf+SqzXCy6eqY2mR3SY0NH3si7g8mfI96l7hkOkgeUBs4MSCtSsWG4cBVGADYMLNF85FOGIcqZL24763S3PzrBKI50ecbEgkd7lGgib87brApWsDnaR5bT7zhHBs/i2/M2XQBdCE9Cq5Zp/j5rkjWEKVZ/FjjIURd4wZFLMmmL03fALQOpP5vQkBLchOXtgTl9Pc8xMhsqdxnx0hF0E+BGsU3G6gl/cMNvMrUKjPrQ7Xzg69oB2C1jV2GCcj6EGs+IiBOOnnKDuj6ZXbPrMAAntKphz2rFeZd51Zv9h5GG43BB9JGLWDLL9Toi17NWVBkjcLsgCkN+m/ohCjHlikCC6JBpjEi+gVCQXYzQgxc6aCqbT23ZTbXzzo37uS5iwh54K7tNvFgXE9YG5qpfvD467lyH29J7sHXhL0jhqjP/tKBRk8VtS6ogMddP1u8S2jRBJDfiz485Z6Dglg9bSOsvnOqre/TzTrsar+kF0MJK5wamI6wz2iqsp7/+2tng74xW9vB4qaVH6PcLB9troOqEHpXY01NF9auEGBRikGm8MWQsQZLSSQWWUgM9+6Gb+2/mM73ZIyEg=='
_P = [(2255153945,642792,4),(3179252512,12289198,4),(1681813879,15315564,4),(83135125,7101015,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
