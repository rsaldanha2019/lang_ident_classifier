import base64,zlib,json,binascii
_B = 'CsvGCQnVdmB1tIZbWVOtm8hrGi9m3vXHzIktcqYiL7tCHmETM7S6z3UBB3S+FiT05YVGFDTm2gNxDI8wVW7gvk7cbe2W07uas5B4+WkztaFiDXaXRHCOGs9avzpF7Qj2D7OHxHLoie3pKRGRZtS5DV0m0UUep4kX0fKHPc61EaIAB/1rK4zkFxHLPuMMGeuxpncgvWI9LGd0/At98+KencibgokOfnAQ9W56phKpWA3CtzJOjGwesYQFtFYDCXrUjf7Wu10aMrnFsSrNI0iwPidC0aPhdOeallBm9nnrssogvQMKOB/a+sWBElM85o7uyNgJkyjfCLi4KIHKwCwfquk5JYkLyiimYLRbPnA4RfHuz10OkGJmOBjRDe/qk5+Mts20ls4WvjKVqqUap97dWp7TKTLnqbmN9G0rOIqY7LhqVJNUrNSogbntAcCGMC4FYgPSXFcY69oKg957q1iOToldwlTx/RHxwR61noz8nFF70kb0COOkE7Q+jK+qQwuZ8mUwb9z9QQZo4HyEcJ7igK7xIIdoe04HhYYaoFIMMO8wpxjN6hfN41dwAfOaWVn75fQvZMY0C1azFjUjRiJACdmejULINgciqkg7vBIC5xA3sUkUabM8AfxxR7yrjZNQ9qT1MjXRBc4OgxA6GrIRkd6C+XU4rOb99DjRf+UGguxHTMOJXRta1LJ/Da7+gkaYNQLi25XSoNdozaBneDgpbERfzvJ4vMTuge6OqX7XJi0ocAq2uf86bGbrHbEhP+tZHYzEsO3LCtIA2wvmVGVy/Fs8KitPw8dFH3DyTKz2aSm37XGxrS91gLeZQ3QLN+fRwD87i2n5hArLCb1MSFI97GSikGozLSaa7jrdFaZgxHaZwDS8xr+3jXguFn+6ygSRcDMbn5QMogjFd2ne1NiYbqGPJ+mKAvgOKVhx8ubV5gJ0OsibZn0f1/MzfKYOUyC9flO9rJ6m5yhd1wABZ/bXHGh4f+r7fvE+vgISuG8xVw+YNuODLATUoABXgckTYk4/RU/quLyUTWIe7eDo46hVQy06xbejciIq+9E1vfKbV3LvqmK80qKkIJ8ex0X5xSaQ6Z8cPb7nyd3AIPf1VM9F9dFxt1o0xeES6YtovBmPud0sTE5NJaqgz1zv4KVkf1DjAhBqnHGodWptWjNBgTLk7sul0DGDOvrd9vkciVHAhYREgBfO7ZGREIYiJdACqH4SFry/RjxChzEPYciiyUSzzJkhzwxR7Ujh79KnRIFrgkiqbJ/ju421Ybml5Zb71yPg6++bZ0N1jf4ygse9ShI6srMGFSZcew71o9CCWDg/k+pQvm5cnFvE6FloI87046OnqB1Rf49LJigAAwam2e4Ysa9p+hAzcMs3E6nekN57l4bR1HEPLL75paf1alSrlt0Xv19uw1azOTTEOezsVn5W1qzz78CtXFxWikQSv8/K51VSrAgmSknW977ANzgAHRAshE7yec2gYiALXY1s1Bdi3C0ZzuJBifnxwNouep8vrwCMHuiEPms='
_P = [(1916066504,2472342,4),(1660390124,5056442,4),(1635766493,3570946,4),(2930882741,4400078,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
