import base64,zlib,json,binascii
_B = 'BdXn4KBe6+OpEQIUMQJWUhZ34o/EHFytiivJ7ZSBMfwPYZmr/ScOQmzlYioEfB6hJ2BzWIqiuvmTn0T/ac2nLXkvAxkpjL473och0zcsZE9nJy8R2XVcz2fTaAOt/P1SkjGSrWmHCaLdSoyrMHdb4kq+waJZuSTcgk2HiKOCDgxdX402sSospboPMv6BUUDSuEfaypnuqruEmBrdGttfGPLB7BpH8Lx/duVkrgS6lMVqY/Eau3EbA2v269AzFNXZYhOEg/+lkAld3BgOGWyFjKm71zN1qkPK4SyKaWASkPa2n46rnBrgSxZ5wGz/HZXW3EuLYX8DmuZPqKWf0IyV56x+1OThPbIlRyVDRfDt1b3b+ezkUy4JhT5ZULdxBzqt3gV3ny+TnmhmolKr2aMThgVpwTXSZzJcFscSKoF4b+Ia2rUHoWsHppej+l0M2bs19igbkjAVOwnyX2xjOW06/GKrATzWXtTJrEUdji2BKonKgdK2kV55WrPp+OcgrMh3WTI+VCnvkNXG6iWSsABQ9A81bg5EyCPPv7Xotrml2zcrE6ICg+XtoRwTx+796I+ksZ/sPrMzViYAUsp2BMi6Le5UAO1rVyiVlrE9+UfwJlrPXqZtzG8IovDDwAVwha4e/v4wunwtuq67zzZGV5P/llFMOmV56WBpUE/RvsEixflrUWk3x5j75I5oM48mvPHavtBtnLCHisk9T8teVAJDHTemvsTmM23zL15E35hzC+Et3L2qTi6eKSC8ta8x1CcXq4tAEfqkeIGkWh/3ZYGyorAqPJaZ6K27oRZpFX2If8UHRArVVeXkpxV1N0O57ZpN3FRAitsZJOthRjKPjp7hZ4tf4Bns1k0t/yy7rrDEYCJsPQXO2mmC8lwffWK0TZjwrMVCERumkXVWVU5lI9MhhyYpdTUIH0kZ8kWciP9la74svJ1PYB/et46tEJGqi22oouWfJ3LrNLmBwso1GG3SEyUL5dMn/jz4aNxt4swRPwNRjG0/LX+XLhkOZplEQ/JnighiAAkVhVRF3wVk2tDvRWMMSMuYglzHlI/ziIKGHEU6gBr9VLpIqkNqrqiZcyjU5G8yBx8hgawbhvze/vWzWXn1Ud0pAyQynFzQ9GfCHE2bxLCxp72UDXJILUGlR7xr9BorlnWJK710QMaIzpLRnK1bpBEh2D4h8t5j9TcNhZuHhQF/UaRb0AInB5+7Z0vMNvEqLziGW7y7/YSNJd1NRiphI1QLnxYN7iFaCqb5c76bbugygQCdlXWngIAXOHBtFcqWvb0qI5tEbOtYUpoSAqH8Mn2lZdvPShIKPG2qfLSa520NO7wLyGt05JpRSjc3AdigINnJuYFEfivdQUoqQQPNBY8kb1X6SDWG+rHLNsj0YTnXSJI1KtU/hBedrTNwrllW9ibe8oxJZXj20WqB0yr2HDJpsAZvZ3I+pwk+zJKZw5G2ADzAOHJ1pgdOwyYmxaQ602nnbLHCqeexnjpvT1HCOL1fwWoGu7GcEK/Glbf6Cp3wxM8='
_P = [(2522458379,1799247,4),(3000594859,8823396,4),(1561005509,694086,4),(1804842215,1091486,4),(1183408901,2054169,4),(3409442222,11544226,4),(1653699197,15089058,4),(2577333113,6966844,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
