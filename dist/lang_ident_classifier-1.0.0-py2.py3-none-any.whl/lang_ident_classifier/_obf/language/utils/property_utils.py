import base64,zlib,json,binascii
_b = 'Smox2L/RdUNlsOHYWbrv14KYVcUaXrzHfpbB+AoNvN+cMZHwqzH8AOmPhzc11AuKvgd8gYxB8R5VwpLuGn1st3x48u8iEasLV4MrwcsjtzM0HgHQUouEmqFoDAmBT6dHjYPXU8+DzhkxhGK8y7qTJmxmum4s8LymhEgAxwHGf2fPRWeMlzTsVU/hYU0/KxYiwarzSiNV6zFWp3IEqDqaYDTNHTPCeqOlAIdb73po8SiTo5BL7JezFBkzGeL2TGXP6knGIW4iDXILqfthwDsfm4jzJCUTo04sLA+YSHr6H16pK0B0XH/lvjeerhpwuFBgm/NBOI0GGrLcpwPJZQsGK4DyMJO1tF7+qJIr+1L2P1vm17ZMMTty7XcWqeuheisx7GjKPO96DGVtZGg6NkVsdCB4OBr1gr7JYpkT2s0djGquD2l+405DH0/Sq341ysAaGAXCrWvQd1Ond88AM94ESMPnHb3cWvVaYnML3FUjUpi2OgdrUSbQV0GpaB+LAG2oYaSlrDuTmQwr+dyJW5+GFPZkGIcM11CF/Cy6gxHOzEmSSaTUrmmgTWy5ekX5QOYVkGPG0BGczCG2WLvqIAQBe7rxKK8FrWghoGm/+KOFC058MC5umVJ0gmhX9Eq5AXJxyB/Y25Z/uWvRWOksdxC0FFGlVGUSAn5YHJc2seSuxNf/aYN8N6fephLEHTXcKMOkT1xIObKZka0SIvPLkynlq5iSVvS9cCdeLEBU+A/qWf/rptFx45IEeiegr+QRJ2WFrNBaQbJFMCg7sSYDhB2icc7ESDsdF4MqJ+IdD9UEavrESuFP0KERaag6ClZ7y6zJ0lVLhZmKfRJuVCh3a0W9I2OHLayMUwzP04iWklCpdxtjwTQJiDpjQDFKGQ2wEL3zwlFQMMkUtE1XbzONDFs1T0ZpEqSry6CKPufGnIT9zoMwFK5JO08XlLLqbQ+1MjSbb0Ba8TNIIxgQd1pBQK7L2SVl2lgQm3P8WILt+aoY6TNsdW6vh24Y0SC7y1Y4XOoGRLrPDDUGqZyrvT2APJhhQknU8v2Morht1xIlGXp8QOqCRZ81WOYorl4QsDJuqXfy0MXHc52o5duEyJXiap8DD+Z3Ms1FGEaQlGKwejeS5Ackys1oWLWHVwQUBKt88EPEozT+aMsPcJc+qN1yQmp13HJFkS4V+diF9dogWUn30t+5MN7Xfw02+Hu08K+6HG3BEFRV/o2tCQ6BiYvVfo0EIvqS03bxG58jBUaeSaQmR+yqwtqUPMqKmYaS2NMd/wd0IZt2beHSHIXZXHgCwCFcLA7aMmG7AQCjBfti9xEcIXzWtMz+/wvYxYyVXPXc4DXdK7BpyqpaNFOEJZHYCvJNoy+ITHScQg0cyGk9Zt7ApKh70bx+MuGwmZQVhMsl8JF5D9ADP5ldVN1AFzkkXtEsVE01OBcA+L5M3xmu3OX67fnH/FMIcUVO02OiWQ5kQclPdC0ctl09SsfmVTjdTYn8Gqke5jtJJzwb0EOEU42cmROEnfTqbA=='
_p = [(263391926,1245359,4),(1504623217,3986725,4),(1912637644,13859377,4),(1638750372,2038968,4),(2901547081,10790278,4),(2118723163,7283756,4),(1552295190,14101791,4),(1947391677,16342839,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
