import base64,zlib,json,binascii
_B = 'JbsC4IsTNnnJF+/OF0sun8B8sIKVs6v/H3SeMQ14nzkg/M8l81skEp4Du4ZG3MyUNNYy+dAbsNQmk0qlw8TpWr6y01CQkYWc4xAp5lX70bBCjgtNWMFqN3i6K8wnAtIV2b/DBpaVXhXUDaBwKmgIqPRxKePcXXT7nzBoqKnXL+mXi7uha8dlq1aSykYpRq3inLZc0RZWochWxyLi+tV94l/lLdaoXxn32ViYf7uQXKu7aLxXXjc0e9IKwL86/GNKZugcZ7523CbkMwYx1MbKDBhxKmvMc1/NYIOEM3TUr9z9EO9TBDnAu0Ay5KJuamP+CMBqEYYo2v/r5Bkmyh6P4gvUFqraPcbkdMJphtHXKX0jJnyqMs7RqtMCM+wv9axdzr/0+MuQ7y80WXCGY/7bFiTLIMAqxeVps2B9WrrjvMz5ZMRDtinkxthy3vQLvMfER8F6oY46I+W4a7o6eGxf8meOYbqDQfA9HPdhuUfzb2g2ObwXbOIjoj9f0GKPTnV59aMGhNi7WEeFYXrowc46a9nn5bF+Cx9kXi1EF5AP5sQ6BCIcUmUfPb7TtjUIyuwlvbUATqtLahWt/7xFZIoxj5oUpJAuud+im9D9tgGySDdF6uOVyQ651W3aIU+JotHptFCqyIql5aztOodjgWuUFPEtDhJqyaO3nV8r60BwjGJQYM/MgDAqCOk2GlqhtfFxfANXkwv521c1dP3gxQ8MFqxYJMh/g8Ve8k0r8EfTUGE7tze/Ud/nofbCQQ12k6xyg3/oP8HNn30DmnPVYB8itHcaWXvqAVheoYzvNuqpgJt4rXd5/JpsB1qKFw9193bucAwk88iAfSowEULc2BGT+EBJxk9n8kkiOL8RJySHBxWscPHXl57YX9gXROtxEE9ZsnYaJ/vrRxlSQ80c/t3p7EwUlTW9AFqbfk2b/alClA=='
_P = [(1562262235,8363375,4),(3603400234,12544867,4),(3710032912,13129801,4),(4223318724,13899127,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
