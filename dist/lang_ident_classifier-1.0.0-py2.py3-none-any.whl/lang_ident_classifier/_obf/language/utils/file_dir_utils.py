import base64,zlib,json,binascii
_B = 'TaQoLqywHj27yOjNBssp6oLU+E1D8u0mCv4sowEgTXn11kgmHeTSpmbeIQi+v27Ysssji65PWb87DCa93ZL9g1tO4aBYK4AoFM/23JcFTUu2A99BeIS37QyMB5tqYfC/8gdiT+qCAzFnKFTwq3/Vx1zF69gb4Iz9hUiZUGa5dBd63XyRY573MJvpaVmJ78i1fpw1/XgVfDYAlV8eocSpJdKeek8qJP9FWDyxFP3w4pFwrtsAhJyfVFG5IHG+qNviohsIm52mCdmvQs35OXDDlhgxSmPAXrqT4Z4a4iJTj33cqG2wLC6CVsfZkRYatGyoXuP4tktxfSthu0oQzCZh+ZroAkGjQh8RgKq+bdiCDsufSxw56Mf2Xhs/yiNR1SPq5nfgvDpboZA2MMYJqCA0NOsBamM8gDezQf9BMmu2KgDoth7bYJnmzXnVBGxmLjuIv5YCOhTY6SNldo3pqqi/MfQFueCxilWegVVG+HElsPPRUlpebkisZScGrxs6526kda67x5ef4XqE3ARk+NfeIFjfc/Fq6VtmKJK4EskVTqb2TulT1LJD/z5zaoRDa5D6e0n4PaaqanhQB1hHiRgo3KCybnhl6xdz8aUayD3r9NUZojY7VVd7FcjFb0eyE9PNkH5Z5MzTQEDp13CZKrOEEZe9wz7lG1GpjE6+Icgr8MtO+l2pxL1V/wbyQ4r85Y2QO/SBDoXYe0nGqybF8lxcMhzsOlrhsFGdRtqASyvd813EFB4JzZdnRz1OakpAs9b8HPF0KEQ0z2J4SvEiZlhXY6iwuX+GbralDRLvmz+iVqM+FzPSCmDFXZc9roBjnnmnn90BTaWe9xUixFfCUvFuW4G3i2P6Q/B0i6McJIV1TBGjsHEPjdjH/qFQksiS8WeXkD6IchaL+GSHyCz6knOmEwTbeOQi5Es8GiH707z84Q=='
_P = [(1795679848,15694337,4),(2998048354,10418601,4),(2858168022,12245034,4),(347848798,14528664,4),(2810992430,1939031,4),(3347441756,5323664,4),(2779743768,12204257,4),(2052924606,14028488,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
