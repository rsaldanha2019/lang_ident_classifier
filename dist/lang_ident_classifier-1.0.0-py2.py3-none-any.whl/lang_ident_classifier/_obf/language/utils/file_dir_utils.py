import base64,zlib,json,binascii
_b = 'gdHzhUdq6vDBoaUKld7ZDZK5yqfqCv46MMGbKtyCf54eKOqs9R/9DZGjaYhdab6/rKOa8gmw7AygzW00T2/EeKV4Xvj3YvOfQeBimXmANJtxvU3UUEKiduMclV4G8jT71fisrK8isSJw1fzNMrDEVwVSPkOipK8Y7Pc/VnN7JwwCN1KXLg8Ndr1cCPpxLuMO1OjfDsihXC+Pbfgqua0r3LYrvFSFCsg0+jCnLoQJty//cQc75s98NIVasDNZnOqy/CxiCC41c9uFTy0RDc5o/lyrQNn4sYa0mtf6IqIaT9C8XGLIUEQ+lCnQvqR9LeYUMGTkQ1lmmY5OjpMYfC1QPFhKPy4mRrp8Sa/GBG/Xa1wMs857KMWkTL1jQFc64Tjz+gLINjFobIf8zw3HMeXkO9YLAKonfneq66JC1AAQpKs/peN08zlsZopV+4K4dcl3OuiFO5CYBgyOAO07KhWflNpSPKeP0QeUZ7woiAxs/vpe6lsOpgQKIUIcipRayTF4+3xz/dvr6UxQO4qxYPMnedtkLUepgTCO/Mx81155xhVa30L2fKfBt3YIUE08Ao/kFN/8CE3WgAy0uf6WfodFBCkcfaCHgQCpBC3MQA0DECnmtkEaFMirZ8QTYhxA/8QWmeDl3LLL3rGgniRg+mbGO8q159b3l0v3hHSQLSzBOiGQKLAuiiW+z96N5ZD8LHX0GJdlPdqYpZcH00zLLmjQsH6VRDG8eiTuuS5CdzRADvASUxQJc3jvYNLyXKpquDVuJOEqgsZU7H6pUx9/bnYoYS9t9Iv9cl7NUMaALSWh2oxOTmUsF0w6cmiwnRdNJRzcY/x03L8xWPicuz63eAcMGv4YMFkawWZ1vIpDUOhJ6I0LOjYuslZou9nfMZzF1sW4IsJO/cnmdvcOInMv4ZVGFGqNCW19z6glSmkeAZ2PXg=='
_p = [(3997179461,10208998,4),(1810566236,12865476,4),(1035597748,8837076,4),(4054074488,12806580,4),(419152628,4996988,4),(535093429,2414019,4),(2506128700,13094908,4),(419715910,15336682,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
