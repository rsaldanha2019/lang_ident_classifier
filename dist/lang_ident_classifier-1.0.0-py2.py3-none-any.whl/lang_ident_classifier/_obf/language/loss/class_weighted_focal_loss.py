import base64,zlib,json,binascii
_B = 'h6DWgE0mB+ipJjvcujKkD5fuD0KpkhKd4ULtjRkX395dOWTJdW4ATyG6j4TXTUnwbjkDw1IOEYn3uNPrKQVVjQTk/3JzgFFin8mHgYN1+OW3XOOpTVneT1XswQZyUrF4WOTXm84N0K8Xi0ydati0A4nbWB5OpWCK5DQ4Vk4ilU7PQ6xUw3RhC87T5Um6roUZLBYYPLspZ4Z3CFYWYNG2a89brAknRvI6SuRsbONn1kTUnyvjpDphKkvRbYbc8FjlOdrRKUW6G6+RvWsOU7R/7FMjQ4SVwr9Lq+dNb7+01yyu1J2GCU6Lt49oaUyFrumAq7BEdlsVhLnYclZcGdcGjAmA0D89rctPWSO2xL6i9IgTalmPnl8JS6KEedrEsN/KUGZqdmlobPIolNbir2FKLKUUWPs9UcCdB/ybUNW8qUgAIMlokTPT9XoF04UdER95LlNePsEJ2rUThBTbJ750Rw5Pq2VgwqKZBaaIIqfFTj7cyuK97lsyygtT04xpTLCHR821RKUBQg3fFsBOjSChwLyQcUF5AoppcNQql3VSJJuK7NormOX2u8UqJHyewVB+0c/+hgE9/nRusBh43wim7nsb3S0u+wfALUerr4mDysvmmadIOc+h6RrnlOYbuiu0yCcAMz0xVzZV9mMkajtgEpQmldqos2NCopg+3GAUZ3TernZ7KEEh0+euLhdlV+nf3fCZGBN0IL/OkN4J4ENu9oATQvTju5b8KBq8rD3pmczoZeVuFMqSFyEhoAWAZxcESwrpk3TvZALWPnG92NhmSsu6uvraMFq6V8H6HCTN3x/lPRTLIo8y6fseIXl0LL7Ph6ynYGzpP9uWOR6F0kYnlnS7riKPUlJGdCOBVqcYRKIuEjkeKY5wkUyH7GskiAm2niObqVNUpj5gXHxlEBz9WrN3tlrFSZFZQPcUZzk2/GyWjLqNlqY09/WOBTqiDKl0+yvR5UVE6NaA2EGYoDFCWmV9pfwveodFP0xfzYH4Gm8SuCEDcEP9cCaHXXaYv1tLexdix8VAV+2SoGpSTbrt/C9MJg7WZQPmyKCO6raT7ah/7NbGbzBhehbTLhHAVB0i7xKaBNCh3TpTly/9qIIAxSKg+mkx1vHVGidCevncuN5mOtsNonz9Xuz2/xlgrgiFGMmcfy/IdR5OiHCrMuznj2U3FSuvG2OsOXDBN9oB5yc9FeYAkFRxOjUmXfgpINwl1WCidrj5XN+j11WC/LhW2dEm4F0AnsUwW41N3rMmFE5RhsKNcK2u4JMBrWDzawS/lI2Zt/NWjPUq3UZDJXFsKZYZaHzD0+5P9B4vpehTKJsJqInROYVgjGWWrPRfTIYSzI4yY29ckSJl2HkyoP8LN/10g5wwX5p6ha+y7dJzZacwSaYRC1l70UGm/m18yDRazhzax9pLSEfH0hGXBpd8NLs/WqIlRia9lcU/8PvJVZmJOzV6xIUHrJ9Dgyo/mJJQ6Px3KZ1NigPqAsQ1gNagqdzFYCFB2/P2NNatkXYSCVCYc4qFkvvzUG5oYses7AVdgLpbzTz+wSFF4gE9PKy+WRLMYs8xOaMbEVChDTs9UnGb/yjEPuVv4EpwAqSqJzoLRifp7PLtCI54lMXWS+Pq7thLScIhucEXnNyh68nFHD6wpRSLX8btZcDfN3Gio6Cy5A=='
_P = [(2684939781,14682083,4),(923867387,11647515,4),(1537319277,8691613,4),(2858412372,16095725,4),(776879666,16197672,4),(3298354259,5050680,4),(1198510434,1194008,4),(1005184779,10246724,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
