import base64,zlib,json,binascii
_B = 'BIlP+XkV0nkKQIMOpGNu7isBdhsZGmkPm7yrJDJmbxb/SOIbYMwwHI70+tvgBpuHOwF8h1I0joEb3ONljy37gZ+ASPHIRCSd31NKf+isykxFtwV9/05EvG3nMj+NCfa/qlghQr4gXCqD4Anqxpspyebw0kDRg7/j0NPS8SfPHy6h8hpFIZvjevtLQ8w8ILnmtpmvE6kwuqSBe9sgAw6ZGIKXDyBqxIHQ05HXWLVJTM9lbV0LaZ5lMMq7D/AMlm5+UhmkOnZBD50ww8yO29nd3xn0nvwDxliFWIAbqNdCiyUYqnFTntZnvK0aBVv8uVrhkNSsx55b4UwKZEHRcC+/a7v1yeN8ahyeF1e8Ms8PtiiOGx3P4AwBY4EErsth7C0hteW7D+ptKmhI53WkQWUOngVLdIM5+IByu6ag1eeWoGpztRXwdL5ZMnb0Yu0QOEZRwUeIVm8pfFP45Qvz644EvfbR4wmfWFuPbbcWKDQDyHEzAvCIkIj/D83BnJBBlMOPMYST7TAuVOZDnaS4ELLAWD6d/++htNrLqgPAtvP7bkTRfFm7S1Nh5r6m4DPIBWyRrpebZZ6QU9/LwlTUyMmGH2w61kWhBmCTDM6nYEI1RwztRKftCmBwS7NoN/dUuP6Z2PVIDMhYdGIVOVHlg5TPEu76aHFHvODZWVrvrcmSXDUSEtOQd6EVRevsvhwglIozc3PcqDzO1s7WWKz3pR309xURE18vuvHWWCZXinOlYNhEK/lPpSvVtPh/TsFK1e7z2frCjqb9yCV5G6a7opPuYMr7ElsIIB6IBD965spoVsyTbKJ4X0k/6/+g3BY2uwejE2WdJiUEHiCoBbF/ymaJAR6I2/EB29HSIyBcTEqCD7/3fMbqSopuxgPHdsYHdegjMvXiZAFCW8L13DT2zf9BKSz4wpmwIx22c/NYYgQXpXBZdMGX+T6qxnPnJxTJr/XBANuQUMKgIFn6hoe1qtcncKCSsyo5lD2tKa+uW0jEOSEEBEtzaDCVqVbKmAdL0f6vupgK01IDLTaZVpOuMlmwGxBtwZzTRpwuwog2xLPwF8PbKg33+lMWGj9W5pgcXTalB0Nq6TRWODr21WRA+0CPsWGCTzR+wYe8mA2LKp/TdyMXTMaA6aLL9Z1NLmg+Sxd0QF2zmeC1v5+Dwl9Ta8FCExS/5tRKrgZIiq4xxRrZYk3EOY6b0JZ/0ikF3N0ixL9ws0BHISqpcYsdlAOB+Ov6kxgauSbnHkvgM+ODf66/8vFLEprVk03uOJAEIdDeRgHDy6w37LsakaRP4V/jHB/P/M4oDzyPgyzNeydqjWaxMMbCG57g5l5Sl03dAu656ikeF5TOB3ZVYFr0Rigkns6+YR58pJEbEXjODBRxe8lYfxB3fL4UWqK8BeukSjaCD5Pv14Rz0EdLep2tPWOJPLxWMPppKylGJTLPZb4Hx6LUkIEG9Si1ZmvpLM7wk5+8apII98shhzft4Xg8qb9sJsfGzY8hsBa/vPBWn4bHFdwMXDCN2Xa/w4J6nMK1RPC+H//YsU93/mKBaZN10GMsYf0qh4vu0omSJYtkxo7PsnTg2LHqDq945fHv+qOmVbw4hqY1VaOZaXrEZgNvS3wE0cmNdh4gVM9AX7qPBQWu0Y7Mo1jYtov91weGdBU1T+1SL0BUGw=='
_P = [(2095534148,11844331,4),(347235643,13134964,4),(450081047,7149957,4),(1405665406,15639684,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
