import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_5890b7_0 = 'BHSNqpfFHC8NCwZB3seu3i1rI29E/oafyrfWuDt88DG9XHz9hr1j7h4JKpn'
_5890b7_1 = 'B6XBDRp8qiSeW79z40lhmzc3wvLDnQ31edb6kjZnzWlD1icG+T'
_5890b7_2 = 'JXdzR2TjU4Hbo5VLXV28LAPH8lbnqM7fyOnU5rN6p'
_5890b7_3 = '1pU+dcVjm61+6fm65DK5qyxDNk3PI454iNytWUxvAJN4ZpR0J'
_5890b7_4 = 'boDcG5eDCIA6HWm31nIerMlI/fnNJaQ5J5jXN0hqH'
_5890b7_5 = 'D7KTfjxS5OU6DoVthOyGq'
_5890b7_6 = 'iwB9ofZSJBMy9i0HhZbBFaEvfE'
_5890b7_7 = 'AWxLl598H54Wwp6Rc2JP35f5z2Ta'
_5890b7_8 = '/K1vO7K7JwiLEghareZ/mQ+EhmxjOWgEWiCTQbawdAXSmY4njUoWN4Df'
_5890b7_9 = 'TbsZBAmhmkjLCLRBFtnSAmSu9A'
_5890b7_10 = 'DcOH9hfEtoACW4VDmIkSFQ+0/f+y4Bm'
_5890b7_11 = 'V4kj+8Bfj3qpGF31hvY+UK6JfPxwFh0jqdgrtMEm2MLpFbLGMLxpk'
_5890b7_12 = 'ghNmqBBKJwZAoYa1/HLA4kOFghaIfR3wbHHr1YYYR'
_5890b7_13 = '3lUjGv9Qy2dqARoNhKEzKWf40cbnwgJK//GExCLXmGv1ikZEoNPShHkjzKPN'
_5890b7_14 = '2OfqpWL8XAQUWqDvot1Yo1OWRdiH4i2PwC1kTLgus9gKbGyaPjqeyCC0h5C'
_5890b7_15 = '4dlJaeBqazdrSreZkGTLA9'
_5890b7_16 = 'XpzEFNICwg9wtniuGFmMfKtdYcuPTyBmJt+aD6kIcUxWYXln/DeV'
_5890b7_17 = 'tkcU6nZYmHulc+9BVmwHqEJBco2XOlwxe3GU2kXai8'
_5890b7_18 = 'pXfNuuFSJp8TG2bdkL3BdeYiC8SzUopOTFJisO6wKvGxVDyFxY3+KKQYl'
_5890b7_19 = 'i29J3JceMnNV9sW2EOtUR'
_5890b7_20 = 'k+Kqrbs+YdHGtmSwZLvJ4UKBA6ra+Xd/mQrg48lI11Lth77pf'
_5890b7_21 = 'ylIaaMyaFbCTn8eYKS97S911h/qMEbXDiWhlvzBBhf4O2C2DXHeAnT'
_5890b7_22 = 'ZO4r'
_5890b7_23 = '1+B0uPIRBiG8V1j/jGCcYy'
_5890b7_24 = 'm/tktV/UB0q4/oR1m+H9xU3Z8vc5iJ2s3545C5jd8/KR'
_5890b7_25 = 'aUWUrTLlKhmhLwz0Eqr8lR7eEg3HbMKkj8fiLY62V/dZNlRDDcewYvl2bxpeFs'
_5890b7_26 = 'yNPNjXKrn4/uc4Rm5iPwMcyHF4ZU7VKuYNjhte/4RVfnQ77ISquz'
_5890b7_27 = 'T6xV5MfMg/4Cuy3H2lDDZ42ajyG1'
_5890b7_28 = 'LJT0N8m0cseo065okW4lifHrfAmlC+u/BrSrnQywHMzXwX9IKLzgF'
_5890b7_29 = '5C9flyFRsT0K/Abklfrr7WhC44Lz3xBaBsEAaZWTkL75LIg'
_5890b7_30 = 'T5LFOxULjnjE+l2EAhPGLm9p0nt/RC'
_5890b7_31 = 'FS7gCxuLiMtOWgW2LoWWqb7PB8LR'
_5890b7_32 = 't6gICWUOG4XoBRYuuWAdBDzmDua8Re+L6TH'
_5890b7_33 = 'X5bCzSpjGYGTy9vHsfNF0FtIdyBeV+d8TBz3Ndx+wMxrwpeqkF7'
_5890b7_34 = '7skifrgBJhANDZlliv8TVtThUlu1X3/xzbM7l'
_5890b7_35 = 'KHrUXyGvyaoI7d4zNSrWtsPc5homnZ5Y1c8qf4FstpO07t+H'
_5890b7_36 = 'yj2ipW6PU2nkYAkgW3pNpfWHYrivCuorYBFeFqhwwsMqS1RP8m5u6N8+qzXfoF'
_5890b7_37 = 'mdg2+/0DzwiT/gBuYA8QIUZt+RZytpKRLRNHrgQk62n0gXGHCWGn0egcq'
_5890b7_38 = 'efnQlZjRaIjbmgNfcP+mVlkexZUL'
_5890b7_39 = 'aBIW0c6Z2eUS8VBoSkmo7n8QbT/ufL'
_pls = [_5890b7_0, _5890b7_1, _5890b7_2, _5890b7_3, _5890b7_4, _5890b7_5, _5890b7_6, _5890b7_7, _5890b7_8, _5890b7_9, _5890b7_10, _5890b7_11, _5890b7_12, _5890b7_13, _5890b7_14, _5890b7_15, _5890b7_16, _5890b7_17, _5890b7_18, _5890b7_19, _5890b7_20, _5890b7_21, _5890b7_22, _5890b7_23, _5890b7_24, _5890b7_25, _5890b7_26, _5890b7_27, _5890b7_28, _5890b7_29, _5890b7_30, _5890b7_31, _5890b7_32, _5890b7_33, _5890b7_34, _5890b7_35, _5890b7_36, _5890b7_37, _5890b7_38, _5890b7_39]
_4b7f6b = [(44587,32592,2),(28983,57704,2),(59241,61221,2),(41024,45631,2),(19155,15034,2),(40849,16526,2),(13291,9936,2),(298,27540,2),(25126,55289,2),(35647,11274,2),(59010,58396,2),(23723,58524,2),(42328,62058,2),(59310,49724,2),(60657,37026,2),(64768,28172,2),(0,0,0),(0,0,0)]
_4e0fd3 = '0XuQXw=='
_e2c35b = 'hG7OYaDWbosxN7A0'
_fe7eb5 = 'nH7IglL2OMg='
_5d28ad = [32, 31, 12, 7, 5, 26, 24, 4, 1, 27, 30, 35, 13, 29, 19, 37, 16, 20, 3, 18, 17, 11, 39, 28, 34, 23, 6, 2, 8, 33, 38, 14, 22, 9, 10, 21, 0, 25, 15, 36]
_salt = base64.b64decode(_fe7eb5)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _5d28ad
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_daaf31 = base64.b64decode(_assembled)
_8d0771 = 32
_40cb43 = _daaf31[:-_8d0771]
_8d0771 = _daaf31[-_8d0771:]
_07750c = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_4b7f6b)
_hdr = base64.b64decode(_4e0fd3)
_nonce = base64.b64decode(_e2c35b)
_km_seed = hashlib.sha256(_07750c + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _40cb43, hashlib.sha256).digest()
if _calc_tag != _8d0771:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_40cb43)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_40cb43, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_d2f686'] = mmap
globals()['_a7f41d'] = lambda i: globals()['_d2f686'][str(i)]
_x = globals()['_a7f41d']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
