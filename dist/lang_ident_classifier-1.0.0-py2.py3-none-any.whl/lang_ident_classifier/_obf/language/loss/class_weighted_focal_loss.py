import base64,zlib,json,binascii
_b = 'mZZDGk0iyYsoXuIoXpktDtfZkCuSxCxQO8v8tyr677qjCdXkICpyG1IWfm5u8g4jck/x08sXTGT+oqXtDXmnbqL4nm/ZPBU0nDJKQiHQq8+dZPSJRcbhFm+d/aYNxSDekWwK8g3Iv8ZpftXZ+IaPj5dJk2geAlhJV+jZIvNLVtH98XBf+AoyUOUw+TM8oe0v1XtEij2dL47h8RX5XTHxGkFqcfAfhggQWpeUkJ2NSfGTejOgGkIMAYb0omd6/SJP4MnKOcYGiS23Faw/Dmp0ynJA0hEIIBd6paM1LuTPPYIa7VmLMHwxQU4D7FN12wHle2a9NcZN4iOzAWyqFD2rq1Tdyzp26VvP6bRcNlSbc08quQljcRXWGpZyRbGY1SEvS7qBnKFzmzcF/ciBM1fzqgxiK8zqHUZix2jkmNJUFD+2vixZEtCXCRBEtxwinDFv7HASkHfIrqzclkAj8KyhCgqxMJ9+R1oUh8MwOE6db9oJbraHpDT6eN0T0W7OqRmcmcgIpqGiBpX7DPTjaVljxdPcaYLffhfqEFGAU4mJV1PvNkgxV+QFfkwXYVTdb7YljGJ+rgHImfpiJzyEE65fT0NjcvGLWqzoXoG3LWmhXJKsctSh/jFCwuH1d8mYuA33rFqdCI/mVEaRz6V4aorIdP8IoCD3f5Dli5hvuoxlmUin36zZVc0ZdY7528YP/eX+b61f4SCtaWi9Cl6Xa2pD0LEjTw4RHsbne7Q5c1p4JECYBz7p4lMluTtk5GPh1bF0lSiOGLG9F2hKSbjsBEByXFuaIXxtlNLiebUlF8CcvcyNwMDTgnGfu2bm5BDY8dqMlHtGho4xdJC+CKA8CGq/vzBGOcbEe/R2/Ix0C6ovb5jLdfDEM5dkUweeb8BJDbg99ysAGCMCush3mhxSgFU7NxdOSWdYMC545MGc1skOP5GwgVghjvHwZDf2BRZIKqNJLfkBz2Z1+g9WxcJswTC2WGsiZRXrgd9GJ7d+44ycuH+DRhFqyZlqozTLjOoMXx0XsoqLOMn+8qrvj01oY3ZINBM13QCQPyGyb+9PeRrfhII4W7ghR2R/SorFPaTP8PkRGSHEiBLbhX64TBmz5V/ix2UBYNeQsPLPGbfVwHltt7JDu7gMMUrGWGlapxTE5f6BRjDGZXMITCSqCYEhBIk9Id4MiBQt64KAOE1any6VHxFcG/UJ8RuoyemspIrOze6Ntve7jc3wi8nISAIDxSxUvlyeaT5k2ALIrp7IKMueAbXAw+wnUXcBHh5lrinGZvmJO3vO/FA2X3eioU/hoBLjPATIx8xp7EKpCVykqrsXefOif2RoOUujWYENAka+7TyFt3ENlSH/Z09NtoZvLgXB20LMg/ZIdmsKp9BGlakpRa6vGjVBJF7AzhRiEpbNdRBwWVXgaVE9qxoklbpkHfO3ZAy/jh260fwRCgTXbZ9b5b1ug3H4kx41zmmtTaAtFG5Oyt6llRaRw/7E1dC/sVgV8KdqlpzT+51a/uISO5JVIuHD4v9P0zoca+MwUPvDteoUAy8mU1BRF0CUNCzhvGGUZVRZ+dSCbAzVumDpAfnE4tNSJZ5ysC7NqZ+XMqyh4/QflFZDlR3DGzPQQMxOvkrWzhchBTaf1C5ZxdEaTpCFTihXcMWKgDat99+6BX0dW2qd'
_p = [(2024447030,2576777,4),(2389795805,10978391,4),(1730806898,6571414,4),(906752750,13191051,4),(2235540390,4264646,4),(1618113215,9581047,4),(1747171573,14771700,4),(2255686238,11922991,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
