import base64,zlib,json,binascii
_B = 'ARoO5cSziiHgvPagdxY/s3fMCiThaIRByusPeyfnuDb+HcbByXT1EmvxEKA6NGgEZNuRu2BaZkBZXZfqTaBcZx4mSoJQDoJwO21uvjsPzrVs7IriCWvINfwBp9sIwuHWiqeCHGVrYIbkO8MIJd0xIEmix2bdjGS54fJ/t9NDeNs7EPkyOf4slRJcmZlhCXUiLHzboK1gdUl1E0TuraqXu36AnFarPaLEoR7ROJlhMSAZ1VRiS17fwm8rCRD6rOIVxBduSzjA1ZBiPZ+gReO+ooqSIkZvWDwEG87K7sEFxKcSnqHjZ9QUuHDOcutEyP6P5JWB2K6FzOLkUIBxBnuo8eqkmpzgb7pIz5znIgC/c416OTC90hOLk7RTVGYwtOu0aVT/oSvKGDKBIFj6P8m4YmT48gI6GJhqvypyQ+/RfjkXtvA2yKSGzvAjcBfF1uuiJ6SYC5kcI3XUK+huE/hBW4VRfnJzqSHblR9eBLQ42zjThrljVpbVTPY7AIYIstp+FkZGUOlMmDH8QXTeoI+YD78e7DL8f9hJFu4nTshsVyafV1GGLwMoHauv6Jt98ngITplnpmWr/5zdMtzrRKG9U7DynPD8xgFtEnt5F8q8DxD9lR41DINiFs4bbnTrumZi+2Ievj7+i7WJ7RQCxpDYSfRysTnL+W2WTeLcRCi++KE6XyMGOTZZ2PK8N2pqq8Hd3e04CcR8UMho3JKiVWDzIxt+oDcw55QkiEAoTMkZJtxzCfR8+wGrxRnvt6/pdXn0rYxnH9v0mML4xSAczGAli3gXysjLgEu8+v6s9LYEndyLW2IZ0/meWvqzl6uQjLcG8FmTr5aUXdh5jGxMt2QPA3/KgowVI5pgXCxAdkiXpg1qsTBWEfdZeW7b9zSrOHdxYiQdgxw6itAVWOYG5zWMOhDP8IwNu1L5AWN59/mDoxoLAFuxehb4BHNBcmt/UbP3g39Yg0Fqn/LP9YFPQ0UZ/qpGOgOxW95lh1IcDSUqab//ZJ0RstgPxEJ26H1IfjH+W+iIUrFf8fZtlAZYOXPm8bTD8A7AM6QwM+Jqf/63iKQ7JZawjn0C4xdUPaFNgqwFVhjRRcKtEPit7mU6l2DF09e7YNSe0J8jBv4ELfhHeJNlm0WezX4A9Uikn9Wr4WOdX/4iQzHNYE65JDsdy6slFLe2zLg8un7aS2TH/GLo+fc/oRSUROgHj2hMILgvqTyuQB4lHc7RSLicucvppqQKE1mnyfnwKfeLVGsczbCtxVOU0VA/Fuf2eqr6shevqiWuGvIWC29qHCUrXKqTgIhqZ7QlPNyVAzzycenqbLPS5JRNoTWMDBglAZ+yqHk+6eONGgEkpl90UUxDH3S5d0HtqKTf4Lc1Rzgut62uvPtFyHaMcyjsp+IBsUO9FBaQ3H7+c3fGrdSy9DPc5Bgk5Eiq5hOgsc9Z0m97Gq4/o+opPhwE3cdPaVqO+c/nQL57Zow4tM2x'
_P = [(2033694971,16214856,4),(2843822568,12411135,4),(4041004264,10357030,4),(2376455886,3556645,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
