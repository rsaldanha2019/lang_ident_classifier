import base64,zlib,json,binascii
_B = 'WSf1EX/da6yb1xSjUbIAHGIMpPacPfsV4qyRtNleMbYG/gerrVqmGhHfLmeAxP4s+tJSey631ofJpttIW7mvnLjDllS1Ock4xV0U/qLcTNP8QTZqMk6vSDmeKHMhxeZCEnSMCD5+qS6hGAuY1VtpIcPi5EiFlOV+DV7KT+y7P+wGkIHBeTDKnuNBglXbysFC17WAQ9ImEwxG+zjq5vu+HYG7PogMyltLBNtjaFIYiL/MPvq4ADdPMoBAT3cJoHE+LBo46GuLgD7SdiIUN186UnuO768Js3OYfqCZpLbTioXhEYSQcEdzzcQ1hdkgbRKV9zbWmHurPAZxs7xdQp1pR7PxGhy5/ak+OCfAJksFjQ7/nalS88aWZxQvK1nFAOAr9tLFTtpKOZurK8nsdFCzfqYU0SDUpZ0pPUw0t1+U+OGNEkuRSyLSoI5M5w+/HG20iNVrdZgMAqu3pzadj6Jp8S3zGhSzI6Jlt596Zz9U/t00FmfHLaZoCj8/tnDH19hYmRzuZ8dmeh9lxoSmJTwaQaWdCCvKCmZhKhD2cneNq5sSQgidw2zsbMd5FN59BL+8hUVJeqUornqKTJxUBKI7Irf5nrsyjr4qAu1r15RqI31aJQ4FMJR17ZUB9k/P2xwlcpcr6KGT6eyiRFPKl7qedY2/lOt5fRZ/VdblSj/PQPHfTz7XUg87pzDa5aJDkreUcrVDLvYUdaSty33B5TpPOTaxxrIelRYq4vBRXKV98KeqtnMEArGk4BotYRD/KnpQ2IfGwtHdYlVHPrXXgwKJMo5zTKPfAXvm4rpj6lrNFORcN4ZbNBCcNhr8RQOvVfPS4/egiJltEfCCvokUQ7pgX2TtpwWLwfZUvrYggx7jObNkpTqnQ8iU3mZLk+xZgg/wWYyT18nN4KXWRH19m9OmGhryO9J5DzHTr+5E1G+p7ZgWWzlbKm7y/HNJ9TT3lubmjRJ6xy8+2iOCoNn0sZ8tRnRiAIkKw1i0sUuvMBb7ErO4jX7BubBt1wL4YepDbTYf02xVKeqFsnAmHHJgvOj3bJdlHMieXGHR/tyXoX718FiVgvTqsMrtiC+QX2HPFpDj3M3WLBWfT28aCCuY5s2Iy9/a5RWwWc8XPUMhKaKgPB5ZHRk65paQaStCbwcAZF4OthO0qbhwfCma+vGetlM8QwCokGte8OS5vigGjrEHFrgHgkyISnpRCAr3WPlIEplnSskAJS2w9OiQqaLjIDUGN6z6KrAq7EKP7UNJnUgPXCdiGBxIn831cZ/j+hk884lFKH0Pj11x7clYubmBxA79XaxU38ZCVc0w+CJMUOhBVDaQ1nzW2WgjVys5HHzZf+nHc9LHF9EwDCqesAtykBlqOyyVhCSXiH9SxUGliwYBX7Mu0ZcbVd0EdmZ+SAkJkBaAXVGB/1YP1MaxlaRUYq7v2T0zmQ3J3WZDRfj1Ira02mPbZJk6PnXZzmpRs/BWv7NqeCEp'
_P = [(309500874,1972989,4),(2172210590,831099,4),(3551325985,301673,4),(1786081439,7155512,4),(2947290435,9424213,4),(1255274398,7154435,4),(932810132,623425,4),(2092783102,2672270,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
