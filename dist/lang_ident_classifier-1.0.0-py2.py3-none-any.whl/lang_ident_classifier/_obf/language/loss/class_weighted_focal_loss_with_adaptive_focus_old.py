import base64,zlib,json,binascii
_b = 'PKJ3f8NldlwnBbO+ZYxXaOMNlbH06ahNOVk4Vt61wP54/xPRM4KVsSzTPPlfSGY2UnoiNRLFWKhaHxOZRTjC1jJjFsELRStphjiSlItjzbamXu0fsljObLqJPspbgSnCEUqRG1GOtVk7DmvA4toHDomn2xc5fd2tYQvvtJ6TN9og4qHxgvOl/rXDndjaQ4OdwU5H90H7A70wEYiC6NSoq09k1r53R2ET1bNhpgmjAS7iNs23racuk0Rz7NJvR03MtB491Q1Ppm2CMXakxL5mLecHbbnq/MJ1H2G9sLVOgjfS3lF8aKBu5ov55WL0xAyhvSzO0OLsyedRxC9MejJslXRlARi+YjKDJZdtUR4Y8A79NUsVYzSeYMzdaFR9VOoXMgUOypXR/1C0KhtveltU+RvaNAzGzlJOl6ZrEF5eFtiHVMNjDcXnP70IQnh5rjKaLk8JuRMABtuEygTaP3Sx0RO+HipwFVbxVn1lcrYD9lmBwaCcLE9XF2xdgriJtPD1XUwgT+Tuv6D9l++J+XFU9UIOqF2QzBP3DIG3g2AGCi3Xs2xiwnh8ZlLlwCbpMfXhoAGiM+ucKsoNuUMpbRSKbA1yd4SbSrI44+DRTjgBZOyW9l+srzCRm+wyV+szseRKeZfoV7gCgaAGNZRzyUoCSCRxA9k5K+rG33pUBRIV/rrHhUidBzJ+Tm7Kb7llNOWlZTcMQ9K9bfhrx9RhZyfvPDQxyLfgnPu+jrHWBd6J3h/0tDyB+9zvJbUks4L++R8ZJyOuLRks2B1/C5afsf5hT9Zdhbe2+c0hD1MJiQnHd7F73SwIPyih3i6v4BoBOZjVPjlwxcGZUhepYwRX3rVaz1/bJp8hOMaglhCM7Rtd8BnCMeSwT6+y8wOjwJ21wUS6KGKgs9Cv6XioJpeOcCSHsRlg+vqzmOeu4JA+VUeK2rKShTAtcc7zx+3IR1TMnSUEYpCbc/yqgxZqOQUk2nNwAxk8bvNLc0D5rrLejH3oDUY9WRwhpK5lBBhyBpoFWOwW8ve7JqxrqypEeJA16yVghDt8cumaqLpaC0hrwiZUtlGCBX6RfQDFC7tkPkViueBHRt/0P4NOGLQeivnKj1nIPDx6RXFxBr+8Z3oCAAVfwlqBCWxZBydQ+PMbPUcjPSG8+vA23jd3KL9U/XFXJ9zww80bdhmNXm2af2edccLhuDn0jmceuydwzlhAsFANoyKx/yd/28khwRILIcGUv5p7m2bFXtE2NkRif4h8UjsULTqoU81K7OEpBdVrFjXTZVP201NjTA3LrmMAhh/jr4OppJVPWjDZf/rBRRXP6O7nRtiJUsTMre0MmNBkE6LefC7KOvyKYo2H73g6yWlq+BUbwXHRfGnTKbiLnpavNxjrEfScm9ogmDVaTCbZdOy1nUHapQjMGGNarmv5YeFs5Ujs2yaa6SDy7X9s8kq8kjvIXMDc3/fx4fXzSSiqmlg+fDik/FEX'
_p = [(2882298434,13068833,4),(3993321089,9939037,4),(4283867328,4196122,4),(2990204716,5572166,4),(3270296483,15440680,4),(3812194951,11239370,4),(3167491585,13028536,4),(312006358,14736027,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
