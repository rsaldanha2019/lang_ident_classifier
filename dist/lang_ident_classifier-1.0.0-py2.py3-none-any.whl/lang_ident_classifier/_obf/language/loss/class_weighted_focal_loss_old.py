import base64,zlib,json,binascii
_B = 'gBytNLP/gx+9SahejTpq6qQ5wkUBpEMjp7OSMzrNO6497v7MCxlznj8oI7ymUroLFDNi3TWW8jARIiGR9fyeC0bBVdCiinvmlwxDYDpcktuOU1REFQYCguTuQwPwDZhaAmhg6vo6zDtMlkJGALckBsXJ73PANSv6IWaIc8Bz+YMETgrttHmnNEoLBdbYEs3FB+7xZTbXuUDgTuJtv/tRBnJwam1Ux4q7x3nJBsYmf1HA1vc5z+6PYduhaFBp5whxblL8rbegJLpIEKdtxYnqUifZZ3yrzmlXEDEF9JKQEPO5FJzExelI3xOUx3kDPYlVy1QfFm7fck3KxrgkGsNjECS4H7nYMmbuQWTRfH+opCKndQ0iWyfKrR25JsPTHWTazAJAUjTUw05/ZwWU5E3mrLBqbbfdPkbCCaurJWfF2iiHmUm2qcY+bf9hJHO2RyUCkM/NJGQm2oyvDUnlLezHSkRTPYWzRKuXSkVEd5pW3JbkkGN7OGkzR+4edQM0hy9OOPEZLmEkRe1H12emcG98JV0jD0l8tnLKl+6ZGwP9CS+ZlFA21rgaYi6BKQqf99/Pno9MOHcwXTPCVEB7pBFIiEMwtvomfB6i4hPiG8njLwRLnRWCLNMpjqeqv+fiM6eXRcoqknRBYg/walcL7h1i+SSXOTCyDCGzandNhYZXbfI0sk1/dHerqe5cmHXCWTnVT2SUnxhPMS1U/qqpnYmZlqeWlI9ULqAiS15/kqlyZemR1pffS4jgF+VHeHQNTWalqhNEDZ3xlCv7ca/f0Py7i0aG3TEhG/00IAjVRYURd8CwtSJwDyVk1vc15p7KAcKJUWMC82QNZFFhhOFN5GS6lLRHpjoZDzoMIegzea7VcQg5oacN+jmTvNciIqm5uJOBK5djjsQ5T9bLpFEcRlZy3jt7rW23Xisytq3RsZHCfBmSeDDWXcoKDeFTZc7R/VqdeKmI56794l/ijAmoIMdmNMDKc5MOrkRc42lahNPKZNA298t1Za+sfFnYLTR4ldJEgFfSkodPOnbGUM7H1htRTujYSkJOdho1PLlo3v67GCiwKqSUSq85JXpEu7oxe2b1NUBEzbqzjr/wuxoC6Xn39pYFbyxnyrn28M2FdZqKYKW1A/ScjkLRY+OpCSTQv+WvZevF+jbjT6qWFD1lXs06iTOZHrMf4/NSz0y2xlOzi2DA3/SYQ/fV8yw='
_P = [(4171156127,5817087,4),(1554219378,3661397,4),(2903433395,12197817,4),(1380372577,7067131,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
