import base64,zlib,json,binascii
_b = '0XSvYLrZpnrudwOLyWSp9OqVMxLGoZ0sgMdCwiyj/WswjQnG96rb4Nc1O6+TaQzqz8QqIvwCaUSPYk9Bu1wA4kIrg+ZAdWhn/WqpTO0t7hOjC/+73f35FXYxFXMniK4+FmCrhk0p3/cvpi1j0Yq8/83lX2ny4rDdQyjOsVRyu/BKvkho1ltDlrJh7a98GR+Ti2UBxn8DAC/5Cywb5Tg6vy64IY4dqlYi13RKOTlA3aSsvuU48dRqFpr5Tw6tZhdmdnDpwfh6Qd5eflv+9K/E/o2KXtpQznyVJVfT4a2pJjXIp5yRzKR19tkeYNWMtAmTntmkHtYBRtFj0Cz9wQmneIc5tDkVUH/QIfUO9uajnuFZUJQMsQWmmHT735RKE60eIs9wsOKjnCOGq4dAgWQVnZJY1wPZEe0PyQeFynHz2d/5LeVVHVVMRm+yygTuQLFd5N4XnuieW36A3VwEdan3CWh147mRiBsEA3vGjM3JQ9XdlNZ+b8SXyBHWdghObOl3NmSQQALiieqxsoSjtKDv4s1CGM2Gp3MLwTKPWWMw+EhOCkkaJIj4SAOz5oovS3IZlkmvOPP407aIUyxQoqmrwg2UfltyCIwzqoSMjAWDz0rsyRKRMc+ODbw2tYiUcGdlpEI5ZPfiY8HWT626o2/BdE48DkroVcDxmPE2Sz6u7sm9ZblB/jnVtzoQQKn+59uzicmw6l4SpWPbsYIGczhKhFSjvKWROV4fuCyGaOsiNXQblt6b1KmvmH0KoiYU9M5uhThLQ2MQrRULV9y8ZwSkaPGIRh/gf/wQ2Ho3aEoBVpvhz/K/AbpXACnyPlv/oIA0G0q5jTYVIf/rNO0hZSkkJPYUDHMEyiMCnsIOLfQmdaowkBM3somI24FbtcgOexJxw4SSdCDDcWbyoX6+sMGyQVNCGUkJjpFGBJLPLj9jKDzwQLts9aY4pekuaD5dRDxD+ayui68MUbaPSrP5Y7KbLSRxIlk5hQ0VdCAxclliKeWN3XNyYxxad+vfSHS/7rQJzL8rN5UoA/roQrAuGYuiQK/pEIGaKucfDuM5h9bhHhjgshC63T/4bGYdZckYt+/X5pb7SFWO9rFzuXzGcd8iOjdm+lgb0ewDQVSBMRE+WbrMc+JISmMJ7zlcQqFajyQG+YgvLKfNamafyvZA0ZBjMpVijMqbwEX/t9PpymED1hkhCl30oyjacww='
_p = [(3320945851,2897743,4),(3672979799,9826575,4),(1078878389,10567192,4),(2067253609,994377,4),(4025479069,10378656,4),(3996894936,10726414,4),(1638537082,14618652,4),(3646143754,12739858,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
