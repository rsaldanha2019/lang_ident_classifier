import base64,zlib,json,binascii
_B = 'wbrg/j1NR+J9oXAUJkoomyWNPRPrR+S1BP6L6F+07qJVAlHDwm418Q6WICNKcuk4cO5mg5m0UMhl7j3gpfaYtC23HJULeGoGtC0tBRvnt+yY3w7HgvJpO99rcJC7Rio+NbXjyFVtDqDsuXnFkbychoB/iVH2pHHykIY5l+HtsU3l7B1UPE0p3zBLb7PqlpyuTtByf92pbZjOquqBFID50sD0ejoP+BE+cvdXZ0Oqb3u9v6jleW54QfHebxv5J9BZcsEwCI9+pDZSFAkLBie8MfMLolrVEQWfG6BqteNpDXeVkx56hCJTGzLDtP2+f7aiUxC31cSf5WbhO+KD8n/9o1mqCOlAeWwdz+/QB7oicEBY/E4aIO1hFpNxqb9Gok5L5g33r3XLYaqgQVOTENGzodapzkJYUaLwThnKMN9VvwO0zUvcV9ATkaoVjktomqGnjT2egF08HzxSdZOVmjpet9PLuFC28jSIg1eePNj1TYK7GfV3L0WR1xY3yo6DKm9wSpJCVtyaNG35rGRrN4vCbrLU2ZqIVBYw/8Tp8ugHa6fyr/kqBT+dno7b45Y52BF9Fp4XukIUpj9HnM7KkpY8kO1S0fFTdvFKS9u02raOxRdBF7CJG7ftly4E0QtIyRtlAyjzJPN+Hr/N0rmHhMN6l0y1kvwmkhzw/MiLjZ9GfPITAzFmJY87/XoreF4u3Jtng19qxhlDHMa2LdiAsdTw2Sm1Bfyw9NZXY7y0vhsoAfhFt3UJn7ht7OO3MVTVTg9ZxGslkPpFeZqn1Tfqzl6Tpdjv2JRcsKCKrJMsHv5bOGJUt64P1GJXIEQBPDGdI0ZRrhD3uqh9EfU+BoiYhM6/zAEAIMDepI8t6NEanoKyZYC7F1XJgLefSADLkhbzbWaxdrTOj6su7kF7upSheLC57xrEbho2EvQwvkJrb1K/Dvkh2MO1m20OpG7qtTetn/TmMwBe7Ry2AB1ce8UejpZkEhnHEmW1j9Ko5NmTUAY+NuKSCjgqqTPhqYrDshqcS9l319B2b7KRCiz2jzXh1gBtC4L4H8R9QJdPH/O/fCTL+T8E//V18SkVhfL9UEPD6Ci5129QDKWU+pZTqs9xMBOmCCHO0LYq9Mnv/d8anujl/BWlgcvoLbdCIAzDpBP7yy/duBpE3ULYpOwfuf7/CW8oMUwvTo9t9JxeUDVGkFykTCp8lIwFjN5I3gIBjiErX0RBLvIkrX+uCQ4F8+LBY3W21kdNC1QIN9FemJ68ZodzTH7PBBBF6Icy2ACup+UM5IHz4Oc53rdDk5K9IrQRJ2CHY/xBZxCKPBAL8z5bJjqJ7t6A/uxIPOLf1HKMB8B4PyoeS0ehNJpRl3VqzXwUPQEcgMPH4yj1M41HGinGS6ZWyztHRbtjoOgHB8BP3pRCYPHspNM5xwI97z+PWWZxoz6yRVjHrCyqliKTiBo4c4iRKZnQ2PydqbkUuOH/pFoc8+malcheWwKQEA4uK+WBGtUZwFWNeqXt+yg='
_P = [(3115323859,13653115,4),(1349015937,11468117,4),(1832473538,6686908,4),(3696072978,12754743,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
