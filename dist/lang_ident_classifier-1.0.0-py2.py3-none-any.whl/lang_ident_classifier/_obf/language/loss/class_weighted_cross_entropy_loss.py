import base64,zlib,json,binascii
_b = 'QMpxejjYFOY+dCymi2EHfuN3G50+JsYRwpyViTy1tMExEtDV14Mc/hdihsd9L8uXB34itVgY6tHTb+ynje2Va83eDFUVOHa0iavQKpebu9nDRPHBq31q77GWYG8rXB4JticvkONFLnMdNwwHNS/JkKSTlsXvxHBJSYYSK4xxxbpRylaPKmye25JCIBzH0J/PbUHJfVrdLC/9dZaVp5dFFqTz5122uvxWYw/jBWX4r8kNf3x5Js+zpz3qX4qwUFqVUThO0LYBeAGh7+7ckBVhJtZFWOW/nRyqKox1F21zWYZtqn83hTgGcszhpHmhcuuW+hJIL0r+cL+hD8DDhtJ6MedWERgbf6/QJLt3dscXIECxv2CcAGCe+kb57J6aDO4wS4NZELTLy3f+1w5IABo71v1gChLPEpRyDkrHsEo0IeNNnjfLSlEKbf80L2C2H3+/LuwkJfYFKTwp7oK3jJsASLqYGJsdZi4lDJFhF/UK7x3hOZY0Z2YqWzXMipLvshGGf/mA8NwC+BVTrRuSpTSdUXvrmNVNfw3/8RhwfXaDcUjC7aMPZ3WJptn9uhNY+SFirUH8AjfDFFKh7MBON3TXxUhykhxGjTM7+IoJVY0FKtQoNt0KdrmSL+kqArzE29JuxEOVSrr3+v5wuzC/deJ01q/+Z+I5wvDoNSMTTHy9EjiHaR8jLSRoq8KPrlSZKsaiP2y1zaOa30I7THllSw4RXXZ4JO5X3mKCRZE/jWAG0f1LX7DYBlk0pp5uKpg7jJMRQaEfmO2SZdw0g7GPMEe5QrKPJ8TFM2Skph341HGEVaVnM3Nsq1xQ2TpXFJPqSm8RZUg2xUhulGZ4UB/9E2sqG30oDhsavkcWBCM7XtkyIMzKHFF0OyXT8//b2NmUGtx778fhknCkNDQAvr+jfxCq7XZTywNv6UmOiFp/BgfQRWIXDeILSh5Enaup/m4aVGXSfc5T5KV4/qcs4RvNwlgQAgDk9CMj0CjIHtUmS0krwSVIhCcULe1XjTRWamYC4Y8uZvZUWGl5Eb0D6U6KREB1DKA7bqJnh/WG6gcuRko6L8kyycLN5GILvNN6IIvukfOdZIKNTmE31pQZr0ETZdtuqv4z5Qxp2SqIR8q09/vDUg8jfnTUpirsXdVDwJhWwUTYRK5D9eU8MvOpg3GuKfrJTjtT1m56hs/iCJPcDDKVVb/FOtz11yK16NPAAvu+ro9PgvNgwmYBjrcDcaLV2eps5z2q4vD7uCJG0hQUETObC6g5dHLyvy0mMPiwpRCDoQ/1IJCSZ925xekmIRaJKfy8UQnNf+rtbeerVyPLNdoSkksnAlFku7gwAB702CeI1JJcXLP95Mohe/SPkBil3RZcVeIPuZRIkj2oA9CmT4TB2gb3GdhLSzGA+GiZTtT9S0iriFCEduLGGtEu3yUzHH2CAcmgeOaI9lMgjYPoPekR/ittVxw3HzkTRxcgtKb0gwDVnaqbR3MKiS+LJRD3JKQaIKcpCuynqw=='
_p = [(2641834033,11677840,4),(2981516386,1414529,4),(6632772,6730585,4),(1471295000,3839779,4),(3275038629,3750973,4),(2345069546,15605998,4),(3854024849,8311594,4),(3900885434,15171828,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
