import base64,zlib,json,binascii
_B = 'AmARFmoNs9slBZSH3lQJYQ85/DMppxH4pSIj/ftwmbqxw2S/EyuYZsPo2OuyCugzqbWngqvI1NUXhE49405lIkSGAgcJdLwFLLPIzBDLnLDatd1oVtvuaCliO085OPVawq7qFqerjqq0ZMrgWJPnGkyreoXqVZH3CDjq8YLeaT8sBgqwo2r4qlcJdzYI99uRKivxo0zlBBOGORPV8EugztC+8y1H+RIvry6mqHUsbaotDmitrRhxiCuYExF2I9RPHZyNC2gwRUIKZu9QlUOcIdoridx/F56JBVRJcegAuEb4ZBfW/o5W/YcQVNfrpP5RBSVQMb9tX+KTAMwVdlQkKzTM/ipflUsjr4wQujvTMDmy0LZiEp1A8TzHxTqdC0TLW2h8tZmOU97EIB9yZn3Jt3vYPvyORK3yeGHt4wnl/D62dgAUOXrBruej2mK4ZW4Imdn5yx6Y+DWp+lWg18XGrRp79F3GoQm8nxmLTaAPyr3H+naf/u4zsEI6bb3G+NroqO0AaTYVSZsaF5msAvEnyRX3l/ize1Q9+3mJJmulQnliXo/mdsTQyoxDngkujRXIwQZoh1QwxWYRjP4XCsPjCj6iFuu31E6U8hORVkZHt8HdhfXgBeENpsmr20cFdju/FM68DpQeCoscFWWki7DCpJ4ro5IRZpJME1VqbxjWN+fwJQc4RATP3mgBdxfeNr1hPnTy7Uxb/0J15dMrg8tidWBwhtFGG+Hmq9McflJg91Pn2YRkE2XAh0NNT+lM82Mbms0ApgQXVAnO7Vnv5+XRZeo/ySKkdSK8RdBHRbWaGdGmzD/+SvlZ+gpm/XJKHEQ6mryusyHhDFoj5B8+JyQZL+vfWaYj0OJYiKDvSdOe1EEEDrhtHq3y+tUGHsVmUyvfpfDh8kmhf5OBxrw2eubAUobJ2p9Ata5cc7dVig5DaLDIDegL9etsHMeAfe1rhm5uyMBYB4gGQSxVvJsO2CfJA3ESe3RVg6CMVQrPZmtVHSQwtFOTxWPMpwCfRW4N6SYpuAGChM6zPcP99g3AgaaPAw67XkU83YXeiOwmQCbEOZ2RXw6qVes/ubeBuniki+ziNdmlpuNod7ieMO06TagDOzHplXfgvk6WiVpia3md3s/3AkOBh3OrtMMgpnvtwrw6y+AmJQ1xoXLOTB/KcjQ/v/LAZZzFUSorV8Kjtf44zF5ZP2QVqtDq6rXzvSCJNQzqY/N6eURZ7CQKA21OigUVp+wGnjeMmgzSMZx4TwYeu5I/mqv6os+Vq6fJqNR2p2BKBrJbbKp6lz8a6uPpH7MNfcSzfpoCkC1V5RabYEdxygYwKIFo8XESlIqutfak4HjwGS1iSLtY9ET8BXKU3/E4V2RExVbZT8Dqaxk7s6Td37xaSPvwY69MoDqX+NEAHjaplO3cUqa3tQ96b0H76F49kd52dYBcGfL8efNPpf3KVHP0fjUgwu9UKe/9rRqum8KdZaskTi5STv4YnkabNnpCAztTO3O5xC4='
_P = [(3380472821,682070,4),(1977087398,9500805,4),(3877231513,5318575,4),(824150654,16616029,4),(3235573250,2329712,4),(3769724951,7010156,4),(362817499,8189748,4),(2963492455,4562482,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
