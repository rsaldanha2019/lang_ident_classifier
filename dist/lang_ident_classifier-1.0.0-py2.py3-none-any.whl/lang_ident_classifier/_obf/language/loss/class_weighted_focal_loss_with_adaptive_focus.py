import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_1e2a2e_0 = 'WTd4WcmwNLGW1m0dz3c='
_1e2a2e_1 = 'zXLBu/Ezmrhw9o219zwep1tSN1ZPR21cO/oZ9ecU7PWMksaSM/XrKhv'
_1e2a2e_2 = 'BQaTkrte2/V4DcYMaGQ4wxj57s/A2/F5MhDd58rwHXmsXNTPNXa/cX'
_1e2a2e_3 = 'yws4E1kPBLBRyGPsquu3LtUajVhgyRRF1yIMeaKvAH0xNLs6H'
_1e2a2e_4 = 'hTlx4qGhRMnMrFgNxWvtL8cQNyi7Wg/ntFhfVxw2twX02yVY7Yl'
_1e2a2e_5 = 'lcoRyOy2HlWAFLel6UiSkbfV'
_1e2a2e_6 = 'ccAUJXs6+9lvoTDYx/6ef8YEB49/2Ax3SQMqMhzeCZPdP/CHJ'
_1e2a2e_7 = 'oniOKXDp1BagWDLgmNWwiViVmmf2wxIbgZbwkVfkj'
_1e2a2e_8 = 'SWdF9hQ1tZlwALcj7Wy4mwfEPV5BJ/AhBaNG9VXbZu2CHVdeXm/2S'
_1e2a2e_9 = 'bfCcIu+aDZrf0F0+gT4J9xmRYb/ESdJ6OaEaefkmRfQrK'
_1e2a2e_10 = '8kWIWsUw13MIb7/SxcrvBDfOOJ1ZLG5yYdGg'
_1e2a2e_11 = 'TZfJSnphOjB3HR5rZMWOSqgSfYNBh7QaZhDVZ9qvcpqvgl0Y2T/WX2iN'
_1e2a2e_12 = 'F5VwUXmb2NWwsRQMy8Jn7FxvC/yNw72soPrWKAn58tBkKMR+RzUf'
_1e2a2e_13 = 'hRM/1R1SgkPatNAA3bTz2AJY'
_1e2a2e_14 = 'Q/MmS/POQ9CBUu7cNz7P/Lw/abI820OJjMdokgGjszUP1gZo7Z6'
_1e2a2e_15 = 'SHjS7l0qzcclCeLuSTdQUwESqSciwii'
_1e2a2e_16 = 'Q3U4F8Oxxag03waMDIECzeF01oXMkMvw/T6wP/22rn0uUUE/JJufsVgIKdNs/jCK'
_1e2a2e_17 = '4kQdZrLrv3O+uf/uQpgwQVktI'
_1e2a2e_18 = 'dJ1kPss+PykuJcwi2eeCUz8byH2erObf'
_1e2a2e_19 = '5vgPJWi6mEWLonE3CwMQCT2NLS2'
_1e2a2e_20 = 'gEw2qknB2ZB55UTBRIJWUbnmmKR4jHgTaNK6ZfcCNOgUCIs/t'
_1e2a2e_21 = 'A9CZVx+nZ0EPUUZDcRlandqy9Waff+Db4'
_1e2a2e_22 = 'f0NO/FWGLcjwLVd9XHLqfwVruKl'
_1e2a2e_23 = 'xToBLejd40hOc0xYc66lmGUmIIdW+eaUlyH6COI1ajg+4wtmG'
_1e2a2e_24 = '/tiRqXtJHlHk2IsBJ7GhSg8gOck3ujLuXOarziehlLpWFKO57CHDGOIeAPHE707x'
_1e2a2e_25 = '8MP7dxVk48NCvZj1E3mkCRmprEAdAkXAE6WActlZYEsfkXu54ggfv8x3'
_1e2a2e_26 = 'jYhibbS+P5MR8+uUkM3HK8gPitZbi3MH8RYk'
_1e2a2e_27 = 'LokkxJEh545ikbGPRgJ3p4QtJDBd9'
_1e2a2e_28 = '+vhVnFL4HyOvNtAA+68v+bsxecYJby0krhH'
_1e2a2e_29 = 'BEr1FWNEgdTYBapnQ6wOo7E8o8qWTv/obirYXwKsdEpwblndYY4cO6BsG8Wz'
_1e2a2e_30 = 'qDyGUUQiUbIDy3lN17E44se+jeM9qp8/Vgj4Ud'
_1e2a2e_31 = 'tRPtxj9kIXY39l+eYFxy0RD0ACBozGsrbmcee/+0b+iKE/7zIG2'
_1e2a2e_32 = 'MYJyP41hDlYd4OIY0DaG4pv7Br1KCM10rcc83iJJhksFx2nyJE'
_1e2a2e_33 = 'Zvcx8OOuwr6WHS4f7C772J05TwixB9ol8VYAZAZ8lkD'
_1e2a2e_34 = 'VfJ+6ySQTwJsFqLwj2AWGA+2Tytn1KwP+gpRcSBu'
_1e2a2e_35 = 'vOvgjR0FEOzXSVIgLAlSzmn03rS1GlkR/88b60doo52gK54apLKV8U/'
_1e2a2e_36 = 'd+KrGtYNfB/wBeVC0IUaKrULBuexAJr1H'
_1e2a2e_37 = 'QjVq3xP1bnTMo70yjNOY'
_1e2a2e_38 = 'Rg99spxOQ8qbXiX6pbbkIPxymSm+PxHnWLBC'
_1e2a2e_39 = 'CJmSh3H1fH2B7tlCMTTXMfDMpl7MjBsSXCPCs'
_1e2a2e_40 = '2YzVpNTNMkATj/GyxJjB3TJQ7LW+ZIX2aJr8DvLdMknIRAw'
_1e2a2e_41 = 'xXcBjMH13mFvZvNGt4mA3uEeSIdsxDFDZ+6wUxKG5nR'
_1e2a2e_42 = 'PsBQh/FbxRZlKmR3MNaTlK1XLdWFRW42r2rKtEK'
_1e2a2e_43 = 'srJjAF18YP9+Rb+bBdsDOHR66uuYcGZLXiR/XTCE5yhjT'
_1e2a2e_44 = '7Uxp3VeMdxub2A9tEXHdvT5jm7qQHBjm90nrqbHPTBv5uGZr6miL7HJlwH6FM2'
_pls = [_1e2a2e_0, _1e2a2e_1, _1e2a2e_2, _1e2a2e_3, _1e2a2e_4, _1e2a2e_5, _1e2a2e_6, _1e2a2e_7, _1e2a2e_8, _1e2a2e_9, _1e2a2e_10, _1e2a2e_11, _1e2a2e_12, _1e2a2e_13, _1e2a2e_14, _1e2a2e_15, _1e2a2e_16, _1e2a2e_17, _1e2a2e_18, _1e2a2e_19, _1e2a2e_20, _1e2a2e_21, _1e2a2e_22, _1e2a2e_23, _1e2a2e_24, _1e2a2e_25, _1e2a2e_26, _1e2a2e_27, _1e2a2e_28, _1e2a2e_29, _1e2a2e_30, _1e2a2e_31, _1e2a2e_32, _1e2a2e_33, _1e2a2e_34, _1e2a2e_35, _1e2a2e_36, _1e2a2e_37, _1e2a2e_38, _1e2a2e_39, _1e2a2e_40, _1e2a2e_41, _1e2a2e_42, _1e2a2e_43, _1e2a2e_44]
_758df3 = [(20977,59284,2),(38173,52244,2),(43539,42716,2),(50252,8151,2),(2320,13973,2),(63152,17345,2),(52233,38578,2),(17850,11456,2),(26411,804,2),(14797,12048,2),(49096,19130,2),(61022,9230,2),(8819,55118,2),(22251,40195,2),(14639,30036,2),(60199,44787,2),(0,0,0),(0,0,0)]
_aeb728 = 'tmVZCQ=='
_2b7848 = 'ZBz07VHik6mNOcgR'
_e8fcd8 = 'O1212+TtlW4='
_f54761 = [44, 26, 0, 16, 12, 6, 19, 11, 31, 41, 30, 25, 14, 28, 38, 39, 1, 34, 43, 24, 42, 3, 32, 8, 37, 18, 10, 17, 4, 36, 23, 20, 29, 2, 15, 9, 33, 27, 22, 21, 40, 7, 13, 5, 35]
_salt = base64.b64decode(_e8fcd8)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _f54761
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_0d8231 = base64.b64decode(_assembled)
_48a324 = 32
_ae324b = _0d8231[:-_48a324]
_48a324 = _0d8231[-_48a324:]
_8b38f5 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_758df3)
_hdr = base64.b64decode(_aeb728)
_nonce = base64.b64decode(_2b7848)
_km_seed = hashlib.sha256(_8b38f5 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _ae324b, hashlib.sha256).digest()
if _calc_tag != _48a324:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_ae324b)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_ae324b, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_0f4772'] = mmap
globals()['_71713e'] = lambda i: globals()['_0f4772'][str(i)]
_x = globals()['_71713e']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
