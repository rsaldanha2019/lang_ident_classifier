import base64,zlib,json,binascii
_B = '4nJhDZDUPHdNQX1enhIsa/UlFJfe49XcOsmcRCec7KjGfwupSJ0c4pD0c6kGnCZGXvSoxjdUIJ6lz+B5UeN8dgtJ7TcYgiXaEEa22qtItpZ+0D+cgtUgrIb/1w44BzNSfgwx5tbyShJIzc4v6/+wxkWy+ssOIQyZ2PGh4Ynf63sh0/PaD3ztr7VjbX1UnLwWFRKf0Hp+dIcY6MPhkb7ivyzjh8ZiJwwiFFOlHrIdob0YTCVXLfqBGROb8atYnDxORUmtYIgPDGW0VICyeDdPVumm/ePTfGxyuMLeU7GTUCaDJEOOwMq8k0ioYPFFMJZzWDxRuvFWnINsENeIp9z/5XzyhL4VAIAi3fvtK1HFcvQ9CL/sZnN7dhUlhx52CH5UsXegSkshMOxW3z36vj27nt928U+nek715XXn+JIYvYJ2cm5gFeXWnYdyV4b7PCTGM0smX5zj4lSFCMeE4BQjxfuYsINl7MV52+Me2sn0fgA9uYHmMBrywgaACcW8HipMhNcF3nZ1uvY1lULKrSe3rtjdTHJsI1OqN6rbDmE7ugZF2uPgpaNwqvl6dZphzGzZMtsAMEj6pQ2GYs9A/wkJxdOjTPGj4zHBWRCyp/Q8nYk8dqy5HKIgtEtjqScSQfcq8Y+9DYuiFt9QNfv7/vesjUX5+aUhtmghiN1+ZO1gCDl+sHP//HgaQeTJ01deLwpbJqWces1W81eMXCAPlqLyegtJw3NCQzq9DB2YKdcH6eqAWumLeVC+CoUA/rAY7ZDRJ9NW4YmaZPpolkvJo+02FJZp2syFkAOs3CVipkmjRim++nqorLBjHYUBDFBWAuRcVmiw2B08EP/TIRNJlfdeSP/rEaLDRgHGJOtroiCHShdaoegjCDIxaEqYWY/bmM8zEcEcL4G00G2ZY3cvfuyFwhYJYicXUDdquHNuMr4nhyeaQgtNfSO0tugsPEP6RLSzNuYAWnyZj4c2lkk65vflIPvac0NNpDL3llghPz2995cXSyV1J8CKdhwzKyyaowYFHp4U2RVHLPU+nPgalThKvNf+qsJzZHrTXyGwDdZ7AShgfh1AzwHdXW9HEyCd7PllA7Kcd6kOXrhgIQPh3aXRAZ2MxnkHnJgSHtJeb3PLvpAB3Zl1QY7Q9NdyfsNB5gXY2rfS4fymc96l8gRmLUTjw2Ry2BnV3Epdm/sdw4FVPB4371/w3Cqd7qsn/auihr007/ShJFFEw/NfERxjpzPG1nFqyEZnZnF4Vu6OuJ0fJKCA/SIh6vVg8Gj1u8oaqnbmbRbfW4UBwhzQcddmKY/FYlYJaJVsirXddtJyD7qEJ/mpDF7wqQ5fntBzQhxiSXKGvdbJBTe+Pd7RW8D0XjkTus9JjmtkbJ0EU7L6D8WwSpIYeAo1ygYXHFoyHwTMRqPc/mBF21R1fJz6JqqqKWGlk01k4YGbmqYCO9G4o0aImgVhQUWkyF0zyMdNo5ctJOFGjQGIpq9fglG+Kr2zbvHIRgIj0CfRAQM12wCSS7rtEtr5ihirDHp0b9PgswebuQNNiZToRnfla3m9XCZkxxi1AJI9sbD4bP/NpdmchhXkpq5Hcd2vohzbTxXr6cCto9cOdMLh/NUSkvRq+sHtqn6ZONZl+wm9Og93MCKlEyWebZnwvD47WNPCrX1TmFiwb92A1N66wjWNgMln9qWVR2Hqivz+hUd0+y9uycMIfUcBZETl4YuoUbMjfU4Y3H+dtYte46TE77TynRUYnUqwxSZfCGU296mLUH4NNXgaCSsp9cVJCE9prH8HbQ8kSvT27fHU9VGqjjnTIdglckP4OXqXmLrxAYhUbuG8wkaSJZf3ljoBOUZK58QPjiOsKTMIhtbFXq2MiXHZ4wZlRjlnw0FBoLf0pKCRUwQZY3vP9e5IODER4QXXJ0PXSjwKn+qSVHHB3Qfe6gr8cUKYDBqKd8S2U5hI1g=='
_P = [(3230021670,13536909,4),(713694077,11783181,4),(1967496575,5325721,4),(4034916636,4200447,4),(2036752721,3098708,4),(1600994449,15191048,4),(1865787734,14429651,4),(1558791645,1484021,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
