import base64,zlib,json,binascii
_b = 'uKMRRLTrpqRv0MmjqD86N3ZhRSEztDthj3TyqjHLpiE37JBK08QvWeQV6Br677mLMrJdt5FVF0TX6qEwQUmO3jANaSXmCo1S7YDvrhsByBQGSMbAjETOZ1K3Hkr0iLS+hlgwkulVHm/eJuOnVzte4xUkKlkJtF0b6eJHSfAepqmkSF2izmDe8iF1uW9FZYaKdfhdTH1EuE2CD12GKUyF31TeiGQALnFHRu6rr7xAFl1MvgiRJloKNT3LBqj9aKHBnWXj9H/aNk3MQ7Y+HN/ZSItxYkos/Ck+0PK32GdBbXRJzoDiMwoVHL58roZMgPoihOd/1LpkxwdNFqg46c/aicbhJF9GfEfi3lD0c2btz3DSIkUapepm0DaHnuqiOPC/qWCfZvzj7E961kBXiTWkWkQ+HU4Bye1Eg/HpA21IWbbnI7seO04emhMUdCFbbRWBHAHGCXmWm9imWvrxDDIoWudfLKvuhcoSyc/tpYRxuvi1aAOzf40yAqSCfWZ+xLuX9ULNT2VSU0RtkdvgVnssCSU5QGFmhxzxBkNUDskHuOtezwCz9UBOKap2T+S08VK/UCLjCsUpNpS7FgvTdbUhW64vgd7+sZ8na2y1rFdMbXFSagi3wX72ljYAtjhgSTLEQ5F3OnrpG+y+/IIlBixFT/bRa2dsIYluVmpXi4Z4eUmq+g8hWkE2SyWd2urTpQ37jY+hJu962HAY3q3x2xfxV+aePNqPC6UEHPHxPQd+mAqPlIvzHU7/R1Unclkghx8getVjOLDnf13iP7QD7jDAhEZfOaAzxHddGZ37OgvC6525XOjpjbZuOsYYZBm/Y2Q5crKIyXdwKBhLRt+db3P1q4ZspqGKoX3fcB3MKuZb08fROQfsPd5cY9pMJbeuJwFOoj3COoXb6gGxQecEIIAHvbzszRBcZOGgVdnutxPtH1EX2OiV+duJ1pT0qL6ltC0Y93+6Fg6vUWdW67or8xNS97F2IOPrtpDBK8C3vEXhgCrIy0SromyO0aRkbuhSrrnJqzyozOMLJG4KocfbQRb1sKqUSdpe7mAYaFaE60JsRDWMS7DGvsXCFrctYM6uHJ7h3Wh349zs6yiT4QVk+WDI3r7zXamdUE4QuQuQw2K8P64FucEjoR8TIRLA7znWU5Wv8OgczjFzYeGMQ2gLdqF7PP/iIgzGBPHZ71l4xZZSOXAMwuPvpA4eAkI5Y12USXTE3gaAozigQ511Lrvmut4W/hCBbkj0y9f0A8nxyN9nuTQ0PwIPVb0UX5yPkmTHNWv+0GxPKtmmOE8Q2oqjJUUrnjYoVtet44/9yv5Ds/Wha2lp3ejoY1pmIxaZkEn8zZALVfpkp11cEw47qMA6Xxw23zUn0wZfmzgcbHa1OEWQhYcJAe8NW0e9eCoSU6/374/0KLH9HTUje7mbmgiiQ7hQHncJcpfpJCQdYG5D1nQ6YK6LtxeJ8JF8Ufl92pKG4TAUqCQJufQwH5kFaZo5tcm8dufPjmQjjxqprJV7g11NZJDeKkqk3qFVO3K1BRCrIq5nLEG18/aI9halwoJzHXw9MdjCeMQQ9d4E3dtuIWPg59Y46489dGf+1S6QqV5U0bRr0A5P3kyHejWzCLXVTLCu+p4qdsznAWIe6900KuGA9mhDynZbgX56vbiE9DlDRDkpOh9uih6W47thEJa9D67PDMoBpbLHs6Vb33NFwE8EKmu5RpCvNX1vrbBnlL43Hx9HkOOQ9CMblhWU/mEyJT/nenLOpsVHok3tBme26fHb/DEwNFlfWMv6kmMBGhFduUcUq7m7Emm19aQ+yh7w3EsPornnXjdrYHWnIm5T+zyUVYBDtUysZNCmaAC4BzSk/BTOyKmq4gcxfTDqrK0uEQJTj+qQynw2YTskjhIeJplTgmP5GGrESddsXPtcgOxtlrW2UxEtzfnAM57dF8kdd7j1e/OA'
_p = [(3224786017,15899905,4),(2339168500,10099065,4),(1825884182,3507679,4),(177757312,12565027,4),(4095165954,10304946,4),(2616560958,2000729,4),(4257824469,5033232,4),(3951812228,14116040,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
