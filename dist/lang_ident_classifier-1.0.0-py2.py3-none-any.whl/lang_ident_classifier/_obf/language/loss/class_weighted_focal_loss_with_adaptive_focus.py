import base64,zlib,json,binascii
_B = 'OgLU8I/vatDNJhULwimG/GkRG8XPcAHHmVk/fAWr4oyiwGuKyVntwpP9lzNs2hzIATJH+Eb1cfoZTkYpxvo/vz5FDTQBVzjdgJVQgAQGlUi60x5Jbi4OFoX3ZtmpgrR94YV5oKWUCNXN3+A63lr8szxzcovFMEJF8S6pObKrvnbs116vTlWRmc4d71mI2vgmRt1grVfLcx/8OfOy1GbI0gnnY7FnOarGOT5Idk9CY/aH6amQ1OT5ANGAYGHpeLh0XXrRrQ/uV5wqQ/egUimyjBIlmEw7fY0WxhER6L/3zP5WsVaMhjwViqaIX93MNYdHMs0vjkESlOpdiURYZyseuciczPOtlhdfTd5MWIc6Jy38K5XQKgy1zSZOKo7M5gDLgwaMlgidkZw1aDFLPoMEZ40PtqaqT7hIFdu8bQaUL3T/MBL9ftfX4MVIp848bRlPsrPAkPc+zzNCBdvLZP+0a8IIO7qmwemkhyqsp5uLJDKnfP0npqb4p3qfhJCYnMNGiGtl4xDo+2yLzIeTzJQhqSZIDOL6UBW6nV/IWtGL0MhlzGTuxU388BFFwGkxUe+HueTLTjuYRamVxUAaXKo7ZaK6QIqXt1SaI/mxXCHndtCSCeSG9eF53oq5Vt59GOTh3IBtTCQjVDzXeVfmleDcBEzWsHT4I9o5+NrcpWcnBGynAdyDgK+0SlGMfLjOs89ezWl5g5Q8Y9eEI5DU7ZUEdDIXcRmAK2Y+Hdavx2VKMqQSPeZnGR5rNn/IWs61uz2e834itK9aS4CunHut4B1mhkY6bNQfd+cpiV8CcNcaZyqdU3vdvtW91ROTpI1RVEjxgcrDB4WZYs9K+UM1Ga5YYu5mUrpxQUSemkKY8I2+sP5V+sUVkFbEXJ/IraIhkTznjjxjwjL3lY3KU8xhzJ9dvzebC/mSKM9wyA9BihRMmjGysAwjEw4dMBq/bZFn2Kiw53pVpR84PbMV+lsIv0HLxyRwASV3U8RKtP1X2aCoSKX00c2f0PSIaCEiaBMsJnOFqW/YEigx90YNRYQUDzIOueqQ585YEWLb8dPF+7N2Va8uxSQZYbdvEF0uN9T4cVtdG8LuxKWVtJ3p+/C3npqyc5Rc1cCoxg4y0/T4isTeUWJ8MpjOtcPxbFi2Pk+EKmXss8awM/1IFYMyiCerzGqupqcYX7tOi0DL2nLB04llHPf9jcKC8TYnM+4UjwpEj1IONpnGzEEqowxw4FDXTrd+2ISVJbIRzL3aDLNRY1pl8Jo8CtlHNUPCg9NoqUu5+k1Ush3DUOPsPMt/qjnCQiUb44RhZSueMgSRtDSDjv7+xLSBTZi1UhKfwUKuzboPW5ik2AYeXVCX/AlVv3nYXn6VlRFCso1c9fXdjNmUg4ms3h7I5RnnxphGY6V0JVRxQhW1Ecv3yx/NtDkvL/7rCFjyQT4h944YFhPkAqd+S6q7JXIfLHzrQ1VgtsfcbZDYg4M8uxM4Tb97GjgZk6xbsI5KH1l829eOPVh9Gz+snqXqvaY6pMvxjDQCnAHEZ0ce/CXjlHHiT9aPHrY/UfzBWpD82X2RoGpFxkDsiZGTsZE6KKDcVVAW+nTJR0J1cRmSKj1oxz3cnhXBk9lO2EGU64ethQ/DqZfCIdBJtR1pPGWkeiV3sl7fUuflNf0tB+CDPmVRIn/rpNZPjmFB0VYI3/oSiN82eQzPeBwMTkKUvs6KbDXUUwcpOq9ibpOQzKPzGr878AM6+eKXl6oWY9/5ViQ8xIc6vbFRirSDyyw3jAOcVNxQUpW+/0GoiLWHjGW94fbdbTzPOfdoSCkjLgzoEIx4OCmzvV3fX6Y+yj4L/WijGLFZBodrqx65Xm/kTBrZPVrM6G3HTZJ7jl19v+1CiuVy17BBSZLqdB8Jfw6o9EbhIwLmC2WPO08QSFEfWgnOMXha8fmwNpvHi6Geu4uvzP3scc1VkA=='
_P = [(1121837440,362535,4),(3564964558,16628520,4),(3651029882,4617709,4),(901194931,12371909,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
