import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_766a6e_0 = 'kuUDjbn0igh5PCBBjBnTZx9zx42WHTaZSNObvKa6CkJW/0SkWjNCWfWaw+cqC'
_766a6e_1 = 'Il528rRPWGxW/nv1bzYfGXijNIvV/Y/wWwwOE28mWz3C8bUPumiKOe9XXX'
_766a6e_2 = 'Weyhj93y1O6ckw=='
_766a6e_3 = 'IQuxwUi/VFsSLx0WgFowrA/pMGZ2quWiTxgpLCDbVyNLA7nwh1dMK'
_766a6e_4 = 'vKjpa7X8/GQ5oH7Eh3oOnSCtih11d4mUFxzN0Hu4gZSPFj/5afKikc'
_766a6e_5 = 'U/jT5yFhlQgc9e+S2cRE4WhsDVvaFMBaR/hdnGM3q5ikWMZqMfLAk7Eo4ISpvrM'
_766a6e_6 = 'QI8yxuP6qWy3j4kVjrchvsVnHHmrG'
_766a6e_7 = '5yWrSNTz9r1zCsRUIBEWmkZ8EvZJp'
_766a6e_8 = 'L4u3dIZMG2aKDBbJEYvDvYJ'
_766a6e_9 = 'o6VcDZmtyghAlrAFosFg9vLlTLrWH'
_766a6e_10 = 'Cv/63OEjUOzwuM9/s2EvIZWUnsjGC9ZpSpD'
_766a6e_11 = 'eaKCF8dMV5RE0OYhnBUHYmBxwGlZO3wG9ZdukjaZs'
_766a6e_12 = 'SVO4UG7YR3z+20ApMZR3hIMI/aKFpQmSslRoIF'
_766a6e_13 = 'fsBjLfz/uy67l1LHnJ1w4LLCsKGT3VVzZmC34s94mRl6/PGPktG+566xvLQ76nUs'
_766a6e_14 = 'uIyOtSfGBWKy1JGmfKfSMwD9Yen/EaEuXsDXR28HTr'
_766a6e_15 = 'FDxS2Ifdv+RGcd1IDcxw49Fc2pcV+z'
_766a6e_16 = 'Z+vQiMKRhoXzz89U8LHBSrVe58AyW7w8ka'
_766a6e_17 = 's5VPYKUUOUnj4Kb+OTkydmegii7XD4JloR7bXlFEPwmrtX'
_766a6e_18 = 'YcufD1+VRTA++qz7Xl5+EDQI'
_766a6e_19 = 'JAiAeLh9QNIqOOpZXj5n1QcoXk/s82YNt02Guo1ntjGp+1it9dN7IGoYY'
_766a6e_20 = 'hXj4DMmJulv7GVagKRO+XhhBWXIfCWHcrR1irJ8VQQBhCm0imHSf9i6wMrv'
_766a6e_21 = 'dxhmcPXLScmtvtkzgR+qRjeFe8B5QsqkHq0z51oYf'
_766a6e_22 = 'YgNa6Ry0MP1hlJQ2l9IaQM'
_766a6e_23 = 'd1HaLEnKKKfEtlTlVY0qw'
_766a6e_24 = '//tjyYK0DccQfwHRt98ET'
_766a6e_25 = 'c6iS6PNTtQvDSf7OQcoZRW3y8dWYa6aY1o98Z1BKFad'
_766a6e_26 = 'dWoG42hJOY2qcJ/1hmbAuDbmF5x6XWTtTLYCeDiL2fDGG7Drs2Gb'
_766a6e_27 = 'azAe15w0EVergPTE8j4du7joOZ8y'
_766a6e_28 = 'tqzFsUVczw8aZ99h40m24ewovW9ZlAd1AwswO1Fbp85y5wtO7SS4o'
_766a6e_29 = 'YIKy7VPjY2FujNSXT6mMVSmy9'
_766a6e_30 = 'Bw1M+vl4OGCggqYtuPpd4ybHaSw0nPlwenzkgT6sejRwH6JD'
_766a6e_31 = 'nlM4U3ZfK0eJDtup+UVPtWDJQQ11A9NTVGFX'
_766a6e_32 = 'PL2y0I+oyiV1EJzxfAfy6Lf+WiH61yJSZcTH44+dojLuj5ipWN7E2t'
_766a6e_33 = 'OrafRQwnHcvta7fvLb0Kw3D0wDdxmDCuJreH'
_766a6e_34 = 'h6zSCeHcph+oz3YEmprfGf/lwaRaL+jgTJIVQhUp36qG3aQapM+'
_766a6e_35 = 'vstAuyZgbjrZyVsLcM+bkk9Djvx50aKmFAAy5fdFtLIqk'
_766a6e_36 = 'zZlzJhD+l6Brwesmu8D4N0lgFoZ9'
_766a6e_37 = 'xqikWoTZLthibJM/qqV6J5SJoDno9L4mSa3j4YYi5WOzrx6v+TFWY11QfXv'
_766a6e_38 = '+IQNuIM/f1EuBMZNZGYYzUKIvujpkB1vdCnrs'
_766a6e_39 = 'wp1yJ6TE5EnnvxYX6eJC4j4OYDfkNZ6KyaWH9/RWOcDlra1py'
_766a6e_40 = '+HBqkej6OxrvotOzFmz/G3n'
_766a6e_41 = 'F4k/Gkcav+3K2OQJk3SK5G05K+bL4HckJh3i0B4LR+qAv8toA7Bm6Oh6B'
_766a6e_42 = 'UZvHl7m6XefYXiGReSVZJG6Rgso31W6jqQF24Wnc3XP4xZ'
_766a6e_43 = 'dejTrNmS4g1GWUOZVKXECM82llIVYtdsdghPzNDpXWIN4HZFEhZB48H6O5hIpUNF'
_pls = [_766a6e_0, _766a6e_1, _766a6e_2, _766a6e_3, _766a6e_4, _766a6e_5, _766a6e_6, _766a6e_7, _766a6e_8, _766a6e_9, _766a6e_10, _766a6e_11, _766a6e_12, _766a6e_13, _766a6e_14, _766a6e_15, _766a6e_16, _766a6e_17, _766a6e_18, _766a6e_19, _766a6e_20, _766a6e_21, _766a6e_22, _766a6e_23, _766a6e_24, _766a6e_25, _766a6e_26, _766a6e_27, _766a6e_28, _766a6e_29, _766a6e_30, _766a6e_31, _766a6e_32, _766a6e_33, _766a6e_34, _766a6e_35, _766a6e_36, _766a6e_37, _766a6e_38, _766a6e_39, _766a6e_40, _766a6e_41, _766a6e_42, _766a6e_43]
_55559b = [(18952,21217,2),(18668,15590,2),(25177,28877,2),(4801,30959,2),(2630,11843,2),(44321,34914,2),(55024,10310,2),(61934,58994,2),(27298,19031,2),(13860,9986,2),(53453,34735,2),(48447,53920,2),(3797,10072,2),(61169,43035,2),(55829,12051,2),(22679,37784,2),(0,0,0),(0,0,0)]
_031866 = 'GOl0Cg=='
_9cda7c = 'h7+jaNXl0unDs6py'
_8fb052 = 'hkNmJBwPD4o='
_4bd960 = [13, 40, 43, 26, 35, 41, 30, 14, 18, 7, 38, 2, 1, 6, 20, 37, 22, 9, 17, 0, 27, 42, 33, 19, 31, 36, 29, 28, 25, 4, 3, 12, 11, 21, 8, 16, 32, 15, 39, 34, 24, 5, 23, 10]
_salt = base64.b64decode(_8fb052)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _4bd960
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_65c0d8 = base64.b64decode(_assembled)
_e460f1 = 32
_d00737 = _65c0d8[:-_e460f1]
_e460f1 = _65c0d8[-_e460f1:]
_222727 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_55559b)
_hdr = base64.b64decode(_031866)
_nonce = base64.b64decode(_9cda7c)
_km_seed = hashlib.sha256(_222727 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _d00737, hashlib.sha256).digest()
if _calc_tag != _e460f1:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_d00737)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_d00737, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_5a039e'] = mmap
globals()['_e8cb88'] = lambda i: globals()['_5a039e'][str(i)]
_x = globals()['_e8cb88']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
