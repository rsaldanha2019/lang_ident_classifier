import base64,zlib,json,binascii
_B = 'cAIOPtvA+iBklqTMj99HFb2m8tmv+pA2He+PCU8uWDcNyMPgABZxsjI6luza5eR+nPAKnf1MV/4ibf+Um2leKudhOIBLDz06qheXX7R6qLFjJj+wEZFW5C+aXD8i51h7Q2K8KBwiwb3BpYvF05aORdL0zL2uEcVaT824DEgIpwKKOEHH7gwhxugyITQuStK6Ws1uCfhat4HFgmuXH4lwuuFUl889ZqVCUdE16Q36kly4U+6iqdXRi+ikhvBeSWWUyzfQayS4UhRyDtxi47npM8mBT6Wq129wOloQsYNmQ8dGvr/j9fPNVD0jbnCUgIhT020J7ZlmZ8PwI0Q0Oba7vGnoFGQfx98W7y0ydXhpzJ9EP0dj5HqbRPLxQNrzFbQmI332QB/yVhUR0tgdHbtTMrEMcU3A/FCvVoVb6aRuqR5FUUh9iri8SqINOhHhtsMSFepyX+BGXYug/oQ+QSmQD9qDZO1BxGQd0KvIRbkr/7XuNWCaHRj4842FdqXX/Q6m1wVXoF1w7rk3IWjPS66ke24V5fBFQMFSJhjsZce1tCL0oZ75xsCnz0XRPRyrYVhTyU5B/RsJt8RfPjuYdOEqbzq/JTFAynH0J62iW+6J+rALK6XoXblXo/GCU+vrdBQquIeHc7iEsEqPEHqyqfjXa4KhNYjNIRjX0Umq0/wyFSozov41RiaL9vy4NcsRbql2ch5i+kNGPowbLooL6jZ6m9P0wHOQOUJ0QcRn58YiJ+D8dUkF+rGILjmpvTM3yTE9I6Cly2SSlO9OW3M/ztq7m/boHfV9UXPs9QFcmN77Fzq7dkwit19aszASJDsMTKQ5Ae4vawUVFMvQVn/dbbcE7jZYI/GsjRLqbHtJVPdmDX0ZwC5/NotJKhfnwz/Y/FDcOICoJWziGQl33altMjDygQH6mMS2qISj9Y76EWt0q/NAYRsdrSna/jlS0zBPudsVuPVwzS/nry70U8DSUYgfbhI5YXm2BVqZRUngQW+UumVIgJtvFXdH1idcllxbfl1GCJ9JYWn8MraJSM1VFB/BOTJgrKZWAiLmtiDkldwh1gXnF5cLn/5bLq4tkrErRd8Tx8L9RtP0barEYMaFcsEx5hg5IDddj4YUZ+kw12mnAvSh7O69j5UDcdseIJa4/ykh64vARRj3S43uZ7qKKqLu6RoKb13VPUpQ9UYLVtGTso7dA/CcJipHoKIafkQU9ott/Ebn6ejmC13EAMo5pTaMvRobhpwGK4cHG9/lOcKxAgnjcPXb6nrxqZ2VcZXYdcv7lJjP9rbSuPiSYJyAWNzLsTQ4zJO5wyLUxrE2ROJinAcw67RBSu2keCZPssAf+RH+BbaAX5CEvkvdJ6Yn2zeAF+7KYTeJvFvkafFhpYg/UQZlzGdC7wbV0KtjsqEFjxJgF2+kloREQE8q0PS/8c6ejEf7pTFi4Idr1BStuXvX2p032gJPSr7BAdITtKwi0kTUxEcah73gf3FZCIdg5kArjyDRQ9fh2WwmZWy0e6A5nvNrJBEz7kEkBsvSvfSgUsNL3/8fT49tfoVBjj0GQxfCp04OCwmO7TtafBSLcMMBzfltXaZ1MKqflfXDSoYtVFJDsCbSGtSEWMag5oDoXXTl+wWvYcgHUG8NTYA/YQoWhnTGVTlfBVjRzrML/YnHxa0T885QATryYQxDcu6zCPq31bqhATyuBz+qfefv8vPqkfu38dcEAn3X6aM7ppLO5pJWjTUJJgqoYiJNkb3cx13Xtxj72E5kUN5ja2mOVmfkmAQxrD8='
_P = [(141382513,11896856,4),(3056814598,10251024,4),(1953377717,434917,4),(2016559509,2676892,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
