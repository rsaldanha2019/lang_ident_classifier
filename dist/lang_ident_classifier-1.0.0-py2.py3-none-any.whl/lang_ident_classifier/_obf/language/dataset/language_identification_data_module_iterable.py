import base64,zlib,json,binascii
_B = 'OYaFZ/+lngUT8SEzVZ7GE6eN8IjXN6EY/ExJt/HCBbji22YP79vvLrLBL15OZKcjtAE+EiASyWPY5YMhwcRGTU9ACtbpmOpjdKm+QAW0UFgtsK4QMdoLSKAIrFXUrOY+sO3usOs2D9yInSVG+e+tmCY8fJjyTZOtK6YAmCW93AetsdP8GWKkGX73c/lCVU8ybHivLy2OcFuJl9PXA4ttbpeLPmW/nAlxYsA4S9nuJ3zKUIYyTbX9/o2UULQxB3ljC43kJV2PL+QFoj6d7pGDfNhdS04/uGF1OKgC3xqLsSw1jGOO12jKV6t4BCLYc/I158L4HHiaOBKz5ahSIoYo6uGGVo9D0zaBD49lOz3FJh91wAk8UmocIeha/FY0xQluSbwfuq+2EHx6Sn/mVv+99WW9k2tmHuSk+ixugeVFLoYKGVCgc1sDHOy2VZPwYBXEsEqPX16POibYmn4+G/KWyVnjXw/xYEpSBHFNRseWTlyzkq8bfiP9OpqvnUcTMub84GaYwHF/BRgYHI/PWaymIPvqgZtP8axSMc92jOr2PSt6jnwq/A4a+Pp9l8JgKD1fgKWy53cSAQtsGWktrqj72/ZGm6Ck7DOJc0khn4NvMABzPRL/xau9HX9jyyiduoeGm7JgTE/1Trqj1YTmDdOrssvaFv9QpriL/abc2sAm20+RNQlJrT4F/R7m3ZRGB7F4Aw9VMHBMzHGxXzrpSktSr09/tSCEee7RqdbDiM5gnYdDt54N0GxVDZrLWVkuYJXwNcZY3074HkhLY3B9LCvxQgGd6dXQXBr8EQFnoXozvQClf0LpqLycZX8pKSa1Jndd0+sfStfHeTfZV5eavTWOkmxai+0tXZiV4qXCicH/U4q4dCLw0ycdnm77tmLxaPZNsfMhW316CQttzNCqwUe+EOjZi0s/RIHiL6aImtuj1c16jjaX5x2nCuOi67061apx8i0xA/7dBQB5XKFa2qSWmwyTh1kU8A3uW6YXr14aQks5Z71PTngPVElqz9x9kK7sXp5SbZE+o2b0wB0GDoWyhOsLep9z7Zarb6EulCGnPC9+Ezw3pfjEPWs3Rwz1cXs1VX9XnXm0Qib2oUKSflmVuQ3vdPydtZl++FZdpiw/UkPjF7Dk8pQSCcU1JRyaoTrG36RAACPNfQRdmOjjrj/nfNhaRFjJFceJuocPaCkVrkxveE64x6HZN7CjFo85o4EN4l66DNr/ZhOlceRp0F9+82gWRh+5OcZ6lwupUlP3FTa5NPk6eZD0blbiwD4OeQP2gwqSvEDS3GHlOMg7dF6feeOSoG2I/zav2ig7VRT/b0bWjSAEwJpq7BEI8Iy0SRC4g1Y+RdlbNesYpQ0HJjnMy3ifNXnvKhzaanJkIvg/Vm3t4lLe/vZwvVFLPpT3byJWHqPr51XDS+b+XHTiO99gwJsgrITqtQQSNVpVas1nHm/oVlfNecYQ+a+srCuyQW5DZ5AbEiEt2V4Luisb/Qypm52SsGdulrO1Tp7FOqmJbgefdRjlhFcd6CFbc20yEqbMf/ktWrzHRvhOqHm5R8lnlWC2pF5FmY7MxFZ30R9kBUmwTqZAmBuGAQLIAwn5hvTLWqcYCC0tAudfqsiynevCcCgL6UGDyH4o1N+Favcl/Cl4dHU23tn4rm2JZvYCURYcixz1pN739uGaAGbGQQr6u0o/cbaEW5znzauCFGpKscVbXyDHtrnI1WwVLslj2WF7CnalIH8uMjWwWjoieWzoZW0xRShIrTj1/AUc2AITjOyeOKQ='
_P = [(3949462278,6088027,4),(2273695399,5691302,4),(2977275901,13441912,4),(4052501018,6483362,4),(1714902079,10660655,4),(3993641688,15355585,4),(3190218610,10236999,4),(959844112,5500404,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
