import base64,zlib,json,binascii
_b = 'BlQwT3jJImSyvpdPbNITds42UcESBWhpAgQ0CxURtCgrxRJI8Jp5LJ/qql/e0P0B4G69INthLHLOJfZaQsmquh6O+C2dfcso83zSahgBQNmuIhq4LOhzTQUzqpQxTiv58D+Uiz4RNsHyy8G0+sxD77V2j2D5Co5l8DQ1nU1NMV0AKbnlqtsv9gOLD9KXhwWf6yn9t3IDP/wIB5Gyy8MmR/cwI4FX9onPuej39TxBpoqOYA2j+g/yLm4qbsztQnjfMQN1pVZOJyGaNDCV9BsUT8w9nB5AbOJT38XIFO2A6IzYYsU1exKQF3lg5JClAwVVvVzhgor8YiHF0eJV7Xr6bPcOUZJu8VgygMnnGZjouInECasSqQ9TjovDZxQkRQ8F86xheCcAT/ljo2SWtJs3Wqyh/rzYItQSVk3Wma5MdMOZPyza4C6Q58/gTW6f+l6kYBqtW4j7iIDT2I7/g4VOU9Ah9QsVjkbz6C8oDmb1LNHydab0moY3txCzDV15KpR2Ym2mZgpIBWfjUDphxieIxbBJrhSlvbY4ydPTKFcDp4QpEPQzuCTC13rwocAlDIRxQc0fyBWovHY6xH1Yu3i+cqFKbsXuyZjgnsO+W3OROVHeN4EdXFQC/SMGfBsTcoaDu8Ha5lpm/QqtFtZU6yConJZYRALQ87xkCF3tSusp/ie/umA0HNA0NoG5dUfXcv86bJkKMYFCk8tSgKAIU8EYNdx+p6mAtH0GEA8u+UvHZWC0pNFBo/kGKYyNT/TszrB4SWEof0Z1pNFCU939sgqVRinvhFGxuGQMnbuphVxG/DWnVsvpAuC5laE9iK8yqSpNwGeUCowZAnm6ll4f49TPBFZvwz5nbEoEoF3esaMDNddhuzzYZ15MdJc6rT/LZM+mmNUC+Q2nN5sSzvltH9KwvoaimPneMwv+j7i/QVKh1C+5l0FW4bTdgoztzyrub0wRxnMAeFg7/s3vQtaFgXBPNDw4ids+KBgiQ4bQ/YS7GoHuEmyfaIQwflx2Ty8JgTQqfwY5O2MhZKw1G5hBecUeh75eibC7JK8eZZt5umbHzo8iPlFbTT3m/MTs+KSj6mE43ANk7E1P7ojmxiQChewNuKA9EPDwvPRm4gOF070PXpaaIWevx+V5wQKssNDCfX0WKjy8ykiNaKG/ac6jjhCypL3uPtmBxBeBbitgJu6qRErbYrwapo7soM/nDyJsJuKnCSneBcmgSRZ9xDfqaba7dyWilQJifF+blGWXzecE0+BgCxGQdYe/zA8PfHu1p1nZN2Y4btvlvE/8RCtw6jG2tj+pFEirnob/ziCbODzstTK1eaCpvbEA36wWOSwZOCxpj/z+TZs8TVKywnNEYqGMmV4vKc+HTquCXjaD4hw41db9rxM4TSAFs2FAeVN1dGCYhIe2c8nGyxZ7hqlWG+Zf/IAkjpYbh4juiRHIZaEJUYHNSaIsyJJpuYU5AheGylJKYaQTio46esK9s8HCmOYOsniEYpEBkvZlSFvZs7ZnnZWIF7TLvcj4RKMIX6dt6GNwi/X2EPQRCCBnOUkb2PDCRUQOfWdOriAATmBueh3J6kfm6QgN3M5dhrVCK3B5EVV5GlApqmm6mfnHRpSAYlqoYPQQBWFDO4Xrqxw5k0P/+gZ2EtyPz/tdLT9ezQf3Yn5DPQaZnsDYGxibLJVzpX5qJ11ekWNDMtYuDRbdHLXOdd9shp8wA7bt30Q+Ij3MwAznwy+ifiUaRKvAFM8zoqrOMLG7E+/Ly91XO6vk0DUVAuIivas='
_p = [(1864031512,4026089,4),(4224069659,13540558,4),(3293954434,12999710,4),(2148155296,13903781,4),(233076266,3604137,4),(3809022130,13605947,4),(442177318,9028943,4),(1694822960,9367016,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
