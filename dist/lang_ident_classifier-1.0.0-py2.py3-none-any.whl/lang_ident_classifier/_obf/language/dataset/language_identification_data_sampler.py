import base64,zlib,json,binascii
_b = 'wUZUTaR0v6xIZgDaevJqUImvy3+c51QJ8aBnVcLKilcSteomKLihxck/UPnE3rZvPbO0Aptp2L0H+TYVPGu+PlBgoyaXi/0Oe22XSI1hTf2X+ELtV3HHos/lgtqhsFPk7ivhsqW68CjFEQ/84Rnr/RkO2er5NwLYah9Raf3V4wWA1Ul6h4wXFRMX8z2v0+hhdDqmDZ60CUfeNVeffXiz4jjCKM3x+OovPUwGwHkpyQTCpCZ9hE/fTrseo3LaFlVDTh3pJpWTCesWPMk1OmTRo22eujJVGVOgUtcpbCJcKbIjPHecLgsUHmKPz6YG7sOeubihkXYdU3xgfEeJe+NA2LHH01IVkQFFz5lDY8ghu7uJfgnYKWhhpA66eyl4QGWlNwMM34p551MjlU8F92WK+bgrRCOLmRYmrH9QvOz5INmseRe9S5Z4ltQ/mPBGTg0N6L3igF0jqdw9yVTDzS2WRVizTOvHc1ncKVulG9FybNalAu3IP96AhHrpPDDZEld63v/MhSiec4liyZ2efadjEyCdgizRUbccvKMXcuGI5ipCEPW4d6zIPILg1Na9+dcvvcpYGXT1FW7zMe+zdmqT+LFFz/viWBw/fh6agcnKjStRUGzrOgbZty0w1hmEV3syRtLPn1Cuh4+7lssBrJBGCoUT0Hkgu2emK9R/KyenN4bjEzoQ6Y8eLFDZdLFpkBb7oIjD0YxTBRg/HDDyqR66FR0bkdVxSrwvGUZ5fawkTp2hBNr5zyocNCuihgGIrjnWb+MgA+xo+xnNbRmr2INjwHR6spKrmoCC/KOWWE96ThM5sx8qMnVosWJ0BNAal1UTTburOuaC0u1C8MfzI9J8'
_p = [(961721642,700513,4),(3835418711,4119787,4),(1970019847,12227160,4),(1312155322,3626247,4),(3795106370,9282948,4),(1003479822,16437029,4),(994352909,8630420,4),(4018395510,1706539,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
