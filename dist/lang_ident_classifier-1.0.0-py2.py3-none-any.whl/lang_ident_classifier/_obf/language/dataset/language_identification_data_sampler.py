import base64,zlib,json,binascii
_B = '6GRNLatZi0oxXLI0uBe/7eZcjDBfY/oQyABCJ/muhPBeHDVB5Ar6N8zetti7CsF+PpFwngVryRPRO201ef7ECrbnXmHDgwvG98XUtNaDrqW9F1ogX0hFZ7y2DTJUnlJpuuaGsvTAu+CQz983StnzpkOOpuhQjpx9YXrgtUU+T+Zjm4S0etS5/E0csfTyWcnqTrEcVK1iFYncwMn6ah/ZLDSBaDhTIITDgJ50D067RLDWs7WnAVembSCL2oevPgqCLT5awApQzbbo98lRTqxLTnJzmPmb5fACAmGenSBt/iQdUjfZpWPdjYcPKPpOri1C+Y7p64WJe1Ipf8tBYvWtCwAcAryJI6OyVKMvw0ojq8P89awnAumOJzOBN22Ux9kNzj3fRYGBslP2lGS5JrsJsor7STa3eFGXOQR4weOaj5MowDBdq3H+eS96orwhRmcWCkFFKXXcDNfOZSV0BtRUPFdm6TpIuCTTvj2UDiQD+zaygrbn+A19++QuROZi5VOYsYZTJMRdSWY0Zr+nJMts/llK/jKbAvlJ6ARYEhEvyLMRXbTmiN0jB73JQqKeZAiziH89yM4HDWAa2mcRNcG5sWt9ulmq1ZLktP264TRYuIQhHxUndPRAy0UdpIrdk+yjqy/NmS1a4tKUeGR6m2noZIg3gwZ3DQf610Aph4NCl1xn6n53KthINQe/4KHW9B8us8GypEbG51yuwGBPnGP7+L3GR63bvU4Qmu4GUvZmQqxJM9i7nn3YypjAcCbPrmf6oErRMZwjU4MHfOp10Nr6wD+ydSGRkiLD2v1vzVgNA8/aRzM41qIsjobQyh3FY955xd62XIm4miQHzmb8mOGo5A=='
_P = [(2422040981,14916076,4),(3873866796,3200070,4),(559187459,16064511,4),(2681523402,2042121,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
