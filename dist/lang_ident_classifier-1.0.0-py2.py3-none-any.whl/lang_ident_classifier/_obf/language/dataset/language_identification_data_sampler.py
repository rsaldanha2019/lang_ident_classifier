import base64,zlib,json,binascii
_B = 'SV2Qt4SeWD1yssCvgr2zSLn7VEK0OaempGKnRjNFUJDDWG/r7qR9KeLAFwKT9cmj0DUVPPye+1CvLFFBK2HgmoL3So2gwSQGSpaP+qs7cct2XbPtHznvKK/rcZltU54HlX13z+w5reJqXCQMJlZigXRLTNeeL/ED8gimYMTrROvru/R4wOdPyo6e67uljcl1ZVw9XFtVdVol76DE+KOaIudwe4F1wxah0/urhRO6GFFkvG1sDKZdNhER/0HZXDJ2T9cvpIgT9wwJpd5P4wEo18tiUGXxqOv2JuVGG/8xaIcBatkk8eiX36mFxDAayy/MwLy0JVXSETVJQUp5w0FmcotprIiwQc0QNGVc0NcXiMtVqhNYFJ0n9dHlwKay4B7mpYxpPqlzjS4rdxrCxaVUWaauzAgsf5JvTjj168CaC9SfGueNUiQ9VixJBqHfBneMhBhK6eLvGz78/yRo+zDYvxbhdsJECHZALdiUbwYJJmfRw2iMBXjybMp1xULlhHE63gOnMKx6XLwb7joxFwjd1yIWriDcf0wB6q4G1uqoX1rzSceZTO+aeIuWX8WAFritzXWSNLVu2Wyj1pxXnmqwRYk++qDG9r0cvA/2XAfsjQdxiAVQ4Mi8w1n4NqqfImBORkPTxnrCfxa1EzbPzViY8sTKOkObHcRBD9jg6g5Ic6U/yICxBUfPy6TOeGABRGiyE64xI376LEj582rMQnRmueNL1/xpF9X9VlDV+19yZ7qbt0BXp9d2b5s37KMwx9OqJeedC/UeTElrx5McJR91gaBleCwQYgKKAeBGT3xLMX6Dq0IRjKLJAVk6J3NfHZiMEXvrInx/XIAC7J1GUsSm0A=='
_P = [(429967850,14243264,4),(134575168,14152481,4),(2511409463,3933585,4),(3360292765,15877955,4),(1721654049,14673193,4),(3201667001,10411532,4),(3986782863,8144429,4),(4201302109,5219681,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
