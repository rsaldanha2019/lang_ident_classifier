import base64,zlib,json,binascii
_B = 'ZRaiIFdXqkCc4b/iaMk8JSe6bQKpfg2hwcZPxKlF2OfN7hJluxDw3B5kF5oeVs/ulmrjdiOWDGgphe2V0ZSKLblQWyk9y7gKftuZxb5wBVj6m1vJo8aC/mnZ4Vi2B4lNttHqCb39FULVZFGNtAXBqG9amBhin0ef4CtrGBSonPCA1Kdlf2UYM8Z2m30MlAJjbrRcAk+OmiHvmaBVr+ZLmPpN4cP+QtJOpotAfhu8DapIMqUjSccEFClrVj7EveMj0WdQiKMuuxZf+dJ3EaZIKPIaAAGlFw5GUOFqAIEK56+oRUomUfj4oKdfPPLN9FoszFzddotrmgy/3c5Gsj5Mi8gv+6ox6xkWBLbuO8vHX3MJTOmdEE7w0urK1ro6N474jW+X5AP6LhDi+SVhv4bXxWeMNF48SnE35tYMNpI5Qva9xNQP1xH1+GAtouBhSUYIBKue4sqfO0D5fz0YS506rGvS44CXyfMcFUxWALCp1uq7yOQXoqVT8YBg3Pe6eJRhT7CdPuGdSEzJPW30BWEkaGOeHoY5wC5666cOZXllhMpPpDTrNA+Je05xgdbXVF2nLzYz874DuOsYTFGgfFvdZk8wvC8IuguYHCCyZaCMND4mnyz7YuIC47FLztQlS8XiAPQFD2bn8GszGxik+VktRj9A/5b4ZJupa+HDqggHydY5smK/OeiBTV7ompb4ghI4XCQgxwZycP18lE0TnEqSfGhotJ0QQhXAv8P00GvVFYfzYxjLXGkYehO9avYZVUlUtggwVpdTtXAoGzG8gGevsqYCaeRjgvyqsP6OkI5qF64+oXUmSYqv3r9GQzpYz4ovJGchc/dqFU8KO7hJJGv8ayNCYyNRONcdftQbTaAAc2X5va4TYcWZjj0EeOVWL9Jw+RJKFj5EeeUCm8pW5fAEhv5BGnIy+U8a50fNTLTE77OFWynZvhco8wkCdEughz3gM0dU+MwoohVm3h/fZQlk8spWC1MZU2HcaO7mvuEiXBf5Tluk1WHwMT5sF+Y1WT91Mu868Yd2wahWEXzYj0xwwKyIni+6gsYQJkc6m73Epaxi1jDJotrrurbQYRi/mbumszRet8LyZjnvmhC8k1teHxv3SO3u2aHwZrJy3NVa7O4tMKfQGlnXHFMNyYu6Y0ohMdHDRej400jnrfkB6I17d6tx2dnZa4U20p650yvHQnXONHnb3NLRT1ugMBaDCJ/bxrGOvhY3G/MJ8RIA3rHRyMXI0PN4pY+xen5c2EIEcDIrLJ99K9CzG2p/fSSQSTC8ahcWIMEY3D5G4I8/rXKYNi4yFQdOAm5m9WWCy5m9G1E9BJiAZoiLtnu0ZVNJ/lU/Z6Pxss/ZXvnhbez2qWJ7Qfg9CO9Pp29PYpqC4g39sLoBPYRVAUe+f42rEClIP6l10ictNvXYR4X3polfUfXzKsxoKNrSv0hk/ZCi7Vk0A2UIDZ5tDndJ4E3dXDofvZ9CEoGWytbkcY7baSMQHiZ+LvHOkugBDQiDg5s8FSM='
_P = [(491331511,8743105,4),(451207004,14462500,4),(2361934618,13948796,4),(3919997699,7144901,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
