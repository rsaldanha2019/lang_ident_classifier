import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_8a993e_0 = 'JgOQNicNYPXLxYtHN67Ug3JjfD0BNdj2SLrRLGredqNNurialU'
_8a993e_1 = 'OB+eLz7qYj2yWGVaBYLYrLDUbTRQGvxstPgj7+BRr2KzJfDnt'
_8a993e_2 = 'fkuVAfQModon8rqhw8uMLvW5tz2siBaoMOMvOxNW4H6xx0bVFiGGyy'
_8a993e_3 = '7AODq/TN6oLIrSpumnhwCOk8+0YWxe75zlKLRxJ768MloMazHMGdMo'
_8a993e_4 = 'SCSqlZ/wvZw7SPLwyyMlrSt2T5nPbkm4iM3yi'
_8a993e_5 = 'jOZkeP37txumxLKH7sVjn32ofsvxHrPq2bwU6AJuDNt251aAZg0ewzwytIc'
_8a993e_6 = '4f3PM5f7KwViZTEe0y+Q9dLrQq0/go6A=='
_8a993e_7 = 'V0j8AIRGlpvdQ3EIKrk2jaFSdEyROdlR8TtE9KjNDO7lZrADpm75GgVt'
_8a993e_8 = 'YRHUU+YGuhuwgrcxlJfDM'
_8a993e_9 = '7N24dRtpj/aPAvvIsnXvvkG10XQ1chM483'
_8a993e_10 = 'dgEDMxv2zc/7lsHetX49wgnkYmAi3XJUJEK2'
_8a993e_11 = 'RUmX0mfY58JNXqxNA4tTeV+Z6F0q6Yldv3r+35/jRoMcIS'
_8a993e_12 = 'BdkCB2wANoA9wF85/IdPGt1qlmLOlj+'
_8a993e_13 = '1ufH9CjmT3N9Cd5cx23pzbDObB'
_8a993e_14 = 'AwpDmEFZ+Gj16ApG2PoGTwrpLYQxv6tKa1Pv5H6'
_8a993e_15 = '3VRV7BulbNdUFbC55S2WweH5fPtz/A/AeiTRmoOT4fwynLGtBf4r1yF'
_8a993e_16 = 'aljoXtlJnUAQ7I4ykl9Wx1TpJoxTJTTVfY9msGYSHbi2DyUjwPZ7iE'
_8a993e_17 = '24Nwc7BLm7LMKnsSqSmiuaZGqH4OQGZ8OL7m8JtnZd1QMgvQ0c'
_8a993e_18 = 'tlTozvhEW3Ed75zx1mCqzNDzcRYcRjwWexFPbIj'
_8a993e_19 = '6eBjU3Jz+PwcTWX1SyPwRljnvT2fine+rJ2u7IfhPQ'
_8a993e_20 = '4PW4ylOrb5mrk3e0q0ccf'
_8a993e_21 = 'f72E8/UkbdaRMN4wFVVpVgFUFopkWXPCU2Qgjbgvsp+'
_8a993e_22 = '7LoBKA53qoKtVZ65xnNeQ+r9DjOKGKlnTxdz0q'
_8a993e_23 = '2AmhMQCUSJS2IcZLibFf68Sf2ZKV2c8AL34gm2igk8'
_8a993e_24 = '+G1SYtHpJOFjP/moarSC2sZkPkCN/'
_8a993e_25 = 'mKe5WIaEmxb+deoA7IkDwFjiPIy'
_8a993e_26 = 'urviCrwacVeT3jcQfaSpLwJbNngHrap6fonmdRoGYOp4WQ'
_8a993e_27 = 'w0p7AiPCJXvRsNghXpxhTalGpMMILdOy9fTGwq'
_8a993e_28 = 'Sw9LOPSyig/z8aQ1kppvcN5UKZg'
_8a993e_29 = 'igKz12Nm9hSiHaf3evistYMxMVi78KFaK16PlQO4A6O6xWFu8SYz4Amt'
_8a993e_30 = 'Eud2roZqPdE9ld1gbaMLhaHZuRzMhYWK1TwQXbT5J80t9YPT3JMmNQi2Pwrs24/'
_8a993e_31 = 'm/+8r2rlCFi6lPTW8ceV0ncdpM3t+9R805BL'
_8a993e_32 = 'bOoS+UBxHPD3r3u8lEInxLBYfiEIHS/mr5W'
_8a993e_33 = 'KN6l7scdWef5gWex+rDbLFeTthn+N4vANrkhxrRcFTrrHgth31qx+XGTKP'
_8a993e_34 = 'qZqgWtMsoyHGH8MAosqpRSvPUU0AVU2rHICWA'
_8a993e_35 = 'K4cEsYRanrYvdjaEzw23gow6eHUao4MeUMWrA7BD0DLVPjHsbAXARx'
_pls = [_8a993e_0, _8a993e_1, _8a993e_2, _8a993e_3, _8a993e_4, _8a993e_5, _8a993e_6, _8a993e_7, _8a993e_8, _8a993e_9, _8a993e_10, _8a993e_11, _8a993e_12, _8a993e_13, _8a993e_14, _8a993e_15, _8a993e_16, _8a993e_17, _8a993e_18, _8a993e_19, _8a993e_20, _8a993e_21, _8a993e_22, _8a993e_23, _8a993e_24, _8a993e_25, _8a993e_26, _8a993e_27, _8a993e_28, _8a993e_29, _8a993e_30, _8a993e_31, _8a993e_32, _8a993e_33, _8a993e_34, _8a993e_35]
_5be7f2 = [(15653,41950,2),(60771,28767,2),(20640,11444,2),(25774,61430,2),(23401,40627,2),(20235,39440,2),(19321,1728,2),(43150,14432,2),(28006,46054,2),(14531,46028,2),(49131,10337,2),(48945,51155,2),(15405,59736,2),(55573,29042,2),(60817,30955,2),(43791,6820,2),(0,0,0),(0,0,0)]
_d9a956 = 'nvudPA=='
_286e17 = 'YJHl/p1LkKWtNRY6'
_86a94e = 'SgPFXIkaZ04='
_efdf87 = [30, 24, 34, 20, 17, 7, 35, 3, 22, 16, 32, 11, 1, 28, 5, 33, 15, 13, 9, 26, 8, 2, 21, 12, 6, 23, 27, 0, 19, 29, 10, 31, 25, 18, 4, 14]
_salt = base64.b64decode(_86a94e)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _efdf87
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_2c34ba = base64.b64decode(_assembled)
_acc734 = 32
_c907f1 = _2c34ba[:-_acc734]
_acc734 = _2c34ba[-_acc734:]
_3f75d3 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_5be7f2)
_hdr = base64.b64decode(_d9a956)
_nonce = base64.b64decode(_286e17)
_km_seed = hashlib.sha256(_3f75d3 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _c907f1, hashlib.sha256).digest()
if _calc_tag != _acc734:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_c907f1)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_c907f1, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_8c5c27'] = mmap
globals()['_6c8ea5'] = lambda i: globals()['_8c5c27'][str(i)]
_x = globals()['_6c8ea5']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
