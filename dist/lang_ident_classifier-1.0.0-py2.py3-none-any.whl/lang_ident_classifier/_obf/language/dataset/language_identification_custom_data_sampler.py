import base64,zlib,json,binascii
_b = '1jyP2n89aoKYdCRrPYm0x1LU5U6l4YAnL+e4xrmKRdQYmlXN1BoKj7Ddra+rMGqpUVMRWNj3xL3K89Bp4xMtmq6rSA4yVuxMN1IrJX3Wcke5QIV3fEiygYtU4Gm1obYPnWUw14JHtmArnJwYp/oUnKLwFCv+5hzpnxSM6GVihIwZIz+J8Ilg1CXbolJHTro9c54ASjs/rJWxGARv9qetU/jS7ZSuttnFJaZ8+dkCwlfQ+ZkaH1+iR7OxvioQeuT4uwO+xdKw2IFPGnp5DZ6fVHiSHipC0PdpTg/H3BElcP2KpodZwBP9VIW+qRHBhNlyHus4MwzJ7QBOTpL9cK6jab8XJBgLGvCgEf39e7fFZP9AIPlka2IwhnEuPP0dnELPKKNnV8mxw/6aCt4DDMjRqn3iB6TMeHDBx5AZWpkHxXtsMTQdH/AE2w9WZgJ8KLCr57UxdQV0dPJIptwfRIA1kzuDFOUfToSj10ea/jD2Lh7Kxbn5CZfndGyunH9qtYPSnS8f5zGxSwZguwUKBaP2COqu81hdzFyUm8vnetm9/pzhzQbKZ/imV5m7RytqbtMHQvWfSSjSZ2NLrpZPhWczBfTyyBj3wN9AM27A/0CbP8L/G7i1ZtuVI+nSWDFtZ2UJmTHID06kA5A7/bs9KvC4x9BMkir3Xp2iFp3bwjFUOKP5MARzZQh0c8Kys4mZjvFDwxsCACj2RP19JPMgtPg81vuhX/RiJDW+3IoAkaA69Cp5o9tmDS4KK8Z7A/QSeHVC1tcppzZXOkoajxwvgOKsbp7/MtuRK43YpCBDEMryOzms+JxbRI5rQHt3rx5pzUDOVLq4l1ftcimI52LRJNXLxoiMjS4MW1/az8uFgMxbiYETyN++wyjvvzFGi27oFRI8vt4+ojeVqJzLZNpLJQvTOxLlxDBMFA2a49IpJkY4jNYDO2DF5iQKhocslAJK1vdyVLeRoC1/qYeerkY24AJZC8U1zjgrNm9VYwnBMB2m62OOvsHsYCLo/ZBN5oZhmZ8mD4zY1SeQE+zy3WqGBkXYXwarCWOBFIM/HUgTuyhvDV1mqan3D46DBoKn2MrBmq5tj36STMnSZARoZhO+XYdbZAO8wt9nsgza5uUv9YX0+niXzvJsYHxMw3d3y9ngo96x9wGNv8i5y2XiRCwGcW0Xo6XF8XlSdgrcbFEUZ9swJ3UM0Nhk2UolkYZpHM0Ffb94Ux0qXMe3NgCwDu7RZpZir91qIEIjJ5BTL0BuTnQbvKFhsiGMvqm2fZwJrpDv1iB1GrgAYWAP9LGfF8SaqBxuy8w9At/ODLlPSAHeWq//FB9s/8kzC3aCWcFIbBmTDpP5nUFr5vRJgxgfg/YIxrPnx5i89YdRc6P0ipsoj9FU+S6NGK/zkuFeuK3khfTX9I4/Z7XukQaBbw8scbQYI7luEXcvjQ9abNPtNT0vBH+PIA1Mj5hNKQ3bghAYPWguPLMeLL90FlopIoMG6jR83EG0uy1H5sbtZschDRCttw=='
_p = [(2134226528,1503211,4),(4053255674,11133458,4),(2665845194,14476170,4),(2552829842,7436686,4),(1952477789,11846706,4),(3762992167,5396710,4),(3777252974,10410810,4),(2278213763,1386199,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
