import base64,zlib,json,binascii
_B = 'RJcUzM7pup1NmUZmsOwyYgPvG9zkBPGvFRUFYUYvjo1JniQey0WBghyvlRBk6CbHfcC90qlP1u0pBIghZXHQTOzHrt9M8A7WxErYWKyl5jBScjWF/RvPQXwmF1qmK1IVXTMD1h6ga6rQ4c50e9tK+OoeCMwCx4cKxTj6FnjxP5k6o1eJzX2pmpYGowjIkZD1aBeg1YzRj4ibZUS072J4/NIWgMGUyMywLvCzDPOnEbtkFBwI3Hx3V2u8n1DB+CyBb/Cl29xw5k2Rvc/qzmRPgk6weyk/eBOWotTgATZc8LAgGaBx2rlxr4qlxi1hO9fiEW8U/y+oj8e/GBZqCl772g0fXKZOetlyNwKjkwdFqDV6vOWlyPerWFHNYihgBxZ25nsnH0bLg+K17GgmbhMjRH5DQBstfSOHE1hGBaVlqQzA/0BPwfvmqkbZDKAvBTghZD98HAmxMiiWbTk6X/HXKBPMxodAFxZRJsdThuZoM4DjD+rh9+QXUzjZk4hi2d3ROJxyZX18vZabakzdMGX8Vbdm0wjky4V0phpBId3/HTZPg1HSBNgYCz7imM+KjrJWqI4WNxKSScLgqsxpUt8ZEVrqQOseE4+otsEv1pjClx5qPdXmNzGMm+8FwNvfILao1ftUVb5BjzoPYZ/RjjqoqG6Bbc4fa6jLhKABRAnWyi9S6l2nIc49yxHnjlgT+Pu3ITbmbAn8XyvioDyriXpQhk8ZGpf19oEo3tWTBhicx96uVDkJ5MrD974CqhVAgtW4xeNAUGkdYVn6PtPGK35eydKlioKIGjT6AeDIwCRk7gM678lfA4WzGUS52fW00bTo/VC6y+eWsZGXHXCgVV4sg2g9gCgFfx8UVCWONLnR4jcTYuxYWccrkfTuw7mBPsxBGI6NhVmMzJihhkKU9RORi2NtRmEcI3iJS+fur1tUAiMXygnhjg4ewaImhL5uX8tcsGX1s+lcCQUlFK/522zlmXRzyVm5ZvIyzwxcg5ukPyH8nZo0IU1eQVs5F4y+65+AU6AfgVJKgF8U3nLoI7xV9dg+6NwijqtEl2onGqsjdM3csrqPxEwnTONO/qHTiwqepLus/DUgQREK4bwTaoiGSbZi/I/ynlg6LocpU9ATJgXTbbGRe0CddHLCzs3Xlkcgt1EvdrsxQn27+NjIOcMO+EjJYPx7d65CYvl1y8K47WAeSe7hTh3lkBZUFH4BVkqK6KCFVgwkVxBlQnE4upuX4daktXK6s8/ye9HCj871kE3nz0pzooCSCMrp6UAoQU9Wqh/lWa9ixAco5s4WRj6CBXaIevhQUGJ3KtFCRBxlHO9dqEF1qMjNr7xnrIikN+Jfj8FIjSlfToO5SYuas3bmsnP1gbtqptBot2T4hqsY1pGLta86NXzBhO5r7QBlxgS5nfZYiWsq1lf/+Lms+/5J65EjRmPYBzgayG2xrwaOYWRMRA2+6oJ6AJc5RUABlH/Rc1NL7vG7Nae+wad9JuwjBcoeSE6Nu0N8w7lc4SU='
_P = [(3377644726,10307773,4),(1491968522,5069545,4),(30607836,8133747,4),(757357039,1676487,4),(3197381587,4318252,4),(361592430,15623981,4),(1366883522,10010451,4),(3616320919,7501063,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
