import base64,zlib,json,binascii
_b = 'JbEfBn3T5/dxx/xUtsxRsgIMhA6VneaIrFbqFkyyBsLhyAnPIWQzaXPiBRDePlJDOPQjynPQ8m9l5tfaQ1OMQtr9yXaDLBh6aTTr8OTmASQ3X6awR26atnorcKbZT5QJENen/kw8f4+tqk4u+lKT14OAM8vcWN8NjkZ+ahSGRgZ93ynKfc8lTqMfv4EVC5NwEM+Q2Ge4lYPVTrSwDA4QB8qWntbyXI1VlUp0Uv8Eey3ijyUX3Qio4/QHmZpoVrY16CQ8sVElbRwV0IBPJKjlkG7cxk3KjS4tMqSCzGSwYPFulMYfpgAuV6LQQJRLwE7jrTmoTQp3j1DW6E5u/IWy4mycypgWLiVXuokCJLiew3iorSu+pGCmifLNQNsmFYmIk59CL4uJcpup9eOp23m+WmykQURs6oZiREvAdLXML2xte4yqE2Ug1V+RK2hgj+Vr1DHWOAKwMEyy/H6lVEqndda/i6zsUc2mh3XpR6brFjr51CkeCSbLUetC3AJoSc/aKBCphRC2Dm/iv7jDmkaEXGoI0gIwt8E8fP6cwgIWOeHuKIYN1o9TSdXZ5JXz7w9Q0NDUB4hhCqHgsdiQmk/ZpzF9Acp881Sukz/e+E2IAU1lUd3Tb3ugUUA3lZkUHHZ165/HQORAJ6eAX/Pu28qA7Cq0PTmddNtrD8+qIOfq7lnd7sr+b9O9mlCqe1QPbHIqgUn9UMMTrjSRn2mkm1KXfyRrA9MFR9PS2SmyPUXJN5VMMb8ony4Bn8M9hqChjJFEbGUII6E/bLvR/8S5iAiGjwMlED89FNGvs/wu/CbIxM6uMx8pk5LJ0HSmnqX7zyfnN9uTMOLksUQKPWDxsIpQfT7r2lmeZrYt1II8m3NN4SmWaF3QyVAJ3whZpdnxDQ88BrjYtpD7kHG8n4vgz8VaBlygIV1G0WKyfizNnfj2Ktx+hh9VX5+DR3nrt2wy2qpCLpWd5eGCu/q2vaicGIjxdSulgijrc74DaUPp/b/NSL25bDFhBpDjDqNN2xTgVGjjmuTQeTHNCINt2IvuFjRld1WO9vi8dh5s+2uYKHRUCVTokk8IiXpCbAW0ObvwoThc2ACnl3wjrey1yG46x7Jybpw3ZcknrJhdkgRBdLiUZFnNcL7y9dZZECymC1oJNSgl4Fe19Sld/uUK7mYGdScwrYD6IWqTy2R/GDdjSDYZWrAxerOZ3AmJ3YKvG+0XYz9QbLx41qDyaTGU/miLfiqVa/2NRwlTTuNXoVPNU3pRv4rzEht9sMLt+EqyOzpwQb/INVf9dlzWGEPDons0UPLeLdIOrPfPy0v7UC0m4fjZ+yE3t+eg1k0p8dnL6hJmeXOeU5g5I1zq2lYYsoid8JFb'
_p = [(1677105384,2793638,4),(3592639736,823730,4),(1152338356,7515222,4),(3171466333,9856367,4),(3528977714,14118908,4),(1294685957,1091437,4),(3556864224,1056488,4),(377438044,6766265,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
