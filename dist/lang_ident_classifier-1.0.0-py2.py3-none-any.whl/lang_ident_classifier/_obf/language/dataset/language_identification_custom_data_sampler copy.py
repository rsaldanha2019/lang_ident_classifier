import base64,zlib,json,binascii
_B = 'MvzqjZ0SJReuc5OykfXaCEZoSkAydAayfnO9nDSl2+SSjXYWKqXMKJK3P/DTFbBhZ9Ch8WrIjBATP6E1ugCz6gN5m8w+rFKkU89w6USweiO/SOVKodv1oB03g0XsNqImmwddzqNAo5Hco+D1dXrHwcFXP6Udljo8dBKL8FkayMoRSVnOd7oyETlnvKrB2ScXt8YMFHPEHn1bBflAoqfZAxenI9GMVFjHeo2mv4qYcqwNlOGvgHd0/1zvfsmhDFWBwVgTtyLaslcZe0vQpG6rrBJGVV9FzehF9OKJdRtYxR4zSieLtTY4yMtPBHTv00qx91/ZtKwfrJEFReHu1nkoa3lkOoLCioNAenAdeEPim7PuA6O7UR8ipRrwrP5zxF8r4/JMPN6YZXesCbijLoCuTRPCyJbqeVDEaTRfqTwoSnLQ0qF29fBMAEJUGSp076D3YjQf21hL2j8K84m8BrWglGl5SQtyT4J5uElw9OeNXLkD5WDKx27jmcNIMfu4ALKUv617ZWab0kE2QZOYkVrQMJ+mwzkAfcO0Blw2Q817pkac1nIgFqbpheTsvpQ5CYPZjPM81NjWwi2g6nDyiU6tRHjHfrfTjvBtZxCub+O+ShtrHcFqeUb3URCsy7u5g25JpRPqAj4euKsZP06XnHyeTzEr4nPNn9FUE1XDBPGPSs9GxvO9MQMFM413E+MB6AL9eR9yx2XOOacrcKrRgVTKcoPYArim+sFSduqv1TRF33UutdcJDEN0SN0AONE3Q6/xp2T7uiEi/QoxCehW1xatcWaKeqsfyClWOZC4ElmmJUjpIdc7zJpdmRWDqR8GgGqaYjMyASWY2uMhcXQgxeqoBkrRSDGYULIrJnadkJuI9It+OuAH45pGxf/ZTbaJYeyoBWV6CskB67lWqAiHu+PxaFx2P3s0U+NcUIdjWCJ/Bd41yKofF51e7tzy8H3SBeuFMY13aSPA1l+LikkYJRUPjBbG/IPYa7WxM9usDz3wVXoTmmk/YcRuUWZjwoBdH5M9to6jRu56eAtyVR4o8qJRh+apqKjtLIIGDLM8fF781PTY0lHbEVsOfAxrMfC4k6SU0X1wAEj+nkCbJtsjqPN1CxfeAHFlFieqIemKMKAAbkKIVWyvuzQXuU16vLmdsdHbBS14q+XBfD4azm48Qpq+4S0a9u/u/mDa2LXvI8VB6U14Y7Eg9gtICv54ktXbm1Z7GWzF82pGe6xMthaXFCMi/+Cud8XaC6HbdO0NYyoY8CJ+2pmNYWDnO/DksGSJAT1oF6iZQU1ias1NAlyYufScrNKZru9feNf5dqWsusDBUisD3qYZdckRwsYhA2d/9oX47b+qCZ/wLLER0kl3SDLo'
_P = [(2694961537,13534096,4),(492836342,5044649,4),(4289358452,5099896,4),(643538289,5886374,4),(2773085100,3904091,4),(2206499795,10170893,4),(1262260177,3953083,4),(2350389812,1998932,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
