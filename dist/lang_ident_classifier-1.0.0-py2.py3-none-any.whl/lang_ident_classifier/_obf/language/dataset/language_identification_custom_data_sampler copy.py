import base64,zlib,json,binascii
_B = '9rDk3KXHyQasuFw44wVBEqbYhfwCCsSS9SM/vwNdgmHO+b3H6gsuotLWT4NUWhpzI+26/L/sNxAcOUa13hqCSM9/RdXtjfI2J5JdBf2VBa3c/EeCoOGgYyIoe4BgluQuv0f0wA7u4hY7SJAaMeXENevYYxgjEOg5Ht4pa4/7E11auYxN4ri4YgqLfxHpzsTDRU5wLCk1hkCxhdx9xUOKNbvLzTIIlAZRTN3lyLyH/6Iua+4hyP8sZWDZvqicnBL29kB81xtSkgXkrdEYIJWP22zAOMaDTHQiOfAPxRXenDLZP55HQYa3xSYu6oISMcSd9oL+FiXaoobDzKnJrNjXPFG1VjGVW1LPVdaPX+C+C8T9rC8Lfde4KtlkWUMU9gFENG66CZtxqOM2jZ0tMMa6zshlez3kwA7bk1M499cncFedP2qceAPJQeSYWh+GLkLJN0Oj2l34BKAVwi8cImAT8gRrJksUXnEdYYdYgw46/4Knsj+XhfPGjtjkpO0v1WVlvIY7qjzceXCtiFmpNMM2n7eYSEnYdSl0N+80gcF+ZZlCH6h1rvXKk9gkzRBWOobBRtvJ9V+zbCPGvhjiyII2iCuLPPE+A3xRSV1vK5eCxkVTt1n/DA/Sg+7HX2DfgZnP2TGVdTMn4Vk2a4ON0beOhtgcS+hRmVr4V2O/M3aCx/QqnUQd52xlK6C4JxAkxfuh1sS/pOmj4SYzh9M4WGtembHMHwsQluuAHmMuyoRX/3pqJiQgFR/jjQYYWF/XD/bht7KlxEK9ZrYGAZjO4J6TH89TFKjpCq0sgtEP/eqPJl8IaDFaXMevOTkvyIjgEKtB7/iv6uFve0WoPmfIctmqBAg/U7wp75fsIOlnehs7i8B42DoyVPumrg64cZ7sKscyomXfxjbK+rPjPWRFB4omcBA5cvzl2cetn0doO73VxX5i6jMaaKIKgVXcGTUsPeA0OK3eZ3KgVwzunlK3uLw/tLXMlzH1os16eqVfh8RKc654nz6ZqOwSw4gyKTGXfm//KJYS61asjftltdwzBTSkYCNTZG644tnLOcvPP07ebwcUk4l+E+DRZ3Z9sPwK7lrzhufzpfJ/BksMBe5Ec9lhZaxSTlsi1By+ZOtwRdfW/TU+Nq6h2GjgQIPvR+fUxKpNfhN8hX1M27XNoy29o2xLhNPK+j5AB1i+Bt6+kXPPkzXT5X+l6+ZMcMj8FX1ydAHe/8m7xQwdfSE8otDczK6mv0L0pPlQ/rYdWiSVR3gIN9fMVeRMm8o9zomah9xf18CfZvmgI7k21ZXvYtQNvwqiQxYDvM44jT0v27jJjbj2uQAopuopHjQ+fp+7vuJ4v1eyzcj44acEUSkEuERGQs3a'
_P = [(2394433796,13762702,4),(1856310752,796624,4),(3088538474,5378576,4),(2742199937,7794278,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
