import base64,zlib,json,binascii
_b = '/Qyd3smIIgzyhCGQcvCERPU51RMdwQ/6Gm6O5fC9T+WpwyOZHPHLid0HN1uaHQdIg9RtrEorJxgcrXSv5VF3Gl/pmie+N4xEbBF8ZZGkfyMllogCni/8uskxU+Wmh5R/lalnC4T8QpEAgGCpGZmKm3JY6yyhnz6z4gr4KgKhLI26wCId1TdvTNq40OKnI2QyNs04W10hmylAa+VKI5LXPeGzsDHZn2qba2btOEox0YMHig4ek6VJFh4hN+Ww/Uw1REsb+Zi+piSCzbaxssmXzYD9niV6Ob6cPlNHYXp0KqITzQbkB1erllSG1qtNI5OkF0E7xHYp447607ojX1Ex6EtuuB1x0yVU/aslKl7BNHgMNjntqqCA8KKA7hMgaB6ZQOIJcfYfry5BgM7p6F2q/ouRCY40HDqj6FjzZ9K6n0mI+ZwQvBpNq7fD5DdzMj9DA28X05KEBaW2UA8pBTslS2OR25EZvXF99SSalsGK0uzFk7qtCRvNsCF+ba1l/nCU5MBhhaUHHqVi++U1FKY7uKAqilsOCtSeo8EO04Gkb8yXKyT1Y+hhwQVUDcMeI2+DEZbgifGK38zSzst2ChbszZ8pmRyWF8IvBgRjdDGD+fpJ0u5KhaeqgfehgxTNBOX89qSU2fRV5zwke9/UKohOEMW2ePnHbC9adq4UJgrRBchapx0zJvGvlbDrJ+wcvjMVr12MmzDcIaKd1xTEtwx5yG00LGns1cZt2PKTcG09RYlQjzdYIXT2C+mukRfSeCl3chos6rHM6mWFkOA/WsFvnbd5HHi5wsqUJu/gnNRGiOQgqY7xcmLj7JLF+Mu6Eat3IFT3gVxlvaz3SwquqCkt3qBwDP+Omit44V0ouYvVORdowUWTsWrxoainHc/F0I+V8mLivvVg4N1nZqHhIsS18qe6x9lzflUpRyYJZe1GfXo9crT+l+rplz+uxPvB/LW7XjfRjx51UgsNBd3KJaM5ZhllOUijS4ACuaZepfpvOTMpMUBfIJ05wrPJuVpIAMgvT0VLw6XAOGJbQp2ty1gTzKcZTI27RfRc7N9J5H2ASlNxnHmHc6+jvq319qGnTtFCIN94h7axpYm+ybBr9nz2S51zETWyDYJ2HnXDynE2pvNFJUeq7CmnDLKW7YC2L+jZKbyrdqETQ3RyPKhjBrhkhHB6UUYXu9BQVbL6Y3Wre1dNnK65E19f8/ulB0M2kK4K15OE8iHscS6OdmyEm/vQVaDkfxJaPyt/QU/RcT1+sujXMcFUY3z3OApperD5P1qxPFOq1vhLCYRmaVCw1+YnQGS3UQCO2I60BO4iue7wuUhLDIbXeI3nQuF29HSzDqjawvZW0oYFGDLHxEdUoiLlcyFKsi4ov4UiXP0o+FqDyJNVeRtnQwq3NRExJ+kmdVMZxWaXFr4xybviyvsYv48LWOwpbJ1eav04pMyHn0QdCzwqUsNZWL4p9oZ+cG8xbzncwk+d2G7NkMtCMv5+3a8gWfwPp0WDyAOZf4y21Yw6gk+5DEfzuOq4FihbXR+FxPA78/Wh/sTDp1TyZHdWp7hcZyJ+h+0ik2iTz3/YM8jOi5QFQmNfWmbch97zfcv/gT2YMbcgQQ2kSFb5SRZJO9zyyYqPDXqgiGkm8byov1BPB5dEmxgBowv00yizkd5ohBe3ui7M4qJ3tG6qL8Tq2aErbbOEZgGLma9318vpYnwEUKK9PbWDP3QmKbBcrIjAVqNvA40tUIRZnAwkD5pSN/Gq51/mDzvjPS+krrIwbeef4OX37Rwrn4SJ4k4KcT28wJwFoKPMWuLoMSViUqjdIAxlF/FEShfPzL6L4fGLx5I5U2MEZtLtb/1tODgKZSLkVL17RTBPC83YUQ4LetTu5+6rC4XzzKAU0uyzJAaIVGSrgUmjcPVC0M3igmF5H4cch6FoKfdnUGFOtGWz3Vaw4GDw9BLZo2mdqqKabYrOCLnmif7pGuirhv4ZqclDzY6F2JZ+vETrujpFrqH+ZpXoFcRFQYN9IYxxxbj6ZbZStrPxKmq+96gFamYmb4Bmac03KjxyY16k+vNQYSV/gINFzt/ehrcbMCpIYClOJBinx1ceuAllSKg1ncmZ8/rf7+fFMfBmlCTJYt7j4cjjqsYe8cScYkyCYWWyeAu+VmRSWKOc5x4f+vF1mrooyUPkTZ1pj+LibONiKe25HoAoQ1KgJx3WiYEtSvp/8q6lm9tQVkqaQFBbVSunKXerA8T4NjRM9xWYs5Cn9ou2KtDqocBFwD8tVtVIkws4wR8M9MyNxUtMSBgTYcDSccOJ4f5jAl3boB+4OYXxhERORol0nLbLIZa8aBSl5iwEGWFWJ6XtRbMA4WrWom7bvbREjjdqRmr3tXzkREquWCx5vXnB//zpyZg3k6RXWbOp6SLM62Gi4y3KWSgiehuD1kalX4Fria4Y54PX6srF989jFYoFOycqtq7xXQ6bCTYomXdQWnWtoqn30EF1R8vlyLXe32m0NSNtwFE5uqTLewArST94bZgyeSLPNI/sZM95zYIH7y/lCVx7vJR0qvBExnZJojYDduiCQgIPx4QaV+DQUFarKVj5klYmawloB1hJYzdXDyJo6JMKJG1B0PVN+Mc7Rhdp'
_p = [(3871432590,3912450,4),(1196289950,484862,4),(275705230,6525546,4),(2628073397,9137001,4),(1310463074,11955680,4),(2980248688,715777,4),(3115703894,7485882,4),(2460158305,1107837,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
