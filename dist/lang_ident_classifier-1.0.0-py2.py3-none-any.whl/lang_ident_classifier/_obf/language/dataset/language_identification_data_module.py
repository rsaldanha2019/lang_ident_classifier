import base64,zlib,json,binascii
_B = 'g/lEd+DQwSRYXjf5MEim+9AHToKmHibzG9vW9+FxSmN6t1LyWsXf5M7NxlCd8ljeZQpiQFWOyUbROjL4zbF0oMiUfH7cJG4Ou17zuMmeJn6NINMnP1gregbBW+8qBL8/Kfz6I7iPaC+y454xdAdNyYQlM6hnAeeo0Wr1yBB0B4rSE6+b47l35PeoqoA7OWThORBS67StKdlqePYvEgetuvAyW45e3vMkuNWTQFL4b5vvJLu8XONs99eKGP9sVaWWnvTIBY9lWFgIuRZhO6S3vC2tJN3fiegL0HW4RKYAFbVJfXn/GJMiLuedRUg2/j4Uc2HCb2BnQc0NpN1HC2gc0rDiDWVRPmfoHzXSw/6wctDfSOKHOjyZ865RKUfU1dLnksYc9VIOn6PGW3inVWTxYkZVbMnBuubQExsoO4NILv1cRgkh4Bbna9h47eC8Rekc1ID4enYOOrl0vXjYikRtALI19oGqjIznFysYJHB3qHmDEEP5AxlrZWk1j9Azjpn3DWwOMnDybHy2y4qH43GTdD7Is3I7qqgypyugTGQdDheVOMIsjCqcBmZZW6UjH3eKgaKu96YT4rVDbkA/0sxaUm63auGblNEAIbGHuhqQRZzft/IedbLgQ7+BIdn00HOcbjU2n4SBlBGAjPlVLDo+M15Cy78N27yRtHejGhaQS3YCTDR/pJyrc8ue4rBOCVNOeJpG77JMxusCmue+enk8XopWH9jORupSF5hJ6JFcf3prxAdCl8MNuLmJZbBkVVlDOAoaUKYmS0Ot7pnyqfWM3F1izW+su9Ef2snLEiYxvtOBJ2OMCuOCwepDCGxGKQN+dxWzSHJdxfSa/kKKlTHRo10U95NJsafecgYYMs3OBSxfqpU8px/Afq2hr4tIXWy+wtOHw4qMvuakr3mommW7vTULPSZus206JbT5kT5t1crMwfBNvW89ox4aBwkhYMe06tr/SpNBd0Kc1l3AYoz14F2ghPGixyPEVNdi8Wc+MZtG51r5JCaQWRy5gKKbwqhPfzkFEkidTR+QQ4nt/iz0dHTlU3FePXp1U1BXDOrqs5TOyvtwCpCwRwW2uSntpUUxzR1ilE23MlA39Ghs0MM+1mFBSBL+PZLDnuKcDEfIv+gnG6igRLlU7LUbEOqZGAMeX2rrNzNW46UOs9QGe7FiTh6o8RRaa0pgq4HgWKvPpEtg3nU21EmEiGwuFtAZRdAAfdOHQNTdw0NOP7WiIEnpZLRHbsT2L+63fQVNlhRNhvgGs4OKYrexm3iaH3zG5WWY+em+Ld1N/CK9E9ejTJZH1TVzJvatDTFrfvpR1C7+YlNXZnmYHVG0INB0wX0ElTiNDMOGL+zgUl+xocpMVhPYspWCsVzfWm+UMoKqAFeuKHefJfclhFLCDVTNoug/sZNK8bIP+6SDfQoW52XOVK4w0S+MPiNqLguRL12rqdPPhbfCVO5n/OQESNjShuuDfl56p07iEaeKXc17Uhic8GWi//eT+nsVQI4TJufUcoXwGKb8n0aqrFg0rG1/fLpAA7qUPL4egwlSuMPKCRk/6KbyBNIGiv3WrlNCKp8kZ8w62iW4dtG2gdA5p4rCQoAUFEjiVKtjzT5V9tTA+chg0Ky2pMsV1TcEHjh+5E8dssolOVRDdXvurN22vWvnNQd+0qx1ex4Wz5Ef/287H5ffnZQcyB1PVeKvDfAVDFzdXVNGapIxB24CRxqaZXfV8ahjf7SmsFrO28Lw/HoluBiyQ1guWHE/aVvGW14aSkUzSY+hFr3wUcKUut+ytdlv9mKDJZ0ckQQv91MJog/4X1wqOkwCIy19oNpgyQEgWGb+NyskXOmKhwV6nbwxYOyMfXu8WIoejAIxUIfELpaSAcKqei7nCjAMRus11OkI7dNBxSKYNh9/2T/nWsCs3PgGCLMwxaAXafdmYzBBUTR2muwRTyMlfbDgdGqJBwraQMY3oL1aSTwR99sU+cbiRwQQh+PG1s47KWzlsFrhG3o1nHDMRTTOdZdVcwQcVekYBzXZ6bh1kTciGHDAtQVaD9DoeThNM20OmVNpUpTj1zqj8imJWrPTHwiSClV6ohq4H1uc8RmtyFHMkW9lHNck+aGrWikmMJ0zuQvn+KUH+iOQV3TUSnfJ5mR14Fqskh2F7bYsvWtRpZsgReay3jTteEWcycop7sRE7W0rd2KOFs4WlOgKDg7nDz0gbVQ02tKcYJ4a9ZRg5h+2VmFYzab8M+QtYp7bfl8ZgncGIWHyvczEMmisBINlxfcHwfj1Lq6hkUH3ByGMxuJXj6KufNMZrWJe8vYnuBp18VAz4SOpM8yEtf76U4rrYPeObdaWvgSiyTjJrIs0F7eDdUG0+f1ZuI5VBuRvHF4gPEabM6U8d0/gS/IS3Tt9df9v7MdC3b8Y7nSgaDMGWI8a1Chc6KvSQpgLztUfoYLHnjRdB3lqjxiNfbn08w8BzXzMdhaSTLiqBkXOxh9P1kHQCEYYdT7a/PFBP1wBixDwy8CkcM1I66xZAl2gyoIxBmw/Mf5WcnoqPuc9u4/cKm0F94PjyvADyrvSVg1UdAu/S9m1BxufUVUPlPb3G9eZfaP67Rg5YcUHVJCHC+LPqEqDCQTptJi5ibxvHQ=='
_P = [(3253797150,3778492,4),(3109594425,8515776,4),(3593708821,4047223,4),(1938241273,13778630,4),(3719894899,10962612,4),(4108724253,16719086,4),(1598124431,1285212,4),(3292148717,3806119,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
