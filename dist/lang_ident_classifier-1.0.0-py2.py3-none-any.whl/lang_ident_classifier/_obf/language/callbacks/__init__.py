import base64,zlib,json,binascii
_b = 'zDQ4IiDfBgIR8KKLtBY8eawpAnNp9eEXRw=='
_p = [(3957280746,7704814,4),(3897109557,5767263,4),(99330731,10210755,4),(2095187576,11253534,4),(878615102,1446273,4),(2597859802,4033012,4),(1491348460,6176391,4),(2343088644,1256918,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
