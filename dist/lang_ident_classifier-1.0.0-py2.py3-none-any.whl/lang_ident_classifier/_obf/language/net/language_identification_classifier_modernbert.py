import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_8cd07a_0 = 'ghdK/qcxWR3ui5dMan9jsjFX37kjA5clZYyc8XRKDLIGfaNmV7WK4iD/Oq'
_8cd07a_1 = 'VMPx4YYV241enfGE5mC83uXwCZ5hnXQK'
_8cd07a_2 = 'OesavgXOhJl+pz9j7PH52d53IzvkUBiYYS9PCekU'
_8cd07a_3 = 'BueOa4WOhlO1RPsHwJz1LBzrGQL'
_8cd07a_4 = 'ib5rwgfj7L4PmAk/svnEwU/bTJDmm6EEeOk/3Dz4ITs0Y3ZEcBNLB3tAHeOe'
_8cd07a_5 = 'aOUYqzR1/hQcNa4VNVo/LC2FbKHOZlSSIQ6IWBCVGbUX74'
_8cd07a_6 = 'CEy7gFqO2qgM01EiS8Yu4RUfiy0qg999O4qaZ56IvTbLU'
_8cd07a_7 = 'wwDIQ+oMRHqmhvsD9dhKNokLU7a3a7JjVvog8XlpZZoGSl+kwcosenspIQc5QSwT'
_8cd07a_8 = 'd/KhNTD1jZtN7EQLMmLLKt5bTiKswcuakGTvE0HVnE++Bofq/H3PpTFMJ'
_8cd07a_9 = 'Gfc2Xbyc4eNgMIV4zeY6IuKxb0cCr85WlmyC9fGu/unxZl1l7X'
_8cd07a_10 = 'TlagUpkWake+6hS6ISf5RDpxRKU1ykyMBxVrW'
_8cd07a_11 = 'iL383VqiVPJJxLpP5jhHXvBwnfDN3lCF9AuC91'
_8cd07a_12 = '7oVTEwJAgLX+GNGpOraLRUpxjT0EexfZd2VDKne3CV0AA0H'
_8cd07a_13 = 'BAQVcMbpOSU73EFDKi4+5RcVQVeYiOd7vk19hAeeC9BeYidOieMTF/SSCbbTYyLA'
_8cd07a_14 = 'rh1r6DlsHdE4BIQAKxbjWzg=='
_8cd07a_15 = 'Rdul7uSMXytOKpZfRqXpU7DWEpXVPZVCZyfZ3z7epv/l'
_8cd07a_16 = 'GMDdORMixEWNTrOfQWLekPIkKHAjUDyQrG8D2lA4CUAAfNFWAlsr4J7+9NYlGU'
_8cd07a_17 = '5bAX1aQxnxZooDdGUlfgNIgubpT9sCBhs7Q2Dqnwa4FgB0kWe2IAt0tl'
_8cd07a_18 = 'Ks3YxecDbskpReXiOFb5KkMlwvEH/zdGjStkd'
_8cd07a_19 = 'DhqKGoV8G5K5GKnJvEuQK8AfvcR+cWZ0gve1LvkO8'
_8cd07a_20 = 'XV4KQH2fGmXykFF/vJIJN4'
_8cd07a_21 = 'ke2Ro1a6KzJNw9NGjtycAgeMVRLqlMrbnGbgFyO2m3gpoj6eIF41eDz1N+oOFSHF'
_8cd07a_22 = 'ojaXorH9XnUb3fVCO7h31Hzf5xema'
_8cd07a_23 = 'VGvsnRiFaCyfuHS6rGdGFGxIkUTBqTF+9'
_8cd07a_24 = 'RR630tHkxR3gk391u/pWPU+K/uv2EwCcv'
_8cd07a_25 = 'mUJjkmqSRcWF0fZ3hHEVqIhaKt5'
_8cd07a_26 = '8/XP/1Yd/kcNH9sOcbj8'
_8cd07a_27 = 'FOmVdWD6Pn8lsHWPdsq2kFmwTZ/'
_8cd07a_28 = 'oNuOcoqmY1DBelWD+BGfy51BoapWZvXKa9N9t8IcsAfzvrzpCP2t+D'
_8cd07a_29 = 'E17bdS9ozTIj01t6kwyZ/l2'
_8cd07a_30 = 'LEEuKrVUPLYN3XeZiN4aN6yryMjKKsHs2'
_8cd07a_31 = '28XN8adsBrsVFtg/0xUPF8VtVmS9b1e9D0OLeGdq7kmADSIrmxzfWaW'
_8cd07a_32 = 'fGnuaIp92M31FhX8ArrCN+KLcD1h0ZVsgWFPx6CA1B3OU'
_8cd07a_33 = 'X9w+hZRIhPJwTCoQvEWIRpVLCBo6flezsDQJGhtx4ZobcHOxK7sz+l'
_8cd07a_34 = 'n9l6LNUxPsp2kZTLrvWfPrUAX9DgN3M3M1HEMatXH9nT1UnhWDMVVAM5Az3CwIg'
_8cd07a_35 = '0K8BYwaNgOmQJIloOfofprhAHmNcdyqkgSyCCSxoNoe6XV6wPj+DS'
_8cd07a_36 = 'Vp1lKVTHhiV3+8u+vTZEHVMcfbRwwP8llYr'
_8cd07a_37 = 'TQP5rvo3JQ6P7YZ0rFXFzswNgbv2Exw293iDfkqDFCm6+'
_8cd07a_38 = '5nfkb2e6afNalynxhykIxnJTAFKQWXQOkv2zwVUTiuM8YfVju4w'
_8cd07a_39 = 'hFoyv44/ZmIIMyINv5k+LC'
_8cd07a_40 = 'WDMaOhbkq9I4nyA8YTrssuXH7ImOVgLsq9Pc9ueqK1omUwk'
_8cd07a_41 = '7aLt5dp3fDMiwQisV6r613mas0ANiuH6'
_8cd07a_42 = 'igwUIWRFZQkiEvTIczoDIeHfUQVRQMd9I572mfBiWH8/8v4FYz+c+OL8Urm'
_8cd07a_43 = 'nM8W+yiNkXwcT1jt5FJBy07j8K6Do0KLFy93QPg5'
_8cd07a_44 = 'Ais2Fpnygvob2VjceZtXoj/FfwH6cl'
_8cd07a_45 = 'sHF9TeLMSne7jop6jlbVBBet'
_8cd07a_46 = 'CGaC7G9/Uc3GAHYOsitoXHl+bwJKG30W1D1/BHYm00S'
_8cd07a_47 = 'DUwAFj2Y7HvdP1KJof3v7J1SHrliYt7JmKAZu'
_8cd07a_48 = 'P5q7J/KM4N12u5C+aaWRHQZHy8S069iUYSjo8j9xfDaaLFrkWsHkkbI'
_8cd07a_49 = 'liBE+6vyWADpTnLZ79okxyIpbyz1d6n4eHI9W3tABCX1Ls1VyEAzyHaQabH0PlH'
_8cd07a_50 = 'DhrUTJJp9kXbQBjMcZ0xHZLi37P4TH/e5V/b92c1xRrM4FjOf12F17FY+QQ2G'
_8cd07a_51 = 'SgCH8Tmx5IrSpo613nFTF'
_8cd07a_52 = 'GxxwTB7cPr25t0q7mQSEkNeg'
_8cd07a_53 = 'saW4/KpQmW4xpHcDHUn3rIEN/9'
_8cd07a_54 = 'xxK6iPZLE+WrMyP0E/ZBD3IyV1ak1o5TFemuQ2mxGslcQFZmXjI'
_8cd07a_55 = 'AK8rq5bv7Tl+9gBLvK63yz3BbdBEPsUdMxsCMr'
_8cd07a_56 = 'mATVrOQY5tR92Wx6xPQKz17'
_8cd07a_57 = 'nJCEuZEtwtOpAdujOnEM'
_8cd07a_58 = 'OI27uCh9iJE0PMlm+l3N+scBIIUJoNJk9H5apbNpscONFGyFCFnMCY+A'
_8cd07a_59 = 'Is0vHl7PP8+2H9BekqOfVIZ0yqYrGkGwKC'
_8cd07a_60 = 'bB2BcifC4tnnjEB8dKi9ujrXeXs'
_8cd07a_61 = 'WSaJNo8N065GYtNWURQBpEVE'
_8cd07a_62 = 'r5qqLGyacGvEYZsmrMW84LP0T0VJvzjOGSWxXq1g4V/MRp+'
_8cd07a_63 = 'wes/u1ogrycrEICPnjisKw8'
_8cd07a_64 = 'Clj/rM1eFoKtUaqRj7ypkOgMekD9qzOZUamQK0n+i3UNvO+PLCtlhIrNhz7Ohp'
_8cd07a_65 = '5+jZXUSas9jXnGzaZ/wFWg+7Ww1hyViZ'
_8cd07a_66 = 'T+agBuMQYuQbW6dV0OdaupOO0Jme29qXcbKwwg0jAZQ/xGQd7z1PLGEvg7'
_8cd07a_67 = 'ZgRaeqhTOh9qwAGGCLI9XqAXUuuX8/SdZ3E4jervBjItt/JOZ4Oz7Ye5ahjmEjy'
_8cd07a_68 = 'Svg7lg95aHK79l923as4Yic'
_8cd07a_69 = 'XbDe4K9CcCsqmcLmsF0lQFDfQZJSzEJ'
_8cd07a_70 = 'EaM8ZLn92crWDaSZHfxPSrWDVtrXNDcylT3iG/UrdrlCwJN1SjKKkYIlFg'
_8cd07a_71 = '8fo97Q0GIvfJpLNhKHiKOMXGMYoKYfE/aq2GWVS8X+L5jzte9M'
_8cd07a_72 = 'chZQdHuekD7xDMYvby5FYg46vwYLMXbtbj7lA4y0pX'
_8cd07a_73 = 'BpcGA6v0CBeaHVZkSY5+xf/zjAJd/cdX'
_8cd07a_74 = 'Mv3SjlopEwDfx3IdvSFhriSMApD0F2a8DN0UlFx4H'
_8cd07a_75 = 'vlvZq3IXMoE+0W/6CaTgr9hzcPTE+TOFdSPDA5tYEA78k38JI'
_8cd07a_76 = '9Ri7iH8P5zrtazehiqOC0EcUbqpBBfXVvHf'
_8cd07a_77 = 'pziZtCgXXkJXlYobIUYiqJlH'
_8cd07a_78 = 'IqHRiZF/F2aiiR2ylE97sHtzNkhNFK8rqh'
_8cd07a_79 = 'SjKybWtRnyUJle4rWf1E1QyU3Q36rSnBA5PTyVl33FYJ3Q2y3WXAmPawsDtW'
_8cd07a_80 = 'hKC4eaRT2HU/wKeP+kCsRORuIEP5Lp/UAz8TkTY6jDfzZui6T2I'
_8cd07a_81 = 'ooBmceV7XYfLhbqaWU44EG9B4GhFhavCxTiko+5Zq+Yy3P'
_8cd07a_82 = 'QvbKJw5AgKcYz+jZ8j0UPdwzJ1w+72wpQPVh0vb+lMkK'
_8cd07a_83 = 'jlb0XLEP9IwPvln4yE5xX1dPdxGUeNVWo0Cx3UEG/8pEx8/sNrZu5vIkxM1'
_8cd07a_84 = 'uSbPdhbZ2xgSA+HyWQWeuOfaNVPHOZ+fDKLtu/i4nMSVDEQO46lY9f2qyJnWDP'
_8cd07a_85 = 'O+/KwAmGVwWYHzbuN2wTVPTY4'
_8cd07a_86 = 'GtkEm23bNhXumnmeUiQbi2ujh4lQ8uq2h8l2ACclnlJkzC9b2RhEcNzWB1zZAoRj'
_8cd07a_87 = 'WGQt9MpDsp8zry7mf/IJTm4WOF'
_8cd07a_88 = 'HWyFrBAWkTHLNYvvSQvi/'
_8cd07a_89 = 'vQegwHhlUF4Ar3I78KP2zsnvBSV8EfmpoFZepTb+4I'
_8cd07a_90 = 'kh4hxtHG0y0v9FAv64ZgAEgyLJkdr9pJSIzGZ07abc2m2j'
_8cd07a_91 = 'J7+uJEsG8dO/ajBlcFExPgUZ5vNdZEEfL'
_8cd07a_92 = 'wUOWZ54CiwG/R0ZR7lYcOjd10vgJ'
_8cd07a_93 = 'I2ourHJ8Rka/jGBc1w7gkidNChuDeVtbiVzdS9w0tlzoSO2NLrPDCnn4TD68TKq'
_8cd07a_94 = '4jhXK00szztLTvfyUS+m'
_8cd07a_95 = 'bHf8vNZ72khdOLDGeIQniYlh+OlMXDl7P3DIIlSNC4S1+Y6'
_8cd07a_96 = 'IjLCZJS+lZCdBGDutIKWSdiQzsrHsbU55xH'
_8cd07a_97 = 'lJpc9IBu2X2o0DS5xCdl7pNo8mSriny9a9xI'
_8cd07a_98 = 'qwpHcgzogXGc02iE4Q+HJLhGH2NsWmLROve6mfwoJYfKBzO'
_8cd07a_99 = 'H1TtBgeVMuhVMRKE0YuyOdArM8bRBnoBoGYCsNFGnxiHKACc'
_8cd07a_100 = 'O82GysEE5xnYl8xQuWtusv'
_8cd07a_101 = 'ijTtodRWqy+jE3yfkfb3HGWbJTfBSTSKhfMTsOaO9+sucHYW80YmLbPKFzxpo'
_8cd07a_102 = '9mePkvZdsjNw6hkoGZrmLZUHJmcukBgVqNCChuEHNzWX1'
_8cd07a_103 = 'R6FAtERwxd1wdj9ldIwNBOycPteDZ0/v20VR11yhwVN2jbzDO2NA2m7iiYNXujef'
_8cd07a_104 = '8/waUDVZTKfb98Op2eYUgzASl8YqsPPRo77FaLDN7MyPS8'
_8cd07a_105 = 'bDw4B1EJwRbKsrkMIBvNbITqCIeV9BROAum'
_8cd07a_106 = '+dOLXe0ZkbQBGE1Le+OIaar'
_8cd07a_107 = 'XNMfkgOuQ1necniEx27SIaSI0/N06'
_8cd07a_108 = '7+uojV+7FGYtLYX2/3Za2DOqAmZoiFQjPDJtJnjXqp4VJ++v0Zgf'
_8cd07a_109 = '0UZKYOcjQG6DXDUpsu8ljuYhhmSaMtS/7NggDiCimyWyA3r77/3YBf'
_8cd07a_110 = 'iGSlH5e1XFRSYpjLAwh5L7vvR3INORJw5LsJpfl4XXbgBJMhV'
_8cd07a_111 = 'dD/XpUrURxVg2LGgNpwduzHOa1iF+21xTEBPrQDDzm/6N/dEHaJ'
_8cd07a_112 = 'k8fGoJ9BzEql+LkKF2JxNm/FGayEugq+S32Ro'
_pls = [_8cd07a_0, _8cd07a_1, _8cd07a_2, _8cd07a_3, _8cd07a_4, _8cd07a_5, _8cd07a_6, _8cd07a_7, _8cd07a_8, _8cd07a_9, _8cd07a_10, _8cd07a_11, _8cd07a_12, _8cd07a_13, _8cd07a_14, _8cd07a_15, _8cd07a_16, _8cd07a_17, _8cd07a_18, _8cd07a_19, _8cd07a_20, _8cd07a_21, _8cd07a_22, _8cd07a_23, _8cd07a_24, _8cd07a_25, _8cd07a_26, _8cd07a_27, _8cd07a_28, _8cd07a_29, _8cd07a_30, _8cd07a_31, _8cd07a_32, _8cd07a_33, _8cd07a_34, _8cd07a_35, _8cd07a_36, _8cd07a_37, _8cd07a_38, _8cd07a_39, _8cd07a_40, _8cd07a_41, _8cd07a_42, _8cd07a_43, _8cd07a_44, _8cd07a_45, _8cd07a_46, _8cd07a_47, _8cd07a_48, _8cd07a_49, _8cd07a_50, _8cd07a_51, _8cd07a_52, _8cd07a_53, _8cd07a_54, _8cd07a_55, _8cd07a_56, _8cd07a_57, _8cd07a_58, _8cd07a_59, _8cd07a_60, _8cd07a_61, _8cd07a_62, _8cd07a_63, _8cd07a_64, _8cd07a_65, _8cd07a_66, _8cd07a_67, _8cd07a_68, _8cd07a_69, _8cd07a_70, _8cd07a_71, _8cd07a_72, _8cd07a_73, _8cd07a_74, _8cd07a_75, _8cd07a_76, _8cd07a_77, _8cd07a_78, _8cd07a_79, _8cd07a_80, _8cd07a_81, _8cd07a_82, _8cd07a_83, _8cd07a_84, _8cd07a_85, _8cd07a_86, _8cd07a_87, _8cd07a_88, _8cd07a_89, _8cd07a_90, _8cd07a_91, _8cd07a_92, _8cd07a_93, _8cd07a_94, _8cd07a_95, _8cd07a_96, _8cd07a_97, _8cd07a_98, _8cd07a_99, _8cd07a_100, _8cd07a_101, _8cd07a_102, _8cd07a_103, _8cd07a_104, _8cd07a_105, _8cd07a_106, _8cd07a_107, _8cd07a_108, _8cd07a_109, _8cd07a_110, _8cd07a_111, _8cd07a_112]
_8ee490 = [(22918,42334,2),(58742,56497,2),(35528,30481,2),(12426,49166,2),(12567,1503,2),(41218,7572,2),(19256,22039,2),(49618,1821,2),(33680,25017,2),(64984,9857,2),(20255,17362,2),(14781,12518,2),(15150,4563,2),(41021,29814,2),(19290,20457,2),(4652,39366,2),(0,0,0),(0,0,0)]
_3f848c = '/Ng5xw=='
_d4840f = 'QSjxPVOsi89Ayc1L'
_b2acc0 = 'HbnssJW6PoQ='
_9cffb7 = [8, 44, 20, 18, 14, 52, 100, 80, 48, 41, 83, 37, 68, 93, 112, 84, 34, 30, 102, 50, 86, 21, 2, 36, 40, 74, 15, 53, 13, 88, 46, 94, 58, 55, 32, 75, 33, 59, 101, 1, 4, 64, 99, 70, 71, 77, 78, 108, 56, 31, 28, 9, 110, 3, 39, 87, 26, 89, 97, 23, 92, 10, 82, 96, 73, 79, 0, 54, 38, 98, 81, 49, 111, 62, 106, 107, 12, 109, 69, 25, 11, 103, 66, 29, 85, 47, 7, 19, 76, 91, 22, 51, 42, 72, 63, 16, 95, 27, 67, 90, 6, 35, 24, 17, 45, 104, 65, 61, 57, 43, 5, 105, 60]
_salt = base64.b64decode(_b2acc0)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _9cffb7
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_856417 = base64.b64decode(_assembled)
_7d0a59 = 32
_04747f = _856417[:-_7d0a59]
_7d0a59 = _856417[-_7d0a59:]
_fec981 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_8ee490)
_hdr = base64.b64decode(_3f848c)
_nonce = base64.b64decode(_d4840f)
_km_seed = hashlib.sha256(_fec981 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _04747f, hashlib.sha256).digest()
if _calc_tag != _7d0a59:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_04747f)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_04747f, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_01bd00'] = mmap
globals()['_5e2a1d'] = lambda i: globals()['_01bd00'][str(i)]
_x = globals()['_5e2a1d']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
