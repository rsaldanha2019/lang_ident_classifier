import base64,zlib,json,binascii
_b = 'IvVPTN75fSUpIZyVHKYOq92x8nTAqKbOA0a/YJDIM6JfJ2/2NGdzm06g/O9AtMdE6fyRZmCKoWvyfX4V0vvtALsU8Yvy3DufDOwak0ON4NM2X13xa/DCKefoy6yCCVX/ir4ZQgTf/cBAwckU71N++LL/+3tQ1Bj+B8eIw02E4gsDoBB3N0/9g6t2FFCREQDtRfWgpq88FXG2FfQrNgTu4fvtPL2Wf7ZIHN9bdP611mRt8mmkTcQFTzlrs7fW58keBDE4TX/DW0AGyK0k55ao1ox2mPZNNQKzdhpFNNUTgVEJws0nK22hXnsz2j6vXnC+B0X8UMBKvyMCtquokFmpeAz8d1CS2IvfavODKHmmm2B7i4i4aHHy+UNo8sEy2+gotc7clxBcAlnka3U1AgOZBSqVWCqTgDfFmC5OrefhW9VeN6Xd1E+md2nECsB7E2jujPDO/ftmbqGH9+1mFu5OYOSTXxswjcEZgPDzn4LTSHZNhJfqgOEmU+qhvgIxmK8p13mW6gi9OhL/cTkcGA2oon7E8ZWl8cQpHfQhTZC4G+UMhQBfrkh0dzofvP+xV5JYHtgIFAbXbcGcItD4+FFL5HWVCahQqCKSDRnBAnOnph/1dJcfqJ+nTzznw9eVmy30vQ1TPLj8112desK/PNheDJf9gBxS0mceu/xJ0xsblrN69L3Z0WwsfKOWUV0O3X9BJQkg0TM12Vkaa2B4zSHZRmHyrxaZke+yVCVhfSY61RdoKPvxjdZvMuI8Mvq4Auh3uLlEArMUXkO2QQCVvKVF7kiuabpkzABHAFDI6zS4sYQv6Sk2eFrh57GCVcNBrIPQQ/MjVETwFamQPXSW5A0ftaA59MZRKJAReHP5WFrQ75HOyLoHhJdMovwOLYLOOSPpOYylWJqb618IrwjGTMhvmmflEWYnH4fccNG6AFVuZkRzZgPnVqIcma3Va7AGcGw9NknUTrPViUTspI2VYQJ/ljnZgzCMXKDt4W8UaEKNK6zVRmjbJuSXpnILB+wABIWoc4aORr84S0QOewdOWM/cMauPd6x1Ha6m0vQohH99ZxJEsXNwHvrfqC65ly7Sh3xh7LY/o4a6GuW6/jlYKPCkYIRqY5UnNqC3Azb8SwpbA0wT1/wjBXQsD3uCmU9ZhohLrHtemNgp8n5EQmxe38Le4sxavG2IqXHd62HJbMn71UNEVppERg9PzMvwU3I3t3e5+O7IbYmAaChjdyQ7UecnJREu1h7N3mEnVUfv5nd8nZ7XDz9zojbPoMN3SsDvfn4L29R4e4aO5AnB57V7vht0tT2Hf00nxWbPGBSOfH9Foj/UamfIR4YrZKtK/cNpwOzVTKINwVFjD75yFBL6WtiS7ComRfkzaYrixn7Tp6MObYbXjGUvRAe9+iBzs85MM/pFDcy7EZBjN9+mXOF+hAX9wcawE46VTst912zvlKxy6ZLmTiiymdjCdi/8FQQTFxqOvafdqjUcjyyeF0WX4Icjy5bVy6fD18cKQwBGeofGndcbFFk6ksj0qC3QJm9pkZNH1nUn/NiexqKRmdGnfbapCx4KYJ/b6FV6Oy5qyf0UrUwC48p4Todxwi8EoZMHCd+KIOPCNht3/eo1Grmkm5eeJJpLUFtq9uDVaczt4kU7y3wWaQc4oQJYXqthexzkaJI8tnU84pUj8+7san5LB6Lzn5Qfsa2p2IRWlVTC7/0XXj5bjlIf+4j6uFKG/itItIGc1SrshcWljDVDXWp2vWnWiwZH97UiZn0H7C5wF28+2yoo4f4iI0V0M9MvfMjhZO6KYiiSEf2SrFatQcRPvaxn+UpSxnBONGQ+iSHab2wzK9tr56wnNgk6eb+4uz/koWrkU/XEok7+tS0bAeHOTvQKrdAPY3KnZmNzdUNYkJNENVW4LT+m5xAeqrvrHLNXk7ROpkmVVqI8feodlLK0KYYrCybQcDf18SGcomNyOxjApEeVCNdsqT0yzGz2VqC1uKaZ1ckyaaYKY4wK928b65gY46l0LQ0mhjKMZnODgvT+x/Jq7E5QuM48r7K3dVLnYFdgPYfsHWeeoDADYByNeQU0KqIpZRi8fhB7tz5HEEEP5466uTij5NFh29GAcPt+3ehia2DtKzGemLZw4dKvIfJPGEPpocIwfG3UnX8/STtWgJ9MzGWCourqHFGLUu5Edl27f1NKAM433U9EA9LaCESW0hVpPCAkQ/sGmU+uzTAGTjWJd7KXapH9zely56SuZSjltG2fJDOlWy8YGw2VrfT+ttyZgM/QYvM9fkG4GMHUyRZOsmYiLj8NsjsovTh8oUPsNko0q89r+SHEOch9a5vZlLyB3ZhmjIDrHNd1JGwmTmgV9YAlDS40aSGDtr/jbiN8wc45463nPSv/5eM84e53Ov2fPa/tTEG+O/1G3Mn8IJka4W69GOHPCDn4JoFOVDnNkKgLIk0gdCevpc3GJgMdhE4chf9td2jyNRNxr2H7hKSlLeDW8UCDbBXgCVGVRUiN1XpsES+9vmtPaXHAckKCq/Z8f4eGVUgnwlo9zLeoMzsih02hH4CeyWWPVkRYrgquL9z8H1d478NnJh4aWgbFPX2+0pVKSQne8gzwiQHrSNwNWtCbnJYyuA95UN/xUhy4vIbOUtuUseq4RPGUnCtOni3Tlj/IZXG7qrgSA8O/UoqCXAOYq2OUGwS1B+P/2yh0NkknJeWyJ7Ys80HJUo6/IRUwaeCgkuzOyd7dlJKNiqgpbY19/rRTWJv4qjYIHma6bB+NT5vuWkQWb7j3xj+22q9FNgjmfoam9pCuE0xLogzWSFYDLiqHRwkucWaFJgbWm6+UKBQcoZYMyE+fZKz1WibfB/KhWaU/ZaDwZvOzsrUiBBXiAFNwImtS95Hcf4V94S7is5h+yYzd4W0djeLy34FW36bulPcbJAZgRNhxwXP6RU5lHPHMci7gQIf49b/wGwuhCO1QUvnCo60rH8WFl7+Zla8KI9oWImOg7LiJ/B+jixjxDCnMHaVyeclMciocLaTH/qMSThQG/NTk1OWoqiy6Zjco/FyY4W+Eyh9Z/pfjKNGcjHisbBCR0EkU8ziUI/cpkudc5sFRzlV7fpVwf+KQ2RY2bPc+650n55/HiIxhTw6OJr2MAbuJJp8hkfna8VvwaOxb5ip6mzvVx/Ne808ysF30H2saPkQDQjWaFiaDAoetFNqu0mM+iYvcsyeAmtWoAZHuGsmX3qwPMJK9TMz9DrVewsLWr+lntpY+K9D3OwBPS/U6Gp0c8YJD3zz+0CW+aS+AV4x0jh6UM2lAz3hxiQCqBVKDKU3PQpbWDZr69aNZKZqa11RWZA5H9/iAtwV/flYIBJQDKAik3X8Wyg65zaIsZsUbo+0hjhkfbjQGN2sVlkyOKf2ZWt/yFSirUEuR0lMyqL2FdQcWOGK+FsTsQqLQM5lpz3mdiBDAG4E6lV3fVdTn+ZfgFru+l/K/NB76dPZzrjRfaXQ9DT6Dtj+/1S3jpan1ZU0dkuWeUYaWmEqfASFkt3ZGej10AuMOgRK69F9JwC7GUh8URFdesCYxxHr8dm5mG26Z6b2ViOVgfPmU78JiQ7w8wexpEUTEUakRuFflg6P3R3jK7LCIxf1JiS1/W8nstqVXRxrnT48gOr2jzLmGzVT4cuxUjZG5GEsPz6pmiW/lwYjV6qHEiEYV7nIEGneEJGj/hM+B7/PSPCMWeFVmmsnZA9SwMiMfw8ZefLuHKtBu/PBrrhnOFQLSRHfTD7m3Wp+ZGamCuve8K/QiJbMDJViygfAV/aguYsbvfDLw3D0BmZ8aoPqzLsQYCVEavdnqydRFWsseICh32HqF6l0QskWDG6Z+ITA/gz7MVLzwVNBHeFiRLINdzq1v2YQ+vLyCNNJVvIITtRyiPazwW+mUmPrbvTNek7Myykxd9mp2NL2NMgtNp7ZPO+D+EZ7uT6SWxw+qnqKTLiEvaPzB3qdiSso7UKb7JbEwhLHK4yNAmLAg1DLg6i4/JU2x8QMPAzD5t5Q98lcmNbQXfm1GpZw8MLiUFwPgiGoXTDRbpjLzImxqGpwnGIB7cvFacSJdrC4Pn8BLtXezOUAVDSvHLydZpzHoSw7gplP/oQ+XjujC+WQAjaKxm/Un9FiuwShuIGKd5P7crHCpbU3uK4McFBiHI3tRGytbUlqtRmjLth2lgtQJiY+2p2+MJf4zQPqyIPPVVjf2qws7dCdEnyLz/XZQ7a7xZdwW1HDMOmUSU0uvV8fPYtZ5XaJ8fLS/t6F0T2BLc9o5chlhcqhIgqUjYMdAvY6TKvXW2IjJWVddDfpWxTr5jS8uS/NgeL4TO/aMthQKZa/RxSJmOX0hEnqK4uCKGjob6RcMOBdiGwyb9sbIozbc/mQz9CUh6NaJPCgotYk/YgVDrHAZCPjkOnQXLnnjAS2qQ5nJRnU/wUWOMgVnbDOATjLG53G0dhGMF1tPcqk+f9W7loPB4V800uQ1H9dgzMpj7/V8yQrMz4/tXW9T77iUperhOPTNh9bDKxRS8Z4Qxxf9iuzRUmTtdBZLtQTIYRT5vLAuOS+a7fVMGHsVSqzEGnrMIylHhfPfBALTl4E2LiyWRRiG8rtc3uTv7uh4RFGZmaIaKC6wt/CuKEn/ttlZC69LPqUETVUROqdvV83HwMccqhVtUg9rEODAukMQCi0E0dk3QNR+X5FQP00luTraHFCbmxkKAhI4OAB+E/shYIgzokwx3HnQgTW6ors9nLYsbZU89jIlHQfb6CDI9+Msb/eQ+16N+1XrGAZUeD+T'
_p = [(1886636623,7252500,4),(1586939478,8685215,4),(1247008375,1946115,4),(4038833572,3973132,4),(1156324905,15882118,4),(532772775,11689884,4),(1500032507,8999921,4),(3109074875,9547846,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
