import base64,zlib,json,binascii
_b = 'HT57RDKHRhsRSU9bcoPepvJb1MVnEnH8aF3+9xJdWHNHrdfIKapyg281xTHs4n6/XhS/BiH6Uc0ZGga1O1SmzZ4rPDFNH1aU/iInI4z05G4SoYk1jxa0yrf9jESXmHjPPE+/Nm2FKR2bpI+XvtpoSA/ncM5PU2rJ7hk41fwmQ4TYTPJFNKVufafd30qWBszIu5pze1tc9jPWhLkoYPPRhKgRh5dJmUmXFBVd7aof4FcZRSd6n+oAvu194JXg/iN/jYp9Qyqp6Pgke7jsX11xkm2s0uAJ81n/jos1BNQYIoEUUzK+3vw14oRnpuxPeBj0WD9vbVFCXefWkWjLVYYbBMaBkfJ9i+8txyZ7XBlSLkIxqIZY19J2plZHVNAfKAVprB/sPf5ZO7PHY5uq4xoIKEJ0AliB3/wFCzANyy2QLL1S5N4gOAg8FNmMZG6FgTmVe/6wLKeS1iHLfMJGzrk5I4lrhCeECAziSSbz71Sk8hrRWKXXLLjzifAm8pHt/BaBh2R5VqsRCDVxdQN0xFJQBHHIDMip2YaLjZlzmYQZ/etCabczuo2aB8pH+yMAnKA2ABxzNYHdyuWG/MuS89iluUi4TwY/TU7nzAwg+k4mtkmCHDoqVuCBSq5AHWTvefUbVlLjdqMLV0UtW0llwRqKJrSqCK6vmAAhfBqEJ7z3VS2qjEm4rcx8xUq7IZRpSnfAG7gxKZ4FFliXj7GJl/LzSJfqJCAhNqcyB5TnRqh7qVcZp5iMKRFV7R6wOzcj+anwMyy+ltB9Da/x92dZ/BYNAxtK7o75jemfJBAiJBNCIs8i26EFC/G6Iz+YgqkBELmHT8ou8i9lXMUsB6UqSO0kGnAHSZ0XiFYQWSf+1emz+ynHFWJaddeS1ZiUGgK8G1lADxiCI0bz3A5dIAZtmZmzjLMPQezUR6unmt2v3TgOtfbmWoYIoEaxT6Z1RTl+JmxkCTtAR3BVRbnNUOuOv3hU0Cn9NL+xbFewBqi8pla6/IDJ5Sr5HfHCfL5ap1/vZZjyNM/cavmdG5zVjk6mVAj0Hv5AZNHo58jlM7TR4r0kzI66J/ssBmC/ct1GZCLj6gMqUpQkxvs7juYjtb/8K0qHv2OFnRZGWImCFXRAs2nPUKeNIE5ov289zySZ1WR6S55AXbkg1jQEySiQrtBD9XWfOHHY22R6RhYTO6me/wyfg+2nwJktwOUX4JZgnZYuwNtQ4FeEnIF5r7zALOe9g+V1AjvGUpvU5wStY5KUtYbj+7k6+gndJEHgPr3xvmQiS8RhHdKgecYz55LLFwPJpMDIcdjE+vYFN7aphtN6iE9PIri19Wa2O+iaVQiWu172o2DqNeSZZ5H0EvXNLUR5GZzxpO8JP65z2AvY6N+KV5D0JONMaQg+z1L+AzL2FuSzGpfh1/wE4pz4Dkm+sOxlCGvVcUZdp7UkjpCuG0FayUCWyHOoSN+If1IC8ruC0ygxzfn70aJ/XxN1LU189cvBkLqHH7ebg8z6acU0GIwfAhKHkS7ta4VzsBS+7HJEGUbR68XywdX6VHtHjL5QVWFQOnATnP1tfTiw8gjd9h7Cmi53U63ZA2w8OuAK4aCHUJjQlqANOK6XP6mWrBtzlUFGidQ+/TYx+IZV9xML28r/iDPjfuVOaGjjt3uOT5HoWbb/rx2CiAkMPIFcS6D0NM9JKNbCab4T4TXeBArjv9HHgFy4TA8a+r0tINqq4qStJoBMOctwTPYpnC3jGlVBc5bXitab12cNG4cu8FWx7dBT1kGSAf9ETskuIw+Znk9Q0Vf6jo+on4SMicUcjw6A8JFTJAZue0PN2DOMstMggqBWNNHjVRMJbnIEKyW4sFd4qbQflVDVnGLjzuK+9WazgJCvh8giRp30k47CkEFw+452SSTVOnfVYty3vdRMixXO+0qDI658txGR2agpLcqDmUxHk5OMj6sxvMooJUuJqo6i4r0ZQGhsQe5sq1PeGEYyq1zvP9vupzUz8IWJu0vuZal0heMYDoyv3BeiloxWHmmLxphmXUF0ZO7RDYrrUtWi/q5+jkb5G+qVqxC2xB+puFECDOrEXGQuUxM4us2NJb0KhZiBXy36s/fWs0ulesev+2C9N0oQM5WsK0wD4ZhJziAi4fASABnegi9vZk15M87XLuPLw2CT1/WT1gB07iStAM1Wf7TPKkenVbPzyG0UxSHkUfeBJqMzAFDIz85rDKSyyXTQZugmO3SbfyVryX7bpMN3zEo20ltcIxEXONl7/RYo1JxNkQixWQe8X1kLvtlYeD4aqRHN212OAuKtdaqEI2djTTyJicHcJYKGZIuDI11ev4fxsVPmBBaMzyGWy25SK5ZttrwoGVLfj7VJDy8f3oXelhHuR3ZbcTLgijqhg8f5E08Nzt/OhMrbx+jXxLj4FmKXpjVObn7anwA+Z/EbUircDWNy38z4lnM+0g7rPi6cnIP277xrTZG+AIUXKwm9gl/2/ga2V4+CqG52LqNlcPLHlq+axXJWc9WcpMmHRIScN3X3VFhiMFdqqJOkrgDZBAagIYK8tUtM8HtLyrFCwrXXQQNRN++GgWu14Fy4ELSEkyxSUYKmHQsmMCU7KLOmjEcFmg40+JqoKupCE3eGAmNJ/Q4fe1BJC6MWKxwzQG5yI7N+0iSpv+NAAOn28lJBsTM8qaTWBXjazseHeG41YseNaB28vrHXxXEkDXibCSl6dxGLo9nf65Cu1QeD1MvRBr2GtuONuuQni0aPUfgdp7VUJAKLRupK7tbqGxmtVgthbJ3/hHZST2T0xd/oG7c8XpsfEN4wWpkkcjVT85LSh0lcGw/m8l0vWZGSJTmhV5BLfqDEFFiI4W4fA6evxZaOnDNpRaULkBndl83hsugL3oRrg3+IKnh3dagN1VKzMMJgjhqm10b3S4rZBi7dprY4/L45VS3tpSXVzh9DN8OcdnDlFYZx1V9hMauuk+I6enGhcg2iFYU1mZDuT9lVHzQ0cuUu4O+L3xSfNU9fLM8Xrjjns9h7TG4lzY3sMfI4OvV2mg8ShpcNHYcqL/ZPEJfIZBIFqNnEXYgfSHlJP0WPkNLSP/kJEgLYBrkcrVvFrXY1uSVAEYVBNwsXJW+nwi5YIdb78CqO2aX5EcjrjXFmsdgbdxVEE4bHBprgery+Nki7QsWOEd3lbBA6/WutWXlzTf0ehe8Kb2/Tksoemfzs2b4VwAdUl4oZRH7sueNB0xXLblhfQ/hr8wjlQt23/MMsmd5es2BQu9UFMGHJX/1Ztd7fBC7984/2JknMzfyF3yCquV+3IwKW7kXCEza9mYYsNFw='
_p = [(1383629918,14543051,4),(319843879,485018,4),(1886902835,2115252,4),(2427258587,98888,4),(1205628469,9662375,4),(3541618520,16745032,4),(791682833,9405537,4),(2002470750,6370281,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
