import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_cd989d_0 = '0f3Mstn2M89o3BrVqtf2x9r7NgCpbUeyXjDFs9Fy5EZQ7Owlr9xrEpIc'
_cd989d_1 = 'dcQBQaT7FViH3tbyAi6sKOMaSM/TqsaeKk5F74Eh2uVGV8i'
_cd989d_2 = 'fvqbR5n+YWRmec0FSmV3GVn4VQ+Qw'
_cd989d_3 = 'r6OaL6SvoSU+Fl/vDr5y6go2HeYXEdQ2unCbUfxesMg7AWtsoOvh71q'
_cd989d_4 = 'c+cEhBZicpMc6hiIshT1VVwjJgN0/9k5d8U/PZnGSYO6tLWaSjPN'
_cd989d_5 = 'u4SUPBlrnca990He5rG9enB8rBq9usDBWs02tSx3JL/3UlaKZQVT'
_cd989d_6 = 'kT0/7wqk+6mm/DOO2lVXlceGvarj5MFU2KP4'
_cd989d_7 = '/mAgog113hxWxOX+9Y9DCK0D5G78TofN9Ua4DIPPfnyXnSI8jUst'
_cd989d_8 = 'olkV4FpQid2z1PjD8xHGcodnZfayAYfcZBTsy/1GznoGPx33UA8e+1rd/L'
_cd989d_9 = 'SNz6pgQxVH7Ksd+Jny1eDmaDAfyGlR'
_cd989d_10 = 'x3bWRYk7DRE19mGjXoACCjUj6ZjTLmSncAEIX4Y5f'
_cd989d_11 = 'rvHRlAsYbEpWpCqMbSnkETeqA'
_cd989d_12 = 'GMSWeM4dq3r74X/aqgwG5D/vu3xuebU4'
_cd989d_13 = 'PI/r0dTXbwrRACny9/Rdp4Tl'
_cd989d_14 = 'DHBi0O6mNeXodIT51Me1NFuX8bSADWDbHRnHJ3btbWovkiefLCyzxq4'
_cd989d_15 = '9uNsCjc08YyYPGhPfvwRX4ZIiAtOFT+QjyHlI/'
_cd989d_16 = 'R5K+TtwlnvS/mq1fPot/h0OmaZAcHYk5EbF4MTdGoo59Flxb'
_cd989d_17 = 'riNDAG5hUNFvgMsPJlpgy3/JBUppP35ePQTHB8Nf+Mk4uRfOVBjufg5MmI33Mr'
_cd989d_18 = 'zpQQuvYLuwt/H9AmdjUCuz4YdPI6q4rvatsKTPPWXUfIEtsLNUBv21QdNf7HEgv'
_cd989d_19 = 'Iylcmzy6TlfWGdTkiOtjGc'
_cd989d_20 = 'xy+wP1fFUQIIRRRfgnBy8mWYQvKf'
_cd989d_21 = 'gIm0e6Z86AMk4Jc44Rv6w/HyFgEXRzib/VGPrlEaGND'
_cd989d_22 = 'DSm/00CS1Fkgso/4ObSllSv2AC67b0oAOzfYTPaWGFlwbjr'
_cd989d_23 = 'UErB1mjidOgPRIXuPfUFrWYr'
_cd989d_24 = '9RGZoMxkMjtdVpyunhQWWaT4VryFWpRqImFAIBMXOn'
_cd989d_25 = 'aRxS99YNEKzeVyfd6TWsH+NDURubHxH+o'
_cd989d_26 = 'qjF4ecKAC2/EApBjZLySZKMBtsIfiqDCNA9CTwb7INeksjHS44C'
_cd989d_27 = '1+wn4dvmRGpSeaz4NZU4LOwe5kQSRb2LOzxUWFk50v7z4oJOr8J0rS23NR4Fpdi'
_cd989d_28 = 'x+ZeRSyFKdQ+F4QMm7nMVvDRyGzuyi2Sa3HY'
_cd989d_29 = 'LAlWFz3qRr0hCJta5DwQibDE/qA4QsY5EIpP7'
_cd989d_30 = '9SunNfhiObfEkgkveWw9Pl4SMm'
_cd989d_31 = 'PT/SiyY32s/'
_cd989d_32 = 'T1oLWHOU/acWHScXXqpXxA'
_cd989d_33 = 'TtMv/ozq5jo4zlCN09WxtIQ5xSmYxKjBD3tVnQKeubkVwFT44IHdiHLLNob1YGLJ'
_cd989d_34 = 'MYKMeoN/fgUi6Whxv287jz674fhJriNQukF8lyaPg'
_cd989d_35 = 'htIpo8gIBBqQtqfvIi3vjnUSTelBIXL6n+HdC4dmHNCpGYlQvrg'
_cd989d_36 = '2IiBD/Mk88YIFC1Ug/ZdZTD4Korx5UJafx/iQx8LH6Nt/WpAD0GugFRFq'
_cd989d_37 = 'cMMN4Hgt+OuU/vszvd2+e2BZHFW526M//sIcLorKbwN95GDwsaZYke5'
_cd989d_38 = '3PkqZTQ9jMbDqHEFTY3UCaR+9ih5mYr01NTVGQAs'
_cd989d_39 = '+ev0PjU6ZqvKh53MsEbN0g+Q1UfduStKt'
_cd989d_40 = 'aQmtBBS9q+JM9eK3QTniMBAh0Xw62cfk'
_cd989d_41 = 'hVDWdz7+e0Hg2bgYSqUV+CaXBSvYRjyFNfeZ6NH8hTPKN8ZdfdA3eLZUfdHYYM'
_cd989d_42 = 'RBsU98VpH8z1cRbbZQzZw+DD4H0+Us8nFQrGKV9pr6BqE5iUq1cWf9YwiOwG+gcb'
_cd989d_43 = 'ehlN4hVIuZIJWwavQ9E9QxQxPY47biBDXaf+Z'
_cd989d_44 = 'Zd+emYbnwlnTRCmgBIPthXe25Z+NicBM1/CSTh'
_cd989d_45 = '8Krvn39sxQXKsP7XZCxG+197zgifiEzcj'
_cd989d_46 = 'iiPLQENptI8cLKPcYiEBKuPHetJvdHedJkPqfVYAvWCKBEDPxV96AS'
_cd989d_47 = '0/a4gYMxwqQMxFBZvKMKumues8HgricLlTZFyt+7x/D0fMpcXY68k'
_cd989d_48 = 'RjkSjgyyHX5RL9AN6afGvIGAfeowAPIIITkikVM71sJzMDw9l/b0v+nAmJ'
_cd989d_49 = 'pQJowEVllhGhvBpDk2LijL2GjVBb9ptboz3l56'
_cd989d_50 = '6njQwTklQrh9jaFxfMOa/LbT1cfbRb3T'
_cd989d_51 = 'yZklfbKHJCxVSkAvrxr5+QS4UCQw+FtU3v2kZWLGodhf6py+8xOdvXAHkAp0WoKm'
_cd989d_52 = 'pw15ZNJ7KE/Cqm2+4lE6OY65TK02iwUw'
_cd989d_53 = 'oZxLJgHxA6hqC4VZ1gRrK2ock262j8bQMMwmO23pUhFQqwAEE/oH8SnWFQ'
_cd989d_54 = 'S0YnKTDnIWwiZdQKbM3P6YHSXTl6SBZuyclfbCCh0S'
_cd989d_55 = 'sYl244DwjIFJppbIyudlY/WDtBVCarU987IDpYDtfgW'
_cd989d_56 = 'kxLLMRssNociqGprXoMt6vJM/5nq7ZYzC3w9uTKBQi/'
_cd989d_57 = 'KbhTyRpdFY8cHl4ycdCWANcnyWDexDbcWNyPm'
_cd989d_58 = 'x4OmeQUY+9jHJByc7IyjfHmvngn8sKUylpDpfXsHIBtwI5GSSRXYZ13oygP'
_cd989d_59 = 'WHAcwYnBBM/7RhYoXgDXDgMe3jXL5V2vPtHIFdo2ZDbBWaJAPFc'
_cd989d_60 = 'Bc3OtvM9NSLqvYmWDkT3nQ2K9qghlVqbf0GrA'
_cd989d_61 = 'Ahbioqgyz7/xhmu6e0gxj6Cm5bVE6Ucr4SGPePapnvpwkaYKZ3gMajmGZpUVC'
_cd989d_62 = 'IpSyi0HdP9WQT8w5avvOl6JFeltqxGYyDDs+6JSWlDjtriQDSoGTs'
_cd989d_63 = 'ZaoP1nzSIYiRZG6MZD9Sn05NbWEJ3thBpq9k'
_cd989d_64 = 'VN8v65jS0rYW+BYDcVROSRNd5/z4PVq6CWEmx'
_cd989d_65 = 'pGIsv9ouK1+JMu3UwnstFSI7EN66l2ypJxsFV8Hq9+'
_cd989d_66 = 'aronNCMGfmeRWY6dv2GA4WS3T//MjA18Df6bvAvMB0sSzCVcNgr3Pyxw1RjI'
_cd989d_67 = '9OtIcQl/fEK+DcyamyYadsEB4kQTGz0xoQQgs0AiyJu0irkF'
_cd989d_68 = 'tO/7viryiHDcl0oOHC8nOb'
_cd989d_69 = 'wLy1Lxa3Y3Afe7e9s+IHtImIa+B8Q/AH0NmC5KWI'
_cd989d_70 = 'ysIfuqsz6P0IcPZ563WNHPPN+J2UbRMPU64XLGTUHECbKms+oMSm8toBx'
_cd989d_71 = '2jfeipw2Eeie/8HQqGwCPCOOxJUFkOAC+xx6ywoOu4ePEHLQW+MBx4Hz'
_pls = [_cd989d_0, _cd989d_1, _cd989d_2, _cd989d_3, _cd989d_4, _cd989d_5, _cd989d_6, _cd989d_7, _cd989d_8, _cd989d_9, _cd989d_10, _cd989d_11, _cd989d_12, _cd989d_13, _cd989d_14, _cd989d_15, _cd989d_16, _cd989d_17, _cd989d_18, _cd989d_19, _cd989d_20, _cd989d_21, _cd989d_22, _cd989d_23, _cd989d_24, _cd989d_25, _cd989d_26, _cd989d_27, _cd989d_28, _cd989d_29, _cd989d_30, _cd989d_31, _cd989d_32, _cd989d_33, _cd989d_34, _cd989d_35, _cd989d_36, _cd989d_37, _cd989d_38, _cd989d_39, _cd989d_40, _cd989d_41, _cd989d_42, _cd989d_43, _cd989d_44, _cd989d_45, _cd989d_46, _cd989d_47, _cd989d_48, _cd989d_49, _cd989d_50, _cd989d_51, _cd989d_52, _cd989d_53, _cd989d_54, _cd989d_55, _cd989d_56, _cd989d_57, _cd989d_58, _cd989d_59, _cd989d_60, _cd989d_61, _cd989d_62, _cd989d_63, _cd989d_64, _cd989d_65, _cd989d_66, _cd989d_67, _cd989d_68, _cd989d_69, _cd989d_70, _cd989d_71]
_56380c = [(41819,47051,2),(55861,6355,2),(64110,51836,2),(57127,63719,2),(52310,44293,2),(37700,24086,2),(36202,58761,2),(45021,11841,2),(7010,10686,2),(844,40725,2),(14794,2987,2),(22321,31267,2),(29754,50615,2),(50469,36985,2),(31445,47001,2),(41788,10172,2),(0,0,0),(0,0,0)]
_4bb1a5 = 'FJDC5g=='
_977ca3 = 'WDobLdBmPOFjxz6P'
_7698f9 = 'dgYvMbkKFn4='
_4b2a15 = [50, 37, 21, 49, 30, 35, 12, 16, 25, 68, 46, 3, 5, 66, 36, 28, 65, 22, 34, 29, 9, 15, 31, 64, 6, 43, 61, 18, 47, 51, 41, 71, 59, 44, 26, 38, 58, 70, 14, 0, 20, 62, 57, 48, 1, 55, 56, 67, 19, 2, 42, 53, 63, 17, 4, 52, 24, 69, 23, 10, 27, 11, 13, 40, 45, 39, 32, 54, 33, 7, 60, 8]
_salt = base64.b64decode(_7698f9)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _4b2a15
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_708aea = base64.b64decode(_assembled)
_b523eb = 32
_eea156 = _708aea[:-_b523eb]
_b523eb = _708aea[-_b523eb:]
_a0215d = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_56380c)
_hdr = base64.b64decode(_4bb1a5)
_nonce = base64.b64decode(_977ca3)
_km_seed = hashlib.sha256(_a0215d + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _eea156, hashlib.sha256).digest()
if _calc_tag != _b523eb:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_eea156)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_eea156, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_3255a4'] = mmap
globals()['_6bc694'] = lambda i: globals()['_3255a4'][str(i)]
_x = globals()['_6bc694']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
