import base64,zlib,json,binascii
_B = 'lB4iNCBrUVOF9qpsv9PGsvpKHL6vWb6Ss7SWmJnGeWX4Ax9Vx/hI+4HM8JDVlrbvh2f3qcZW9INGU608+EKMnhURzKSu4O6u56ik6zpHlH0UzNGb5fjadgHWFBedf/5NfDMmBSqoRKj1PjuUVV3BPt7wb1FG3AnT2RrjtooltPIV2mZgFlfotOJn3U2xKS3VJ4u9kdBqxBbKaOAUk2weQG8xMpghw5DdfC8KuM/OFgkmCP1RT1BPX4RnYNbn1P6tdVzqSG8wP7r0wYcjkeaDdHvhe3/5bRYjoK3NdweEWlUm1RsueMF69xfa632BTw33n1Yp/MYrOItUB38NCIHzg9SQ54/GgLlCtIqTS8LNikbcIop6xnd2uRqKh0zx3bObRnLzfVD6qVnhFAQMu/IWiGeACErHVhjhu+iSbNV2y5QUq+wZOooeyiXarDbe1V1a3R7Ln89DYqVot8tzWIfzwG2fg/4d+Vm+1Rn5Eyu0rvlhhh/Z17CYS5J54Ckh7iGHgVOKzvyGm7PVUqRKwsclQNiK6VK6I1/KVbsB80RzLTA5JRNW7Q2G+4Q/SN8yPGTQuGx6/TURxwdpzcE3vUi5UGkd/5T3DrEZEsyFUmLBpzXXXZNPD2nRlvckfM4Vj1OpdbcPhKX6zGVROPRyuqqzB/vBmWAvuuCSj1AEtvOrsggmdlf2EiTe9a8lom0ftn70p8S8lKDF+khcS2/LdGOiRTJt//3NDhGxASNoN1fAjNyXut2pvDhx6ODOptx6AtH4yFFwI8DhW0xd1f0qP8oWe175UnRk//kmoHMpz4GCN21KLou98Pug4cuH3+fJCIWT96b3eaK8+07Vi3FD7L6gmQgK0DhFTjnh4wb3dU6c0cQww+1MjCc7b6NbXrNKx6nVk9lYkOmTzRg9H5FabVms7qEpro8jJAul6O6Q18uJVUqZQU4O8cjlXlEfFbbdj3H3o230/7iJEvPEYgqD0JDPlOfJ4NzPmgNtwDz+oQdgq3r+ZjIJQ1DttsCd1bnumGrhoO7ii3AozMO2976QRiYxhEMrYP9u/kl1KiYZl0JaTLrr0sxYIHEETLpgo0W0H8tgjuxXznDQ0G/PxknVK8y+GYxyXv08T2eA/3DnZ8n/OvjsJGHESi/+0g6Qvxy5N5dUrX3NDzjXU9PTIT5TgL8pzMIRFPa2kF35tF0s7LMN/235JVMbgL7+LFL6kDy008TnNV5v6LeVXWnn4fvOosnyA9V0txDwPhRwur5RXBcCpEzpOFEaCTd2LeolzD1MdQgWwnBW0uxWJWI0BEyrJUZYM60oxoz3QI/vCUcf1jJjHh9UR4Dbjx6mYxZ/4XMU5e3TY5I97LXFzwMdW+4LVl8KmLxXcqpukrgDSARoB/OHUubVX/sWfJ9aNyKX4CxMmUsxwtNJrdzPIE3udAJWUTmfwoHG8P8ryyCFp4uc38wHFnYeSgucJvdfiEUN0IYDtgknieJCm+B61bageI6u1JvPdH7OYCf7LmUCW2EuNvPIUhXQltr4DQ9qA9lDGKtHN+YWGzZ62pNXwiLRYn6GydG4IJ7aNJcuaelqx23AfqmMOUCnrD7uay140zkePB3FUe29DqswkCYFmjKjLXaHlYtLSiVJ3XlL0tWbgtG38htTiIXTBAKz/G0i6xIcJtCLjwplExaxHS1N37QqN3X1Nd3Oum90N9SPgC56E/chI7IUgI+7OjZ25L+ix6Go4eShPNB45jEJjEBJmYqIuCF1/Zi6uaunnR7Pkz5rId32kh9oy1S3AjsE6VIPkx3FVGpvDGjib9j8w8SYqcsJgLbFPte3HKGTmxLGCu5Bst786Zvvry3VaJY3Qd29Pup8yoPW3kozSsXqla2/vYPryFpKAK6q4yvE1VI7wgl/LbBFmZ+Z535nX+on+V3UAWwjV4+/wDAk6Z31ATdl7TfFMbugR8c9CiIkC+eUYL0GO27C5+y9h1MdIGowBvtSvMGdRmv2AUrAFy9YXjqbyJsMhXmf/0ty9pi2/EyhzYRkm/5ENDApZGZnNWPekmCrxC8eQdc5USng556ljRMiz4AmJTzPBe7+0bMN9tWip3ANzkIEGgVWZkb7i1TMDOXgnebJWjBtQ92cuPhuuFWas+L1SShZ9iv8V6zEYreRGJb1b0C4JRgnyr0mlKbQShX4icX3K/iox0jW94QoDRcS4abfRN/jX3J/a3XpuLzPYE35H9N31OY5AUKlVV4muC0RbPbF5d3YDONQijOWIZsiYy67y2PQii6rrbiPsjbiU1BsfyiVLZWfeaq39y7TVGBjiq7e99IV+NvNRIFIOK54+JnzDJ6yt4xqlRuDw3a/nHYY2IXlmLHRpv1c+QRuvZe9ouuGE6D5IJbJZdKrvlJqS1avvkiQhNYuNQs2hrXN0ppydbCFe99aWa5MxmPxNlUoTvatMMIBTWp4v/LuabPp8dSInREM88vl5Mpjrtl0Msii8VzEkMg/ducDPTImBq0eCFUxW/0FfJSYje+qFnYtS3TBXKpapp7mneJ6zsdHI5IrFVpKRwDQZnEejuG0j2xXDluyh9gpKxGd6QV77741diFBcctabzbuI9SBy3pF73PrllTxcmIvqlYuP+aN2KubbJFOINYtAIW7EDB2MNG2fRBvboGeTo0dKEzyGcn9RxrmKZPcr+mgkP0ted5OA1MdC8yUFIcG7OmFc7RP6t68utjooPsrp3UYIbHBfERbwhiRIgW/KCSjr/rMwkTpfawLn/32Rm++BgHbZzkaY2uaWqpf7d7smi0H91jirmsYpfM+2f4Ydm0CFy+fCAFry4rD14uSrFI2dpYa1oW1S1YkIWCgyqt6HUQejzXMpG7hnkHWGXuRwJ0vswO8rebgvAJ0EbikrmoZutTMlZQG7CU2HGqJ7PXoIHjr0KoJ80qTc+Irnu/SXe++Y9AbAq2O0itO6nqQxJiyLY+tN6/H95kgJQthtHTnkKPBHKuLj3zMMOnCWtLqXuZ5IQiyigVzmH4upGTWpwRZiWYcTI6v4N7PZyo4HXtAM5L+d+smXvdfKfOIGbWvi1MgVdIpDkpbkI+R2ec6NxwKXIrfQMi5HlT1pgGJoREzDkERmc5E8Bjx1OKJofoYIQSU2y7Q6z5ocVrUZRx45MQ0gvOJHIM29pzOhb+/SZ6ztWPDsD8MZpbp4X6mSHlzuDl2m8RvP7w8SLNIJKqwq1TpbsG5EcdOtjtPaE4CXdlIRw0e/1P/ia7UwMLZBelusE/Msel3jqOe14JLpEgu+upraNbiJ9wTCJc2jh4iXbsAH/VRgnCr0gsw3lxzROEwvgc='
_P = [(870349347,13538475,4),(1894423112,5071752,4),(3815702991,6091624,4),(93168587,15856691,4),(1173452197,13819924,4),(2106591737,11283883,4),(854801918,9499847,4),(1384093228,5131976,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
