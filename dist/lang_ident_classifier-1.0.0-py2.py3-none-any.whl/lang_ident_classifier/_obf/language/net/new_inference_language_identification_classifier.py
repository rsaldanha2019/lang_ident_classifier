import base64,zlib,json,binascii
_B = 'dR0ak9cs7IAjMdP9dOTIYs6SJ5tWaKZbb+DtHoXTMhwDZFz8O2uBeU/AbK5FeKBqTLkwFR8b8uouaNUTYUEHXTCarP4ngdslJ4dv/mhRucLsUaqp6daO8ooJk0e9dHdySrf6BmhNakA9xxanr64p2BKYwiZmdbWZO07rEQ08TGKMV6q0E0lKTPpglON/Flck7F+MtA4U+WgP+hy5qL1JD7fXtJzxnQdoPiqW2i5ehHSJOOPbNVUMexbBNiWE/quKDSPdOO7XJnLcBcO/Rwg/WBTn7De4DUdLoWDGf1HwdvRbd4ojNsJIZSMWPWPycOJBZdUUX++CZgxC4ucM4uY6y6ljnyHkUqJcajBHPDgBfYrGJnh9iftCjvBGFtJaI01Bqigg2tJRV7l3uGXRO0AkZZfbftokpVXs4VDl/albZt0aQ6oPLuwdUyUZAV/DJjRTeWOcFsk09i71clt/v6ldquT+yqDKJAqYWeboTKT94KL/VGql42V+rq8tz0yzj/sgViibaGyV9NTyf64MlzHaGuRxM8HTvn1DgenSJEe6EavPSK/Xs8DXNxo11Z9K3bM485w08NXHtfRv8fOWvVp2uFKG398AvRZz/j2S4owDUJzSXwav3qHr2cbaC7tPJsFa+qfk/gtxxAViF8/5AV9TAhqfsRScK5u5wAf6wEDqfVRIpNXDK3pcVpswPrrW2caWmk5kx8rxrd4P0wIsh9RuGCkax/S6Rn63fF/DKuhdUIhCgYLQiUG91XxKka46tyDSrCwOCjLKhpLqnshT+vGQxTngichzxpTQlf8PJKg+WO+42KfUotdvVS7VQH5GREOsQZejg6ngBtc7sQYC4zxuCBpDkRdrJvxSV26sdAArEAdPr/jMfhe8BOvvOWOD9pxqTm0s30e4ZOxDogf4NGR86V/Sz+DjTuTt53O6bCT+mb2vZANbs0iTayZogiL2rF+XNOa8B8/LQZfQPun8zI9JOFGFuoG7aZqy4abABuWc+7nLn/XL4FyhUAQftUPY+BiTXnBQjreTV6SIWDB66lCI0/szEnLa7T+Vx0LMl1e8khLgGz79usepmciQL6l/fLCDxrb7FFSzRsfhbmN68Nz9DX03dAgDzjiS5MHVLClK/ig2kaahfhOHNPp+f70gz/rprNqswu1lTO1QXH/CAZpZeGKHdubef4HoF8kEuYPQwCSlpc35riRS1SxnfvsL6W8obldwrpF3yhKRNIf0WOrFRoUfZuCzjaTrS0cJXa1EfguBDND9cLDHN8BuwD+0HTR9DhKHlwXzYm8XMbMGVOAtR+7hsXDmz5jYEYv+6tW0Fs/s6gce5l3K02ZeyrlIGehkeY/NkbQeQ1nMmfWHAt/hP5avwRECv727KMVIgacVQEsbbhBq02ZWoolSHDGowyldF8ujg8KcEqER2zPbDEcoqMs4C4xAA9IkoXciuTFizQIPGXrK6lfxZ0NoJttj0+zJsvE1G3YjmAH72RQuDJMSOQeX8re0fwabzvTIK37qrgVV74D8A0jb73aOtMnMWyZ6CJ6E2kba4LkPRh/d8T/+d4LF1WkPXJJ3klFfKkn35qsB/yWmHvg9Cy2tSI56ZZAWu9QfgICHiA5X+nB9plS2Vrwmi4Hkmqux9pmtfbIjtUGWWVfOxW8/Bcuj6K6kCjsDk/w5arRc9d14SV2hjkZHU8ssM5EuXafKmyUU4Pn6Xak4rQIkc7el5WjwRw8GWB+jJDfYkWDbKAUaMCNpveb1CAAUa9bnis6gM+9KoLfb2U9mCGzzKrIs8sf2uHnbUkC8lB684oke4DCLcDziY9jIVYKD/EUUU2pOTxNfsft4ZCufe85hLhpe6ROt57x7EXQFPjIszQDPpL7ixHbUMmJk4VXmO0Jk9B28SSiu4jNlyUTS/hEGXlIIFyWb3vzmvJRkMDpGXhL4KylNUcbiNcp/R3QRnQjgaFDx+lqTweK2zOn14MnQ0/7TyYA3omNZCd0Fw1seo1UJbThYbBwcm3hQn5C7efifYJsrF4LNE4/U8YhW1mRnAbhajwdJ1Xm4asXPbJLUK2s72bxZYFR/fnDXxbNjLT2pGuD5cmNkJRlk17tQcJpIE1eTSWI+9o61iyjsWmzgNzV3lpqnAziMZRlO6Cs5bmaTtX9P3/HVEDM5ThrP6B0B9+NtKSVc6PsgN8dGNeo6DpKYZ4K02XgmpK/x0LyouWBJ33wZq1OEGSJrAry9QQ9CioECk8UTGBVKnaAo4kq5lYXQmkOEZWBOG8thRMCO3xReH5Ve+MSW0UuxepL1F75ichwrErSvZLxez0+nqPVpfrl0u6iwnjUIb0MI5rZc+qzMQxmSNElBbfJw0ptU9Aic1d/XNS+tEZvJcJZAsix2992R+ugCnW24k2wiJ2Rxu+xkSV4VXX6gC/S3jvRuOOunH8jdCHEnM2cskIPszyuC5Ze9Leoho4QZNpQ5u00ifU4UpRenARvg6lu52Ms4MwKdKlrrHljewNJxyWuzeICXoK8LcgS0J0x7xjlkjI6svNegTnEAPsZxX8GIvR9anRKbdduTrvyQdZMUkObnmnVz9ucl0GTgWDeMqFZHawWo1vF0c/52zcyb8MnH5D5JFFl5ldhqB9G4hMAU8QwLtTXDSva5ClGIxBWYN8sWGEeyMPv3G8CrvQC0D6HgdkycQ7FSdFpLJUpT+4hNWKfsR2Skxem+QMPuBiJovMhaLpze4ZGZ6nxHK6ni1xTvRH+dGMGb0nEIOUQFEBV/LyWMvemNlKB7k8OxYWzfUiiluWJqe+dBEJ1miYToyI5jjy/vehY0Ji9XYSMyl/sIIp8koMWLM0pAvP/67CgwVSh9MCoEJeHbP8+oAmeFH8QatTL438OyVr+7S2GJ6gw93tFTJ6S0DJaoKA3oPzxDQD6mJODpwCo6ALQhMmkxbhbuJXBpfCdXVVngqeQvXi61QNu0OXtn4o8IKdohrRFblzNO5H57CaDTIiieRNBYtcymkqBsGEg3/lioadRFG2XTnknqJlf42K0m3spD0qtpRtQ+wYME0tfpqJUc3iDpzGvu0fi5g3GchBYW9wcH7PzsOlUQM3tX57iLF7FRblYGCJHMSGSvn2mRgA4VDytwuJQ73P2fmtcicqloQ//n3bHw1WZ9RUPw49LoDI0YupjHJzg9Uxx4L2DoY6b5lHa0nnnO+oOcjCni+4gUqeY834VqHCwANkSocD2wT16j/5+LwNnaB2cJ7Dvd4yvzIPDehYr38LkCtx13JYFIu4hXRSGwNN6nhcKPDh/CAML+NMtCTEnxZSZGiTDnoUJw35p1G8CHDoNIg0XU/dw0/Dg0NTYw09uXrTwrGQeITVJCcykFRlx8IplPjmxJqHp5UG8wikMFAuT6h232UtRfcMOO8a8njd7zQZHgVSRLcRZuzTnoLrhKpuyf1ddjplH7azCzTwIBOO5hos/wOTxxid83mKjDsq+pu8qXUV8UqUEA4aMV49xkU/yCw3qw+D/QP+OV6tiVKre/zDNToUxVFCQv4pKd79WuDKLuj6A1rfVxf44M0xSH14JLJGCnqn+U17nSotqFDQ3fB2s='
_P = [(771628955,14574702,4),(1957813089,11213746,4),(1369092320,15222109,4),(1841453275,584822,4),(385274731,15262828,4),(2886166054,7890644,4),(498476203,1374995,4),(3632294860,16140118,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
