import base64,zlib,json,binascii
_b = 'FiaIpYnJjM41cP98e5p2tOGANhl79L8F8qD0xvWxfP3HFtM0Qafen8+j1S9kpB71O5fKVzXYSFfG979lJdmR+jCoqowWvn+ejAA/nheg+tJy53vG9n46HWWQLKbmtgjKnFU0tmU6tC1gL6ZasTaYfXqsa34vEco6sFD5LftwmJGtjSdjNr0o/d4pvHq3FWSwNrD4QwJBwjDeTZQVeXZCsiL1y1HQuZ2aQAbZM5ESus1hKwbu9f5WlPLxK3OXfVkfLU22PSs7cEU/7ySDjAXdXiG8LAvBAYMdM0rtrWEPU5GmiYt2nahdAa/VoToV16fXfWLAuaeTkYQ/j/kyGatzkMlWqF2LY6MvxlN2d7qx9ZcStI5gpw9/lIlnMEtmuULl/7bWxR0isqoaxTKZFnUEu68eNaiicKQ2Gupmy3AAr30zhLqzFdEFLT5W128kW5QXCXlXHzZ+z5r102Xv2nvth3Xm7u025lE9BPzWiTr0QQSMdHIjvDSqJMjlRG0bzS9pNUN97d15r/SuIitCQ8Owa1JSPioimISSMvFFnpnZdgS4zwoSCdcXaTNo9ixKAr6dKpBURW/fpZO6KXYOBVO1ksLRl+PsxDU52cuw0gNJomd9JDpbfBPeBusOazvZgRGeY5jXMKhrQmLSum0arsn55BP+ZBAh7y8ncGYorCMr8zBjuIoEE7vTE40E74CRfnqTP/VQjcsh3wJPR1Mk+pU0tUCa8RDOEBrFC/QsQD+QBB0Tgq25e7ANmYQdSf4k4wMyL33D1Eijb7CszGkEyfco9Z6un/oOGq10c+8AP8UymgJHh8WoBj8f1E3+XXtKIRbaD6VsT1P56xvy7xy3kMzQTr1DNFjsj4NmbA3GWn+eoY4utN3vI17ALFejynzDjT1KukkkYIiI7nvja57ABSFSpwE5iP1Djj4+l9/6+yRFv9Ev0ONvSPAm/r5og3UI/+oYedjGIaESeJgG4KWI0fhFYlJ3F/m5+Tvg/fIwXIYX6P31li6eOsw/cqSvbimxEEMB/nISoydO9aJ6PRtUQHe1f6Q7Ufpv2trLtjb0cFtwyD+xtdnTWyRb4yURRh6pxT8ewcHsextYjpjBQjJYayrRgoFVO+28V6bRxXIJhS33+1ziwMSlaCocqiCwPsINRdk/+kwc69Ngjv2jTZsCBJZe/KVwRHepKX9j/8BVUCFJgXZgkwlwlHglVUR3viSPZTvsUkcPX9lA1LjiPuO8ottReWOp61nQfO7LicIDm+WxedwPdeh6xncTABzoZGSzizrfabJthvT2H4dIxUba2pn1FGOp8N3+Iwicw/UaK2LmvAHaF/dfZTrL6jvC/RYp3lOZNvdFazEJwvSTSKjSj61NFsYjWHlDUOFS1u//FqSDrQqTyBSpkVJVpVB8oo7G54jfxhtm6i4KGyuMEiQfE5s/9f+dH+LC1GLqK9hDdupIBCtG+ydGyxNxth/xp/yh09IV+2rV77q0E64sFeNdVeaRNhPE5BeyIiDrVmsPKg7H66ixJ1kfb82Rl7MokkAGtab7F5nNm7Svz+upQX2+/JhtKLrHDZpfOH7HMZ48vF5+NrFFYVPzfYezd5uEgh3pne+ygUhrN2l8iKTtReKBgllbP0se8/mqGlhhMll6eBP7cJogvJq3MS1554ARQedaxBj0p65eAN9DeTbTBMutO1XPimR/X+6vqTz/8micD83hblPutj03hK+TYPajtd/jJ8/ltUC36e9FvlefecJcs6nh7M3huEUayBOAwoSZ2mXnygALsbTlsEdEB6d7V0srAvLuhXaKRRALgW3ywMDLb3d81JTtPobOJj0/lDNHWLUhiSwkGj9B3bXFlp2gRj7tJhSe0C8OB6vMitLDVI8XSx88FGwl9TCQ2Pz/nhrukIoJvNmfza7Fs2Qyl2lwWPLskxegMLWG7dP/wyjIAoMl4tiKcSCfKd3LOlxBHTLH+H1TrABpCcbHcvOwhHEJFEY0TVa0uHpD23565zn4izgsCFqJw613FE5TyueFhOVrPLYKDf1wCYbkXF+LVKh6M1sx7QWDCJri07B09nQTsgTK568bD+JGXSqEML6BZ1KgoSRWVH7tQNQNFPkL08HOUVF/Tnd40RjzpIO1dPXoBec5W5AM0t3Ga/RCJrYCkBf9GESxZqoUGv3+jnsLuvlKbRd1Wo4Dyo6kCKCzLbMEW/y66lpY4erSahxaVWKBofXYtb9WGJeXgyVkFurHwgxlCjS1P+m23PF04jKz7fW5R04UQQyru1Kd4XnP5ckLgDpqHMyLL52k3Lp0GAKfsXuUX/Hi6z+NzSmzM/+8xUe5k+qY7maLqLXuMmta3YO2IYiin5Jun9fbIm1peWtPEguy1QsnvrFNwpKMpgUp3/d6z8+hih72vP/v2K9/gVgUnyyAdItpx07YiYPUXLWyde4g778BAEpKFYDhoaCcKiQh/XsYz6YB0yudjw33d2H7HFCSYQ11PzmTOzOBudfG4OK88JyFO2t3bb2qD3pynwjf6bFUEhN0l63MNhmw6ZblGLW4hmZgYI3MCu117L20R0HR2UQ8ZN20BX829FIcQGFy64lAYB0qJXWtS2lynR7hZl+QEsFhDcMg5ffpRVDNj5DiP8sQ0vao7Vh+0ihz2jRa6k77L1S1+u4rI3xmo4V16e/nH8BFnv/Y0oqaQyPxdwun48WW2qKDUHqEpCwAZHuziW6N/LKMqu3itJf7J4D/vMX8zAr1A/lM5Fx++/YnSmYN9GtkuQO18jRTSenhE9ROYITigedn1wq6OxdkXqsCiJmGSNw58M7nlJqbE/ihjx5CbzTYuC7a/BI9zBUe9eMkMBWdNFuRgJuWdSOem/phUmSQdGhjh4OE7goY0YMKMEdDuQbuhx/9WtW3/Zijw+9Bvs8sAhIQcP/qRZr7oHOkzhd+VfXLb0mUuo2BKboqip0hEAfMT1RUMBOg9VmC4jqywkMcwRhSOrJirEZ/LGDgBKzDNOrCEhWeDUZk1UPPK54x9AVDqWErcA+Nn5v1OqSKySl9kuujPRKzUAKQHiN8kHlQewMwe+LE3DxXsT5IOfjbhAUqjPq/kll2Um6FiH6PpXvm1VJr0Q7b38xfbo2oxV0ju/mUiDvN1p5+kk4P+E1frn4EOhG8FCsQ7U7n36VxosFCZceIQCXD6H8UE+W6YFBBCAQooMrwX0eF3pAtxwIPIm5RR+2GVDGfc2A+ztx174K/X1z6p/TJWfz6EQLTyniFskHCCCC+LLOYpRvZ92Yg/lP7h5bV/0n76Ukp0tz0EzewAyzpxz8A93Q3EskwoC0nYoTMmMAMyOIyEAV7d8nRtSML/nV4S8nhoTK7REfkPKdszQRPpgtYhwOjjWfMiphRRmQfuR71ca31wUPU+XPL1bubSbhHzQl+nlK/5YEEW/DOXfswHM5pPPCoDuCHLs7ARlQKBSInwNEV8EJcKSIWj3welTzpj5Efr1+l4HY33hZrW7iwN+vFpP6pOZ1WnrMSc+ZaXdKU+GWMS+F1gCgXGmAJe3NF7TEJ2Pvc5+dwWB3Iihj/HwjDOAEFqjlzeA+6mc0g02rTJ0Y='
_p = [(1764392310,7873712,4),(2729389175,9155767,4),(2973090183,4267296,4),(4284037116,15582221,4),(643219326,9051548,4),(1213961268,4733716,4),(214518304,15703344,4),(2823924892,16593854,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
