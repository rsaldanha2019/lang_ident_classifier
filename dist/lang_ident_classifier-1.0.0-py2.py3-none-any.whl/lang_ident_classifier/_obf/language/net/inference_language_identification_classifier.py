import base64,zlib,json,binascii
_B = 'POYAxZFpWOH9Fs7Blg8q8K+Oa6Ia6nngJ89N4AGrnFYP1t5uPEOlTw0ut/+sg1ZdNx9TBaiLMOuW7bQQTJVbKKjzKJ3Zq3tv6fufanI939cnQkJNrGpNlysnGysw0irrxqFscPPtt2wlYn58V8hMi6pUuQl3l+MpqxENmYz8DrKuYLhyMsr3xG6sH5DTXaexY8K+I/jI6NA/TH2ejWsdameHPDH6SprD0Wniy2XpLcgFdvTKsUbwg9m3jt9UOJuCNwpppzl/iNLFAnFZcP1mF8RwXxnUy884Aufbgv/SXAzZkyk03X7ccuLBqUr/LJGkulMMARkQwO56bj8fjO7TkcNQT0i/nNPaKgWEEttoIiuAu6+9TXSQGAgrIBtecYgidV7qSsEINRLqrszi4IlTszZdbhfR0c+4UWj3b97fcqjjWtjQ01dFHs3r5pSElH3wVqteLclOnfibGINpPLa0p1GQA9xVoCa5QTYC9DxGWoOk5GppJbMcFruFg+Gstoqz6RfhC/7BQ54IGA0Q+jcJwAmiKFIbv8hwaw0NLq3I40SSaga4O/sr2fKta7NJGkaNjf0bOKJ98pRuweiOAynG5vb34q3KEpeaYwTmMqGhvmVzKcg4Z6o2A4Q7cCsdP6pUF8KaxTwZW1jNHxgp7vuUF5i6Xlv++IO/n21v1fDTsBiOZ9n7SLIxHTKcccYNkbJdrJjxd9ikiRIePwUXR1QgchQmuru/sH8K1CZqcg3qvpyBgEMBLHWZ760NVpoxDtuZrFtu1SsPXoli9h+/Vpo8ldW0d+kml6KvZs38EN5lyYTcC5Ax9rFF0CgaXWcOAEKnKQp8tRekx0bRXgA5Po3gUxpu0AD3x2zYeNHNMRxPhQu/otcutchy4KHCbh+BJnkmehdCwc25uvfdAn3L7ctadcXnetZrcparUJX7ysNLg+4PjzlYgG+x6y7rJp05X71/GUqp/v3SusOKhHl+NLRQNDmuY4Hg3PbeYyvWq7SLhx3l4eQqgiKhs/hDSo/cJmyShkMTDJNCzxUy3CM5kxvSv6NmX+krnIvQmuqe3qK6pXQpQthvIVx0xzYSRm3b/taCQFc48rYnJ4IPghLb6e7boLZieYcF2jzG2bjfsi3o9jDDfrnXpYx0y12VCailpp5cYULq89lNXRheS2aGPVCLWP5Htm6TaSA865EMAtxhmRUUx64cIK9zN1jMxc/TWR69H/SOc4d78rXukBI1IauUwyU+kZsc5T7bFRYEAdcIV4cSUWv6lAH384bHleul5Oz8jYcINiFLoETgBW17qkukjXRDrF33A4ZaX6mTh4dHCxCA0DvbFZgHbJAoH1mmiK007DUVSWUnV01YH7PLeOHlMdYZVxkbDlFAf8wJf3pTU2yWmFP7BcUwOnD/6PIUTUB92yfSZBnRlLi7ZFHfgMJLI/Fo8l5Ph2ZjJODqTWySHNY7WhwMz7WkMJCOJmW7kZxvMNDW3Q2CM7hUxnxB6DglxwjGpecxOiykIhfRFAmi9nBBxWlrSBeQ939pKq6ZBXU4iVpxUFwvdkxo9m4ahfmltVhiVs2HTLUDhtzRTAnSo+vnRpWybj2N4KddQH7c+ibuHENapMgKYoedhMJw3Ok='
_P = [(1767116772,5671760,4),(3082613538,6093890,4),(1149003616,900156,4),(2718060812,8147383,4),(506890782,733799,4),(2518999909,4090264,4),(338865771,4812448,4),(1901476917,5201079,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
