import base64,zlib,json,binascii
_b = 'yNGdt+/NttcKGpKGIYqjbYWLtUaluldNbzSX/SDyBgHRCd9+rUe61Ra17zJZ35PprGJqg5Ql5w5wTtOcadIZKnP7EELVVQb9dbH7G/nvaxpjX0HSFjqswZpwSu472I1qIE761W9AHbY6jy5QFdzWN40IK9BnwlcGHcYjsnDUQHL3I0ibFMy+AR2luSmbeIUAXiDuNYxhmOZX/HlAQVMGCkSEtY5697UPElWjZvFR553RdlZ6wpKe+foMLLHpAsIjSwNXkP1EdQ48KmMr4hhhZQCTZFc01w17aPWPtOs2vBTEQiTes5bs9TwxOsU+oBtOyoqXNXoaQYVLVEFefKPTEToefAL0pTcaTjnpu4J7woFhIyR1Rm2YsOwsdVRcXRdqZv51O+GS/6zS0/x4kty4ab2PbOGfxrnsNM4v04IG6opnzCNlGJ1oTDWyI8kMsx5mC4id6ub0DbjE2TxrQLS7jsOSSWSLjClyQ0u+vegroZCf7ZnSVoXXriFf2tpz2qxMsfzgdgkA+PZRFeHQjYdNrdtn22SaTwe9HFmY+AsV6T8EWdwL2JtwXiTAg80kN0qA0oi7MKQrf1bfq/4Hdtd6Aw5NkJ2rt63JBz5w5XgaotOaGitWEAIIJLM0hACRDrUhasAT/qxcLppBW4OukRFXDlHOw+XNRWRcZML6ujtm5IJ54Le7/IhXCEu6CHwJpntO455PUNgO97tM51Q8d6sijFKDM20OCW5kZZg6f7vKDXzD/jRxCdQf4nYHrKO9T/wlIgFmM0sOJ3Bd49ZXT6IqwsPUWJbVftJmRjY9SMe6ecIrvaVzjkHXGH2hlHDKCZj0KplYJTECsPAJtn2QknExeEFdo2bs+qc+AZplKofm88K9W6CLWGupaFMzRB5YIZX5IDauj2FVVc8X7nvtZzTLF0noTzggR8NjOZ8uDDsFRefxdUHbhS3mvp9u+7qWyhKt0gLaFnVKOsQ+8d9m9x0mSXfvPZveuwhqj3OwUcvBnlRI2cCL3CY9Bm5nNBbPq1QqqASYJ29Dx2QbeP6BmvvJh47+apbWofUHbskVTtKSrbiS11r5sbyysVeBTQ6SGP3NWXoy1SkIt12JC7x24HvxOPAawmGESqHMV6DUAZUwwl6G7ECYIWMVR7wMSXIQmK0kmHg6ajAokdArdhNb9RYMR2C8w37Zu+AD9pHeb74FXN+KE5k8BqMUVtA7hDpOSz4b3i65+oT8Sa/zNVeRgjbMC4lfeLEgSfYClvJx+zqfoWIycNEoi0/Jjhlkj5hqedomKiJud4bTzdlbRZaHhOgKY1xlQOzNBcZv+l0Qzl5WwyxYTdMIaSMtB5z9didD530kBT2YqRP+Q89DnRUDvaatnmbwaQFYft+qlByb21qfmE5cjoHpEWtWRCVdoENG6NQFTcjI7w0FH7OV5cfajBjKz30BNNZTFNFwnEWHJ53REwZe8neJnvf6vbLkmDTLuhaaSfpk4CtktJ+efcPOeFUBfRdtdCUOAFSYaHFzqoAGyDJWixGHRQ6q6PIRMwdke9sQ3t5NoyaW6FgNouZwi5SeVeDFIkplaJK2P1T64ppXwM6MoKcCbPS4saDVSXOtjjJZGgUUmMYEQrFE0n0Y8w=='
_p = [(2800397001,5714045,4),(3833893105,15741937,4),(1589345666,5753401,4),(3479851096,8824953,4),(3037713273,10592057,4),(96226502,14761625,4),(3382479444,14924318,4),(3316086279,826403,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
