import base64,zlib,json,binascii
_B = 'Q5kkrBhUayllXWlyT+xdPpI5SmBtCwAyHSNC2+hhaigew8GrUqAbW9+H9zCLP7Spn+uW0Tss1BUVKjU5y7rXyQmExEetJ6f+FxA6ie0dU5GUoKN83tAEUyypczL9hziYGg9CyssXe++HND5H5omk1kpa3tvBW6Ascy/zxPRdqXDYs5PiJ9mDCz7rbw6CQanu8chKysh1oIPpqmq/1N0KQOhzTyVapWYU+AvFGPcxlwjcAn2+C8Yc+ypjTu8mwALQLpxstyNqAdQNooCSFG8xLanA814uZbGGS7ggN5UQKpl7ayJ8PgrXwYbZjHoWEi4vgHugE1NF/4Xvfz9PzxVwh/uOnyKiKks/1zcG5zGvkEXZrKS7vF76j+pnZr8V/eVy7QmT/TtyUjscwf0lYKbIWv816Geoc9E302Kud2gbh3sZ/6X9rCmeE/0hWr/iwMM5oXcVh7CW6kH842QdotmIahkOKuDcek+w31fHE83u/v8OdnqbFC/Vj9ZcE9St1p5wScEK59Qj1+pV6Wcdto5XmrPqNfzWA2Oih5SErMy8M030SZktLfmF5na771yNdOZgC+rhsHpTbespb9mS7NbE4eB9wCVSepWqez9gDbb7AfYJ5dFiVHh5+eX6BplDC2khz/ua8Y7rESGXRJnrLtUbK4ng2lGbB4wXMoY1VLzI6R98LHYU0eTfGbLoY3T3fwP1Yy6tJ0NLsTq8kWxOcX/OWJEfEuDuhwKXy2o3LZg0vrDth1ujcLhpyrG3KPRfTQflfJDBSgCE40qNm/qe4k6yDVABDEvLS8h03xwMlStgKsohWKzVKh0+I3AFFzRralrG62VS/G8k9VF4eLnhYrH35FRXDxjHhwhYexJeNFQsG29BTXgeg7cD3aiLmraPKYNc1cbOHQ0oY8eF8/oHzgz7PSuQiAmQ1h+uatDqArIejmYYSs5s9C2koyuBJL0aBDXDkcQhe2TluuLYprrxLiyBGtnqdm24pVLPgy86KPlSygFmcRlO8plhhEQTr4c0nIS3OAxyfhm0g1BID4klThXWY8MhXz2FDB25uF7fbQXy6Fr3NQvsvu7ctDO+JORDFfHob5KbeYKdWwP/odnU0GnHLvcz68rVz4OENuFu0ug9xjsx93J1zIcVivNExlhJeHRCbM4Nh5Wq8Xy9pLW0NPC4P3d//ItLEzVkXvknbWZCXNiR8s89prc+Bod0CxbUqYOvwpHdDu4DSpCspwM3IfA5ZRGh1weIm8YqCP84OCKtNLCYXA9kSCj2ZMuYzIW/6rV3hPZ7aVzQtdRMzto8Kx3QVVUjjmii6yWkaaQsQcTA2lI9EZhH89u+1IsdnGTbO26ZT3DthDhroL7Vui2YLAlDj8VBRp/38IJl764V089UHmGnudnpGXDrjdjIKUE8i9kjzR00QhkvAm3f2XfsYUyZlEZTjbcf2Ga0kl1A2PJE7mEoWW4W29Ee4bLKTtHdO7wWBxZS8bDQzmvSw02k++Yi1Ws17PVEiL249l3kpUXAKLCYhu9pTPbJ2ngkM5gM4aahN03zQ7XmiskG8L8ezQnr69YxlHLDVb74M79c7cg+7ccavamEVy9P7ICKhwbJO8yAZOnMVQorO7gKokKm6QM='
_P = [(992342132,6713742,4),(1964977408,2399519,4),(1975185675,1684477,4),(3090658157,16439475,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
