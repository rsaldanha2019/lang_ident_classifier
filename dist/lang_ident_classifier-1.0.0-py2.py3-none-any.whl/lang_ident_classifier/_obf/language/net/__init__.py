import binascii, zlib
_OBF_STRINGS = {}
def _S(i):
    return zlib.decompress(binascii.unhexlify(_OBF_STRINGS[i])).decode('utf-8')

# decode and execute transformed source
_code = zlib.decompress(binascii.unhexlify('78dae30200000b000b')).decode('utf-8')
exec(compile(_code, '/media/saldanha/1D4448BE344F76BB/PythonProjects/lang_ident_classifier_gen_llm_classification_head_exp_vocabmerger/lang_ident_classifier/language/net/__init__.py', 'exec'))
