import base64,zlib,json,binascii
_B = 'WpPjx2pu9Irbe9WxM59xq80ZHLTwTsRFYbWGEaeQDJgx+w5v7gkvbLjjliNTY7jmJL395bbiQGYT7ATfQ90QzSUzjhmqs8xC6M0V7f7bJbocq1t/GDIUaHNtNbXL4x5SZBCqXD2uNLCMj0mr6ocqAqcjfXBSRHBUmvpEMuCAHE4QUV9kHc2/WAGkKzH9XV7CyL6AU4YVDD/4x5gdt58c1Hd5VWKCsf2l4Bn77q/1oQy/sbHNhA2Fsha5GJhZPbYVQP6Lr3D39LqL6GHU9Vs2A1E4TVKjzfglzd34q3MasY6UEGtgAXvzhqbYo0PWY7jt5mQHjyyeUATCIdBN0HlCEEBerBRayDxdamzt/CcGijU1ehXrh7/9GHvzMS+i7QIAbXJyRYtvQ8WzDnIf64wjXTqGi4zhL4yhuxM49LljdktSjYa2dgprEgWTQbLPNso+sG2EsyCRAJRfrhWrRHjhsLZuSGp+tndxqNn5gp3Sw2KMWzwr65iBXB//ZT5WRaJg72RZzKI/Tl0MpBlcvWPA1vV+yExZXg+Yx3eenRtYzwWLvNOWchnrOg8dsGYg97OoJnpMYQ/uPkpiwKd1GgTZmvdjHbDztfnRlHPUd59Ur6bEJHYEcgXvTS8b1dVExYTa85rsI4Cppuhxtt6/VOa33Np7wPRWB2/nOfodm4xGbm3elnp9OfGex9kqNO8R8fXc6ThGQizLv7EP8C9aIC0c2Nn1eKzfud5Kq8r1nwBP6zn7Lo4tDi4t8BVYODFvZllXP+lbgMY5pqw3QHVIPK8q/rlua4nhIwpDnqnvXeAVW5/2Ekgewld00ME4Zvk+AnrvgICANGiOZejuGhFtI2EIHic5q/C8Ts6DHmPG2Vv1roUCeYvWC7wAFL+KEI3zrJfbumKwYe6PLbDFO0Im/cGDqkYXDrLP7lk1b6X9rFzCG6VZw48DiIbDSN4heAaCKuJ8oVPvlOM9++7fplL5uH4G+p6+Z/Ux/2rtrxNrBR6hFKc7T+41eodMfKH1mXqK06mBD5AQVWyguHPMsxoA0JuNxeBlxwgAfxuwPDTk1ZLTdNCROlkbA1rtFidlaELt+ugNHWhCotItA0krO7fhJigGYJffljts59AI8C5pvWfiInpJJigC2U8bVBAi0cQsU5bd395U5Yqs+e0qxhkjbCfwR19srt2/pAOWGfpw9SrCuNZ6h6T7Pg/UJJGo/cSUFl00DEAtX82qDUP3DmaASzWxohSp5ibJfpgMM5Z/hbuCsG960O4I2IzNCt//1Uq2V9VFMMBpw1QWpd9i7sWYSqEcBFgOsTVWbUJNuxs6oVtUYcbL8gSakyU7mtwYuEBwOgZPw6weTnxVo9KD2uGzHDYcV1m8t0//Ulqjvx3k7MJhpVNWJKwDyBYuUfIeU46oY9sIWXg8eqEguKgUs2SRlXPUTfWeYLmhZQY8RAa5RUqUw1Yufes2KxFGX6w1tbYpTc76zNGrZqEXl2hCoDU0KKqSH4JGuI2hfwEIWpTnpnfk4JbqVoRojuDSv0uwKs/ONBm84nLpfiZFB18JHFs2HmXIChMtlVH6ySFDXkHsM4H0P9uyRC1vY2KXL8jTr7ldjZVg1dbarbh59YaJ+YET9amF4SCfsNg3ul/Y/jwYfMZxrw9YLZoVImoMo94e2GelFUhXuavrQhvectTyLgEo32fNB8W6w9vxIZU9gVIQBeMUgPT/HlyWXr/c8Sbbu2Vm8eKqyGAP80GchMX/byLV+eIlcx5r2K6v1cObFSlV5odVDJ2eINUPJmF63J4lAo/ulR/gsI3SCaC8G8DXCiECGNU5Jali6A2S5FSrAHAPqFwESBcHkdLItQMKsjADc3MxQxznt0xJMUQpHyF2Xc3DNEI8yrK4loH8wVa79yfMce1TOkibk2InuOLIDjrRxNSd9Y+ppYdLXuT0FPVALyzmU2W6HGONkrXUIhufk9v4DFDtcn7WZ46zMsUCsLoE5pxjvNNRn1YYtJgSAhG77k4VjR9vBcjLpbP9puMaGNHQ89OOTmpDZ/KBPb2sry0D2wljX18ZwgEx38Ioq4LKcJvikjBN6fA8ogG6CnCbmJluFf3R1XaWdc0fGRZv3iU='
_P = [(3001097852,16387744,4),(3463694361,1982236,4),(785886552,6318352,4),(2406962917,11270882,4),(3428565398,12882631,4),(2699474403,1917552,4),(1057738503,11084897,4),(2216728457,9736102,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
def _rc4(data, key):
    S = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + S[i] + key[i % kl]) % 256
        S[i], S[j] = S[j], S[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + S[i]) % 256
        S[i], S[j] = S[j], S[i]
        out[k] = data[k] ^ S[(S[i] + S[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_B)
_r = _rc4(_x, _k)
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
