import base64,zlib,json,binascii
_b = 'CGuQEVab797OhpInV/bJpn20n/DVEemOqm755+HWW96JifCMmtip5+nHe8B/1qL+rhEvEpbzlbEd2QJwHXMc1bpcMjCQ1mducj6/dKkV3mwGFqUiKc4GVSILpk68mKBM3UiDoZC2Y143dwsSP2osNIPzi+tXg+5+yt74+jovv3x1QYD0htCQBpnoD6FCaQ4CpprmgLoscuMxadUP9dASUoxn2l28+3gZfnpq8gGkyiDNvygsTziYj3OSagl673nL0KfZBuxC4Y9rBcvdeyU6DtHUsuc8YVfXUGydSXjRUQ/pV9PtFgdhOaKSJIAO1S3ccJs32xY0dO4n5AeHJoBawn2g+HUoH2juNhmoFhYS31i5ciWLag5qeBnAWM9Rq1FoynPgYcESk/03AMbc+NRivphHtc07EeikBlR2GF3AbVKsTyUp9VEHjl74uxXh3wNY5BKzkbgTxQRZU6GqzBxt6AuQFhjO+fGW7OZ8O62yfHR+M9PFyropPYj3LGdRtymg/fP9Z4ZfC3EcczIDLvLadnIZCFuUoWG0ywJayrbh+hjZZGQz8yXJvr+hNAmcv1ZgzSO4C5RFSDYe0iS7otjKxjNuoJxZHuiVvy2IZQP4v/6WA4NcNH2jb8iiWWmy2Yx2mIGwXRcHzYrtiTOsOnu1AnY2H94Dp/VzufhMt0hSHk54WQoPdjRg3fH3Uj0ovY3desjiVlunW6m+AMqB6liCkRlbgw47wg3dDCskSfTajVipDhzizfFB7CLBfgp2jpVn+8IL44LnuJL/1L/R9q4zMAhzF13IpS9y8eDTvFIXAkQTsJ9kub2WmaJzzUn6vJ5pXCp3Iw3lEyj+0iGDCOkbxqJx57bB/D+pLfkrOK9nyB92PDeFitaWnco+srUGDIMjZvDFM4ga2SaV6gWSgCON3hF8ScvqI3aXHnZdT3CiCrfjTJ/6yfRWN5DEXnfl5mH4JFTgNeyb/6abpeI1Oolz755vv+5hR7YWQGDRxX6+yAyNnb++ohvcrhLx8iqVUprybSQmCAf9ih+Udh81QSXedwF9CmfTbWAlgL92DvwYEARUHWpFnCXElH76MZky6XHTbf8fxOg77WGn8huvv/+2xb7fpa+95c8AgX6pE8ry2Q6OOFz5buUjhqoFN7DBhtZQZ91v9CFqp9d10jO8KB21oYYNR4Rel4QOFdeLR0qbnORD2/vBiykHZPcQK5W5wpKUabuLYuThx0EEcmbN1n2Vp+vAYrUUr0ECQA0WBtVrSF8MED9SWJ5Z9YaXdnbyD634o06hjnXDlKuyCdevaVKA/PfOGuHO5yTk/llDI2zB4jd+jW0CE1YyllJcC885mZKBStJGppqVK55ME6rSQB7aj0yxDTBQd9JRpY5lNnPgz9tvp7swHfAstRvKeTSR4tkd273orrBaDuErt8pW2+Tt8S5xbZ5zJZ/48cC4uhYKdwrA/spUdeH8YPWAGZb1za6XxGcToDXOcEzYxFiTmq6Fs3awH8FhFz5wbqQ2InDWqTnCTGNJ3IdR4FFuM89h+O1arHtsyUpUHSGXqS0VY5LDE4Ez0CNEh2TNFymTDHSwkrt4sdgj8jzzRXdOj0I3rrd03p0D0mN/5JH0XaYl8cRX81mgBQ3lIv0tXLEmlKT2tnJXXKh7Aoedu5WEPIufdTRgEGr2k/KEj3zb1sSkwFgRcbEUAsHW+4umbkx3AdC6v2cLTu1CU5UG6VuwosVYYyjC+XJk+VhMcbfwHTEczOAMdGefQgY9Wu19s5LWpLmxKL55T5kGMaBS+eB5BPfLliUDJUNoC7i/5b0xb7049dTWxwEU0JXM+qlZIj01+yZm5O77Ufy9/eTtVyNW9ShvV/bYzjnNA/lCAh1OQ+d3tLBoMjc0FjovlOWbcEVqlRvg14ELX1sle8TVSydg7796HJQsnx3katCwaJhe7ggk27rTbhnMCn/u4wTZ0n1rgeeoE5goAc3Sm9ghRzxO6d7TSAbVuzwaWb2qDTCyRMllInsuNTgfdFje/yKyfu0ksgPnCL91ngC4Gv2rJWHRm2prAsuLCak+5dilrZjsyM/o16/y2aYnhWRQj1kIFVgnUqlSRH/MFcKz4pupbw=='
_p = [(4269845445,4607003,4),(3784021694,2188395,4),(468610397,2644358,4),(2930026702,728287,4),(4171305875,11221147,4),(2993754093,11448961,4),(2669755079,13831674,4),(3328333904,4954524,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
