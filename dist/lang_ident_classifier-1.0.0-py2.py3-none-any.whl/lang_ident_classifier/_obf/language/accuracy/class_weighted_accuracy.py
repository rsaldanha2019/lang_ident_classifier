import base64,zlib,json,binascii
_B = 'n7JUrfVMVC2bItmM4Jc2x/+of2/yamW/OCpXyVW3VQIWpEm7SCG/skK6Z6dxdGqjJOhkd/qE1LATr0yrMuyA/NCtHxTbgPkcFKHWQJCVESIw5holyHg+Ec6sVkRRQ8yh+czd/jOg23iljHvWeQbriti6zZo/Q4ALnRi+eI0ibedlfCwH/17R0gfYzs3uSzU2Zsz789aEyaE+2Bc4izck5vWYqtR+1EIDA9rGPOgV4p7XYIL5ai0MyqP6rMgtdzviREGc6iBjXROX0gVQ4npceWhgrYgPoWosEKQTVivWCZ3hdsgdZLnYzgsO4kxNXNq9/s24vusH4drIzs2X5v4lHwhhHzs1l425xz+0RmsSrzc5nBMlXokcAq9iNS/LEBwX7QaD9sG5E7YlXkXnJhvRNyHfXY5mrCUogdl/YVtstKjFRlijqndEY+3N8IWPjw5q3ud6wr5iyBLuyCwha4jtPaG42dJN665pY+VGIqs+H0LpzMvq8stQkwvUO3og6S5XCeVkd0PKtgrf4ZrWz0Ck1KPlMFJi9+cB7y8jEQLBKuRpwjSofjCM4fVvGBgQ95RIXuREeu4jVIRUkfFi9naiSTECUmDRPZvN+okalypr5y/QPtYF5b4ifkHzuH1mtMtsivFsdcAUqRJZukApxFGSMYjaV/xlMo6ZQzYAS1PkNcj9g/YGUZxGe90gPCH4NPLBjFc3JwkRTTxVOYuKG6uZ6pB+CYzJ3mRBONIkx4NoKCFG8mlTO+eW8jqVkG+dSLv17ABeHoIoixK09A/1WunRqr9Uz3mtv27q9N6+dd3I2XqplkhzHXbzrN+/verJiH4CC+kLJfvqgpZjbV4yptOIX11YW5pa3QUNlUmv+fbMasIE6/Ss36JrZx27Z5eJFhXM8N74IhC9+GYCkHPNXmOufCYrIotpn0CCu+zJcBahDtOwgEB1HIaZSj9mTSd3XciG6KZEDc4xZCU9MN/LLZoLZwOwnEPmj37Wp0Xi4irX1a17KU5KgKzAwQgBpM7iUtdD+y2gKYh223YYlQitrwF3RME2DUnWMttExIu5aEbKeQz5MUE/r6ij2PKcWSWWzFKEKkMvALqOUFmhTXy/lqw4nt2NgH8rPHDah3JCUD7CaGVI/OXn4OS1vaNzLXcts6aO3A++Y8HulKjr3goxrMC9ERUCQpwD79Wwvlbxfft/2kKHSRpnB0PgNRqxpC7dKU2Rik4pHeamCpOdEM8wkEdIXoPpwI53Bm/94otlS1Ju5lcdhG4Zt3ETt2bhHSb7Cge49G6gTF1kHAuvjpe/OSUnk7u32VEKg4AAsrkAgdHo+W07TgLcT2gellU7ehCiQyFlaswMgGLKiaoVD9rv0T4gFAktjjxB3eJMJBqCPSUozdRipJT9d9Fjq58dFum+gyJoalQrn+XOiLlOLqRiDarCiY890Qrxc2DdDRjrcqGf+DBzDwUGHy1rWkfO/JpEp5a5mbmahrTz0nxd1QGCY0p19jD6mkFHgU/KpGMqJfW9vlo1ISBtcKYq4FJ/rwj5/xQDfbtxQJY6e916N5M+RzFREt9kI1DLOo3YIAI9dkngoF47P1hWPARVYvSxCG1E4974tLf2uufuHNY2rFXRt6wB9GtuV6eJGihJ1gFflvV+LVMMUPpx5u4tXK529tUGTnYJSXJD/qHJVGfE2apWPvsU69Y1fOPmBYc5iOjJRtdSkBiZoeBhRZGz3khzvrJDoabNj6xVsBGnAtjx4D/+su7mxMwVzKSNFm4qstulEfayY0pd9jhWW/yDaTO0zemziZtgjepUJQIKHqq3Qy1YgKC1TXVd8R0kPnKZdGyGhBwa6Lyx4QwosSVDUWSlq/tNEZ42EQQepu82gr9x1oJ9JGgGZrss6khYqS21goLvi1st42MDpcqLh6eW/teXqbnAKgpfXRvXDyHhv7lgtD0Bs0ME0AwYgjHmD603QRjWkyaxEtoQCA5REcAbhIg8JVdb0fBGBsDy7HnU4+dsvSo0qSZwVRQM3CYq+PfUQsbYFzgV+oLeA7Ra+Rs3UOayg/vEYQidKwkJqJs+wQghkiod1mmTY4yrzacbdqNLdDpQRdEYZoqfsIUFodJQdGE='
_P = [(3891781615,10429973,4),(2924542525,9647446,4),(2407016227,10802555,4),(2945997112,10442139,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
