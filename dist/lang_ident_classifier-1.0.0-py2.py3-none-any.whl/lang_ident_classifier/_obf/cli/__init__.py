import binascii, zlib
_OBF_STRINGS = {}
def _S(i):
    return zlib.decompress(binascii.unhexlify(_OBF_STRINGS[i])).decode('utf-8')

# decode and execute the obfuscated source
_code = zlib.decompress(binascii.unhexlify('78da25cac109c3300c05d0bba710e49eccd12984b17f1a8164095b8566fb06face6f23ade3cdd231929bd6b5e414cca3a91ccc322499f7b84bd9e865e133292f50730b5174c2373196f820f3fe519473bad12eff7add81197556e30545cb27f213a1ec9162547ea5f92f44')).decode('utf-8')
exec(compile(_code, '/media/saldanha/1D4448BE344F76BB/PythonProjects/lang_ident_classifier_gen_llm_classification_head_exp_vocabmerger/lang_ident_classifier/cli/__init__.py', 'exec'))
