import binascii, zlib
_OBF_STRINGS = {}
def _S(i):
    return zlib.decompress(binascii.unhexlify(_OBF_STRINGS[i])).decode('utf-8')

# decode and execute transformed source
_code = zlib.decompress(binascii.unhexlify('78da4b2bcacf55d053c8cc2dc82f2a51c8a82c482d2a482c4acc8d2f4ecd494d2ec9cccf8bcfcd4f49cd89cf2f28c9cce50200af66123e')).decode('utf-8')
exec(compile(_code, '/media/saldanha/1D4448BE344F76BB/PythonProjects/lang_ident_classifier_gen_llm_classification_head_exp_vocabmerger/lang_ident_classifier/cli/__init__.py', 'exec'))
