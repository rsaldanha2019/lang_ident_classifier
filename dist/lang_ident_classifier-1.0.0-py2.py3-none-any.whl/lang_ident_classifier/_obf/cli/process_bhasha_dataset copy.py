import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_b8903b_0 = 'OJNhKswlpOWF1aIPC4PD/t'
_b8903b_1 = 'V+/H9Be2T2vTuoZbo+lOh+KLXRjie/60NjkYZOuCpplBGJ'
_b8903b_2 = 'aE0Ol9owsbPT7HLeaPItEBnqd3TOkDSBrlhqc+tp7cNT/JxDYNrw0lk'
_b8903b_3 = '47L/Mi3M5mu1eLIQtZoIV0cps'
_b8903b_4 = 'k1zJpMb9Rqm/fYoyilSy7BZG2xEdbo7TI87p90LYS'
_b8903b_5 = 'vlprVGroh2/05Gfwj3DLJtNneb9hzpL5irUQyGZt69mKdRX+9Gn9RiLwLCkGh6'
_b8903b_6 = 'wXDHAyV1oxfU1+Wvy/y/HRYk/lfEBDcJoIczDf5qQabKgO1Bihy4TB2EFa6/yN'
_b8903b_7 = '0jlSgqvgyQ2GtGW8+vOBzpVh3yjYwrdMYlMiRAugMVAmXPWBjFNr7xtfbbN8lAGh'
_b8903b_8 = 'dhQnXBIqLPsntqj0F2MU6b+TFbXzdAEG3JeGLq9+WPU'
_b8903b_9 = '1MgKPUeoLT2dihTQg45onuVEH7'
_b8903b_10 = 'wv6WQzRdEiWvTEfu8JJ0W+TcbDXV7kZ/pQHWBzuIU/X5BnRXu'
_b8903b_11 = 'GBfyEc9VkvxcTiAkBwRGJQduCiyINaWG+V6a/A8r58F4/DjftfmK'
_b8903b_12 = 'Onc0YiNFPO4cZYEI4+EToZ+ZSZgm4LHSaRHakbHtgeAiWJKdjA5n2XxiWqCx'
_b8903b_13 = 'ynCVy9BSCZBhX7l+QbhpQ2i7ang8eegUaqH+PftRksjPrcqc'
_b8903b_14 = 'oho135ttze9a8dtr40Gs6KNLgnya'
_b8903b_15 = 'odKtO6umjBlRn2EhzvcMD7CMQTvZemXaZZN2B4'
_b8903b_16 = 'wT2Nt7vNhTTHIU9Yu+R6f06Cvtc4K2D0swZseHpMCmGQEwpC7HEorFl'
_b8903b_17 = 'CR/r1Qe11H4NhF3DxqmTx6zEwtCUbUgYH7x0DtnNMCIk7GSswI'
_b8903b_18 = '3lz9HAXtek/VnKmnAQHswRMnEalbEJmAEEPjsMAFWu23s97zuHGQy'
_b8903b_19 = 'VeXytc5rDJNCsUFV88cIvEWxAA4fCNbYhlJLtXQ'
_b8903b_20 = 'pp9PavqyZrhP6+2mv0shhF6wBfp0AIQZ'
_b8903b_21 = 'AG+ybLALjGTLk4E1fn1885zbyftMzknb7lrmny2sFxtGWamYt0XXcWr6YEy'
_b8903b_22 = '4pnUJO072ovAX0iw/Kkq1JMbgKkBSxcezD64ARoURILkf'
_b8903b_23 = 'lnpsKNuqoGYoHwSrr7sP1YDsrLkSFD6cexIeI'
_b8903b_24 = '/r0234L2t94l+t0xGnP5ulhKcn6BxjO8KL7QdsH'
_b8903b_25 = 'DjW/sp2PWnntby9CYE/G'
_b8903b_26 = 'kp8DpQ/hqujIA2E5wzBtRJhJvMNLQxrpY574r3RzTmlBM'
_b8903b_27 = 'Cptbco6H2ZsUUfn8ZDhaHkczIKY85UmH5rZw44uuyp'
_b8903b_28 = 'ged+EfhtPwRMWbg0PKa1uQjQ4YcUW9TpSXRPV'
_b8903b_29 = '+zUQoc2JvpnZ2OnO1QU2LTWfvItuE3z'
_b8903b_30 = 'ff+EAIM2Loi6sXZhP6L9H62/uxmncOFtzvcfNx4o7S6fsT0nlOF0A'
_b8903b_31 = 'FCN+Vbx58I7KV+Qa8CDdGn+lX7NQulcN0wVIx/zFaTLdDh2DhLKRVGW'
_b8903b_32 = 'xxoG/7JGiY/m/WhdQugIZdquch0WMdmIBifuWGFaFbx170k316KV0evb3lGcbAVt'
_b8903b_33 = 'AnozVPmCEl26Om37DoKaOs6BwSPPY/FiCsJ1fV4EDssAr2'
_b8903b_34 = 'EJ44c6RzaPGnHbv3wb8FCzHeiYRo9wf2XG1juwG0tZj7SWVQ'
_b8903b_35 = 'GFotkIWJPJ179FH5A89s86XsZ36FnB1AdlRWQnTQ9Iktzn9ZRGT4g'
_b8903b_36 = '+kfMIWD6sWMlG0JHQT69I'
_b8903b_37 = '7JonAzhj7ZbWoUerdZcB4Gy6Evm7m58AK'
_b8903b_38 = 'xOyLV2mFynlqU8Ucvum0kr9AYfsk3hJ9Uuvv40Z'
_b8903b_39 = 'FmqI7DHl+2/PmqYmPl6CadyrVayGP0/oAXyFsKC4Em4qrhJA/566dx5bG/'
_b8903b_40 = 'igzBfSv3SfDLuEbCdZ4O25vvf3'
_b8903b_41 = 'jApqpDGTG0sC6I7tE9tGnQHXVjGzAs'
_b8903b_42 = 'MR3Q19p9Tsfwenbm9IHRgwgVERmBbLNsCI37RWfYP6VgjS3CxPzL'
_b8903b_43 = 'XrN+FRugLXSlyxmhN3KDPNdB90qS37/WqKeQS2l4Dat69Kq5A7Gt'
_b8903b_44 = 'Fnayh1pA6u97FpgFNd3+pq241WYjDwMZLiJj5DYEzeHYXtKihz+oJaZzPuy7'
_b8903b_45 = 'N3nuuhoQdaI9YqA2VsqMAk9dzVDxQ6m8hAXiiAISpDMAHAWkkX'
_b8903b_46 = 'yUrFegyGTHyh8qbTfFojFmZ3V3eVPuDJtu5aoWzuAehp4RXKtuErdCD2BrNFbxU'
_b8903b_47 = '9H6f6YI+R8u2WllH3OO/BqfSpMKJaApWlvNhKgnjxTbEABUracN6'
_b8903b_48 = 'VZ7Y5A6iYtUwyxMjHTqTYy'
_b8903b_49 = 'wukvH3XTv2XWAKIQLvgivLeJ'
_b8903b_50 = 'DUycPseqcfUkoc9Ppf22R'
_b8903b_51 = '5nE/NSV5MIcmH+S1kr06DedBT/qkyOQU5F13fqZEoYAMrDsFg4tYJHbZe3tu'
_b8903b_52 = 'uViaox9wTc0Srh3zxB9ctXgEVLnecWAOgts1xyTruv+mOYI2pfSvw6wM'
_b8903b_53 = 'I5ioEaTSZ6GM9PYnandJ2TZ2dPBbthOniJSdcrTZLxkOolg'
_b8903b_54 = 'uJbHowJtcPpyuaDKOQ0lyR4S2vzXe86JGkhTRxwvEkC0hLwFWsPbiqW'
_b8903b_55 = 'eNC9e72haxxXk6mhZ8g18WOTy8Q9MBjftItoCH57mpY6ir'
_b8903b_56 = 's2g/LVmaNDbqT5CBQWjWIpkswhT5blQPEIln+91TJfBLlJE3wLeJZ3gGyUMtBx'
_b8903b_57 = '4O+9UPEKAaBmTH+2Uufq19r0cQxooztScbpjjp8G13YlN'
_b8903b_58 = '+oYVn9NQ1fKf2ZXDpK4EGN/pwSWQrFm+RYQ'
_b8903b_59 = 'J+cLxXygABMOrcCYjOJBmUmFZ1E0MgFIGL6Pt0PSdPKN40YHj5rWoWF/DI'
_b8903b_60 = 't5Nh4Shd+47NkrohIs66ERJH9T19/H/d2FgWAGOXouroLMcXu'
_b8903b_61 = 'soEAsYXytC/1CrFb9OeYwT'
_b8903b_62 = 'p9JM8zvg+C1LO15sBqgocds9cWzEecYBUoOutASFG+k7kfaQcKhiqpL3LhrBy0'
_b8903b_63 = 'B85u4Z/G89j45mi/mGligupbPQFq9Zajj'
_b8903b_64 = 'kikWA/NmGvY5Q+QMVwW1leR0X9Yq3'
_b8903b_65 = 'WsErt112D9SjHZiN0q7U9qN'
_b8903b_66 = 'HRPEF5ZkuSOIj/wti8WKxOvczX2jcVjjvSEhgjDflgfR/bR9L014PhpZ3Q0a'
_b8903b_67 = 'hjSXpxi7L9xgl3dG/Ytbv5e36OzoOMThUZeFryKL80'
_b8903b_68 = 'ilZW4xaPywaTnBkC9RnYGZflUHvBKV7ZGVcvYwnJzIz6+ycjX'
_b8903b_69 = '/WtfZSok4N2ipCgnR5ObTSW'
_b8903b_70 = 'yTU8QbA3L+WeQHALhzptuNMXZGdn0BhXWoD0kqZQEdgs9XI1CNpH'
_b8903b_71 = 'S2UepQbLY0CNlAeHav/Lt7zzhGjwvoZW8IhjOUZflpBXRflC'
_b8903b_72 = 'jRGx+SophGi/gmFq38/fZtf'
_b8903b_73 = 'l32Z8RVONT5x+CB3cwg=='
_b8903b_74 = 'mIwpZl6MHCkn+p1jpVcypx+d+kF/jepthyvV0BDpaXGLm4W'
_b8903b_75 = 'Et6+CY9uM6gRas5TQHs8tNUZAdqBhD76o'
_b8903b_76 = 'TKfu8uOQxouqvbbD3yED3V+8fAzd2c4DR61dR2wt0f+wI6PePlhu'
_b8903b_77 = 'Iai0BcggCyzj7F3a1LZPe43Ai44nZHySJ/kDcsJN5mLjJkeh49/'
_b8903b_78 = '1YmFeifQA/E6O6A3fIy2OTRnOX0dq9W7kwM'
_b8903b_79 = 'N2Lr9mg8ip011f6c6YJN3no7suKe/GDY+bsGW27RG+'
_b8903b_80 = 'RzNpvXojc9XRheLOvLTetDAFk09FxfS906wkjBIWTPxLrdmbSL'
_b8903b_81 = 'D6AaCqQD4Be23jkQGpsX'
_b8903b_82 = 'pgYAyJmQgPi4VBo2DwQc4W78JrY/WGJKU5'
_b8903b_83 = 'o8XIugwGxpCefvdDSZhfs2+OkZN0G8DZIYn0JUEW'
_b8903b_84 = 'PVSxtbZPn+Lonl6OvozbtMlmNgnMuhu+0Bive0mI5eNpIweTP'
_b8903b_85 = '2CLrDeS4fzotmUtR4WPlJVoY4gx5arvGKgmdv/5mB'
_b8903b_86 = '4LF9kurFNAe6bqUFsoAvhwFVrVBp2F90DnIF6Qmnt1lGiWQowVxMxcvYlxIcj'
_b8903b_87 = '7E875IGAwAJPO5hp3zY+Qd0uG1aUUEVCmYjx2SAd3fbvLyPx'
_b8903b_88 = '2jaGwQzaVMpZhz+OLtq/xns9OscSKLTXNN'
_b8903b_89 = '2HFokx3GYC/s+ZQHnJT/aoPmxurq8keRAPH/9T0YSAaVH/O82Vf3'
_b8903b_90 = 'Vl7m3LUjYwkHiscezUJaSR45jIg+1Krli+N'
_b8903b_91 = 'lsXUwLCdEXnpiN8dxaMT99keWtSQzTbXpQ81gTXaiAd4z'
_b8903b_92 = '1yVxTGWPh93ASmx1IUS9DgZ4zpLvdmZn2PohGKpMXjK2uaVi0VhOqLSNYTVUvh'
_b8903b_93 = '1tODjrRMasa0Uw93O1T5Ci8h+ufU'
_b8903b_94 = 'HrDm80dGmSAkcVw8mWO7hasw2qrXVpu6C1nimyJa2ztqgqMqzxw+V9ufmtZQW'
_b8903b_95 = '2OSeiu7NHPKrsdj/OgkNMG013RqLjlu1/DG9I4izolIdljide2SnemmHp2uTZf'
_b8903b_96 = 'Eo6wwUkMurj2MjS9YYbD/bVWqe3Qb7AJ/0S/AvV4tZYVKf'
_b8903b_97 = 'HUmiAXbHkPHGMKSz2ZL2yAfk2E5T1sV748eu7jYWj4HrztYW0MaoqRYDy'
_b8903b_98 = '104uOhDfzHm83jtdqNsRjMWxRdoCDJX'
_b8903b_99 = 'fuYrMsRnm5W3VUoR8qZ68j+'
_b8903b_100 = 'resAVvu/eSnLlviPIVm20gH9rdAQqYYpl+ayjXWZ7gEPwNrMcRfEjCX7qdg9Qm'
_b8903b_101 = 'l9ujFPfwWVyqit5p0/1NSVYKVkZlf0cg'
_b8903b_102 = 'AN99SRJLFPjPdsrAhUez7bJDx9Aey0'
_b8903b_103 = 'D1DnrVWIf+VtkXeAxsRZTddWlgO2j6e2flpmXUnHW3CIBkw0G'
_b8903b_104 = 'c60X4BeBFzc4QQUrFApNywiZlIqxUB6HFvx47oBwZXa2Y7ptjhD3b'
_b8903b_105 = '8QSKRpnx5V+1uSU0kDhx8Pur5tXLf6NK'
_b8903b_106 = 'ezJd5+JHMYzKZ+EC4bsLG/+p76+CQckmFiK4LlG5uZlvBkFzfbf2M0'
_b8903b_107 = 'vMyBBA6BIeKvLTlNqJGev7XZAW+v9OuP+Ha6YUvEQ82v3Hd3Pyr'
_b8903b_108 = 'Ba5pCYlMPV1xZNcJ3ooUYLZXasZwPKTKzIGtI406hSfTxxSoRojQMP4P'
_b8903b_109 = 'RXEzMNL8UBBkBevW57Ua6FMY8Qr8CA/+'
_b8903b_110 = 'w/wvV2HbxkjArZAo7fUvDu9JJU10wWrvl'
_b8903b_111 = 'rULyQSLZZ49qwDaawoTkd42I+ZUvLZgtk/1iSS8sqz9qLYH'
_b8903b_112 = 'jrm88RTaYyzWBQpJzElpksW0Ciz5v1bk'
_b8903b_113 = 'EWLi9KckqOZlT+hsE3HWXwMq60q6kwqo+WZVqawxaKYo'
_b8903b_114 = 'pmUBGt7LWiKCPrrftIchxTaCoNs2i9M3XbG+95KatSe2k8eqf7c2tKF57Z9uOgQ'
_b8903b_115 = 'PvukFaDQhcwaXi62ST+T'
_b8903b_116 = 'Z93IS+doUhsPXqmRpaQPli5oyHQNfLg1'
_b8903b_117 = 'zXLKpZB3x69vMCfA7G0kmgVkG/kNVe'
_b8903b_118 = 'KdSPVI+tP3JQ2neco7G2DM0Yr'
_b8903b_119 = '3aEh4LncxxBjxYW7MfBJ9GDXVmebgGKPNUa+lW'
_b8903b_120 = 'B7Wrk8sEj6HeE99EO54uic76+6/qLzAxKLJ1CttrzexoSsmhWlDDhWnF1Dik'
_b8903b_121 = 'jqH7aoMz1vT5LXcxGHITP1AHG/s5r3SSiv80IBdtOYh'
_b8903b_122 = 'qFICdf8Sh9fcw7yXDjF31yw4VA9mfcykfGh3fceZ1Cazdvhqm12Xly2nM4'
_b8903b_123 = 'JH1Q4tOGhO1d9jvbCXnZOuPSvkiY+K4z'
_b8903b_124 = '9AlxpdPfg54Azmynm14beN5fCWnwsz7g9gsD5iJ5r5k/EZ81H2f'
_b8903b_125 = 'LeP8J3MD43zdWBTKhK2gnDRPVg06rH8zkR+Lp2ixBAnD0zY741EvP/TSIvp'
_b8903b_126 = 'tGfCKG6K8PFehJd2JLNMTnDtYYVxS+qZc9d9YMf7Zh'
_b8903b_127 = '8LFdCD5EmalwHVP7CWQ5sbyNDlibdnQ2ikPOSIwksB6ygqVX/BWlUb'
_b8903b_128 = 'V6LcvlJIo5oBqiGYWkRjJfZXIznDM5n6E3W47L6'
_b8903b_129 = 'It7A+IXCECtxX9GtKLzBXr'
_b8903b_130 = 'kqx/zTBv2bAWoq1DJt63/9jsNs4/zeYYDZ1fvFiUlbyhlDcJ8do9+'
_b8903b_131 = '/MmBCugWxdifbTBl2UQwJ3ZXHGUfOE3H2qRExC'
_pls = [_b8903b_0, _b8903b_1, _b8903b_2, _b8903b_3, _b8903b_4, _b8903b_5, _b8903b_6, _b8903b_7, _b8903b_8, _b8903b_9, _b8903b_10, _b8903b_11, _b8903b_12, _b8903b_13, _b8903b_14, _b8903b_15, _b8903b_16, _b8903b_17, _b8903b_18, _b8903b_19, _b8903b_20, _b8903b_21, _b8903b_22, _b8903b_23, _b8903b_24, _b8903b_25, _b8903b_26, _b8903b_27, _b8903b_28, _b8903b_29, _b8903b_30, _b8903b_31, _b8903b_32, _b8903b_33, _b8903b_34, _b8903b_35, _b8903b_36, _b8903b_37, _b8903b_38, _b8903b_39, _b8903b_40, _b8903b_41, _b8903b_42, _b8903b_43, _b8903b_44, _b8903b_45, _b8903b_46, _b8903b_47, _b8903b_48, _b8903b_49, _b8903b_50, _b8903b_51, _b8903b_52, _b8903b_53, _b8903b_54, _b8903b_55, _b8903b_56, _b8903b_57, _b8903b_58, _b8903b_59, _b8903b_60, _b8903b_61, _b8903b_62, _b8903b_63, _b8903b_64, _b8903b_65, _b8903b_66, _b8903b_67, _b8903b_68, _b8903b_69, _b8903b_70, _b8903b_71, _b8903b_72, _b8903b_73, _b8903b_74, _b8903b_75, _b8903b_76, _b8903b_77, _b8903b_78, _b8903b_79, _b8903b_80, _b8903b_81, _b8903b_82, _b8903b_83, _b8903b_84, _b8903b_85, _b8903b_86, _b8903b_87, _b8903b_88, _b8903b_89, _b8903b_90, _b8903b_91, _b8903b_92, _b8903b_93, _b8903b_94, _b8903b_95, _b8903b_96, _b8903b_97, _b8903b_98, _b8903b_99, _b8903b_100, _b8903b_101, _b8903b_102, _b8903b_103, _b8903b_104, _b8903b_105, _b8903b_106, _b8903b_107, _b8903b_108, _b8903b_109, _b8903b_110, _b8903b_111, _b8903b_112, _b8903b_113, _b8903b_114, _b8903b_115, _b8903b_116, _b8903b_117, _b8903b_118, _b8903b_119, _b8903b_120, _b8903b_121, _b8903b_122, _b8903b_123, _b8903b_124, _b8903b_125, _b8903b_126, _b8903b_127, _b8903b_128, _b8903b_129, _b8903b_130, _b8903b_131]
_c7045f = [(60169,20694,2),(27612,23764,2),(21884,46322,2),(322,19521,2),(1592,55007,2),(14554,54409,2),(41663,6435,2),(57076,20567,2),(47483,58150,2),(55885,43038,2),(32288,52450,2),(60964,25399,2),(19797,41998,2),(52348,43789,2),(35707,42730,2),(50128,31833,2),(0,0,0),(0,0,0)]
_b21a65 = 'u983CA=='
_35933c = 'SHZQa/I9XxYs4ha9'
_a5993c = 'jawqQSrp2AY='
_f6c043 = [101, 81, 61, 125, 4, 54, 23, 63, 68, 43, 5, 20, 25, 28, 56, 100, 103, 79, 13, 39, 7, 67, 91, 24, 83, 50, 108, 66, 74, 113, 73, 77, 1, 93, 36, 78, 71, 32, 53, 110, 3, 57, 17, 48, 22, 45, 10, 9, 31, 8, 38, 15, 82, 70, 30, 116, 88, 90, 19, 26, 75, 51, 2, 95, 96, 69, 98, 33, 42, 87, 102, 84, 21, 131, 106, 92, 80, 59, 72, 41, 16, 117, 6, 115, 109, 76, 118, 119, 99, 122, 97, 123, 124, 49, 64, 127, 128, 46, 121, 120, 47, 18, 126, 35, 130, 52, 60, 55, 29, 27, 40, 114, 65, 94, 89, 107, 112, 44, 85, 12, 37, 104, 129, 86, 11, 111, 0, 58, 34, 14, 62, 105]
_salt = base64.b64decode(_a5993c)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _f6c043
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_693551 = base64.b64decode(_assembled)
_bdb8d6 = 32
_8fd62d = _693551[:-_bdb8d6]
_bdb8d6 = _693551[-_bdb8d6:]
_55b525 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_c7045f)
_hdr = base64.b64decode(_b21a65)
_nonce = base64.b64decode(_35933c)
_km_seed = hashlib.sha256(_55b525 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _8fd62d, hashlib.sha256).digest()
if _calc_tag != _bdb8d6:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_8fd62d)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_8fd62d, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_99c41c'] = mmap
globals()['_45b8b5'] = lambda i: globals()['_99c41c'][str(i)]
_x = globals()['_45b8b5']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
