import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_b0cd32_0 = 'nK+o/q6fPvvsgqwu5AAwC5vuYLkFn78lc+t1q3tJJvBA6'
_b0cd32_1 = 'Yt3p1h9vQ+34+ej3YSzZcWSY+K/kjw3ue7yjyNLp'
_b0cd32_2 = 'NfbcH7INkPcQqCwPYI77OiJ3SAAcNeS1femMzYUizswJD'
_b0cd32_3 = 'sL/AOs7/XVTfYF3uiJJVrx3h7p/WecFr'
_b0cd32_4 = 'OL3Hdj85GTg9pp4GLiWSpvw'
_b0cd32_5 = '6BXKc51tf/cnBWuG3E4Xn8U185RZTnEsKkox/4MRG+wlgTjmfmGWd'
_b0cd32_6 = 'WjDTaBfac8nRNRXKUzUrCAx8SZ1y'
_b0cd32_7 = 'N+Pljs3gLAgWpZhIQzIlRIXv7W00'
_b0cd32_8 = 'dfZFEgERTmjUfW7k3T2jrkLb6fBTTE6tLerV4AZgaf0NgEjXMSqcRhFz+H'
_b0cd32_9 = 'm6LWV4EB/eZzBlDxGfow7Co7wd+tyJeb4M/IqMDMzmI'
_b0cd32_10 = 'FAOD/7LPfQ/lOR9mdDS+k3b4BTUbEXOnOd'
_b0cd32_11 = 'LP+elySYGl/hD2lgWgG0916'
_b0cd32_12 = 'kHPwEon6skQGNwTUK3eFFyzCJl7grYC3vc'
_b0cd32_13 = 'Pg73h3UjyTwy79MaZVBgU/58'
_b0cd32_14 = '441jGVbFwoD+ilP3A4SlPaSDY0Dj29E0hqbR6dEOEF+P'
_b0cd32_15 = 'NdD5e+LKciCtqITBUWzCaBUO6jDPa3U'
_b0cd32_16 = 'JEnKi0/yFtN7drk3KtxApEBV2+NdIh'
_b0cd32_17 = 'ptEQ+PjW+X0KzL7AGPiK4qG94+Cmt8uso+0'
_b0cd32_18 = 'T/zQM0wTwoQZrc1Stvo+rkNI+cUP9u3AN4I3'
_b0cd32_19 = 'CgFb4fE6xkXgkZguPwNcNouF506CV15x5XwDbxKWlev6iWdX2BtmcXbClL7B'
_b0cd32_20 = 'R0mfwocDndRT8dJ821nTpivyUaa4Irs2a5aO6HkDoY/'
_b0cd32_21 = 'ICr75pB3/AASvE/3r4vjhU7FmfYc8zwI06ueknmI6D5JJukJMWcdafLSVH'
_b0cd32_22 = '8ufZehYtvMgaS7DPeGUdLQMyqTA+rYZtFI7bvhtPzrMNPe1NxW0Ok'
_b0cd32_23 = 'YxAx3M82EZcPuaUwyJn2Mj/MIxw7rXYgfggRjmV6lfaVx5Yv6iR8tmlv7BoU'
_b0cd32_24 = '49PsaM4aDTZW9lhgdwphorqp4JDUcb+hSDPsBUWSnoRUAEFL'
_b0cd32_25 = 'FWGL55Lo0QW7bFVIsTzt93qTSImxQFNC'
_b0cd32_26 = 'jgJE3uva4xkEfcFSjUYFlFforVG2pdf8PHxRCri4OgyEnJ4Yvd/FT8'
_b0cd32_27 = 'z0rTzveUCEHUdg6Aoztyw/lHH'
_b0cd32_28 = 'K5GoXD1hGypTenSYacfMBvC'
_b0cd32_29 = 'F/7k5XvzMFz1Kfos61RT5VvDl2WPfasCwy3J/Iym//V1DU98WoUl8rhpqJRzosI'
_b0cd32_30 = 'ywP5pa42Hx8td3N8xkXRpIV2N6j68/hcgxJNP2zj5QtNRilBI'
_b0cd32_31 = 'NnIUG+LzGSYjaHkVVDfjfObg2lQQ7UpWvs'
_b0cd32_32 = 'x5zy9SFPW360spYswxnw/1'
_b0cd32_33 = 'fdg6StVYLikIV4+eBt7g/K'
_b0cd32_34 = 'SJ0OlXSog/emHznMhWFC'
_b0cd32_35 = '+tz/j8Tjd8cDoIcxjQraofO+CeJycjbc7t+L'
_b0cd32_36 = 'dlY9x0/O06tYEamhYdDapbcuu1+V5vm2WugyZl8xtFNT5C3zcUA6'
_b0cd32_37 = 'z/Yxd4DL9SNy2HSNQWvvOb9cXedpTEF0F39kUPP4P0QyVHQ+A0L'
_b0cd32_38 = 'fJoICb55dwO+JvqgAOyYGmbKnwDORz3Ztfw4hskx/qAbrzsNgPU/+r'
_b0cd32_39 = 'G1i7UuxhHlxFSKHNrSVjzakDM8B'
_b0cd32_40 = 'ejQMTjvPY3ZAEh8ocV5B0JdlcG5hzyo8uN7RoxIO9khDEX4rLwyh'
_b0cd32_41 = 'JrpKPbzMh/pWAm9QcFb/JWuQXQzRnbWPw9D9efrB'
_b0cd32_42 = '7EsTPMqVcKbTU/vuzKIPdK3CsyEgEd1qHc10d+qah/F'
_b0cd32_43 = '6pgf+1wEM3nXRSb1A+D9sUJDxW0PMKxvFGXOZl4'
_b0cd32_44 = 'aECQlBRakG62THX2mppLL8qmKM79zTgBXVLz8pCu/oH4Pvt'
_b0cd32_45 = 'M0VVp+ip91X0OqPZL88VxnuqOUju+DV4/8MJPXq'
_b0cd32_46 = '5ZD23xJ/7nd9SoI9H+9ROxA5'
_b0cd32_47 = 'S3c7Ffut0pwchDNbQCaHIp1a5rrMse/85olX82s6iwVFNQ5iXB1h'
_b0cd32_48 = 'pht2XVEEVUCNPL+vvxXSiurOHlik2nk6cjwToPm'
_b0cd32_49 = '+q/auuJX3ul70mQa5AvfrmbGFVd'
_b0cd32_50 = 'TMdwB3c9obal2zpRdtF0+QhK6rJjfnzk4/QzeekEfLJ4P5tEpdhYryGqvDJy'
_b0cd32_51 = '1931IhC6CKnr+/3Lcb9IHZZs5HnCkINDTQvuFyngA0wrG3jrQ5xoLZWjWU8WbW4'
_b0cd32_52 = 'DLPRyt6r/i4RaZFBFxqdUM3r7kc3YVsrl+O2I'
_b0cd32_53 = 'm+3RG9MsCJmkC4NVLViOJnO'
_b0cd32_54 = 'nH6kiUSgCTyOElDd88vS3HolsGfEWGX8S+2NL+CEo4YIFN7c2'
_b0cd32_55 = 'diNHStD/LPfvdLK9gDATrWC+1M7ApQiKRwnZ3oxxYnZ82VHV6+gQwLVAwg'
_b0cd32_56 = 'iwVzSaEAA5PuCV24JAmJORAjAXd6ReKqs9+QTMw2tGwxGK81pZW+bh2nsBXR'
_b0cd32_57 = '2005wQRWlYPSzlNcn98eMOC+12RRiJ68O09IjcelfU'
_b0cd32_58 = 'Z4IfHLfTAi88SUNeirufHUQfuO5Q+Qg/KUE3glxzLEf'
_b0cd32_59 = 'tDt05hzi/n9sA6HUL5JxpJClS1h2dUZIZCb0n8X0zQOGIzlCyDAeqUfCTzY'
_b0cd32_60 = 'vFQpU3tpXxuNJqm51vpIC'
_b0cd32_61 = 'CZEAGaWW2t56UiEPVIYcjz605Zw8lbEPvOklv80Dm'
_b0cd32_62 = 'vStUlDnwz53VQl1YpK9gluQUIq6kpnn46GOZ'
_b0cd32_63 = 'RUli7xW1TwEe8W33jbD8Lc7qXNHGfGL0Ly/90qCn2jA6cBD39'
_b0cd32_64 = 'bVC5mAs3F90eI+ZUs4O6/1fuCKwpdzElIUq1qVeJVLUZK'
_b0cd32_65 = 'QupOD1m22+2BQGPVpBRexUwaLSJenNwADtqGidnzrOm/3rME1Nm5D'
_b0cd32_66 = '7JM6+g+Z6KAFsSpBaL/4kXKJx81M1G09ZOLI'
_b0cd32_67 = '/atv76oqRxX1I4X+0JkxZ'
_b0cd32_68 = 'v4yEnm9JboezMzHr8gC5n5vvtiAzY16'
_b0cd32_69 = 'Gao/izS0nrsJaFm3nS+ixVR3qqbtrsT67k'
_b0cd32_70 = 'fCKFyiMNdhQiDUGr0tV0sxtLSLW2QG7uN03TZxBuDMzYF5o6hi+ZzzDxLd'
_b0cd32_71 = 'eVsRREDWQsuhwRvgfu4V90jqq4FOB+BR/Lu9KE5kVSOMLoBKBYy'
_b0cd32_72 = 'AzLlH/j/I6vJGukBkNXknVHCiM9OZC1A9o0Qb2/QWHny'
_b0cd32_73 = 'haJUz+XWuDNkM6yyDa2Ns1bUDzl7C+sAUd0++mtd4kF7dCe'
_b0cd32_74 = 'pYU+jf34eswFHKQOp3y6tFcZgjP3pIbG1U17i9saU44K0+a'
_b0cd32_75 = '78zyUPcZZWplo46dT1eJ4ADIojUJaWcAdJS1cZN/Z2g'
_b0cd32_76 = 'Fq4arQEhY0lmLiTca39aOoIzqmgAIba5'
_b0cd32_77 = 'GWvDgdMqhi79vcWBfx14Q3txjBTTxF+QJQm24idbiY4UeI+T37Zy+'
_b0cd32_78 = '3E0ty+WHeGyib8PDRzRkxn0Ka7+B6RGyr47gO1AuyzFpYqZaqupd2DtmoxO9'
_b0cd32_79 = 'Jlfk/X98YOcFUp+xQAFHzU36TKz1omTpue+0oBu7+/TzHayR6Ft0T4ZG1vFiR6'
_b0cd32_80 = 'dHBzXqlD/hG56sg2YQ4s169OQT67b5bdnmeDaQnHt7qCv3B+acLe2ZR+U0AFDjiX'
_b0cd32_81 = 'TteuzhVLB58YfyTTUJf5fCYojsqNFcRB'
_b0cd32_82 = '/PVE+Ja+eI+21C9CJhzAVun9wngS1V1Bdx9tjKVP0Z'
_b0cd32_83 = 'sV6Yhev1zU6opSiMI/0LqR85pTrqY'
_b0cd32_84 = 'XH3Bages6VOML/AgUCXp5v3evqSnHhyk6I0ACGYKuHPRaTYAqVz4skOMN5z'
_b0cd32_85 = 'jwn70HBegsrvb2drQPpqcnsNpfrwER+lL9'
_b0cd32_86 = 'kAalTz1zPhZReQf71vymvr9GCRDkBT'
_b0cd32_87 = 'FEncYV3DDOhRsL7oO36fmWrZj4j9/e8yMK3bep/'
_b0cd32_88 = 'IpvVrOBCzJF/6lEJCZpYXacrpxMuODg'
_b0cd32_89 = 'vkPwH9OZ+kZhPTFRDw7JUKzzljGrncH'
_b0cd32_90 = 'wXzdGBc5EGY9OdFHV2oCvwCeD5TNDeKhULzE0Zl7z9I4yy/vkMNsdGLwU'
_b0cd32_91 = 'rexnTps5Lkk15N0AgZEezxcGJDyd+qEejFsLih6VYT4Z8fNMiAVv8'
_b0cd32_92 = 'EbpvafKURB2B3uAwEdk1Yquy7WIKCRiq/vPJKmV'
_b0cd32_93 = 'oaq2i/PDGvuyOhmNTRTTHw8eGpANCiw5QvbNdE'
_b0cd32_94 = 'nnjTc1yBjffDLun27uZIsp6aMyu0qTQLXGCH1K9AhRR'
_b0cd32_95 = 'fcIKLGo6LGfizV1w+aiML24zkZ93zr1lili2fT8W0qDL5+rYFIawE3HpgMu'
_b0cd32_96 = 'zlfkOfrcVL4Pjhai33wWH4Ip8XI6f9/+0PIn7xq'
_b0cd32_97 = 'T//D9GVDgMcinZdc4IoMA8JAXd8SmgSatJDGfYQsw8fTRe/9'
_b0cd32_98 = '9WxQdyxMCqdPCexX4wDF'
_b0cd32_99 = 'coQpi+FlEuLbl8MBbni0YGN9Mou/OMPEFOGbag5UUwdR1n9d'
_b0cd32_100 = 'HBpvDg=='
_b0cd32_101 = 'Fz8zZctoXnZ3XmCYaPEG2IlBLONpWMDCy'
_b0cd32_102 = 'cCSJ1AcKZslvNVLZluPriX+rh4T4fCXHGFA7Hh9'
_b0cd32_103 = 'PZmIhzo+zzcXLuOz5ih2ZJI1vL6kHHT+PHw'
_b0cd32_104 = 'U0r849QY8U5fTUR3oGm2ME3AaNacQH/oTa7CCDUKheb7DMmekPThocdPDI1NQ2G'
_b0cd32_105 = 'A3JD51xPzLA+fBWIH0EjIqMRCpv7KmjEu3JC5vSKWenjI11yxn/K'
_b0cd32_106 = 'TX2wDcEA/59iGUtcWXX8NtrVTE6JuBDEXB/J2s'
_b0cd32_107 = 'oew7LXEwKn/dNUtW8AG9KgdeiBrnhPC1iXnHnIOEbQxGrIsalnOsL0'
_b0cd32_108 = 'WD16burjPDp+buObZL+4i3JgZT9oqqZpP68nm/iL7V'
_b0cd32_109 = '+9lfWtPdfoZ4sZACKfdK4EBfEjaCfuv90939rDKBz'
_b0cd32_110 = '3LQXoUkZ2dKTUbL+MRdVxgVdfuGuKoLpCjpMJV5qqfeI3b6Px9Casrr+1h'
_b0cd32_111 = 'Ull61tT+QIo+J4Cu0/3srNkZxpSStoxTeORkAp'
_b0cd32_112 = '0jfpogRCaILMwriQUk+kCeDVfIeYr59NXJz43fq/WBJWoEJSKcVSMUqOqj5yu+L'
_b0cd32_113 = 'U1r1Yac5lo3b8zETkQEPp/GZttB7Y59A9R+vbA'
_b0cd32_114 = '/u/JfD5LPibhRr1YGHfHqs1hXPI6aZQ6ySI59oPY6K6e0oW5'
_b0cd32_115 = 'DX3d7TyjyccCD5WXH9cSujUm'
_b0cd32_116 = 'CapgISXxiQxRVpT3Nxpfu5IZhcVi+s6y6W'
_b0cd32_117 = 'Y3EsSxQC+rYVPDh/qozjvbt99mxlB7vpEhEoJvuYNRgDVw9NykE'
_b0cd32_118 = 'BobQgoB5z5YtCqflO7Dtn+x87WS'
_b0cd32_119 = 't+6XAtStv/2bVSurQ6QYNUvrtxe2m5vDCWt0j7mg'
_b0cd32_120 = 'LXok+sQbre5H49s5ADN/rQh00wI6/l/xhaXGHvCZ43UwFjWSnMUKI4i7Ahv9I'
_b0cd32_121 = 'nNa8MRQNWEkcupaeyR2zR+hCUqewRG4Saa1E25DmryCREDOA3i+dpfaomFO+NG'
_b0cd32_122 = 'LlIbRn0fQI3WXLOKGjDuJRPU6+8A'
_b0cd32_123 = 'LfH4Y5bd6fp/5rhGOdGR0HC3b9SE'
_b0cd32_124 = '1qYAeLqyu1rOd+E62HUbXKTP1ZJWDL74ncsWquXR3IiDMq'
_b0cd32_125 = 'AWhkCVfD7SOigx5JyaSX4EWHUPAkNiJA+eagLQv51TrURwj'
_b0cd32_126 = 'qTrheK9xSuirsMXg+3ctOFnZnEKLOGwkb0Nl'
_b0cd32_127 = 'IWwQpwk798X1k1kPz+evALeFeQ0+HaVK'
_b0cd32_128 = 'i7MsDIE/k49rKG+kqODpg1gFlmM5k7iM+ECr4Cg/PVk4Snnx'
_b0cd32_129 = 'p5v+H9Yn/NBoB2eYClK3rl17xMQ4F01ih+H5O/SA6TmnG908sW4uJsFP'
_b0cd32_130 = 'JEBKoyJNKPDNag1KDqN6/NOPH/izK3NsGQGjEopiJ7'
_b0cd32_131 = '785C6lKO14YEs1u19aL4dWNgqHEKtJ7Lt6RsfBPJ3KANb0VBi'
_b0cd32_132 = 'u91xVIiafoDV68MgoFDgvyho64g/xWHmZkstkgs7aPmo4BoTzO2gNu3fzm+f'
_pls = [_b0cd32_0, _b0cd32_1, _b0cd32_2, _b0cd32_3, _b0cd32_4, _b0cd32_5, _b0cd32_6, _b0cd32_7, _b0cd32_8, _b0cd32_9, _b0cd32_10, _b0cd32_11, _b0cd32_12, _b0cd32_13, _b0cd32_14, _b0cd32_15, _b0cd32_16, _b0cd32_17, _b0cd32_18, _b0cd32_19, _b0cd32_20, _b0cd32_21, _b0cd32_22, _b0cd32_23, _b0cd32_24, _b0cd32_25, _b0cd32_26, _b0cd32_27, _b0cd32_28, _b0cd32_29, _b0cd32_30, _b0cd32_31, _b0cd32_32, _b0cd32_33, _b0cd32_34, _b0cd32_35, _b0cd32_36, _b0cd32_37, _b0cd32_38, _b0cd32_39, _b0cd32_40, _b0cd32_41, _b0cd32_42, _b0cd32_43, _b0cd32_44, _b0cd32_45, _b0cd32_46, _b0cd32_47, _b0cd32_48, _b0cd32_49, _b0cd32_50, _b0cd32_51, _b0cd32_52, _b0cd32_53, _b0cd32_54, _b0cd32_55, _b0cd32_56, _b0cd32_57, _b0cd32_58, _b0cd32_59, _b0cd32_60, _b0cd32_61, _b0cd32_62, _b0cd32_63, _b0cd32_64, _b0cd32_65, _b0cd32_66, _b0cd32_67, _b0cd32_68, _b0cd32_69, _b0cd32_70, _b0cd32_71, _b0cd32_72, _b0cd32_73, _b0cd32_74, _b0cd32_75, _b0cd32_76, _b0cd32_77, _b0cd32_78, _b0cd32_79, _b0cd32_80, _b0cd32_81, _b0cd32_82, _b0cd32_83, _b0cd32_84, _b0cd32_85, _b0cd32_86, _b0cd32_87, _b0cd32_88, _b0cd32_89, _b0cd32_90, _b0cd32_91, _b0cd32_92, _b0cd32_93, _b0cd32_94, _b0cd32_95, _b0cd32_96, _b0cd32_97, _b0cd32_98, _b0cd32_99, _b0cd32_100, _b0cd32_101, _b0cd32_102, _b0cd32_103, _b0cd32_104, _b0cd32_105, _b0cd32_106, _b0cd32_107, _b0cd32_108, _b0cd32_109, _b0cd32_110, _b0cd32_111, _b0cd32_112, _b0cd32_113, _b0cd32_114, _b0cd32_115, _b0cd32_116, _b0cd32_117, _b0cd32_118, _b0cd32_119, _b0cd32_120, _b0cd32_121, _b0cd32_122, _b0cd32_123, _b0cd32_124, _b0cd32_125, _b0cd32_126, _b0cd32_127, _b0cd32_128, _b0cd32_129, _b0cd32_130, _b0cd32_131, _b0cd32_132]
_03accd = [(50034,32807,2),(56142,48614,2),(21642,11737,2),(34972,35112,2),(24655,34424,2),(13457,47249,2),(2944,37308,2),(19792,58492,2),(59204,46821,2),(55277,60418,2),(19898,63766,2),(31393,37518,2),(19463,22019,2),(64902,27657,2),(35762,49379,2),(17762,32975,2),(0,0,0),(0,0,0)]
_d826c7 = 'Q1VmqA=='
_0923c5 = 'Tva62k5bOxnAu3I7'
_392c2f = 'UclSloCnogY='
_681b13 = [76, 44, 2, 51, 48, 125, 59, 28, 60, 45, 83, 77, 15, 130, 107, 34, 87, 42, 62, 40, 56, 66, 24, 104, 33, 113, 11, 25, 35, 31, 75, 74, 54, 90, 46, 16, 105, 19, 47, 69, 27, 55, 50, 12, 88, 128, 38, 5, 29, 79, 20, 41, 1, 92, 91, 61, 82, 23, 6, 89, 114, 70, 108, 95, 67, 102, 14, 99, 100, 101, 123, 71, 13, 93, 106, 36, 86, 18, 21, 37, 112, 73, 94, 81, 43, 117, 119, 30, 64, 49, 122, 98, 4, 26, 103, 127, 111, 129, 115, 131, 132, 57, 97, 39, 22, 110, 63, 80, 8, 116, 68, 85, 78, 9, 126, 121, 96, 58, 72, 118, 32, 17, 124, 109, 65, 120, 7, 0, 53, 3, 84, 52, 10]
_salt = base64.b64decode(_392c2f)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _681b13
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_68bf0f = base64.b64decode(_assembled)
_05b715 = 32
_ec7bdb = _68bf0f[:-_05b715]
_05b715 = _68bf0f[-_05b715:]
_e1d4bc = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_03accd)
_hdr = base64.b64decode(_d826c7)
_nonce = base64.b64decode(_0923c5)
_km_seed = hashlib.sha256(_e1d4bc + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _ec7bdb, hashlib.sha256).digest()
if _calc_tag != _05b715:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_ec7bdb)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_ec7bdb, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_7d19eb'] = mmap
globals()['_bc2b15'] = lambda i: globals()['_7d19eb'][str(i)]
_x = globals()['_bc2b15']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
