import binascii, zlib
_OBF_STRINGS = {0: '78da8bf6f473f38f55c849cc4b8fcf4c49cd2b894fce492c2ece4ccb4c2d52c8cd4f29cd4955c82c56c8cb2f57c8c94f4c494d0100c1f4123d'}
def _S(i):
    return zlib.decompress(binascii.unhexlify(_OBF_STRINGS[i])).decode('utf-8')

# decode and execute the obfuscated source
_code = zlib.decompress(binascii.unhexlify('78da2b28cacc2b51d0880fd630d054d00400237d03f2')).decode('utf-8')
exec(compile(_code, '/media/saldanha/1D4448BE344F76BB/PythonProjects/lang_ident_classifier_gen_llm_classification_head_exp_vocabmerger/lang_ident_classifier/__main__.py', 'exec'))
