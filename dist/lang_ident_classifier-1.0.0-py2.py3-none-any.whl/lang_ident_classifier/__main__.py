
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(44109, 27891, 2), (24790, 32194, 2), (37545, 14582, 2), (29821, 12085, 2), (63342, 43673, 2), (12309, 51309, 2), (419, 38759, 2), (21666, 63427, 2), (13532, 15983, 2), (15195, 29640, 2), (20846, 52083, 2), (55980, 11676, 2), (36091, 54149, 2), (36830, 39845, 2), (4615, 51466, 2), (22578, 29980, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('wL4dFA==')
_nonce = base64.b64decode('yvk41govz7HeReWQ')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('Xa0VFh5IWXbP4+XlbprorYhAUHLz7iWwJDdycU3urr5y7l0+CuDvgFCZEO8AIKIsMRTvc1cN2hRUiosvUMigu8POae3jsCKJShlnjuDfGLHrPOiVkConKuoVo5NqfG706tjF3yK5k7iX7TcH4+woD6Wd0/7cpWHa4/ya1lLNsezM7OqbHxG8/gzXN5eSLDMegJZEncpQGYo5GL0niKgv/pRviczyTwa2qPmysTAWZ/tgkaHphnw/ug0XluzU6ZFXM2M9KkxSqoLLFvYI+C5YALnTbCCvQhghVyAc1IoPsV3ekCESS+lA+qiazsmRvqLNlPf5AagwrQP0HVfECCGixpCAHuggmPHYyi87qmmXa3ctKuFR')
_tag = base64.b64decode('pQpyFvzjDXwIEQv54DQFEg==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
