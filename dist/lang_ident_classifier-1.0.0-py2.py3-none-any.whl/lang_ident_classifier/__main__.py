#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(22154, 27590, 2), (11165, 64661, 2), (35039, 65412, 2), (37794, 53438, 2), (60562, 6622, 2), (15128, 29639, 2), (30787, 31336, 2), (44437, 22514, 2), (17077, 38705, 2), (30964, 17492, 2), (16265, 13335, 2), (56500, 22307, 2), (4942, 18566, 2), (50618, 8220, 2), (49248, 33154, 2), (21975, 15699, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('PUzXCA==')
_nonce = base64.b64decode('xFndC+/HB2NWmQcv')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('dHbeDgERKJZ1cUoBhrA/ysnC18p1HJako4Kl0qwghqgbRGCD7xw3yea1RTskTjGuBfd1Kik7fcZulZHv5yjG5/qTT8SScuHVWBuDztj+Y4/PABGKWnydoopsKSj5hezcXPs9jATakphc3n3avYVP1HepZai/68t05kaa7LulULuetIsHlgAY/+XNwi8fWy59Kd1K3Kbxr+YHdgdbUKds9ryy2kFttpLJDp/7AHpbnhKkm3ZWL/w6zrmp3u7M832Sp3YM2Koc8KdWuMPsUTZMpueJtYYqN5rwGSFz79bHXsLZpwg4huFhQAbrBjp0pYawOGsYNfI6hf52wIpME4myabnrKFS8NpGTmDQKbbHbXAYA3Kfw')
_tag = base64.b64decode('4OTW0ylC05sSM/iurjvWjA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
