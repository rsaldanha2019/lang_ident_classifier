import base64,zlib,json,binascii
_B = 'TvhIfG3+9IJXwJaHnp/Z9Qh9k2YDHG3qZrrvTMA4Kc3EzSjX1VUQL68hDOWJlpFusVTCrLYCm5xR13NikIDq01n+6Hi/YfEibpeBQHtflEMOZRorlcb93gLkRnf5NbeaGm90kK5tD9lGlJOEPmY3B0jhoMt4hYuvL39oLOq3pQ=='
_P = [(920796304,12607841,4),(3691870335,16338877,4),(1542978018,7639200,4),(3449517927,439228,4)]
def _reconstruct(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _reconstruct(_P)
_x = base64.b64decode(_B)
_r = bytes(b ^ _k[i % len(_k)] for i, b in enumerate(_x))
_j = zlib.decompress(_r).decode('utf-8')
_payload = json.loads(_j)
mapping = {int(k):v for k,v in _payload['m'].items()}
def _S(i):
    return zlib.decompress(binascii.unhexlify(mapping[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
