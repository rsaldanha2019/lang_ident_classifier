#!/usr/bin/env python3
import sys, hashlib, marshal, base64

_enc = base64.b64decode('Z6q7L/vW/Wtp7hFDNIg6q5OwN+tBu44XawAtQgw4MlNAuqKNb066dr0XL/s8V7GqMMIeykeStDtaqTWn9ZwkQioYCjh3xPYaXjPXbEWO1rR8RHSt8D9SwMBq9qG39eqaUoGpNQLn5FzEo4bv7dnuq0C35IOvSsQC+XJ4QiO2uuZ/7wVDWvsY/PTTsefo3Cj9hDWQeQcFZadcD0f4KX9y5LWsArAlO6LSjrzZthAxs4h4pM3rC8bA/A+d5bBjKh/U4sdScgtAkYzA7iqd29XLbfYdsOaa7NPAwrJLvvN1KRm2Iv9XFXLmoGf3ejgN/xYKe/km8WqziG5wSlnyQhU7UALDGVC/6kRexEwJ0eR2j7SrYqtFAwm38sCN2Pvdbiiymu3fI/VIZt6XX3hZA/NVg+2V9VRslllBzkU=')
_nonce = base64.b64decode('UNF/a5Fli7xvjsi4')
_tag = base64.b64decode('5lD/5IHvtmoMoaIleB2oFQ==')

def _sha_stream(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

h = hashlib.sha256()
h.update(b"__main__|")
h.update(repr(globals().get("__file__", "")).encode())
seed = h.digest()

km = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(seed + _nonce).digest(),
    _nonce,
    300000,
    32
)

blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(km + b"blob").digest(),
    _nonce,
    60000,
    32
)

if hashlib.sha256(blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_stream(blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals(), globals())
