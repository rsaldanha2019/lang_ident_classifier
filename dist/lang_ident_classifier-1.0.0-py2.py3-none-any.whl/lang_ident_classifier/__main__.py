#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(9073, 46925, 2), (42217, 4925, 2), (53719, 56303, 2), (3529, 28602, 2), (27220, 38641, 2), (45641, 64809, 2), (15130, 20147, 2), (11119, 60372, 2), (26874, 55325, 2), (57096, 30386, 2), (3711, 39728, 2), (546, 45700, 2), (39863, 31696, 2), (12783, 42289, 2), (62176, 63860, 2), (53080, 42401, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('lDy31A==')
_nonce = base64.b64decode('5OoeDVAr0B1y9WcV')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('z8kzhuDq8rVsOCHYrSGk7JZu2ft43od/8k+wAqKBCrXIi7YcozaM9TBAyG74PsRmDp6ic4EXGAi4AiOokGEsuWHuZGNHNNP2G+7my+Ez7enFt0E6HxVUBEiy4e5JiX4+4Ph84RinM5WdxFNv4g1+zKeJos2ixbI9VKG4hFXj0xM9pBOTYV+yvaI9kYf48bYM+xI8YeSGxilN60yZxk0Tdt2eotuc/qZVgu94bgNZWPKiuKwnRiBZPEGxpHH15I74HSiV3Cu6l0c8qxdaJc2F0N79HOMeIkV8eBdDdzulp22qR0GyuENwUjbumd1/FqEMaHLp3xxnU0ba6TkYyJNgiDhPHMHMkiWR42bBfzqoTnC5sYx7')
_tag = base64.b64decode('pGxLrlO4dcB/fE7SxZKjnw==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
