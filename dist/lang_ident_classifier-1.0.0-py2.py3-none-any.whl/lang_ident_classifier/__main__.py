import base64,zlib,json,binascii
_b = 'MrU+X3TP2bjsXb6FTDIQpzjxW66uX7hMIQlFndZLWQ336C69albT6f9QT7MGyEjliRwaKYRfe8GmHWwcYT0hTqJBzPaqECYHy5k80gmqUy+5+E6dTPyimMic/2/P+1PLeb+mxAihUH0ar3gKhv/Lc6JoaSrjzOslePgBgmc='
_p = [(1127725991,14705453,4),(2416098756,2731536,4),(4018351366,16175870,4),(4218347535,2851113,4),(4190449713,16728822,4),(147192063,7074490,4),(3750807656,502162,4),(3832753634,15789164,4)]
def _r(parts):
    out = []
    for v,p,l in parts:
        x = v ^ p
        out.append(x.to_bytes(l,'big'))
    return b''.join(out)
_k = _r(_p)
def _t(data, key):
    s = list(range(256))
    j = 0
    kl = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % kl]) % 256
        s[i], s[j] = s[j], s[i]
    i = j = 0
    out = bytearray(len(data))
    for k in range(len(data)):
        i = (i + 1) % 256
        j = (j + s[i]) % 256
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) % 256]
    return bytes(out)
_x = base64.b64decode(_b)
_z = _t(_x, _k)
_j = zlib.decompress(_z).decode('utf-8')
_payload = json.loads(_j)
m = {int(k):v for k,v in _payload['m'].items()}
def _d(i):
    return zlib.decompress(binascii.unhexlify(m[i])).decode('utf-8')
src = _payload['s']
exec(compile(src,'<obf>','exec'))
