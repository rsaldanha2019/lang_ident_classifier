# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_cross_entropy_loss.py
# @Time             : 2025-10-23 15:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _ab7d2b7b4f00


class _e64a6d5ff5ee(_ab7d2b7b4f00._dd10f886a282._26d050612a19):
    """
    Implements class-weighted cross-entropy loss with per-token weighting.
    """

    def _554cc344a522(
        self,
        _834107f7c293: _3027d2b93b7d = 'cpu',
        _71fd199e9bae: _372b23c6ef31 = _8118e0899111,
        _733274475fa3: _3027d2b93b7d = "mean",
        _a34b3523bdf5: _b71ff97ccfa9 = 20,
        _01be18eb3b60: _b71ff97ccfa9 = -100,
        _3fad06c8e86a: _b71ff97ccfa9 = _8118e0899111
    ):
        """
        Initialize the loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            class_weights: Dictionary mapping class labels to (token_ids, weight).
            reduction: Reduction mode ('mean' or 'sum').
            random_seed: Random seed for reproducibility.
            ignore_index: Index to ignore in loss computation.
            separator_token: Optional token ID used as a separator.
        """
        _96282c6320e8()._7e69982b0230()
        _ab7d2b7b4f00._293d49a1ccfa(_a34b3523bdf5)
        if _ab7d2b7b4f00._7f192b6976dc._9184e80cbc7d():
            _ab7d2b7b4f00._7f192b6976dc._c9c3b48117ae(_a34b3523bdf5)

        self._50cab6cd6b47 = _834107f7c293
        self._733274475fa3 = _733274475fa3
        self._01be18eb3b60 = _01be18eb3b60
        self._43eb3221b571 = _71fd199e9bae or {}
        self._a648b7afcb9f = _39827425aa32(self._43eb3221b571)
        self._a2c22514bd80 = self._43eb3221b571._6b01cb488d3e("unk", [[], 0.0])[1]
        self._3fad06c8e86a = _3fad06c8e86a
        self._88023cc54568 = self._19fe3e1c4e2e() if self._a648b7afcb9f else {}

        self._e5121c13cfb1 = _ab7d2b7b4f00._dd10f886a282._c29f3b98cc8e(
            _733274475fa3="none",
            _01be18eb3b60=self._01be18eb3b60,
            _3ed9db64b353=0.1,
        )

    def _c9c45e2ba2f6(self):
        """
        Builds a mapping from token ID to weight based on provided class weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _970822308519 = {}
            _25272fd4d6ed = [
                _d9d703d2762e[1]
                for _80bb731bbacb, _d9d703d2762e in self._43eb3221b571._7c1960345dad()
                if _80bb731bbacb != "unk" and _d9d703d2762e[1] is not _8118e0899111
            ]
            _d71562592d22 = _13a93a0ac0ba(_25272fd4d6ed) if _25272fd4d6ed else 0.0

            for _80bb731bbacb, (_2465dcc7c297, _06536afceadd) in self._43eb3221b571._7c1960345dad():
                if _80bb731bbacb == "unk":
                    continue
                for _42b520b8c89b in _2465dcc7c297:
                    _970822308519[_42b520b8c89b] = _06536afceadd if _06536afceadd is not _8118e0899111 else 0.0

            if self._3fad06c8e86a is not _8118e0899111:
                # half on min weight
                _970822308519[self._3fad06c8e86a] = _d71562592d22 * 0.5

            return _970822308519
        except _b86a6fdb71f1 as _3dc615e745e0:
            raise _d7b51dc6bfc1(f"Failed to build token weight map: {_3dc615e745e0}")

    def _0df962699ab7(self, _6fbf0d736783: _ab7d2b7b4f00._4007069b792e) -> _ab7d2b7b4f00._4007069b792e:
        """
        Generates a tensor of weights aligned with label tensor.

        Args:
            labels: Tensor of target labels.

        Returns:
            torch.Tensor: Weight tensor.
        """
        try:
            _17d895174ab5 = _ab7d2b7b4f00._085b5e2f19d0(_6fbf0d736783, self._a2c22514bd80, _ef203085cc09=_ab7d2b7b4f00._7d49fd20166d)
            for _42b520b8c89b, _06536afceadd in self._88023cc54568._7c1960345dad():
                _db3f694dcd28 = _6fbf0d736783 == _42b520b8c89b
                _17d895174ab5 = _ab7d2b7b4f00._8caa84a40613(
                    _db3f694dcd28, _ab7d2b7b4f00._1e3b5145cff1(_06536afceadd, _834107f7c293=_6fbf0d736783._834107f7c293), _17d895174ab5
                )
            return _17d895174ab5
        except _b86a6fdb71f1 as _3dc615e745e0:
            raise _514ba41daeb2(f"Error generating weight mask: {_3dc615e745e0}")

    def _12cbec170f70(self, _852faf0388d4: _ab7d2b7b4f00._4007069b792e, _fceb043a44ef: _ab7d2b7b4f00._4007069b792e) -> _ab7d2b7b4f00._4007069b792e:
        """
        Compute the weighted cross-entropy loss.

        Args:
            logits: Model output tensor of shape (..., vocab_size).
            targets: Ground truth tensor of same leading shape as logits (excluding vocab dim).

        Returns:
            torch.Tensor: Scalar loss value.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _852faf0388d4._834107f7c293 != self._50cab6cd6b47:
                _852faf0388d4 = _852faf0388d4._6a7abebfc90e(self._50cab6cd6b47)
            if _fceb043a44ef._834107f7c293 != self._50cab6cd6b47:
                _fceb043a44ef = _fceb043a44ef._6a7abebfc90e(self._50cab6cd6b47)

            _e63a3b44bc4d = _fceb043a44ef != self._01be18eb3b60
            if not _e63a3b44bc4d._c971b9dca1a3():
                return _ab7d2b7b4f00._1e3b5145cff1(0.0, _834107f7c293=self._50cab6cd6b47)

            _852faf0388d4 = _852faf0388d4[_e63a3b44bc4d]
            _fceb043a44ef = _fceb043a44ef[_e63a3b44bc4d]

            _9f315b30180f = self._e5121c13cfb1(_852faf0388d4, _fceb043a44ef)

            if self._a648b7afcb9f:
                _17d895174ab5 = self._f6b397fa993d(_fceb043a44ef)
                _9f315b30180f = _9f315b30180f * _17d895174ab5
                del _17d895174ab5

            _da2ee8f8c8a0 = _9f315b30180f._52cdcb1b9c6c()

            del _852faf0388d4, _fceb043a44ef, _9f315b30180f
            if _ab7d2b7b4f00._7f192b6976dc._9184e80cbc7d():
                _ab7d2b7b4f00._7f192b6976dc._1d31043901b0()

            return _da2ee8f8c8a0
        except _b86a6fdb71f1 as _3dc615e745e0:
            raise _514ba41daeb2(f"Error in loss forward computation: {_3dc615e745e0}")
