# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_cross_entropy_loss.py
# @Time             : 2025-10-23 15:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _b9d566a34a8b


class _10f6b77d015c(_b9d566a34a8b._ee531db08c31._2bc27ddc8a92):
    """
    Implements class-weighted cross-entropy loss with per-token weighting.
    """

    def _172b41fd8a65(
        self,
        _c4af65d90f20: _f024c00525ae = 'cpu',
        _8988b57eeefd: _2c2131a32412 = _055069f29e01,
        _62bffc7b5076: _f024c00525ae = "mean",
        _3b65c7607d0e: _49992fb511df = 20,
        _c9b1c9bc59ef: _49992fb511df = -100,
        _3f6540926485: _49992fb511df = _055069f29e01
    ):
        """
        Initialize the loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            class_weights: Dictionary mapping class labels to (token_ids, weight).
            reduction: Reduction mode ('mean' or 'sum').
            random_seed: Random seed for reproducibility.
            ignore_index: Index to ignore in loss computation.
            separator_token: Optional token ID used as a separator.
        """
        _0d7c5d22885a()._917d0662036e()
        _b9d566a34a8b._efd380340eda(_3b65c7607d0e)
        if _b9d566a34a8b._3fad54e5f634._0c9e3b9dda47():
            _b9d566a34a8b._3fad54e5f634._ea87764bbf2a(_3b65c7607d0e)

        self._7fdb51bd6124 = _c4af65d90f20
        self._62bffc7b5076 = _62bffc7b5076
        self._c9b1c9bc59ef = _c9b1c9bc59ef
        self._7d334bd984ae = _8988b57eeefd or {}
        self._3348311c8135 = _a247bb2e2c76(self._7d334bd984ae)
        self._b60dcf286fcc = self._7d334bd984ae._405428b2835a("unk", [[], 0.0])[1]
        self._3f6540926485 = _3f6540926485
        self._f97873f5b7a0 = self._23aaa744d567() if self._3348311c8135 else {}

        self._46a444bd7c12 = _b9d566a34a8b._ee531db08c31._db242376416f(
            _62bffc7b5076="none",
            _c9b1c9bc59ef=self._c9b1c9bc59ef,
            _48bbd8d9c31b=0.1,
        )

    def _4da5dd50debd(self):
        """
        Builds a mapping from token ID to weight based on provided class weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _4331d4d991f7 = {}
            _b91673f2f6c3 = [
                _e79fbf24c519[1]
                for _4dd3a7d2beb1, _e79fbf24c519 in self._7d334bd984ae._4f9860ef41f8()
                if _4dd3a7d2beb1 != "unk" and _e79fbf24c519[1] is not _055069f29e01
            ]
            _e71d76800ec7 = _c759ab78fa96(_b91673f2f6c3) if _b91673f2f6c3 else 0.0

            for _4dd3a7d2beb1, (_72143e5736c3, _9a63c626c26a) in self._7d334bd984ae._4f9860ef41f8():
                if _4dd3a7d2beb1 == "unk":
                    continue
                for _553ae99d6b03 in _72143e5736c3:
                    _4331d4d991f7[_553ae99d6b03] = _9a63c626c26a if _9a63c626c26a is not _055069f29e01 else 0.0

            if self._3f6540926485 is not _055069f29e01:
                # half on min weight
                _4331d4d991f7[self._3f6540926485] = _e71d76800ec7 * 0.5

            return _4331d4d991f7
        except _fab96d91b3ca as _405c3313df19:
            raise _6599238d617d(f"Failed to build token weight map: {_405c3313df19}")

    def _a2be3a517e0c(self, _29cbf241db77: _b9d566a34a8b._a6e78a30bd36) -> _b9d566a34a8b._a6e78a30bd36:
        """
        Generates a tensor of weights aligned with label tensor.

        Args:
            labels: Tensor of target labels.

        Returns:
            torch.Tensor: Weight tensor.
        """
        try:
            _d71f8ba1339b = _b9d566a34a8b._f24cf5d418df(_29cbf241db77, self._b60dcf286fcc, _bd8af2512a5b=_b9d566a34a8b._8b1b2712b992)
            for _553ae99d6b03, _9a63c626c26a in self._f97873f5b7a0._4f9860ef41f8():
                _470843e3b73f = _29cbf241db77 == _553ae99d6b03
                _d71f8ba1339b = _b9d566a34a8b._d19754b5ad32(
                    _470843e3b73f, _b9d566a34a8b._4badd359267a(_9a63c626c26a, _c4af65d90f20=_29cbf241db77._c4af65d90f20), _d71f8ba1339b
                )
            return _d71f8ba1339b
        except _fab96d91b3ca as _405c3313df19:
            raise _b2abd07dd9bd(f"Error generating weight mask: {_405c3313df19}")

    def _340210007de3(self, _635d7c9be706: _b9d566a34a8b._a6e78a30bd36, _92825e518a91: _b9d566a34a8b._a6e78a30bd36) -> _b9d566a34a8b._a6e78a30bd36:
        """
        Compute the weighted cross-entropy loss.

        Args:
            logits: Model output tensor of shape (..., vocab_size).
            targets: Ground truth tensor of same leading shape as logits (excluding vocab dim).

        Returns:
            torch.Tensor: Scalar loss value.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _635d7c9be706._c4af65d90f20 != self._7fdb51bd6124:
                _635d7c9be706 = _635d7c9be706._1446c7e973e5(self._7fdb51bd6124)
            if _92825e518a91._c4af65d90f20 != self._7fdb51bd6124:
                _92825e518a91 = _92825e518a91._1446c7e973e5(self._7fdb51bd6124)

            _cc96f45dc285 = _92825e518a91 != self._c9b1c9bc59ef
            if not _cc96f45dc285._c8a3cb8730f2():
                return _b9d566a34a8b._4badd359267a(0.0, _c4af65d90f20=self._7fdb51bd6124)

            _635d7c9be706 = _635d7c9be706[_cc96f45dc285]
            _92825e518a91 = _92825e518a91[_cc96f45dc285]

            _0c3fe676fcfc = self._46a444bd7c12(_635d7c9be706, _92825e518a91)

            if self._3348311c8135:
                _d71f8ba1339b = self._56fd8dc20d95(_92825e518a91)
                _0c3fe676fcfc = _0c3fe676fcfc * _d71f8ba1339b
                del _d71f8ba1339b

            _3c9f9d43de4e = _0c3fe676fcfc._39774feb9d3a()

            del _635d7c9be706, _92825e518a91, _0c3fe676fcfc
            if _b9d566a34a8b._3fad54e5f634._0c9e3b9dda47():
                _b9d566a34a8b._3fad54e5f634._20fca2d16445()

            return _3c9f9d43de4e
        except _fab96d91b3ca as _405c3313df19:
            raise _b2abd07dd9bd(f"Error in loss forward computation: {_405c3313df19}")
