# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_cross_entropy_loss.py
# @Time             : 2025-10-23 15:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _324fbf112030


class _6f07ff38f176(_324fbf112030._da32ffd6f06d._bc65910db039):
    """
    Implements class-weighted cross-entropy loss with per-token weighting.
    """

    def _5f5987f71bc3(
        self,
        _c3928ad4abb7: _c2a46a8b3360 = 'cpu',
        _ce45610161cb: _4134959efebb = _d90eacd90951,
        _22b18d05bd57: _c2a46a8b3360 = "mean",
        _4fb530308c09: _6ce1bc3785fa = 20,
        _b012cad36178: _6ce1bc3785fa = -100,
        _a60b19f90448: _6ce1bc3785fa = _d90eacd90951
    ):
        """
        Initialize the loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            class_weights: Dictionary mapping class labels to (token_ids, weight).
            reduction: Reduction mode ('mean' or 'sum').
            random_seed: Random seed for reproducibility.
            ignore_index: Index to ignore in loss computation.
            separator_token: Optional token ID used as a separator.
        """
        _80301ee155e4()._49d37d8c6863()
        _324fbf112030._3d0840a32255(_4fb530308c09)
        if _324fbf112030._7dd4686f4107._e87dd57a4172():
            _324fbf112030._7dd4686f4107._07e08852bfb6(_4fb530308c09)

        self._63de3108f8e3 = _c3928ad4abb7
        self._22b18d05bd57 = _22b18d05bd57
        self._b012cad36178 = _b012cad36178
        self._beffec6956dc = _ce45610161cb or {}
        self._9e95266f5165 = _26ef8524dd24(self._beffec6956dc)
        self._1f746a2f94f9 = self._beffec6956dc._5d78ff86da88("unk", [[], 0.0])[1]
        self._a60b19f90448 = _a60b19f90448
        self._251b39cea5eb = self._6cfb5d7c5e13() if self._9e95266f5165 else {}

        self._f265ff2a93cb = _324fbf112030._da32ffd6f06d._25552b15db24(
            _22b18d05bd57="none",
            _b012cad36178=self._b012cad36178,
            _c1d1e02bfca0=0.1,
        )

    def _5aa922e1b845(self):
        """
        Builds a mapping from token ID to weight based on provided class weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _fc01822c703e = {}
            _f512432cfe69 = [
                _63e50d0e34fa[1]
                for _9316962d55ee, _63e50d0e34fa in self._beffec6956dc._d237fa72e5bc()
                if _9316962d55ee != "unk" and _63e50d0e34fa[1] is not _d90eacd90951
            ]
            _fff601da2e73 = _1651cba88b04(_f512432cfe69) if _f512432cfe69 else 0.0

            for _9316962d55ee, (_45e2820bbbae, _4b1b084e6e90) in self._beffec6956dc._d237fa72e5bc():
                if _9316962d55ee == "unk":
                    continue
                for _442b70f06522 in _45e2820bbbae:
                    _fc01822c703e[_442b70f06522] = _4b1b084e6e90 if _4b1b084e6e90 is not _d90eacd90951 else 0.0

            if self._a60b19f90448 is not _d90eacd90951:
                # half on min weight
                _fc01822c703e[self._a60b19f90448] = _fff601da2e73 * 0.5

            return _fc01822c703e
        except _9bdcae5f5e02 as _554893f212f8:
            raise _6d61fb648ed6(f"Failed to build token weight map: {_554893f212f8}")

    def _aed0c4d6ae6f(self, _1a71e4a0aa62: _324fbf112030._45c0ee912afc) -> _324fbf112030._45c0ee912afc:
        """
        Generates a tensor of weights aligned with label tensor.

        Args:
            labels: Tensor of target labels.

        Returns:
            torch.Tensor: Weight tensor.
        """
        try:
            _d4aad070e11c = _324fbf112030._5203ac1164c9(_1a71e4a0aa62, self._1f746a2f94f9, _44811b1aef15=_324fbf112030._a6ceede7b6f4)
            for _442b70f06522, _4b1b084e6e90 in self._251b39cea5eb._d237fa72e5bc():
                _556f885edf2f = _1a71e4a0aa62 == _442b70f06522
                _d4aad070e11c = _324fbf112030._b4df591fc116(
                    _556f885edf2f, _324fbf112030._417f1339577d(_4b1b084e6e90, _c3928ad4abb7=_1a71e4a0aa62._c3928ad4abb7), _d4aad070e11c
                )
            return _d4aad070e11c
        except _9bdcae5f5e02 as _554893f212f8:
            raise _a10c1dc00399(f"Error generating weight mask: {_554893f212f8}")

    def _a6076049c1dc(self, _7778fb94e587: _324fbf112030._45c0ee912afc, _5878fde4f508: _324fbf112030._45c0ee912afc) -> _324fbf112030._45c0ee912afc:
        """
        Compute the weighted cross-entropy loss.

        Args:
            logits: Model output tensor of shape (..., vocab_size).
            targets: Ground truth tensor of same leading shape as logits (excluding vocab dim).

        Returns:
            torch.Tensor: Scalar loss value.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _7778fb94e587._c3928ad4abb7 != self._63de3108f8e3:
                _7778fb94e587 = _7778fb94e587._efa0f602e33f(self._63de3108f8e3)
            if _5878fde4f508._c3928ad4abb7 != self._63de3108f8e3:
                _5878fde4f508 = _5878fde4f508._efa0f602e33f(self._63de3108f8e3)

            _c1ef243cde83 = _5878fde4f508 != self._b012cad36178
            if not _c1ef243cde83._4fe7160bbdb1():
                return _324fbf112030._417f1339577d(0.0, _c3928ad4abb7=self._63de3108f8e3)

            _7778fb94e587 = _7778fb94e587[_c1ef243cde83]
            _5878fde4f508 = _5878fde4f508[_c1ef243cde83]

            _dd5af50ed717 = self._f265ff2a93cb(_7778fb94e587, _5878fde4f508)

            if self._9e95266f5165:
                _d4aad070e11c = self._7fe27ab391ab(_5878fde4f508)
                _dd5af50ed717 = _dd5af50ed717 * _d4aad070e11c
                del _d4aad070e11c

            _b0247f6ccfc6 = _dd5af50ed717._79f9eac740b0()

            del _7778fb94e587, _5878fde4f508, _dd5af50ed717
            if _324fbf112030._7dd4686f4107._e87dd57a4172():
                _324fbf112030._7dd4686f4107._a02d772274d8()

            return _b0247f6ccfc6
        except _9bdcae5f5e02 as _554893f212f8:
            raise _a10c1dc00399(f"Error in loss forward computation: {_554893f212f8}")
