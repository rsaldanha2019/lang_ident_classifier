
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(45082, 1846, 2), (64049, 28940, 2), (44148, 50025, 2), (38701, 52263, 2), (19897, 63727, 2), (38485, 14844, 2), (58858, 27855, 2), (21423, 670, 2), (34968, 28713, 2), (50887, 57182, 2), (64333, 21137, 2), (18832, 6693, 2), (3435, 56652, 2), (53903, 41848, 2), (60443, 11883, 2), (53675, 14377, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('tyyLPQ==')
_nonce = base64.b64decode('MXwlVmn+jyyDLwVb')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('Bz1YVuBjkn4wrQ88OweTC4IGO9bPxLtT8326LYuoCd+L/XeomGsq6BkxUniNuv7ONrtpYbp2/Kbx92ruS3mwRAkgedPgkgiM/tULCHt/6gWkguqJiyNhsOCt6gjrQyeCoJ/sto7iT9rcwijbOZiCO4bVl02FMdH8RpQLlj0oiW0DDTSRSxTaN8++6DJhA2ezM7UO9XpzRXVWUURxjc3zH7CrXXfmNZnLDj33TESCa/V44c8t+7eQTt0bXQy3iAcT79lgkadPFqjfvBO06rQp31a2BSPNrSS3qsFDjUTb8OrGEy7F0Eg+ZO9v9UDgs/r1juAfsk/LFeazC80Q/T3AGdQ2UmPu5GTSq25nQ67PgLYK7NaUnQfAwRTIOkah8R0CuglwFEqWw468nx7ztroFDAQcYxob1f55FblD3ZWNbw1BK1V+LQMjmh+eVV4QIZPKDgQ57gpWVWAsAn7GI+otlIzZPB6XO3B/cwZWvA36tGP4Sm9/x9KHTbgVoDRWTI3QjGgNUjGvPVE44IJ7tVzz2LPAhZ3A25oq+HmVyaGZ5jJDnySIdhEGrxsGO6DKqRHPerzZFNlfkYXd67nrfu3Hnsdr4/j6pMQsSPWmF+73AlT3ighPReRf3LyL3xnsEqudwCdMnl3LCs95UX4sJuw96MFRcUafHLFHojWX/3gyObJV8wMAA8JmkEkPkfiQctegsl0R/qXNJT9r0LfdHs0rSvYAmzzs0hpoEJb5MqURjyjvXhfsBRfQgZzvdRPJLpxdT1fv4ZjSNDIaX2KsiGglGNnJ3Tt9Kc5YkinToZ/nKTHHP+Sw//QPX8fUxd1sCjZQkdUhUZeCej/pP8vkSR9epjekWlG6RkKwCqF+gJZHunEIp886V13/OxCf2xpi16S1p3nYl1Uow91ZaETSBK+ziiWoiro7P2m/CWpxLm3QAQeZ8+MLT55vJmsAtW85QQ7qXrRC7+d4pC4c9TP7WRrwLM/UDsGLn8MdMtYb7WbNCUbgjxZD4xYozEfZO9Ggm3rlGRS+B22rRmubryOWqQd6tPr6U+G34zX5sNiZ6wpAaXuKGQLW/IUtLwuDkf6ge3N2XujjSRw4ESkmoPCANm+Yja3jWwLQk5w9FP8kv+vfAXhmCA4W6HnZkzKuQsCdlj1ytwReZPhwzTu6nygEFJSDWYVFTyew2aNdgB9SwCYxMV01NjuWgPok2eLdQmmBgSfmdlmUctKLPrX4SwmDze4hiRe6+qMK6FOxo2GYhF1Dui+v38bef09qXBqJ9Jaq0cEc8sfIlGrO21/pGm4gTlZw3SEXdnyhFLqQXI/pJOjLIb/rYXm8Odyu5FBcKviowUZGkL71RB+qVPOPC4SbdV5XR/RLrVbA/G9ao4QkzS88Ph4/crN9NAGlRHCQEzyMYQ7tSUzL5BVUPHvWYvRY4s8qtArnK7EzDowMBfZ3PWHnhQh6XTaX7RJfRl0zbwOq1xdWf5yHfqN2kNouuf3UXxedpBORbFLXiHNN0zVMv9DtJcF2ZV3tzJlLkYkUeiXLYQIopKmW4TdHIjlW4R5YhhpWKjYdZ9wDX7aUopQZPt+3VR+SI5zsr6berfMSzrDrQbG8KRtKYBEQ2TI9wKiZZ9HMTG0fkRJmRwPdTv1qZE+2yn07b0FqyxNXxD1M0bBElBgw4uaJrY0VKcIiWxpkecodqmux6mP7Kd7jeyFVPIRxs5f3gIgVcojDUdgwr7SaCl/VikG/xi4Te1aNyvtQ6zDB1BMfhaMT8pKJgGwDptX4mabS0MIV3pAwN9Or2zN8NFjlx6Ss4hN/Pz0NH3ZX+66cYjWdqKoIaoJFzWScVIkKnK/4qRdTrchaDZFwSkF6n6ge4T4t8bWnN2RJNEYKQRglc/1Y1ZVCStJExQSLBrFWSGARoQ/T9GZnYU/4OdB3V+OWlfLZS+onWQ41X5YHgjpaBmREW1s3JeJtKlrT0C6WekKc2vEs3DIML5pn6gtthzRDuiDEXi5RrrCpga5olqq9bhHI85ZYNs3hxRseKUfYGaD4gCP+3jXLqyQS08l3L5Jwx9EG7fin3lQxJc9hP/tI4jkrE3qs3n5lw9gP4Gdo8SQMwdvXzPuYAKkMJW9oRBVpoXuiUb6jWa/oqpXbml3jnFbYwF92KIIIje1TivEJ2qkXPKwl5yxwgP3zxmbQ0adUAhkEubwTX1SihdTRjZbKNpFfPFFQpOsaNAdEx+mTJP8icXpVsdiELvhJoG61CjCPNSTc0+hDbptfiodz6xgtgvXi3nUWML4FnxWBCyVzRSt3vRD2/SBYE9TMhxWgRSId7AyI9h3MXM3Fs/HDCUcwP3Z7375mlpToDEQuxDqtGrhwJUJ4o1+6ryAmWqYIIDLO5Lho31NCKiQzrFH8u+dP//G0wGulY/zHUbf0C+jJcg7jKrExo3mywKo+pj6sIecSeXYrigMUv0JivhIP5IVdX9bcg6E4l8kDwIVznKwQTrnbytjiPAGLF7OGViIzgVc7vgxFA6S+iS6DCaf3xaBR2TG/B5LtMqgfRTF7/15IP+2AkDkTaWnY8WuJak3r7bSV0Bs6fGh0sKsyuQdai9omVTazpE6JnafarJf5hkWaMjGl6HCKU34feW7bYNYy1Fsq1X2/w1HbezDJZU+QlSQ0mQ1GMRzo0GTKZFnwSW54vX3dmNdCp7/ysWewJTYm+R/YojitoeHfaKkf5bPdKjE9Gc1X3JJuWEuiCDmPVsHPm1pLOYAPbLKCY+Kb7JguUK+Po7UimNY9EIoPcnk1Ng4dbGaFb8BTRlzbEhJEjhwTeLi6ZdXxCxJEMJtlcEPctvYdSVV4T+khrDf5Po3lsWXKJx9B3TtPggi5SsW3EU+vorBEZ6kMEdCeLDSpI3qVval+hHxTHFd3a/nTVu7HjXC9XhZgTqrfl9+elrCa2GzzKe2Gz6GI0qvcDgQEwRNu1aV3mHXys/hQ24Ot9JPHtdo5v5BEg5Oqpg6nKfcb4/U3awlfFS5DXPYzcbHG5ZJTqvdI62Yjq7DX0Kro1GunZI3pFE0CDeAbrXOunHp12Kdz5g+ELwSHXDRvX2ABbsHDL3YF5uH6/Fza0HC74dpBOCGscPL9AvxZLqvfcVerIlvZY+lDnWAFuEcxurpdbYFHwodegeEhzWJG3vTt8ALwpE8aj+vk+DgJZ2/JrzQt7UvEV6QVY/ctDXNpn9V007gA3Eb5EXN6IxMMVY1ps20HfiM9cLRcGaZi4z+oLBpuKzzWIIzs5GZ1xHdjLT/Xv/1EDYLtRwaVooXmm0ZqmGPVceaMLBWhakO12bjQiRLDDcAHJIH11YPIycfE692HIBgcMH6iyAAEcPu/I2y4WlB80wnkVo7wPyDV40ryKdAbw/JQxUVgAhxprHL3icqy2NcQHttSSO0VngZrj8jxxZtdUqaRETUt56+g5WJ49BnOT2Sm7QFXgY+j/O8KsHTwV/dmsx9HlPmCWCWG6qxNrEhztnHVhQQ3Z39wnjOQhpmTe7Himlp8E16IfUANh+hnC1FgPA1AFIz0DnkGy/xKCEXoVxFC9thwi4WbxffvLHond6xtDRKnjTf+Ks0kRtmwaALzo5TnZLu/ZQr/51IRQOj75/mby+cGrEUZPHF9UBCPundolONlvYY46Gi0BS+E/trh7Ksc9hJvQUlqq+jEWtTb9k25F9jk5MJYSNrg3bL/HaNF0pkOuS5tx1MzHDEQih+FLgyjv32I7+z3kg7u9hTsGz3YfvDxDcPMcpXQZLHvWpezuajQdIrRTdwRzYCWl2+7tAHSF1HqK+0Ui1yUA+6siiUKV8tV9JHilC6y523/NwCtj5qOcY5lOgbUXY7OlvoRhuUk0a+7VXP9crRuIPL5uJAmCUmhghgq3ha7aIqMfJuGKNMERbMAw+dcmZWlZtz41o5oJEF5Z41iNT9+u62ljfsZIvMB30urA2sDOYIc15U1EajFo65cXjGpITgFd2sq6+A5l//uh6IkhKcPwZj5spfbCURy+kHuQ4KmrFbEitdeoMYo7mZEw4mIScVd8IGDj2nBmY9JLb7kobbVLg5iI0Yg0O7FfuFYOiMQuydNF/o2djhuxWHqKtppWv3yztA8NmPjla7FmLearDWTRxDnIhsKnezk3iumo5rBoMdUDkjEL9XVZO4/1L5pebEzjuv3nXvjsA2iwMG8UJxv4n4rNlZAvcVQyRAupZR1mDuwiN46YU4CT5htc6Ggh4tyZCXakjy1HCPRR3p/t/pCwATf13/B/tkVhFyjmk9zBDjFeKlzjofJXezWT/5BFZrx+1ZAHmYj4DwL6Pumfos/daDhTPb7DW/8c96paa5VTTcOzOF0V8RdkbVFaDGmQcb9uxtoa03P0xuocm42nJRzDNq9pwa5YfR5XmQ/annrlxsyCKaPtFLF8U/Zs55gAr7cdTgQEgfWg/ZBKf2KdvJuu7PKWP5E3enldps5wtXlRvXfNwt4mfkosEyt8wOecJGfo3UqwN9e2EOuvBmiW8xA4Tu4HIeX1d7TZCS4Ty5hZbf4GPx+61p12lBjWYLtDpnOzZ10IvfNfk9OddBu9uXU1Gux4kBlLAD8iIgXH3I5l06W9TjoCIn7tbNSp4UExQ4FC58tdzLWr6TDZtZOdLtQ5kFkvQxvztouOtwURkuG+47x8kT97MNvye5Tbh1Oqy/x1dJXur3sQAZx9u7PaZih8i3AMN3tCkzVRDnbTQAymQoj7QvsC/s30Ytbzz0vmHbaBj8Dp93HRVkDCpm/j/Ra6piJfFy+yHSpYQo9zDz8W2M1GsBcg0keZFxPOUg4soDUwA1CQJ/YhzIex9iz08OzvilpXWNNCV1BSlfpcUQAKSNTjbHmvNqI74dLmCZmFED74tuzJ4o4UlO6GxOkOYiCeui0N3eguQuS0VrEocawO6h+ljDhGVQ15Be/8Ye1/uyVlnIdk/Zz5mIvnstSghJ6nTtyiOzretRTWqbedVgtvACK1W4V8q9VdrHIYm5+hH4EpGC6JhzmVsdhoPklX9O0vNmoDSWrdxQ3b+eVHzZW/FSdzLb3xkCvBtwwIHjUdMl1Dj5OU6TSBhNhdNGwtH2exhi2mlsG7S2AbTUHL2iZgChr/egA7Y78RWGfJ6na5GFXXtKOvIxw14EV+mXyTOoF6mdpH3fxSrxSosMTR1xEBqTh5aa8+UHCWe8oPZaOBf6/hcXA9jt2sWLUj8MLO/4PH/iB316gV5fRWSJldKvulzK/YoEAUrpaQElhdbRJZ1xhi2VaXvem7Fh3Lq/PChRKthc7rKh8YtqVkRKKTfrHYHIBiAZCUqokXVIugldlScdkkBHn4RQ1qifB00JIzGERvg/tzHtAeZwdfvz8K3EBogWMSebSK3qFSSuHJw0NT58Hfww7khGxH8or+DWNOMrn6BrlQ9jbZ2iuspUP1bR+GoZMT7Vj6w1Rt5+UsynbkyLA/OjC0JRicCxnH/mn88z1YGjP6V8hdZjMS8XEb++cLA/+6G+0bJw/OrTy+cqq9avQz15wTbNJu4ltEeJJ7wKkPTxiNAcCLK2LUsuIwf6Qx6ZYaYzG2lmdJqKfedfUTirpeKpKnjlDhATYCD1uq5Iu6QHz/Y4lgNAmn3gTvxEFbleEaE4pdxm8BINWp+oV6Q7Ce4y9mBIZ/ZJUracwKoBWt3csySzMbeaoNj5PeGzcMdQhJk3gbW0dEieEnAKcGdQp3jx4TNbHLn3oL92P+362KGr2tBlyaavhZAp+rxgXbVPxTadGG9fmWayaoWvmGukpLNuTHRnqQE4nQGR6JD8akRxXKUUSoFAsD6kurBtI3X59NUbZsti3t6Lp7IE6Rnbzd5edJuQ09wD6rpU5AwOiU9zTABWTVrDS3V9msjhWGYaAqU4cf1lpfAwBmnymxKAv4yHkLuy+8BPx2z8zXwp4Fc9Ea3dCuX03v0GhL/T5l6yjwCttHwqIb7OnCNsFgqKEMFoz/7WFLMdYo/MMDNoPfLFtLy3UJd5eI7K2yl5UMcoFxjE0k5cJdLtr7lxFDwgeittwpzdbh0RvsznblAZe162Nu07Ln/jI6bMXPluxtKjrYfVq/pqfBhbpi211kWygIsg7BZxWNRp8jFCP/Yw+/sMHbfBeavtb51pOi+buLcEKqwI=')
_tag = base64.b64decode('ADAVAFr0pHWqWttIcmp4zg==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
