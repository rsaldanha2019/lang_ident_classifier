# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : custom_loss
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import torch
import lightning as pl

class ClassWeightedCrossEntropyLoss(torch.nn.Module):
    def __init__(
        self,
        device='cpu',
        class_weights=None,
        reduction="mean",
        random_seed=20,
        ignore_index=-100,
        separator_token_id=None
    ):
        super().__init__()
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)

        self.curr_device = device
        self.reduction = reduction
        self.ignore_index = ignore_index

        self.class_weights_dict = class_weights or {}
        self.use_weighting = bool(self.class_weights_dict)
        self.unk_weight = self.class_weights_dict.get("unk", [[], 0.0])[1]

        self.separator_token_id = separator_token_id
        if self.separator_token_id is not None:
            # Add separator token weight if not already present
            if "separator" not in self.class_weights_dict:
                self.class_weights_dict["separator"] = ([self.separator_token_id], 0.1)

        self.token_weight_map = self._build_token_weight_map() if self.use_weighting else {}

        self.ce_loss = torch.nn.CrossEntropyLoss(
            reduction="none",
            ignore_index=self.ignore_index,
        )

    def _build_token_weight_map(self):
        weight_map = {}
        for label, (token_ids, weight) in self.class_weights_dict.items():
            if label == "unk":
                continue
            for tid in token_ids:
                weight_map[tid] = weight if weight else 0.0
        return weight_map

    def _generate_weight_mask(self, labels):
        # Initialize all weights to unk
        weight_mask = torch.full_like(labels, self.unk_weight, dtype=torch.float)

        # Assign token-specific weights
        for tid, weight in self.token_weight_map.items():
            mask = labels == tid
            weight_mask = torch.where(mask, torch.tensor(weight, device=labels.device), weight_mask)

        return weight_mask

    def forward(self, logits, targets):
        if logits.device != self.curr_device:
            logits = logits.to(self.curr_device)
        if targets.device != self.curr_device:
            targets = targets.to(self.curr_device)

        valid_mask = targets != self.ignore_index

        if not valid_mask.any():
            return torch.tensor(0.0, device=self.curr_device)

        # Apply valid mask
        logits = logits[valid_mask]
        targets = targets[valid_mask]

        loss_per_token = self.ce_loss(logits, targets)

        if self.use_weighting:
            weight_mask = self._generate_weight_mask(targets)
            loss_per_token = loss_per_token * weight_mask
            del weight_mask

        mean_loss = loss_per_token.mean()

        # Cleanup (helps during test/val loop)
        del logits, targets, loss_per_token
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return mean_loss
    
    # def forward(self, logits, targets):
    #     print("\n==== Forward Pass Debugging ====")

    #     # Print initial logits and targets
    #     print(f"Initial logits - min: {logits.min().item()}, max: {logits.max().item()}, NaNs: {torch.isnan(logits).sum().item()}")
    #     print(f"Initial targets - min: {targets.min().item()}, max: {targets.max().item()}, NaNs: {torch.isnan(targets).sum().item()}")

    #     # Flatten logits and targets
    #     logits = logits.view(-1, logits.size(-1))
    #     targets = targets.view(-1)

    #     print(f"Flattened logits shape: {logits.shape}, Flattened targets shape: {targets.shape}")

    #     # Mask out ignored indices
    #     valid_mask = targets != self.ignore_index
    #     print(f"Valid mask sum (should be >0): {valid_mask.sum().item()}")

    #     if not valid_mask.any():
    #         print("No valid targets found, returning 0 loss.")
    #         return torch.tensor(0.0, device=logits.device, requires_grad=True)

    #     logits, targets = logits[valid_mask], targets[valid_mask]

    #     # Check for NaNs and extremes after masking
    #     print(f"Post-masking logits - min: {logits.min().item()}, max: {logits.max().item()}, NaNs: {torch.isnan(logits).sum().item()}")
    #     print(f"Post-masking targets - min: {targets.min().item()}, max: {targets.max().item()}, NaNs: {torch.isnan(targets).sum().item()}")

    #     # Check for extreme logits
    #     if (logits > 10).any() or (logits < -10).any():
    #         print(f"Warning: Extreme logits found! min={logits.min().item()}, max={logits.max().item()}")
    #         # Clamp logits to prevent extreme values
    #         logits = torch.clamp(logits, min=-10, max=10)

    #     # Check for NaNs after clamping
    #     print(f"After clamping - min: {logits.min().item()}, max: {logits.max().item()}, NaNs: {torch.isnan(logits).sum().item()}")

    #     # Compute cross-entropy loss
    #     weighted_cross_entropy_loss = self.ce_loss(logits, targets)

    #     # Check for NaN loss
    #     print(f"Loss shape: {weighted_cross_entropy_loss.shape}, NaNs in loss: {torch.isnan(weighted_cross_entropy_loss).sum().item()}")

    #     # # Apply reduction
    #     if self.reduction == "mean":
    #         loss = weighted_cross_entropy_loss.mean()
    #     elif self.reduction == "sum":
    #         loss = weighted_cross_entropy_loss.sum()
    #     else:
    #         loss = weighted_cross_entropy_loss
    #     return loss

