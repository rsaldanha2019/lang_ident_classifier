# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_cross_entropy_loss.py
# @Time             : 2025-10-23 15:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _16b3493abf30


class _f28ccd4f695e(_16b3493abf30._e9c550a4b010._bf714f5e2092):
    """
    Implements class-weighted cross-entropy loss with per-token weighting.
    """

    def _5d7fecf61a49(
        self,
        _816f3fcb0123: _3c0aa483b2d6 = 'cpu',
        _2b91b13792ab: _d2a5bc1c7438 = _1fd0f6c89eb0,
        _45c1112e3495: _3c0aa483b2d6 = "mean",
        _596cb9a5c9e5: _c751f0aa44e1 = 20,
        _6c845f9408a3: _c751f0aa44e1 = -100,
        _337cdfb48762: _c751f0aa44e1 = _1fd0f6c89eb0
    ):
        """
        Initialize the loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            class_weights: Dictionary mapping class labels to (token_ids, weight).
            reduction: Reduction mode ('mean' or 'sum').
            random_seed: Random seed for reproducibility.
            ignore_index: Index to ignore in loss computation.
            separator_token: Optional token ID used as a separator.
        """
        _d9804499a1a4()._f935be7e3577()
        _16b3493abf30._36e8f0bd5de2(_596cb9a5c9e5)
        if _16b3493abf30._1eecb5fe9274._f04cba60401f():
            _16b3493abf30._1eecb5fe9274._01a977ffe751(_596cb9a5c9e5)

        self._9a2d5d96f9ce = _816f3fcb0123
        self._45c1112e3495 = _45c1112e3495
        self._6c845f9408a3 = _6c845f9408a3
        self._c4daa3e41c35 = _2b91b13792ab or {}
        self._012369352912 = _da59768fcbae(self._c4daa3e41c35)
        self._51e986e8a21d = self._c4daa3e41c35._c8be7a98d19c("unk", [[], 0.0])[1]
        self._337cdfb48762 = _337cdfb48762
        self._b79acbbfda07 = self._2db3c1b41ff0() if self._012369352912 else {}

        self._746fae9656c4 = _16b3493abf30._e9c550a4b010._f7b532585c26(
            _45c1112e3495="none",
            _6c845f9408a3=self._6c845f9408a3,
            _f27821bf8dc9=0.1,
        )

    def _c248ec8ba0a3(self):
        """
        Builds a mapping from token ID to weight based on provided class weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _b46c95724021 = {}
            _fa0801762bd4 = [
                _3b9aeb0ccd04[1]
                for _6d3cedade0c4, _3b9aeb0ccd04 in self._c4daa3e41c35._be82df61706c()
                if _6d3cedade0c4 != "unk" and _3b9aeb0ccd04[1] is not _1fd0f6c89eb0
            ]
            _114f632a2e9f = _2b5062845527(_fa0801762bd4) if _fa0801762bd4 else 0.0

            for _6d3cedade0c4, (_85b76cd806ff, _ac7a07e5232f) in self._c4daa3e41c35._be82df61706c():
                if _6d3cedade0c4 == "unk":
                    continue
                for _1f38107a857a in _85b76cd806ff:
                    _b46c95724021[_1f38107a857a] = _ac7a07e5232f if _ac7a07e5232f is not _1fd0f6c89eb0 else 0.0

            if self._337cdfb48762 is not _1fd0f6c89eb0:
                # half on min weight
                _b46c95724021[self._337cdfb48762] = _114f632a2e9f * 0.5

            return _b46c95724021
        except _1390c6bbb505 as _f2d315218757:
            raise _3a890261eaa8(f"Failed to build token weight map: {_f2d315218757}")

    def _d35527c22253(self, _c9f7960cf330: _16b3493abf30._2c75e4a46101) -> _16b3493abf30._2c75e4a46101:
        """
        Generates a tensor of weights aligned with label tensor.

        Args:
            labels: Tensor of target labels.

        Returns:
            torch.Tensor: Weight tensor.
        """
        try:
            _1b93a05bd267 = _16b3493abf30._f36d1303e7e2(_c9f7960cf330, self._51e986e8a21d, _ae37a6f71d5b=_16b3493abf30._5a80d145647b)
            for _1f38107a857a, _ac7a07e5232f in self._b79acbbfda07._be82df61706c():
                _144e86c5d61b = _c9f7960cf330 == _1f38107a857a
                _1b93a05bd267 = _16b3493abf30._ef94e111f17e(
                    _144e86c5d61b, _16b3493abf30._c96663fa80dc(_ac7a07e5232f, _816f3fcb0123=_c9f7960cf330._816f3fcb0123), _1b93a05bd267
                )
            return _1b93a05bd267
        except _1390c6bbb505 as _f2d315218757:
            raise _5a5edf1ab514(f"Error generating weight mask: {_f2d315218757}")

    def _04bf3a44b894(self, _42ba88b436c4: _16b3493abf30._2c75e4a46101, _368f10db65ac: _16b3493abf30._2c75e4a46101) -> _16b3493abf30._2c75e4a46101:
        """
        Compute the weighted cross-entropy loss.

        Args:
            logits: Model output tensor of shape (..., vocab_size).
            targets: Ground truth tensor of same leading shape as logits (excluding vocab dim).

        Returns:
            torch.Tensor: Scalar loss value.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _42ba88b436c4._816f3fcb0123 != self._9a2d5d96f9ce:
                _42ba88b436c4 = _42ba88b436c4._cf05fa42eca1(self._9a2d5d96f9ce)
            if _368f10db65ac._816f3fcb0123 != self._9a2d5d96f9ce:
                _368f10db65ac = _368f10db65ac._cf05fa42eca1(self._9a2d5d96f9ce)

            _01fd6ba2bcc3 = _368f10db65ac != self._6c845f9408a3
            if not _01fd6ba2bcc3._bb711cc46869():
                return _16b3493abf30._c96663fa80dc(0.0, _816f3fcb0123=self._9a2d5d96f9ce)

            _42ba88b436c4 = _42ba88b436c4[_01fd6ba2bcc3]
            _368f10db65ac = _368f10db65ac[_01fd6ba2bcc3]

            _85fa93ff933a = self._746fae9656c4(_42ba88b436c4, _368f10db65ac)

            if self._012369352912:
                _1b93a05bd267 = self._7a9e31638493(_368f10db65ac)
                _85fa93ff933a = _85fa93ff933a * _1b93a05bd267
                del _1b93a05bd267

            _af0fbc083316 = _85fa93ff933a._47230a616bd2()

            del _42ba88b436c4, _368f10db65ac, _85fa93ff933a
            if _16b3493abf30._1eecb5fe9274._f04cba60401f():
                _16b3493abf30._1eecb5fe9274._3eea7e8a1e16()

            return _af0fbc083316
        except _1390c6bbb505 as _f2d315218757:
            raise _5a5edf1ab514(f"Error in loss forward computation: {_f2d315218757}")
