# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : custom_loss
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import torch
import lightning as pl

class ClassWeightedFocalLossWithAdaptiveFocus(pl.LightningModule):
    def __init__(self, device='cpu', alpha=None, gamma=2, reduction="mean", gamma_type:str='default',random_seed:int=20, ignore_index:int=-100):
        super(ClassWeightedFocalLossWithAdaptiveFocus,self).__init__()
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        self.curr_device = device
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.gamma_type = gamma_type
        self.ignore_index = ignore_index

    def forward(self, logits, targets):
        # Reshape logits to (batch_size * seq_len, num_classes)
        # logits = logits.view(-1, logits.size(-1))
        # targets = targets.view(-1)

        # Create a mask to ignore the specified index
        ignore_index_mask = targets != self.ignore_index
        if not ignore_index_mask.any():
            return torch.tensor(0.0, device=logits.device, requires_grad=True)
        # kept_tokens = ignore_index_mask.sum().item()
        # print(f"Tokens contributing to loss: {kept_tokens}/{targets.numel()}")
        
        # Filter out the ignored indices
        logits = logits[ignore_index_mask]
        targets = targets[ignore_index_mask]
        # epsilon = 1e3  # large epsilon value to avoid zero probabilities
        # small_epsilon = 1e-6
        # epsilon = 1e-6

        # nan_inf_mask = torch.isnan(logits) | torch.isinf(logits)
        # logits[nan_inf_mask] = epsilon
        # if logits.numel() == 0:
        #     return torch.tensor(0.0, device=logits.device, requires_grad=True)

        # logits = torch.clamp(logits, min=-10, max=10)
        
        # Compute softmax along class dimension
        pred_softmax = torch.nn.functional.softmax(logits, dim=1).to(self.curr_device)

        # Gather the probabilities corresponding to the target labels
        pt = pred_softmax.gather(1, targets.unsqueeze(1)).to(self.curr_device).squeeze()
        # nan_inf_mask = torch.isnan(pt) | torch.isinf(pt)
        # pt[nan_inf_mask] = epsilon
        
        log_pt = torch.log(pt).to(self.curr_device)

        # nan_inf_mask = torch.isnan(log_pt) | torch.isinf(log_pt)
        # log_pt[nan_inf_mask] = epsilon

        # Apply class-specific weights if provided
        alpha_weights = None
        if self.alpha is not None:
            if isinstance(self.alpha, (int, float)):
                # Apply scalar alpha directly to focal loss
                alpha_weights = self.alpha
            else:  # Assuming alpha is a list of weights
                alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                # Truth label index alone will be used for using that particular class weight
                alpha_weights = alpha_tensor[targets]
        
        # Calculate gamma as the ratio of pt to alpha_weights
        if alpha_weights is not None:
            if self.gamma_type.casefold() == 'type1':
                gamma = pt / alpha_weights # already tried second option alpha_weights/pt but that is worse in accuracy metrics
                # gamma = alpha_weights / pt
            elif self.gamma_type.casefold() == 'type2':
                pt_raised_to_alpha = torch.pow(pt, alpha_weights)
                gamma = pt_raised_to_alpha / alpha_weights
                # gamma = alpha_weights / pt_raised_to_alpha
            else:
                # alpha_mask = alpha_weights > 1 # masks alpha greater than 1
                # print(f"alpha mask {alpha_mask}")
                # alpha_weights[alpha_mask] = 1 / alpha_weights[alpha_mask]
                # gamma = pt / alpha_weights
                alpha_mask = pt >= 0.5 # means if pt is greater than 0.5 ie good prediction then apply mask
                alpha_weights[alpha_mask] = pt[alpha_mask] # change alpha for the mask values to pt so as to not give too much imp and loss to good predictions
                gamma = pt / alpha_weights
        else:
            gamma = self.gamma  # Use the provided gamma value if alpha_weights are not provided
        
        # print(f"alpha_weights {alpha_weights}")
        # print(f"pt {pt}")
        # print(f"gamma {gamma}")
        # Compute the focal loss
        focal_loss = - ((1 - pt) ** gamma) * log_pt
        # print(f"log_pt {log_pt}")
        # print(f"focal loss before {focal_loss}")

        # Apply class-specific weights if provided
        if self.alpha is not None:
            if isinstance(self.alpha, (int, float)):
                # Apply scalar alpha directly to focal loss
                focal_loss *= self.alpha
            else:  # Assuming alpha is a list of weights
                alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                alpha_weights = alpha_tensor[targets]  # Use the original weights for corresponding targets
                focal_loss *= alpha_weights
        
        # nan_inf_mask = torch.isnan(focal_loss) | torch.isinf(focal_loss)
        # focal_loss[nan_inf_mask] = epsilon

        # print(f"Focal Loss {focal_loss}")
        
        # Apply reduction
        if self.reduction == "mean":
            loss = focal_loss.mean()
        elif self.reduction == "sum":
            loss = focal_loss.sum()
        else:
            loss = focal_loss
        return loss
