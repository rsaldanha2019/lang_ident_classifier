# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : custom_loss
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import torch
import lightning as pl

class ClassWeightedFocalLossWithAdaptiveFocus(torch.nn.Module):
    def __init__(self, device='cpu', alpha=None, gamma=2, reduction="mean", 
                 gamma_type:str='default', random_seed:int=20, ignore_index:int=-100,
                 separator_token_id=None):
        super(ClassWeightedFocalLossWithAdaptiveFocus, self).__init__()
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)

        self.curr_device = device
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.gamma_type = gamma_type
        self.ignore_index = ignore_index

        self.use_token_weights = isinstance(alpha, dict)
        if not self.use_token_weights:
            self.alpha_scalar = alpha
        else:
            self.alpha_scalar = None

        self.token_weight_map = {}
        self.unk_weight = 0.0

        self.separator_token_id = separator_token_id
        if self.separator_token_id is not None and self.alpha is not None:
            self.alpha["separator"] = ([self.separator_token_id], 0.1)
            if self.use_token_weights:
                self.token_weight_map = self._build_token_weight_map(self.alpha)

        if self.use_token_weights:
            self.unk_weight = self.alpha.get("unk", [[], 0.0])[1]
            if not self.token_weight_map:
                self.token_weight_map = self._build_token_weight_map(self.alpha)

    # def _build_token_weight_map(self, alpha_dict):
    #     weight_map = {}
    #     for label, (token_ids, weight) in alpha_dict.items():
    #         if label == "unk":
    #             continue
    #         for tid in token_ids:
    #             weight_map[tid] = weight if weight else 0.0
    #     return weight_map

    # # def _generate_token_weight_mask(self, labels):
    # #     weight_mask = torch.full_like(labels, self.unk_weight, dtype=torch.float)
    # #     for tid, weight in self.token_weight_map.items():
    # #         mask = labels == tid
    # #         weight_mask = torch.where(mask, torch.tensor(weight, device=labels.device), weight_mask)
    # #     return weight_mask

    # def _generate_token_weight_mask(self, labels):
    #     # print(f"[DEBUG] labels {labels}")
    #     # print(f"\n[DEBUG] Token Weight Map: {self.token_weight_map}")
    #     # print(f"\n[DEBUG] labels shape: {labels.shape}")
    #     # print(f"[DEBUG] unique labels: {labels.unique().tolist()}")

    #     weight_mask = torch.full_like(labels, self.unk_weight, dtype=torch.float)
    #     # print(f"[DEBUG] initial weight_mask filled with unk_weight={self.unk_weight}")

    #     for tid, weight in self.token_weight_map.items():
    #         mask = labels == tid
    #         num_matches = mask.sum().item()
    #         # print(f"[DEBUG] tid={tid}, weight={weight}, matches={num_matches}")
    #         if num_matches > 0:
    #             weight_mask = torch.where(mask, torch.tensor(weight, device=labels.device), weight_mask)

    #     # print(f"[DEBUG] final unique weights in mask: {weight_mask.unique().tolist()}")
    #     return weight_mask


    def _build_token_weight_map(self, alpha_dict):
        weight_map = {}
        for label, (token_ids, weight) in alpha_dict.items():
            if label == "unk":
                continue
            for tid in token_ids:
                weight_map[tid] = weight if weight else 0.0
        return weight_map

    def _generate_token_weight_mask(self, labels):
        weight_mask = torch.full_like(labels, self.unk_weight, dtype=torch.float)
        for tid, weight in self.token_weight_map.items():
            mask = labels == tid
            weight_mask = torch.where(mask, torch.tensor(weight, device=labels.device), weight_mask)
        return weight_mask

    def forward(self, logits, targets):
        # Reshape logits to (batch_size * seq_len, num_classes)
        # logits = logits.view(-1, logits.size(-1))
        # targets = targets.view(-1)

        # Create a mask to ignore the specified index
        ignore_index_mask = targets != self.ignore_index
        if not ignore_index_mask.any():
            return torch.tensor(0.0, device=logits.device, requires_grad=True)
        # kept_tokens = ignore_index_mask.sum().item()
        # print(f"Tokens contributing to loss: {kept_tokens}/{targets.numel()}")
        
        # Filter out the ignored indices
        logits = logits[ignore_index_mask]
        targets = targets[ignore_index_mask]
        # epsilon = 1e3  # large epsilon value to avoid zero probabilities
        # small_epsilon = 1e-6
        # epsilon = 1e-6

        # nan_inf_mask = torch.isnan(logits) | torch.isinf(logits)
        # logits[nan_inf_mask] = epsilon
        # if logits.numel() == 0:
        #     return torch.tensor(0.0, device=logits.device, requires_grad=True)

        # logits = torch.clamp(logits, min=-10, max=10)
        
        # Compute softmax along class dimension
        pred_softmax = torch.nn.functional.softmax(logits, dim=1).to(self.curr_device)

        # Gather the probabilities corresponding to the target labels
        pt = pred_softmax.gather(1, targets.unsqueeze(1)).to(self.curr_device).squeeze()
        # nan_inf_mask = torch.isnan(pt) | torch.isinf(pt)
        # pt[nan_inf_mask] = epsilon
        
        log_pt = torch.log(pt).to(self.curr_device)

        # nan_inf_mask = torch.isnan(log_pt) | torch.isinf(log_pt)
        # log_pt[nan_inf_mask] = epsilon

        # Apply class-specific weights if provided
        alpha_weights = None
        if self.alpha is not None:
            if isinstance(self.alpha, (int, float)):
                # Apply scalar alpha directly to focal loss
                alpha_weights = self.alpha
            else:  # Assuming alpha is a list of weights
                # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                # Truth label index alone will be used for using that particular class weight
                # alpha_weights = alpha_tensor[targets]
                alpha_weights = self._generate_token_weight_mask(targets)
        # print(f"Alpha weights from tokens {alpha_weights}")
        # Calculate gamma as the ratio of pt to alpha_weights
        if alpha_weights is not None:
            if self.gamma_type.casefold() == 'type1':
                gamma = pt / alpha_weights # already tried second option alpha_weights/pt but that is worse in accuracy metrics
                # gamma = alpha_weights / pt
            elif self.gamma_type.casefold() == 'type2':
                pt_raised_to_alpha = torch.pow(pt, alpha_weights)
                gamma = pt_raised_to_alpha / alpha_weights
                # gamma = alpha_weights / pt_raised_to_alpha
            else:
                # alpha_mask = alpha_weights > 1 # masks alpha greater than 1
                # print(f"alpha mask {alpha_mask}")
                # alpha_weights[alpha_mask] = 1 / alpha_weights[alpha_mask]
                # gamma = pt / alpha_weights
                alpha_mask = pt >= 0.5 # means if pt is greater than 0.5 ie good prediction then apply mask
                alpha_weights[alpha_mask] = pt[alpha_mask] # change alpha for the mask values to pt so as to not give too much imp and loss to good predictions
                gamma = pt / alpha_weights
        else:
            gamma = self.gamma  # Use the provided gamma value if alpha_weights are not provided
        
        # print(f"alpha_weights {alpha_weights}")
        # print(f"pt {pt}")
        # print(f"gamma {gamma}")
        # Compute the focal loss
        focal_loss = - ((1 - pt) ** gamma) * log_pt
        # print(f"log_pt {log_pt}")
        # print(f"focal loss before {focal_loss}")

        # Apply class-specific weights if provided
        if self.alpha is not None:
            if isinstance(self.alpha, (int, float)):
                # Apply scalar alpha directly to focal loss
                focal_loss *= self.alpha
            else:  # Assuming alpha is a list of weights
                # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                # alpha_weights = alpha_tensor[targets]  # Use the original weights for corresponding targets
                focal_loss *= alpha_weights
        
        # nan_inf_mask = torch.isnan(focal_loss) | torch.isinf(focal_loss)
        # focal_loss[nan_inf_mask] = epsilon

        # print(f"Focal Loss {focal_loss}")        
        # Apply reduction
        if self.reduction == "mean":
            loss = focal_loss.mean()
        elif self.reduction == "sum":
            loss = focal_loss.sum()
        else:
            loss = focal_loss
        return loss
