# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss_with_adaptive_focus.py
# @Time             : 2025-10-23 16:10 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _3cae8dc3ef3a
import _9a34e2545fd2 as _b659ddfb4b58


class _497324743413(_3cae8dc3ef3a._20a00906cfaa._78c7715bc79b):
    """
    Implements a class-weighted focal loss with an adaptive focusing mechanism.

    This loss extends the traditional focal loss by dynamically adjusting the
    focusing parameter (gamma) during training. It supports both scalar and
    per-token weighting schemes, allowing better handling of class imbalance
    and sequence-level label variability.
    """

    def _4300b52c222e(
        self,
        _9dab828aa210: _186e172b3098 = 'cpu',
        _228322bdc1a2=_0b0fceeaf055,
        _7d9937a7009b: _181fd8e638d4 = 2.0,
        _78c22cd3cc08: _186e172b3098 = "mean",
        _2e6a4ffe27d4: _186e172b3098 = 'default',
        _2dda69b5f9bc: _8b17fa55ea4e = 20,
        _ff653b4d0ef5: _8b17fa55ea4e = -100,
        _931b5b882941: _8b17fa55ea4e = _0b0fceeaf055
    ):
        """
        Initialize the adaptive focal loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to (token_ids, weight) tuples.
            gamma: Base focusing parameter controlling how easily classified examples
                are down-weighted.
            reduction: Specifies the reduction method ('mean', 'sum', or 'none').
            gamma_type: Strategy used to adapt gamma dynamically across epochs or batches.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional token ID used as a boundary marker.
        """
        _202519e766ea(_8b8a266ad3ae,self)._c1882293f349()
        _b659ddfb4b58._2533954443ba(_2dda69b5f9bc, _23d464fbd978=_08ee2b68bc37)
        _3cae8dc3ef3a._2f40b723d289(_2dda69b5f9bc)
        if _3cae8dc3ef3a._0dbf8dfa6378._4a04cb7afa24():
            _3cae8dc3ef3a._0dbf8dfa6378._9d0da27f1352(_2dda69b5f9bc)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        self._1384bcf0e3ce = _9dab828aa210
        self._228322bdc1a2 = _228322bdc1a2
        self._7d9937a7009b = _7d9937a7009b
        self._78c22cd3cc08 = _78c22cd3cc08
        self._2e6a4ffe27d4 = _2e6a4ffe27d4
        self._ff653b4d0ef5 = _ff653b4d0ef5
        self._931b5b882941 = _931b5b882941

        self._18010375a3c7 = _5cad4e621f7e(_228322bdc1a2, _44e07c1791fc)
        self._78c152070a38 = _228322bdc1a2 if _5cad4e621f7e(_228322bdc1a2, (_181fd8e638d4, _8b17fa55ea4e)) else _0b0fceeaf055
        self._569da91c5837 = {}
        self._457404b8471f = 0.0

        if self._18010375a3c7:
            self._457404b8471f = _228322bdc1a2._8f2485478a5b("unk", [[], 0.0])[1]
            self._569da91c5837 = self._0692b5850352(_228322bdc1a2)

    def _a9f1a143a555(self, _217f15b6855e):
        """
        Build a mapping from token IDs to their corresponding weights
        based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers
                to their associated weights.

        Returns:
            dict: Mapping from token IDs to weight values.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _5199c4e6e9be = _10d7ef511055(_2a1080eb426f for _9cbec8542d6a, (_a903015f3312, _) in _217f15b6855e._48b72fff60c2() if _9cbec8542d6a != "unk" for _2a1080eb426f in _a903015f3312) + 1
            _9945d6b28d19 = _3cae8dc3ef3a._2bc8d608e87c((_5199c4e6e9be,), self._457404b8471f, _4f9d2d53249c=_3cae8dc3ef3a._181fd8e638d4, _9dab828aa210=self._1384bcf0e3ce)
            # Find the least weight from alpha_dict (excluding 'unk')
            _e0a30d2f8c50 = [_feb4d727355e[1] for _9cbec8542d6a, _feb4d727355e in _217f15b6855e._48b72fff60c2() if _9cbec8542d6a != "unk" and _feb4d727355e[1] is not _0b0fceeaf055]
            _26301ca58336 = _c040ec709915(_e0a30d2f8c50) if _e0a30d2f8c50 else 0.0

            # Assign weights for regular tokens
            for _9cbec8542d6a, (_a903015f3312, _653736280ade) in _217f15b6855e._48b72fff60c2():
                if _9cbec8542d6a == "unk":
                    continue
                _9945d6b28d19[_a903015f3312] = _653736280ade if _653736280ade is not _0b0fceeaf055 else 0.0

            # Assign separator_token the least weight if not None
            if self._931b5b882941 is not _0b0fceeaf055:
                # half of min weight
                _9945d6b28d19[self._931b5b882941] = _26301ca58336 * 0.5

            return _9945d6b28d19
        
        except _e739bcbd718e as _c3705c4c0353:
            raise _6b61041b8b5d(f"Failed to build token weight map: {_c3705c4c0353}")        


    def _b46fb9bdd52f(self, _d89352081bf5):
        """
        Generate a weight mask tensor that aligns with the given label tensor.

        Args:
            labels: Tensor of class or token labels for which weights
                need to be applied.

        Returns:
            torch.Tensor: A float tensor of shape matching `labels`,
                containing the weight assigned to each element.

        Raises:
            RuntimeError: If label tensor contains invalid or unmapped token IDs.
        """
        try:
            return self._569da91c5837[_d89352081bf5]
        except _e739bcbd718e as _c3705c4c0353:
            raise _74d10a023e93(f"Error generating weight mask: {_c3705c4c0353}")

    def _388ce864bc59(self, _96f384ff7527, _923469732591):
        """
        Compute the adaptive focal loss for the given logits and targets.

        Args:
            logits: Predicted unnormalized scores from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If computation fails due to invalid shapes,
                numerical instability, or device mismatch.
        """
        try:
            # Create a mask to ignore the specified index
            _3243df5d406b = _923469732591 != self._ff653b4d0ef5
            if not _3243df5d406b._33d2b840da6c():
                return _3cae8dc3ef3a._5e3325beaca7(0.0, _9dab828aa210=_96f384ff7527._9dab828aa210, _28d1908da6b9=_08ee2b68bc37)
            # kept_tokens = ignore_index_mask.sum().item()
            # print(f"Tokens contributing to loss: {kept_tokens}/{targets.numel()}")
            
            # Filter out the ignored indices
            _96f384ff7527 = _96f384ff7527[_3243df5d406b]
            _923469732591 = _923469732591[_3243df5d406b]
            # epsilon = 1e3  # large epsilon value to avoid zero probabilities
            # small_epsilon = 1e-6
            # epsilon = 1e-6

            # nan_inf_mask = torch.isnan(logits) | torch.isinf(logits)
            # logits[nan_inf_mask] = epsilon
            # if logits.numel() == 0:
            #     return torch.tensor(0.0, device=logits.device, requires_grad=True)

            # logits = torch.clamp(logits, min=-10, max=10)
            
            # Compute softmax along class dimension
            # pred_softmax = torch.nn.functional.softmax(logits, dim=1).to(self.curr_device)

            # Gather the probabilities corresponding to the target labels
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).to(self.curr_device).squeeze()
            # nan_inf_mask = torch.isnan(pt) | torch.isinf(pt)
            # pt[nan_inf_mask] = epsilon
            
            # log_pt = torch.log(pt).to(self.curr_device)

            _a437be88818a = _3cae8dc3ef3a._20a00906cfaa._05b8cc636ac7._18215b2cb61b(_96f384ff7527, _74ec3ce1e66c=-1)._698b31cc5026(self._1384bcf0e3ce)
            _8bd87945d25f = 0.1
            _23642df56e32 = _96f384ff7527._c9f9010cfba6(-1)

            # Smooth pt
            _567a5b1a5fbc = _a437be88818a._c81a49340289(1, _923469732591._a6f3293cef8d(1))._09128ab5cb93()._698b31cc5026(self._1384bcf0e3ce)._09128ab5cb93()
            _567a5b1a5fbc = (1 - _8bd87945d25f) * _567a5b1a5fbc + (_8bd87945d25f / _23642df56e32)

            _1a6522199de8 = _3cae8dc3ef3a._c49f6d8de6aa(_567a5b1a5fbc)._698b31cc5026(self._1384bcf0e3ce)

            # nan_inf_mask = torch.isnan(log_pt) | torch.isinf(log_pt)
            # log_pt[nan_inf_mask] = epsilon

            # Apply class-specific weights if provided
            _166db41dae0c = _0b0fceeaf055
            if self._228322bdc1a2 is not _0b0fceeaf055:
                if _5cad4e621f7e(self._228322bdc1a2, (_8b17fa55ea4e, _181fd8e638d4)):
                    # Apply scalar alpha directly to focal loss
                    _166db41dae0c = self._228322bdc1a2
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # Truth label index alone will be used for using that particular class weight
                    # alpha_weights = alpha_tensor[targets]
                    _166db41dae0c = self._0431c9aff1dc(_923469732591)
            # print(f"Alpha weights from tokens {alpha_weights}")
            # Calculate gamma as the ratio of pt to alpha_weights
            if _166db41dae0c is not _0b0fceeaf055:
                if self._2e6a4ffe27d4._96dad1446fcd() == 'type1':
                    _7d9937a7009b = _567a5b1a5fbc / _166db41dae0c # already tried second option alpha_weights/pt but that is worse in accuracy metrics
                    # gamma = alpha_weights / pt
                elif self._2e6a4ffe27d4._96dad1446fcd() == 'type2':
                    _0a70343876cd = _3cae8dc3ef3a._a2e90dfd85ec(_567a5b1a5fbc, _166db41dae0c)
                    _7d9937a7009b = _0a70343876cd / _166db41dae0c
                    # gamma = alpha_weights / pt_raised_to_alpha
                else:
                    # alpha_mask = alpha_weights > 1 # masks alpha greater than 1
                    # print(f"alpha mask {alpha_mask}")
                    # alpha_weights[alpha_mask] = 1 / alpha_weights[alpha_mask]
                    # gamma = pt / alpha_weights
                    _d3de05b4b0e3 = _567a5b1a5fbc >= 0.5 # means if pt is greater than 0.5 ie good prediction then apply mask
                    _166db41dae0c[_d3de05b4b0e3] = _567a5b1a5fbc[_d3de05b4b0e3] # change alpha for the mask values to pt so as to not give too much imp and loss to good predictions
                    _7d9937a7009b = _567a5b1a5fbc / _166db41dae0c
            else:
                _7d9937a7009b = self._7d9937a7009b  # Use the provided gamma value if alpha_weights are not provided
            
            # print(f"alpha_weights {alpha_weights}")
            # print(f"pt {pt}")
            # print(f"gamma {gamma}")
            # Compute the focal loss
            _41c00db39112 = - ((1 - _567a5b1a5fbc) ** _7d9937a7009b) * _1a6522199de8
            # print(f"log_pt {log_pt}")
            # print(f"focal loss before {focal_loss}")

            # Apply class-specific weights if provided
            if self._228322bdc1a2 is not _0b0fceeaf055:
                if _5cad4e621f7e(self._228322bdc1a2, (_8b17fa55ea4e, _181fd8e638d4)):
                    # Apply scalar alpha directly to focal loss
                    _41c00db39112 *= self._228322bdc1a2
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # alpha_weights = alpha_tensor[targets]  # Use the original weights for corresponding targets
                    _41c00db39112 *= _166db41dae0c
            
            # nan_inf_mask = torch.isnan(focal_loss) | torch.isinf(focal_loss)
            # focal_loss[nan_inf_mask] = epsilon

            # print(f"Focal Loss {focal_loss}")        
            # Apply reduction
            if self._78c22cd3cc08 == "mean":
                _79e37f3c9b71 = _41c00db39112._1b91f839f99d()
            elif self._78c22cd3cc08 == "sum":
                _79e37f3c9b71 = _41c00db39112._82525505a787()
            else:
                _79e37f3c9b71 = _41c00db39112
            return _79e37f3c9b71

        except _e739bcbd718e as _c3705c4c0353:
            raise _74d10a023e93(f"Error in loss forward computation: {_c3705c4c0353}")     