# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss_with_adaptive_focus.py
# @Time             : 2025-10-23 16:10 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _88939aebe5af
import _b1963533ec70 as _2bc3e62e6838


class _61959efc4393(_88939aebe5af._ec6b854a36e1._d96116b84652):
    """
    Implements a class-weighted focal loss with an adaptive focusing mechanism.

    This loss extends the traditional focal loss by dynamically adjusting the
    focusing parameter (gamma) during training. It supports both scalar and
    per-token weighting schemes, allowing better handling of class imbalance
    and sequence-level label variability.
    """

    def _f860ca4e7df7(
        self,
        _954bc2e8bfd6: _0bd6c2687b3d = 'cpu',
        _b91c679cc539=_31d422c15e6a,
        _15679994661b: _fbe63c65a5ad = 2.0,
        _b8848f62f373: _0bd6c2687b3d = "mean",
        _91455b9784b5: _0bd6c2687b3d = 'default',
        _450c9cde5479: _1638b1585a17 = 20,
        _2301c81b5c5f: _1638b1585a17 = -100,
        _125c8a361d98: _1638b1585a17 = _31d422c15e6a
    ):
        """
        Initialize the adaptive focal loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to (token_ids, weight) tuples.
            gamma: Base focusing parameter controlling how easily classified examples
                are down-weighted.
            reduction: Specifies the reduction method ('mean', 'sum', or 'none').
            gamma_type: Strategy used to adapt gamma dynamically across epochs or batches.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional token ID used as a boundary marker.
        """
        _409acd4761d2(_355d51373a53,self)._63bdc410e9f8()
        _2bc3e62e6838._9ab8cfdb76f0(_450c9cde5479, _8a1cefe9b30b=_38609161de69)
        _88939aebe5af._2b9cc70bf87c(_450c9cde5479)
        if _88939aebe5af._5734599187b3._78dffd96ca4d():
            _88939aebe5af._5734599187b3._50aa37f62cd3(_450c9cde5479)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        self._0a44a6887a6b = _954bc2e8bfd6
        self._b91c679cc539 = _b91c679cc539
        self._15679994661b = _15679994661b
        self._b8848f62f373 = _b8848f62f373
        self._91455b9784b5 = _91455b9784b5
        self._2301c81b5c5f = _2301c81b5c5f
        self._125c8a361d98 = _125c8a361d98

        self._c7a231d83769 = _0292a194d7f1(_b91c679cc539, _5eb0aac28865)
        self._0438a6f735a3 = _b91c679cc539 if _0292a194d7f1(_b91c679cc539, (_fbe63c65a5ad, _1638b1585a17)) else _31d422c15e6a
        self._cb282c4bfcac = {}
        self._cb67a3ba8a81 = 0.0

        if self._c7a231d83769:
            self._cb67a3ba8a81 = _b91c679cc539._95985db3b13f("unk", [[], 0.0])[1]
            self._cb282c4bfcac = self._6cb3533e8c49(_b91c679cc539)

    def _8208593aba6f(self, _2cb542a08aa1):
        """
        Build a mapping from token IDs to their corresponding weights
        based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers
                to their associated weights.

        Returns:
            dict: Mapping from token IDs to weight values.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _895bdb42b1bc = _02ba7ccb05e2(_a0321dfc020a for _77b959888775, (_6fd37ba15a3f, _) in _2cb542a08aa1._3510bfb4bb46() if _77b959888775 != "unk" for _a0321dfc020a in _6fd37ba15a3f) + 1
            _5d4f1830124b = _88939aebe5af._80b4c17ee11e((_895bdb42b1bc,), self._cb67a3ba8a81, _341fe02f3b33=_88939aebe5af._fbe63c65a5ad, _954bc2e8bfd6=self._0a44a6887a6b)
            # Find the least weight from alpha_dict (excluding 'unk')
            _d69ee16b63ad = [_9ee0f1eedeac[1] for _77b959888775, _9ee0f1eedeac in _2cb542a08aa1._3510bfb4bb46() if _77b959888775 != "unk" and _9ee0f1eedeac[1] is not _31d422c15e6a]
            _cd9aa9245db7 = _74cb14777cc2(_d69ee16b63ad) if _d69ee16b63ad else 0.0

            # Assign weights for regular tokens
            for _77b959888775, (_6fd37ba15a3f, _6a4a511ca774) in _2cb542a08aa1._3510bfb4bb46():
                if _77b959888775 == "unk":
                    continue
                _5d4f1830124b[_6fd37ba15a3f] = _6a4a511ca774 if _6a4a511ca774 is not _31d422c15e6a else 0.0

            # Assign separator_token the least weight if not None
            if self._125c8a361d98 is not _31d422c15e6a:
                # half of min weight
                _5d4f1830124b[self._125c8a361d98] = _cd9aa9245db7 * 0.5

            return _5d4f1830124b
        
        except _b36f6eeae269 as _ee162d93e2e2:
            raise _6017af8fe4b2(f"Failed to build token weight map: {_ee162d93e2e2}")        


    def _7acc3e7b88f5(self, _142ed5b6adc1):
        """
        Generate a weight mask tensor that aligns with the given label tensor.

        Args:
            labels: Tensor of class or token labels for which weights
                need to be applied.

        Returns:
            torch.Tensor: A float tensor of shape matching `labels`,
                containing the weight assigned to each element.

        Raises:
            RuntimeError: If label tensor contains invalid or unmapped token IDs.
        """
        try:
            return self._cb282c4bfcac[_142ed5b6adc1]
        except _b36f6eeae269 as _ee162d93e2e2:
            raise _e31d0d7c015f(f"Error generating weight mask: {_ee162d93e2e2}")

    def _e62cfba137e7(self, _4f8963ea2603, _ab662f402cc8):
        """
        Compute the adaptive focal loss for the given logits and targets.

        Args:
            logits: Predicted unnormalized scores from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If computation fails due to invalid shapes,
                numerical instability, or device mismatch.
        """
        try:
            # Create a mask to ignore the specified index
            _732311d16143 = _ab662f402cc8 != self._2301c81b5c5f
            if not _732311d16143._747b6e460e33():
                return _88939aebe5af._a93ba5ae7f74(0.0, _954bc2e8bfd6=_4f8963ea2603._954bc2e8bfd6, _68374ccea8c7=_38609161de69)
            # kept_tokens = ignore_index_mask.sum().item()
            # print(f"Tokens contributing to loss: {kept_tokens}/{targets.numel()}")
            
            # Filter out the ignored indices
            _4f8963ea2603 = _4f8963ea2603[_732311d16143]
            _ab662f402cc8 = _ab662f402cc8[_732311d16143]
            # epsilon = 1e3  # large epsilon value to avoid zero probabilities
            # small_epsilon = 1e-6
            # epsilon = 1e-6

            # nan_inf_mask = torch.isnan(logits) | torch.isinf(logits)
            # logits[nan_inf_mask] = epsilon
            # if logits.numel() == 0:
            #     return torch.tensor(0.0, device=logits.device, requires_grad=True)

            # logits = torch.clamp(logits, min=-10, max=10)
            
            # Compute softmax along class dimension
            # pred_softmax = torch.nn.functional.softmax(logits, dim=1).to(self.curr_device)

            # Gather the probabilities corresponding to the target labels
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).to(self.curr_device).squeeze()
            # nan_inf_mask = torch.isnan(pt) | torch.isinf(pt)
            # pt[nan_inf_mask] = epsilon
            
            # log_pt = torch.log(pt).to(self.curr_device)

            _4719076de17f = _88939aebe5af._ec6b854a36e1._d4dbec2eb3a7._195b523c7235(_4f8963ea2603, _8878a7e20274=-1)._7967761e26da(self._0a44a6887a6b)
            _0672b92ee09f = 0.1
            _58a6f31b1265 = _4f8963ea2603._5ea8030c88c1(-1)

            # Smooth pt
            _6a9598ebd10a = _4719076de17f._a54e36e46aef(1, _ab662f402cc8._ba07bfd33f01(1))._48f83dc96026()._7967761e26da(self._0a44a6887a6b)._48f83dc96026()
            _6a9598ebd10a = (1 - _0672b92ee09f) * _6a9598ebd10a + (_0672b92ee09f / _58a6f31b1265)

            _e8ffd86ceffd = _88939aebe5af._2ee4236d9f5a(_6a9598ebd10a)._7967761e26da(self._0a44a6887a6b)

            # nan_inf_mask = torch.isnan(log_pt) | torch.isinf(log_pt)
            # log_pt[nan_inf_mask] = epsilon

            # Apply class-specific weights if provided
            _b2aaceab98a4 = _31d422c15e6a
            if self._b91c679cc539 is not _31d422c15e6a:
                if _0292a194d7f1(self._b91c679cc539, (_1638b1585a17, _fbe63c65a5ad)):
                    # Apply scalar alpha directly to focal loss
                    _b2aaceab98a4 = self._b91c679cc539
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # Truth label index alone will be used for using that particular class weight
                    # alpha_weights = alpha_tensor[targets]
                    _b2aaceab98a4 = self._1b1b4e70e9f1(_ab662f402cc8)
            # print(f"Alpha weights from tokens {alpha_weights}")
            # Calculate gamma as the ratio of pt to alpha_weights
            if _b2aaceab98a4 is not _31d422c15e6a:
                if self._91455b9784b5._5a0fbd0c3177() == 'type1':
                    _15679994661b = _6a9598ebd10a / _b2aaceab98a4 # already tried second option alpha_weights/pt but that is worse in accuracy metrics
                    # gamma = alpha_weights / pt
                elif self._91455b9784b5._5a0fbd0c3177() == 'type2':
                    _290ad1d1404a = _88939aebe5af._689275dfd61a(_6a9598ebd10a, _b2aaceab98a4)
                    _15679994661b = _290ad1d1404a / _b2aaceab98a4
                    # gamma = alpha_weights / pt_raised_to_alpha
                else:
                    # alpha_mask = alpha_weights > 1 # masks alpha greater than 1
                    # print(f"alpha mask {alpha_mask}")
                    # alpha_weights[alpha_mask] = 1 / alpha_weights[alpha_mask]
                    # gamma = pt / alpha_weights
                    _120aa82f9209 = _6a9598ebd10a >= 0.5 # means if pt is greater than 0.5 ie good prediction then apply mask
                    _b2aaceab98a4[_120aa82f9209] = _6a9598ebd10a[_120aa82f9209] # change alpha for the mask values to pt so as to not give too much imp and loss to good predictions
                    _15679994661b = _6a9598ebd10a / _b2aaceab98a4
            else:
                _15679994661b = self._15679994661b  # Use the provided gamma value if alpha_weights are not provided
            
            # print(f"alpha_weights {alpha_weights}")
            # print(f"pt {pt}")
            # print(f"gamma {gamma}")
            # Compute the focal loss
            _fa5757b7bea7 = - ((1 - _6a9598ebd10a) ** _15679994661b) * _e8ffd86ceffd
            # print(f"log_pt {log_pt}")
            # print(f"focal loss before {focal_loss}")

            # Apply class-specific weights if provided
            if self._b91c679cc539 is not _31d422c15e6a:
                if _0292a194d7f1(self._b91c679cc539, (_1638b1585a17, _fbe63c65a5ad)):
                    # Apply scalar alpha directly to focal loss
                    _fa5757b7bea7 *= self._b91c679cc539
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # alpha_weights = alpha_tensor[targets]  # Use the original weights for corresponding targets
                    _fa5757b7bea7 *= _b2aaceab98a4
            
            # nan_inf_mask = torch.isnan(focal_loss) | torch.isinf(focal_loss)
            # focal_loss[nan_inf_mask] = epsilon

            # print(f"Focal Loss {focal_loss}")        
            # Apply reduction
            if self._b8848f62f373 == "mean":
                _dac00352017c = _fa5757b7bea7._a6531f0df881()
            elif self._b8848f62f373 == "sum":
                _dac00352017c = _fa5757b7bea7._94e107c27ba0()
            else:
                _dac00352017c = _fa5757b7bea7
            return _dac00352017c

        except _b36f6eeae269 as _ee162d93e2e2:
            raise _e31d0d7c015f(f"Error in loss forward computation: {_ee162d93e2e2}")     