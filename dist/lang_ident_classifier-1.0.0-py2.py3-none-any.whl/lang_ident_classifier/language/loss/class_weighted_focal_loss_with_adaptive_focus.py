# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss_with_adaptive_focus.py
# @Time             : 2025-10-23 16:10 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _31a4b8526363
import _4d92b336dc54 as _73bf5184a799


class _8d98b699d8ad(_31a4b8526363._93ef79cc8735._501516a19cff):
    """
    Implements a class-weighted focal loss with an adaptive focusing mechanism.

    This loss extends the traditional focal loss by dynamically adjusting the
    focusing parameter (gamma) during training. It supports both scalar and
    per-token weighting schemes, allowing better handling of class imbalance
    and sequence-level label variability.
    """

    def _d1734e1a8c01(
        self,
        _796e023549a6: _b5f22d235aaa = 'cpu',
        _6da0cf253128=_078d87b75b3a,
        _6f056bbdd563: _db25eac76cec = 2.0,
        _f43da60bdd06: _b5f22d235aaa = "mean",
        _e67017b7ae50: _b5f22d235aaa = 'default',
        _61d6db25fb37: _4270f2c0d426 = 20,
        _292b394e304c: _4270f2c0d426 = -100,
        _bff8e936f8bf: _4270f2c0d426 = _078d87b75b3a
    ):
        """
        Initialize the adaptive focal loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to (token_ids, weight) tuples.
            gamma: Base focusing parameter controlling how easily classified examples
                are down-weighted.
            reduction: Specifies the reduction method ('mean', 'sum', or 'none').
            gamma_type: Strategy used to adapt gamma dynamically across epochs or batches.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional token ID used as a boundary marker.
        """
        _72e9ec31ef07(_905bacaaa312,self)._3e959556bf98()
        _73bf5184a799._8145fd9f55dc(_61d6db25fb37, _7c45abb5687b=_84d5daafabff)
        _31a4b8526363._1d6cf8cb5f51(_61d6db25fb37)
        if _31a4b8526363._612e93f1fcaa._57c713537ffa():
            _31a4b8526363._612e93f1fcaa._f22adf1a0e69(_61d6db25fb37)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        self._0feab77d7e01 = _796e023549a6
        self._6da0cf253128 = _6da0cf253128
        self._6f056bbdd563 = _6f056bbdd563
        self._f43da60bdd06 = _f43da60bdd06
        self._e67017b7ae50 = _e67017b7ae50
        self._292b394e304c = _292b394e304c
        self._bff8e936f8bf = _bff8e936f8bf

        self._ccf278388af8 = _47bcacf6f8dd(_6da0cf253128, _93eba211e551)
        self._9bdf21de1d18 = _6da0cf253128 if _47bcacf6f8dd(_6da0cf253128, (_db25eac76cec, _4270f2c0d426)) else _078d87b75b3a
        self._d4ad07d53939 = {}
        self._c44130d73d50 = 0.0

        if self._ccf278388af8:
            self._c44130d73d50 = _6da0cf253128._dc39a1f4f030("unk", [[], 0.0])[1]
            self._d4ad07d53939 = self._487d6d933788(_6da0cf253128)

    def _1892b1b102fe(self, _e615d6fa4308):
        """
        Build a mapping from token IDs to their corresponding weights
        based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers
                to their associated weights.

        Returns:
            dict: Mapping from token IDs to weight values.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _e6569cfca4ea = _13b0e1a22a1d(_88283ec77006 for _e9e3ff05737d, (_3cbcee4a074b, _) in _e615d6fa4308._849d035a01b2() if _e9e3ff05737d != "unk" for _88283ec77006 in _3cbcee4a074b) + 1
            _f4224c9cf100 = _31a4b8526363._47649f2e02eb((_e6569cfca4ea,), self._c44130d73d50, _e472081ca8d0=_31a4b8526363._db25eac76cec, _796e023549a6=self._0feab77d7e01)
            # Find the least weight from alpha_dict (excluding 'unk')
            _916e98b9f4e6 = [_131648dc86a4[1] for _e9e3ff05737d, _131648dc86a4 in _e615d6fa4308._849d035a01b2() if _e9e3ff05737d != "unk" and _131648dc86a4[1] is not _078d87b75b3a]
            _571cad974bdd = _5ec098516f32(_916e98b9f4e6) if _916e98b9f4e6 else 0.0

            # Assign weights for regular tokens
            for _e9e3ff05737d, (_3cbcee4a074b, _3f1a1fa275da) in _e615d6fa4308._849d035a01b2():
                if _e9e3ff05737d == "unk":
                    continue
                _f4224c9cf100[_3cbcee4a074b] = _3f1a1fa275da if _3f1a1fa275da is not _078d87b75b3a else 0.0

            # Assign separator_token the least weight if not None
            if self._bff8e936f8bf is not _078d87b75b3a:
                # half of min weight
                _f4224c9cf100[self._bff8e936f8bf] = _571cad974bdd * 0.5

            return _f4224c9cf100
        
        except _082054c722c9 as _cb2b83a323ae:
            raise _c84b3c1af926(f"Failed to build token weight map: {_cb2b83a323ae}")        


    def _0549277cb19e(self, _b80fa1233624):
        """
        Generate a weight mask tensor that aligns with the given label tensor.

        Args:
            labels: Tensor of class or token labels for which weights
                need to be applied.

        Returns:
            torch.Tensor: A float tensor of shape matching `labels`,
                containing the weight assigned to each element.

        Raises:
            RuntimeError: If label tensor contains invalid or unmapped token IDs.
        """
        try:
            return self._d4ad07d53939[_b80fa1233624]
        except _082054c722c9 as _cb2b83a323ae:
            raise _6d7169c67dec(f"Error generating weight mask: {_cb2b83a323ae}")

    def _24484ef9c2e7(self, _2ef6c5ec7975, _a81e57f9ec9e):
        """
        Compute the adaptive focal loss for the given logits and targets.

        Args:
            logits: Predicted unnormalized scores from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If computation fails due to invalid shapes,
                numerical instability, or device mismatch.
        """
        try:
            # Create a mask to ignore the specified index
            _c567a546d927 = _a81e57f9ec9e != self._292b394e304c
            if not _c567a546d927._1e95e778c9e8():
                return _31a4b8526363._5aa333997138(0.0, _796e023549a6=_2ef6c5ec7975._796e023549a6, _3dd00ccdf1fc=_84d5daafabff)
            # kept_tokens = ignore_index_mask.sum().item()
            # print(f"Tokens contributing to loss: {kept_tokens}/{targets.numel()}")
            
            # Filter out the ignored indices
            _2ef6c5ec7975 = _2ef6c5ec7975[_c567a546d927]
            _a81e57f9ec9e = _a81e57f9ec9e[_c567a546d927]
            # epsilon = 1e3  # large epsilon value to avoid zero probabilities
            # small_epsilon = 1e-6
            # epsilon = 1e-6

            # nan_inf_mask = torch.isnan(logits) | torch.isinf(logits)
            # logits[nan_inf_mask] = epsilon
            # if logits.numel() == 0:
            #     return torch.tensor(0.0, device=logits.device, requires_grad=True)

            # logits = torch.clamp(logits, min=-10, max=10)
            
            # Compute softmax along class dimension
            # pred_softmax = torch.nn.functional.softmax(logits, dim=1).to(self.curr_device)

            # Gather the probabilities corresponding to the target labels
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).to(self.curr_device).squeeze()
            # nan_inf_mask = torch.isnan(pt) | torch.isinf(pt)
            # pt[nan_inf_mask] = epsilon
            
            # log_pt = torch.log(pt).to(self.curr_device)

            _a0631c755e6a = _31a4b8526363._93ef79cc8735._dd0124863bd3._9556b040ced7(_2ef6c5ec7975, _67efb80a6769=-1)._dee0a95863b1(self._0feab77d7e01)
            _3be7286a235c = 0.1
            _78adaf0f3905 = _2ef6c5ec7975._fe4c43756366(-1)

            # Smooth pt
            _2add4a96952a = _a0631c755e6a._15fc0d696b27(1, _a81e57f9ec9e._83c1886f341e(1))._fb271887b733()._dee0a95863b1(self._0feab77d7e01)._fb271887b733()
            _2add4a96952a = (1 - _3be7286a235c) * _2add4a96952a + (_3be7286a235c / _78adaf0f3905)

            _920df547823d = _31a4b8526363._58d7557a2a88(_2add4a96952a)._dee0a95863b1(self._0feab77d7e01)

            # nan_inf_mask = torch.isnan(log_pt) | torch.isinf(log_pt)
            # log_pt[nan_inf_mask] = epsilon

            # Apply class-specific weights if provided
            _ec983dae88cb = _078d87b75b3a
            if self._6da0cf253128 is not _078d87b75b3a:
                if _47bcacf6f8dd(self._6da0cf253128, (_4270f2c0d426, _db25eac76cec)):
                    # Apply scalar alpha directly to focal loss
                    _ec983dae88cb = self._6da0cf253128
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # Truth label index alone will be used for using that particular class weight
                    # alpha_weights = alpha_tensor[targets]
                    _ec983dae88cb = self._986cade3bc18(_a81e57f9ec9e)
            # print(f"Alpha weights from tokens {alpha_weights}")
            # Calculate gamma as the ratio of pt to alpha_weights
            if _ec983dae88cb is not _078d87b75b3a:
                if self._e67017b7ae50._9b0071053ea0() == 'type1':
                    _6f056bbdd563 = _2add4a96952a / _ec983dae88cb # already tried second option alpha_weights/pt but that is worse in accuracy metrics
                    # gamma = alpha_weights / pt
                elif self._e67017b7ae50._9b0071053ea0() == 'type2':
                    _8540029d8c21 = _31a4b8526363._5c8dcbe28002(_2add4a96952a, _ec983dae88cb)
                    _6f056bbdd563 = _8540029d8c21 / _ec983dae88cb
                    # gamma = alpha_weights / pt_raised_to_alpha
                else:
                    # alpha_mask = alpha_weights > 1 # masks alpha greater than 1
                    # print(f"alpha mask {alpha_mask}")
                    # alpha_weights[alpha_mask] = 1 / alpha_weights[alpha_mask]
                    # gamma = pt / alpha_weights
                    _d65c222fe393 = _2add4a96952a >= 0.5 # means if pt is greater than 0.5 ie good prediction then apply mask
                    _ec983dae88cb[_d65c222fe393] = _2add4a96952a[_d65c222fe393] # change alpha for the mask values to pt so as to not give too much imp and loss to good predictions
                    _6f056bbdd563 = _2add4a96952a / _ec983dae88cb
            else:
                _6f056bbdd563 = self._6f056bbdd563  # Use the provided gamma value if alpha_weights are not provided
            
            # print(f"alpha_weights {alpha_weights}")
            # print(f"pt {pt}")
            # print(f"gamma {gamma}")
            # Compute the focal loss
            _5337698ab9b8 = - ((1 - _2add4a96952a) ** _6f056bbdd563) * _920df547823d
            # print(f"log_pt {log_pt}")
            # print(f"focal loss before {focal_loss}")

            # Apply class-specific weights if provided
            if self._6da0cf253128 is not _078d87b75b3a:
                if _47bcacf6f8dd(self._6da0cf253128, (_4270f2c0d426, _db25eac76cec)):
                    # Apply scalar alpha directly to focal loss
                    _5337698ab9b8 *= self._6da0cf253128
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # alpha_weights = alpha_tensor[targets]  # Use the original weights for corresponding targets
                    _5337698ab9b8 *= _ec983dae88cb
            
            # nan_inf_mask = torch.isnan(focal_loss) | torch.isinf(focal_loss)
            # focal_loss[nan_inf_mask] = epsilon

            # print(f"Focal Loss {focal_loss}")        
            # Apply reduction
            if self._f43da60bdd06 == "mean":
                _73757e35f7a9 = _5337698ab9b8._5c5dbb82a7e0()
            elif self._f43da60bdd06 == "sum":
                _73757e35f7a9 = _5337698ab9b8._064f9436a3fa()
            else:
                _73757e35f7a9 = _5337698ab9b8
            return _73757e35f7a9

        except _082054c722c9 as _cb2b83a323ae:
            raise _6d7169c67dec(f"Error in loss forward computation: {_cb2b83a323ae}")     