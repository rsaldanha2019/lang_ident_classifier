# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss_with_adaptive_focus.py
# @Time             : 2025-10-23 16:10 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _8d79144f43b4
import _d923c8626094 as _f7aa8c024f06


class _69ee8a727afc(_8d79144f43b4._f64f76da4b60._c2d94b2f0b71):
    """
    Implements a class-weighted focal loss with an adaptive focusing mechanism.

    This loss extends the traditional focal loss by dynamically adjusting the
    focusing parameter (gamma) during training. It supports both scalar and
    per-token weighting schemes, allowing better handling of class imbalance
    and sequence-level label variability.
    """

    def _cc9089b3052b(
        self,
        _32125725bd83: _530ea88294f6 = 'cpu',
        _1b08916f1ad2=_01454168c0e2,
        _0bc8386ba923: _478d492e2b4e = 2.0,
        _d656ee399450: _530ea88294f6 = "mean",
        _36ad15ca81ca: _530ea88294f6 = 'default',
        _4111ecd74643: _bc921a61d5a3 = 20,
        _8925838e008d: _bc921a61d5a3 = -100,
        _3cdeb7991701: _bc921a61d5a3 = _01454168c0e2
    ):
        """
        Initialize the adaptive focal loss module.

        Args:
            device: Target computation device ('cpu' or 'cuda').
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to (token_ids, weight) tuples.
            gamma: Base focusing parameter controlling how easily classified examples
                are down-weighted.
            reduction: Specifies the reduction method ('mean', 'sum', or 'none').
            gamma_type: Strategy used to adapt gamma dynamically across epochs or batches.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional token ID used as a boundary marker.
        """
        _b1cdf83f2cd9(_056b84ad3f0b,self)._0c383b997c7e()
        _f7aa8c024f06._6306e0a65107(_4111ecd74643, _60574366e6a8=_ad7ced061bc4)
        _8d79144f43b4._92824b82121a(_4111ecd74643)
        if _8d79144f43b4._82e9bcb50999._c07a705dd6a3():
            _8d79144f43b4._82e9bcb50999._9d87557455d2(_4111ecd74643)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        self._566c2744c957 = _32125725bd83
        self._1b08916f1ad2 = _1b08916f1ad2
        self._0bc8386ba923 = _0bc8386ba923
        self._d656ee399450 = _d656ee399450
        self._36ad15ca81ca = _36ad15ca81ca
        self._8925838e008d = _8925838e008d
        self._3cdeb7991701 = _3cdeb7991701

        self._e751fc7e7dc1 = _b64894177af2(_1b08916f1ad2, _669392e838cc)
        self._d9fb168a271a = _1b08916f1ad2 if _b64894177af2(_1b08916f1ad2, (_478d492e2b4e, _bc921a61d5a3)) else _01454168c0e2
        self._fc204a4ede90 = {}
        self._3bd3313321c3 = 0.0

        if self._e751fc7e7dc1:
            self._3bd3313321c3 = _1b08916f1ad2._56ebc8901f0a("unk", [[], 0.0])[1]
            self._fc204a4ede90 = self._73f1e775815a(_1b08916f1ad2)

    def _086ac0df054e(self, _56cf9073118c):
        """
        Build a mapping from token IDs to their corresponding weights
        based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers
                to their associated weights.

        Returns:
            dict: Mapping from token IDs to weight values.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _4a3224fd71c6 = _45d11877b9a4(_b974b695380e for _83d6c7b372cf, (_bb4fae4ac937, _) in _56cf9073118c._9b7d48095c42() if _83d6c7b372cf != "unk" for _b974b695380e in _bb4fae4ac937) + 1
            _0678053ba6d9 = _8d79144f43b4._c9b8cecd08cb((_4a3224fd71c6,), self._3bd3313321c3, _16537b70ce3a=_8d79144f43b4._478d492e2b4e, _32125725bd83=self._566c2744c957)
            # Find the least weight from alpha_dict (excluding 'unk')
            _52de2f5fe4d3 = [_4cbd3a429281[1] for _83d6c7b372cf, _4cbd3a429281 in _56cf9073118c._9b7d48095c42() if _83d6c7b372cf != "unk" and _4cbd3a429281[1] is not _01454168c0e2]
            _bcf8bd88a2b1 = _3698b9bb3edd(_52de2f5fe4d3) if _52de2f5fe4d3 else 0.0

            # Assign weights for regular tokens
            for _83d6c7b372cf, (_bb4fae4ac937, _5e71348bed5a) in _56cf9073118c._9b7d48095c42():
                if _83d6c7b372cf == "unk":
                    continue
                _0678053ba6d9[_bb4fae4ac937] = _5e71348bed5a if _5e71348bed5a is not _01454168c0e2 else 0.0

            # Assign separator_token the least weight if not None
            if self._3cdeb7991701 is not _01454168c0e2:
                # half of min weight
                _0678053ba6d9[self._3cdeb7991701] = _bcf8bd88a2b1 * 0.5

            return _0678053ba6d9
        
        except _3beb6c53b8a8 as _58f355cbad88:
            raise _03824595da9a(f"Failed to build token weight map: {_58f355cbad88}")        


    def _2580d936c232(self, _a140da49b462):
        """
        Generate a weight mask tensor that aligns with the given label tensor.

        Args:
            labels: Tensor of class or token labels for which weights
                need to be applied.

        Returns:
            torch.Tensor: A float tensor of shape matching `labels`,
                containing the weight assigned to each element.

        Raises:
            RuntimeError: If label tensor contains invalid or unmapped token IDs.
        """
        try:
            return self._fc204a4ede90[_a140da49b462]
        except _3beb6c53b8a8 as _58f355cbad88:
            raise _8c7732ff1473(f"Error generating weight mask: {_58f355cbad88}")

    def _31654ca36ae3(self, _5b0c01549eab, _c121fce7439e):
        """
        Compute the adaptive focal loss for the given logits and targets.

        Args:
            logits: Predicted unnormalized scores from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If computation fails due to invalid shapes,
                numerical instability, or device mismatch.
        """
        try:
            # Create a mask to ignore the specified index
            _3d6ee60d13f8 = _c121fce7439e != self._8925838e008d
            if not _3d6ee60d13f8._cf513840e660():
                return _8d79144f43b4._a8dc85566556(0.0, _32125725bd83=_5b0c01549eab._32125725bd83, _d396c29da312=_ad7ced061bc4)
            # kept_tokens = ignore_index_mask.sum().item()
            # print(f"Tokens contributing to loss: {kept_tokens}/{targets.numel()}")
            
            # Filter out the ignored indices
            _5b0c01549eab = _5b0c01549eab[_3d6ee60d13f8]
            _c121fce7439e = _c121fce7439e[_3d6ee60d13f8]
            # epsilon = 1e3  # large epsilon value to avoid zero probabilities
            # small_epsilon = 1e-6
            # epsilon = 1e-6

            # nan_inf_mask = torch.isnan(logits) | torch.isinf(logits)
            # logits[nan_inf_mask] = epsilon
            # if logits.numel() == 0:
            #     return torch.tensor(0.0, device=logits.device, requires_grad=True)

            # logits = torch.clamp(logits, min=-10, max=10)
            
            # Compute softmax along class dimension
            # pred_softmax = torch.nn.functional.softmax(logits, dim=1).to(self.curr_device)

            # Gather the probabilities corresponding to the target labels
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).to(self.curr_device).squeeze()
            # nan_inf_mask = torch.isnan(pt) | torch.isinf(pt)
            # pt[nan_inf_mask] = epsilon
            
            # log_pt = torch.log(pt).to(self.curr_device)

            _b96656525300 = _8d79144f43b4._f64f76da4b60._b6ff13b03632._c8646ef7986f(_5b0c01549eab, _811c4cbf4f68=-1)._74cb8356ebce(self._566c2744c957)
            _d8cea21bd65b = 0.1
            _3cfd59819ef7 = _5b0c01549eab._7a12f421d24b(-1)

            # Smooth pt
            _0272e85a95ca = _b96656525300._e37dc83f246a(1, _c121fce7439e._7257d36ca2ee(1))._f3ad74e4bd23()._74cb8356ebce(self._566c2744c957)._f3ad74e4bd23()
            _0272e85a95ca = (1 - _d8cea21bd65b) * _0272e85a95ca + (_d8cea21bd65b / _3cfd59819ef7)

            _2f1c7cf69875 = _8d79144f43b4._7301a39a5d84(_0272e85a95ca)._74cb8356ebce(self._566c2744c957)

            # nan_inf_mask = torch.isnan(log_pt) | torch.isinf(log_pt)
            # log_pt[nan_inf_mask] = epsilon

            # Apply class-specific weights if provided
            _25b82f6261ea = _01454168c0e2
            if self._1b08916f1ad2 is not _01454168c0e2:
                if _b64894177af2(self._1b08916f1ad2, (_bc921a61d5a3, _478d492e2b4e)):
                    # Apply scalar alpha directly to focal loss
                    _25b82f6261ea = self._1b08916f1ad2
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # Truth label index alone will be used for using that particular class weight
                    # alpha_weights = alpha_tensor[targets]
                    _25b82f6261ea = self._067b84db5f25(_c121fce7439e)
            # print(f"Alpha weights from tokens {alpha_weights}")
            # Calculate gamma as the ratio of pt to alpha_weights
            if _25b82f6261ea is not _01454168c0e2:
                if self._36ad15ca81ca._8dc5445256fd() == 'type1':
                    _0bc8386ba923 = _0272e85a95ca / _25b82f6261ea # already tried second option alpha_weights/pt but that is worse in accuracy metrics
                    # gamma = alpha_weights / pt
                elif self._36ad15ca81ca._8dc5445256fd() == 'type2':
                    _201cb42ca4fd = _8d79144f43b4._c932a19646da(_0272e85a95ca, _25b82f6261ea)
                    _0bc8386ba923 = _201cb42ca4fd / _25b82f6261ea
                    # gamma = alpha_weights / pt_raised_to_alpha
                else:
                    # alpha_mask = alpha_weights > 1 # masks alpha greater than 1
                    # print(f"alpha mask {alpha_mask}")
                    # alpha_weights[alpha_mask] = 1 / alpha_weights[alpha_mask]
                    # gamma = pt / alpha_weights
                    _b49955f7ab6c = _0272e85a95ca >= 0.5 # means if pt is greater than 0.5 ie good prediction then apply mask
                    _25b82f6261ea[_b49955f7ab6c] = _0272e85a95ca[_b49955f7ab6c] # change alpha for the mask values to pt so as to not give too much imp and loss to good predictions
                    _0bc8386ba923 = _0272e85a95ca / _25b82f6261ea
            else:
                _0bc8386ba923 = self._0bc8386ba923  # Use the provided gamma value if alpha_weights are not provided
            
            # print(f"alpha_weights {alpha_weights}")
            # print(f"pt {pt}")
            # print(f"gamma {gamma}")
            # Compute the focal loss
            _91ffa4e11cd7 = - ((1 - _0272e85a95ca) ** _0bc8386ba923) * _2f1c7cf69875
            # print(f"log_pt {log_pt}")
            # print(f"focal loss before {focal_loss}")

            # Apply class-specific weights if provided
            if self._1b08916f1ad2 is not _01454168c0e2:
                if _b64894177af2(self._1b08916f1ad2, (_bc921a61d5a3, _478d492e2b4e)):
                    # Apply scalar alpha directly to focal loss
                    _91ffa4e11cd7 *= self._1b08916f1ad2
                else:  # Assuming alpha is a list of weights
                    # alpha_tensor = torch.tensor(self.alpha, dtype=torch.float32, device=self.curr_device)
                    # alpha_weights = alpha_tensor[targets]  # Use the original weights for corresponding targets
                    _91ffa4e11cd7 *= _25b82f6261ea
            
            # nan_inf_mask = torch.isnan(focal_loss) | torch.isinf(focal_loss)
            # focal_loss[nan_inf_mask] = epsilon

            # print(f"Focal Loss {focal_loss}")        
            # Apply reduction
            if self._d656ee399450 == "mean":
                _9149b6897bf5 = _91ffa4e11cd7._f62814b21117()
            elif self._d656ee399450 == "sum":
                _9149b6897bf5 = _91ffa4e11cd7._31e79055271f()
            else:
                _9149b6897bf5 = _91ffa4e11cd7
            return _9149b6897bf5

        except _3beb6c53b8a8 as _58f355cbad88:
            raise _8c7732ff1473(f"Error in loss forward computation: {_58f355cbad88}")     