#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(25085, 22233, 2), (23354, 2234, 2), (50782, 17609, 2), (21995, 47720, 2), (27945, 65172, 2), (9848, 23624, 2), (25171, 9393, 2), (50414, 45242, 2), (51903, 54901, 2), (55188, 10276, 2), (65144, 35752, 2), (17556, 51413, 2), (64543, 34186, 2), (28174, 21328, 2), (33733, 39976, 2), (38045, 36631, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('NyRTgA==')
_nonce = base64.b64decode('x+iJ6+ZsSo5UBjS6')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('aSQt/YXiljf1Fzon8Yj3hpEg32FKd4JiiO9BGbMMs0McejYv4SYg3s4n106fwA1V9D6SLVwA9IWLmjD6aS8HtQbIk2/M55M1erz/sxQcO3i1yt4BEsQA/26ctTyReJ4M6tChw066ryyBSh3BIZ08+cuEZ05E6TebomskcZ7+I0Xc/t+2s14Ox5CuMep5pYdn9nh7ZXxb43XJjvAF9s9SHWKWLPZFHKhHbIKEHjA3H8AppGMRJ/UCWyeqTm3SAsT+IruF4L/qsqX5/AsLNA6BM0AqHcUJv3LDeL0XIeuOqOdbychDjyJA0WjU8zTrX3tfbV1MKqBDjN3Do49TugENWVkxSKgAugwR+Q==')
_tag = base64.b64decode('iHxNvrI0AXLHBVZwqQD90A==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
