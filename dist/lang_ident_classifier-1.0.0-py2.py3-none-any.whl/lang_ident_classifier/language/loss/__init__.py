#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(57358, 44237, 2), (23367, 13716, 2), (35374, 31349, 2), (29503, 18576, 2), (49548, 41692, 2), (10348, 65317, 2), (34800, 49556, 2), (32660, 37325, 2), (1086, 38659, 2), (50630, 25998, 2), (17063, 52650, 2), (63479, 57457, 2), (28706, 21833, 2), (17385, 64253, 2), (35728, 3384, 2), (24321, 14178, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('TMNu0w==')
_nonce = base64.b64decode('4TRZBuWyJE9qBof5')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('Wp6suEsSoj084pm5wB8NLi2LnvF+tVHyBLxWgPzI2oRO4xAV6bb0DvSDkiz+TtkFoQyQKG59QmM1YVhq4RjkCKKcdtKFEtDvgzw2C17xyshVDW3p4BVhL6dx2B3lM3SvHj++RtvforYDDoxt36ZiObd1ny70rBu3cwtkhH8Q39mJiekpANtFC2UuGk6xqLRyuGLD3EIsT2v/7rcdo69sjXQs6+dRsD3S6WjqTmqCqQqSQ59R19F4thyAgIKTqI11XzafsaYLft5KlyEF3Ht1kolTOH+P7nfnxFvwawlldECKjUkREArUJzLlT2t7ErRwRIMCF+1zJUX+P0cEMjR6S3tEUs66p3IrEw==')
_tag = base64.b64decode('u9OC4jsgAd9r5jN4vvNkEw==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
