
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(60085, 60800, 2), (25505, 59547, 2), (32345, 24910, 2), (21000, 24853, 2), (43797, 21900, 2), (36575, 13329, 2), (32845, 54965, 2), (33669, 6615, 2), (10852, 3229, 2), (32231, 9217, 2), (60586, 5079, 2), (37350, 59637, 2), (49544, 61610, 2), (46064, 36466, 2), (37094, 4030, 2), (25940, 65535, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('BzWLOg==')
_nonce = base64.b64decode('7lseV1G0OfxKgh4H')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('h5kJjA9AnflHw1iQLad3x6h+9J2LfswN48yZLDW2+LaBQczl+HjZyw/3966bFL4B998lAEWDZ4jzvxpfSwJe5kjnvVHVEWbtkE7UaNsaORYt6kJgopkEJ0maR3v4MknmtqZDJf4KffKhD/WYiZEEVsZli1xSihvjTVEnRg7/scxaW4VM/BQ1IXUo5iX4s0YZUHOztqigVGerHwYLnNRVAIpkYa8lCi/KJZtBY+vXWWSuNO3QtIZnzdbb6c8p7p/fI/BXmVyYTAIewbQByuSQw6vni2fgIOqkFMWi7i0R5mPPR/6/ESnzu7tWA5ONGcMnFvvrvua/H+JSirL/DqYnZYxmaYkxIPQgig==')
_tag = base64.b64decode('9MaJnBNsxrdOlafclUtUVQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
