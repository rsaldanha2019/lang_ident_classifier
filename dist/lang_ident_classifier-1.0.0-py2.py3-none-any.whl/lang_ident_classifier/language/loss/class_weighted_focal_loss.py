# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss.py
# @Time             : 2025-10-23 16:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _b2f36e2583d9
import _00f2437cd85d as _37339dfbf08f

class _893ab4730528(_b2f36e2583d9._bbbd660d570a._d592ee58e1d4):
    """
    Implements a class-weighted focal loss function with optional per-token weighting.

    This loss combines focal scaling with class or token-specific weights to handle
    class imbalance in sequence-level or token-level classification tasks.
    """

    def _83aff29217e0(
        self,
        _56aa0739f0c0: _08ebcef58c9c = "cpu",
        _1807233afdfb=_b93d9f7024b6,
        _a38038abbd20: _8d0cf6fd425d = 2.0,
        _c16a662aa3ec: _08ebcef58c9c = "mean",
        _476508d8df41: _f7a67ced6f25 = 20,
        _d56f714ed00c: _f7a67ced6f25 = -100,
        _6ab22782bbca: _f7a67ced6f25 = _b93d9f7024b6,
    ):
        """
        Initialize the weighted focal loss module.

        Args:
            device: Computation device, e.g., 'cpu' or 'cuda'.
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to weights.
            gamma: Focusing parameter that controls down-weighting of easy examples.
            reduction: Reduction method to apply to the final loss. Options: 'mean', 'sum', or 'none'.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional special token to assign custom weight.
        """
        _b0908d499371(_9e05a463b1f1, self)._a5d3d5d4a3de()
        _37339dfbf08f._4d1efec88eae(_476508d8df41, _d76574284cf7=_2671d35fb90c)
        _b2f36e2583d9._c75d377f89d5(_476508d8df41)
        if _b2f36e2583d9._05df3d80445d._10e16cbaff14():
            _b2f36e2583d9._05df3d80445d._749e61072f4d(_476508d8df41)

        self._a7395f06ed76 = _56aa0739f0c0
        self._1807233afdfb = _1807233afdfb
        self._a38038abbd20 = _a38038abbd20
        self._c16a662aa3ec = _c16a662aa3ec
        self._d56f714ed00c = _d56f714ed00c
        self._6ab22782bbca = _6ab22782bbca

        self._6af95d606869 = _3eb2fa596ea0(_1807233afdfb, _d9a28a070b21)
        self._c6e042269073 = {}
        self._3e2c975c6f27 = 0.0

        if self._6af95d606869:
            self._3e2c975c6f27 = _1807233afdfb._f7a15a1fafe6("unk", [[], 0.0])[1]
            self._c6e042269073 = self._ef53a591da63(_1807233afdfb)

    def _745a2fcfe6cd(self, _7c8f46c91aab):
        """
        Build a mapping from token IDs to weights based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers to their respective weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _221a1f4ffd81 = {}
            # Find the least weight from alpha_dict (excluding 'unk')
            _9fcd921a4e09 = [_b1fc2c098664[1] for _416f476b3ff0, _b1fc2c098664 in _7c8f46c91aab._c718d9ff1f28() if _416f476b3ff0 != "unk" and _b1fc2c098664[1] is not _b93d9f7024b6]
            _9529aa226f72 = _acbc4bc001be(_9fcd921a4e09) if _9fcd921a4e09 else 0.0

            # Build weight map for regular tokens
            for _416f476b3ff0, (_984e3ea5092e, _5b82f63ad82e) in _7c8f46c91aab._c718d9ff1f28():
                if _416f476b3ff0 == "unk":
                    continue
                for _491b44dcf952 in _984e3ea5092e:
                    _221a1f4ffd81[_491b44dcf952] = _5b82f63ad82e if _5b82f63ad82e is not _b93d9f7024b6 else 0.0

            # Assign separator_token the least weight if not None
            if self._6ab22782bbca is not _b93d9f7024b6:
                # half of min weight
                _221a1f4ffd81[self._6ab22782bbca] = _9529aa226f72 * 0.5
            
            return _221a1f4ffd81

        except _fd9dee13f405 as _fb8cb8488a7d:
            raise _4a15980ddbd3(f"Failed to build token weight map: {_fb8cb8488a7d}")

    def _9c9e9a2b9f79(self, _4b677e1ae3a2):
        """
        Generate a per-token weight mask for the provided label tensor.

        Args:
            labels: Tensor of target labels (token IDs).

        Returns:
            torch.Tensor: A float tensor of the same shape as labels, where each entry
            represents the weight assigned to that token.

        Raises:
            RuntimeError: If label tensor shape is incompatible or mapping fails.
        """
        try:
            _3380bf804d9e = _b2f36e2583d9._1c32b39212d7(_4b677e1ae3a2, self._3e2c975c6f27, _18239c77435f=_b2f36e2583d9._8d0cf6fd425d)
            for _491b44dcf952, _5b82f63ad82e in self._c6e042269073._c718d9ff1f28():
                _91918581b184 = _4b677e1ae3a2 == _491b44dcf952
                _3380bf804d9e = _b2f36e2583d9._79dd9f4a1f2d(_91918581b184, _b2f36e2583d9._7a80866f9998(_5b82f63ad82e, _56aa0739f0c0=_4b677e1ae3a2._56aa0739f0c0), _3380bf804d9e)
            return _3380bf804d9e
        except _fd9dee13f405 as _fb8cb8488a7d:
            raise _72fffdc88b76(f"Error generating weight mask: {_fb8cb8488a7d}")
        

    def _64195720da58(self, _5a7fa833569e, _9d1bb9ee5b7a):
        """
        Compute the focal loss with class or token weighting.

        Args:
            logits: Predicted unnormalized scores (logits) from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _5a7fa833569e._56aa0739f0c0 != self._a7395f06ed76:
                _5a7fa833569e = _5a7fa833569e._67507b2959d5(self._a7395f06ed76)
            if _9d1bb9ee5b7a._56aa0739f0c0 != self._a7395f06ed76:
                _9d1bb9ee5b7a = _9d1bb9ee5b7a._67507b2959d5(self._a7395f06ed76)

            # Ignore padding or invalid targets
            _546adb890956 = _9d1bb9ee5b7a != self._d56f714ed00c
            if not _546adb890956._9444bb38d1fb():
                return _b2f36e2583d9._7a80866f9998(0.0, _56aa0739f0c0=_5a7fa833569e._56aa0739f0c0, _03a5ceeeef07=_2671d35fb90c)

            _5a7fa833569e = _5a7fa833569e[_546adb890956]
            _9d1bb9ee5b7a = _9d1bb9ee5b7a[_546adb890956]

            # pred_softmax = torch.nn.functional.softmax(logits, dim=1)
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).squeeze()
            # log_pt = torch.log(pt)

            # focal_loss = -((1 - pt) ** self.gamma) * log_pt
            _1795fec331c7 = _b2f36e2583d9._bbbd660d570a._c90baf4b9172._986c70c4c9d5(_5a7fa833569e, _834f8a077cb9=-1)
            _010d0337803d = 0.1
            _9659480273ae = _5a7fa833569e._e24e61aabba9(-1)

            # Smooth pt
            _369322e23e3b = _1795fec331c7._7172753d12b9(1, _9d1bb9ee5b7a._d0345544faea(1))._715c67ad7cef()
            _369322e23e3b = (1 - _010d0337803d) * _369322e23e3b + (_010d0337803d / _9659480273ae)

            _61581e64c121 = _b2f36e2583d9._cd3c178b30f8(_369322e23e3b)
            _f072ed2d6bb8 = -((1 - _369322e23e3b) ** self._a38038abbd20) * _61581e64c121

            # Apply class-specific weights if provided
            if self._1807233afdfb is not _b93d9f7024b6:
                if _3eb2fa596ea0(self._1807233afdfb, (_f7a67ced6f25, _8d0cf6fd425d)):
                    # Apply scalar alpha directly to focal loss
                    _f072ed2d6bb8 *= self._1807233afdfb
                else:  # Assuming alpha is a dict like {label: ([token_ids], weight)}
                    _139af90e2e96 = self._e90a2bf9c78d(_9d1bb9ee5b7a)
                    _f072ed2d6bb8 *= _139af90e2e96
                    del _139af90e2e96

            # Reduction
            if self._c16a662aa3ec == "mean":
                _80161ac18d71 = _f072ed2d6bb8._32592abb9c2c()
            elif self._c16a662aa3ec == "sum":
                _80161ac18d71 = _f072ed2d6bb8._e78fd678ed52()
            else:
                _80161ac18d71 = _f072ed2d6bb8

            # Cleanup
            del _5a7fa833569e, _9d1bb9ee5b7a, _f072ed2d6bb8
            if _b2f36e2583d9._05df3d80445d._10e16cbaff14():
                _b2f36e2583d9._05df3d80445d._d6bcb31070a7()

            return _80161ac18d71

        except _fd9dee13f405 as _fb8cb8488a7d:
            raise _72fffdc88b76(f"Error in loss forward computation: {_fb8cb8488a7d}")