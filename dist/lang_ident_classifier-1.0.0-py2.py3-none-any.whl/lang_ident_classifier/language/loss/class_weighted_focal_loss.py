# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss.py
# @Time             : 2025-10-23 16:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _c116d59162f6
import _63a69fd3cbc6 as _f0c73f85f1ee

class _f47fba1a6fa1(_c116d59162f6._42285afabdb4._cddf18e9031b):
    """
    Implements a class-weighted focal loss function with optional per-token weighting.

    This loss combines focal scaling with class or token-specific weights to handle
    class imbalance in sequence-level or token-level classification tasks.
    """

    def _fc3b466818e4(
        self,
        _c599d68d5b71: _1abc29917454 = "cpu",
        _cdc97c5d813f=_0edae904f54e,
        _9fbf09c9ca17: _12a95fe5820e = 2.0,
        _65edecf7c1ff: _1abc29917454 = "mean",
        _96c9ddbb4945: _bd7277c29d58 = 20,
        _10482787ef97: _bd7277c29d58 = -100,
        _4d9b77023d33: _bd7277c29d58 = _0edae904f54e,
    ):
        """
        Initialize the weighted focal loss module.

        Args:
            device: Computation device, e.g., 'cpu' or 'cuda'.
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to weights.
            gamma: Focusing parameter that controls down-weighting of easy examples.
            reduction: Reduction method to apply to the final loss. Options: 'mean', 'sum', or 'none'.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional special token to assign custom weight.
        """
        _64bb134f5efc(_de4f59759f9c, self)._f688b793d496()
        _f0c73f85f1ee._753edf5d546f(_96c9ddbb4945, _bb922e131bd5=_2ee67c79a82e)
        _c116d59162f6._d436b8d60ee5(_96c9ddbb4945)
        if _c116d59162f6._40cecf55b46c._999e32b338ac():
            _c116d59162f6._40cecf55b46c._da0792a27198(_96c9ddbb4945)

        self._8ccdb009b732 = _c599d68d5b71
        self._cdc97c5d813f = _cdc97c5d813f
        self._9fbf09c9ca17 = _9fbf09c9ca17
        self._65edecf7c1ff = _65edecf7c1ff
        self._10482787ef97 = _10482787ef97
        self._4d9b77023d33 = _4d9b77023d33

        self._e6ea5d15f5e7 = _9c36c911a6b4(_cdc97c5d813f, _6b5d5c0464df)
        self._c1d5db226ff4 = {}
        self._09274e23b489 = 0.0

        if self._e6ea5d15f5e7:
            self._09274e23b489 = _cdc97c5d813f._2bf6d49c0570("unk", [[], 0.0])[1]
            self._c1d5db226ff4 = self._5b3411c24704(_cdc97c5d813f)

    def _105d85ebe397(self, _517600fc27cc):
        """
        Build a mapping from token IDs to weights based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers to their respective weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _400da3742d0f = {}
            # Find the least weight from alpha_dict (excluding 'unk')
            _c20bd3f04601 = [_909893b26aa1[1] for _a6cf338c60ad, _909893b26aa1 in _517600fc27cc._060987663771() if _a6cf338c60ad != "unk" and _909893b26aa1[1] is not _0edae904f54e]
            _c022506d2fd2 = _18e8427d8d3f(_c20bd3f04601) if _c20bd3f04601 else 0.0

            # Build weight map for regular tokens
            for _a6cf338c60ad, (_f3afda595923, _4d28753ace83) in _517600fc27cc._060987663771():
                if _a6cf338c60ad == "unk":
                    continue
                for _0b467511d4f2 in _f3afda595923:
                    _400da3742d0f[_0b467511d4f2] = _4d28753ace83 if _4d28753ace83 is not _0edae904f54e else 0.0

            # Assign separator_token the least weight if not None
            if self._4d9b77023d33 is not _0edae904f54e:
                # half of min weight
                _400da3742d0f[self._4d9b77023d33] = _c022506d2fd2 * 0.5
            
            return _400da3742d0f

        except _dee188c0baf4 as _ff3604d2b4f3:
            raise _2e011a862e37(f"Failed to build token weight map: {_ff3604d2b4f3}")

    def _dc910842d5de(self, _888ff6b9e7b6):
        """
        Generate a per-token weight mask for the provided label tensor.

        Args:
            labels: Tensor of target labels (token IDs).

        Returns:
            torch.Tensor: A float tensor of the same shape as labels, where each entry
            represents the weight assigned to that token.

        Raises:
            RuntimeError: If label tensor shape is incompatible or mapping fails.
        """
        try:
            _9cc608075684 = _c116d59162f6._baa1b064f0b3(_888ff6b9e7b6, self._09274e23b489, _c322000e7b2e=_c116d59162f6._12a95fe5820e)
            for _0b467511d4f2, _4d28753ace83 in self._c1d5db226ff4._060987663771():
                _00f03fb247b2 = _888ff6b9e7b6 == _0b467511d4f2
                _9cc608075684 = _c116d59162f6._9b19b36dcddb(_00f03fb247b2, _c116d59162f6._58ded169964e(_4d28753ace83, _c599d68d5b71=_888ff6b9e7b6._c599d68d5b71), _9cc608075684)
            return _9cc608075684
        except _dee188c0baf4 as _ff3604d2b4f3:
            raise _7b609c900e88(f"Error generating weight mask: {_ff3604d2b4f3}")
        

    def _160752c6696b(self, _4beee12e156d, _519ceb358ccd):
        """
        Compute the focal loss with class or token weighting.

        Args:
            logits: Predicted unnormalized scores (logits) from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _4beee12e156d._c599d68d5b71 != self._8ccdb009b732:
                _4beee12e156d = _4beee12e156d._eb5a19e8ecc2(self._8ccdb009b732)
            if _519ceb358ccd._c599d68d5b71 != self._8ccdb009b732:
                _519ceb358ccd = _519ceb358ccd._eb5a19e8ecc2(self._8ccdb009b732)

            # Ignore padding or invalid targets
            _9ecc69374940 = _519ceb358ccd != self._10482787ef97
            if not _9ecc69374940._1672b470970c():
                return _c116d59162f6._58ded169964e(0.0, _c599d68d5b71=_4beee12e156d._c599d68d5b71, _e17cd805db6f=_2ee67c79a82e)

            _4beee12e156d = _4beee12e156d[_9ecc69374940]
            _519ceb358ccd = _519ceb358ccd[_9ecc69374940]

            # pred_softmax = torch.nn.functional.softmax(logits, dim=1)
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).squeeze()
            # log_pt = torch.log(pt)

            # focal_loss = -((1 - pt) ** self.gamma) * log_pt
            _60015b90d390 = _c116d59162f6._42285afabdb4._796c15e6831e._b55703cbefb8(_4beee12e156d, _39dae6110d7e=-1)
            _e83105c58177 = 0.1
            _7f02b2f34466 = _4beee12e156d._bcd2bf085a51(-1)

            # Smooth pt
            _ea2231bc9889 = _60015b90d390._efa68730dc0c(1, _519ceb358ccd._dae99463cb08(1))._0d7fd60c2abf()
            _ea2231bc9889 = (1 - _e83105c58177) * _ea2231bc9889 + (_e83105c58177 / _7f02b2f34466)

            _b9a675bc0651 = _c116d59162f6._6824f6d2e0a9(_ea2231bc9889)
            _912c43ed018b = -((1 - _ea2231bc9889) ** self._9fbf09c9ca17) * _b9a675bc0651

            # Apply class-specific weights if provided
            if self._cdc97c5d813f is not _0edae904f54e:
                if _9c36c911a6b4(self._cdc97c5d813f, (_bd7277c29d58, _12a95fe5820e)):
                    # Apply scalar alpha directly to focal loss
                    _912c43ed018b *= self._cdc97c5d813f
                else:  # Assuming alpha is a dict like {label: ([token_ids], weight)}
                    _7a48602454c1 = self._35a23d87f0c9(_519ceb358ccd)
                    _912c43ed018b *= _7a48602454c1
                    del _7a48602454c1

            # Reduction
            if self._65edecf7c1ff == "mean":
                _7d2287fa9c76 = _912c43ed018b._0a1ab778b4ba()
            elif self._65edecf7c1ff == "sum":
                _7d2287fa9c76 = _912c43ed018b._47b57a1d2856()
            else:
                _7d2287fa9c76 = _912c43ed018b

            # Cleanup
            del _4beee12e156d, _519ceb358ccd, _912c43ed018b
            if _c116d59162f6._40cecf55b46c._999e32b338ac():
                _c116d59162f6._40cecf55b46c._8bc9110541fa()

            return _7d2287fa9c76

        except _dee188c0baf4 as _ff3604d2b4f3:
            raise _7b609c900e88(f"Error in loss forward computation: {_ff3604d2b4f3}")