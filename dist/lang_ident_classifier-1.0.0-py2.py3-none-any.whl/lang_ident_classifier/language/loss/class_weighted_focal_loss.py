# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss.py
# @Time             : 2025-10-23 16:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _53d82f3afe79
import _b583e8519e17 as _314f113827b9

class _07f9962f883c(_53d82f3afe79._cce9f0af614c._553ae2925ccf):
    """
    Implements a class-weighted focal loss function with optional per-token weighting.

    This loss combines focal scaling with class or token-specific weights to handle
    class imbalance in sequence-level or token-level classification tasks.
    """

    def _33b071b8d220(
        self,
        _b6381b130851: _7be0b779dd4e = "cpu",
        _9da79c51e13f=_ff20e1a64de3,
        _5ffc8b35f0d8: _bedc4a5fd3dc = 2.0,
        _fdfcf0b9ba8e: _7be0b779dd4e = "mean",
        _d200757b2b64: _2ed350aca0b2 = 20,
        _4d4ca1428112: _2ed350aca0b2 = -100,
        _1770640a8584: _2ed350aca0b2 = _ff20e1a64de3,
    ):
        """
        Initialize the weighted focal loss module.

        Args:
            device: Computation device, e.g., 'cpu' or 'cuda'.
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to weights.
            gamma: Focusing parameter that controls down-weighting of easy examples.
            reduction: Reduction method to apply to the final loss. Options: 'mean', 'sum', or 'none'.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional special token to assign custom weight.
        """
        _ca7fd93c34c0(_85b137127c81, self)._5a3e8c39d314()
        _314f113827b9._4f908a5d01f2(_d200757b2b64, _c37669714e70=_46afcf37a28e)
        _53d82f3afe79._1ed2ebff408b(_d200757b2b64)
        if _53d82f3afe79._89f3608fec3f._a1eb3ec6e93d():
            _53d82f3afe79._89f3608fec3f._a5ec6f267e95(_d200757b2b64)

        self._6d2221122121 = _b6381b130851
        self._9da79c51e13f = _9da79c51e13f
        self._5ffc8b35f0d8 = _5ffc8b35f0d8
        self._fdfcf0b9ba8e = _fdfcf0b9ba8e
        self._4d4ca1428112 = _4d4ca1428112
        self._1770640a8584 = _1770640a8584

        self._089f3b1fba70 = _6d15bf82ccbb(_9da79c51e13f, _259600418ccb)
        self._12d42c1e5593 = {}
        self._e80c76322df4 = 0.0

        if self._089f3b1fba70:
            self._e80c76322df4 = _9da79c51e13f._2406d8986c6e("unk", [[], 0.0])[1]
            self._12d42c1e5593 = self._3159e531712d(_9da79c51e13f)

    def _53ab8e3cc187(self, _4a6445535cc6):
        """
        Build a mapping from token IDs to weights based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers to their respective weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _dad06bffd8c1 = {}
            # Find the least weight from alpha_dict (excluding 'unk')
            _98cffbbef3ef = [_65440b4d652d[1] for _5f9397ab7f19, _65440b4d652d in _4a6445535cc6._03321a4c3b7c() if _5f9397ab7f19 != "unk" and _65440b4d652d[1] is not _ff20e1a64de3]
            _4f9d39acac40 = _8d8531962c59(_98cffbbef3ef) if _98cffbbef3ef else 0.0

            # Build weight map for regular tokens
            for _5f9397ab7f19, (_98327d33eca1, _26ac317a5e44) in _4a6445535cc6._03321a4c3b7c():
                if _5f9397ab7f19 == "unk":
                    continue
                for _b6269f68ceeb in _98327d33eca1:
                    _dad06bffd8c1[_b6269f68ceeb] = _26ac317a5e44 if _26ac317a5e44 is not _ff20e1a64de3 else 0.0

            # Assign separator_token the least weight if not None
            if self._1770640a8584 is not _ff20e1a64de3:
                # half of min weight
                _dad06bffd8c1[self._1770640a8584] = _4f9d39acac40 * 0.5
            
            return _dad06bffd8c1

        except _31ed12179815 as _5a2811c5f5e9:
            raise _b5630d22134e(f"Failed to build token weight map: {_5a2811c5f5e9}")

    def _05017d187430(self, _2c487933977b):
        """
        Generate a per-token weight mask for the provided label tensor.

        Args:
            labels: Tensor of target labels (token IDs).

        Returns:
            torch.Tensor: A float tensor of the same shape as labels, where each entry
            represents the weight assigned to that token.

        Raises:
            RuntimeError: If label tensor shape is incompatible or mapping fails.
        """
        try:
            _af3b2b3548d7 = _53d82f3afe79._1b5a5f9b6c87(_2c487933977b, self._e80c76322df4, _6dc226b9013c=_53d82f3afe79._bedc4a5fd3dc)
            for _b6269f68ceeb, _26ac317a5e44 in self._12d42c1e5593._03321a4c3b7c():
                _9fcd0f92b360 = _2c487933977b == _b6269f68ceeb
                _af3b2b3548d7 = _53d82f3afe79._79282e555041(_9fcd0f92b360, _53d82f3afe79._33e93c6464ce(_26ac317a5e44, _b6381b130851=_2c487933977b._b6381b130851), _af3b2b3548d7)
            return _af3b2b3548d7
        except _31ed12179815 as _5a2811c5f5e9:
            raise _69a746148444(f"Error generating weight mask: {_5a2811c5f5e9}")
        

    def _992461fb2577(self, _2487020139b3, _ddcd2ac60169):
        """
        Compute the focal loss with class or token weighting.

        Args:
            logits: Predicted unnormalized scores (logits) from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _2487020139b3._b6381b130851 != self._6d2221122121:
                _2487020139b3 = _2487020139b3._7f0285a33358(self._6d2221122121)
            if _ddcd2ac60169._b6381b130851 != self._6d2221122121:
                _ddcd2ac60169 = _ddcd2ac60169._7f0285a33358(self._6d2221122121)

            # Ignore padding or invalid targets
            _a1e9bd5605aa = _ddcd2ac60169 != self._4d4ca1428112
            if not _a1e9bd5605aa._64491cf4fb2c():
                return _53d82f3afe79._33e93c6464ce(0.0, _b6381b130851=_2487020139b3._b6381b130851, _e1ec4d64def2=_46afcf37a28e)

            _2487020139b3 = _2487020139b3[_a1e9bd5605aa]
            _ddcd2ac60169 = _ddcd2ac60169[_a1e9bd5605aa]

            # pred_softmax = torch.nn.functional.softmax(logits, dim=1)
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).squeeze()
            # log_pt = torch.log(pt)

            # focal_loss = -((1 - pt) ** self.gamma) * log_pt
            _c37631f252b5 = _53d82f3afe79._cce9f0af614c._ed57dad8ce11._fbf827f4f676(_2487020139b3, _bc0c05d2e181=-1)
            _3b1bdc5b63e5 = 0.1
            _2120e8533d88 = _2487020139b3._a422ff9fc8fe(-1)

            # Smooth pt
            _d4fec628c928 = _c37631f252b5._3ed8cd2d3b52(1, _ddcd2ac60169._e1952e279f0f(1))._6f5a1161b371()
            _d4fec628c928 = (1 - _3b1bdc5b63e5) * _d4fec628c928 + (_3b1bdc5b63e5 / _2120e8533d88)

            _500c20c911e3 = _53d82f3afe79._714d4540085c(_d4fec628c928)
            _d4b6effebd83 = -((1 - _d4fec628c928) ** self._5ffc8b35f0d8) * _500c20c911e3

            # Apply class-specific weights if provided
            if self._9da79c51e13f is not _ff20e1a64de3:
                if _6d15bf82ccbb(self._9da79c51e13f, (_2ed350aca0b2, _bedc4a5fd3dc)):
                    # Apply scalar alpha directly to focal loss
                    _d4b6effebd83 *= self._9da79c51e13f
                else:  # Assuming alpha is a dict like {label: ([token_ids], weight)}
                    _b17e7d86375c = self._44a796bb037c(_ddcd2ac60169)
                    _d4b6effebd83 *= _b17e7d86375c
                    del _b17e7d86375c

            # Reduction
            if self._fdfcf0b9ba8e == "mean":
                _189c0ebd9e57 = _d4b6effebd83._8c6f215bc976()
            elif self._fdfcf0b9ba8e == "sum":
                _189c0ebd9e57 = _d4b6effebd83._4ac412d818de()
            else:
                _189c0ebd9e57 = _d4b6effebd83

            # Cleanup
            del _2487020139b3, _ddcd2ac60169, _d4b6effebd83
            if _53d82f3afe79._89f3608fec3f._a1eb3ec6e93d():
                _53d82f3afe79._89f3608fec3f._edb41095bde4()

            return _189c0ebd9e57

        except _31ed12179815 as _5a2811c5f5e9:
            raise _69a746148444(f"Error in loss forward computation: {_5a2811c5f5e9}")