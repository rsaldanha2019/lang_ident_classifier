# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : custom_loss
# @Time             : 19/12/23 4:27 pm IST
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import torch
import lightning as pl

class ClassWeightedFocalLoss(torch.nn.Module):
    def __init__(
        self,
        device='cpu',
        alpha=None,  # scalar or dict
        gamma=2,
        reduction="mean",
        random_seed=20,
        ignore_index=-100,
        separator_token_id=None
    ):
        super(ClassWeightedFocalLoss, self).__init__()
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)

        self.curr_device = device
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction
        self.ignore_index = ignore_index

        self.use_token_weights = isinstance(alpha, dict)
        self.token_weight_map = {}
        self.unk_weight = 0.0

        self.separator_token_id = separator_token_id
        if self.separator_token_id is not None and self.alpha is not None:
            self.alpha["separator"] = ([self.separator_token_id], 0.1)
            if self.use_token_weights:
                self.token_weight_map = self._build_token_weight_map(self.alpha)

        if self.use_token_weights:
            self.unk_weight = alpha.get("unk", [[], 0.0])[1]
            self.token_weight_map = self._build_token_weight_map(alpha)

    def _build_token_weight_map(self, alpha_dict):
        weight_map = {}
        for label, (token_ids, weight) in alpha_dict.items():
            if label == "unk":
                continue
            for tid in token_ids:
                weight_map[tid] = weight if weight else 0.0
        return weight_map

    def _generate_token_weight_mask(self, labels):
        weight_mask = torch.full_like(labels, self.unk_weight, dtype=torch.float)
        for tid, weight in self.token_weight_map.items():
            mask = labels == tid
            weight_mask = torch.where(mask, torch.tensor(weight, device=labels.device), weight_mask)
        return weight_mask

    def forward(self, logits, targets):
        if logits.device != self.curr_device:
            logits = logits.to(self.curr_device)
        if targets.device != self.curr_device:
            targets = targets.to(self.curr_device)

        # Ignore padding or invalid targets
        valid_mask = targets != self.ignore_index
        if not valid_mask.any():
            return torch.tensor(0.0, device=logits.device, requires_grad=True)

        logits = logits[valid_mask]
        targets = targets[valid_mask]

        pred_softmax = torch.nn.functional.softmax(logits, dim=1)
        pt = pred_softmax.gather(1, targets.unsqueeze(1)).squeeze()
        log_pt = torch.log(pt)

        focal_loss = -((1 - pt) ** self.gamma) * log_pt

        # Apply class-specific weights if provided
        if self.alpha is not None:
            if isinstance(self.alpha, (int, float)):
                # Apply scalar alpha directly to focal loss
                focal_loss *= self.alpha
            else:  # Assuming alpha is a dict like {label: ([token_ids], weight)}
                alpha_weights = self._generate_token_weight_mask(targets)
                focal_loss *= alpha_weights
                del alpha_weights

        # Reduction
        if self.reduction == "mean":
            loss = focal_loss.mean()
        elif self.reduction == "sum":
            loss = focal_loss.sum()
        else:
            loss = focal_loss

        # Cleanup
        del logits, targets, focal_loss
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        return loss
