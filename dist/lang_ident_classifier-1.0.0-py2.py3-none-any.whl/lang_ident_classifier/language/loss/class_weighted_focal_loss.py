# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : class_weighted_focal_loss.py
# @Time             : 2025-10-23 16:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _39f7340f28d4
import _be117df3eef1 as _29368cd24a3e

class _0d0b20ff3882(_39f7340f28d4._72b7682b5db4._7b55ff330729):
    """
    Implements a class-weighted focal loss function with optional per-token weighting.

    This loss combines focal scaling with class or token-specific weights to handle
    class imbalance in sequence-level or token-level classification tasks.
    """

    def _690ba88f489a(
        self,
        _e2e92df0a68b: _d0b20e31390b = "cpu",
        _51bff26b8116=_880d6d6743ce,
        _63db26137f21: _0a5591b335a8 = 2.0,
        _8e97dd8432aa: _d0b20e31390b = "mean",
        _9acb52652021: _2bd1a93f1b62 = 20,
        _a3719ea63bc0: _2bd1a93f1b62 = -100,
        _9358bf831b00: _2bd1a93f1b62 = _880d6d6743ce,
    ):
        """
        Initialize the weighted focal loss module.

        Args:
            device: Computation device, e.g., 'cpu' or 'cuda'.
            alpha: Class weighting factor. Can be a scalar or a dictionary mapping
                class labels to weights.
            gamma: Focusing parameter that controls down-weighting of easy examples.
            reduction: Reduction method to apply to the final loss. Options: 'mean', 'sum', or 'none'.
            random_seed: Random seed for reproducibility.
            ignore_index: Label index to ignore during loss computation.
            separator_token: Optional special token to assign custom weight.
        """
        _f2e4ede63562(_758b928dbe19, self)._c038e5e57070()
        _29368cd24a3e._365371e4b654(_9acb52652021, _83558488b5ef=_4999cf53b2bf)
        _39f7340f28d4._193079b8b5dc(_9acb52652021)
        if _39f7340f28d4._d6d15064119a._e384133c091e():
            _39f7340f28d4._d6d15064119a._1e5d9a301054(_9acb52652021)

        self._13db051ce4b2 = _e2e92df0a68b
        self._51bff26b8116 = _51bff26b8116
        self._63db26137f21 = _63db26137f21
        self._8e97dd8432aa = _8e97dd8432aa
        self._a3719ea63bc0 = _a3719ea63bc0
        self._9358bf831b00 = _9358bf831b00

        self._4805ae3be947 = _6a77dfdac75f(_51bff26b8116, _799f24ea8fda)
        self._0763d446f42f = {}
        self._b87bc79899a9 = 0.0

        if self._4805ae3be947:
            self._b87bc79899a9 = _51bff26b8116._ea124d4f402c("unk", [[], 0.0])[1]
            self._0763d446f42f = self._19b17f698e3e(_51bff26b8116)

    def _428e4c73f805(self, _5bccca3e8524):
        """
        Build a mapping from token IDs to weights based on the provided alpha dictionary.

        Args:
            alpha_dict: Dictionary mapping class or token identifiers to their respective weights.

        Returns:
            dict: Token ID to weight mapping.

        Raises:
            ValueError: If token IDs or weights are invalid.
        """
        try:
            _457662fc0ab3 = {}
            # Find the least weight from alpha_dict (excluding 'unk')
            _4210a5baab22 = [_9d5dbc9cb708[1] for _a2ee23dfc63c, _9d5dbc9cb708 in _5bccca3e8524._7402057290e4() if _a2ee23dfc63c != "unk" and _9d5dbc9cb708[1] is not _880d6d6743ce]
            _2b917bd30414 = _c16cf582f887(_4210a5baab22) if _4210a5baab22 else 0.0

            # Build weight map for regular tokens
            for _a2ee23dfc63c, (_2fc9ada70483, _5329e68b6666) in _5bccca3e8524._7402057290e4():
                if _a2ee23dfc63c == "unk":
                    continue
                for _8b4204c2c354 in _2fc9ada70483:
                    _457662fc0ab3[_8b4204c2c354] = _5329e68b6666 if _5329e68b6666 is not _880d6d6743ce else 0.0

            # Assign separator_token the least weight if not None
            if self._9358bf831b00 is not _880d6d6743ce:
                # half of min weight
                _457662fc0ab3[self._9358bf831b00] = _2b917bd30414 * 0.5
            
            return _457662fc0ab3

        except _a215b15629ac as _9637de09a964:
            raise _0c8664db0990(f"Failed to build token weight map: {_9637de09a964}")

    def _38d80ef98648(self, _0176dfb263d6):
        """
        Generate a per-token weight mask for the provided label tensor.

        Args:
            labels: Tensor of target labels (token IDs).

        Returns:
            torch.Tensor: A float tensor of the same shape as labels, where each entry
            represents the weight assigned to that token.

        Raises:
            RuntimeError: If label tensor shape is incompatible or mapping fails.
        """
        try:
            _a61d3b770281 = _39f7340f28d4._a07005676496(_0176dfb263d6, self._b87bc79899a9, _ced4abdab294=_39f7340f28d4._0a5591b335a8)
            for _8b4204c2c354, _5329e68b6666 in self._0763d446f42f._7402057290e4():
                _fc0c0ddc6a6c = _0176dfb263d6 == _8b4204c2c354
                _a61d3b770281 = _39f7340f28d4._7709e7854a14(_fc0c0ddc6a6c, _39f7340f28d4._a6be6fa5af43(_5329e68b6666, _e2e92df0a68b=_0176dfb263d6._e2e92df0a68b), _a61d3b770281)
            return _a61d3b770281
        except _a215b15629ac as _9637de09a964:
            raise _1a922d0ac79d(f"Error generating weight mask: {_9637de09a964}")
        

    def _add4c8122ccd(self, _95c444ecb079, _5d0942e75276):
        """
        Compute the focal loss with class or token weighting.

        Args:
            logits: Predicted unnormalized scores (logits) from the model, of shape (..., num_classes).
            targets: Ground truth tensor of class indices, matching the leading dimensions of logits.

        Returns:
            torch.Tensor: Scalar loss value after applying reduction.

        Raises:
            RuntimeError: If loss computation fails.
        """
        try:
            if _95c444ecb079._e2e92df0a68b != self._13db051ce4b2:
                _95c444ecb079 = _95c444ecb079._9b0bcda92211(self._13db051ce4b2)
            if _5d0942e75276._e2e92df0a68b != self._13db051ce4b2:
                _5d0942e75276 = _5d0942e75276._9b0bcda92211(self._13db051ce4b2)

            # Ignore padding or invalid targets
            _8250cf51d1be = _5d0942e75276 != self._a3719ea63bc0
            if not _8250cf51d1be._84305da4bc5d():
                return _39f7340f28d4._a6be6fa5af43(0.0, _e2e92df0a68b=_95c444ecb079._e2e92df0a68b, _33cfd1d422a4=_4999cf53b2bf)

            _95c444ecb079 = _95c444ecb079[_8250cf51d1be]
            _5d0942e75276 = _5d0942e75276[_8250cf51d1be]

            # pred_softmax = torch.nn.functional.softmax(logits, dim=1)
            # pt = pred_softmax.gather(1, targets.unsqueeze(1)).squeeze()
            # log_pt = torch.log(pt)

            # focal_loss = -((1 - pt) ** self.gamma) * log_pt
            _35557cccf625 = _39f7340f28d4._72b7682b5db4._cb4744530cc9._b033f2ef40d7(_95c444ecb079, _1a1be616c57f=-1)
            _1c0fc19ba06d = 0.1
            _a4740317ffb1 = _95c444ecb079._96a78cb7487c(-1)

            # Smooth pt
            _732f6949d3fe = _35557cccf625._1e3c9bf907b2(1, _5d0942e75276._53122b16da5a(1))._3103764b4fba()
            _732f6949d3fe = (1 - _1c0fc19ba06d) * _732f6949d3fe + (_1c0fc19ba06d / _a4740317ffb1)

            _634cc330f1e3 = _39f7340f28d4._40065f254f26(_732f6949d3fe)
            _0f7d2ce0f010 = -((1 - _732f6949d3fe) ** self._63db26137f21) * _634cc330f1e3

            # Apply class-specific weights if provided
            if self._51bff26b8116 is not _880d6d6743ce:
                if _6a77dfdac75f(self._51bff26b8116, (_2bd1a93f1b62, _0a5591b335a8)):
                    # Apply scalar alpha directly to focal loss
                    _0f7d2ce0f010 *= self._51bff26b8116
                else:  # Assuming alpha is a dict like {label: ([token_ids], weight)}
                    _07f4886c8251 = self._6320e5674512(_5d0942e75276)
                    _0f7d2ce0f010 *= _07f4886c8251
                    del _07f4886c8251

            # Reduction
            if self._8e97dd8432aa == "mean":
                _e660aaaf4427 = _0f7d2ce0f010._285df4b5e958()
            elif self._8e97dd8432aa == "sum":
                _e660aaaf4427 = _0f7d2ce0f010._e766a2032ab8()
            else:
                _e660aaaf4427 = _0f7d2ce0f010

            # Cleanup
            del _95c444ecb079, _5d0942e75276, _0f7d2ce0f010
            if _39f7340f28d4._d6d15064119a._e384133c091e():
                _39f7340f28d4._d6d15064119a._b5fe7fcb77e7()

            return _e660aaaf4427

        except _a215b15629ac as _9637de09a964:
            raise _1a922d0ac79d(f"Error in loss forward computation: {_9637de09a964}")