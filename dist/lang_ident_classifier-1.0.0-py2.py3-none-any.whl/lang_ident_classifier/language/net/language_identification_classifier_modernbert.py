# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the authora if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import re
import traceback
import torch
import lightning as pl
import numpy as np
from torchmetrics import Accuracy, Precision, Recall, F1Score
from torch.amp import autocast
from lang_ident_classifier.language.loss.class_weighted_focal_loss_with_adaptive_focus import ClassWeightedFocalLossWithAdaptiveFocus
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'


class ModernBERTLanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        pretrained_embedding_model,
        num_classes,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_embedding_layers_unfrozen,
        loss_type,
        num_fc_layers,
        activation_function_for_layer,
        add_dropout_after_embedding,
        is_train,
        random_seed: int = 20,
        pretrained_model_embedding_name = None
    ):
        super(ModernBERTLanguageIdentificationClassifier, self).__init__()
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        np.random.seed(random_seed)
        self.save_hyperparameters(ignore=["pretrained_embedding_model"])
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.pretrained_model_embedding_name = pretrained_model_embedding_name
        self.num_classes = num_classes
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.embedding = pretrained_embedding_model.requires_grad_(False).to(self.curr_device)
        self.num_fc_layers = num_fc_layers
        self.activation_function_for_layer = activation_function_for_layer
        # The following logic finetunes the embedding used [appicable for only BERT like embeddings]
        if num_embedding_layers_unfrozen > 0:
            # Freeze the embedding layers (if applicable)
            for param in self.embedding.parameters():
                if not param.is_leaf:
                    param = param.detach()
                param.requires_grad = False  # Freeze embedding layers, set to True to unfreeze

            # If the model has multiple layers, unfreeze the last (num_embedding_layers_unfrozen-1) layers
            if num_embedding_layers_unfrozen > 1:
                for layer in self.embedding.layers[-(num_embedding_layers_unfrozen-1):]:  # Index from the end of layers
                    for param in layer.parameters():
                        if not param.is_leaf:
                            param = param.detach()
                        param.requires_grad = True  # Unfreeze this layer

            # If there are other layers, like final normalization, apply similar logic
            for param in self.embedding.final_norm.parameters():
                if not param.is_leaf:
                    param = param.detach()
                param.requires_grad = False  # Freeze final normalization layers, set to True to unfreeze
        self.add_dropout_after_embedding = add_dropout_after_embedding
        if add_dropout_after_embedding:
            self.dropout = torch.nn.Dropout(0.5)
        if num_fc_layers == 1:
            self.fc_1 = torch.nn.Linear(self.embedding.config.hidden_size, self.num_classes)
        else:
            start_input_features = self.embedding.config.hidden_size
            end_output_features = self.num_classes
            for layer_idx in range(num_fc_layers):
                if layer_idx == 0: # for first layer we start with embedding vector size and out is half the size
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 != num_fc_layers: # any intermediate layer the start will be out of previous updated by start_input_features assignment in the end
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 == num_fc_layers:
                    in_features = start_input_features
                    out_features = end_output_features
                setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
                if activation_function_for_layer and layer_idx+1 < num_fc_layers:
                    setattr(self, f"{activation_function_for_layer}_{layer_idx+1}", self._get_activation_function_instance(activation_function_for_layer, out_features))
                start_input_features = out_features
        if loss_type.casefold() == "class_weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, device=self.curr_device)
        elif loss_type.casefold() == "focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=0.25, device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type1', device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type2', device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type3', device=self.curr_device)
        else:
            self._criterion = ClassWeightedCrossEntropyLoss(device=self.curr_device)
            # self._criterion = torch.nn.CrossEntropyLoss(reduction='mean')
        self._accuracy = Accuracy(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._precision = Precision(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._recall = Recall(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._f1 = F1Score(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self.optimizer_name = optimizer.casefold()
        self.initialize_weights(self.curr_device, num_fc_layers)
    
    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            return torch.nn.PReLU(num_parameters=num_parameters)
        elif activation_function_for_layer.casefold() == "leaky_relu":
            return torch.nn.LeakyReLU()
        else:
            return torch.nn.ReLU()

    def initialize_weights(self, device, num_fc_layers):
        def _initialize_weights(m):
            if hasattr(m, "weight") and m.weight.dim() > 1:
                m.to(device)
                torch.nn.init.xavier_uniform_(m.weight.data)
        
        for layer_idx in range(num_fc_layers):
            layer = getattr(self, f"fc_{layer_idx+1}")
            layer.apply(_initialize_weights)

    def forward(self, input_ids, attention_mask):
        if self.training == True:
            with autocast(CAST_TO_DEVICE):
                output = self._forward(input_ids=input_ids, attention_mask=attention_mask)
        else:
            for param in self.embedding.parameters():
                if not param.is_leaf:
                    param = param.detach()
                param.requires_grad = False
            output = self._test_forward(input_ids=input_ids, attention_mask=attention_mask)
        return output
    
    def _mean_pooling(self, embedding, attention_mask):
        # Ensure we are working with the last hidden state
        token_embeddings = embedding.last_hidden_state  # Extract tensor from BaseModelOutput

        # Expand mask: (batch_size, seq_len, 1) and convert to float for multiplication
        mask = attention_mask.unsqueeze(-1).float()

        # Apply mask and compute mean over non-masked tokens
        pooled_output = (token_embeddings * mask).sum(dim=1) / mask.sum(dim=1).clamp(min=1e-9)

        return pooled_output
    
    def _cls_pooling(self, embedding):
        """
        Extracts the [CLS] token representation from the last hidden state.
        """
        return embedding.last_hidden_state[:, 0]  # Take only the CLS token (first token)

    def _max_pooling(self, embedding, attention_mask):
        token_embeddings = embedding.last_hidden_state
        mask = attention_mask.unsqueeze(-1).float()
        masked_embeddings = token_embeddings * mask + (1 - mask) * -1e9
        return masked_embeddings.max(dim=1).values
    
    def _test_forward(self, input_ids, attention_mask):
        # input_ids = torch.randint(0, 30522, (32, 100))  # Example input
        # attention_mask = torch.ones(32, 100)  # Example attention mask
        input_ids = input_ids.to(self.curr_device)
        attention_mask = attention_mask.to(self.curr_device)
        try:
            with torch.cuda.amp.autocast(enabled=False):  # Disable mixed precision
                embedding = self.embedding(input_ids, attention_mask)
        except Exception as e:
            print(f"Error during forward pass: {e}")
            traceback.print_exc()
        # output = self._mean_pooling(embedding, attention_mask)
        # output = self._cls_pooling(embedding)
        output = self._max_pooling(embedding, attention_mask)
        for layer_idx in range(self.num_fc_layers):
            # Dynamically access the fully connected layer using getattr()
            fc_layer = getattr(self, f"fc_{layer_idx+1}")
            # Apply the fully connected layer
            output = fc_layer(output)
            # Apply the activation function (e.g., ReLU)
            if self.activation_function_for_layer and layer_idx+1 < self.num_fc_layers:
                activation_function = getattr(self, f"{self.activation_function_for_layer}_{layer_idx+1}")
                output = activation_function(output)
        return output
    
    def _forward(self, input_ids, attention_mask):
        input_ids = input_ids.to(self.curr_device)
        attention_mask = attention_mask.to(self.curr_device)
        embedding = self.embedding(input_ids, attention_mask)
        # embedding_output = self._mean_pooling(embedding, attention_mask)
        # embedding_output = self._cls_pooling(embedding)
        embedding_output = self._max_pooling(embedding, attention_mask)
        if self.add_dropout_after_embedding:
            output = self.dropout(embedding_output)
        else:
            output = embedding_output
        for layer_idx in range(self.num_fc_layers):
            # Dynamically access the fully connected layer using getattr()
            fc_layer = getattr(self, f"fc_{layer_idx+1}")
            # Apply the fully connected layer
            output = fc_layer(output)
            # Apply the activation function (e.g., ReLU)
            if self.activation_function_for_layer and layer_idx+1 < self.num_fc_layers:
                activation_function = getattr(self, f"{self.activation_function_for_layer}_{layer_idx+1}")
                output = activation_function(output)
        return output

    def training_step(self, batch, batch_idx):
        input_ids, attention_mask, labels = batch

        outputs = self(input_ids, attention_mask)
        loss = self._criterion(outputs, labels)
        epoch = float(round(self.current_epoch)) # for distributed training some values not rounding
        # Convert logits to predicted labels
        predicted_labels = torch.argmax(outputs, dim=1)
        accuracy = self._accuracy(predicted_labels, labels)
        precision = self._precision(predicted_labels, labels)
        recall = self._recall(predicted_labels, labels)
        f1 = self._f1(predicted_labels, labels)
        # f1 = (2 * precision * recall)/(precision + recall + 1e-6) # adding small epsilon to avoid divide by zero
        train_metrics = {
            "epoch": epoch,
            "train_loss": loss,
            "train_accuracy": accuracy,
            "train_precision": precision,
            "train_recall": recall,
            "train_f1": f1,
        }
        
        self.log_dict(
            train_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )
        return loss

    def validation_step(self, batch, batch_idx):
        input_ids, attention_mask, labels = batch
        outputs = self(input_ids, attention_mask)
        loss = self._criterion(outputs, labels)
        # Convert logits to predicted labels
        predicted_labels = torch.argmax(outputs, dim=1)
        accuracy = self._accuracy(predicted_labels, labels)
        precision = self._precision(predicted_labels, labels)
        recall = self._recall(predicted_labels, labels)
        f1 = self._f1(predicted_labels, labels)
        # f1 = (2 * precision * recall)/(precision + recall + 1e-6) # adding small epsilon to avoid divide by zero
        val_metrics = {
            "val_loss": loss,
            "val_accuracy": accuracy,
            "val_precision": precision,
            "val_recall": recall,
            "val_f1": f1,
        }
        self.log_dict(
            val_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )
        return loss
    
    def test_step(self, batch, batch_idx):
        input_ids, attention_mask, labels = batch
        outputs = self(input_ids, attention_mask)

        # Convert logits to predicted labels
        predicted_labels = torch.argmax(outputs, dim=1)

        # Calculate metrics
        accuracy = self._accuracy(predicted_labels, labels)
        precision = self._precision(predicted_labels, labels)
        recall = self._recall(predicted_labels, labels)
        f1 = self._f1(predicted_labels, labels)
        
        # Create a dictionary to store test metrics
        test_metrics = {
            "test_accuracy": accuracy,
            "test_precision": precision,
            "test_recall": recall,
            "test_f1": f1,
        }
        
        # Log the metrics
        self.log_dict(
            test_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        # Return predicted labels or other relevant information if needed
        return predicted_labels

    
    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        input_ids, attention_mask, labels = batch
        logits = self(input_ids=input_ids, attention_mask=attention_mask)
        preds = torch.argmax(logits, dim=1)
        return {"predictions": preds, "labels": labels}

    def configure_optimizers(self):
        model_parameters = filter(lambda p: p.requires_grad, self.trainer.model.parameters())
        if self.optimizer_name == "adamw":
            optimizer = torch.optim.AdamW(
                model_parameters, lr=self.hparams.lr, weight_decay=0.001
            )
        elif self.optimizer_name == "adamax":
            optimizer = torch.optim.Adamax(
                model_parameters, lr=self.hparams.lr, weight_decay=0.001
            )
        else:
            optimizer = torch.optim.Adam(
                model_parameters, lr=self.hparams.lr, weight_decay=0.001
            )
        lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=0.1,
            patience=3,
            verbose=True,
            cooldown=3,
            min_lr=1e-8,
        )
        return {"optimizer": optimizer, "lr_scheduler": lr_scheduler, "monitor": "val_loss"}


