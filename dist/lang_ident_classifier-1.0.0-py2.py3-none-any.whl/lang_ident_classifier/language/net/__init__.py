#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(29708, 57245, 2), (23512, 53528, 2), (33047, 33992, 2), (23992, 36822, 2), (1365, 37872, 2), (49020, 49352, 2), (53725, 19608, 2), (20312, 60537, 2), (28153, 40461, 2), (38483, 53702, 2), (15578, 18788, 2), (54191, 43215, 2), (37559, 10897, 2), (40468, 10013, 2), (22170, 44920, 2), (20494, 53976, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('q5GKwA==')
_nonce = base64.b64decode('Dqc+kDd1oqcp+oXj')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('Tc6G+1oFgagiwbRt/Vkpw9ND7tfIuM9nVOKHYodlkUlIL0RnjT8lXOdw3eA9GpRyrpkOgOPoJEBUodmNPCyPGkLSAHJ8yeZvqL05QC9NisTJ5TZHceRqZftOCSmQ5tvFZb+YRdbywynURL9K2pVtxxespTe3Mc2XEr1Fu3/g8MET/w2pKDBWa+6kdgLszXwtVfVJXrZuI5zBZNbL62SbS9OraMrJXrUU9JrZyJ2bRPr9v8IJEILjtsgfFAdnHQJlc2RIxNJHVasT58sVGp7bYdTi9vKIqG+I/c5ALvNnulybJOcy1EmgeD7wprQyZlPZzEKS/VNc87WNrO69HvR8AMd1YpN1aYbr')
_tag = base64.b64decode('b4ldqZg7Dawq7iDbTGBEZA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
