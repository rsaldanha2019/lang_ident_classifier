#!/usr/bin/env python3
import sys, hashlib, marshal, base64

_enc = base64.b64decode('7eNDkjCUI2hMqdbuCa5gHUx/qoqFS00yrPKyx2peB1L9r+x0oQ6p/uDNdwSwY9pBj5V3+yjf7Rm6J6mZgmk6OEfRo2CB4jM7EJEf4FxvSw+yjqMXe4y8Q9NFnDLjAYqtXE6r1NNU02D+xjnArOI6YYxbWbt7hsQheHDHOYdKW9OXMmHoOLYyxf8mKDnu6LvY+fTIsnmS02oVQBWkEGdNnGEZxFnTTTB9phS56fyXdacutYqqWf9rZKbu5qdGIwKpI7p8ZcRg6oo5ThkZtZJzRVTgP7N2dJyeQGK+KUBlwRK6Tk6axumuVSJAUEHs4MbkdSelBWfIUCEOMb/3I13hqcStRZeGW1+7')
_nonce = base64.b64decode('agZ4vi3Ks3xQ9tNM')
_tag = base64.b64decode('ftbtfUqSSqiy9oRdaP70+w==')

def _sha_stream(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

h = hashlib.sha256()
h.update(b"__main__|")
h.update(repr(globals().get("__file__", "")).encode())
seed = h.digest()

km = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(seed + _nonce).digest(),
    _nonce,
    300000,
    32
)

blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(km + b"blob").digest(),
    _nonce,
    60000,
    32
)

if hashlib.sha256(blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_stream(blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals(), globals())
