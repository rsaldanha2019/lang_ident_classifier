#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(12850, 38129, 2), (4074, 23248, 2), (37905, 8530, 2), (47994, 58766, 2), (44591, 42663, 2), (13899, 22574, 2), (33667, 3782, 2), (13449, 40464, 2), (36278, 153, 2), (19079, 40753, 2), (29834, 3879, 2), (45978, 26952, 2), (12518, 19410, 2), (8908, 1932, 2), (54833, 4965, 2), (32920, 29817, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('psNVOg==')
_nonce = base64.b64decode('KIr1lY4z/ygWYrki')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('BYC3C/9kqHN4J1eYJbuYQYjYsL7tIomiDsdv6rw0P7DIibfZ1DT1TpVPtR5oHUaq8YrsCpMAnV004uaxH4rTOf61OPNDmcNgStgrEveZ63ZlgslIed5/+NJ1d9VnRJheobTma8/UnFAIGJ5ifs70Mf3qUrbjguOtoz1eH4l38j4OoorOYWCJX7K9EOMN6efw0XvX7u3O1hQXbR/iBFHFa2UDYctYeSpmX6ZvCFsI/fiZvhgHAYcxXxZGxxFiP0O5fVYkTqfC1oWc4ZZ6GtWz7JD4eyelQ2o2Oxf5sSLzXYMpMR+RhL3VFUB8YBBxqEU+BKRnCrB1ajXOE7Itg8uWox0IqDVoe67x')
_tag = base64.b64decode('mJmguAo6aMCv4FPAWRurTw==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
