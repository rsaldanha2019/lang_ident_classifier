
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(51234, 42217, 2), (2495, 43785, 2), (49007, 50097, 2), (52505, 49947, 2), (48217, 58078, 2), (593, 42886, 2), (40942, 21621, 2), (40411, 2610, 2), (50648, 28683, 2), (13937, 57120, 2), (43708, 65358, 2), (29929, 64480, 2), (24485, 51829, 2), (54424, 47191, 2), (24262, 12078, 2), (40855, 45614, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('bMuitg==')
_nonce = base64.b64decode('fF0BL/K8nK5+TNrV')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('MPt35f9JIeMDwhmCNp0KBos2eVXjJBiPpkieKiKOEIZiIQBuizss3LTunHe28YOft6t+RCI0SMynbrLRMez2HIdi+e1drPwmskhMBiFqSocTj7NxxI7ACrTWy1dwoRO2AR+j2NZAz1HKxGHAgpdoEXp1w6RpiVq5wBqL5z168o3T8j9rRDLquZScqk/gnXixfHR63NKwALa7ZWI5tqwyjPlvu9qFjUGyVgRCPCNqP0dqKmR4XrZokCgY+eerWelB905O6JqtXQFwNsNTSRtfl0fDVQjwEaucoeXVIQFd2Zh4RcsBlDhBRMt53VAMyGaRN5yAhNtuixWMrZt1Fx3eImGpz7YCCewf')
_tag = base64.b64decode('KlAInjUUM8JvSDcOdb5vBA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
