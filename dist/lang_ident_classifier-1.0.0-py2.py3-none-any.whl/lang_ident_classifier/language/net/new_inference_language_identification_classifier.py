# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import math
import traceback
import numpy as np
import torch
import lightning as pl
from torch import nn
from torchmetrics import Accuracy, Precision, Recall, F1Score
from torch.amp import autocast
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss_with_adaptive_focus import ClassWeightedFocalLossWithAdaptiveFocus
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

class InferenceLanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        pretrained_embedding_model,
        num_classes,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_embedding_layers_unfrozen,
        loss_type,
        num_fc_layers,
        activation_function_for_layer,
        add_dropout_after_embedding,
        is_train,
        random_seed: int = 20
    ):
        super(InferenceLanguageIdentificationClassifier, self).__init__()
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        np.random.seed(random_seed)
        self.save_hyperparameters(ignore=["pretrained_embedding_model"])
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.num_classes = num_classes
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.embedding = pretrained_embedding_model.requires_grad_(False).to(self.curr_device)
        self.num_fc_layers = num_fc_layers
        self.activation_function_for_layer = activation_function_for_layer
        if num_fc_layers == 1:
            self.fc_1 = torch.nn.Linear(self.embedding.config.hidden_size, self.num_classes)
        else:
            start_input_features = self.embedding.config.hidden_size
            end_output_features = self.num_classes
            for layer_idx in range(num_fc_layers):
                if layer_idx == 0: # for first layer we start with embedding vector size and out is half the size
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 != num_fc_layers: # any intermediate layer the start will be out of previous updated by start_input_features assignment in the end
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 == num_fc_layers:
                    in_features = start_input_features
                    out_features = end_output_features
                setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
                if activation_function_for_layer and layer_idx+1 < num_fc_layers:
                    setattr(self, f"{activation_function_for_layer}_{layer_idx+1}", self._get_activation_function_instance(activation_function_for_layer, out_features))
                start_input_features = out_features
        if loss_type.casefold() == "class_weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, device=self.curr_device)
        elif loss_type.casefold() == "focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=0.25, device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type1', device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type2', device=self.curr_device)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type3', device=self.curr_device)
        else:
            self._criterion = ClassWeightedCrossEntropyLoss(device=self.curr_device)
            # self._criterion = torch.nn.CrossEntropyLoss(reduction='mean')
        self._accuracy = Accuracy(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._precision = Precision(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._recall = Recall(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._f1 = F1Score(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self.optimizer_name = optimizer.casefold()
        self.initialize_weights(self.curr_device, num_fc_layers)
    
    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            return torch.nn.PReLU(num_parameters=num_parameters)
        elif activation_function_for_layer.casefold() == "leaky_relu":
            return torch.nn.LeakyReLU()
        else:
            return torch.nn.ReLU()

    def initialize_weights(self, device, num_fc_layers):
        def _initialize_weights(m):
            if hasattr(m, "weight") and m.weight.dim() > 1:
                m.to(device)
                torch.nn.init.xavier_uniform_(m.weight.data)
        
        for layer_idx in range(num_fc_layers):
            layer = getattr(self, f"fc_{layer_idx+1}")
            layer.apply(_initialize_weights)
    
    def forward(self, input_ids, attention_mask):
        if self.training == True:
            with autocast(CAST_TO_DEVICE):
                output = self._forward(input_ids=input_ids, attention_mask=attention_mask)
        else:
            output = self._test_forward(input_ids=input_ids, attention_mask=attention_mask)
        return output

    def _test_forward(self, input_ids, attention_mask):
        input_ids = input_ids.to(self.curr_device)
        attention_mask = attention_mask.to(self.curr_device)
        embedding = self.embedding(input_ids, attention_mask)
        # output = self.classifier(output.pooler_output)
        output = embedding.pooler_output
        for layer_idx in range(self.num_fc_layers):
            # Dynamically access the fully connected layer using getattr()
            fc_layer = getattr(self, f"fc_{layer_idx+1}")
            # Apply the fully connected layer
            output = fc_layer(output)
            # Apply the activation function (e.g., ReLU)
            if self.activation_function_for_layer and layer_idx+1 < self.num_fc_layers:
                activation_function = getattr(self, f"{self.activation_function_for_layer}_{layer_idx+1}")
                output = activation_function(output)
        return output
    
    def test_step(self, batch, batch_idx):
        print(f"Test step check")
        print(f"Model training mode: {self.training}")  # Should print False for testing
        print(f"Test step called for batch {batch_idx}")
        input_ids, attention_mask, labels = batch
        print(f"Batch contents: input_ids={input_ids.shape}, attention_mask={attention_mask.shape}, labels={labels.shape}")
        # input_ids, attention_mask, labels = batch
        try:
            outputs = self(input_ids, attention_mask)
        except Exception as e:
            print(f"Error during forward pass: {e}")
            traceback.print_exc()

        print(f"Test outputs {outputs}")
        
        # Convert logits to predicted labels
        predicted_labels = torch.argmax(outputs, dim=1)

        print(f"Test step test predicted labels{predicted_labels}")
        
        # Calculate metrics
        accuracy = self._accuracy(predicted_labels, labels)
        precision = self._precision(predicted_labels, labels)
        recall = self._recall(predicted_labels, labels)
        f1 = self._f1(predicted_labels, labels)
        
        # Create a dictionary to store test metrics
        test_metrics = {
            "test_accuracy": accuracy,
            "test_precision": precision,
            "test_recall": recall,
            "test_f1": f1,
        }
        
        # Log the metrics
        self.log_dict(
            test_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        self.log.info(f"Inside test step {test_metrics}")
        
        # Return predicted labels or other relevant information if needed
        return predicted_labels
    
    def predict_step(self, batch, batch_idx, dataloader_idx: int = 0):
        input_ids, attention_mask, labels = batch
        outputs = self(input_ids, attention_mask)
        # outputs is the model prediction tensor for each class
        pred_probabilities = torch.softmax(outputs, dim=1)
        # TODO if pred_probabilities < 0.9 set index unknown
        
        # predicted class indices
        pred_indices = pred_probabilities.argmax(dim=1).cpu().numpy()

        print(f"expected idx {labels} and predictions {pred_indices}")
        
        return pred_indices

