# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _94f1e44ed1f2, _0fef6e80ccdb
import copy
from _70a77dde3097 import _fd826cc29df4
import _9b19313fbbe3
import math
import os
from typing import _a16ec371122c
import _749cc7313116 as _46b5fa0c82f0
import _eac849003c8b as _f40144ab4f1a
import _695804038798
import _cce55ac0c139 as _b045ec826d4d
from _c9130eb83969._fe20ffbafad7._cb743c13097b._73653bddba76 import _08b04f0159f6
from _7c6f824aede4 import _925e5e0c4230, _04cfa826dc77, _28203ac73d79, _de48aace01ea, _f68318aaed33

from _0045bb7ca21e._0e38c60bcba6._bb0e0a2b019e._122aad707dd7 import _63157511a485
from _0045bb7ca21e._0e38c60bcba6._51f54f5129fe._38cb6458e1eb import _981359effe27
from _0045bb7ca21e._0e38c60bcba6._51f54f5129fe._05947e74334a import _dee35fdc4e9e
from _0045bb7ca21e._0e38c60bcba6._51f54f5129fe._22092197f759 import _8c964e6fd35d
from _0045bb7ca21e._0e38c60bcba6._1fb632193a65._a76f5de0d0fb import _caafb2b63c90
# expose only the classifier from the module
_fbc003cccbf1 = ["GenLLMLanguageIdentificationClassifier"]

_a5a7fa9607bb = 'cuda' if _695804038798._1d9613fc3f23._e67af70ab23b() else 'cpu'
_412883da768d = _e0333a685467  # global frozen embedding (kept for compatibility)

    
class _a82db5f9cff7(_b045ec826d4d._1ea729e45737):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _c7531b17ff4f(_695804038798._d99d914cb171._904c7f7aeda2):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _3bcc8aac6f5c(self, _04eff1e6b0a8: _9756b51a9090, _4cf5db948dc2: _9756b51a9090 = 64):
            _1d5d28892616()._663cedca52bd()
            self._bacd6cc9d46c = _695804038798._d99d914cb171._136294950ca3(_04eff1e6b0a8, _4cf5db948dc2, _6115f03d92f2=_00db95800c16)
            self._27cc9ecf9101 = _695804038798._d99d914cb171._116f883256f3(_d0b304cdcbf8=_fef3663a10ca)
            self._64daeb117818 = _695804038798._d99d914cb171._136294950ca3(_4cf5db948dc2, _04eff1e6b0a8, _6115f03d92f2=_00db95800c16)
            # start adapter near-zero so initial behavior is identity
            _695804038798._d99d914cb171._36a7b7b51fde._9aa87dbbed9a(self._64daeb117818._cde44bef0534)
            _695804038798._d99d914cb171._36a7b7b51fde._cb5415c78a7f(self._bacd6cc9d46c._cde44bef0534, _2a7caadad9f6=math._cd7cc925a5d9(5))

        def _6407a70afc35(self, _c1fad5b1c343: _695804038798._39057bac7da9) -> _695804038798._39057bac7da9:
            # supports x shape (B, L, D) or (B, D)
            if _c1fad5b1c343._04eff1e6b0a8() == 2:
                _0175f23bdade = self._64daeb117818(self._27cc9ecf9101(self._bacd6cc9d46c(_c1fad5b1c343)))
                return _c1fad5b1c343 + _0175f23bdade
            _aa6a04fa87c2, _2a3fd697e1d6, _befb801db5a4 = _c1fad5b1c343._299641664922
            _ea17dc12bd5f = _c1fad5b1c343._6bef2bd4b244(-1, _befb801db5a4)                    # (B*L, D)
            _ea17dc12bd5f = self._64daeb117818(self._27cc9ecf9101(self._bacd6cc9d46c(_ea17dc12bd5f)))  # (B*L, D)
            _ea17dc12bd5f = _ea17dc12bd5f._6bef2bd4b244(_aa6a04fa87c2, _2a3fd697e1d6, _befb801db5a4)
            return _c1fad5b1c343 + _ea17dc12bd5f
        
    class _a9e4cf669bf7(_695804038798._d99d914cb171._904c7f7aeda2):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _3bcc8aac6f5c(self, _e7b352955304, _280bb7024dfe=-5, _c7525dc86283=5):
            _1d5d28892616()._663cedca52bd()
            self._e7b352955304 = _e7b352955304
            self._280bb7024dfe = _280bb7024dfe
            self._c7525dc86283 = _c7525dc86283
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _6407a70afc35(self, *_ad3d2338576f, **_239592e55864):
            _ad3d2338576f = _f706a0f2318b(
                _5d0c8eb6ef08._5f3fa46da332(_695804038798._656ef110f540)._1ccb7014c0b3(-10, 10) if _7e127e0d68c4(_5d0c8eb6ef08, _695804038798._39057bac7da9) and _5d0c8eb6ef08._9c4c79c0803c != _695804038798._656ef110f540 else _5d0c8eb6ef08
                for _5d0c8eb6ef08 in _ad3d2338576f
            )
            for _2ba727c12923, _5d0c8eb6ef08 in _12054a007492(_ad3d2338576f):
                if _7e127e0d68c4(_5d0c8eb6ef08, _695804038798._39057bac7da9) and not _695804038798._53e8586b20ec(_5d0c8eb6ef08)._84c17ceaa40c():
                    _5d0c8eb6ef08 = _695804038798._17ff38cf0f81(_5d0c8eb6ef08)
            _845dc65326eb = self._e7b352955304(*_ad3d2338576f, **_239592e55864)
            if _7e127e0d68c4(_845dc65326eb, _695804038798._39057bac7da9):
                _845dc65326eb = _845dc65326eb._5f3fa46da332(_695804038798._656ef110f540)
                if not _695804038798._53e8586b20ec(_845dc65326eb)._84c17ceaa40c():
                    _845dc65326eb = _695804038798._17ff38cf0f81(_845dc65326eb)
                _845dc65326eb._e4db39f37950(self._280bb7024dfe, self._c7525dc86283)
            return _845dc65326eb

    # --- original __init__ signature and body preserved ---
    def _3bcc8aac6f5c(
        self,
        _f5ae1c65e541,
        _6e30692cd2d8,
        _214b58612281,
        _43575df0dcb4,
        _f9b54c0d79f6,
        _b8f6c95e87fb,
        _8f9b2bca79f2,
        _61e33631cd13,
        _898cc3322008,
        _327973829216,
        _a76d1ee875be,
        _47c1fcb016c8: _9756b51a9090 = 20,
        _0c7128742064 = _e0333a685467,
        _6ec473af9373=_e0333a685467,
        _438a78513374=0.9,
        _64ce717c7c18:_4dc6837b43ba=_e0333a685467,
    ):
        _1d5d28892616(_1d26cbb8b161, self)._663cedca52bd()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._7dc15e30584f({
            "lr": _9f80a393943a(_214b58612281),
            "optimizer": _4dc6837b43ba(_43575df0dcb4),
            "num_backbone_model_units_unfrozen": _9756b51a9090(_8f9b2bca79f2),
            "loss_type": _4dc6837b43ba(_61e33631cd13),
            "is_train": _85a716e04afe(_898cc3322008),
            "random_seed": _9756b51a9090(_47c1fcb016c8),
        })
        self._47c1fcb016c8 = _47c1fcb016c8
        _b045ec826d4d._02575137b536(_47c1fcb016c8, _49d663aa813a=_fef3663a10ca)
        _695804038798._03b4145e74dc(_47c1fcb016c8)
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            _695804038798._1d9613fc3f23._7d7d8c26e34a(_47c1fcb016c8)
        _46b5fa0c82f0.random._c84f04f10619(_47c1fcb016c8)
        self._6ec473af9373 = _9756b51a9090(_6ec473af9373) if _6ec473af9373 is not _e0333a685467 else _e0333a685467
        self._327973829216 = _327973829216
        self._64ce717c7c18 = _64ce717c7c18
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._327973829216._8c77d72a456c and "<PAD>" not in self._327973829216._6945cdad3944():
            self._327973829216._08996bc38765(["<PAD>"], _291199ce6912=_00db95800c16)
            _6b571304829e = self._327973829216._8f926c2fcfb9("<PAD>")
            _d192e8d79307(f"Added padding token  <PAD> with (id: {_6b571304829e})")
        
        self._1c86a99db69c = _327973829216._69f0f4805199(" ", _b5e85a4a53d2=_00db95800c16)[0]
        self._5287239c7dc4 = (
            _695804038798._1dd26ca682a8("cuda:{}"._70beb3de4e31(_b8f6c95e87fb["gpu_local_rank"]))
            if _b8f6c95e87fb["gpu_local_rank"] != -1
            else "cpu"
        )
        self._0c7128742064 = _0c7128742064
        self._438a78513374 = _438a78513374
        self._6e30692cd2d8 =  ["unk"] + _6e30692cd2d8 if self._438a78513374 > 0 else _6e30692cd2d8
        self._2e97905ca873 = _5c56c98d45d2(self._6e30692cd2d8)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._d16faa0de913 = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _3946feb41f6a in self._6e30692cd2d8:
            if _5c56c98d45d2(self._327973829216._69f0f4805199(_3946feb41f6a, _b5e85a4a53d2=_00db95800c16)) > 1:
                token = f"{_3946feb41f6a}"
                if token not in self._327973829216._6945cdad3944():
                    self._327973829216._08996bc38765([token], _291199ce6912=_00db95800c16)
                    _6b571304829e = self._327973829216._8f926c2fcfb9(token)
                    _d192e8d79307(f"Added class '{_3946feb41f6a}' Token: {token} (id: {_6b571304829e})")

        # Map every class to single token ID
        self._d16faa0de913 = {
            _a0eb7d51e92e: [self._327973829216._8f926c2fcfb9(f"{_3946feb41f6a}")]
            for _a0eb7d51e92e, _3946feb41f6a in _12054a007492(self._6e30692cd2d8)
        }

        self._82738ddecee1 = {_f706a0f2318b(_0442f998399b): _de964870ee3b for _de964870ee3b, _0442f998399b in self._d16faa0de913._23bc914ed9d4()}
        self._626121d958f5 = _0fef6e80ccdb(_0b9494aecdc5)
        for _a6ec09832e80, _0442f998399b in self._d16faa0de913._23bc914ed9d4():
            self._626121d958f5[_5c56c98d45d2(_0442f998399b)]._765710c831c0((_a6ec09832e80, _0442f998399b))
        self._d67c41ad276d = 0
        _d192e8d79307(f"SEQ {self._d16faa0de913} and {self._82738ddecee1}")
        self._f91a4db1aaae = _327973829216._8c77d72a456c or _327973829216._bc7f71adc0ea
        self._f9b54c0d79f6 = _f9b54c0d79f6
        self._2fedffac9f7b = "multiclass"
        self._8cf23bf6cc15 = -100
        self._afdaf60a51f6 = _327973829216._69f0f4805199("assistant<|end_header_id|>\n\n", _b5e85a4a53d2=_00db95800c16)
        self._7e3a976f2e75 = self._f6fcd941902c()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._566fcaebbc0c = _f5ae1c65e541
        # Resize vocab based token embeddings
        self._566fcaebbc0c._b3def731d49e(_5c56c98d45d2(self._327973829216))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._566fcaebbc0c._23f2ed1f5d2d(_00db95800c16)
        _5cf14de395e4 = _caafb2b63c90()  # bfloat16 or float16

        for _b81c4b0e7efb, _e7b352955304 in self._fa58bc823464():
            if not _356e5d977457(_4e0a0e10f4e3._dd63e72132ac for _4e0a0e10f4e3 in _e7b352955304._777093f629b5(_3ce00808e3a8=_00db95800c16)):
                # FROZEN → BF16 (save memory)
                _e7b352955304._5f3fa46da332(_9c4c79c0803c=_5cf14de395e4)
            else:
                # TRAINABLE → FP32 (stable grads)
                _e7b352955304._5f3fa46da332(_9c4c79c0803c=_695804038798._656ef110f540)
        self._566fcaebbc0c._5f3fa46da332(self._5287239c7dc4)
        if _1a95d2a5efdc(self._566fcaebbc0c, "gradient_checkpointing_enable"):
            self._566fcaebbc0c._cf3d7274c662()
        # determine embedding dim robustly from model config if available
        _52c0e0ab06de = _0191bec34475(_0191bec34475(self._566fcaebbc0c, "config", _e0333a685467), "hidden_size", _e0333a685467)
        if _52c0e0ab06de is _e0333a685467:
            # fallback to common default — change if your model uses a different hidden size
            _52c0e0ab06de = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _1a95d2a5efdc(self._566fcaebbc0c, "lm_head") and _0191bec34475(self._566fcaebbc0c, "lm_head") is not _e0333a685467:
            self._81017538ac28 = self._566fcaebbc0c._27583ccc4da1
        else:
            _5025e5cabd92 = _0191bec34475(self._566fcaebbc0c, "get_output_embeddings", _e0333a685467)
            self._81017538ac28 = _5025e5cabd92() if _ac18e703fe02(_5025e5cabd92) else _e0333a685467

        # mark presence and ensure module (if any) is on the same device
        self._a649398a8217 = self._81017538ac28 is not _e0333a685467
        if self._a649398a8217:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._81017538ac28._5f3fa46da332(self._5287239c7dc4)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._7d15f4a8cdf8 = self._14ae44e9085d(_04eff1e6b0a8=_52c0e0ab06de, _4cf5db948dc2=64)
        self._7d15f4a8cdf8._5f3fa46da332(self._5287239c7dc4)
        for _4e0a0e10f4e3 in self._7d15f4a8cdf8._777093f629b5():
            _4e0a0e10f4e3._dd63e72132ac = _fef3663a10ca
            
        if _8f9b2bca79f2 > 0:
            if "llama" in self._0c7128742064:
                for _f934dd0dddbd in self._566fcaebbc0c._777093f629b5():
                    if not _f934dd0dddbd._4b39a62c67b0:
                        _f934dd0dddbd = _f934dd0dddbd._7fb8965f23fc()
                    _f934dd0dddbd._dd63e72132ac = _00db95800c16  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _a9b9a0695380 = self._566fcaebbc0c._381e6d9d64eb._35e247b0a1cc  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _51ffc9519d5e in _a9b9a0695380[-_8f9b2bca79f2:]:
                    for _f934dd0dddbd in _51ffc9519d5e._777093f629b5():
                        if _7e127e0d68c4(_f934dd0dddbd, _695804038798._39057bac7da9) and (_f934dd0dddbd._fc74b46b4c12() or _695804038798._a6899bdfc15d(_f934dd0dddbd)):
                            _f934dd0dddbd._dd63e72132ac = _fef3663a10ca
                if _1a95d2a5efdc(self._566fcaebbc0c, "lm_head"):
                    self._566fcaebbc0c._27583ccc4da1._dd63e72132ac = _fef3663a10ca

        self._6ed990cec7e9 = 1
        _d192e8d79307(f"DEBUG xth_batch init {self._6ed990cec7e9}")
        global _412883da768d
        _412883da768d = copy._9941a6dbffbd(self._566fcaebbc0c)._0fcfc51ed028()
        self._214b58612281 = _214b58612281

        self._94f6591e624c = {}
        self._b22fe6899f05 = {}

        # Loss function initialization
        if _61e33631cd13._f672636e08dc() == "class_weighted_cross_entropy_loss":
            self._b22fe6899f05['criterion'] = _dee35fdc4e9e(_f9b54c0d79f6=self._f9b54c0d79f6,
                                                            _1dd26ca682a8=self._5287239c7dc4,
                                                            _e80c6b9011f9=self._8cf23bf6cc15,
                                                            _346286f2d79a=self._1c86a99db69c)
        elif _61e33631cd13._f672636e08dc() == "focal_loss":
            self._b22fe6899f05['criterion'] = _8c964e6fd35d(_1ac5c496827d=0.25,
                                                     _1dd26ca682a8=self._5287239c7dc4,
                                                     _e80c6b9011f9=self._8cf23bf6cc15,
                                                     _346286f2d79a=self._1c86a99db69c)
        elif _61e33631cd13._f672636e08dc() == "class_weighted_focal_loss":
            self._b22fe6899f05['criterion'] = _8c964e6fd35d(_1ac5c496827d=self._f9b54c0d79f6,
                                                     _1dd26ca682a8=self._5287239c7dc4,
                                                     _e80c6b9011f9=self._8cf23bf6cc15,
                                                     _346286f2d79a=self._1c86a99db69c)
        elif _61e33631cd13._f672636e08dc() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._b22fe6899f05['criterion'] = _981359effe27(_1ac5c496827d=self._f9b54c0d79f6,
                                                                      _daeef7be40bf='type1',
                                                                      _1dd26ca682a8=self._5287239c7dc4,
                                                                      _e80c6b9011f9=self._8cf23bf6cc15,
                                                                      _346286f2d79a=self._1c86a99db69c)
        elif _61e33631cd13._f672636e08dc() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._b22fe6899f05['criterion'] = _981359effe27(_1ac5c496827d=self._f9b54c0d79f6,
                                                                      _daeef7be40bf='type2',
                                                                      _1dd26ca682a8=self._5287239c7dc4,
                                                                      _e80c6b9011f9=self._8cf23bf6cc15,
                                                                      _346286f2d79a=self._1c86a99db69c)
        elif _61e33631cd13._f672636e08dc() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._b22fe6899f05['criterion'] = _981359effe27(_1ac5c496827d=self._f9b54c0d79f6,
                                                                      _daeef7be40bf='type3',
                                                                      _1dd26ca682a8=self._5287239c7dc4,
                                                                      _e80c6b9011f9=self._8cf23bf6cc15,
                                                                      _346286f2d79a=self._1c86a99db69c)
        else:
            self._b22fe6899f05['criterion'] = _dee35fdc4e9e(_1dd26ca682a8=self._5287239c7dc4,
                                                            _e80c6b9011f9=self._8cf23bf6cc15,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._431fb44305a8 = 0.99
        self._8e3c2273d70b = 0.3
        self._b1e0dff057c0 = 0.30
        self._425efd6ec6fc = 0.25
        self._7f218a60243e = 0.6
        self._4a7223b04a9e = 0.995
        self._49bbeac39418 = 0.60
        self._87cdfa7ee9ba = 0.20
        self._c2e3c6ef381f = _0191bec34475(self, "batch_counter", 0)


        self._27be6ccb9a01 = []
        self._9ba8a73bccf4 = []

        self._9952bc80a64a = _43575df0dcb4._f672636e08dc()
        self._e2e25a4affe5()

        self._9dd78da0f5d0(self._566fcaebbc0c)
    
    def _ff41fd1fc7e2(self):
        # rebuild all metrics on the correct device
        self._94f6591e624c['micro_accuracy'] = _925e5e0c4230(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5="micro",
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['macro_accuracy'] = _925e5e0c4230(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5="macro",
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['macro_precision'] = _28203ac73d79(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5="macro",
            _21c4d0325f73=self. _2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['macro_recall'] = _de48aace01ea(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5="macro",
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['macro_f1'] = _f68318aaed33(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5="macro",
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['classwise_accuracy'] = _925e5e0c4230(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5=_e0333a685467,
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['classwise_precision'] = _28203ac73d79(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5=_e0333a685467,
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['classwise_recall'] = _de48aace01ea(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5=_e0333a685467,
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['classwise_f1'] = _f68318aaed33(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _db6a87f4e7e5=_e0333a685467,
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)

        self._94f6591e624c['confmat'] = _04cfa826dc77(
            _2e97905ca873=_5c56c98d45d2(self._6e30692cd2d8),
            _21c4d0325f73=self._2fedffac9f7b,
            _e80c6b9011f9=self._8cf23bf6cc15,
        )._5f3fa46da332(self._5287239c7dc4)


    def _7b1298e303ba(self, _8b04a5aa873a=_e0333a685467):
        """Calculate batch counts and set xth_batch_to_consider."""
        _1ef6f09112af = 0
        _8f12538fed7a = 0
        if self._4e3895a8aa8d._fbdef89d242a is not _e0333a685467:
            if _1a95d2a5efdc(self._4e3895a8aa8d._fbdef89d242a, 'train_dataset') and self._4e3895a8aa8d._fbdef89d242a._7f72eafcff27 is not _e0333a685467:
                _1ef6f09112af = _5c56c98d45d2(self._4e3895a8aa8d._fbdef89d242a._7f72eafcff27)
            if _1a95d2a5efdc(self._4e3895a8aa8d._fbdef89d242a, 'val_dataset') and self._4e3895a8aa8d._fbdef89d242a._efa9183a2202 is not _e0333a685467:
                _8f12538fed7a = _5c56c98d45d2(self._4e3895a8aa8d._fbdef89d242a._efa9183a2202)
            _e72bb4450fa6 = self._4e3895a8aa8d._fbdef89d242a._e72bb4450fa6
            _856208297fa9 = (_1ef6f09112af + _e72bb4450fa6 - 1) // _e72bb4450fa6 if _1ef6f09112af > 0 else 1
            _f3698b83c108 = (_8f12538fed7a + _e72bb4450fa6 - 1) // _e72bb4450fa6 if _8f12538fed7a > 0 else 1
            _215ba5470caa = _884377ed7a1b(_856208297fa9, _f3698b83c108) if _8f12538fed7a > 0 else _856208297fa9
            _c6b45a5098ef = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._6ed990cec7e9 = 1
            _d192e8d79307(f"DEBUG Batch Info: num_train_batches={_856208297fa9}, num_val_batches={_f3698b83c108}, xth_batch_to_consider={self._6ed990cec7e9}")

    def _4b3c4619ed5c(self, _024b6454051b, _33f71d57c44f):
        if _024b6454051b._f672636e08dc() == "parametric_relu":
            return _695804038798._d99d914cb171._0a2d845a0a6a(_33f71d57c44f=1)
        elif _024b6454051b._f672636e08dc() == "leaky_relu":
            return _695804038798._d99d914cb171._730254c8d996(_d0b304cdcbf8=_00db95800c16)
        else:
            return _695804038798._d99d914cb171._116f883256f3(_d0b304cdcbf8=_00db95800c16)

    def _1e40f6f97390(self, _e7b352955304, _c8c369706ee4=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _b81c4b0e7efb, _aa9e3e93d5d7 in _e7b352955304._549f5fe9ae8c():
            _8d4146cd16ea = f"{_c8c369706ee4}.{_b81c4b0e7efb}" if _c8c369706ee4 else _b81c4b0e7efb

            def _b73a3c7b2999(_ad3d58114e04, _5d0c8eb6ef08, _0175f23bdade):
                if _7e127e0d68c4(_0175f23bdade, _695804038798._39057bac7da9) and _0175f23bdade._dbdb0923cead()._356e5d977457():
                    _d192e8d79307(f"NaN detected in {_8d4146cd16ea} ({_ad3d58114e04._6f35fbc63336.__name__}) ({_0175f23bdade._9c4c79c0803c})")

            _aa9e3e93d5d7._f6c7e3afddf0(_c78ec4f6b920)

            self._9dd78da0f5d0(_aa9e3e93d5d7, _8d4146cd16ea)

    def _d351449281c1(self, _e7b352955304):
        return _356e5d977457(_4e0a0e10f4e3._dd63e72132ac for _4e0a0e10f4e3 in _e7b352955304._777093f629b5())

    def _6afc4bdc8159(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _31c42decb382 = []
        for _b81c4b0e7efb, _e7b352955304 in self._fa58bc823464():
            if not self._4828fd33aecc(_e7b352955304):
                continue
            _a2be5b52b7c0 = (
                "norm" in _b81c4b0e7efb._17546d413436() or 
                "linear4bit" in _b81c4b0e7efb._17546d413436() or 
                _356e5d977457(_27cc9ecf9101 in _b81c4b0e7efb._17546d413436() for _27cc9ecf9101 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _b81c4b0e7efb._17546d413436() or 
                "dropout" in _b81c4b0e7efb._17546d413436() or 
                _7e127e0d68c4(_e7b352955304, (_08b04f0159f6, _695804038798._d99d914cb171._136294950ca3, _695804038798._d99d914cb171._4c82b2a99010))
            )
            if _a2be5b52b7c0:
                if _1a95d2a5efdc(_e7b352955304, "eps"):
                    _e7b352955304._00cc9bb8ed85 = 1e-3
                _e7b352955304 = _e7b352955304._5f3fa46da332(_695804038798._656ef110f540)
                if not _7e127e0d68c4(_e7b352955304, _1d26cbb8b161._e47d5f0a941c):
                    _31c42decb382._765710c831c0((_b81c4b0e7efb, _1d26cbb8b161._e47d5f0a941c(_e7b352955304, _280bb7024dfe=-10, _c7525dc86283=10)))
        for _b81c4b0e7efb, _3040964c5719 in _31c42decb382:
            _51a3ebfaeb45, _160d1fea7bda = self._10611f52a1be(_b81c4b0e7efb)
            if _51a3ebfaeb45 is not _e0333a685467:
                _f7250e5fe3ca(_51a3ebfaeb45, _160d1fea7bda, _3040964c5719)

    def _aae985490a46(self, _52b146322047):
        """Finds the parent module and attribute name given the full module path."""
        _ec7d9037e498 = _52b146322047._a88179000d2f('.')
        _5b838ff242df = self
        for _fe52b94376f0 in _ec7d9037e498[:-1]:
            _5b838ff242df = _0191bec34475(_5b838ff242df, _fe52b94376f0, _e0333a685467)
            if _5b838ff242df is _e0333a685467:
                return _e0333a685467, _e0333a685467
        return _5b838ff242df, _ec7d9037e498[-1]

    def _586d1c88f214(self, _8fad22172230: _695804038798._39057bac7da9, _4a1a7ea20d54: _695804038798._39057bac7da9, _eac13f159783: _695804038798._39057bac7da9) -> _92d7b4de0090:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _1dd26ca682a8 = _8fad22172230._1dd26ca682a8

        # 1) gating w (use cached per-example teacher_conf if available)
        _b34516cbd22d = _0191bec34475(self, "_last_teacher_conf", _e0333a685467)
        if _b34516cbd22d is _e0333a685467:
            # no teacher info => w = 0 (no distillation)
            _2fd311f1c11e = 0.0
        else:
            _7925978d50a8 = (_b34516cbd22d >= _9f80a393943a(_0191bec34475(self, "teacher_conf_tau", 0.6)))._9f80a393943a()
            _2fd311f1c11e = _9f80a393943a(_7925978d50a8._98530a1013f8()._764f9e2c1112()._eca40a7b2f6b()) if _7925978d50a8._194ba60d6904() > 0 else 0.0

        # apply gating to the batch scalars
        _e1735614a67b = _4a1a7ea20d54 * _9f80a393943a(_2fd311f1c11e)
        _3e0037b702c4 = _eac13f159783 * _9f80a393943a(_2fd311f1c11e)

        # 2) EMAs for autoscaling
        _e01628adabbb = _9f80a393943a((_e1735614a67b + _3e0037b702c4)._7fb8965f23fc()._764f9e2c1112()._eca40a7b2f6b())
        _2bb977f64fd1 = _9f80a393943a(_8fad22172230._7fb8965f23fc()._764f9e2c1112()._eca40a7b2f6b())
        if _0191bec34475(self, "ema_task", _e0333a685467) is _e0333a685467:
            self._3bdbbb484572 = _2bb977f64fd1
            self._c83af64e06ea = _e01628adabbb + 1e-12
        else:
            _1ac5c496827d = _9f80a393943a(_0191bec34475(self, "ema_alpha", 0.99))
            self._3bdbbb484572 = _1ac5c496827d * _9f80a393943a(self._3bdbbb484572) + (1.0 - _1ac5c496827d) * _2bb977f64fd1
            self._c83af64e06ea  = _1ac5c496827d * _9f80a393943a(self._c83af64e06ea)  + (1.0 - _1ac5c496827d) * _e01628adabbb

        _54f193bda7c1 = _9f80a393943a(_0191bec34475(self, "distill_target_ratio", 0.3))
        _9a1928514d5c = (_9f80a393943a(self._3bdbbb484572) / (_9f80a393943a(self._c83af64e06ea) + 1e-12)) * _54f193bda7c1
        _09d48efbffec = _9f80a393943a(_9a1928514d5c)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _79e85cde11ac = _9f80a393943a(_0191bec34475(self._4e3895a8aa8d, "current_epoch", _0191bec34475(self._4e3895a8aa8d, "global_step", 0.0)))
        _21bbc9b2476e = _9f80a393943a(_801945e0cf62(1, _0191bec34475(self._4e3895a8aa8d, "max_epochs", 1)))
        _9fdcf1e2a5ee = _884377ed7a1b(_801945e0cf62(_79e85cde11ac / _21bbc9b2476e, 0.0), 1.0)
        _eac333be418a = 0.30
        _673ba6a9fc38 = _9f80a393943a(_0191bec34475(self, "kl_base", 0.30)) * _884377ed7a1b(_9fdcf1e2a5ee / _eac333be418a, 1.0)
        _425efd6ec6fc = _9f80a393943a(_0191bec34475(self, "cos_base", 0.25))
        _bfecf9ed1f71 = _425efd6ec6fc + (0.10 - _425efd6ec6fc) * _9fdcf1e2a5ee

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _5bcc9ba54ee9 = _9f80a393943a(self._109b507a7759._98530a1013f8()._764f9e2c1112()._eca40a7b2f6b()) if _0191bec34475(self, "_last_teacher_conf", _e0333a685467) is not _e0333a685467 else 0.0
        if _0191bec34475(self, "ema_teacher_conf", _e0333a685467) is _e0333a685467:
            self._dab629658662 = _5bcc9ba54ee9
        else:
            _aa6a04fa87c2 = _9f80a393943a(_0191bec34475(self, "teacher_conf_beta", 0.995))
            self._dab629658662 = _aa6a04fa87c2 * _9f80a393943a(self._dab629658662) + (1.0 - _aa6a04fa87c2) * _5bcc9ba54ee9

        _49bbeac39418 = _9f80a393943a(_0191bec34475(self, "tau_warn", 0.60))
        _87cdfa7ee9ba = _9f80a393943a(_0191bec34475(self, "tau_detect", 0.20))
        _3909e66376e5 = _801945e0cf62(1e-12, (_49bbeac39418 - _87cdfa7ee9ba))
        _8b8ebb102bfb = (_9f80a393943a(self._dab629658662) - _87cdfa7ee9ba) / _3909e66376e5
        _8b8ebb102bfb = _801945e0cf62(0.0, _884377ed7a1b(1.0, _8b8ebb102bfb))

        _e6c1e32c6a28 = _673ba6a9fc38 * _8b8ebb102bfb
        _98c1734c239f = _bfecf9ed1f71 * _8b8ebb102bfb

        # 5) final aux term
        _a3356ff6a8dc = _695804038798._ea1185bc1fb5(0.0, _1dd26ca682a8=_1dd26ca682a8)
        _a3356ff6a8dc = _a3356ff6a8dc + (_e6c1e32c6a28 * _e1735614a67b + _98c1734c239f * _3e0037b702c4) * _9f80a393943a(_09d48efbffec)

        # diagnostics
        _0175f23bdade = {
            "aux_term": _a3356ff6a8dc,
            "kl_batch": _4a1a7ea20d54,
            "contrast_batch": _eac13f159783,
            "kl_loss": _e1735614a67b,
            "contrastive_loss": _3e0037b702c4,
            "w_mean": _2fd311f1c11e,
            "aux_scale": _9f80a393943a(_09d48efbffec),
            "lambda_kl_eff": _9f80a393943a(_e6c1e32c6a28),
            "lambda_cos_eff": _9f80a393943a(_98c1734c239f),
            "teacher_conf_mean": _9f80a393943a(self._dab629658662),
            "shift_r": _9f80a393943a(_8b8ebb102bfb)
        }
        return _0175f23bdade

    def _6407a70afc35(self, _fdc136a55819):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _fdc136a55819 = _fdc136a55819._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)
        _2d9db20b0e02 = (_fdc136a55819 != self._327973829216._8c77d72a456c)._5f3fa46da332(_9c4c79c0803c=_695804038798._85a716e04afe, _1dd26ca682a8=self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)

        # model forward (request hidden states)
        _d2673be47344 = self._566fcaebbc0c(
            _fdc136a55819=_fdc136a55819,
            _2d9db20b0e02=_2d9db20b0e02,
            _af32236e5d5b=_fef3663a10ca,
            _ad6e6aa84f7e=_fef3663a10ca,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _1499b9b4570a = _0191bec34475(_d2673be47344, "last_hidden_state", _e0333a685467)
        if _1499b9b4570a is _e0333a685467:
            _1499b9b4570a = _d2673be47344._4e57425becba[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _1499b9b4570a._9c4c79c0803c != _695804038798._656ef110f540:
            _1499b9b4570a = _1499b9b4570a._5f3fa46da332(_695804038798._656ef110f540)
        _e8547a1e0fc4 = self._7d15f4a8cdf8(_1499b9b4570a)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._a649398a8217:
            _ccf77227a00c = self._81017538ac28(_e8547a1e0fc4)
        else:
            _ccf77227a00c = _d2673be47344._ccf77227a00c


        _ccf77227a00c = _ccf77227a00c._5f3fa46da332(_695804038798._656ef110f540)._1ccb7014c0b3(-20, 20)

        # default zero scalars
        _e1735614a67b = _695804038798._ea1185bc1fb5(0.0, _1dd26ca682a8=self._5287239c7dc4)
        _3e0037b702c4 = _695804038798._ea1185bc1fb5(0.0, _1dd26ca682a8=self._5287239c7dc4)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _db930ee1cd6c = _0191bec34475(self, "trainer", _e0333a685467)
        _186635a0a4bb = _00db95800c16
        if _db930ee1cd6c is not _e0333a685467:
            _186635a0a4bb = _85a716e04afe(_0191bec34475(self._4e3895a8aa8d, "training", _00db95800c16) or _0191bec34475(self._4e3895a8aa8d, "validating", _00db95800c16))

        if _186635a0a4bb and (_0191bec34475(self, "batch_counter", 0) % _0191bec34475(self, "xth_batch_to_consider", 1) == 0):
            with _695804038798._cdc7263698ee():
                _5c13e7ca6219 = _412883da768d(
                    _fdc136a55819=_fdc136a55819,
                    _2d9db20b0e02=_2d9db20b0e02,
                    _af32236e5d5b=_fef3663a10ca,
                    _ad6e6aa84f7e=_fef3663a10ca,
                )
                _560ba5a4bad1 = _0191bec34475(_5c13e7ca6219, "last_hidden_state", _e0333a685467)
                if _560ba5a4bad1 is _e0333a685467:
                    _560ba5a4bad1 = _5c13e7ca6219._4e57425becba[-1]

            # compute embedding-level KL + contrastive (scalar)
            _e1735614a67b, _3e0037b702c4 = self._e22cd5666e0c(_e8547a1e0fc4, _560ba5a4bad1, _1dd26ca682a8=self._5287239c7dc4)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _0f103a5e2854(_c1fad5b1c343): return _c1fad5b1c343._98530a1013f8(_04eff1e6b0a8=1) if _c1fad5b1c343._04eff1e6b0a8() == 3 else _c1fad5b1c343
            _bbb668752357 = _695804038798._d99d914cb171._a58a5d1c493c._8f43c7cbf8c3(_5ff8273ec78d(_e8547a1e0fc4), _4e0a0e10f4e3=2, _04eff1e6b0a8=-1, _00cc9bb8ed85=1e-6)
            _7f5abadf3482 = _695804038798._d99d914cb171._a58a5d1c493c._8f43c7cbf8c3(_5ff8273ec78d(_560ba5a4bad1), _4e0a0e10f4e3=2, _04eff1e6b0a8=-1, _00cc9bb8ed85=1e-6)
            _3382d56b7401 = _695804038798._d99d914cb171._a58a5d1c493c._f3178dfcc57a(_bbb668752357, _7f5abadf3482, _04eff1e6b0a8=-1)  # [-1,1]
            _b34516cbd22d = _3382d56b7401._1ccb7014c0b3(_884377ed7a1b=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._4d09a7bfd0bb = _e8547a1e0fc4._7fb8965f23fc()
            self._7cec2c584583 = _560ba5a4bad1._7fb8965f23fc()
            self._109b507a7759 = _b34516cbd22d._7fb8965f23fc()  # shape (B,)

        # increment counter
        self._c2e3c6ef381f = _0191bec34475(self, "batch_counter", 0) + 1

        return _ccf77227a00c, _e1735614a67b, _3e0037b702c4


    def _03ed47514c92(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _816c5fb5e56b(_e7b352955304, _ad3d2338576f, _6e683451f42b):
            if _356e5d977457(_5d0c8eb6ef08._9c4c79c0803c == _695804038798._dfcbd9b65d7d for _5d0c8eb6ef08 in _ad3d2338576f if _7e127e0d68c4(_5d0c8eb6ef08, _695804038798._39057bac7da9)):
                _d192e8d79307(f"Layer {_e7b352955304._6f35fbc63336.__name__} is using float16!")

        for _6d9601c8cc5a in self._5d9b8f09fae0():
            _c7008c284a4f = _6d9601c8cc5a._f6c7e3afddf0(_c53373269ea0)
            self._364874e3f2ff._765710c831c0(_c7008c284a4f)

    def _4bf1d8f1c7e5(self):
        """Remove all registered forward hooks."""
        for _c7008c284a4f in _0191bec34475(self, "amp_hooks", []):
            _c7008c284a4f._8a31675132b0()
        self._364874e3f2ff = []

    def _38526eae26db(self, _fdc136a55819, _42e88acc3151, _f6c5d1af5074):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _c04a7a4a1059 = [self._327973829216._9c1e984a3dcc(_012d53fdf4da) for _012d53fdf4da in _fdc136a55819]
        _abfad43ca0b7, _317ffb0f7049 = [], []

        for _39588b14c5c5, _d9511322fcbf, _f9bd121407a3 in _c32a2a37b85c(_c04a7a4a1059, _42e88acc3151, _f6c5d1af5074):
            for token, _6c1796c4efe7, _dcfb0ce4ffd0 in _c32a2a37b85c(_39588b14c5c5, _d9511322fcbf, _f9bd121407a3):
                if token == self._327973829216._c1e37286fb83 or _dcfb0ce4ffd0 == self._8cf23bf6cc15:
                    continue

                _5a194202fbce = (
                    token._b430df53ef89("##") or
                    token._b430df53ef89("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _5a194202fbce:
                    continue

                _abfad43ca0b7._765710c831c0(_6c1796c4efe7._eca40a7b2f6b())
                _317ffb0f7049._765710c831c0(_dcfb0ce4ffd0._eca40a7b2f6b())

        return _695804038798._ea1185bc1fb5(_abfad43ca0b7), _695804038798._ea1185bc1fb5(_317ffb0f7049)

    def _78c44e7cf065(self):
        _da6c20cf8232 = _695804038798._656ef110f540
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            _32f8eac20726, _817728d87ce8 = _695804038798._1d9613fc3f23._977a41a67f21()
            if _32f8eac20726 >= 8:
                _da6c20cf8232 = _695804038798._0bdc8898fdca
            else:
                _da6c20cf8232 = _695804038798._dfcbd9b65d7d
        return _da6c20cf8232

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _8eb51b933927(
        self,
        _1c2d5ae8a331: _695804038798._39057bac7da9,
        _17aaf2b9282b: _695804038798._39057bac7da9,
        _1dd26ca682a8: _4dc6837b43ba = "cpu",
    ) -> _a16ec371122c[_695804038798._39057bac7da9, _695804038798._39057bac7da9]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _c667c56e078b = 2.0
            # NaN/Inf guard
            _1c2d5ae8a331 = _1c2d5ae8a331._1ccb7014c0b3(_884377ed7a1b=-30, _801945e0cf62=30)
            _17aaf2b9282b = _17aaf2b9282b._1ccb7014c0b3(_884377ed7a1b=-30, _801945e0cf62=30)

            # Move once if needed
            _1509b822c078 = _695804038798._1dd26ca682a8(_1dd26ca682a8)
            if _1c2d5ae8a331._1dd26ca682a8 != _1509b822c078:
                _1c2d5ae8a331 = _1c2d5ae8a331._5f3fa46da332(_1dd26ca682a8=_1509b822c078, _32f1501ecd4c=_fef3663a10ca, _9c4c79c0803c=self._7e3a976f2e75)
                _17aaf2b9282b = _17aaf2b9282b._5f3fa46da332(_1dd26ca682a8=_1509b822c078, _32f1501ecd4c=_fef3663a10ca, _9c4c79c0803c=self._7e3a976f2e75)

            _e72bb4450fa6 = _1c2d5ae8a331._12d5cc68a327(0)
            _52c0e0ab06de = _1c2d5ae8a331._12d5cc68a327(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _7fed8965814b = (_e72bb4450fa6 * _52c0e0ab06de) > 32_000_000

            if not _7fed8965814b or _e72bb4450fa6 <= 8:
                # Direct computation
                _758233ae3489 = _695804038798._d99d914cb171._a58a5d1c493c._029e34357433(_1c2d5ae8a331 / _c667c56e078b, _04eff1e6b0a8=-1)
                _d619b2ae977c = _695804038798._d99d914cb171._a58a5d1c493c._2c9e196f7132(_17aaf2b9282b / _c667c56e078b, _04eff1e6b0a8=-1)
                _e1735614a67b = _695804038798._d99d914cb171._a58a5d1c493c._5e279dd670a2(_758233ae3489, _d619b2ae977c, _8b3926b0ede3="batchmean") * (_c667c56e078b * _c667c56e078b)
                _3e0037b702c4 = 1 - _695804038798._d99d914cb171._a58a5d1c493c._f3178dfcc57a(_1c2d5ae8a331, _17aaf2b9282b, _04eff1e6b0a8=-1)._98530a1013f8()
                return _e1735614a67b, _3e0037b702c4

            # Chunked mode for large inputs
            _2a905e8ed329 = _801945e0cf62(1, _e72bb4450fa6 // 8)
            _5bde62d02343, _10bf4a1344d9 = [], []

            for _2ba727c12923 in _9fd4a891ab02(0, _e72bb4450fa6, _2a905e8ed329):
                _601308edf120 = _1c2d5ae8a331[_2ba727c12923:_2ba727c12923 + _2a905e8ed329]
                _64280d3a0403 = _17aaf2b9282b[_2ba727c12923:_2ba727c12923 + _2a905e8ed329]

                _758233ae3489 = _695804038798._d99d914cb171._a58a5d1c493c._029e34357433(_601308edf120 / _c667c56e078b, _04eff1e6b0a8=-1)
                _d619b2ae977c = _695804038798._d99d914cb171._a58a5d1c493c._2c9e196f7132(_64280d3a0403 / _c667c56e078b, _04eff1e6b0a8=-1)

                _5dd0571d3b01 = _695804038798._d99d914cb171._a58a5d1c493c._5e279dd670a2(_758233ae3489, _d619b2ae977c, _8b3926b0ede3="batchmean") * (_c667c56e078b * _c667c56e078b)
                _c44eea968af6 = _695804038798._d99d914cb171._a58a5d1c493c._f3178dfcc57a(_601308edf120, _64280d3a0403, _04eff1e6b0a8=-1)._98530a1013f8()
                _1f4c8639bee6 = 1 - _c44eea968af6

                _5bde62d02343._765710c831c0(_5dd0571d3b01)
                _10bf4a1344d9._765710c831c0(_1f4c8639bee6)

            _e1735614a67b = _695804038798._4a67b64366da(_5bde62d02343)._98530a1013f8()
            _3e0037b702c4 = _695804038798._4a67b64366da(_10bf4a1344d9)._98530a1013f8()
            return _e1735614a67b, _3e0037b702c4

        except _41ce0cfcb8f4 as _6e4a9e5cea80:
            raise _7d537dd754e7(f"KL/contrastive loss computation failed: {_4dc6837b43ba(_6e4a9e5cea80)}")


    def _6e416e604d8c(self, _1b1d07cf35cc, _4f971abd14a9):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _fdc136a55819 = _1b1d07cf35cc["input_ids"]
            _d071bc722c8f = _1b1d07cf35cc["labels"]
            _68c27b7cccd4 = _1b1d07cf35cc._ee17a8f9adb1("prompt_lens", _e0333a685467)
            _e72bb4450fa6 = _fdc136a55819._12d5cc68a327(0)

            # move to device
            _fdc136a55819 = _fdc136a55819._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)
            _d071bc722c8f = _d071bc722c8f._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _6e683451f42b, _4a1a7ea20d54, _eac13f159783 = self(_fdc136a55819)

            # causal LM shift for next-token classification (unchanged)
            _7133284c1981 = _6e683451f42b[:, :-1, :]._41f4c9d6ae66()
            _682b6eb8a935 = _d071bc722c8f[:, 1:]._41f4c9d6ae66()
            _15748bace7fa = _7133284c1981._6bef2bd4b244(-1, _7133284c1981._12d5cc68a327(-1))
            _e5e09d90ec45 = _682b6eb8a935._6bef2bd4b244(-1)

            # classification/task loss
            _7f22039a8ec9 = self._b22fe6899f05['criterion'](_15748bace7fa, _e5e09d90ec45)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _4a1a7ea20d54 = _695804038798._17ff38cf0f81(_4a1a7ea20d54, _cf6b5ef1aaf4=0.0, _4fc713b4ad0c=0.0, _716478d80556=0.0)
            _eac13f159783 = _695804038798._17ff38cf0f81(_eac13f159783, _cf6b5ef1aaf4=0.0, _4fc713b4ad0c=0.0, _716478d80556=0.0)
            _7f22039a8ec9 = _695804038798._17ff38cf0f81(_7f22039a8ec9, _cf6b5ef1aaf4=0.0, _4fc713b4ad0c=0.0, _716478d80556=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _f49f4bcf6ea2 = self._9bbffb364982(_7f22039a8ec9, _4a1a7ea20d54, _eac13f159783)
            _a3356ff6a8dc = _f49f4bcf6ea2["aux_term"]

            # final combined loss (single-equation)
            _ccc48a599b79 = _7f22039a8ec9 + _a3356ff6a8dc

            # Optional NaN print as before (keeps your original check)
            if _695804038798._dbdb0923cead(_7f22039a8ec9):
                _d192e8d79307(f"Step {_4f971abd14a9}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _67abff2aa6ec = {
                "epoch": _9f80a393943a(_0191bec34475(self, "current_epoch", _0191bec34475(self._4e3895a8aa8d, "current_epoch", 0))),
                "train_kl_loss": _f49f4bcf6ea2._ee17a8f9adb1("kl_loss", _4a1a7ea20d54)._7fb8965f23fc() if _7e127e0d68c4(_f49f4bcf6ea2._ee17a8f9adb1("kl_loss", _4a1a7ea20d54), _695804038798._39057bac7da9) else _f49f4bcf6ea2._ee17a8f9adb1("kl_loss", _4a1a7ea20d54),
                "train_contrastive_loss": _f49f4bcf6ea2._ee17a8f9adb1("contrastive_loss", _eac13f159783)._7fb8965f23fc() if _7e127e0d68c4(_f49f4bcf6ea2._ee17a8f9adb1("contrastive_loss", _eac13f159783), _695804038798._39057bac7da9) else _f49f4bcf6ea2._ee17a8f9adb1("contrastive_loss", _eac13f159783),
                "train_classification_loss": _7f22039a8ec9._7fb8965f23fc(),
                "train_loss": _ccc48a599b79._7fb8965f23fc(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _9f80a393943a(_0191bec34475(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _f49f4bcf6ea2._ee17a8f9adb1("lambda_kl_eff", _9f80a393943a(_0191bec34475(self, "kl_base", 0.30))),
                "train_lambda_contrast": _f49f4bcf6ea2._ee17a8f9adb1("lambda_cos_eff", _9f80a393943a(_0191bec34475(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _71efe1468911 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _71efe1468911 in _f49f4bcf6ea2:
                    _0c624202f25c = _f49f4bcf6ea2[_71efe1468911]
                    # convert single-element tensors to python floats for logging
                    if _7e127e0d68c4(_0c624202f25c, _695804038798._39057bac7da9) and _0c624202f25c._194ba60d6904() == 1:
                        _67abff2aa6ec[f"train_{_71efe1468911}"] = _9f80a393943a(_0c624202f25c._7fb8965f23fc()._764f9e2c1112()._eca40a7b2f6b())
                    else:
                        _67abff2aa6ec[f"train_{_71efe1468911}"] = _0c624202f25c

            # log exactly like you did
            self._0d21a08014b3(
                _67abff2aa6ec,
                _e72bb4450fa6=_e72bb4450fa6,
                _37b3569c7ca3=_00db95800c16,
                _77ac50a40ba1=_fef3663a10ca,
                _93fb18c609a2=_00db95800c16,
                _e24767457426=_fef3663a10ca,
                _7ed81678c7bf=_fef3663a10ca,
            )

            # free references as you did
            del _fdc136a55819, _d071bc722c8f, _6e683451f42b, _4a1a7ea20d54, _7f22039a8ec9, _eac13f159783, _682b6eb8a935, _7133284c1981, _e5e09d90ec45, _15748bace7fa

            return _ccc48a599b79

        except _41ce0cfcb8f4 as _6e4a9e5cea80:
            raise _7d537dd754e7(f"Error in training_step: {_6e4a9e5cea80}") from _6e4a9e5cea80

    def _d1c9e8aca4df(self):
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            _695804038798._1d9613fc3f23._858372616079()
        _9b19313fbbe3._3b4b219b332a()
        return _1d5d28892616()._d3ddd0474a31()

    def _ba04b2fa683e(self, _1b1d07cf35cc, _4f971abd14a9):
        _fdc136a55819      = _1b1d07cf35cc["input_ids"]._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)
        _d071bc722c8f         = _1b1d07cf35cc["labels"]._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)
        _ab1e690a4f78     = _1b1d07cf35cc._ee17a8f9adb1("lang_codes", _e0333a685467)
        _3ad9173bcd40     = _1b1d07cf35cc._ee17a8f9adb1("sample_ids", _e0333a685467)
        _b5cdf8575f9a      = _1b1d07cf35cc._ee17a8f9adb1("chunk_ids", _e0333a685467)
        _ab28754a0336 = _1b1d07cf35cc._ee17a8f9adb1("word_positions", _e0333a685467)
        _68c27b7cccd4    = _1b1d07cf35cc._ee17a8f9adb1("prompt_lens", _e0333a685467)
        _0459261051bf = _1b1d07cf35cc._ee17a8f9adb1("num_chunks", _e0333a685467)

        _e72bb4450fa6 = _fdc136a55819._12d5cc68a327(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _6e683451f42b, _4a1a7ea20d54, _eac13f159783 = self(_fdc136a55819)

        # causal LM shift for next-token classification (same as training)
        _7133284c1981 = _6e683451f42b[:, :-1, :]._41f4c9d6ae66()
        _682b6eb8a935 = _d071bc722c8f[:, 1:]._41f4c9d6ae66()
        _15748bace7fa = _7133284c1981._6bef2bd4b244(-1, _7133284c1981._12d5cc68a327(-1))
        _e5e09d90ec45 = _682b6eb8a935._6bef2bd4b244(-1)

        if _4f971abd14a9 == 0:
            try:
                _d192e8d79307(
                    f"VAL TEST BATCH {_4f971abd14a9} Input IDs: {_fdc136a55819._71c57657d0aa()[0]}, "
                    f"Predictions: {_695804038798._01914d704e6d(_7133284c1981, _04eff1e6b0a8=-1)._71c57657d0aa()[0]}, "
                    f"Labels: {_682b6eb8a935._71c57657d0aa()[0]}"
                )
            except _41ce0cfcb8f4:
                # printing should never crash validation
                pass

        # classification loss
        _7f22039a8ec9 = self._b22fe6899f05['criterion'](_15748bace7fa, _e5e09d90ec45)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _4a1a7ea20d54 = _695804038798._17ff38cf0f81(_4a1a7ea20d54, _cf6b5ef1aaf4=0.0, _4fc713b4ad0c=0.0, _716478d80556=0.0)
        _eac13f159783 = _695804038798._17ff38cf0f81(_eac13f159783, _cf6b5ef1aaf4=0.0, _4fc713b4ad0c=0.0, _716478d80556=0.0)
        _7f22039a8ec9 = _695804038798._17ff38cf0f81(_7f22039a8ec9, _cf6b5ef1aaf4=0.0, _4fc713b4ad0c=0.0, _716478d80556=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _f49f4bcf6ea2 = self._9bbffb364982(_7f22039a8ec9, _4a1a7ea20d54, _eac13f159783)
        _a3356ff6a8dc = _f49f4bcf6ea2["aux_term"]
        _ccc48a599b79 = _7f22039a8ec9 + _a3356ff6a8dc

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _0d21a08014b3 = {
            "val_kl_loss": _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("kl_loss", _4a1a7ea20d54)._7fb8965f23fc()._764f9e2c1112()._eca40a7b2f6b()) if _7e127e0d68c4(_f49f4bcf6ea2._ee17a8f9adb1("kl_loss", _4a1a7ea20d54), _695804038798._39057bac7da9) else _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("kl_loss", _4a1a7ea20d54)),
            "val_contrastive_loss": _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("contrastive_loss", _eac13f159783)._7fb8965f23fc()._764f9e2c1112()._eca40a7b2f6b()) if _7e127e0d68c4(_f49f4bcf6ea2._ee17a8f9adb1("contrastive_loss", _eac13f159783), _695804038798._39057bac7da9) else _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("contrastive_loss", _eac13f159783)),
            "val_classification_loss": _9f80a393943a(_7f22039a8ec9._7fb8965f23fc()._764f9e2c1112()._eca40a7b2f6b()),
            "val_loss": _9f80a393943a(_ccc48a599b79._7fb8965f23fc()._764f9e2c1112()._eca40a7b2f6b()),
        }

        # include effective lambdas and others if provided by aux
        _0d21a08014b3["val_lambda_kl"] = _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("lambda_kl", _f49f4bcf6ea2._ee17a8f9adb1("lambda_kl_eff", _9f80a393943a(_0191bec34475(self, "kl_base", 0.30)))))
        _0d21a08014b3["val_lambda_contrast"] = _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("lambda_cos", _f49f4bcf6ea2._ee17a8f9adb1("lambda_cos_eff", _9f80a393943a(_0191bec34475(self, "cos_base", 0.25)))))
        _0d21a08014b3["val_w_mean"] = _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("w_mean", 0.0))
        _0d21a08014b3["val_aux_scale"] = _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("aux_scale", 0.0))
        _0d21a08014b3["val_shift_r"] = _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("shift_r", 0.0))
        _0d21a08014b3["val_teacher_conf_mean"] = _9f80a393943a(_f49f4bcf6ea2._ee17a8f9adb1("teacher_conf_mean", 0.0))

        self._0d21a08014b3(
            _0d21a08014b3,
            _e72bb4450fa6=_e72bb4450fa6,
            _37b3569c7ca3=_00db95800c16,
            _77ac50a40ba1=_fef3663a10ca,
            _93fb18c609a2=_00db95800c16,
            _e24767457426=_fef3663a10ca,
            _7ed81678c7bf=_fef3663a10ca,
        )

        # build preds and labels per example (preserve your previous behavior)
        _7b835352a47d = []
        _c8bd7635e2bf = []
        for _2ba727c12923 in _9fd4a891ab02(_e72bb4450fa6):
            _06f0688fbfc3 = _6e683451f42b[_2ba727c12923]
            _dcfb0ce4ffd0 = _d071bc722c8f[_2ba727c12923]
            _5f6d0676567b = _695804038798._01914d704e6d(_06f0688fbfc3, _04eff1e6b0a8=-1)
            _ef079e3ffabb = _dcfb0ce4ffd0
            _7b835352a47d._765710c831c0(_5f6d0676567b)
            _c8bd7635e2bf._765710c831c0(_ef079e3ffabb)

        _845dc65326eb = {
            "lang_codes": _ab1e690a4f78,
            "preds": _7b835352a47d,
            "labels": _c8bd7635e2bf,
            "sample_ids": _3ad9173bcd40,
            "chunk_ids": _b5cdf8575f9a,
            "word_positions": _ab28754a0336,
            "val_loss": _ccc48a599b79,
            "prompt_lens": _68c27b7cccd4,
            "num_chunks": _0459261051bf,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._27be6ccb9a01._765710c831c0(_845dc65326eb)

        # explicit frees (same as you had)
        del _fdc136a55819, _d071bc722c8f, _6e683451f42b, _15748bace7fa, _e5e09d90ec45, _7133284c1981, _682b6eb8a935
        del _4a1a7ea20d54, _eac13f159783, _7f22039a8ec9, _7b835352a47d, _c8bd7635e2bf

        return _845dc65326eb


    def _65a901f927fd(self, _c2ce55ba3956, _5c967d8c536f, _6ec473af9373=_e0333a685467):
        _f4855dcafd05 = os._3389293bac21()
        _17a1647dd4c3 = f"trial_{_6ec473af9373}" if _6ec473af9373 is not _e0333a685467 else "default"
        _d192e8d79307(f"[DEBUG rank={_695804038798._3026e486704c._bd3516a6122a() if _695804038798._3026e486704c._5a7bdaccbe1a() else 0}] metrics_dict confusion_matrix sum={_ad8403b227c0(_ad8403b227c0(_77960e534b97) for _77960e534b97 in _c2ce55ba3956['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _460027720314 = os._449ff728c369._8eb41a7dcb1b(_f4855dcafd05, "metrics", self._64ce717c7c18,  _17a1647dd4c3)
        os._16370a5eb439(_460027720314, _f8e516c76880=_fef3663a10ca)
        _3d98591ea802 = os._449ff728c369._8eb41a7dcb1b(_460027720314, _5c967d8c536f)
        _5fae55c8d83d = _f40144ab4f1a._52e15dd380d6(_c2ce55ba3956)
        _5fae55c8d83d._0f78663471c7(_3d98591ea802, _aaee8193fc66=_00db95800c16)
        _d192e8d79307(f"[metrics] Saved {_3d98591ea802}")

    def _f29159cb9478(self):
        # pick correct device for this rank
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            if _695804038798._3026e486704c._5a7bdaccbe1a():
                _5b9f70c96f9e = _695804038798._3026e486704c._bd3516a6122a()
            else:
                _5b9f70c96f9e = 0
            _695804038798._1d9613fc3f23._706ef28d3c19(_5b9f70c96f9e)
            self._5287239c7dc4 = _695804038798._1dd26ca682a8(f"cuda:{_5b9f70c96f9e}")
        else:
            self._5287239c7dc4 = _695804038798._1dd26ca682a8("cpu")

        self._6a91e592d50f()

    def _33db9713d07a(self):
        _6e683451f42b = _0191bec34475(self, "_validation_outputs", _e0333a685467)
        if not _6e683451f42b:
            return

        _a0b477718949, _85ec789efe1d, _ee5e17e3bcff, _1bb73bbe7fbf = \
            self._ea4bdc019c3e(_6e683451f42b)

        _0ba0b8019542, _a0cde5fd7a5d = [], []
        for _3d5d7a2a0058 in _384696953e78(_ee5e17e3bcff._a33c4a2af409()):
            _4b372a58bfac = _a0b477718949[_3d5d7a2a0058]._71c57657d0aa()
            _6cdb34a34d96 = _85ec789efe1d[_3d5d7a2a0058]._71c57657d0aa()
            _c41de4e42bfc = _ee5e17e3bcff[_3d5d7a2a0058]
            _7271ae8017b5 = _1bb73bbe7fbf[_3d5d7a2a0058]
            if _c41de4e42bfc._194ba60d6904() > 0 and _7271ae8017b5._194ba60d6904() > 0:
                _0ba0b8019542._765710c831c0(_c41de4e42bfc)
                _a0cde5fd7a5d._765710c831c0(_7271ae8017b5)

        if not _0ba0b8019542:
            _d192e8d79307("[VAL END] Nothing to score.")
            self._27be6ccb9a01._d173a9a00418()
            return

        _eda4fef15499 = _695804038798._4bc3ebc6f5c6(_0ba0b8019542)._5f3fa46da332(_1dd26ca682a8=self._94f6591e624c['micro_accuracy']._1dd26ca682a8, _32f1501ecd4c=_fef3663a10ca)
        _d071bc722c8f = _695804038798._4bc3ebc6f5c6(_a0cde5fd7a5d)._5f3fa46da332(_1dd26ca682a8=self._94f6591e624c['micro_accuracy']._1dd26ca682a8, _32f1501ecd4c=_fef3663a10ca)

        self._94f6591e624c['micro_accuracy']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_accuracy']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_precision']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_recall']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_f1']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_accuracy']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_precision']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_recall']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_f1']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['confmat']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)

        _8af29a604ba5  = self._94f6591e624c['micro_accuracy']._513057efbc27()._eca40a7b2f6b()
        _5f6c5cb9715c  = self._94f6591e624c['macro_accuracy']._513057efbc27()._eca40a7b2f6b()
        _3d401257ed9a = self._94f6591e624c['macro_precision']._513057efbc27()._eca40a7b2f6b()
        _60eccae5d27b    = self._94f6591e624c['macro_recall']._513057efbc27()._eca40a7b2f6b()
        _30070ded29d5        = self._94f6591e624c['macro_f1']._513057efbc27()._eca40a7b2f6b()

        self._4a08bb457c69("val_accuracy", _5f6c5cb9715c, _7ed81678c7bf=_fef3663a10ca)

        try:
            _12740638992a = self._aaea460ac15e
            _c2ce55ba3956 = {
                "epoch": [_12740638992a],
                "class_names": [self._6e30692cd2d8],
                "micro_accuracy": [_8af29a604ba5],
                "macro_accuracy": [_5f6c5cb9715c],
                "macro_precision": [_3d401257ed9a],
                "macro_recall": [_60eccae5d27b],
                "macro_f1": [_30070ded29d5],
                "classwise_accuracy": [self._94f6591e624c['classwise_accuracy']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "classwise_precision": [self._94f6591e624c['classwise_precision']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "classwise_recall": [self._94f6591e624c['classwise_recall']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "classwise_f1": [self._94f6591e624c['classwise_f1']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "confusion_matrix": [self._94f6591e624c['confmat']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
            }
            self._4b5f2872f5a4(_c2ce55ba3956, f"val_epoch_{_12740638992a}.csv", _6ec473af9373=self._6ec473af9373)
        except _41ce0cfcb8f4 as _6e4a9e5cea80:
            _d192e8d79307(f"[VAL END] save metrics FAILED: {_6e4a9e5cea80}")

        # cleanup
        self._94f6591e624c['micro_accuracy']._9e172c518cec(); self._94f6591e624c['macro_accuracy']._9e172c518cec()
        self._94f6591e624c['macro_precision']._9e172c518cec(); self._94f6591e624c['macro_recall']._9e172c518cec(); self._94f6591e624c['macro_f1']._9e172c518cec()
        self._94f6591e624c['classwise_accuracy']._9e172c518cec(); self._94f6591e624c['classwise_precision']._9e172c518cec()
        self._94f6591e624c['classwise_recall']._9e172c518cec(); self._94f6591e624c['classwise_f1']._9e172c518cec()
        self._94f6591e624c['confmat']._9e172c518cec(); self._27be6ccb9a01._d173a9a00418()
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            _695804038798._1d9613fc3f23._858372616079()
        _d192e8d79307("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_695804038798._cdc7263698ee()
    def _64c424e58807(self, _fdc136a55819: _695804038798._39057bac7da9, **_239592e55864):
        _239592e55864._2767737d974f("pad_token_id", _e0333a685467)
        _239592e55864._2767737d974f("attention_mask", _e0333a685467)
        return self._566fcaebbc0c._1a6d7a7a0a47(
            _fdc136a55819=_fdc136a55819,
            _2d9db20b0e02=(_fdc136a55819 != self._327973829216._8c77d72a456c),
            _8c77d72a456c=self._327973829216._8c77d72a456c,
            _bc7f71adc0ea=self._327973829216._bc7f71adc0ea,
            **_239592e55864
        )

    def _a9c2cc5f1cff(self, _1b1d07cf35cc, _4f971abd14a9):
        _fdc136a55819 = _1b1d07cf35cc["input_ids"]._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)
        _d071bc722c8f    = _1b1d07cf35cc["labels"]._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)
        _ab1e690a4f78     = _1b1d07cf35cc._ee17a8f9adb1("lang_codes", _e0333a685467)
        _3ad9173bcd40     = _1b1d07cf35cc._ee17a8f9adb1("sample_ids", _e0333a685467)
        _b5cdf8575f9a      = _1b1d07cf35cc._ee17a8f9adb1("chunk_ids", _e0333a685467)
        _ab28754a0336 = _1b1d07cf35cc._ee17a8f9adb1("word_positions", _e0333a685467)
        _68c27b7cccd4    = _1b1d07cf35cc._ee17a8f9adb1("prompt_lens", _e0333a685467)
        _0459261051bf = _1b1d07cf35cc._ee17a8f9adb1("num_chunks", _e0333a685467)

        _e72bb4450fa6 = _fdc136a55819._12d5cc68a327(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _b98db3071588 = self._1a6d7a7a0a47(
            _fdc136a55819,
            _714e4842a24a=32,
            _0319dbf7c7ae=_00db95800c16,
            _4ba4b455f1fc=_e0333a685467,     # for deterministic answers
            _db33139787a8=_e0333a685467,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _7b835352a47d = []
        _c8bd7635e2bf = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _2ba727c12923 in _9fd4a891ab02(_e72bb4450fa6):
            _7b835352a47d._765710c831c0(_b98db3071588[_2ba727c12923])   # FULL sequence
            _c8bd7635e2bf._765710c831c0(_d071bc722c8f[_2ba727c12923])          # FULL labels


        _845dc65326eb = {
            "lang_codes": _ab1e690a4f78,
            "preds": _7b835352a47d,
            "labels": _c8bd7635e2bf,
            "sample_ids": _3ad9173bcd40,
            "chunk_ids": _b5cdf8575f9a,
            "word_positions": _ab28754a0336,
            "prompt_lens": _68c27b7cccd4,
            "num_chunks": _0459261051bf,
        }

        self._9ba8a73bccf4._765710c831c0(_845dc65326eb)

        # Exact same cleanup as before
        del _fdc136a55819, _d071bc722c8f, _b98db3071588, _7b835352a47d, _c8bd7635e2bf

        return _845dc65326eb

    def _0df3603454f6(self):
        # pick correct device for this rank
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            if _695804038798._3026e486704c._5a7bdaccbe1a():
                _5b9f70c96f9e = _695804038798._3026e486704c._bd3516a6122a()
            else:
                _5b9f70c96f9e = 0
            _695804038798._1d9613fc3f23._706ef28d3c19(_5b9f70c96f9e)
            self._5287239c7dc4 = _695804038798._1dd26ca682a8(f"cuda:{_5b9f70c96f9e}")
        else:
            self._5287239c7dc4 = _695804038798._1dd26ca682a8("cpu")

        self._6a91e592d50f()
        
    def _eb332b77eaa8(self):
        _6e683451f42b = _0191bec34475(self, "_test_outputs", _e0333a685467)
        _d192e8d79307(f"[DEBUG rank={_695804038798._3026e486704c._bd3516a6122a()}] outputs_len={_5c56c98d45d2(_6e683451f42b)}")
        if not _6e683451f42b:
            return

        _a0b477718949, _85ec789efe1d, _ee5e17e3bcff, _1bb73bbe7fbf = \
            self._ea4bdc019c3e(_6e683451f42b)

        _0ba0b8019542, _a0cde5fd7a5d = [], []
        for _3d5d7a2a0058 in _384696953e78(_ee5e17e3bcff._a33c4a2af409()):
            _4b372a58bfac = _a0b477718949[_3d5d7a2a0058]._71c57657d0aa()
            _6cdb34a34d96 = _85ec789efe1d[_3d5d7a2a0058]._71c57657d0aa()
            _c41de4e42bfc = _ee5e17e3bcff[_3d5d7a2a0058]
            _7271ae8017b5 = _1bb73bbe7fbf[_3d5d7a2a0058]

            if _c41de4e42bfc._194ba60d6904() > 0 and _7271ae8017b5._194ba60d6904() > 0:
                _0ba0b8019542._765710c831c0(_c41de4e42bfc)
                _a0cde5fd7a5d._765710c831c0(_7271ae8017b5)

        if not _0ba0b8019542:
            _d192e8d79307("[TEST END] Nothing to score.")
            self._27be6ccb9a01._d173a9a00418()
            return

        _eda4fef15499 = _695804038798._4bc3ebc6f5c6(_0ba0b8019542)._5f3fa46da332(_1dd26ca682a8=self._94f6591e624c['micro_accuracy']._1dd26ca682a8, _32f1501ecd4c=_fef3663a10ca)
        _d071bc722c8f = _695804038798._4bc3ebc6f5c6(_a0cde5fd7a5d)._5f3fa46da332(_1dd26ca682a8=self._94f6591e624c['micro_accuracy']._1dd26ca682a8, _32f1501ecd4c=_fef3663a10ca)

        self._94f6591e624c['micro_accuracy']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_accuracy']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_precision']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_recall']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['macro_f1']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_accuracy']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_precision']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_recall']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['classwise_f1']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)
        self._94f6591e624c['confmat']._dc7dad0b7c59(_eda4fef15499, _d071bc722c8f)

        _8af29a604ba5  = self._94f6591e624c['micro_accuracy']._513057efbc27()._eca40a7b2f6b()
        _5f6c5cb9715c  = self._94f6591e624c['macro_accuracy']._513057efbc27()._eca40a7b2f6b()
        _3d401257ed9a = self._94f6591e624c['macro_precision']._513057efbc27()._eca40a7b2f6b()
        _60eccae5d27b    = self._94f6591e624c['macro_recall']._513057efbc27()._eca40a7b2f6b()
        _30070ded29d5        = self._94f6591e624c['macro_f1']._513057efbc27()._eca40a7b2f6b()

        self._4a08bb457c69("test_accuracy", _5f6c5cb9715c, _7ed81678c7bf=_fef3663a10ca)

        try:
            _12740638992a = self._aaea460ac15e
            _c2ce55ba3956 = {
                "epoch": [_12740638992a],
                "class_names": [self._6e30692cd2d8],
                "micro_accuracy": [_8af29a604ba5],
                "macro_accuracy": [_5f6c5cb9715c],
                "macro_precision": [_3d401257ed9a],
                "macro_recall": [_60eccae5d27b],
                "macro_f1": [_30070ded29d5],
                "classwise_accuracy": [self._94f6591e624c['classwise_accuracy']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "classwise_precision": [self._94f6591e624c['classwise_precision']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "classwise_recall": [self._94f6591e624c['classwise_recall']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "classwise_f1": [self._94f6591e624c['classwise_f1']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
                "confusion_matrix": [self._94f6591e624c['confmat']._513057efbc27()._5f3fa46da332(_1dd26ca682a8="cpu")._749cc7313116()._71c57657d0aa()],
            }
            self._4b5f2872f5a4(_c2ce55ba3956, f"test_final.csv", _6ec473af9373=self._6ec473af9373)
        except _41ce0cfcb8f4 as _6e4a9e5cea80:
            _d192e8d79307(f"[TEST END] save metrics FAILED: {_6e4a9e5cea80}")

        # cleanup
        self._94f6591e624c['micro_accuracy']._9e172c518cec(); self._94f6591e624c['macro_accuracy']._9e172c518cec()
        self._94f6591e624c['macro_precision']._9e172c518cec(); self._94f6591e624c['macro_recall']._9e172c518cec(); self._94f6591e624c['macro_f1']._9e172c518cec()
        self._94f6591e624c['classwise_accuracy']._9e172c518cec(); self._94f6591e624c['classwise_precision']._9e172c518cec()
        self._94f6591e624c['classwise_recall']._9e172c518cec(); self._94f6591e624c['classwise_f1']._9e172c518cec()
        self._94f6591e624c['confmat']._9e172c518cec(); self._27be6ccb9a01._d173a9a00418()
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            _695804038798._1d9613fc3f23._858372616079()
        _d192e8d79307("[TEST END] Finished and cleaned up.")

    def _174d99530597(self, _1b1d07cf35cc, _4f971abd14a9, _df7724ca356e=0):
        """Optimized prediction step with efficient memory handling."""
        _fdc136a55819, _ = _1b1d07cf35cc
        _fdc136a55819 = _fdc136a55819._5f3fa46da332(self._5287239c7dc4, _32f1501ecd4c=_fef3663a10ca)
        _6e683451f42b, _, _ = self(_fdc136a55819)
        _4911d548a600 = _695804038798._01914d704e6d(_6e683451f42b, _04eff1e6b0a8=-1)
        del _fdc136a55819, _6e683451f42b
        if _695804038798._1d9613fc3f23._e67af70ab23b():
            _695804038798._1d9613fc3f23._858372616079()
        return {"predictions": _4911d548a600._764f9e2c1112()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _a549667e64a9(self, _c04a7a4a1059, _08cfe0e250f4):
        # if sep token not present then just tuple the tokens and return
        if _08cfe0e250f4 is _e0333a685467:
            return [(_13abad27e54c,) for _13abad27e54c in _c04a7a4a1059]

        _8accb048338f = []
        _9b67758960ef = []

        for _13abad27e54c in _c04a7a4a1059:
            if _13abad27e54c == _08cfe0e250f4:
                if _9b67758960ef:
                    _8accb048338f._765710c831c0(_f706a0f2318b(_9b67758960ef))
                    _9b67758960ef = []
            else:
                if _08cfe0e250f4 == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _13abad27e54c in _9b67758960ef:
                        continue
                    else:
                        _9b67758960ef._765710c831c0(_13abad27e54c)
                    
                else:
                    _9b67758960ef._765710c831c0(_13abad27e54c)

        if _9b67758960ef:
            _8accb048338f._765710c831c0(_f706a0f2318b(_9b67758960ef))

        return _8accb048338f

    def _da1d77538bfc(self, _81cba6e5b087, _19b9575d9fe5="exact_match", _d6eafb3f9290=_e0333a685467):
        if not _81cba6e5b087:
            return _d6eafb3f9290

        if _19b9575d9fe5 == "exact_match":
            return _81cba6e5b087[0] if _84c17ceaa40c(_760d895b0c61 == _81cba6e5b087[0] for _760d895b0c61 in _81cba6e5b087) else _d6eafb3f9290

        if _19b9575d9fe5 == "most_common":
            return _94f1e44ed1f2(_81cba6e5b087)._92808979b67e(1)[0][0]

        if _19b9575d9fe5 == "first":
            return _81cba6e5b087[0]

        raise _4d596c577632(f"Unknown vote mode: {_19b9575d9fe5}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _b0bf8c4a835d(self, _6e683451f42b, _3eb8989d7bba=_fef3663a10ca, _1509b822c078="cpu"):
        from collections import _0fef6e80ccdb
        import _695804038798

        _e80c6b9011f9 = self._8cf23bf6cc15
        _08cfe0e250f4 = self._1c86a99db69c
        _8eee0fbf5327 = self._d67c41ad276d

        def _5d31ba1ec09d(_c1fad5b1c343):
            if _7e127e0d68c4(_c1fad5b1c343, _695804038798._39057bac7da9):
                return _c1fad5b1c343._7fb8965f23fc()._5f3fa46da332(_1dd26ca682a8=_1509b822c078)._f4cfba58f3ca(-1)._71c57657d0aa()
            return _0b9494aecdc5(_c1fad5b1c343) if _7e127e0d68c4(_c1fad5b1c343, (_0b9494aecdc5, _f706a0f2318b)) else [_c1fad5b1c343]

        _4ffe6bd7e1e3 = _17a2b76022ee()
        _002979106ad5 = _0fef6e80ccdb(_0b9494aecdc5)
        _afd0358d4622 = _0fef6e80ccdb(_9756b51a9090)
        _3e93ca772158 = []

        if _3eb8989d7bba:
            _d192e8d79307(f"[reconcile] start: num_outputs={_5c56c98d45d2(_6e683451f42b)}")

        for _0175f23bdade in _6e683451f42b:
            _3ad9173bcd40 = _0175f23bdade["sample_ids"]
            _b5cdf8575f9a = _0175f23bdade["chunk_ids"]
            _e8fccfb20a4b = _0175f23bdade["preds"]
            _b0ae5a602107 = _0175f23bdade["labels"]
            _ab28754a0336 = _0175f23bdade["word_positions"]
            _68c27b7cccd4 = _0175f23bdade["prompt_lens"]
            _bdf8210311df = _0175f23bdade["num_chunks"]

            for _2ba727c12923, _3d5d7a2a0058 in _12054a007492(_3ad9173bcd40):
                _de964870ee3b = _9756b51a9090(_b5cdf8575f9a[_2ba727c12923])
                if (_3d5d7a2a0058, _de964870ee3b) in _4ffe6bd7e1e3:
                    continue
                _4ffe6bd7e1e3._b14d409bf536((_3d5d7a2a0058, _de964870ee3b))

                _afd0358d4622[_3d5d7a2a0058] = _9756b51a9090(_bdf8210311df[_2ba727c12923])
                _150a19046aca = _9756b51a9090(_68c27b7cccd4[_2ba727c12923])
                _47c5008c74ce = _5e2811cffe52(_ab28754a0336[_2ba727c12923])
                _66e5f017a954 = _5e2811cffe52(_e8fccfb20a4b[_2ba727c12923])[_150a19046aca:]
                _8ec0c54658d3 = _5e2811cffe52(_b0ae5a602107[_2ba727c12923])[_150a19046aca:]

                _5fa88034a07e = [_4e0a0e10f4e3 for _4e0a0e10f4e3 in _66e5f017a954 if _4e0a0e10f4e3 != _e80c6b9011f9]
                _14c012f78060 = [_2a3fd697e1d6 for _2a3fd697e1d6 in _8ec0c54658d3 if _2a3fd697e1d6 != _e80c6b9011f9]

                if _3d5d7a2a0058 not in _3e93ca772158:
                    _3e93ca772158._765710c831c0(_3d5d7a2a0058)

                _002979106ad5[_3d5d7a2a0058]._765710c831c0((_de964870ee3b, _47c5008c74ce, _5fa88034a07e, _14c012f78060))

        _0cd23a249874 = _e0333a685467
        _a0b477718949 = {}
        _85ec789efe1d = {}

        for _3d5d7a2a0058 in _3e93ca772158:
            _fe0be828717d = _002979106ad5[_3d5d7a2a0058]
            if _5c56c98d45d2(_fe0be828717d) != _afd0358d4622[_3d5d7a2a0058]:
                if _3eb8989d7bba:
                    _d192e8d79307(f"Skipping sample {_3d5d7a2a0058}: expected {_afd0358d4622[_3d5d7a2a0058]} chunks, got {_5c56c98d45d2(_fe0be828717d)}")
                continue

            _fe0be828717d._48f10eee2fbc(_bb8c72362da3=lambda _c1fad5b1c343: _c1fad5b1c343[0])

            if _0cd23a249874 is _e0333a685467 and _5c56c98d45d2(_fe0be828717d) > 1:
                _0cd23a249874 = _3d5d7a2a0058

            # Split into words
            _2544d6bf912f = []
            for _de964870ee3b, _4f358b375a23, _6555b29b73d6, _df71ab92f892 in _fe0be828717d:
                _e7e608f38de5 = self._c78273ea0cac(_4f358b375a23, -1)
                _4e3b35441e15 = self._c78273ea0cac(_6555b29b73d6, _08cfe0e250f4)
                _a65fa95da412 = self._c78273ea0cac(_df71ab92f892, _08cfe0e250f4)
                _6ca00eed6ac1 = _5c56c98d45d2(_e7e608f38de5)
                if _5c56c98d45d2(_4e3b35441e15) < _6ca00eed6ac1:
                    _4e3b35441e15 += [(_8eee0fbf5327,)] * (_6ca00eed6ac1 - _5c56c98d45d2(_4e3b35441e15))
                if _5c56c98d45d2(_a65fa95da412) < _6ca00eed6ac1:
                    _a65fa95da412 += [(_e80c6b9011f9,)] * (_6ca00eed6ac1 - _5c56c98d45d2(_a65fa95da412))
                _2544d6bf912f._765710c831c0((_e7e608f38de5, _4e3b35441e15, _a65fa95da412))

            # Vote per word position
            _bd1209f72430 = _0fef6e80ccdb(_0b9494aecdc5)
            _58bda821e7dd = _0fef6e80ccdb(_0b9494aecdc5)
            for _e7e608f38de5, _4e3b35441e15, _a65fa95da412 in _2544d6bf912f:
                for _6c7a210123d6, _54f7f6988970, _73dc76b5eaed in _c32a2a37b85c(_e7e608f38de5, _4e3b35441e15, _a65fa95da412):
                    _4f358b375a23 = _6c7a210123d6[0]
                    _bd1209f72430[_4f358b375a23]._765710c831c0(_54f7f6988970)
                    _58bda821e7dd[_4f358b375a23]._765710c831c0(_73dc76b5eaed)

            _8565738c8e9b = _384696953e78(_bd1209f72430._a33c4a2af409())

            _14b956369616 = [self._40d11f5f0516(_bd1209f72430[_4e0a0e10f4e3], _19b9575d9fe5="exact_match", _d6eafb3f9290=(_8eee0fbf5327,)) for _4e0a0e10f4e3 in _8565738c8e9b]
            _90895c3ca0fa = []
            for _4e0a0e10f4e3 in _8565738c8e9b:
                _9a8ac6d4dc59 = _58bda821e7dd[_4e0a0e10f4e3]
                _49ae677d81c1 = self._40d11f5f0516(_9a8ac6d4dc59, _19b9575d9fe5="exact_match", _d6eafb3f9290=_e0333a685467)
                if _49ae677d81c1 is _e0333a685467:
                    for _47a69cff3206 in _9a8ac6d4dc59:
                        if _e80c6b9011f9 not in _47a69cff3206:
                            _49ae677d81c1 = _47a69cff3206
                            break
                    if _49ae677d81c1 is _e0333a685467:
                        _49ae677d81c1 = _9a8ac6d4dc59[0]
                _90895c3ca0fa._765710c831c0(_49ae677d81c1)

            # Reconstruct
            _5eb1661758ce = []
            _c692a146384a = []
            for _2ba727c12923 in _9fd4a891ab02(_5c56c98d45d2(_8565738c8e9b)):
                _5eb1661758ce._0f4457476acc(_14b956369616[_2ba727c12923])
                _c692a146384a._0f4457476acc(_90895c3ca0fa[_2ba727c12923])
                if _2ba727c12923 < _5c56c98d45d2(_8565738c8e9b) - 1:
                    _5eb1661758ce._765710c831c0(_08cfe0e250f4)
                    _c692a146384a._765710c831c0(_08cfe0e250f4)

            _d192e8d79307(f"check labels final {(_ad8403b227c0(1 for _c1fad5b1c343 in _c692a146384a if _c1fad5b1c343 == _08cfe0e250f4))}")

            _a0b477718949[_3d5d7a2a0058] = _695804038798._ea1185bc1fb5(_5eb1661758ce, _1dd26ca682a8=_1509b822c078)
            _85ec789efe1d[_3d5d7a2a0058] = _695804038798._ea1185bc1fb5(_c692a146384a, _1dd26ca682a8=_1509b822c078)

        if _3eb8989d7bba and _0cd23a249874 is not _e0333a685467:
            _d192e8d79307(f"[SUMMARY] reconciled samples in batch = {_5c56c98d45d2(_3e93ca772158)} "
                f"sid={_0cd23a249874} total_preds={_5c56c98d45d2(_a0b477718949[_0cd23a249874])} "
                f"total_labels={_5c56c98d45d2(_85ec789efe1d[_0cd23a249874])} "
                f"raw_preds {_a0b477718949[_0cd23a249874]} and raw_labels {_85ec789efe1d[_0cd23a249874]} "
                f"chunks {_002979106ad5[_0cd23a249874]}")

        _452bf5bc9f24 = _ad8403b227c0(_5c56c98d45d2(_2a3fd697e1d6) for _2a3fd697e1d6 in _85ec789efe1d._81cba6e5b087())
        _d192e8d79307(f"Total reconciled labels: {_452bf5bc9f24}")

        _cde71f888045, _73e24e3fecc9 = self._d53f3a90bc38(
            _a0b477718949, _85ec789efe1d, _3eb8989d7bba=_3eb8989d7bba, _1509b822c078=_1509b822c078
        )
        _29009b902739 = _ad8403b227c0(_5c56c98d45d2(_2a3fd697e1d6) for _2a3fd697e1d6 in _73e24e3fecc9._81cba6e5b087())
        _d192e8d79307(f"Total reconciled labels classes: {_29009b902739}")

        _c5d8d3375ea1 = _695804038798._3026e486704c._bd3516a6122a() if _695804038798._3026e486704c._5a7bdaccbe1a() else -1
        _d192e8d79307(f"Rank {_c5d8d3375ea1} samples are {_3e93ca772158}")

        return _a0b477718949, _85ec789efe1d, _cde71f888045, _73e24e3fecc9

    def _13afe9e9a6be(self, _a0b477718949, _85ec789efe1d, _3eb8989d7bba=_fef3663a10ca, _1509b822c078="cpu"):
        _82738ddecee1 = _0191bec34475(self, "seq2class", {})
        _08cfe0e250f4 = _0191bec34475(self, "tokenizer_separator_token", _e0333a685467)
        _e80c6b9011f9 = _0191bec34475(self, "ignore_idx", -100)
        
        def _c5aeb913a64c(_c04a7a4a1059, _07689ae12b86):
            _8accb048338f = []
            _1448c5c17539 = []
            for _2ba727c12923, token in _12054a007492(_c04a7a4a1059):
                if token == _07689ae12b86 and _1448c5c17539:
                    _8accb048338f._765710c831c0(_1448c5c17539)
                    _1448c5c17539 = []
                elif token != _07689ae12b86:
                    _1448c5c17539._765710c831c0(token)
            if _1448c5c17539:
                _8accb048338f._765710c831c0(_1448c5c17539)
            return _8accb048338f
        
        def _785d74414eff(_2d6eee87330d, _82738ddecee1, _3eb8989d7bba, _3d5d7a2a0058):
            _0175f23bdade = []
            _070dede20f99 = _384696953e78(_82738ddecee1._a33c4a2af409(), _bb8c72362da3=_5c56c98d45d2, _efa410b99695=_fef3663a10ca)
            for _2ba727c12923, _efde139c0b69 in _12054a007492(_2d6eee87330d, 1):
                _bcb8cf730d32 = _f706a0f2318b(_efde139c0b69)
                _4fd452e42ddc = self._d67c41ad276d
                for _bb8c72362da3 in _070dede20f99:
                    if _5c56c98d45d2(_bcb8cf730d32) >= _5c56c98d45d2(_bb8c72362da3) and _bcb8cf730d32[:_5c56c98d45d2(_bb8c72362da3)] == _bb8c72362da3:
                        _4fd452e42ddc = _82738ddecee1[_bb8c72362da3]
                        break
                _0175f23bdade._765710c831c0(_4fd452e42ddc)

            return _0175f23bdade
        
        _ee5e17e3bcff, _1bb73bbe7fbf = {}, {}
        for _3d5d7a2a0058 in _a0b477718949:
            _4e0a0e10f4e3 = _a0b477718949[_3d5d7a2a0058]
            _2a3fd697e1d6 = _85ec789efe1d._ee17a8f9adb1(_3d5d7a2a0058, _e0333a685467)
            _eda4fef15499 = _4e0a0e10f4e3._71c57657d0aa() if _7e127e0d68c4(_4e0a0e10f4e3, _695804038798._39057bac7da9) else _0b9494aecdc5(_4e0a0e10f4e3)
            _d071bc722c8f = _2a3fd697e1d6._71c57657d0aa() if _7e127e0d68c4(_2a3fd697e1d6, _695804038798._39057bac7da9) else _0b9494aecdc5(_2a3fd697e1d6) if _2a3fd697e1d6 else _e0333a685467
            if _d071bc722c8f is not _e0333a685467:
                _a7d15a185bfb = _11968e36d963(_d071bc722c8f, _08cfe0e250f4)
                _de247101b0f3 = _e940b50b045e(_a7d15a185bfb, _82738ddecee1, _3d5d7a2a0058 == 1 or _3eb8989d7bba, _3d5d7a2a0058)
                _cb7699ef37cd = _11968e36d963(_eda4fef15499, _08cfe0e250f4)
                _9bcb60f8d68a = _e940b50b045e(_cb7699ef37cd, _82738ddecee1, _3d5d7a2a0058 == 1 or _3eb8989d7bba, _3d5d7a2a0058)
                if _5c56c98d45d2(_9bcb60f8d68a) < _5c56c98d45d2(_de247101b0f3):
                    _9bcb60f8d68a += [0] * (_5c56c98d45d2(_de247101b0f3) - _5c56c98d45d2(_9bcb60f8d68a))
                elif _5c56c98d45d2(_9bcb60f8d68a) > _5c56c98d45d2(_de247101b0f3):
                    _9bcb60f8d68a = _9bcb60f8d68a[:_5c56c98d45d2(_de247101b0f3)]
            else:
                _cb7699ef37cd = _11968e36d963(_eda4fef15499, _08cfe0e250f4)
                _9bcb60f8d68a = _e940b50b045e(_cb7699ef37cd, _82738ddecee1, _3d5d7a2a0058 == 1 or _3eb8989d7bba, _3d5d7a2a0058)
                _de247101b0f3 = [_e80c6b9011f9] * _5c56c98d45d2(_9bcb60f8d68a)
            _ee5e17e3bcff[_3d5d7a2a0058] = _695804038798._ea1185bc1fb5(_9bcb60f8d68a, _1dd26ca682a8=_1509b822c078, _9c4c79c0803c=_695804038798._6e1c5b6e9215)
            _1bb73bbe7fbf[_3d5d7a2a0058] = _695804038798._ea1185bc1fb5(_de247101b0f3, _1dd26ca682a8=_1509b822c078, _9c4c79c0803c=_695804038798._6e1c5b6e9215)
        return _ee5e17e3bcff, _1bb73bbe7fbf

    def _5fcf22b5f921(self, _43575df0dcb4):
        _695804038798._d99d914cb171._1fb632193a65._d5c83ba3a5da(self._777093f629b5(), _ce77c470c996=1.0)
    
    def _570abcb39400(self, _43575df0dcb4):
        for _f934dd0dddbd in self._777093f629b5():
            if _f934dd0dddbd is not _e0333a685467:
                _f934dd0dddbd._5bd3b2f42e53._e4db39f37950(-5, 5)

    def _5070a6cbc4f1(self):
        _8d363cb73622 = 0
        for _f934dd0dddbd in self._777093f629b5():
            if _f934dd0dddbd._09794549f5de is not _e0333a685467:
                _0f864dac03d1 = _f934dd0dddbd._09794549f5de._7fb8965f23fc()._5bd3b2f42e53._157c77ae7d86(2)
                _8d363cb73622 += _0f864dac03d1._eca40a7b2f6b() ** 2
        return _8d363cb73622 ** 0.5  # L2 norm

    def _b7af37a36b50(self):
        _7fecda3ff168 = [_4e0a0e10f4e3 for _4e0a0e10f4e3 in self._777093f629b5() if _4e0a0e10f4e3._dd63e72132ac]
        if not _7fecda3ff168:
            _d192e8d79307("No trainable parameters. Skipping optimizer creation.")
            return _e0333a685467
        
        _6881aac844bb = _e64dadc92623(lambda _4e0a0e10f4e3: _4e0a0e10f4e3._dd63e72132ac, self._777093f629b5())

        _b436bd90b66a = {
            "adamw": _695804038798._8ba42bb6b9c5._5c48b241b363,
            "adamax": _695804038798._8ba42bb6b9c5._ff6f0897a3c8,
            "adam": _695804038798._8ba42bb6b9c5._4cef9bfa9f1c,
        }
        _46cbb1528156 = _b436bd90b66a._ee17a8f9adb1(self._9952bc80a64a._17546d413436(), _695804038798._8ba42bb6b9c5._4cef9bfa9f1c)

        _43575df0dcb4 = _46cbb1528156(_6881aac844bb, _214b58612281=self._8d10e3058c59._214b58612281, _7a3c997fabe6=0.001)

        _097d11e6de65 = self._4e3895a8aa8d._21bbc9b2476e
        _ace3f0273c29 = math._8977829b2278(0.1 * _097d11e6de65)

        _857d55db159d = _695804038798._8ba42bb6b9c5._7d0d267ad49c._ae7f52722791(_43575df0dcb4, _13ae030117e5=lambda _79e85cde11ac: (_79e85cde11ac + 1) / _ace3f0273c29)

        _e3397a06173d = _695804038798._8ba42bb6b9c5._7d0d267ad49c._d0b65aa7bd68(
            _43575df0dcb4,
            _e302c9b3831d=_801945e0cf62(1, _097d11e6de65 - _ace3f0273c29),
            _073e703012fe=2,
            _e85fda5d9787=1e-6
        )
        _7d0d267ad49c = _695804038798._8ba42bb6b9c5._7d0d267ad49c._a21e6da7d7a3(
            _43575df0dcb4,
            _751ccf7a2fdf=[_857d55db159d, _e3397a06173d],
            _c98ba35bfb3f=[_ace3f0273c29]
        )
        return {"optimizer": _43575df0dcb4, "lr_scheduler": {"scheduler": _7d0d267ad49c, "interval": "epoch", "monitor": "val_loss"}}
