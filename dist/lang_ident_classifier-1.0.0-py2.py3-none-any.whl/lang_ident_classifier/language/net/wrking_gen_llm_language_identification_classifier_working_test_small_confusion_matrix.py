# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _4f8899ab3d97, _a8b312d7f5dd
import copy
from _919fb8fafa5c import _9baa440cda33
import _70757aeca278
import math
import os
from typing import _ea09ef820e40
import _3e8df47d6a1d as _1eb8d8970a4e
import _e27598b676a4 as _d6ab597f8b72
import _f48500a0e01b
import _a9c2063c88ac as _27f5833490c1
from _b86cb9f35a73._ef967f64881a._13aa1624ba56._c8d49f769ef6 import _18e1b765b5ca
from _975c22f26cb7 import _0fed79331a27, _ebaa4aee494d, _fbb0749c0940, _d186e3789d6f, _ba2f2f7d7c7f

from _1bdde60a07fb._7adbf7c7b511._75be8b981fdd._175df7a4ac24 import _05135e3a4730
from _1bdde60a07fb._7adbf7c7b511._1262a422cc7b._1df7293e9607 import _8f419c3638cd
from _1bdde60a07fb._7adbf7c7b511._1262a422cc7b._483f7e8cc9a2 import _bfee1d27cce5
from _1bdde60a07fb._7adbf7c7b511._1262a422cc7b._1a6b56c6ab31 import _43bca72958c9
from _1bdde60a07fb._7adbf7c7b511._87ac4f75d94b._7f1b5c0694dc import _7f737a33484c
# expose only the classifier from the module
_6eed260065cc = ["GenLLMLanguageIdentificationClassifier"]

_88c7c5a0977a = 'cuda' if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4() else 'cpu'
_5199d6f690d2 = _fde062d49480  # global frozen embedding (kept for compatibility)

    
class _c79b5ef89ace(_27f5833490c1._dd50a23aafe7):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _30e8195332b0(_f48500a0e01b._a14f528d8ccf._a74395e05174):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _bbc7b2b5773a(self, _dd67473f1010: _178a6c94fe0f, _a0990a3c5f73: _178a6c94fe0f = 64):
            _2912a458494b()._2f956c1e2827()
            self._f1e3978b5804 = _f48500a0e01b._a14f528d8ccf._227687e4cf7d(_dd67473f1010, _a0990a3c5f73, _b35282db2b01=_3c15818fdba3)
            self._99d1db418dab = _f48500a0e01b._a14f528d8ccf._6124d5e51612(_282fc9edf26d=_25457baefff4)
            self._4daf86964352 = _f48500a0e01b._a14f528d8ccf._227687e4cf7d(_a0990a3c5f73, _dd67473f1010, _b35282db2b01=_3c15818fdba3)
            # start adapter near-zero so initial behavior is identity
            _f48500a0e01b._a14f528d8ccf._afed471a8b07._3488a0788419(self._4daf86964352._dab02d1a5297)
            _f48500a0e01b._a14f528d8ccf._afed471a8b07._7e4ed912740e(self._f1e3978b5804._dab02d1a5297, _109f6471ae9b=math._858246760d1a(5))

        def _bd31164236c9(self, _60b1b4282fd0: _f48500a0e01b._531c31acec9b) -> _f48500a0e01b._531c31acec9b:
            # supports x shape (B, L, D) or (B, D)
            if _60b1b4282fd0._dd67473f1010() == 2:
                _234bce52b3a5 = self._4daf86964352(self._99d1db418dab(self._f1e3978b5804(_60b1b4282fd0)))
                return _60b1b4282fd0 + _234bce52b3a5
            _3c53a148e6f6, _a15d9df024d6, _f6ac06466786 = _60b1b4282fd0._f5aeccbe46bd
            _55593a613b6b = _60b1b4282fd0._e4b2e263678c(-1, _f6ac06466786)                    # (B*L, D)
            _55593a613b6b = self._4daf86964352(self._99d1db418dab(self._f1e3978b5804(_55593a613b6b)))  # (B*L, D)
            _55593a613b6b = _55593a613b6b._e4b2e263678c(_3c53a148e6f6, _a15d9df024d6, _f6ac06466786)
            return _60b1b4282fd0 + _55593a613b6b
        
    class _da60b3e1c51b(_f48500a0e01b._a14f528d8ccf._a74395e05174):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _bbc7b2b5773a(self, _50a51690fb56, _7e4117752be1=-5, _cba72bb56905=5):
            _2912a458494b()._2f956c1e2827()
            self._50a51690fb56 = _50a51690fb56
            self._7e4117752be1 = _7e4117752be1
            self._cba72bb56905 = _cba72bb56905
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _bd31164236c9(self, *_b21044eb339c, **_0942e0b9af63):
            _b21044eb339c = _7454e608213e(
                _8d21fb9b3f27._842c6ac46095(_f48500a0e01b._1a8e97e21ee2)._2d090ff63b63(-10, 10) if _4fdb8474d472(_8d21fb9b3f27, _f48500a0e01b._531c31acec9b) and _8d21fb9b3f27._6aaf82c98abb != _f48500a0e01b._1a8e97e21ee2 else _8d21fb9b3f27
                for _8d21fb9b3f27 in _b21044eb339c
            )
            for _5be39fe1c60f, _8d21fb9b3f27 in _7c49ec5c2553(_b21044eb339c):
                if _4fdb8474d472(_8d21fb9b3f27, _f48500a0e01b._531c31acec9b) and not _f48500a0e01b._bd5275220034(_8d21fb9b3f27)._6e86e9e05fcf():
                    _8d21fb9b3f27 = _f48500a0e01b._3d3f28c3dd9f(_8d21fb9b3f27)
            _825956188ba2 = self._50a51690fb56(*_b21044eb339c, **_0942e0b9af63)
            if _4fdb8474d472(_825956188ba2, _f48500a0e01b._531c31acec9b):
                _825956188ba2 = _825956188ba2._842c6ac46095(_f48500a0e01b._1a8e97e21ee2)
                if not _f48500a0e01b._bd5275220034(_825956188ba2)._6e86e9e05fcf():
                    _825956188ba2 = _f48500a0e01b._3d3f28c3dd9f(_825956188ba2)
                _825956188ba2._6d4f1642a059(self._7e4117752be1, self._cba72bb56905)
            return _825956188ba2

    # --- original __init__ signature and body preserved ---
    def _bbc7b2b5773a(
        self,
        _a886afa34e7e,
        _7f4a4f9face8,
        _22ff6f4e762c,
        _7c5aa5eeffd2,
        _65d367744136,
        _78f71c049420,
        _67d143ec8fd7,
        _b6af7963d0f7,
        _bbb22467dc4e,
        _399e7f31a58c,
        _ad3bbd058317,
        _f6415bebf48e: _178a6c94fe0f = 20,
        _9137728c40cf = _fde062d49480,
        _e2a085b4bfd8=_fde062d49480,
        _b9192b3d71a5=0.9,
        _e123cb273e4e:_f780e422c7b7=_fde062d49480,
    ):
        _2912a458494b(_8337ac5f33a0, self)._2f956c1e2827()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._badb009ca26e({
            "lr": _18b8dc998a1f(_22ff6f4e762c),
            "optimizer": _f780e422c7b7(_7c5aa5eeffd2),
            "num_backbone_model_units_unfrozen": _178a6c94fe0f(_67d143ec8fd7),
            "loss_type": _f780e422c7b7(_b6af7963d0f7),
            "is_train": _a944915e821f(_bbb22467dc4e),
            "random_seed": _178a6c94fe0f(_f6415bebf48e),
        })
        self._f6415bebf48e = _f6415bebf48e
        _27f5833490c1._4f7ff3045274(_f6415bebf48e, _3c78fcd73bc4=_25457baefff4)
        _f48500a0e01b._2a4df650fbf3(_f6415bebf48e)
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            _f48500a0e01b._6666d9d82aa0._ed7b5eb4add9(_f6415bebf48e)
        _1eb8d8970a4e.random._3a57d8dab3ea(_f6415bebf48e)
        self._e2a085b4bfd8 = _178a6c94fe0f(_e2a085b4bfd8) if _e2a085b4bfd8 is not _fde062d49480 else _fde062d49480
        self._399e7f31a58c = _399e7f31a58c
        self._e123cb273e4e = _e123cb273e4e
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._399e7f31a58c._5b83268b8173 and "<PAD>" not in self._399e7f31a58c._94019c34b3b3():
            self._399e7f31a58c._5c12f2a6f4ae(["<PAD>"], _f8b457197822=_3c15818fdba3)
            _a82229998ace = self._399e7f31a58c._2db1eb78c80a("<PAD>")
            _5c659c29e456(f"Added padding token  <PAD> with (id: {_a82229998ace})")
        
        self._aaf164a1e1f8 = _399e7f31a58c._29130a4ebafc(" ", _734de1726114=_3c15818fdba3)[0]
        self._e30e1b0d3067 = (
            _f48500a0e01b._d3734ee07a4d("cuda:{}"._028fafaf1fd2(_78f71c049420["gpu_local_rank"]))
            if _78f71c049420["gpu_local_rank"] != -1
            else "cpu"
        )
        self._9137728c40cf = _9137728c40cf
        self._b9192b3d71a5 = _b9192b3d71a5
        self._7f4a4f9face8 =  ["unk"] + _7f4a4f9face8 if self._b9192b3d71a5 > 0 else _7f4a4f9face8
        self._981ba6e7df88 = _41658cc59397(self._7f4a4f9face8)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._15955c1aafc3 = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _e99116700700 in self._7f4a4f9face8:
            if _41658cc59397(self._399e7f31a58c._29130a4ebafc(_e99116700700, _734de1726114=_3c15818fdba3)) > 1:
                token = f"{_e99116700700}"
                if token not in self._399e7f31a58c._94019c34b3b3():
                    self._399e7f31a58c._5c12f2a6f4ae([token], _f8b457197822=_3c15818fdba3)
                    _a82229998ace = self._399e7f31a58c._2db1eb78c80a(token)
                    _5c659c29e456(f"Added class '{_e99116700700}' Token: {token} (id: {_a82229998ace})")

        # Map every class to single token ID
        self._15955c1aafc3 = {
            _457627da46a6: [self._399e7f31a58c._2db1eb78c80a(f"{_e99116700700}")]
            for _457627da46a6, _e99116700700 in _7c49ec5c2553(self._7f4a4f9face8)
        }

        self._6e30ef406327 = {_7454e608213e(_aaf4d54a3a96): _d316a1677015 for _d316a1677015, _aaf4d54a3a96 in self._15955c1aafc3._d0442bfe0b51()}
        self._8e28d8a90da4 = _a8b312d7f5dd(_8fc3a34e211b)
        for _aedf27293efc, _aaf4d54a3a96 in self._15955c1aafc3._d0442bfe0b51():
            self._8e28d8a90da4[_41658cc59397(_aaf4d54a3a96)]._85cdac0b11ad((_aedf27293efc, _aaf4d54a3a96))
        self._d52481d7001d = 0
        _5c659c29e456(f"SEQ {self._15955c1aafc3} and {self._6e30ef406327}")
        self._378bd45f2e49 = _399e7f31a58c._5b83268b8173 or _399e7f31a58c._0399a9a3a6d2
        self._65d367744136 = _65d367744136
        self._a4d29c0df3ba = "multiclass"
        self._6a19ae9660de = -100
        self._c16f7fcd5345 = _399e7f31a58c._29130a4ebafc("assistant<|end_header_id|>\n\n", _734de1726114=_3c15818fdba3)
        self._45d9d3db12dc = self._6f3c3ef2b8dc()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._924347a5b2eb = _a886afa34e7e
        # Resize vocab based token embeddings
        self._924347a5b2eb._d458c28c9852(_41658cc59397(self._399e7f31a58c))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._924347a5b2eb._7f95988b9962(_3c15818fdba3)
        _180c5d0cb050 = _7f737a33484c()  # bfloat16 or float16

        for _a51529776a79, _50a51690fb56 in self._fa9ca6dfdd87():
            if not _56aed627b51c(_1c5f021ce483._6c479b5ca8d0 for _1c5f021ce483 in _50a51690fb56._535c9c383ae3(_7709e5842aec=_3c15818fdba3)):
                # FROZEN → BF16 (save memory)
                _50a51690fb56._842c6ac46095(_6aaf82c98abb=_180c5d0cb050)
            else:
                # TRAINABLE → FP32 (stable grads)
                _50a51690fb56._842c6ac46095(_6aaf82c98abb=_f48500a0e01b._1a8e97e21ee2)
        self._924347a5b2eb._842c6ac46095(self._e30e1b0d3067)
        if _19359d1f2465(self._924347a5b2eb, "gradient_checkpointing_enable"):
            self._924347a5b2eb._3b596987653a()
        # determine embedding dim robustly from model config if available
        _04832f1ae2b4 = _06e3dce2cc26(_06e3dce2cc26(self._924347a5b2eb, "config", _fde062d49480), "hidden_size", _fde062d49480)
        if _04832f1ae2b4 is _fde062d49480:
            # fallback to common default — change if your model uses a different hidden size
            _04832f1ae2b4 = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _19359d1f2465(self._924347a5b2eb, "lm_head") and _06e3dce2cc26(self._924347a5b2eb, "lm_head") is not _fde062d49480:
            self._0627d49243e3 = self._924347a5b2eb._0f0b2ad7691f
        else:
            _e533186d5f18 = _06e3dce2cc26(self._924347a5b2eb, "get_output_embeddings", _fde062d49480)
            self._0627d49243e3 = _e533186d5f18() if _cfbdd64a6d57(_e533186d5f18) else _fde062d49480

        # mark presence and ensure module (if any) is on the same device
        self._c0d9fbe2e3ad = self._0627d49243e3 is not _fde062d49480
        if self._c0d9fbe2e3ad:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._0627d49243e3._842c6ac46095(self._e30e1b0d3067)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._2b8f32004224 = self._c35ccfff33ab(_dd67473f1010=_04832f1ae2b4, _a0990a3c5f73=64)
        self._2b8f32004224._842c6ac46095(self._e30e1b0d3067)
        for _1c5f021ce483 in self._2b8f32004224._535c9c383ae3():
            _1c5f021ce483._6c479b5ca8d0 = _25457baefff4
            
        if _67d143ec8fd7 > 0:
            if "llama" in self._9137728c40cf:
                for _2be54c205a42 in self._924347a5b2eb._535c9c383ae3():
                    if not _2be54c205a42._aef9f69f6994:
                        _2be54c205a42 = _2be54c205a42._2520f732b87a()
                    _2be54c205a42._6c479b5ca8d0 = _3c15818fdba3  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _64e79b25c4e5 = self._924347a5b2eb._d6b404f8df9d._c22f1802660c  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _2c97c18b69c5 in _64e79b25c4e5[-_67d143ec8fd7:]:
                    for _2be54c205a42 in _2c97c18b69c5._535c9c383ae3():
                        if _4fdb8474d472(_2be54c205a42, _f48500a0e01b._531c31acec9b) and (_2be54c205a42._7f212a5f8bd2() or _f48500a0e01b._b7efe5da335d(_2be54c205a42)):
                            _2be54c205a42._6c479b5ca8d0 = _25457baefff4
                if _19359d1f2465(self._924347a5b2eb, "lm_head"):
                    self._924347a5b2eb._0f0b2ad7691f._6c479b5ca8d0 = _25457baefff4

        self._ef3647dfa1b8 = 1
        _5c659c29e456(f"DEBUG xth_batch init {self._ef3647dfa1b8}")
        global _5199d6f690d2
        _5199d6f690d2 = copy._bc01d6fb7737(self._924347a5b2eb)._bf286293bb7c()
        self._22ff6f4e762c = _22ff6f4e762c

        self._a0a8f128477a = {}
        self._28c03050ab35 = {}

        # Loss function initialization
        if _b6af7963d0f7._0445b8dd53ce() == "class_weighted_cross_entropy_loss":
            self._28c03050ab35['criterion'] = _bfee1d27cce5(_65d367744136=self._65d367744136,
                                                            _d3734ee07a4d=self._e30e1b0d3067,
                                                            _f88a6d77e3eb=self._6a19ae9660de,
                                                            _cee6001878d8=self._aaf164a1e1f8)
        elif _b6af7963d0f7._0445b8dd53ce() == "focal_loss":
            self._28c03050ab35['criterion'] = _43bca72958c9(_1a46dca7bdf8=0.25,
                                                     _d3734ee07a4d=self._e30e1b0d3067,
                                                     _f88a6d77e3eb=self._6a19ae9660de,
                                                     _cee6001878d8=self._aaf164a1e1f8)
        elif _b6af7963d0f7._0445b8dd53ce() == "class_weighted_focal_loss":
            self._28c03050ab35['criterion'] = _43bca72958c9(_1a46dca7bdf8=self._65d367744136,
                                                     _d3734ee07a4d=self._e30e1b0d3067,
                                                     _f88a6d77e3eb=self._6a19ae9660de,
                                                     _cee6001878d8=self._aaf164a1e1f8)
        elif _b6af7963d0f7._0445b8dd53ce() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._28c03050ab35['criterion'] = _8f419c3638cd(_1a46dca7bdf8=self._65d367744136,
                                                                      _86c395663dae='type1',
                                                                      _d3734ee07a4d=self._e30e1b0d3067,
                                                                      _f88a6d77e3eb=self._6a19ae9660de,
                                                                      _cee6001878d8=self._aaf164a1e1f8)
        elif _b6af7963d0f7._0445b8dd53ce() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._28c03050ab35['criterion'] = _8f419c3638cd(_1a46dca7bdf8=self._65d367744136,
                                                                      _86c395663dae='type2',
                                                                      _d3734ee07a4d=self._e30e1b0d3067,
                                                                      _f88a6d77e3eb=self._6a19ae9660de,
                                                                      _cee6001878d8=self._aaf164a1e1f8)
        elif _b6af7963d0f7._0445b8dd53ce() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._28c03050ab35['criterion'] = _8f419c3638cd(_1a46dca7bdf8=self._65d367744136,
                                                                      _86c395663dae='type3',
                                                                      _d3734ee07a4d=self._e30e1b0d3067,
                                                                      _f88a6d77e3eb=self._6a19ae9660de,
                                                                      _cee6001878d8=self._aaf164a1e1f8)
        else:
            self._28c03050ab35['criterion'] = _bfee1d27cce5(_d3734ee07a4d=self._e30e1b0d3067,
                                                            _f88a6d77e3eb=self._6a19ae9660de,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._d560aa16875f = 0.99
        self._057751f84c02 = 0.3
        self._b471d57bbe75 = 0.30
        self._cdef56f055fc = 0.25
        self._7f11d832a6c5 = 0.6
        self._3dae3421fddf = 0.995
        self._b5204397712f = 0.60
        self._6e5077e52848 = 0.20
        self._d43e3f0929d3 = _06e3dce2cc26(self, "batch_counter", 0)


        self._c4dccb4e4477 = []
        self._458028a0936f = []

        self._9e91e008c947 = _7c5aa5eeffd2._0445b8dd53ce()
        self._02c2577304b7()

        self._2fc9a00b72dc(self._924347a5b2eb)
    
    def _c4ce3c15d482(self):
        # rebuild all metrics on the correct device
        self._a0a8f128477a['micro_accuracy'] = _0fed79331a27(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed="micro",
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['macro_accuracy'] = _0fed79331a27(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed="macro",
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['macro_precision'] = _fbb0749c0940(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed="macro",
            _f355553ff49b=self. _a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['macro_recall'] = _d186e3789d6f(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed="macro",
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['macro_f1'] = _ba2f2f7d7c7f(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed="macro",
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['classwise_accuracy'] = _0fed79331a27(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed=_fde062d49480,
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['classwise_precision'] = _fbb0749c0940(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed=_fde062d49480,
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['classwise_recall'] = _d186e3789d6f(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed=_fde062d49480,
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['classwise_f1'] = _ba2f2f7d7c7f(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _3b4963739fed=_fde062d49480,
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)

        self._a0a8f128477a['confmat'] = _ebaa4aee494d(
            _981ba6e7df88=_41658cc59397(self._7f4a4f9face8),
            _f355553ff49b=self._a4d29c0df3ba,
            _f88a6d77e3eb=self._6a19ae9660de,
        )._842c6ac46095(self._e30e1b0d3067)


    def _6d65bac0f64c(self, _a1c672f552d0=_fde062d49480):
        """Calculate batch counts and set xth_batch_to_consider."""
        _53bc9a617f37 = 0
        _97ae3e994cb3 = 0
        if self._48fe8453a91c._63ad7f1c2cfa is not _fde062d49480:
            if _19359d1f2465(self._48fe8453a91c._63ad7f1c2cfa, 'train_dataset') and self._48fe8453a91c._63ad7f1c2cfa._0e7b7200b868 is not _fde062d49480:
                _53bc9a617f37 = _41658cc59397(self._48fe8453a91c._63ad7f1c2cfa._0e7b7200b868)
            if _19359d1f2465(self._48fe8453a91c._63ad7f1c2cfa, 'val_dataset') and self._48fe8453a91c._63ad7f1c2cfa._eedf642afb76 is not _fde062d49480:
                _97ae3e994cb3 = _41658cc59397(self._48fe8453a91c._63ad7f1c2cfa._eedf642afb76)
            _1e5688de498c = self._48fe8453a91c._63ad7f1c2cfa._1e5688de498c
            _20627163d476 = (_53bc9a617f37 + _1e5688de498c - 1) // _1e5688de498c if _53bc9a617f37 > 0 else 1
            _4b618deb2382 = (_97ae3e994cb3 + _1e5688de498c - 1) // _1e5688de498c if _97ae3e994cb3 > 0 else 1
            _51e5978773e8 = _90fd6b3a3737(_20627163d476, _4b618deb2382) if _97ae3e994cb3 > 0 else _20627163d476
            _c159131ecbc0 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._ef3647dfa1b8 = 1
            _5c659c29e456(f"DEBUG Batch Info: num_train_batches={_20627163d476}, num_val_batches={_4b618deb2382}, xth_batch_to_consider={self._ef3647dfa1b8}")

    def _d63232c618b9(self, _b3a43daa17fb, _bb7341a35fe2):
        if _b3a43daa17fb._0445b8dd53ce() == "parametric_relu":
            return _f48500a0e01b._a14f528d8ccf._8a5ead60bb11(_bb7341a35fe2=1)
        elif _b3a43daa17fb._0445b8dd53ce() == "leaky_relu":
            return _f48500a0e01b._a14f528d8ccf._497ccdac6599(_282fc9edf26d=_3c15818fdba3)
        else:
            return _f48500a0e01b._a14f528d8ccf._6124d5e51612(_282fc9edf26d=_3c15818fdba3)

    def _1efc7809b415(self, _50a51690fb56, _cb0c0ab823b4=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _a51529776a79, _eacb4495ab40 in _50a51690fb56._33721d36a217():
            _9f1e9786fb7f = f"{_cb0c0ab823b4}.{_a51529776a79}" if _cb0c0ab823b4 else _a51529776a79

            def _7d27dbe408a1(_f01ad95959f6, _8d21fb9b3f27, _234bce52b3a5):
                if _4fdb8474d472(_234bce52b3a5, _f48500a0e01b._531c31acec9b) and _234bce52b3a5._45033f1efe73()._56aed627b51c():
                    _5c659c29e456(f"NaN detected in {_9f1e9786fb7f} ({_f01ad95959f6._9d569c9947ac.__name__}) ({_234bce52b3a5._6aaf82c98abb})")

            _eacb4495ab40._f3a60d7b21ae(_556803fdfa9f)

            self._2fc9a00b72dc(_eacb4495ab40, _9f1e9786fb7f)

    def _9d8d1ba27de2(self, _50a51690fb56):
        return _56aed627b51c(_1c5f021ce483._6c479b5ca8d0 for _1c5f021ce483 in _50a51690fb56._535c9c383ae3())

    def _8dc56069f463(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _f37a00bbf07f = []
        for _a51529776a79, _50a51690fb56 in self._fa9ca6dfdd87():
            if not self._42506812627b(_50a51690fb56):
                continue
            _6c471962adea = (
                "norm" in _a51529776a79._0fd237fb0a16() or 
                "linear4bit" in _a51529776a79._0fd237fb0a16() or 
                _56aed627b51c(_99d1db418dab in _a51529776a79._0fd237fb0a16() for _99d1db418dab in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _a51529776a79._0fd237fb0a16() or 
                "dropout" in _a51529776a79._0fd237fb0a16() or 
                _4fdb8474d472(_50a51690fb56, (_18e1b765b5ca, _f48500a0e01b._a14f528d8ccf._227687e4cf7d, _f48500a0e01b._a14f528d8ccf._b4ebd0573e7f))
            )
            if _6c471962adea:
                if _19359d1f2465(_50a51690fb56, "eps"):
                    _50a51690fb56._b14eaa061916 = 1e-3
                _50a51690fb56 = _50a51690fb56._842c6ac46095(_f48500a0e01b._1a8e97e21ee2)
                if not _4fdb8474d472(_50a51690fb56, _8337ac5f33a0._da4f02ca0ad1):
                    _f37a00bbf07f._85cdac0b11ad((_a51529776a79, _8337ac5f33a0._da4f02ca0ad1(_50a51690fb56, _7e4117752be1=-10, _cba72bb56905=10)))
        for _a51529776a79, _fd4f632e2e88 in _f37a00bbf07f:
            _5e95977d316f, _b3acfe9b4256 = self._da3e9c507a2f(_a51529776a79)
            if _5e95977d316f is not _fde062d49480:
                _79fa1a29951e(_5e95977d316f, _b3acfe9b4256, _fd4f632e2e88)

    def _104f03166bae(self, _5da018fb9bec):
        """Finds the parent module and attribute name given the full module path."""
        _31bc9d1f7af4 = _5da018fb9bec._4bb933406d43('.')
        _324ba7c60e65 = self
        for _8733ee8ae01f in _31bc9d1f7af4[:-1]:
            _324ba7c60e65 = _06e3dce2cc26(_324ba7c60e65, _8733ee8ae01f, _fde062d49480)
            if _324ba7c60e65 is _fde062d49480:
                return _fde062d49480, _fde062d49480
        return _324ba7c60e65, _31bc9d1f7af4[-1]

    def _b92cb1fa636c(self, _2449e27e0b19: _f48500a0e01b._531c31acec9b, _abd240235199: _f48500a0e01b._531c31acec9b, _c6d4600763c3: _f48500a0e01b._531c31acec9b) -> _4a1ec85f399b:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _d3734ee07a4d = _2449e27e0b19._d3734ee07a4d

        # 1) gating w (use cached per-example teacher_conf if available)
        _42d7f906f9ec = _06e3dce2cc26(self, "_last_teacher_conf", _fde062d49480)
        if _42d7f906f9ec is _fde062d49480:
            # no teacher info => w = 0 (no distillation)
            _587764845db5 = 0.0
        else:
            _ccce99b28c3a = (_42d7f906f9ec >= _18b8dc998a1f(_06e3dce2cc26(self, "teacher_conf_tau", 0.6)))._18b8dc998a1f()
            _587764845db5 = _18b8dc998a1f(_ccce99b28c3a._9b1ac5608a4d()._1b7b65e86ccf()._77da29428691()) if _ccce99b28c3a._2789915207db() > 0 else 0.0

        # apply gating to the batch scalars
        _cb8db6d4cdd1 = _abd240235199 * _18b8dc998a1f(_587764845db5)
        _901b3f3d6aa3 = _c6d4600763c3 * _18b8dc998a1f(_587764845db5)

        # 2) EMAs for autoscaling
        _9066a451dbae = _18b8dc998a1f((_cb8db6d4cdd1 + _901b3f3d6aa3)._2520f732b87a()._1b7b65e86ccf()._77da29428691())
        _dbc3043ba58d = _18b8dc998a1f(_2449e27e0b19._2520f732b87a()._1b7b65e86ccf()._77da29428691())
        if _06e3dce2cc26(self, "ema_task", _fde062d49480) is _fde062d49480:
            self._4ad8ce12cfe5 = _dbc3043ba58d
            self._875de0caad24 = _9066a451dbae + 1e-12
        else:
            _1a46dca7bdf8 = _18b8dc998a1f(_06e3dce2cc26(self, "ema_alpha", 0.99))
            self._4ad8ce12cfe5 = _1a46dca7bdf8 * _18b8dc998a1f(self._4ad8ce12cfe5) + (1.0 - _1a46dca7bdf8) * _dbc3043ba58d
            self._875de0caad24  = _1a46dca7bdf8 * _18b8dc998a1f(self._875de0caad24)  + (1.0 - _1a46dca7bdf8) * _9066a451dbae

        _64e37bfac1a5 = _18b8dc998a1f(_06e3dce2cc26(self, "distill_target_ratio", 0.3))
        _01865ee4d3fc = (_18b8dc998a1f(self._4ad8ce12cfe5) / (_18b8dc998a1f(self._875de0caad24) + 1e-12)) * _64e37bfac1a5
        _0aaca66d4767 = _18b8dc998a1f(_01865ee4d3fc)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _f1411ced47eb = _18b8dc998a1f(_06e3dce2cc26(self._48fe8453a91c, "current_epoch", _06e3dce2cc26(self._48fe8453a91c, "global_step", 0.0)))
        _d8abcb29782c = _18b8dc998a1f(_5b679c251c3c(1, _06e3dce2cc26(self._48fe8453a91c, "max_epochs", 1)))
        _f51acc0c12fe = _90fd6b3a3737(_5b679c251c3c(_f1411ced47eb / _d8abcb29782c, 0.0), 1.0)
        _03637b8569f0 = 0.30
        _2786a9e3f826 = _18b8dc998a1f(_06e3dce2cc26(self, "kl_base", 0.30)) * _90fd6b3a3737(_f51acc0c12fe / _03637b8569f0, 1.0)
        _cdef56f055fc = _18b8dc998a1f(_06e3dce2cc26(self, "cos_base", 0.25))
        _497d8f6a2c84 = _cdef56f055fc + (0.10 - _cdef56f055fc) * _f51acc0c12fe

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _573da5b3c985 = _18b8dc998a1f(self._65b3e7989c54._9b1ac5608a4d()._1b7b65e86ccf()._77da29428691()) if _06e3dce2cc26(self, "_last_teacher_conf", _fde062d49480) is not _fde062d49480 else 0.0
        if _06e3dce2cc26(self, "ema_teacher_conf", _fde062d49480) is _fde062d49480:
            self._7fc9a71e6994 = _573da5b3c985
        else:
            _3c53a148e6f6 = _18b8dc998a1f(_06e3dce2cc26(self, "teacher_conf_beta", 0.995))
            self._7fc9a71e6994 = _3c53a148e6f6 * _18b8dc998a1f(self._7fc9a71e6994) + (1.0 - _3c53a148e6f6) * _573da5b3c985

        _b5204397712f = _18b8dc998a1f(_06e3dce2cc26(self, "tau_warn", 0.60))
        _6e5077e52848 = _18b8dc998a1f(_06e3dce2cc26(self, "tau_detect", 0.20))
        _12d3063d949f = _5b679c251c3c(1e-12, (_b5204397712f - _6e5077e52848))
        _482c9336e2d7 = (_18b8dc998a1f(self._7fc9a71e6994) - _6e5077e52848) / _12d3063d949f
        _482c9336e2d7 = _5b679c251c3c(0.0, _90fd6b3a3737(1.0, _482c9336e2d7))

        _46205903b138 = _2786a9e3f826 * _482c9336e2d7
        _88fc614c06ff = _497d8f6a2c84 * _482c9336e2d7

        # 5) final aux term
        _27bd7ff375b2 = _f48500a0e01b._072a3d87f816(0.0, _d3734ee07a4d=_d3734ee07a4d)
        _27bd7ff375b2 = _27bd7ff375b2 + (_46205903b138 * _cb8db6d4cdd1 + _88fc614c06ff * _901b3f3d6aa3) * _18b8dc998a1f(_0aaca66d4767)

        # diagnostics
        _234bce52b3a5 = {
            "aux_term": _27bd7ff375b2,
            "kl_batch": _abd240235199,
            "contrast_batch": _c6d4600763c3,
            "kl_loss": _cb8db6d4cdd1,
            "contrastive_loss": _901b3f3d6aa3,
            "w_mean": _587764845db5,
            "aux_scale": _18b8dc998a1f(_0aaca66d4767),
            "lambda_kl_eff": _18b8dc998a1f(_46205903b138),
            "lambda_cos_eff": _18b8dc998a1f(_88fc614c06ff),
            "teacher_conf_mean": _18b8dc998a1f(self._7fc9a71e6994),
            "shift_r": _18b8dc998a1f(_482c9336e2d7)
        }
        return _234bce52b3a5

    def _bd31164236c9(self, _abfbf829a9d1):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _abfbf829a9d1 = _abfbf829a9d1._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)
        _3a4eee61b5fa = (_abfbf829a9d1 != self._399e7f31a58c._5b83268b8173)._842c6ac46095(_6aaf82c98abb=_f48500a0e01b._a944915e821f, _d3734ee07a4d=self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)

        # model forward (request hidden states)
        _1f5a9fe928f1 = self._924347a5b2eb(
            _abfbf829a9d1=_abfbf829a9d1,
            _3a4eee61b5fa=_3a4eee61b5fa,
            _979de4b749bd=_25457baefff4,
            _46456deb6d1f=_25457baefff4,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _e030d7bbb838 = _06e3dce2cc26(_1f5a9fe928f1, "last_hidden_state", _fde062d49480)
        if _e030d7bbb838 is _fde062d49480:
            _e030d7bbb838 = _1f5a9fe928f1._527561a75242[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _e030d7bbb838._6aaf82c98abb != _f48500a0e01b._1a8e97e21ee2:
            _e030d7bbb838 = _e030d7bbb838._842c6ac46095(_f48500a0e01b._1a8e97e21ee2)
        _a199b1cbeb64 = self._2b8f32004224(_e030d7bbb838)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._c0d9fbe2e3ad:
            _dbad2cd9d00a = self._0627d49243e3(_a199b1cbeb64)
        else:
            _dbad2cd9d00a = _1f5a9fe928f1._dbad2cd9d00a


        _dbad2cd9d00a = _dbad2cd9d00a._842c6ac46095(_f48500a0e01b._1a8e97e21ee2)._2d090ff63b63(-20, 20)

        # default zero scalars
        _cb8db6d4cdd1 = _f48500a0e01b._072a3d87f816(0.0, _d3734ee07a4d=self._e30e1b0d3067)
        _901b3f3d6aa3 = _f48500a0e01b._072a3d87f816(0.0, _d3734ee07a4d=self._e30e1b0d3067)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _3fe6b2a41f82 = _06e3dce2cc26(self, "trainer", _fde062d49480)
        _072125653753 = _3c15818fdba3
        if _3fe6b2a41f82 is not _fde062d49480:
            _072125653753 = _a944915e821f(_06e3dce2cc26(self._48fe8453a91c, "training", _3c15818fdba3) or _06e3dce2cc26(self._48fe8453a91c, "validating", _3c15818fdba3))

        if _072125653753 and (_06e3dce2cc26(self, "batch_counter", 0) % _06e3dce2cc26(self, "xth_batch_to_consider", 1) == 0):
            with _f48500a0e01b._2f3e1ac90a85():
                _8d3b5ba45361 = _5199d6f690d2(
                    _abfbf829a9d1=_abfbf829a9d1,
                    _3a4eee61b5fa=_3a4eee61b5fa,
                    _979de4b749bd=_25457baefff4,
                    _46456deb6d1f=_25457baefff4,
                )
                _d7f1c901ea17 = _06e3dce2cc26(_8d3b5ba45361, "last_hidden_state", _fde062d49480)
                if _d7f1c901ea17 is _fde062d49480:
                    _d7f1c901ea17 = _8d3b5ba45361._527561a75242[-1]

            # compute embedding-level KL + contrastive (scalar)
            _cb8db6d4cdd1, _901b3f3d6aa3 = self._b0e338bfb2bf(_a199b1cbeb64, _d7f1c901ea17, _d3734ee07a4d=self._e30e1b0d3067)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _e2cbc33e3818(_60b1b4282fd0): return _60b1b4282fd0._9b1ac5608a4d(_dd67473f1010=1) if _60b1b4282fd0._dd67473f1010() == 3 else _60b1b4282fd0
            _466e6063951b = _f48500a0e01b._a14f528d8ccf._00e212f6e840._b77acf116023(_f8582b6063fb(_a199b1cbeb64), _1c5f021ce483=2, _dd67473f1010=-1, _b14eaa061916=1e-6)
            _c19d45682b36 = _f48500a0e01b._a14f528d8ccf._00e212f6e840._b77acf116023(_f8582b6063fb(_d7f1c901ea17), _1c5f021ce483=2, _dd67473f1010=-1, _b14eaa061916=1e-6)
            _55789789839b = _f48500a0e01b._a14f528d8ccf._00e212f6e840._227bc063f104(_466e6063951b, _c19d45682b36, _dd67473f1010=-1)  # [-1,1]
            _42d7f906f9ec = _55789789839b._2d090ff63b63(_90fd6b3a3737=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._e2f11233ef1c = _a199b1cbeb64._2520f732b87a()
            self._4fba5679b252 = _d7f1c901ea17._2520f732b87a()
            self._65b3e7989c54 = _42d7f906f9ec._2520f732b87a()  # shape (B,)

        # increment counter
        self._d43e3f0929d3 = _06e3dce2cc26(self, "batch_counter", 0) + 1

        return _dbad2cd9d00a, _cb8db6d4cdd1, _901b3f3d6aa3


    def _4de688a04cc4(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _ed3aa9e27639(_50a51690fb56, _b21044eb339c, _f2c4d6b65399):
            if _56aed627b51c(_8d21fb9b3f27._6aaf82c98abb == _f48500a0e01b._bb1fc34ef123 for _8d21fb9b3f27 in _b21044eb339c if _4fdb8474d472(_8d21fb9b3f27, _f48500a0e01b._531c31acec9b)):
                _5c659c29e456(f"Layer {_50a51690fb56._9d569c9947ac.__name__} is using float16!")

        for _964f4106addc in self._26338dc3327e():
            _575732c6f0f0 = _964f4106addc._f3a60d7b21ae(_42344650c241)
            self._edb48d3adf71._85cdac0b11ad(_575732c6f0f0)

    def _ec8d3e81efbd(self):
        """Remove all registered forward hooks."""
        for _575732c6f0f0 in _06e3dce2cc26(self, "amp_hooks", []):
            _575732c6f0f0._9cbc3095afcc()
        self._edb48d3adf71 = []

    def _bfe043f150c0(self, _abfbf829a9d1, _443d57c8e188, _2761d7737b11):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _32b070efaccc = [self._399e7f31a58c._93abb1f9afdb(_9aa9b4e0838b) for _9aa9b4e0838b in _abfbf829a9d1]
        _b282bcea2829, _1c85f0acf4ad = [], []

        for _2a1abd448ab2, _808aaf9fd7d0, _8651a7137aa0 in _dc558b82ddab(_32b070efaccc, _443d57c8e188, _2761d7737b11):
            for token, _2048ed49de79, _5c6dc6b5add2 in _dc558b82ddab(_2a1abd448ab2, _808aaf9fd7d0, _8651a7137aa0):
                if token == self._399e7f31a58c._7bee6bc72a51 or _5c6dc6b5add2 == self._6a19ae9660de:
                    continue

                _e2f9ffab8270 = (
                    token._f65cd64db7e4("##") or
                    token._f65cd64db7e4("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _e2f9ffab8270:
                    continue

                _b282bcea2829._85cdac0b11ad(_2048ed49de79._77da29428691())
                _1c85f0acf4ad._85cdac0b11ad(_5c6dc6b5add2._77da29428691())

        return _f48500a0e01b._072a3d87f816(_b282bcea2829), _f48500a0e01b._072a3d87f816(_1c85f0acf4ad)

    def _03f74d32dbf3(self):
        _1d95006662c5 = _f48500a0e01b._1a8e97e21ee2
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            _983c4907fde7, _96455be07582 = _f48500a0e01b._6666d9d82aa0._dc778a9908cb()
            if _983c4907fde7 >= 8:
                _1d95006662c5 = _f48500a0e01b._0deb10206670
            else:
                _1d95006662c5 = _f48500a0e01b._bb1fc34ef123
        return _1d95006662c5

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _287d2395bd3e(
        self,
        _1819be191bfd: _f48500a0e01b._531c31acec9b,
        _2a3d9dcc28d0: _f48500a0e01b._531c31acec9b,
        _d3734ee07a4d: _f780e422c7b7 = "cpu",
    ) -> _ea09ef820e40[_f48500a0e01b._531c31acec9b, _f48500a0e01b._531c31acec9b]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _f0f39fff39a9 = 2.0
            # NaN/Inf guard
            _1819be191bfd = _1819be191bfd._2d090ff63b63(_90fd6b3a3737=-30, _5b679c251c3c=30)
            _2a3d9dcc28d0 = _2a3d9dcc28d0._2d090ff63b63(_90fd6b3a3737=-30, _5b679c251c3c=30)

            # Move once if needed
            _99acdb1aabe4 = _f48500a0e01b._d3734ee07a4d(_d3734ee07a4d)
            if _1819be191bfd._d3734ee07a4d != _99acdb1aabe4:
                _1819be191bfd = _1819be191bfd._842c6ac46095(_d3734ee07a4d=_99acdb1aabe4, _c1bd87bff54e=_25457baefff4, _6aaf82c98abb=self._45d9d3db12dc)
                _2a3d9dcc28d0 = _2a3d9dcc28d0._842c6ac46095(_d3734ee07a4d=_99acdb1aabe4, _c1bd87bff54e=_25457baefff4, _6aaf82c98abb=self._45d9d3db12dc)

            _1e5688de498c = _1819be191bfd._db72f7d5502d(0)
            _04832f1ae2b4 = _1819be191bfd._db72f7d5502d(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _d4aa7fff4020 = (_1e5688de498c * _04832f1ae2b4) > 32_000_000

            if not _d4aa7fff4020 or _1e5688de498c <= 8:
                # Direct computation
                _2a40fec8a37f = _f48500a0e01b._a14f528d8ccf._00e212f6e840._06f211e3d5b6(_1819be191bfd / _f0f39fff39a9, _dd67473f1010=-1)
                _90a740b30495 = _f48500a0e01b._a14f528d8ccf._00e212f6e840._54b51e853a48(_2a3d9dcc28d0 / _f0f39fff39a9, _dd67473f1010=-1)
                _cb8db6d4cdd1 = _f48500a0e01b._a14f528d8ccf._00e212f6e840._d5a43e64864d(_2a40fec8a37f, _90a740b30495, _1cf35555820b="batchmean") * (_f0f39fff39a9 * _f0f39fff39a9)
                _901b3f3d6aa3 = 1 - _f48500a0e01b._a14f528d8ccf._00e212f6e840._227bc063f104(_1819be191bfd, _2a3d9dcc28d0, _dd67473f1010=-1)._9b1ac5608a4d()
                return _cb8db6d4cdd1, _901b3f3d6aa3

            # Chunked mode for large inputs
            _86c1b7e30d80 = _5b679c251c3c(1, _1e5688de498c // 8)
            _d27d51233cfa, _4fe2e432658c = [], []

            for _5be39fe1c60f in _71df794e6854(0, _1e5688de498c, _86c1b7e30d80):
                _b0147cde8344 = _1819be191bfd[_5be39fe1c60f:_5be39fe1c60f + _86c1b7e30d80]
                _e4f205ed1396 = _2a3d9dcc28d0[_5be39fe1c60f:_5be39fe1c60f + _86c1b7e30d80]

                _2a40fec8a37f = _f48500a0e01b._a14f528d8ccf._00e212f6e840._06f211e3d5b6(_b0147cde8344 / _f0f39fff39a9, _dd67473f1010=-1)
                _90a740b30495 = _f48500a0e01b._a14f528d8ccf._00e212f6e840._54b51e853a48(_e4f205ed1396 / _f0f39fff39a9, _dd67473f1010=-1)

                _b09672e2ee97 = _f48500a0e01b._a14f528d8ccf._00e212f6e840._d5a43e64864d(_2a40fec8a37f, _90a740b30495, _1cf35555820b="batchmean") * (_f0f39fff39a9 * _f0f39fff39a9)
                _1dfbfeaa58ab = _f48500a0e01b._a14f528d8ccf._00e212f6e840._227bc063f104(_b0147cde8344, _e4f205ed1396, _dd67473f1010=-1)._9b1ac5608a4d()
                _35700ff42ffd = 1 - _1dfbfeaa58ab

                _d27d51233cfa._85cdac0b11ad(_b09672e2ee97)
                _4fe2e432658c._85cdac0b11ad(_35700ff42ffd)

            _cb8db6d4cdd1 = _f48500a0e01b._b7fcfaa338b5(_d27d51233cfa)._9b1ac5608a4d()
            _901b3f3d6aa3 = _f48500a0e01b._b7fcfaa338b5(_4fe2e432658c)._9b1ac5608a4d()
            return _cb8db6d4cdd1, _901b3f3d6aa3

        except _5eff7161c1f8 as _8b232209306f:
            raise _66e73f586fa3(f"KL/contrastive loss computation failed: {_f780e422c7b7(_8b232209306f)}")


    def _9ead31d97e43(self, _c63b4b4896f5, _6443dd53d99b):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _abfbf829a9d1 = _c63b4b4896f5["input_ids"]
            _e7ff40bc14fb = _c63b4b4896f5["labels"]
            _1f5cf4ed0bbc = _c63b4b4896f5._2aa253a0a485("prompt_lens", _fde062d49480)
            _1e5688de498c = _abfbf829a9d1._db72f7d5502d(0)

            # move to device
            _abfbf829a9d1 = _abfbf829a9d1._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)
            _e7ff40bc14fb = _e7ff40bc14fb._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _f2c4d6b65399, _abd240235199, _c6d4600763c3 = self(_abfbf829a9d1)

            # causal LM shift for next-token classification (unchanged)
            _e16248415110 = _f2c4d6b65399[:, :-1, :]._fbffea2d871b()
            _d4a8d65389e5 = _e7ff40bc14fb[:, 1:]._fbffea2d871b()
            _2de3f5e07c27 = _e16248415110._e4b2e263678c(-1, _e16248415110._db72f7d5502d(-1))
            _d8e8cc813f86 = _d4a8d65389e5._e4b2e263678c(-1)

            # classification/task loss
            _aee59a3967c3 = self._28c03050ab35['criterion'](_2de3f5e07c27, _d8e8cc813f86)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _abd240235199 = _f48500a0e01b._3d3f28c3dd9f(_abd240235199, _e7a2ca0fd566=0.0, _ace669733e58=0.0, _244fdabb6ad1=0.0)
            _c6d4600763c3 = _f48500a0e01b._3d3f28c3dd9f(_c6d4600763c3, _e7a2ca0fd566=0.0, _ace669733e58=0.0, _244fdabb6ad1=0.0)
            _aee59a3967c3 = _f48500a0e01b._3d3f28c3dd9f(_aee59a3967c3, _e7a2ca0fd566=0.0, _ace669733e58=0.0, _244fdabb6ad1=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _ff222833086f = self._c8a312090249(_aee59a3967c3, _abd240235199, _c6d4600763c3)
            _27bd7ff375b2 = _ff222833086f["aux_term"]

            # final combined loss (single-equation)
            _847c20aee638 = _aee59a3967c3 + _27bd7ff375b2

            # Optional NaN print as before (keeps your original check)
            if _f48500a0e01b._45033f1efe73(_aee59a3967c3):
                _5c659c29e456(f"Step {_6443dd53d99b}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _5ad446dd3abe = {
                "epoch": _18b8dc998a1f(_06e3dce2cc26(self, "current_epoch", _06e3dce2cc26(self._48fe8453a91c, "current_epoch", 0))),
                "train_kl_loss": _ff222833086f._2aa253a0a485("kl_loss", _abd240235199)._2520f732b87a() if _4fdb8474d472(_ff222833086f._2aa253a0a485("kl_loss", _abd240235199), _f48500a0e01b._531c31acec9b) else _ff222833086f._2aa253a0a485("kl_loss", _abd240235199),
                "train_contrastive_loss": _ff222833086f._2aa253a0a485("contrastive_loss", _c6d4600763c3)._2520f732b87a() if _4fdb8474d472(_ff222833086f._2aa253a0a485("contrastive_loss", _c6d4600763c3), _f48500a0e01b._531c31acec9b) else _ff222833086f._2aa253a0a485("contrastive_loss", _c6d4600763c3),
                "train_classification_loss": _aee59a3967c3._2520f732b87a(),
                "train_loss": _847c20aee638._2520f732b87a(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _18b8dc998a1f(_06e3dce2cc26(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _ff222833086f._2aa253a0a485("lambda_kl_eff", _18b8dc998a1f(_06e3dce2cc26(self, "kl_base", 0.30))),
                "train_lambda_contrast": _ff222833086f._2aa253a0a485("lambda_cos_eff", _18b8dc998a1f(_06e3dce2cc26(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _c8d3eba2a65b in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _c8d3eba2a65b in _ff222833086f:
                    _6ce1de07c830 = _ff222833086f[_c8d3eba2a65b]
                    # convert single-element tensors to python floats for logging
                    if _4fdb8474d472(_6ce1de07c830, _f48500a0e01b._531c31acec9b) and _6ce1de07c830._2789915207db() == 1:
                        _5ad446dd3abe[f"train_{_c8d3eba2a65b}"] = _18b8dc998a1f(_6ce1de07c830._2520f732b87a()._1b7b65e86ccf()._77da29428691())
                    else:
                        _5ad446dd3abe[f"train_{_c8d3eba2a65b}"] = _6ce1de07c830

            # log exactly like you did
            self._e6442cc44d71(
                _5ad446dd3abe,
                _1e5688de498c=_1e5688de498c,
                _b414ca4b5d0a=_3c15818fdba3,
                _a68ba761e3f5=_25457baefff4,
                _b85809d2a761=_3c15818fdba3,
                _a4685f222348=_25457baefff4,
                _1509e21dbb3f=_25457baefff4,
            )

            # free references as you did
            del _abfbf829a9d1, _e7ff40bc14fb, _f2c4d6b65399, _abd240235199, _aee59a3967c3, _c6d4600763c3, _d4a8d65389e5, _e16248415110, _d8e8cc813f86, _2de3f5e07c27

            return _847c20aee638

        except _5eff7161c1f8 as _8b232209306f:
            raise _66e73f586fa3(f"Error in training_step: {_8b232209306f}") from _8b232209306f

    def _9e89a232cc3a(self):
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            _f48500a0e01b._6666d9d82aa0._f8460c656ee3()
        _70757aeca278._8e9bd38bebf2()
        return _2912a458494b()._b1fd30431fd9()

    def _3639f9aff11b(self, _c63b4b4896f5, _6443dd53d99b):
        _abfbf829a9d1      = _c63b4b4896f5["input_ids"]._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)
        _e7ff40bc14fb         = _c63b4b4896f5["labels"]._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)
        _54f96aa8c37d     = _c63b4b4896f5._2aa253a0a485("lang_codes", _fde062d49480)
        _4e405e6dee70     = _c63b4b4896f5._2aa253a0a485("sample_ids", _fde062d49480)
        _ae1677c9afec      = _c63b4b4896f5._2aa253a0a485("chunk_ids", _fde062d49480)
        _1524d1291aa5 = _c63b4b4896f5._2aa253a0a485("word_positions", _fde062d49480)
        _1f5cf4ed0bbc    = _c63b4b4896f5._2aa253a0a485("prompt_lens", _fde062d49480)
        _80bccdb6ce54 = _c63b4b4896f5._2aa253a0a485("num_chunks", _fde062d49480)

        _1e5688de498c = _abfbf829a9d1._db72f7d5502d(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _f2c4d6b65399, _abd240235199, _c6d4600763c3 = self(_abfbf829a9d1)

        # causal LM shift for next-token classification (same as training)
        _e16248415110 = _f2c4d6b65399[:, :-1, :]._fbffea2d871b()
        _d4a8d65389e5 = _e7ff40bc14fb[:, 1:]._fbffea2d871b()
        _2de3f5e07c27 = _e16248415110._e4b2e263678c(-1, _e16248415110._db72f7d5502d(-1))
        _d8e8cc813f86 = _d4a8d65389e5._e4b2e263678c(-1)

        if _6443dd53d99b == 0:
            try:
                _5c659c29e456(
                    f"VAL TEST BATCH {_6443dd53d99b} Input IDs: {_abfbf829a9d1._43b41e404a7c()[0]}, "
                    f"Predictions: {_f48500a0e01b._ae88595303f9(_e16248415110, _dd67473f1010=-1)._43b41e404a7c()[0]}, "
                    f"Labels: {_d4a8d65389e5._43b41e404a7c()[0]}"
                )
            except _5eff7161c1f8:
                # printing should never crash validation
                pass

        # classification loss
        _aee59a3967c3 = self._28c03050ab35['criterion'](_2de3f5e07c27, _d8e8cc813f86)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _abd240235199 = _f48500a0e01b._3d3f28c3dd9f(_abd240235199, _e7a2ca0fd566=0.0, _ace669733e58=0.0, _244fdabb6ad1=0.0)
        _c6d4600763c3 = _f48500a0e01b._3d3f28c3dd9f(_c6d4600763c3, _e7a2ca0fd566=0.0, _ace669733e58=0.0, _244fdabb6ad1=0.0)
        _aee59a3967c3 = _f48500a0e01b._3d3f28c3dd9f(_aee59a3967c3, _e7a2ca0fd566=0.0, _ace669733e58=0.0, _244fdabb6ad1=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _ff222833086f = self._c8a312090249(_aee59a3967c3, _abd240235199, _c6d4600763c3)
        _27bd7ff375b2 = _ff222833086f["aux_term"]
        _847c20aee638 = _aee59a3967c3 + _27bd7ff375b2

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _e6442cc44d71 = {
            "val_kl_loss": _18b8dc998a1f(_ff222833086f._2aa253a0a485("kl_loss", _abd240235199)._2520f732b87a()._1b7b65e86ccf()._77da29428691()) if _4fdb8474d472(_ff222833086f._2aa253a0a485("kl_loss", _abd240235199), _f48500a0e01b._531c31acec9b) else _18b8dc998a1f(_ff222833086f._2aa253a0a485("kl_loss", _abd240235199)),
            "val_contrastive_loss": _18b8dc998a1f(_ff222833086f._2aa253a0a485("contrastive_loss", _c6d4600763c3)._2520f732b87a()._1b7b65e86ccf()._77da29428691()) if _4fdb8474d472(_ff222833086f._2aa253a0a485("contrastive_loss", _c6d4600763c3), _f48500a0e01b._531c31acec9b) else _18b8dc998a1f(_ff222833086f._2aa253a0a485("contrastive_loss", _c6d4600763c3)),
            "val_classification_loss": _18b8dc998a1f(_aee59a3967c3._2520f732b87a()._1b7b65e86ccf()._77da29428691()),
            "val_loss": _18b8dc998a1f(_847c20aee638._2520f732b87a()._1b7b65e86ccf()._77da29428691()),
        }

        # include effective lambdas and others if provided by aux
        _e6442cc44d71["val_lambda_kl"] = _18b8dc998a1f(_ff222833086f._2aa253a0a485("lambda_kl", _ff222833086f._2aa253a0a485("lambda_kl_eff", _18b8dc998a1f(_06e3dce2cc26(self, "kl_base", 0.30)))))
        _e6442cc44d71["val_lambda_contrast"] = _18b8dc998a1f(_ff222833086f._2aa253a0a485("lambda_cos", _ff222833086f._2aa253a0a485("lambda_cos_eff", _18b8dc998a1f(_06e3dce2cc26(self, "cos_base", 0.25)))))
        _e6442cc44d71["val_w_mean"] = _18b8dc998a1f(_ff222833086f._2aa253a0a485("w_mean", 0.0))
        _e6442cc44d71["val_aux_scale"] = _18b8dc998a1f(_ff222833086f._2aa253a0a485("aux_scale", 0.0))
        _e6442cc44d71["val_shift_r"] = _18b8dc998a1f(_ff222833086f._2aa253a0a485("shift_r", 0.0))
        _e6442cc44d71["val_teacher_conf_mean"] = _18b8dc998a1f(_ff222833086f._2aa253a0a485("teacher_conf_mean", 0.0))

        self._e6442cc44d71(
            _e6442cc44d71,
            _1e5688de498c=_1e5688de498c,
            _b414ca4b5d0a=_3c15818fdba3,
            _a68ba761e3f5=_25457baefff4,
            _b85809d2a761=_3c15818fdba3,
            _a4685f222348=_25457baefff4,
            _1509e21dbb3f=_25457baefff4,
        )

        # build preds and labels per example (preserve your previous behavior)
        _d32f08b6958a = []
        _77428e7c77c5 = []
        for _5be39fe1c60f in _71df794e6854(_1e5688de498c):
            _9004d3bf96fa = _f2c4d6b65399[_5be39fe1c60f]
            _5c6dc6b5add2 = _e7ff40bc14fb[_5be39fe1c60f]
            _fab3b72b4250 = _f48500a0e01b._ae88595303f9(_9004d3bf96fa, _dd67473f1010=-1)
            _99fe3d9fd476 = _5c6dc6b5add2
            _d32f08b6958a._85cdac0b11ad(_fab3b72b4250)
            _77428e7c77c5._85cdac0b11ad(_99fe3d9fd476)

        _825956188ba2 = {
            "lang_codes": _54f96aa8c37d,
            "preds": _d32f08b6958a,
            "labels": _77428e7c77c5,
            "sample_ids": _4e405e6dee70,
            "chunk_ids": _ae1677c9afec,
            "word_positions": _1524d1291aa5,
            "val_loss": _847c20aee638,
            "prompt_lens": _1f5cf4ed0bbc,
            "num_chunks": _80bccdb6ce54,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._c4dccb4e4477._85cdac0b11ad(_825956188ba2)

        # explicit frees (same as you had)
        del _abfbf829a9d1, _e7ff40bc14fb, _f2c4d6b65399, _2de3f5e07c27, _d8e8cc813f86, _e16248415110, _d4a8d65389e5
        del _abd240235199, _c6d4600763c3, _aee59a3967c3, _d32f08b6958a, _77428e7c77c5

        return _825956188ba2


    def _b564f6efdb90(self, _f2c536fac374, _8cf6c2423313, _e2a085b4bfd8=_fde062d49480):
        _7e4b189d8ea4 = os._3d2542205dc3()
        _d13f9edb1954 = f"trial_{_e2a085b4bfd8}" if _e2a085b4bfd8 is not _fde062d49480 else "default"
        _5c659c29e456(f"[DEBUG rank={_f48500a0e01b._cfcf5fd393bf._fd39d6a9ef45() if _f48500a0e01b._cfcf5fd393bf._eff25c880b7a() else 0}] metrics_dict confusion_matrix sum={_ffca1243e92f(_ffca1243e92f(_2accaaa94c6d) for _2accaaa94c6d in _f2c536fac374['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _0f9623c74cdc = os._aceccad6a77b._c8431f09b824(_7e4b189d8ea4, "metrics", self._e123cb273e4e,  _d13f9edb1954)
        os._dab43e350df0(_0f9623c74cdc, _ad78a7fd81a1=_25457baefff4)
        _2cf59bf6ba47 = os._aceccad6a77b._c8431f09b824(_0f9623c74cdc, _8cf6c2423313)
        _d5e09d78c824 = _d6ab597f8b72._9a7d0b35c5ee(_f2c536fac374)
        _d5e09d78c824._e76f6265e8a4(_2cf59bf6ba47, _08ebf3ecb571=_3c15818fdba3)
        _5c659c29e456(f"[metrics] Saved {_2cf59bf6ba47}")

    def _7e0bbda6c7da(self):
        # pick correct device for this rank
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            if _f48500a0e01b._cfcf5fd393bf._eff25c880b7a():
                _e6d5fa3d41bd = _f48500a0e01b._cfcf5fd393bf._fd39d6a9ef45()
            else:
                _e6d5fa3d41bd = 0
            _f48500a0e01b._6666d9d82aa0._2118977ab338(_e6d5fa3d41bd)
            self._e30e1b0d3067 = _f48500a0e01b._d3734ee07a4d(f"cuda:{_e6d5fa3d41bd}")
        else:
            self._e30e1b0d3067 = _f48500a0e01b._d3734ee07a4d("cpu")

        self._81231ba5641e()

    def _334d47c9db2e(self):
        _f2c4d6b65399 = _06e3dce2cc26(self, "_validation_outputs", _fde062d49480)
        if not _f2c4d6b65399:
            return

        _b8e795d2323b, _f748e98afcec, _27348f495518, _2ed533ab4e9c = \
            self._bd9882a5dae9(_f2c4d6b65399)

        _a852c5c30106, _71c5a75d5d10 = [], []
        for _20a934414d29 in _3128bffd4d02(_27348f495518._5dd8d2cf740b()):
            _00b84c1d3c5b = _b8e795d2323b[_20a934414d29]._43b41e404a7c()
            _2a45f97ad085 = _f748e98afcec[_20a934414d29]._43b41e404a7c()
            _57635d37c80b = _27348f495518[_20a934414d29]
            _28cc0482dd67 = _2ed533ab4e9c[_20a934414d29]
            if _57635d37c80b._2789915207db() > 0 and _28cc0482dd67._2789915207db() > 0:
                _a852c5c30106._85cdac0b11ad(_57635d37c80b)
                _71c5a75d5d10._85cdac0b11ad(_28cc0482dd67)

        if not _a852c5c30106:
            _5c659c29e456("[VAL END] Nothing to score.")
            self._c4dccb4e4477._18dc810490c2()
            return

        _d8fda41be51e = _f48500a0e01b._5ab0053cde47(_a852c5c30106)._842c6ac46095(_d3734ee07a4d=self._a0a8f128477a['micro_accuracy']._d3734ee07a4d, _c1bd87bff54e=_25457baefff4)
        _e7ff40bc14fb = _f48500a0e01b._5ab0053cde47(_71c5a75d5d10)._842c6ac46095(_d3734ee07a4d=self._a0a8f128477a['micro_accuracy']._d3734ee07a4d, _c1bd87bff54e=_25457baefff4)

        self._a0a8f128477a['micro_accuracy']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_accuracy']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_precision']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_recall']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_f1']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_accuracy']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_precision']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_recall']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_f1']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['confmat']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)

        _b4d8c052a344  = self._a0a8f128477a['micro_accuracy']._00e73a9c4b52()._77da29428691()
        _4b83a43a907a  = self._a0a8f128477a['macro_accuracy']._00e73a9c4b52()._77da29428691()
        _8039739b0f44 = self._a0a8f128477a['macro_precision']._00e73a9c4b52()._77da29428691()
        _4d9fc7525406    = self._a0a8f128477a['macro_recall']._00e73a9c4b52()._77da29428691()
        _05d44bc94255        = self._a0a8f128477a['macro_f1']._00e73a9c4b52()._77da29428691()

        self._c15b4b686196("val_accuracy", _4b83a43a907a, _1509e21dbb3f=_25457baefff4)

        try:
            _f9d9eb9a8f80 = self._05606ec24357
            _f2c536fac374 = {
                "epoch": [_f9d9eb9a8f80],
                "class_names": [self._7f4a4f9face8],
                "micro_accuracy": [_b4d8c052a344],
                "macro_accuracy": [_4b83a43a907a],
                "macro_precision": [_8039739b0f44],
                "macro_recall": [_4d9fc7525406],
                "macro_f1": [_05d44bc94255],
                "classwise_accuracy": [self._a0a8f128477a['classwise_accuracy']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "classwise_precision": [self._a0a8f128477a['classwise_precision']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "classwise_recall": [self._a0a8f128477a['classwise_recall']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "classwise_f1": [self._a0a8f128477a['classwise_f1']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "confusion_matrix": [self._a0a8f128477a['confmat']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
            }
            self._1beab8cec9c7(_f2c536fac374, f"val_epoch_{_f9d9eb9a8f80}.csv", _e2a085b4bfd8=self._e2a085b4bfd8)
        except _5eff7161c1f8 as _8b232209306f:
            _5c659c29e456(f"[VAL END] save metrics FAILED: {_8b232209306f}")

        # cleanup
        self._a0a8f128477a['micro_accuracy']._d5c06b2ec513(); self._a0a8f128477a['macro_accuracy']._d5c06b2ec513()
        self._a0a8f128477a['macro_precision']._d5c06b2ec513(); self._a0a8f128477a['macro_recall']._d5c06b2ec513(); self._a0a8f128477a['macro_f1']._d5c06b2ec513()
        self._a0a8f128477a['classwise_accuracy']._d5c06b2ec513(); self._a0a8f128477a['classwise_precision']._d5c06b2ec513()
        self._a0a8f128477a['classwise_recall']._d5c06b2ec513(); self._a0a8f128477a['classwise_f1']._d5c06b2ec513()
        self._a0a8f128477a['confmat']._d5c06b2ec513(); self._c4dccb4e4477._18dc810490c2()
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            _f48500a0e01b._6666d9d82aa0._f8460c656ee3()
        _5c659c29e456("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_f48500a0e01b._2f3e1ac90a85()
    def _39939db8b3e0(self, _abfbf829a9d1: _f48500a0e01b._531c31acec9b, **_0942e0b9af63):
        _0942e0b9af63._41fe5d3bb61f("pad_token_id", _fde062d49480)
        _0942e0b9af63._41fe5d3bb61f("attention_mask", _fde062d49480)
        return self._924347a5b2eb._593ecf459a49(
            _abfbf829a9d1=_abfbf829a9d1,
            _3a4eee61b5fa=(_abfbf829a9d1 != self._399e7f31a58c._5b83268b8173),
            _5b83268b8173=self._399e7f31a58c._5b83268b8173,
            _0399a9a3a6d2=self._399e7f31a58c._0399a9a3a6d2,
            **_0942e0b9af63
        )

    def _696566327ef1(self, _c63b4b4896f5, _6443dd53d99b):
        _abfbf829a9d1 = _c63b4b4896f5["input_ids"]._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)
        _e7ff40bc14fb    = _c63b4b4896f5["labels"]._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)
        _54f96aa8c37d     = _c63b4b4896f5._2aa253a0a485("lang_codes", _fde062d49480)
        _4e405e6dee70     = _c63b4b4896f5._2aa253a0a485("sample_ids", _fde062d49480)
        _ae1677c9afec      = _c63b4b4896f5._2aa253a0a485("chunk_ids", _fde062d49480)
        _1524d1291aa5 = _c63b4b4896f5._2aa253a0a485("word_positions", _fde062d49480)
        _1f5cf4ed0bbc    = _c63b4b4896f5._2aa253a0a485("prompt_lens", _fde062d49480)
        _80bccdb6ce54 = _c63b4b4896f5._2aa253a0a485("num_chunks", _fde062d49480)

        _1e5688de498c = _abfbf829a9d1._db72f7d5502d(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _549cb931eb94 = self._593ecf459a49(
            _abfbf829a9d1,
            _b847291b81e9=32,
            _52fc3d3e9965=_3c15818fdba3,
            _9c2eb0af8f27=_fde062d49480,     # for deterministic answers
            _da05ff8c01fe=_fde062d49480,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _d32f08b6958a = []
        _77428e7c77c5 = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _5be39fe1c60f in _71df794e6854(_1e5688de498c):
            _d32f08b6958a._85cdac0b11ad(_549cb931eb94[_5be39fe1c60f])   # FULL sequence
            _77428e7c77c5._85cdac0b11ad(_e7ff40bc14fb[_5be39fe1c60f])          # FULL labels


        _825956188ba2 = {
            "lang_codes": _54f96aa8c37d,
            "preds": _d32f08b6958a,
            "labels": _77428e7c77c5,
            "sample_ids": _4e405e6dee70,
            "chunk_ids": _ae1677c9afec,
            "word_positions": _1524d1291aa5,
            "prompt_lens": _1f5cf4ed0bbc,
            "num_chunks": _80bccdb6ce54,
        }

        self._458028a0936f._85cdac0b11ad(_825956188ba2)

        # Exact same cleanup as before
        del _abfbf829a9d1, _e7ff40bc14fb, _549cb931eb94, _d32f08b6958a, _77428e7c77c5

        return _825956188ba2

    def _04d7b44f4294(self):
        # pick correct device for this rank
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            if _f48500a0e01b._cfcf5fd393bf._eff25c880b7a():
                _e6d5fa3d41bd = _f48500a0e01b._cfcf5fd393bf._fd39d6a9ef45()
            else:
                _e6d5fa3d41bd = 0
            _f48500a0e01b._6666d9d82aa0._2118977ab338(_e6d5fa3d41bd)
            self._e30e1b0d3067 = _f48500a0e01b._d3734ee07a4d(f"cuda:{_e6d5fa3d41bd}")
        else:
            self._e30e1b0d3067 = _f48500a0e01b._d3734ee07a4d("cpu")

        self._81231ba5641e()
        
    def _37c2aa165983(self):
        _f2c4d6b65399 = _06e3dce2cc26(self, "_test_outputs", _fde062d49480)
        _5c659c29e456(f"[DEBUG rank={_f48500a0e01b._cfcf5fd393bf._fd39d6a9ef45()}] outputs_len={_41658cc59397(_f2c4d6b65399)}")
        if not _f2c4d6b65399:
            return

        _b8e795d2323b, _f748e98afcec, _27348f495518, _2ed533ab4e9c = \
            self._bd9882a5dae9(_f2c4d6b65399)

        _a852c5c30106, _71c5a75d5d10 = [], []
        for _20a934414d29 in _3128bffd4d02(_27348f495518._5dd8d2cf740b()):
            _00b84c1d3c5b = _b8e795d2323b[_20a934414d29]._43b41e404a7c()
            _2a45f97ad085 = _f748e98afcec[_20a934414d29]._43b41e404a7c()
            _57635d37c80b = _27348f495518[_20a934414d29]
            _28cc0482dd67 = _2ed533ab4e9c[_20a934414d29]

            if _57635d37c80b._2789915207db() > 0 and _28cc0482dd67._2789915207db() > 0:
                _a852c5c30106._85cdac0b11ad(_57635d37c80b)
                _71c5a75d5d10._85cdac0b11ad(_28cc0482dd67)

        if not _a852c5c30106:
            _5c659c29e456("[TEST END] Nothing to score.")
            self._c4dccb4e4477._18dc810490c2()
            return

        _d8fda41be51e = _f48500a0e01b._5ab0053cde47(_a852c5c30106)._842c6ac46095(_d3734ee07a4d=self._a0a8f128477a['micro_accuracy']._d3734ee07a4d, _c1bd87bff54e=_25457baefff4)
        _e7ff40bc14fb = _f48500a0e01b._5ab0053cde47(_71c5a75d5d10)._842c6ac46095(_d3734ee07a4d=self._a0a8f128477a['micro_accuracy']._d3734ee07a4d, _c1bd87bff54e=_25457baefff4)

        self._a0a8f128477a['micro_accuracy']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_accuracy']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_precision']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_recall']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['macro_f1']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_accuracy']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_precision']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_recall']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['classwise_f1']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)
        self._a0a8f128477a['confmat']._01db6967cfab(_d8fda41be51e, _e7ff40bc14fb)

        _b4d8c052a344  = self._a0a8f128477a['micro_accuracy']._00e73a9c4b52()._77da29428691()
        _4b83a43a907a  = self._a0a8f128477a['macro_accuracy']._00e73a9c4b52()._77da29428691()
        _8039739b0f44 = self._a0a8f128477a['macro_precision']._00e73a9c4b52()._77da29428691()
        _4d9fc7525406    = self._a0a8f128477a['macro_recall']._00e73a9c4b52()._77da29428691()
        _05d44bc94255        = self._a0a8f128477a['macro_f1']._00e73a9c4b52()._77da29428691()

        self._c15b4b686196("test_accuracy", _4b83a43a907a, _1509e21dbb3f=_25457baefff4)

        try:
            _f9d9eb9a8f80 = self._05606ec24357
            _f2c536fac374 = {
                "epoch": [_f9d9eb9a8f80],
                "class_names": [self._7f4a4f9face8],
                "micro_accuracy": [_b4d8c052a344],
                "macro_accuracy": [_4b83a43a907a],
                "macro_precision": [_8039739b0f44],
                "macro_recall": [_4d9fc7525406],
                "macro_f1": [_05d44bc94255],
                "classwise_accuracy": [self._a0a8f128477a['classwise_accuracy']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "classwise_precision": [self._a0a8f128477a['classwise_precision']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "classwise_recall": [self._a0a8f128477a['classwise_recall']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "classwise_f1": [self._a0a8f128477a['classwise_f1']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
                "confusion_matrix": [self._a0a8f128477a['confmat']._00e73a9c4b52()._842c6ac46095(_d3734ee07a4d="cpu")._3e8df47d6a1d()._43b41e404a7c()],
            }
            self._1beab8cec9c7(_f2c536fac374, f"test_final.csv", _e2a085b4bfd8=self._e2a085b4bfd8)
        except _5eff7161c1f8 as _8b232209306f:
            _5c659c29e456(f"[TEST END] save metrics FAILED: {_8b232209306f}")

        # cleanup
        self._a0a8f128477a['micro_accuracy']._d5c06b2ec513(); self._a0a8f128477a['macro_accuracy']._d5c06b2ec513()
        self._a0a8f128477a['macro_precision']._d5c06b2ec513(); self._a0a8f128477a['macro_recall']._d5c06b2ec513(); self._a0a8f128477a['macro_f1']._d5c06b2ec513()
        self._a0a8f128477a['classwise_accuracy']._d5c06b2ec513(); self._a0a8f128477a['classwise_precision']._d5c06b2ec513()
        self._a0a8f128477a['classwise_recall']._d5c06b2ec513(); self._a0a8f128477a['classwise_f1']._d5c06b2ec513()
        self._a0a8f128477a['confmat']._d5c06b2ec513(); self._c4dccb4e4477._18dc810490c2()
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            _f48500a0e01b._6666d9d82aa0._f8460c656ee3()
        _5c659c29e456("[TEST END] Finished and cleaned up.")

    def _2917cb80bb11(self, _c63b4b4896f5, _6443dd53d99b, _103ef1086e39=0):
        """Optimized prediction step with efficient memory handling."""
        _abfbf829a9d1, _ = _c63b4b4896f5
        _abfbf829a9d1 = _abfbf829a9d1._842c6ac46095(self._e30e1b0d3067, _c1bd87bff54e=_25457baefff4)
        _f2c4d6b65399, _, _ = self(_abfbf829a9d1)
        _dee754d8f522 = _f48500a0e01b._ae88595303f9(_f2c4d6b65399, _dd67473f1010=-1)
        del _abfbf829a9d1, _f2c4d6b65399
        if _f48500a0e01b._6666d9d82aa0._820c4a7c86e4():
            _f48500a0e01b._6666d9d82aa0._f8460c656ee3()
        return {"predictions": _dee754d8f522._1b7b65e86ccf()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _33ba75a71a7f(self, _32b070efaccc, _aa0b041fe0d7):
        # if sep token not present then just tuple the tokens and return
        if _aa0b041fe0d7 is _fde062d49480:
            return [(_a6acfb9385e6,) for _a6acfb9385e6 in _32b070efaccc]

        _286a0dc8df72 = []
        _3798c8c9560c = []

        for _a6acfb9385e6 in _32b070efaccc:
            if _a6acfb9385e6 == _aa0b041fe0d7:
                if _3798c8c9560c:
                    _286a0dc8df72._85cdac0b11ad(_7454e608213e(_3798c8c9560c))
                    _3798c8c9560c = []
            else:
                if _aa0b041fe0d7 == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _a6acfb9385e6 in _3798c8c9560c:
                        continue
                    else:
                        _3798c8c9560c._85cdac0b11ad(_a6acfb9385e6)
                    
                else:
                    _3798c8c9560c._85cdac0b11ad(_a6acfb9385e6)

        if _3798c8c9560c:
            _286a0dc8df72._85cdac0b11ad(_7454e608213e(_3798c8c9560c))

        return _286a0dc8df72

    def _4e7795d63ad3(self, _c7a0ef6820d3, _a8f6e1fc0326="exact_match", _3761bcf5d3e1=_fde062d49480):
        if not _c7a0ef6820d3:
            return _3761bcf5d3e1

        if _a8f6e1fc0326 == "exact_match":
            return _c7a0ef6820d3[0] if _6e86e9e05fcf(_93229d4eb685 == _c7a0ef6820d3[0] for _93229d4eb685 in _c7a0ef6820d3) else _3761bcf5d3e1

        if _a8f6e1fc0326 == "most_common":
            return _4f8899ab3d97(_c7a0ef6820d3)._2daa131bd8c6(1)[0][0]

        if _a8f6e1fc0326 == "first":
            return _c7a0ef6820d3[0]

        raise _ba58a9efa402(f"Unknown vote mode: {_a8f6e1fc0326}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _ddc3ec393acf(self, _f2c4d6b65399, _a313af91f61e=_25457baefff4, _99acdb1aabe4="cpu"):
        from collections import _a8b312d7f5dd
        import _f48500a0e01b

        _f88a6d77e3eb = self._6a19ae9660de
        _aa0b041fe0d7 = self._aaf164a1e1f8
        _0933578dd8cf = self._d52481d7001d

        def _0b205dc9237c(_60b1b4282fd0):
            if _4fdb8474d472(_60b1b4282fd0, _f48500a0e01b._531c31acec9b):
                return _60b1b4282fd0._2520f732b87a()._842c6ac46095(_d3734ee07a4d=_99acdb1aabe4)._c6694d44ecb7(-1)._43b41e404a7c()
            return _8fc3a34e211b(_60b1b4282fd0) if _4fdb8474d472(_60b1b4282fd0, (_8fc3a34e211b, _7454e608213e)) else [_60b1b4282fd0]

        _7d7610d3563f = _fedc7fc36b37()
        _c9fb70f816f9 = _a8b312d7f5dd(_8fc3a34e211b)
        _d99bffa5e2e6 = _a8b312d7f5dd(_178a6c94fe0f)
        _fd705df58c00 = []

        if _a313af91f61e:
            _5c659c29e456(f"[reconcile] start: num_outputs={_41658cc59397(_f2c4d6b65399)}")

        for _234bce52b3a5 in _f2c4d6b65399:
            _4e405e6dee70 = _234bce52b3a5["sample_ids"]
            _ae1677c9afec = _234bce52b3a5["chunk_ids"]
            _87ad465db779 = _234bce52b3a5["preds"]
            _f73bcab521b8 = _234bce52b3a5["labels"]
            _1524d1291aa5 = _234bce52b3a5["word_positions"]
            _1f5cf4ed0bbc = _234bce52b3a5["prompt_lens"]
            _2e3f72e5fcdf = _234bce52b3a5["num_chunks"]

            for _5be39fe1c60f, _20a934414d29 in _7c49ec5c2553(_4e405e6dee70):
                _d316a1677015 = _178a6c94fe0f(_ae1677c9afec[_5be39fe1c60f])
                if (_20a934414d29, _d316a1677015) in _7d7610d3563f:
                    continue
                _7d7610d3563f._84040421adb4((_20a934414d29, _d316a1677015))

                _d99bffa5e2e6[_20a934414d29] = _178a6c94fe0f(_2e3f72e5fcdf[_5be39fe1c60f])
                _a3bd0a13cb35 = _178a6c94fe0f(_1f5cf4ed0bbc[_5be39fe1c60f])
                _ae086fd9f52b = _b5ef042c8b8e(_1524d1291aa5[_5be39fe1c60f])
                _79582838b182 = _b5ef042c8b8e(_87ad465db779[_5be39fe1c60f])[_a3bd0a13cb35:]
                _5c4a2d93bd95 = _b5ef042c8b8e(_f73bcab521b8[_5be39fe1c60f])[_a3bd0a13cb35:]

                _3213464c2f43 = [_1c5f021ce483 for _1c5f021ce483 in _79582838b182 if _1c5f021ce483 != _f88a6d77e3eb]
                _8f98d46372bd = [_a15d9df024d6 for _a15d9df024d6 in _5c4a2d93bd95 if _a15d9df024d6 != _f88a6d77e3eb]

                if _20a934414d29 not in _fd705df58c00:
                    _fd705df58c00._85cdac0b11ad(_20a934414d29)

                _c9fb70f816f9[_20a934414d29]._85cdac0b11ad((_d316a1677015, _ae086fd9f52b, _3213464c2f43, _8f98d46372bd))

        _aa8f22d4b6a1 = _fde062d49480
        _b8e795d2323b = {}
        _f748e98afcec = {}

        for _20a934414d29 in _fd705df58c00:
            _30befcb86f12 = _c9fb70f816f9[_20a934414d29]
            if _41658cc59397(_30befcb86f12) != _d99bffa5e2e6[_20a934414d29]:
                if _a313af91f61e:
                    _5c659c29e456(f"Skipping sample {_20a934414d29}: expected {_d99bffa5e2e6[_20a934414d29]} chunks, got {_41658cc59397(_30befcb86f12)}")
                continue

            _30befcb86f12._4e1e341a0aca(_dcfac0885b4b=lambda _60b1b4282fd0: _60b1b4282fd0[0])

            if _aa8f22d4b6a1 is _fde062d49480 and _41658cc59397(_30befcb86f12) > 1:
                _aa8f22d4b6a1 = _20a934414d29

            # Split into words
            _6cd43783c43d = []
            for _d316a1677015, _79fe27c69d57, _796875f2432e, _6a17c476f212 in _30befcb86f12:
                _5f25edf13df0 = self._7de46938d12e(_79fe27c69d57, -1)
                _24ea5864aec4 = self._7de46938d12e(_796875f2432e, _aa0b041fe0d7)
                _55a7ca01e46f = self._7de46938d12e(_6a17c476f212, _aa0b041fe0d7)
                _43a54ad239c8 = _41658cc59397(_5f25edf13df0)
                if _41658cc59397(_24ea5864aec4) < _43a54ad239c8:
                    _24ea5864aec4 += [(_0933578dd8cf,)] * (_43a54ad239c8 - _41658cc59397(_24ea5864aec4))
                if _41658cc59397(_55a7ca01e46f) < _43a54ad239c8:
                    _55a7ca01e46f += [(_f88a6d77e3eb,)] * (_43a54ad239c8 - _41658cc59397(_55a7ca01e46f))
                _6cd43783c43d._85cdac0b11ad((_5f25edf13df0, _24ea5864aec4, _55a7ca01e46f))

            # Vote per word position
            _5cf7217aa025 = _a8b312d7f5dd(_8fc3a34e211b)
            _8ee8af7cee29 = _a8b312d7f5dd(_8fc3a34e211b)
            for _5f25edf13df0, _24ea5864aec4, _55a7ca01e46f in _6cd43783c43d:
                for _0411e1b505a6, _66c73fff8ad0, _4f02b0369cf5 in _dc558b82ddab(_5f25edf13df0, _24ea5864aec4, _55a7ca01e46f):
                    _79fe27c69d57 = _0411e1b505a6[0]
                    _5cf7217aa025[_79fe27c69d57]._85cdac0b11ad(_66c73fff8ad0)
                    _8ee8af7cee29[_79fe27c69d57]._85cdac0b11ad(_4f02b0369cf5)

            _14a245bd7884 = _3128bffd4d02(_5cf7217aa025._5dd8d2cf740b())

            _5f3f9093899c = [self._87f8f0be36ef(_5cf7217aa025[_1c5f021ce483], _a8f6e1fc0326="exact_match", _3761bcf5d3e1=(_0933578dd8cf,)) for _1c5f021ce483 in _14a245bd7884]
            _29a44bfd106c = []
            for _1c5f021ce483 in _14a245bd7884:
                _d98afba08d20 = _8ee8af7cee29[_1c5f021ce483]
                _d2af335f10fa = self._87f8f0be36ef(_d98afba08d20, _a8f6e1fc0326="exact_match", _3761bcf5d3e1=_fde062d49480)
                if _d2af335f10fa is _fde062d49480:
                    for _4982a63b90e6 in _d98afba08d20:
                        if _f88a6d77e3eb not in _4982a63b90e6:
                            _d2af335f10fa = _4982a63b90e6
                            break
                    if _d2af335f10fa is _fde062d49480:
                        _d2af335f10fa = _d98afba08d20[0]
                _29a44bfd106c._85cdac0b11ad(_d2af335f10fa)

            # Reconstruct
            _9b4533c39940 = []
            _c1329e47297f = []
            for _5be39fe1c60f in _71df794e6854(_41658cc59397(_14a245bd7884)):
                _9b4533c39940._ab67d2ee705c(_5f3f9093899c[_5be39fe1c60f])
                _c1329e47297f._ab67d2ee705c(_29a44bfd106c[_5be39fe1c60f])
                if _5be39fe1c60f < _41658cc59397(_14a245bd7884) - 1:
                    _9b4533c39940._85cdac0b11ad(_aa0b041fe0d7)
                    _c1329e47297f._85cdac0b11ad(_aa0b041fe0d7)

            _5c659c29e456(f"check labels final {(_ffca1243e92f(1 for _60b1b4282fd0 in _c1329e47297f if _60b1b4282fd0 == _aa0b041fe0d7))}")

            _b8e795d2323b[_20a934414d29] = _f48500a0e01b._072a3d87f816(_9b4533c39940, _d3734ee07a4d=_99acdb1aabe4)
            _f748e98afcec[_20a934414d29] = _f48500a0e01b._072a3d87f816(_c1329e47297f, _d3734ee07a4d=_99acdb1aabe4)

        if _a313af91f61e and _aa8f22d4b6a1 is not _fde062d49480:
            _5c659c29e456(f"[SUMMARY] reconciled samples in batch = {_41658cc59397(_fd705df58c00)} "
                f"sid={_aa8f22d4b6a1} total_preds={_41658cc59397(_b8e795d2323b[_aa8f22d4b6a1])} "
                f"total_labels={_41658cc59397(_f748e98afcec[_aa8f22d4b6a1])} "
                f"raw_preds {_b8e795d2323b[_aa8f22d4b6a1]} and raw_labels {_f748e98afcec[_aa8f22d4b6a1]} "
                f"chunks {_c9fb70f816f9[_aa8f22d4b6a1]}")

        _f2c36979849b = _ffca1243e92f(_41658cc59397(_a15d9df024d6) for _a15d9df024d6 in _f748e98afcec._c7a0ef6820d3())
        _5c659c29e456(f"Total reconciled labels: {_f2c36979849b}")

        _f1e7a7eb1a71, _7a1fe6e4f47a = self._10f94c7fecc1(
            _b8e795d2323b, _f748e98afcec, _a313af91f61e=_a313af91f61e, _99acdb1aabe4=_99acdb1aabe4
        )
        _636321bc1cca = _ffca1243e92f(_41658cc59397(_a15d9df024d6) for _a15d9df024d6 in _7a1fe6e4f47a._c7a0ef6820d3())
        _5c659c29e456(f"Total reconciled labels classes: {_636321bc1cca}")

        _92b3ebd1883f = _f48500a0e01b._cfcf5fd393bf._fd39d6a9ef45() if _f48500a0e01b._cfcf5fd393bf._eff25c880b7a() else -1
        _5c659c29e456(f"Rank {_92b3ebd1883f} samples are {_fd705df58c00}")

        return _b8e795d2323b, _f748e98afcec, _f1e7a7eb1a71, _7a1fe6e4f47a

    def _e7710adf800b(self, _b8e795d2323b, _f748e98afcec, _a313af91f61e=_25457baefff4, _99acdb1aabe4="cpu"):
        _6e30ef406327 = _06e3dce2cc26(self, "seq2class", {})
        _aa0b041fe0d7 = _06e3dce2cc26(self, "tokenizer_separator_token", _fde062d49480)
        _f88a6d77e3eb = _06e3dce2cc26(self, "ignore_idx", -100)
        
        def _a29287f562a4(_32b070efaccc, _7bc2f2c2d418):
            _286a0dc8df72 = []
            _3427bbd65725 = []
            for _5be39fe1c60f, token in _7c49ec5c2553(_32b070efaccc):
                if token == _7bc2f2c2d418 and _3427bbd65725:
                    _286a0dc8df72._85cdac0b11ad(_3427bbd65725)
                    _3427bbd65725 = []
                elif token != _7bc2f2c2d418:
                    _3427bbd65725._85cdac0b11ad(token)
            if _3427bbd65725:
                _286a0dc8df72._85cdac0b11ad(_3427bbd65725)
            return _286a0dc8df72
        
        def _b4cc065ecaf2(_c3bc18290af1, _6e30ef406327, _a313af91f61e, _20a934414d29):
            _234bce52b3a5 = []
            _3c93aaf11b4b = _3128bffd4d02(_6e30ef406327._5dd8d2cf740b(), _dcfac0885b4b=_41658cc59397, _702430815fa0=_25457baefff4)
            for _5be39fe1c60f, _9de18a6f1c06 in _7c49ec5c2553(_c3bc18290af1, 1):
                _fa337545085c = _7454e608213e(_9de18a6f1c06)
                _95e54c451fe0 = self._d52481d7001d
                for _dcfac0885b4b in _3c93aaf11b4b:
                    if _41658cc59397(_fa337545085c) >= _41658cc59397(_dcfac0885b4b) and _fa337545085c[:_41658cc59397(_dcfac0885b4b)] == _dcfac0885b4b:
                        _95e54c451fe0 = _6e30ef406327[_dcfac0885b4b]
                        break
                _234bce52b3a5._85cdac0b11ad(_95e54c451fe0)

            return _234bce52b3a5
        
        _27348f495518, _2ed533ab4e9c = {}, {}
        for _20a934414d29 in _b8e795d2323b:
            _1c5f021ce483 = _b8e795d2323b[_20a934414d29]
            _a15d9df024d6 = _f748e98afcec._2aa253a0a485(_20a934414d29, _fde062d49480)
            _d8fda41be51e = _1c5f021ce483._43b41e404a7c() if _4fdb8474d472(_1c5f021ce483, _f48500a0e01b._531c31acec9b) else _8fc3a34e211b(_1c5f021ce483)
            _e7ff40bc14fb = _a15d9df024d6._43b41e404a7c() if _4fdb8474d472(_a15d9df024d6, _f48500a0e01b._531c31acec9b) else _8fc3a34e211b(_a15d9df024d6) if _a15d9df024d6 else _fde062d49480
            if _e7ff40bc14fb is not _fde062d49480:
                _c663916bb1bf = _be908cec5f2e(_e7ff40bc14fb, _aa0b041fe0d7)
                _e084b392f03d = _e31f75975da9(_c663916bb1bf, _6e30ef406327, _20a934414d29 == 1 or _a313af91f61e, _20a934414d29)
                _e0714d940cd0 = _be908cec5f2e(_d8fda41be51e, _aa0b041fe0d7)
                _db9359ace22a = _e31f75975da9(_e0714d940cd0, _6e30ef406327, _20a934414d29 == 1 or _a313af91f61e, _20a934414d29)
                if _41658cc59397(_db9359ace22a) < _41658cc59397(_e084b392f03d):
                    _db9359ace22a += [0] * (_41658cc59397(_e084b392f03d) - _41658cc59397(_db9359ace22a))
                elif _41658cc59397(_db9359ace22a) > _41658cc59397(_e084b392f03d):
                    _db9359ace22a = _db9359ace22a[:_41658cc59397(_e084b392f03d)]
            else:
                _e0714d940cd0 = _be908cec5f2e(_d8fda41be51e, _aa0b041fe0d7)
                _db9359ace22a = _e31f75975da9(_e0714d940cd0, _6e30ef406327, _20a934414d29 == 1 or _a313af91f61e, _20a934414d29)
                _e084b392f03d = [_f88a6d77e3eb] * _41658cc59397(_db9359ace22a)
            _27348f495518[_20a934414d29] = _f48500a0e01b._072a3d87f816(_db9359ace22a, _d3734ee07a4d=_99acdb1aabe4, _6aaf82c98abb=_f48500a0e01b._f23c04314681)
            _2ed533ab4e9c[_20a934414d29] = _f48500a0e01b._072a3d87f816(_e084b392f03d, _d3734ee07a4d=_99acdb1aabe4, _6aaf82c98abb=_f48500a0e01b._f23c04314681)
        return _27348f495518, _2ed533ab4e9c

    def _7bbae4abec99(self, _7c5aa5eeffd2):
        _f48500a0e01b._a14f528d8ccf._87ac4f75d94b._bb37265afef2(self._535c9c383ae3(), _c5a3ee5d854c=1.0)
    
    def _3b78249ebd84(self, _7c5aa5eeffd2):
        for _2be54c205a42 in self._535c9c383ae3():
            if _2be54c205a42 is not _fde062d49480:
                _2be54c205a42._9fa160a191f5._6d4f1642a059(-5, 5)

    def _061aeea6b2bc(self):
        _7703546abbde = 0
        for _2be54c205a42 in self._535c9c383ae3():
            if _2be54c205a42._da049a5c5134 is not _fde062d49480:
                _ac2cc072c83d = _2be54c205a42._da049a5c5134._2520f732b87a()._9fa160a191f5._5f899433615b(2)
                _7703546abbde += _ac2cc072c83d._77da29428691() ** 2
        return _7703546abbde ** 0.5  # L2 norm

    def _823d2cf9e77c(self):
        _01c2b39e1be3 = [_1c5f021ce483 for _1c5f021ce483 in self._535c9c383ae3() if _1c5f021ce483._6c479b5ca8d0]
        if not _01c2b39e1be3:
            _5c659c29e456("No trainable parameters. Skipping optimizer creation.")
            return _fde062d49480
        
        _9420e161b507 = _063bc057591d(lambda _1c5f021ce483: _1c5f021ce483._6c479b5ca8d0, self._535c9c383ae3())

        _e1c542149461 = {
            "adamw": _f48500a0e01b._478bfbaa61fe._6bd16d21c463,
            "adamax": _f48500a0e01b._478bfbaa61fe._59b75c6d2623,
            "adam": _f48500a0e01b._478bfbaa61fe._d89190f23151,
        }
        _207e84adf3dc = _e1c542149461._2aa253a0a485(self._9e91e008c947._0fd237fb0a16(), _f48500a0e01b._478bfbaa61fe._d89190f23151)

        _7c5aa5eeffd2 = _207e84adf3dc(_9420e161b507, _22ff6f4e762c=self._7a6f6c01fb7b._22ff6f4e762c, _ebfb620e01d3=0.001)

        _a618826aba3b = self._48fe8453a91c._d8abcb29782c
        _11693d4a6da6 = math._98361d6cd442(0.1 * _a618826aba3b)

        _7ceafc05c032 = _f48500a0e01b._478bfbaa61fe._6193771ba72a._d3ec96d8e5bd(_7c5aa5eeffd2, _d381faccafbd=lambda _f1411ced47eb: (_f1411ced47eb + 1) / _11693d4a6da6)

        _324410ccefc3 = _f48500a0e01b._478bfbaa61fe._6193771ba72a._ffa2a073bee8(
            _7c5aa5eeffd2,
            _20470d2614bd=_5b679c251c3c(1, _a618826aba3b - _11693d4a6da6),
            _2e81e24af946=2,
            _f107e7d9d5c9=1e-6
        )
        _6193771ba72a = _f48500a0e01b._478bfbaa61fe._6193771ba72a._857b1a32276c(
            _7c5aa5eeffd2,
            _11307ba1b47a=[_7ceafc05c032, _324410ccefc3],
            _11ac25c67ab2=[_11693d4a6da6]
        )
        return {"optimizer": _7c5aa5eeffd2, "lr_scheduler": {"scheduler": _6193771ba72a, "interval": "epoch", "monitor": "val_loss"}}
