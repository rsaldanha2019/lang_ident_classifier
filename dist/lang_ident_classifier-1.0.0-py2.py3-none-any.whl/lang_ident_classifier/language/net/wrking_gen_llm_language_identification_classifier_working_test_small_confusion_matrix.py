# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from _ff7c7e710767 import _d06d4c6bbced, _fa4fb0583108
import _3067f99ea81d
from _1e86dd0ffdb3 import _5055f585e29f
import _2caf4d4ffc93
import _de060d8085c7
import _74fb9aa7f514
from _989345b7f06e import _fe97b84bb73e
import _bf911228b3ff as _875fb12df564
import _31636bff101e as _0e8d54809917
import _50728aa02373
import _ddc93e43d448 as _4bbb38dc440d
from _ed66ea140a9f._b9f7c75c94f8._e8ee6ddad47b._975eeaa07957 import _036caf2fe316
from _9e38ee69a01f import _57708472dbd4, _9c60495d4660, _2278adb3ab6d, _b02b352481fd, _43b56d4a0e68

from _71ae5b108947._8745d5d89094._d415863e5bfb._c35a465ac64b import _afbf8cfe8c56
from _71ae5b108947._8745d5d89094._e7592f5d5e29._c0ee7be8a825 import _d618edfe79ab
from _71ae5b108947._8745d5d89094._e7592f5d5e29._eb29a3776ee7 import _2e2eab4a5b5f
from _71ae5b108947._8745d5d89094._e7592f5d5e29._00cd875277f3 import _d431e17bc69d
from _71ae5b108947._8745d5d89094._d6f3c712f05a._1e7133c3065b import _dad968ac212c
# expose only the classifier from the module
_b359a3ca743b = ["GenLLMLanguageIdentificationClassifier"]

_296edaa1c16a = 'cuda' if _50728aa02373._86caffea6183._bc68d1594d5e() else 'cpu'
_aaddbf5f0339 = _4e161416dfa9  # global frozen embedding (kept for compatibility)

    
class _fcceb9079b9f(_4bbb38dc440d._daab09d3c746):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _84b2c966ff99(_50728aa02373._d3b8f44143da._21a6465612a5):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _675c48b80b6c(self, _4c6e2a0ae971: _277691fccdf2, _86253ea2cc5e: _277691fccdf2 = 64):
            _5568537f94ca()._73322ec0daf7()
            self._ba5e22e29ccf = _50728aa02373._d3b8f44143da._803e4620cf15(_4c6e2a0ae971, _86253ea2cc5e, _300eb89ae703=_733fe1034e95)
            self._769a5d9a849d = _50728aa02373._d3b8f44143da._1a00f07c4771(_4c200eb46e4c=_8d98d45589f8)
            self._491fa48830de = _50728aa02373._d3b8f44143da._803e4620cf15(_86253ea2cc5e, _4c6e2a0ae971, _300eb89ae703=_733fe1034e95)
            # start adapter near-zero so initial behavior is identity
            _50728aa02373._d3b8f44143da._11f31b35e285._6b9f69e0c749(self._491fa48830de._ffe606be17ca)
            _50728aa02373._d3b8f44143da._11f31b35e285._80f7dfb2134e(self._ba5e22e29ccf._ffe606be17ca, _a73c1dfc31bc=_de060d8085c7._a4ec9ebcf3aa(5))

        def _57a9aff592ed(self, _fad7522cb3b4: _50728aa02373._9bb48afd74d0) -> _50728aa02373._9bb48afd74d0:
            # supports x shape (B, L, D) or (B, D)
            if _fad7522cb3b4._4c6e2a0ae971() == 2:
                _bb4b7969453b = self._491fa48830de(self._769a5d9a849d(self._ba5e22e29ccf(_fad7522cb3b4)))
                return _fad7522cb3b4 + _bb4b7969453b
            _8abe87455a2b, _904783ff4d2c, _900ed70b1daf = _fad7522cb3b4._737b7dd3f8c6
            _1cdfbda869be = _fad7522cb3b4._4079008bd9bf(-1, _900ed70b1daf)                    # (B*L, D)
            _1cdfbda869be = self._491fa48830de(self._769a5d9a849d(self._ba5e22e29ccf(_1cdfbda869be)))  # (B*L, D)
            _1cdfbda869be = _1cdfbda869be._4079008bd9bf(_8abe87455a2b, _904783ff4d2c, _900ed70b1daf)
            return _fad7522cb3b4 + _1cdfbda869be
        
    class _f030a2e3d91e(_50728aa02373._d3b8f44143da._21a6465612a5):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _675c48b80b6c(self, _d572260d4d6c, _370a34f2f0c2=-5, _b2ad2c7c7a1d=5):
            _5568537f94ca()._73322ec0daf7()
            self._d572260d4d6c = _d572260d4d6c
            self._370a34f2f0c2 = _370a34f2f0c2
            self._b2ad2c7c7a1d = _b2ad2c7c7a1d
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _57a9aff592ed(self, *_70ffd20fa17a, **_e58ddb25912e):
            _70ffd20fa17a = _1f90b9ebd29c(
                _1cc86ae81512._133eaee48b67(_50728aa02373._80133e122f6b)._8de3621ee020(-10, 10) if _e45cbc4997b7(_1cc86ae81512, _50728aa02373._9bb48afd74d0) and _1cc86ae81512._3cd1c5f8fa33 != _50728aa02373._80133e122f6b else _1cc86ae81512
                for _1cc86ae81512 in _70ffd20fa17a
            )
            for _24518f80a818, _1cc86ae81512 in _27b400510198(_70ffd20fa17a):
                if _e45cbc4997b7(_1cc86ae81512, _50728aa02373._9bb48afd74d0) and not _50728aa02373._6bd0794a1a72(_1cc86ae81512)._dd269ea88fc6():
                    _1cc86ae81512 = _50728aa02373._ed74b98214da(_1cc86ae81512)
            _45034f21fc97 = self._d572260d4d6c(*_70ffd20fa17a, **_e58ddb25912e)
            if _e45cbc4997b7(_45034f21fc97, _50728aa02373._9bb48afd74d0):
                _45034f21fc97 = _45034f21fc97._133eaee48b67(_50728aa02373._80133e122f6b)
                if not _50728aa02373._6bd0794a1a72(_45034f21fc97)._dd269ea88fc6():
                    _45034f21fc97 = _50728aa02373._ed74b98214da(_45034f21fc97)
                _45034f21fc97._0728f2256900(self._370a34f2f0c2, self._b2ad2c7c7a1d)
            return _45034f21fc97

    # --- original __init__ signature and body preserved ---
    def _675c48b80b6c(
        self,
        _713bb3570cd0,
        _99086f9b4551,
        _b47245a4392b,
        _8e084a53c4d8,
        _6e13b57e4677,
        _6a2fe3460c5f,
        _3f9aebd20280,
        _ea22d295b602,
        _b5c8a39acd98,
        _03c71a9e4d2c,
        _7a6103c6e36f,
        _109b35663ff1: _277691fccdf2 = 20,
        _49330ae4e14d = _4e161416dfa9,
        _a40bef14b76e=_4e161416dfa9,
        _79534ec913b1=0.9,
        _a7b2e675f685:_3e86fabb7c0a=_4e161416dfa9,
    ):
        _5568537f94ca(_2db12a9253a9, self)._73322ec0daf7()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._e766fe93084a({
            "lr": _da8d82bb517e(_b47245a4392b),
            "optimizer": _3e86fabb7c0a(_8e084a53c4d8),
            "num_backbone_model_units_unfrozen": _277691fccdf2(_3f9aebd20280),
            "loss_type": _3e86fabb7c0a(_ea22d295b602),
            "is_train": _0f94627d7bb1(_b5c8a39acd98),
            "random_seed": _277691fccdf2(_109b35663ff1),
        })
        self._109b35663ff1 = _109b35663ff1
        _4bbb38dc440d._a53155653897(_109b35663ff1, _024566f351c6=_8d98d45589f8)
        _50728aa02373._32a41af90874(_109b35663ff1)
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            _50728aa02373._86caffea6183._3b8a9871116b(_109b35663ff1)
        _875fb12df564._5898c4b16e34._5d0ca55bd2d0(_109b35663ff1)
        self._a40bef14b76e = _277691fccdf2(_a40bef14b76e) if _a40bef14b76e is not _4e161416dfa9 else _4e161416dfa9
        self._03c71a9e4d2c = _03c71a9e4d2c
        self._a7b2e675f685 = _a7b2e675f685
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._03c71a9e4d2c._f35d8a11d7cb and "<PAD>" not in self._03c71a9e4d2c._3d5f65b4e17a():
            self._03c71a9e4d2c._bfb04b2ef49c(["<PAD>"], _c0119eb93097=_733fe1034e95)
            _07deb276f0a1 = self._03c71a9e4d2c._c9828c22ed37("<PAD>")
            _8ae9b9c98c60(f"Added padding token  <PAD> with (id: {_07deb276f0a1})")
        
        self._8caeeff61dbb = _03c71a9e4d2c._c5e9b17ba8d8(" ", _497d8ac3f9ad=_733fe1034e95)[0]
        self._000fec14525f = (
            _50728aa02373._d8e1905f3566("cuda:{}"._411deb4a3e82(_6a2fe3460c5f["gpu_local_rank"]))
            if _6a2fe3460c5f["gpu_local_rank"] != -1
            else "cpu"
        )
        self._49330ae4e14d = _49330ae4e14d
        self._79534ec913b1 = _79534ec913b1
        self._99086f9b4551 =  ["unk"] + _99086f9b4551 if self._79534ec913b1 > 0 else _99086f9b4551
        self._723bb162ab3a = _c04de5307634(self._99086f9b4551)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._c761d711dfea = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _80ddacb6318e in self._99086f9b4551:
            if _c04de5307634(self._03c71a9e4d2c._c5e9b17ba8d8(_80ddacb6318e, _497d8ac3f9ad=_733fe1034e95)) > 1:
                _e9ffb10f5130 = f"{_80ddacb6318e}"
                if _e9ffb10f5130 not in self._03c71a9e4d2c._3d5f65b4e17a():
                    self._03c71a9e4d2c._bfb04b2ef49c([_e9ffb10f5130], _c0119eb93097=_733fe1034e95)
                    _07deb276f0a1 = self._03c71a9e4d2c._c9828c22ed37(_e9ffb10f5130)
                    _8ae9b9c98c60(f"Added class '{_80ddacb6318e}' Token: {_e9ffb10f5130} (id: {_07deb276f0a1})")

        # Map every class to single token ID
        self._c761d711dfea = {
            _1cada371c5cf: [self._03c71a9e4d2c._c9828c22ed37(f"{_80ddacb6318e}")]
            for _1cada371c5cf, _80ddacb6318e in _27b400510198(self._99086f9b4551)
        }

        self._1dfe0f012e02 = {_1f90b9ebd29c(_bb28ee0c0643): _d14e0fb7d5ee for _d14e0fb7d5ee, _bb28ee0c0643 in self._c761d711dfea._d8b38bb8f910()}
        self._6e320a579a39 = _fa4fb0583108(_4ccaf31d72a4)
        for _445a5201f3d1, _bb28ee0c0643 in self._c761d711dfea._d8b38bb8f910():
            self._6e320a579a39[_c04de5307634(_bb28ee0c0643)]._97193a8ff77c((_445a5201f3d1, _bb28ee0c0643))
        self._5a6f43beb02f = 0
        _8ae9b9c98c60(f"SEQ {self._c761d711dfea} and {self._1dfe0f012e02}")
        self._e75c97e4d3f8 = _03c71a9e4d2c._f35d8a11d7cb or _03c71a9e4d2c._35f2fd37c3d0
        self._6e13b57e4677 = _6e13b57e4677
        self._3e36e13fabdd = "multiclass"
        self._ed5cd2d40289 = -100
        self._7b21f33f2a71 = _03c71a9e4d2c._c5e9b17ba8d8("assistant<|end_header_id|>\n\n", _497d8ac3f9ad=_733fe1034e95)
        self._4e4d1d0b55cb = self._7ac884f2b37e()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._d5e238974d52 = _713bb3570cd0
        # Resize vocab based token embeddings
        self._d5e238974d52._9820836a31cb(_c04de5307634(self._03c71a9e4d2c))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._d5e238974d52._02a7827a4af9(_733fe1034e95)
        _f41a2e9b7da0 = _dad968ac212c()  # bfloat16 or float16

        for _48caeb1e0f4e, _d572260d4d6c in self._86e36be470c7():
            if not _ebfb2cb98082(_7bc116611282._42db6d892803 for _7bc116611282 in _d572260d4d6c._64d8707f1003(_61d6f831f867=_733fe1034e95)):
                # FROZEN → BF16 (save memory)
                _d572260d4d6c._133eaee48b67(_3cd1c5f8fa33=_f41a2e9b7da0)
            else:
                # TRAINABLE → FP32 (stable grads)
                _d572260d4d6c._133eaee48b67(_3cd1c5f8fa33=_50728aa02373._80133e122f6b)
        self._d5e238974d52._133eaee48b67(self._000fec14525f)
        if _de7b27dafe88(self._d5e238974d52, "gradient_checkpointing_enable"):
            self._d5e238974d52._1531c4c7a9bc()
        # determine embedding dim robustly from model config if available
        _0cda3913524e = _c4a85c64eacb(_c4a85c64eacb(self._d5e238974d52, "config", _4e161416dfa9), "hidden_size", _4e161416dfa9)
        if _0cda3913524e is _4e161416dfa9:
            # fallback to common default — change if your model uses a different hidden size
            _0cda3913524e = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _de7b27dafe88(self._d5e238974d52, "lm_head") and _c4a85c64eacb(self._d5e238974d52, "lm_head") is not _4e161416dfa9:
            self._973b0a7997c5 = self._d5e238974d52._ab5b0009e289
        else:
            _ab3b6950f39f = _c4a85c64eacb(self._d5e238974d52, "get_output_embeddings", _4e161416dfa9)
            self._973b0a7997c5 = _ab3b6950f39f() if _9be208921e62(_ab3b6950f39f) else _4e161416dfa9

        # mark presence and ensure module (if any) is on the same device
        self._811350139ebf = self._973b0a7997c5 is not _4e161416dfa9
        if self._811350139ebf:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._973b0a7997c5._133eaee48b67(self._000fec14525f)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._b11e34f3ddde = self._fd443c6e17cb(_4c6e2a0ae971=_0cda3913524e, _86253ea2cc5e=64)
        self._b11e34f3ddde._133eaee48b67(self._000fec14525f)
        for _7bc116611282 in self._b11e34f3ddde._64d8707f1003():
            _7bc116611282._42db6d892803 = _8d98d45589f8
            
        if _3f9aebd20280 > 0:
            if "llama" in self._49330ae4e14d:
                for _d6f10372766c in self._d5e238974d52._64d8707f1003():
                    if not _d6f10372766c._6d1d3bcbc375:
                        _d6f10372766c = _d6f10372766c._b3ebf0b67645()
                    _d6f10372766c._42db6d892803 = _733fe1034e95  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _5343eacabb3f = self._d5e238974d52._4fc99418b240._7219250b351c  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _9a97b26e6795 in _5343eacabb3f[-_3f9aebd20280:]:
                    for _d6f10372766c in _9a97b26e6795._64d8707f1003():
                        if _e45cbc4997b7(_d6f10372766c, _50728aa02373._9bb48afd74d0) and (_d6f10372766c._176796edbb6a() or _50728aa02373._6a3ab743f9cd(_d6f10372766c)):
                            _d6f10372766c._42db6d892803 = _8d98d45589f8
                if _de7b27dafe88(self._d5e238974d52, "lm_head"):
                    self._d5e238974d52._ab5b0009e289._42db6d892803 = _8d98d45589f8

        self._778b44e67806 = 1
        _8ae9b9c98c60(f"DEBUG xth_batch init {self._778b44e67806}")
        global _aaddbf5f0339
        _aaddbf5f0339 = _3067f99ea81d._09a1398e8c5d(self._d5e238974d52)._01d8826773df()
        self._b47245a4392b = _b47245a4392b

        self._8eb29399dccb = {}
        self._14b999b194e4 = {}

        # Loss function initialization
        if _ea22d295b602._300a5bb1e6e6() == "class_weighted_cross_entropy_loss":
            self._14b999b194e4['criterion'] = _2e2eab4a5b5f(_6e13b57e4677=self._6e13b57e4677,
                                                            _d8e1905f3566=self._000fec14525f,
                                                            _a82cdf733388=self._ed5cd2d40289,
                                                            _59e68124ef8d=self._8caeeff61dbb)
        elif _ea22d295b602._300a5bb1e6e6() == "focal_loss":
            self._14b999b194e4['criterion'] = _d431e17bc69d(_1ac0041a770c=0.25,
                                                     _d8e1905f3566=self._000fec14525f,
                                                     _a82cdf733388=self._ed5cd2d40289,
                                                     _59e68124ef8d=self._8caeeff61dbb)
        elif _ea22d295b602._300a5bb1e6e6() == "class_weighted_focal_loss":
            self._14b999b194e4['criterion'] = _d431e17bc69d(_1ac0041a770c=self._6e13b57e4677,
                                                     _d8e1905f3566=self._000fec14525f,
                                                     _a82cdf733388=self._ed5cd2d40289,
                                                     _59e68124ef8d=self._8caeeff61dbb)
        elif _ea22d295b602._300a5bb1e6e6() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._14b999b194e4['criterion'] = _d618edfe79ab(_1ac0041a770c=self._6e13b57e4677,
                                                                      _390cc71fbfec='type1',
                                                                      _d8e1905f3566=self._000fec14525f,
                                                                      _a82cdf733388=self._ed5cd2d40289,
                                                                      _59e68124ef8d=self._8caeeff61dbb)
        elif _ea22d295b602._300a5bb1e6e6() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._14b999b194e4['criterion'] = _d618edfe79ab(_1ac0041a770c=self._6e13b57e4677,
                                                                      _390cc71fbfec='type2',
                                                                      _d8e1905f3566=self._000fec14525f,
                                                                      _a82cdf733388=self._ed5cd2d40289,
                                                                      _59e68124ef8d=self._8caeeff61dbb)
        elif _ea22d295b602._300a5bb1e6e6() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._14b999b194e4['criterion'] = _d618edfe79ab(_1ac0041a770c=self._6e13b57e4677,
                                                                      _390cc71fbfec='type3',
                                                                      _d8e1905f3566=self._000fec14525f,
                                                                      _a82cdf733388=self._ed5cd2d40289,
                                                                      _59e68124ef8d=self._8caeeff61dbb)
        else:
            self._14b999b194e4['criterion'] = _2e2eab4a5b5f(_d8e1905f3566=self._000fec14525f,
                                                            _a82cdf733388=self._ed5cd2d40289,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._2c640fa5c3ac = 0.99
        self._c69a05ab4476 = 0.3
        self._4c67a79ca4fe = 0.30
        self._e8b47d795dba = 0.25
        self._a53cb3366a8c = 0.6
        self._bfd6c828590d = 0.995
        self._02d5a0c81c5f = 0.60
        self._6c4ec4039359 = 0.20
        self._eb89a088ca97 = _c4a85c64eacb(self, "batch_counter", 0)


        self._cf1eb66602b9 = []
        self._65862cee0737 = []

        self._14ac7b3739ac = _8e084a53c4d8._300a5bb1e6e6()
        self._5d1b62c273ba()

        self._a1e9598ed43e(self._d5e238974d52)
    
    def _674b289efdbe(self):
        # rebuild all metrics on the correct device
        self._8eb29399dccb['micro_accuracy'] = _57708472dbd4(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e="micro",
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['macro_accuracy'] = _57708472dbd4(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e="macro",
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['macro_precision'] = _2278adb3ab6d(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e="macro",
            _b54adf766ae6=self. _3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['macro_recall'] = _b02b352481fd(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e="macro",
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['macro_f1'] = _43b56d4a0e68(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e="macro",
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['classwise_accuracy'] = _57708472dbd4(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e=_4e161416dfa9,
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['classwise_precision'] = _2278adb3ab6d(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e=_4e161416dfa9,
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['classwise_recall'] = _b02b352481fd(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e=_4e161416dfa9,
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['classwise_f1'] = _43b56d4a0e68(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _1599f6c1c06e=_4e161416dfa9,
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)

        self._8eb29399dccb['confmat'] = _9c60495d4660(
            _723bb162ab3a=_c04de5307634(self._99086f9b4551),
            _b54adf766ae6=self._3e36e13fabdd,
            _a82cdf733388=self._ed5cd2d40289,
        )._133eaee48b67(self._000fec14525f)


    def _3e1b865ddadb(self, _e57c428629f3=_4e161416dfa9):
        """Calculate batch counts and set xth_batch_to_consider."""
        _067a5f4076f7 = 0
        _11e41fd668b7 = 0
        if self._643f30b37f38._25e6427ffb5e is not _4e161416dfa9:
            if _de7b27dafe88(self._643f30b37f38._25e6427ffb5e, 'train_dataset') and self._643f30b37f38._25e6427ffb5e._44be8ca2dca3 is not _4e161416dfa9:
                _067a5f4076f7 = _c04de5307634(self._643f30b37f38._25e6427ffb5e._44be8ca2dca3)
            if _de7b27dafe88(self._643f30b37f38._25e6427ffb5e, 'val_dataset') and self._643f30b37f38._25e6427ffb5e._940799444eb9 is not _4e161416dfa9:
                _11e41fd668b7 = _c04de5307634(self._643f30b37f38._25e6427ffb5e._940799444eb9)
            _a5b0f5a9be77 = self._643f30b37f38._25e6427ffb5e._a5b0f5a9be77
            _927c8d999ce9 = (_067a5f4076f7 + _a5b0f5a9be77 - 1) // _a5b0f5a9be77 if _067a5f4076f7 > 0 else 1
            _f129e49e13b7 = (_11e41fd668b7 + _a5b0f5a9be77 - 1) // _a5b0f5a9be77 if _11e41fd668b7 > 0 else 1
            _22387081bfb2 = _2e646843503f(_927c8d999ce9, _f129e49e13b7) if _11e41fd668b7 > 0 else _927c8d999ce9
            _7f10dc140485 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._778b44e67806 = 1
            _8ae9b9c98c60(f"DEBUG Batch Info: num_train_batches={_927c8d999ce9}, num_val_batches={_f129e49e13b7}, xth_batch_to_consider={self._778b44e67806}")

    def _aae82795ade3(self, _f21b8635a3f0, _21b2325436d0):
        if _f21b8635a3f0._300a5bb1e6e6() == "parametric_relu":
            return _50728aa02373._d3b8f44143da._3b4cae2b3168(_21b2325436d0=1)
        elif _f21b8635a3f0._300a5bb1e6e6() == "leaky_relu":
            return _50728aa02373._d3b8f44143da._6e0efb78eb76(_4c200eb46e4c=_733fe1034e95)
        else:
            return _50728aa02373._d3b8f44143da._1a00f07c4771(_4c200eb46e4c=_733fe1034e95)

    def _bd828b9e9988(self, _d572260d4d6c, _539fb3ae071b=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _48caeb1e0f4e, _c144f620b9fd in _d572260d4d6c._278f63ceb3a0():
            _3c1da2cace15 = f"{_539fb3ae071b}.{_48caeb1e0f4e}" if _539fb3ae071b else _48caeb1e0f4e

            def _6282b3ec02df(_919fe18fe477, _1cc86ae81512, _bb4b7969453b):
                if _e45cbc4997b7(_bb4b7969453b, _50728aa02373._9bb48afd74d0) and _bb4b7969453b._96f20c3d83a7()._ebfb2cb98082():
                    _8ae9b9c98c60(f"NaN detected in {_3c1da2cace15} ({_919fe18fe477._20bc74a45dd3.__name__}) ({_bb4b7969453b._3cd1c5f8fa33})")

            _c144f620b9fd._5662c253beb0(_e7b565f8584e)

            self._a1e9598ed43e(_c144f620b9fd, _3c1da2cace15)

    def _b7144e3edc05(self, _d572260d4d6c):
        return _ebfb2cb98082(_7bc116611282._42db6d892803 for _7bc116611282 in _d572260d4d6c._64d8707f1003())

    def _973c516b477e(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _5b572cb1ebfe = []
        for _48caeb1e0f4e, _d572260d4d6c in self._86e36be470c7():
            if not self._4d96b58c6aea(_d572260d4d6c):
                continue
            _4413d71aa24a = (
                "norm" in _48caeb1e0f4e._685365dcc0e7() or 
                "linear4bit" in _48caeb1e0f4e._685365dcc0e7() or 
                _ebfb2cb98082(_769a5d9a849d in _48caeb1e0f4e._685365dcc0e7() for _769a5d9a849d in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _48caeb1e0f4e._685365dcc0e7() or 
                "dropout" in _48caeb1e0f4e._685365dcc0e7() or 
                _e45cbc4997b7(_d572260d4d6c, (_036caf2fe316, _50728aa02373._d3b8f44143da._803e4620cf15, _50728aa02373._d3b8f44143da._89245086defa))
            )
            if _4413d71aa24a:
                if _de7b27dafe88(_d572260d4d6c, "eps"):
                    _d572260d4d6c._d6f177d0b15e = 1e-3
                _d572260d4d6c = _d572260d4d6c._133eaee48b67(_50728aa02373._80133e122f6b)
                if not _e45cbc4997b7(_d572260d4d6c, _2db12a9253a9._030a3b1d53c7):
                    _5b572cb1ebfe._97193a8ff77c((_48caeb1e0f4e, _2db12a9253a9._030a3b1d53c7(_d572260d4d6c, _370a34f2f0c2=-10, _b2ad2c7c7a1d=10)))
        for _48caeb1e0f4e, _670878db06ec in _5b572cb1ebfe:
            _d5e9d4016029, _52dd316b3c99 = self._ba6f5428d123(_48caeb1e0f4e)
            if _d5e9d4016029 is not _4e161416dfa9:
                _2678eed8f0a9(_d5e9d4016029, _52dd316b3c99, _670878db06ec)

    def _6d4e4306b4b6(self, _d0d88b393bec):
        """Finds the parent module and attribute name given the full module path."""
        _5d116c0bfe35 = _d0d88b393bec._ef0452b12178('.')
        _817f4dda18e5 = self
        for _ea5b7ea9eacd in _5d116c0bfe35[:-1]:
            _817f4dda18e5 = _c4a85c64eacb(_817f4dda18e5, _ea5b7ea9eacd, _4e161416dfa9)
            if _817f4dda18e5 is _4e161416dfa9:
                return _4e161416dfa9, _4e161416dfa9
        return _817f4dda18e5, _5d116c0bfe35[-1]

    def _30d87d34a267(self, _69e1cf96b4c7: _50728aa02373._9bb48afd74d0, _03757e759b32: _50728aa02373._9bb48afd74d0, _a295b73aa4da: _50728aa02373._9bb48afd74d0) -> _2fe6e4652c3c:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _d8e1905f3566 = _69e1cf96b4c7._d8e1905f3566

        # 1) gating w (use cached per-example teacher_conf if available)
        _5b962cd5ffb4 = _c4a85c64eacb(self, "_last_teacher_conf", _4e161416dfa9)
        if _5b962cd5ffb4 is _4e161416dfa9:
            # no teacher info => w = 0 (no distillation)
            _6703b2c54d8a = 0.0
        else:
            _bfd94d3d04aa = (_5b962cd5ffb4 >= _da8d82bb517e(_c4a85c64eacb(self, "teacher_conf_tau", 0.6)))._da8d82bb517e()
            _6703b2c54d8a = _da8d82bb517e(_bfd94d3d04aa._d58cb63f5ec7()._581dd66c9841()._16635e6db8b4()) if _bfd94d3d04aa._8c9616c97779() > 0 else 0.0

        # apply gating to the batch scalars
        _2f9bec6f7379 = _03757e759b32 * _da8d82bb517e(_6703b2c54d8a)
        _7ca9b3fdd139 = _a295b73aa4da * _da8d82bb517e(_6703b2c54d8a)

        # 2) EMAs for autoscaling
        _d6154dd7b9df = _da8d82bb517e((_2f9bec6f7379 + _7ca9b3fdd139)._b3ebf0b67645()._581dd66c9841()._16635e6db8b4())
        _b8f3c957ba76 = _da8d82bb517e(_69e1cf96b4c7._b3ebf0b67645()._581dd66c9841()._16635e6db8b4())
        if _c4a85c64eacb(self, "ema_task", _4e161416dfa9) is _4e161416dfa9:
            self._1cb0f3cd7764 = _b8f3c957ba76
            self._ec7a33b32329 = _d6154dd7b9df + 1e-12
        else:
            _1ac0041a770c = _da8d82bb517e(_c4a85c64eacb(self, "ema_alpha", 0.99))
            self._1cb0f3cd7764 = _1ac0041a770c * _da8d82bb517e(self._1cb0f3cd7764) + (1.0 - _1ac0041a770c) * _b8f3c957ba76
            self._ec7a33b32329  = _1ac0041a770c * _da8d82bb517e(self._ec7a33b32329)  + (1.0 - _1ac0041a770c) * _d6154dd7b9df

        _01bb4277e34c = _da8d82bb517e(_c4a85c64eacb(self, "distill_target_ratio", 0.3))
        _638b2fcfa22d = (_da8d82bb517e(self._1cb0f3cd7764) / (_da8d82bb517e(self._ec7a33b32329) + 1e-12)) * _01bb4277e34c
        _2c885c6dc6d4 = _da8d82bb517e(_638b2fcfa22d)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _51161ea55216 = _da8d82bb517e(_c4a85c64eacb(self._643f30b37f38, "current_epoch", _c4a85c64eacb(self._643f30b37f38, "global_step", 0.0)))
        _796f7367a84e = _da8d82bb517e(_46d5cf4b20eb(1, _c4a85c64eacb(self._643f30b37f38, "max_epochs", 1)))
        _103338683224 = _2e646843503f(_46d5cf4b20eb(_51161ea55216 / _796f7367a84e, 0.0), 1.0)
        _6963958b0d29 = 0.30
        _1d6656d81f6f = _da8d82bb517e(_c4a85c64eacb(self, "kl_base", 0.30)) * _2e646843503f(_103338683224 / _6963958b0d29, 1.0)
        _e8b47d795dba = _da8d82bb517e(_c4a85c64eacb(self, "cos_base", 0.25))
        _9626d0e8d3be = _e8b47d795dba + (0.10 - _e8b47d795dba) * _103338683224

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _44857cdb5538 = _da8d82bb517e(self._a9a5b6f4927a._d58cb63f5ec7()._581dd66c9841()._16635e6db8b4()) if _c4a85c64eacb(self, "_last_teacher_conf", _4e161416dfa9) is not _4e161416dfa9 else 0.0
        if _c4a85c64eacb(self, "ema_teacher_conf", _4e161416dfa9) is _4e161416dfa9:
            self._3448310a4ff5 = _44857cdb5538
        else:
            _8abe87455a2b = _da8d82bb517e(_c4a85c64eacb(self, "teacher_conf_beta", 0.995))
            self._3448310a4ff5 = _8abe87455a2b * _da8d82bb517e(self._3448310a4ff5) + (1.0 - _8abe87455a2b) * _44857cdb5538

        _02d5a0c81c5f = _da8d82bb517e(_c4a85c64eacb(self, "tau_warn", 0.60))
        _6c4ec4039359 = _da8d82bb517e(_c4a85c64eacb(self, "tau_detect", 0.20))
        _71519a648224 = _46d5cf4b20eb(1e-12, (_02d5a0c81c5f - _6c4ec4039359))
        _bc58a18b0c79 = (_da8d82bb517e(self._3448310a4ff5) - _6c4ec4039359) / _71519a648224
        _bc58a18b0c79 = _46d5cf4b20eb(0.0, _2e646843503f(1.0, _bc58a18b0c79))

        _0795202e8d73 = _1d6656d81f6f * _bc58a18b0c79
        _742cc21cd82f = _9626d0e8d3be * _bc58a18b0c79

        # 5) final aux term
        _2fa0fee8731e = _50728aa02373._3dbff4cf99c3(0.0, _d8e1905f3566=_d8e1905f3566)
        _2fa0fee8731e = _2fa0fee8731e + (_0795202e8d73 * _2f9bec6f7379 + _742cc21cd82f * _7ca9b3fdd139) * _da8d82bb517e(_2c885c6dc6d4)

        # diagnostics
        _bb4b7969453b = {
            "aux_term": _2fa0fee8731e,
            "kl_batch": _03757e759b32,
            "contrast_batch": _a295b73aa4da,
            "kl_loss": _2f9bec6f7379,
            "contrastive_loss": _7ca9b3fdd139,
            "w_mean": _6703b2c54d8a,
            "aux_scale": _da8d82bb517e(_2c885c6dc6d4),
            "lambda_kl_eff": _da8d82bb517e(_0795202e8d73),
            "lambda_cos_eff": _da8d82bb517e(_742cc21cd82f),
            "teacher_conf_mean": _da8d82bb517e(self._3448310a4ff5),
            "shift_r": _da8d82bb517e(_bc58a18b0c79)
        }
        return _bb4b7969453b

    def _57a9aff592ed(self, _275bb112de7c):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _275bb112de7c = _275bb112de7c._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)
        _33a2bcfbf873 = (_275bb112de7c != self._03c71a9e4d2c._f35d8a11d7cb)._133eaee48b67(_3cd1c5f8fa33=_50728aa02373._0f94627d7bb1, _d8e1905f3566=self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)

        # model forward (request hidden states)
        _464a9b5948dd = self._d5e238974d52(
            _275bb112de7c=_275bb112de7c,
            _33a2bcfbf873=_33a2bcfbf873,
            _3ecbaa756d43=_8d98d45589f8,
            _4965f27a3f62=_8d98d45589f8,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _350d361f6505 = _c4a85c64eacb(_464a9b5948dd, "last_hidden_state", _4e161416dfa9)
        if _350d361f6505 is _4e161416dfa9:
            _350d361f6505 = _464a9b5948dd._c7079837d721[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _350d361f6505._3cd1c5f8fa33 != _50728aa02373._80133e122f6b:
            _350d361f6505 = _350d361f6505._133eaee48b67(_50728aa02373._80133e122f6b)
        _eb2cbe7ad1e4 = self._b11e34f3ddde(_350d361f6505)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._811350139ebf:
            _606cd06c2e97 = self._973b0a7997c5(_eb2cbe7ad1e4)
        else:
            _606cd06c2e97 = _464a9b5948dd._606cd06c2e97


        _606cd06c2e97 = _606cd06c2e97._133eaee48b67(_50728aa02373._80133e122f6b)._8de3621ee020(-20, 20)

        # default zero scalars
        _2f9bec6f7379 = _50728aa02373._3dbff4cf99c3(0.0, _d8e1905f3566=self._000fec14525f)
        _7ca9b3fdd139 = _50728aa02373._3dbff4cf99c3(0.0, _d8e1905f3566=self._000fec14525f)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _0a3d6451c0c1 = _c4a85c64eacb(self, "trainer", _4e161416dfa9)
        _410d892066e4 = _733fe1034e95
        if _0a3d6451c0c1 is not _4e161416dfa9:
            _410d892066e4 = _0f94627d7bb1(_c4a85c64eacb(self._643f30b37f38, "training", _733fe1034e95) or _c4a85c64eacb(self._643f30b37f38, "validating", _733fe1034e95))

        if _410d892066e4 and (_c4a85c64eacb(self, "batch_counter", 0) % _c4a85c64eacb(self, "xth_batch_to_consider", 1) == 0):
            with _50728aa02373._764ef61321d8():
                _592393c268b5 = _aaddbf5f0339(
                    _275bb112de7c=_275bb112de7c,
                    _33a2bcfbf873=_33a2bcfbf873,
                    _3ecbaa756d43=_8d98d45589f8,
                    _4965f27a3f62=_8d98d45589f8,
                )
                _0f0b449da3b1 = _c4a85c64eacb(_592393c268b5, "last_hidden_state", _4e161416dfa9)
                if _0f0b449da3b1 is _4e161416dfa9:
                    _0f0b449da3b1 = _592393c268b5._c7079837d721[-1]

            # compute embedding-level KL + contrastive (scalar)
            _2f9bec6f7379, _7ca9b3fdd139 = self._6d072e67ad7c(_eb2cbe7ad1e4, _0f0b449da3b1, _d8e1905f3566=self._000fec14525f)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _e0c9286b640e(_fad7522cb3b4): return _fad7522cb3b4._d58cb63f5ec7(_4c6e2a0ae971=1) if _fad7522cb3b4._4c6e2a0ae971() == 3 else _fad7522cb3b4
            _247e71645628 = _50728aa02373._d3b8f44143da._ff902cc150d2._3fba41ca0633(_c3f18a03d08e(_eb2cbe7ad1e4), _7bc116611282=2, _4c6e2a0ae971=-1, _d6f177d0b15e=1e-6)
            _fa334245d0f1 = _50728aa02373._d3b8f44143da._ff902cc150d2._3fba41ca0633(_c3f18a03d08e(_0f0b449da3b1), _7bc116611282=2, _4c6e2a0ae971=-1, _d6f177d0b15e=1e-6)
            _d423d53fef31 = _50728aa02373._d3b8f44143da._ff902cc150d2._bddb8fb5edde(_247e71645628, _fa334245d0f1, _4c6e2a0ae971=-1)  # [-1,1]
            _5b962cd5ffb4 = _d423d53fef31._8de3621ee020(_2e646843503f=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._1f6ea214fe66 = _eb2cbe7ad1e4._b3ebf0b67645()
            self._63685fcb021e = _0f0b449da3b1._b3ebf0b67645()
            self._a9a5b6f4927a = _5b962cd5ffb4._b3ebf0b67645()  # shape (B,)

        # increment counter
        self._eb89a088ca97 = _c4a85c64eacb(self, "batch_counter", 0) + 1

        return _606cd06c2e97, _2f9bec6f7379, _7ca9b3fdd139


    def _5f0b9553c9f6(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _a5960603b67e(_d572260d4d6c, _70ffd20fa17a, _83dab662d258):
            if _ebfb2cb98082(_1cc86ae81512._3cd1c5f8fa33 == _50728aa02373._241ec47a8406 for _1cc86ae81512 in _70ffd20fa17a if _e45cbc4997b7(_1cc86ae81512, _50728aa02373._9bb48afd74d0)):
                _8ae9b9c98c60(f"Layer {_d572260d4d6c._20bc74a45dd3.__name__} is using float16!")

        for _321be02abca8 in self._3193b3906951():
            _f60564382018 = _321be02abca8._5662c253beb0(_b50100f28e46)
            self._10a378d07958._97193a8ff77c(_f60564382018)

    def _34ac4b2a0b88(self):
        """Remove all registered forward hooks."""
        for _f60564382018 in _c4a85c64eacb(self, "amp_hooks", []):
            _f60564382018._5e4dd4b20238()
        self._10a378d07958 = []

    def _8e98bdcd1eb1(self, _275bb112de7c, _d79dd52cd9a5, _b022fe976534):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _77ca88fa6560 = [self._03c71a9e4d2c._f8971a7e5955(_d43e422e3d66) for _d43e422e3d66 in _275bb112de7c]
        _671ec6f0b95e, _e7470e89ea5e = [], []

        for _788eea61100d, _11fe2ca09ae1, _63515d008b47 in _ee4532c0e94f(_77ca88fa6560, _d79dd52cd9a5, _b022fe976534):
            for _e9ffb10f5130, _398ffebb1b60, _802040cb8569 in _ee4532c0e94f(_788eea61100d, _11fe2ca09ae1, _63515d008b47):
                if _e9ffb10f5130 == self._03c71a9e4d2c._c09a548a5aff or _802040cb8569 == self._ed5cd2d40289:
                    continue

                _ef6b49670319 = (
                    _e9ffb10f5130._0ab012e5dd7a("##") or
                    _e9ffb10f5130._0ab012e5dd7a("▁") or
                    _e9ffb10f5130 in ["<unk>", "<pad>"]
                )

                if _ef6b49670319:
                    continue

                _671ec6f0b95e._97193a8ff77c(_398ffebb1b60._16635e6db8b4())
                _e7470e89ea5e._97193a8ff77c(_802040cb8569._16635e6db8b4())

        return _50728aa02373._3dbff4cf99c3(_671ec6f0b95e), _50728aa02373._3dbff4cf99c3(_e7470e89ea5e)

    def _42ed41bb4d37(self):
        _fb33d262590a = _50728aa02373._80133e122f6b
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            _e2a75f0b055b, _044f3e605256 = _50728aa02373._86caffea6183._b3b0ae71a68d()
            if _e2a75f0b055b >= 8:
                _fb33d262590a = _50728aa02373._233bc1523896
            else:
                _fb33d262590a = _50728aa02373._241ec47a8406
        return _fb33d262590a

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _6ab5826e0d86(
        self,
        _b973550d1a75: _50728aa02373._9bb48afd74d0,
        _0e7a044a3497: _50728aa02373._9bb48afd74d0,
        _d8e1905f3566: _3e86fabb7c0a = "cpu",
    ) -> _fe97b84bb73e[_50728aa02373._9bb48afd74d0, _50728aa02373._9bb48afd74d0]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _00b9832840f7 = 2.0
            # NaN/Inf guard
            _b973550d1a75 = _b973550d1a75._8de3621ee020(_2e646843503f=-30, _46d5cf4b20eb=30)
            _0e7a044a3497 = _0e7a044a3497._8de3621ee020(_2e646843503f=-30, _46d5cf4b20eb=30)

            # Move once if needed
            _a6c009dfc46f = _50728aa02373._d8e1905f3566(_d8e1905f3566)
            if _b973550d1a75._d8e1905f3566 != _a6c009dfc46f:
                _b973550d1a75 = _b973550d1a75._133eaee48b67(_d8e1905f3566=_a6c009dfc46f, _c70a6fcd5749=_8d98d45589f8, _3cd1c5f8fa33=self._4e4d1d0b55cb)
                _0e7a044a3497 = _0e7a044a3497._133eaee48b67(_d8e1905f3566=_a6c009dfc46f, _c70a6fcd5749=_8d98d45589f8, _3cd1c5f8fa33=self._4e4d1d0b55cb)

            _a5b0f5a9be77 = _b973550d1a75._9dda805d2992(0)
            _0cda3913524e = _b973550d1a75._9dda805d2992(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _3df943642548 = (_a5b0f5a9be77 * _0cda3913524e) > 32_000_000

            if not _3df943642548 or _a5b0f5a9be77 <= 8:
                # Direct computation
                _873f1ef67bf9 = _50728aa02373._d3b8f44143da._ff902cc150d2._895eb811b4c9(_b973550d1a75 / _00b9832840f7, _4c6e2a0ae971=-1)
                _2578cb2a64d2 = _50728aa02373._d3b8f44143da._ff902cc150d2._aa39df6e8b0f(_0e7a044a3497 / _00b9832840f7, _4c6e2a0ae971=-1)
                _2f9bec6f7379 = _50728aa02373._d3b8f44143da._ff902cc150d2._e84aa93f4f27(_873f1ef67bf9, _2578cb2a64d2, _5f73baa041dd="batchmean") * (_00b9832840f7 * _00b9832840f7)
                _7ca9b3fdd139 = 1 - _50728aa02373._d3b8f44143da._ff902cc150d2._bddb8fb5edde(_b973550d1a75, _0e7a044a3497, _4c6e2a0ae971=-1)._d58cb63f5ec7()
                return _2f9bec6f7379, _7ca9b3fdd139

            # Chunked mode for large inputs
            _f6f664acf314 = _46d5cf4b20eb(1, _a5b0f5a9be77 // 8)
            _dbb84f81efbb, _be3e5f251acf = [], []

            for _24518f80a818 in _e69fdcdb3ed1(0, _a5b0f5a9be77, _f6f664acf314):
                _2ed1e516e66f = _b973550d1a75[_24518f80a818:_24518f80a818 + _f6f664acf314]
                _676eb21a0710 = _0e7a044a3497[_24518f80a818:_24518f80a818 + _f6f664acf314]

                _873f1ef67bf9 = _50728aa02373._d3b8f44143da._ff902cc150d2._895eb811b4c9(_2ed1e516e66f / _00b9832840f7, _4c6e2a0ae971=-1)
                _2578cb2a64d2 = _50728aa02373._d3b8f44143da._ff902cc150d2._aa39df6e8b0f(_676eb21a0710 / _00b9832840f7, _4c6e2a0ae971=-1)

                _1dc3473a2f12 = _50728aa02373._d3b8f44143da._ff902cc150d2._e84aa93f4f27(_873f1ef67bf9, _2578cb2a64d2, _5f73baa041dd="batchmean") * (_00b9832840f7 * _00b9832840f7)
                _0117c562cee3 = _50728aa02373._d3b8f44143da._ff902cc150d2._bddb8fb5edde(_2ed1e516e66f, _676eb21a0710, _4c6e2a0ae971=-1)._d58cb63f5ec7()
                _0adaf613dad4 = 1 - _0117c562cee3

                _dbb84f81efbb._97193a8ff77c(_1dc3473a2f12)
                _be3e5f251acf._97193a8ff77c(_0adaf613dad4)

            _2f9bec6f7379 = _50728aa02373._33267903d389(_dbb84f81efbb)._d58cb63f5ec7()
            _7ca9b3fdd139 = _50728aa02373._33267903d389(_be3e5f251acf)._d58cb63f5ec7()
            return _2f9bec6f7379, _7ca9b3fdd139

        except _57133f310dac as _309c821cb997:
            raise _fdd3f6354471(f"KL/contrastive loss computation failed: {_3e86fabb7c0a(_309c821cb997)}")


    def _12e978a37e75(self, _2cbe0a50bd99, _061636ec311d):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _275bb112de7c = _2cbe0a50bd99["input_ids"]
            _ab50476194ab = _2cbe0a50bd99["labels"]
            _f24a1c7d982a = _2cbe0a50bd99._00cc97563355("prompt_lens", _4e161416dfa9)
            _a5b0f5a9be77 = _275bb112de7c._9dda805d2992(0)

            # move to device
            _275bb112de7c = _275bb112de7c._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)
            _ab50476194ab = _ab50476194ab._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _83dab662d258, _03757e759b32, _a295b73aa4da = self(_275bb112de7c)

            # causal LM shift for next-token classification (unchanged)
            _d5880fc7c1a6 = _83dab662d258[:, :-1, :]._10f543c6d9fe()
            _8e1965dbe780 = _ab50476194ab[:, 1:]._10f543c6d9fe()
            _6e2b6dc76ad1 = _d5880fc7c1a6._4079008bd9bf(-1, _d5880fc7c1a6._9dda805d2992(-1))
            _d6c632f2f53e = _8e1965dbe780._4079008bd9bf(-1)

            # classification/task loss
            _8a5b8c56b2e3 = self._14b999b194e4['criterion'](_6e2b6dc76ad1, _d6c632f2f53e)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _03757e759b32 = _50728aa02373._ed74b98214da(_03757e759b32, _fd67ca7e0117=0.0, _61543cec6f10=0.0, _32fa6e792fa5=0.0)
            _a295b73aa4da = _50728aa02373._ed74b98214da(_a295b73aa4da, _fd67ca7e0117=0.0, _61543cec6f10=0.0, _32fa6e792fa5=0.0)
            _8a5b8c56b2e3 = _50728aa02373._ed74b98214da(_8a5b8c56b2e3, _fd67ca7e0117=0.0, _61543cec6f10=0.0, _32fa6e792fa5=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _c6e98fe80bad = self._287380579c3b(_8a5b8c56b2e3, _03757e759b32, _a295b73aa4da)
            _2fa0fee8731e = _c6e98fe80bad["aux_term"]

            # final combined loss (single-equation)
            _80c8beeaa081 = _8a5b8c56b2e3 + _2fa0fee8731e

            # Optional NaN print as before (keeps your original check)
            if _50728aa02373._96f20c3d83a7(_8a5b8c56b2e3):
                _8ae9b9c98c60(f"Step {_061636ec311d}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _a54874af5f8d = {
                "epoch": _da8d82bb517e(_c4a85c64eacb(self, "current_epoch", _c4a85c64eacb(self._643f30b37f38, "current_epoch", 0))),
                "train_kl_loss": _c6e98fe80bad._00cc97563355("kl_loss", _03757e759b32)._b3ebf0b67645() if _e45cbc4997b7(_c6e98fe80bad._00cc97563355("kl_loss", _03757e759b32), _50728aa02373._9bb48afd74d0) else _c6e98fe80bad._00cc97563355("kl_loss", _03757e759b32),
                "train_contrastive_loss": _c6e98fe80bad._00cc97563355("contrastive_loss", _a295b73aa4da)._b3ebf0b67645() if _e45cbc4997b7(_c6e98fe80bad._00cc97563355("contrastive_loss", _a295b73aa4da), _50728aa02373._9bb48afd74d0) else _c6e98fe80bad._00cc97563355("contrastive_loss", _a295b73aa4da),
                "train_classification_loss": _8a5b8c56b2e3._b3ebf0b67645(),
                "train_loss": _80c8beeaa081._b3ebf0b67645(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _da8d82bb517e(_c4a85c64eacb(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _c6e98fe80bad._00cc97563355("lambda_kl_eff", _da8d82bb517e(_c4a85c64eacb(self, "kl_base", 0.30))),
                "train_lambda_contrast": _c6e98fe80bad._00cc97563355("lambda_cos_eff", _da8d82bb517e(_c4a85c64eacb(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _90c4f7f5bc6a in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _90c4f7f5bc6a in _c6e98fe80bad:
                    _25fd7d8dc30b = _c6e98fe80bad[_90c4f7f5bc6a]
                    # convert single-element tensors to python floats for logging
                    if _e45cbc4997b7(_25fd7d8dc30b, _50728aa02373._9bb48afd74d0) and _25fd7d8dc30b._8c9616c97779() == 1:
                        _a54874af5f8d[f"train_{_90c4f7f5bc6a}"] = _da8d82bb517e(_25fd7d8dc30b._b3ebf0b67645()._581dd66c9841()._16635e6db8b4())
                    else:
                        _a54874af5f8d[f"train_{_90c4f7f5bc6a}"] = _25fd7d8dc30b

            # log exactly like you did
            self._e860e51f8771(
                _a54874af5f8d,
                _a5b0f5a9be77=_a5b0f5a9be77,
                _ee2888169b01=_733fe1034e95,
                _683e8851b5a8=_8d98d45589f8,
                _a96b2172bfd1=_733fe1034e95,
                _755fb1e74b63=_8d98d45589f8,
                _42bad3a0c4c2=_8d98d45589f8,
            )

            # free references as you did
            del _275bb112de7c, _ab50476194ab, _83dab662d258, _03757e759b32, _8a5b8c56b2e3, _a295b73aa4da, _8e1965dbe780, _d5880fc7c1a6, _d6c632f2f53e, _6e2b6dc76ad1

            return _80c8beeaa081

        except _57133f310dac as _309c821cb997:
            raise _fdd3f6354471(f"Error in training_step: {_309c821cb997}") from _309c821cb997

    def _757c94a8ea54(self):
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            _50728aa02373._86caffea6183._8a3a51220af8()
        _2caf4d4ffc93._bee24af2acdc()
        return _5568537f94ca()._05901b9e86b6()

    def _759df78a7024(self, _2cbe0a50bd99, _061636ec311d):
        _275bb112de7c      = _2cbe0a50bd99["input_ids"]._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)
        _ab50476194ab         = _2cbe0a50bd99["labels"]._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)
        _2fbdf9d54bea     = _2cbe0a50bd99._00cc97563355("lang_codes", _4e161416dfa9)
        _47f22f169454     = _2cbe0a50bd99._00cc97563355("sample_ids", _4e161416dfa9)
        _fb9082c4a987      = _2cbe0a50bd99._00cc97563355("chunk_ids", _4e161416dfa9)
        _a6a838a2a6ce = _2cbe0a50bd99._00cc97563355("word_positions", _4e161416dfa9)
        _f24a1c7d982a    = _2cbe0a50bd99._00cc97563355("prompt_lens", _4e161416dfa9)
        _79784527be38 = _2cbe0a50bd99._00cc97563355("num_chunks", _4e161416dfa9)

        _a5b0f5a9be77 = _275bb112de7c._9dda805d2992(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _83dab662d258, _03757e759b32, _a295b73aa4da = self(_275bb112de7c)

        # causal LM shift for next-token classification (same as training)
        _d5880fc7c1a6 = _83dab662d258[:, :-1, :]._10f543c6d9fe()
        _8e1965dbe780 = _ab50476194ab[:, 1:]._10f543c6d9fe()
        _6e2b6dc76ad1 = _d5880fc7c1a6._4079008bd9bf(-1, _d5880fc7c1a6._9dda805d2992(-1))
        _d6c632f2f53e = _8e1965dbe780._4079008bd9bf(-1)

        if _061636ec311d == 0:
            try:
                _8ae9b9c98c60(
                    f"VAL TEST BATCH {_061636ec311d} Input IDs: {_275bb112de7c._191358ea6f73()[0]}, "
                    f"Predictions: {_50728aa02373._0aea9456dae8(_d5880fc7c1a6, _4c6e2a0ae971=-1)._191358ea6f73()[0]}, "
                    f"Labels: {_8e1965dbe780._191358ea6f73()[0]}"
                )
            except _57133f310dac:
                # printing should never crash validation
                pass

        # classification loss
        _8a5b8c56b2e3 = self._14b999b194e4['criterion'](_6e2b6dc76ad1, _d6c632f2f53e)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _03757e759b32 = _50728aa02373._ed74b98214da(_03757e759b32, _fd67ca7e0117=0.0, _61543cec6f10=0.0, _32fa6e792fa5=0.0)
        _a295b73aa4da = _50728aa02373._ed74b98214da(_a295b73aa4da, _fd67ca7e0117=0.0, _61543cec6f10=0.0, _32fa6e792fa5=0.0)
        _8a5b8c56b2e3 = _50728aa02373._ed74b98214da(_8a5b8c56b2e3, _fd67ca7e0117=0.0, _61543cec6f10=0.0, _32fa6e792fa5=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _c6e98fe80bad = self._287380579c3b(_8a5b8c56b2e3, _03757e759b32, _a295b73aa4da)
        _2fa0fee8731e = _c6e98fe80bad["aux_term"]
        _80c8beeaa081 = _8a5b8c56b2e3 + _2fa0fee8731e

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _e860e51f8771 = {
            "val_kl_loss": _da8d82bb517e(_c6e98fe80bad._00cc97563355("kl_loss", _03757e759b32)._b3ebf0b67645()._581dd66c9841()._16635e6db8b4()) if _e45cbc4997b7(_c6e98fe80bad._00cc97563355("kl_loss", _03757e759b32), _50728aa02373._9bb48afd74d0) else _da8d82bb517e(_c6e98fe80bad._00cc97563355("kl_loss", _03757e759b32)),
            "val_contrastive_loss": _da8d82bb517e(_c6e98fe80bad._00cc97563355("contrastive_loss", _a295b73aa4da)._b3ebf0b67645()._581dd66c9841()._16635e6db8b4()) if _e45cbc4997b7(_c6e98fe80bad._00cc97563355("contrastive_loss", _a295b73aa4da), _50728aa02373._9bb48afd74d0) else _da8d82bb517e(_c6e98fe80bad._00cc97563355("contrastive_loss", _a295b73aa4da)),
            "val_classification_loss": _da8d82bb517e(_8a5b8c56b2e3._b3ebf0b67645()._581dd66c9841()._16635e6db8b4()),
            "val_loss": _da8d82bb517e(_80c8beeaa081._b3ebf0b67645()._581dd66c9841()._16635e6db8b4()),
        }

        # include effective lambdas and others if provided by aux
        _e860e51f8771["val_lambda_kl"] = _da8d82bb517e(_c6e98fe80bad._00cc97563355("lambda_kl", _c6e98fe80bad._00cc97563355("lambda_kl_eff", _da8d82bb517e(_c4a85c64eacb(self, "kl_base", 0.30)))))
        _e860e51f8771["val_lambda_contrast"] = _da8d82bb517e(_c6e98fe80bad._00cc97563355("lambda_cos", _c6e98fe80bad._00cc97563355("lambda_cos_eff", _da8d82bb517e(_c4a85c64eacb(self, "cos_base", 0.25)))))
        _e860e51f8771["val_w_mean"] = _da8d82bb517e(_c6e98fe80bad._00cc97563355("w_mean", 0.0))
        _e860e51f8771["val_aux_scale"] = _da8d82bb517e(_c6e98fe80bad._00cc97563355("aux_scale", 0.0))
        _e860e51f8771["val_shift_r"] = _da8d82bb517e(_c6e98fe80bad._00cc97563355("shift_r", 0.0))
        _e860e51f8771["val_teacher_conf_mean"] = _da8d82bb517e(_c6e98fe80bad._00cc97563355("teacher_conf_mean", 0.0))

        self._e860e51f8771(
            _e860e51f8771,
            _a5b0f5a9be77=_a5b0f5a9be77,
            _ee2888169b01=_733fe1034e95,
            _683e8851b5a8=_8d98d45589f8,
            _a96b2172bfd1=_733fe1034e95,
            _755fb1e74b63=_8d98d45589f8,
            _42bad3a0c4c2=_8d98d45589f8,
        )

        # build preds and labels per example (preserve your previous behavior)
        _67a8e394d3c5 = []
        _83a316109598 = []
        for _24518f80a818 in _e69fdcdb3ed1(_a5b0f5a9be77):
            _950fe2eb3f99 = _83dab662d258[_24518f80a818]
            _802040cb8569 = _ab50476194ab[_24518f80a818]
            _1bf7f601a21a = _50728aa02373._0aea9456dae8(_950fe2eb3f99, _4c6e2a0ae971=-1)
            _8d22591aa416 = _802040cb8569
            _67a8e394d3c5._97193a8ff77c(_1bf7f601a21a)
            _83a316109598._97193a8ff77c(_8d22591aa416)

        _45034f21fc97 = {
            "lang_codes": _2fbdf9d54bea,
            "preds": _67a8e394d3c5,
            "labels": _83a316109598,
            "sample_ids": _47f22f169454,
            "chunk_ids": _fb9082c4a987,
            "word_positions": _a6a838a2a6ce,
            "val_loss": _80c8beeaa081,
            "prompt_lens": _f24a1c7d982a,
            "num_chunks": _79784527be38,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._cf1eb66602b9._97193a8ff77c(_45034f21fc97)

        # explicit frees (same as you had)
        del _275bb112de7c, _ab50476194ab, _83dab662d258, _6e2b6dc76ad1, _d6c632f2f53e, _d5880fc7c1a6, _8e1965dbe780
        del _03757e759b32, _a295b73aa4da, _8a5b8c56b2e3, _67a8e394d3c5, _83a316109598

        return _45034f21fc97


    def _07f55f5edc8e(self, _4aea25e91e2c, _116afb3ec738, _a40bef14b76e=_4e161416dfa9):
        _dbccb15ca5db = _74fb9aa7f514._857647dbccc6()
        _9f896da1efc7 = f"trial_{_a40bef14b76e}" if _a40bef14b76e is not _4e161416dfa9 else "default"
        _8ae9b9c98c60(f"[DEBUG rank={_50728aa02373._4e63d957f109._df3c0f74989d() if _50728aa02373._4e63d957f109._05483fe3441d() else 0}] metrics_dict confusion_matrix sum={_045cb383a552(_045cb383a552(_d028005d3c2a) for _d028005d3c2a in _4aea25e91e2c['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _6a7b9a21ea49 = _74fb9aa7f514._0edac3e51d45._bdf1bb633a5a(_dbccb15ca5db, "metrics", self._a7b2e675f685,  _9f896da1efc7)
        _74fb9aa7f514._78f81c899c4f(_6a7b9a21ea49, _10b39f915a2b=_8d98d45589f8)
        _7f45e2fa2d03 = _74fb9aa7f514._0edac3e51d45._bdf1bb633a5a(_6a7b9a21ea49, _116afb3ec738)
        _076f36699157 = _0e8d54809917._cdc06abf8813(_4aea25e91e2c)
        _076f36699157._8fbc71b39dab(_7f45e2fa2d03, _a043d19d3bca=_733fe1034e95)
        _8ae9b9c98c60(f"[metrics] Saved {_7f45e2fa2d03}")

    def _d2407d309a1d(self):
        # pick correct device for this rank
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            if _50728aa02373._4e63d957f109._05483fe3441d():
                _2b0414854b80 = _50728aa02373._4e63d957f109._df3c0f74989d()
            else:
                _2b0414854b80 = 0
            _50728aa02373._86caffea6183._3adb272021e3(_2b0414854b80)
            self._000fec14525f = _50728aa02373._d8e1905f3566(f"cuda:{_2b0414854b80}")
        else:
            self._000fec14525f = _50728aa02373._d8e1905f3566("cpu")

        self._814dd87529c1()

    def _1b2ade224fb1(self):
        _83dab662d258 = _c4a85c64eacb(self, "_validation_outputs", _4e161416dfa9)
        if not _83dab662d258:
            return

        _68a7a4eeea94, _31645fe66d6c, _572cfc777a7d, _93d54042441a = \
            self._d32a0d117971(_83dab662d258)

        _73817e9cb9c3, _a6b0a77e8084 = [], []
        for _149a491157fc in _fc26c00886c8(_572cfc777a7d._b9ea88c8c95c()):
            _7cda4823207d = _68a7a4eeea94[_149a491157fc]._191358ea6f73()
            _74fffcfaa1e8 = _31645fe66d6c[_149a491157fc]._191358ea6f73()
            _f2912c3d72f4 = _572cfc777a7d[_149a491157fc]
            _24a5d58fe03b = _93d54042441a[_149a491157fc]
            if _f2912c3d72f4._8c9616c97779() > 0 and _24a5d58fe03b._8c9616c97779() > 0:
                _73817e9cb9c3._97193a8ff77c(_f2912c3d72f4)
                _a6b0a77e8084._97193a8ff77c(_24a5d58fe03b)

        if not _73817e9cb9c3:
            _8ae9b9c98c60("[VAL END] Nothing to score.")
            self._cf1eb66602b9._f19d54fa585c()
            return

        _155dd247d0d6 = _50728aa02373._3bbddf018d46(_73817e9cb9c3)._133eaee48b67(_d8e1905f3566=self._8eb29399dccb['micro_accuracy']._d8e1905f3566, _c70a6fcd5749=_8d98d45589f8)
        _ab50476194ab = _50728aa02373._3bbddf018d46(_a6b0a77e8084)._133eaee48b67(_d8e1905f3566=self._8eb29399dccb['micro_accuracy']._d8e1905f3566, _c70a6fcd5749=_8d98d45589f8)

        self._8eb29399dccb['micro_accuracy']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_accuracy']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_precision']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_recall']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_f1']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_accuracy']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_precision']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_recall']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_f1']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['confmat']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)

        _571a2f3ded11  = self._8eb29399dccb['micro_accuracy']._b7ca5639bbdb()._16635e6db8b4()
        _f0b6cbd41cc1  = self._8eb29399dccb['macro_accuracy']._b7ca5639bbdb()._16635e6db8b4()
        _dbb4b511fd20 = self._8eb29399dccb['macro_precision']._b7ca5639bbdb()._16635e6db8b4()
        _1a7d76b3e037    = self._8eb29399dccb['macro_recall']._b7ca5639bbdb()._16635e6db8b4()
        _e21dd32b99f2        = self._8eb29399dccb['macro_f1']._b7ca5639bbdb()._16635e6db8b4()

        self._c40511295999("val_accuracy", _f0b6cbd41cc1, _42bad3a0c4c2=_8d98d45589f8)

        try:
            _8518506a36c9 = self._c3e9f9411a63
            _4aea25e91e2c = {
                "epoch": [_8518506a36c9],
                "class_names": [self._99086f9b4551],
                "micro_accuracy": [_571a2f3ded11],
                "macro_accuracy": [_f0b6cbd41cc1],
                "macro_precision": [_dbb4b511fd20],
                "macro_recall": [_1a7d76b3e037],
                "macro_f1": [_e21dd32b99f2],
                "classwise_accuracy": [self._8eb29399dccb['classwise_accuracy']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "classwise_precision": [self._8eb29399dccb['classwise_precision']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "classwise_recall": [self._8eb29399dccb['classwise_recall']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "classwise_f1": [self._8eb29399dccb['classwise_f1']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "confusion_matrix": [self._8eb29399dccb['confmat']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
            }
            self._d1633841d57e(_4aea25e91e2c, f"val_epoch_{_8518506a36c9}.csv", _a40bef14b76e=self._a40bef14b76e)
        except _57133f310dac as _309c821cb997:
            _8ae9b9c98c60(f"[VAL END] save metrics FAILED: {_309c821cb997}")

        # cleanup
        self._8eb29399dccb['micro_accuracy']._7da2011b8995(); self._8eb29399dccb['macro_accuracy']._7da2011b8995()
        self._8eb29399dccb['macro_precision']._7da2011b8995(); self._8eb29399dccb['macro_recall']._7da2011b8995(); self._8eb29399dccb['macro_f1']._7da2011b8995()
        self._8eb29399dccb['classwise_accuracy']._7da2011b8995(); self._8eb29399dccb['classwise_precision']._7da2011b8995()
        self._8eb29399dccb['classwise_recall']._7da2011b8995(); self._8eb29399dccb['classwise_f1']._7da2011b8995()
        self._8eb29399dccb['confmat']._7da2011b8995(); self._cf1eb66602b9._f19d54fa585c()
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            _50728aa02373._86caffea6183._8a3a51220af8()
        _8ae9b9c98c60("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_50728aa02373._764ef61321d8()
    def _eb7be2bc0946(self, _275bb112de7c: _50728aa02373._9bb48afd74d0, **_e58ddb25912e):
        _e58ddb25912e._903012de93c8("pad_token_id", _4e161416dfa9)
        _e58ddb25912e._903012de93c8("attention_mask", _4e161416dfa9)
        return self._d5e238974d52._873e75681d41(
            _275bb112de7c=_275bb112de7c,
            _33a2bcfbf873=(_275bb112de7c != self._03c71a9e4d2c._f35d8a11d7cb),
            _f35d8a11d7cb=self._03c71a9e4d2c._f35d8a11d7cb,
            _35f2fd37c3d0=self._03c71a9e4d2c._35f2fd37c3d0,
            **_e58ddb25912e
        )

    def _4d1c590a3517(self, _2cbe0a50bd99, _061636ec311d):
        _275bb112de7c = _2cbe0a50bd99["input_ids"]._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)
        _ab50476194ab    = _2cbe0a50bd99["labels"]._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)
        _2fbdf9d54bea     = _2cbe0a50bd99._00cc97563355("lang_codes", _4e161416dfa9)
        _47f22f169454     = _2cbe0a50bd99._00cc97563355("sample_ids", _4e161416dfa9)
        _fb9082c4a987      = _2cbe0a50bd99._00cc97563355("chunk_ids", _4e161416dfa9)
        _a6a838a2a6ce = _2cbe0a50bd99._00cc97563355("word_positions", _4e161416dfa9)
        _f24a1c7d982a    = _2cbe0a50bd99._00cc97563355("prompt_lens", _4e161416dfa9)
        _79784527be38 = _2cbe0a50bd99._00cc97563355("num_chunks", _4e161416dfa9)

        _a5b0f5a9be77 = _275bb112de7c._9dda805d2992(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _e5bc6d7c6a98 = self._873e75681d41(
            _275bb112de7c,
            _87e8fc0c81c3=32,
            _96e3b7551144=_733fe1034e95,
            _a9301f9e03c1=_4e161416dfa9,     # for deterministic answers
            _93effd457fce=_4e161416dfa9,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _67a8e394d3c5 = []
        _83a316109598 = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _24518f80a818 in _e69fdcdb3ed1(_a5b0f5a9be77):
            _67a8e394d3c5._97193a8ff77c(_e5bc6d7c6a98[_24518f80a818])   # FULL sequence
            _83a316109598._97193a8ff77c(_ab50476194ab[_24518f80a818])          # FULL labels


        _45034f21fc97 = {
            "lang_codes": _2fbdf9d54bea,
            "preds": _67a8e394d3c5,
            "labels": _83a316109598,
            "sample_ids": _47f22f169454,
            "chunk_ids": _fb9082c4a987,
            "word_positions": _a6a838a2a6ce,
            "prompt_lens": _f24a1c7d982a,
            "num_chunks": _79784527be38,
        }

        self._65862cee0737._97193a8ff77c(_45034f21fc97)

        # Exact same cleanup as before
        del _275bb112de7c, _ab50476194ab, _e5bc6d7c6a98, _67a8e394d3c5, _83a316109598

        return _45034f21fc97

    def _857b2eec525d(self):
        # pick correct device for this rank
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            if _50728aa02373._4e63d957f109._05483fe3441d():
                _2b0414854b80 = _50728aa02373._4e63d957f109._df3c0f74989d()
            else:
                _2b0414854b80 = 0
            _50728aa02373._86caffea6183._3adb272021e3(_2b0414854b80)
            self._000fec14525f = _50728aa02373._d8e1905f3566(f"cuda:{_2b0414854b80}")
        else:
            self._000fec14525f = _50728aa02373._d8e1905f3566("cpu")

        self._814dd87529c1()
        
    def _8f1a3f5c6f9f(self):
        _83dab662d258 = _c4a85c64eacb(self, "_test_outputs", _4e161416dfa9)
        _8ae9b9c98c60(f"[DEBUG rank={_50728aa02373._4e63d957f109._df3c0f74989d()}] outputs_len={_c04de5307634(_83dab662d258)}")
        if not _83dab662d258:
            return

        _68a7a4eeea94, _31645fe66d6c, _572cfc777a7d, _93d54042441a = \
            self._d32a0d117971(_83dab662d258)

        _73817e9cb9c3, _a6b0a77e8084 = [], []
        for _149a491157fc in _fc26c00886c8(_572cfc777a7d._b9ea88c8c95c()):
            _7cda4823207d = _68a7a4eeea94[_149a491157fc]._191358ea6f73()
            _74fffcfaa1e8 = _31645fe66d6c[_149a491157fc]._191358ea6f73()
            _f2912c3d72f4 = _572cfc777a7d[_149a491157fc]
            _24a5d58fe03b = _93d54042441a[_149a491157fc]

            if _f2912c3d72f4._8c9616c97779() > 0 and _24a5d58fe03b._8c9616c97779() > 0:
                _73817e9cb9c3._97193a8ff77c(_f2912c3d72f4)
                _a6b0a77e8084._97193a8ff77c(_24a5d58fe03b)

        if not _73817e9cb9c3:
            _8ae9b9c98c60("[TEST END] Nothing to score.")
            self._cf1eb66602b9._f19d54fa585c()
            return

        _155dd247d0d6 = _50728aa02373._3bbddf018d46(_73817e9cb9c3)._133eaee48b67(_d8e1905f3566=self._8eb29399dccb['micro_accuracy']._d8e1905f3566, _c70a6fcd5749=_8d98d45589f8)
        _ab50476194ab = _50728aa02373._3bbddf018d46(_a6b0a77e8084)._133eaee48b67(_d8e1905f3566=self._8eb29399dccb['micro_accuracy']._d8e1905f3566, _c70a6fcd5749=_8d98d45589f8)

        self._8eb29399dccb['micro_accuracy']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_accuracy']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_precision']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_recall']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['macro_f1']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_accuracy']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_precision']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_recall']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['classwise_f1']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)
        self._8eb29399dccb['confmat']._425a987a6a5a(_155dd247d0d6, _ab50476194ab)

        _571a2f3ded11  = self._8eb29399dccb['micro_accuracy']._b7ca5639bbdb()._16635e6db8b4()
        _f0b6cbd41cc1  = self._8eb29399dccb['macro_accuracy']._b7ca5639bbdb()._16635e6db8b4()
        _dbb4b511fd20 = self._8eb29399dccb['macro_precision']._b7ca5639bbdb()._16635e6db8b4()
        _1a7d76b3e037    = self._8eb29399dccb['macro_recall']._b7ca5639bbdb()._16635e6db8b4()
        _e21dd32b99f2        = self._8eb29399dccb['macro_f1']._b7ca5639bbdb()._16635e6db8b4()

        self._c40511295999("test_accuracy", _f0b6cbd41cc1, _42bad3a0c4c2=_8d98d45589f8)

        try:
            _8518506a36c9 = self._c3e9f9411a63
            _4aea25e91e2c = {
                "epoch": [_8518506a36c9],
                "class_names": [self._99086f9b4551],
                "micro_accuracy": [_571a2f3ded11],
                "macro_accuracy": [_f0b6cbd41cc1],
                "macro_precision": [_dbb4b511fd20],
                "macro_recall": [_1a7d76b3e037],
                "macro_f1": [_e21dd32b99f2],
                "classwise_accuracy": [self._8eb29399dccb['classwise_accuracy']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "classwise_precision": [self._8eb29399dccb['classwise_precision']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "classwise_recall": [self._8eb29399dccb['classwise_recall']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "classwise_f1": [self._8eb29399dccb['classwise_f1']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
                "confusion_matrix": [self._8eb29399dccb['confmat']._b7ca5639bbdb()._133eaee48b67(_d8e1905f3566="cpu")._bf911228b3ff()._191358ea6f73()],
            }
            self._d1633841d57e(_4aea25e91e2c, f"test_final.csv", _a40bef14b76e=self._a40bef14b76e)
        except _57133f310dac as _309c821cb997:
            _8ae9b9c98c60(f"[TEST END] save metrics FAILED: {_309c821cb997}")

        # cleanup
        self._8eb29399dccb['micro_accuracy']._7da2011b8995(); self._8eb29399dccb['macro_accuracy']._7da2011b8995()
        self._8eb29399dccb['macro_precision']._7da2011b8995(); self._8eb29399dccb['macro_recall']._7da2011b8995(); self._8eb29399dccb['macro_f1']._7da2011b8995()
        self._8eb29399dccb['classwise_accuracy']._7da2011b8995(); self._8eb29399dccb['classwise_precision']._7da2011b8995()
        self._8eb29399dccb['classwise_recall']._7da2011b8995(); self._8eb29399dccb['classwise_f1']._7da2011b8995()
        self._8eb29399dccb['confmat']._7da2011b8995(); self._cf1eb66602b9._f19d54fa585c()
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            _50728aa02373._86caffea6183._8a3a51220af8()
        _8ae9b9c98c60("[TEST END] Finished and cleaned up.")

    def _ebc36bb52459(self, _2cbe0a50bd99, _061636ec311d, _fcb9d71cc16a=0):
        """Optimized prediction step with efficient memory handling."""
        _275bb112de7c, _ = _2cbe0a50bd99
        _275bb112de7c = _275bb112de7c._133eaee48b67(self._000fec14525f, _c70a6fcd5749=_8d98d45589f8)
        _83dab662d258, _, _ = self(_275bb112de7c)
        _f00d21e13afa = _50728aa02373._0aea9456dae8(_83dab662d258, _4c6e2a0ae971=-1)
        del _275bb112de7c, _83dab662d258
        if _50728aa02373._86caffea6183._bc68d1594d5e():
            _50728aa02373._86caffea6183._8a3a51220af8()
        return {"predictions": _f00d21e13afa._581dd66c9841()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _a2a94fe90c65(self, _77ca88fa6560, _fd77f17a0e69):
        # if sep token not present then just tuple the tokens and return
        if _fd77f17a0e69 is _4e161416dfa9:
            return [(_5236075c5da9,) for _5236075c5da9 in _77ca88fa6560]

        _ea42e788963b = []
        _6e9ab08f20b1 = []

        for _5236075c5da9 in _77ca88fa6560:
            if _5236075c5da9 == _fd77f17a0e69:
                if _6e9ab08f20b1:
                    _ea42e788963b._97193a8ff77c(_1f90b9ebd29c(_6e9ab08f20b1))
                    _6e9ab08f20b1 = []
            else:
                if _fd77f17a0e69 == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _5236075c5da9 in _6e9ab08f20b1:
                        continue
                    else:
                        _6e9ab08f20b1._97193a8ff77c(_5236075c5da9)
                    
                else:
                    _6e9ab08f20b1._97193a8ff77c(_5236075c5da9)

        if _6e9ab08f20b1:
            _ea42e788963b._97193a8ff77c(_1f90b9ebd29c(_6e9ab08f20b1))

        return _ea42e788963b

    def _6dfbe01ba69a(self, _c5131a650329, _8758914379bd="exact_match", _aee7264c4aa2=_4e161416dfa9):
        if not _c5131a650329:
            return _aee7264c4aa2

        if _8758914379bd == "exact_match":
            return _c5131a650329[0] if _dd269ea88fc6(_493a3cb9c134 == _c5131a650329[0] for _493a3cb9c134 in _c5131a650329) else _aee7264c4aa2

        if _8758914379bd == "most_common":
            return _d06d4c6bbced(_c5131a650329)._b2fd8a2ea67f(1)[0][0]

        if _8758914379bd == "first":
            return _c5131a650329[0]

        raise _872e94dfea21(f"Unknown vote mode: {_8758914379bd}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _9a574293e311(self, _83dab662d258, _c9fb71b462f0=_8d98d45589f8, _a6c009dfc46f="cpu"):
        from _ff7c7e710767 import _fa4fb0583108
        import _50728aa02373

        _a82cdf733388 = self._ed5cd2d40289
        _fd77f17a0e69 = self._8caeeff61dbb
        _63f15db6a047 = self._5a6f43beb02f

        def _628971ea8605(_fad7522cb3b4):
            if _e45cbc4997b7(_fad7522cb3b4, _50728aa02373._9bb48afd74d0):
                return _fad7522cb3b4._b3ebf0b67645()._133eaee48b67(_d8e1905f3566=_a6c009dfc46f)._6e1c482acf53(-1)._191358ea6f73()
            return _4ccaf31d72a4(_fad7522cb3b4) if _e45cbc4997b7(_fad7522cb3b4, (_4ccaf31d72a4, _1f90b9ebd29c)) else [_fad7522cb3b4]

        _54de4f8a88e3 = _d46fbbd26916()
        _6cece62cef40 = _fa4fb0583108(_4ccaf31d72a4)
        _1cfde1eae1e9 = _fa4fb0583108(_277691fccdf2)
        _74dac10d85a1 = []

        if _c9fb71b462f0:
            _8ae9b9c98c60(f"[reconcile] start: num_outputs={_c04de5307634(_83dab662d258)}")

        for _bb4b7969453b in _83dab662d258:
            _47f22f169454 = _bb4b7969453b["sample_ids"]
            _fb9082c4a987 = _bb4b7969453b["chunk_ids"]
            _686cb2f4e411 = _bb4b7969453b["preds"]
            _e22f965973b4 = _bb4b7969453b["labels"]
            _a6a838a2a6ce = _bb4b7969453b["word_positions"]
            _f24a1c7d982a = _bb4b7969453b["prompt_lens"]
            _974990fb0b0a = _bb4b7969453b["num_chunks"]

            for _24518f80a818, _149a491157fc in _27b400510198(_47f22f169454):
                _d14e0fb7d5ee = _277691fccdf2(_fb9082c4a987[_24518f80a818])
                if (_149a491157fc, _d14e0fb7d5ee) in _54de4f8a88e3:
                    continue
                _54de4f8a88e3._4b52b7929056((_149a491157fc, _d14e0fb7d5ee))

                _1cfde1eae1e9[_149a491157fc] = _277691fccdf2(_974990fb0b0a[_24518f80a818])
                _65368d66805f = _277691fccdf2(_f24a1c7d982a[_24518f80a818])
                _dd66d037a562 = _6b42c02ea72b(_a6a838a2a6ce[_24518f80a818])
                _d040cc73e129 = _6b42c02ea72b(_686cb2f4e411[_24518f80a818])[_65368d66805f:]
                _3c3ea2318af6 = _6b42c02ea72b(_e22f965973b4[_24518f80a818])[_65368d66805f:]

                _a1fd7e5a714e = [_7bc116611282 for _7bc116611282 in _d040cc73e129 if _7bc116611282 != _a82cdf733388]
                _05d6ae2f4e1a = [_904783ff4d2c for _904783ff4d2c in _3c3ea2318af6 if _904783ff4d2c != _a82cdf733388]

                if _149a491157fc not in _74dac10d85a1:
                    _74dac10d85a1._97193a8ff77c(_149a491157fc)

                _6cece62cef40[_149a491157fc]._97193a8ff77c((_d14e0fb7d5ee, _dd66d037a562, _a1fd7e5a714e, _05d6ae2f4e1a))

        _61ab63b8e688 = _4e161416dfa9
        _68a7a4eeea94 = {}
        _31645fe66d6c = {}

        for _149a491157fc in _74dac10d85a1:
            _27134ca89315 = _6cece62cef40[_149a491157fc]
            if _c04de5307634(_27134ca89315) != _1cfde1eae1e9[_149a491157fc]:
                if _c9fb71b462f0:
                    _8ae9b9c98c60(f"Skipping sample {_149a491157fc}: expected {_1cfde1eae1e9[_149a491157fc]} chunks, got {_c04de5307634(_27134ca89315)}")
                continue

            _27134ca89315._510429b07b3c(_a514376b94be=lambda _fad7522cb3b4: _fad7522cb3b4[0])

            if _61ab63b8e688 is _4e161416dfa9 and _c04de5307634(_27134ca89315) > 1:
                _61ab63b8e688 = _149a491157fc

            # Split into words
            _bdd206db7a27 = []
            for _d14e0fb7d5ee, _0dda1548cdec, _aea7fa0a164a, _6284a72b67ad in _27134ca89315:
                _c5cb5fe8099b = self._dd6ed060a947(_0dda1548cdec, -1)
                _f6c3b9e0cc39 = self._dd6ed060a947(_aea7fa0a164a, _fd77f17a0e69)
                _9496256a102f = self._dd6ed060a947(_6284a72b67ad, _fd77f17a0e69)
                _318eab8b3dec = _c04de5307634(_c5cb5fe8099b)
                if _c04de5307634(_f6c3b9e0cc39) < _318eab8b3dec:
                    _f6c3b9e0cc39 += [(_63f15db6a047,)] * (_318eab8b3dec - _c04de5307634(_f6c3b9e0cc39))
                if _c04de5307634(_9496256a102f) < _318eab8b3dec:
                    _9496256a102f += [(_a82cdf733388,)] * (_318eab8b3dec - _c04de5307634(_9496256a102f))
                _bdd206db7a27._97193a8ff77c((_c5cb5fe8099b, _f6c3b9e0cc39, _9496256a102f))

            # Vote per word position
            _21067f044398 = _fa4fb0583108(_4ccaf31d72a4)
            _99e9d3c8d585 = _fa4fb0583108(_4ccaf31d72a4)
            for _c5cb5fe8099b, _f6c3b9e0cc39, _9496256a102f in _bdd206db7a27:
                for _f53f8ecff50a, _f560ecd5ee9e, _9addedf7d769 in _ee4532c0e94f(_c5cb5fe8099b, _f6c3b9e0cc39, _9496256a102f):
                    _0dda1548cdec = _f53f8ecff50a[0]
                    _21067f044398[_0dda1548cdec]._97193a8ff77c(_f560ecd5ee9e)
                    _99e9d3c8d585[_0dda1548cdec]._97193a8ff77c(_9addedf7d769)

            _0d158d0752a4 = _fc26c00886c8(_21067f044398._b9ea88c8c95c())

            _09dc425a29a1 = [self._b12868d2ed9d(_21067f044398[_7bc116611282], _8758914379bd="exact_match", _aee7264c4aa2=(_63f15db6a047,)) for _7bc116611282 in _0d158d0752a4]
            _c8faf2f82942 = []
            for _7bc116611282 in _0d158d0752a4:
                _17c25f0fd3d5 = _99e9d3c8d585[_7bc116611282]
                _5d4e127103b3 = self._b12868d2ed9d(_17c25f0fd3d5, _8758914379bd="exact_match", _aee7264c4aa2=_4e161416dfa9)
                if _5d4e127103b3 is _4e161416dfa9:
                    for _367e250249fc in _17c25f0fd3d5:
                        if _a82cdf733388 not in _367e250249fc:
                            _5d4e127103b3 = _367e250249fc
                            break
                    if _5d4e127103b3 is _4e161416dfa9:
                        _5d4e127103b3 = _17c25f0fd3d5[0]
                _c8faf2f82942._97193a8ff77c(_5d4e127103b3)

            # Reconstruct
            _c8d30197a7a4 = []
            _de3d464b7f09 = []
            for _24518f80a818 in _e69fdcdb3ed1(_c04de5307634(_0d158d0752a4)):
                _c8d30197a7a4._35c4282d3d0e(_09dc425a29a1[_24518f80a818])
                _de3d464b7f09._35c4282d3d0e(_c8faf2f82942[_24518f80a818])
                if _24518f80a818 < _c04de5307634(_0d158d0752a4) - 1:
                    _c8d30197a7a4._97193a8ff77c(_fd77f17a0e69)
                    _de3d464b7f09._97193a8ff77c(_fd77f17a0e69)

            _8ae9b9c98c60(f"check labels final {(_045cb383a552(1 for _fad7522cb3b4 in _de3d464b7f09 if _fad7522cb3b4 == _fd77f17a0e69))}")

            _68a7a4eeea94[_149a491157fc] = _50728aa02373._3dbff4cf99c3(_c8d30197a7a4, _d8e1905f3566=_a6c009dfc46f)
            _31645fe66d6c[_149a491157fc] = _50728aa02373._3dbff4cf99c3(_de3d464b7f09, _d8e1905f3566=_a6c009dfc46f)

        if _c9fb71b462f0 and _61ab63b8e688 is not _4e161416dfa9:
            _8ae9b9c98c60(f"[SUMMARY] reconciled samples in batch = {_c04de5307634(_74dac10d85a1)} "
                f"sid={_61ab63b8e688} total_preds={_c04de5307634(_68a7a4eeea94[_61ab63b8e688])} "
                f"total_labels={_c04de5307634(_31645fe66d6c[_61ab63b8e688])} "
                f"raw_preds {_68a7a4eeea94[_61ab63b8e688]} and raw_labels {_31645fe66d6c[_61ab63b8e688]} "
                f"chunks {_6cece62cef40[_61ab63b8e688]}")

        _2134bca6f0f1 = _045cb383a552(_c04de5307634(_904783ff4d2c) for _904783ff4d2c in _31645fe66d6c._c5131a650329())
        _8ae9b9c98c60(f"Total reconciled labels: {_2134bca6f0f1}")

        _5a6ddd6d4134, _95d07f77e955 = self._558a65a5fcb9(
            _68a7a4eeea94, _31645fe66d6c, _c9fb71b462f0=_c9fb71b462f0, _a6c009dfc46f=_a6c009dfc46f
        )
        _791d3a68eec0 = _045cb383a552(_c04de5307634(_904783ff4d2c) for _904783ff4d2c in _95d07f77e955._c5131a650329())
        _8ae9b9c98c60(f"Total reconciled labels classes: {_791d3a68eec0}")

        _64977af01dc6 = _50728aa02373._4e63d957f109._df3c0f74989d() if _50728aa02373._4e63d957f109._05483fe3441d() else -1
        _8ae9b9c98c60(f"Rank {_64977af01dc6} samples are {_74dac10d85a1}")

        return _68a7a4eeea94, _31645fe66d6c, _5a6ddd6d4134, _95d07f77e955

    def _40ab86711c9b(self, _68a7a4eeea94, _31645fe66d6c, _c9fb71b462f0=_8d98d45589f8, _a6c009dfc46f="cpu"):
        _1dfe0f012e02 = _c4a85c64eacb(self, "seq2class", {})
        _fd77f17a0e69 = _c4a85c64eacb(self, "tokenizer_separator_token", _4e161416dfa9)
        _a82cdf733388 = _c4a85c64eacb(self, "ignore_idx", -100)
        
        def _f4648c1260c2(_77ca88fa6560, _2c3576735085):
            _ea42e788963b = []
            _564c2179a44a = []
            for _24518f80a818, _e9ffb10f5130 in _27b400510198(_77ca88fa6560):
                if _e9ffb10f5130 == _2c3576735085 and _564c2179a44a:
                    _ea42e788963b._97193a8ff77c(_564c2179a44a)
                    _564c2179a44a = []
                elif _e9ffb10f5130 != _2c3576735085:
                    _564c2179a44a._97193a8ff77c(_e9ffb10f5130)
            if _564c2179a44a:
                _ea42e788963b._97193a8ff77c(_564c2179a44a)
            return _ea42e788963b
        
        def _3868f9e87d3d(_089b41c4be8f, _1dfe0f012e02, _c9fb71b462f0, _149a491157fc):
            _bb4b7969453b = []
            _51761d33df9d = _fc26c00886c8(_1dfe0f012e02._b9ea88c8c95c(), _a514376b94be=_c04de5307634, _7c93fa729b18=_8d98d45589f8)
            for _24518f80a818, _4c2d32208955 in _27b400510198(_089b41c4be8f, 1):
                _289f93d014bd = _1f90b9ebd29c(_4c2d32208955)
                _7c45548c2d92 = self._5a6f43beb02f
                for _a514376b94be in _51761d33df9d:
                    if _c04de5307634(_289f93d014bd) >= _c04de5307634(_a514376b94be) and _289f93d014bd[:_c04de5307634(_a514376b94be)] == _a514376b94be:
                        _7c45548c2d92 = _1dfe0f012e02[_a514376b94be]
                        break
                _bb4b7969453b._97193a8ff77c(_7c45548c2d92)

            return _bb4b7969453b
        
        _572cfc777a7d, _93d54042441a = {}, {}
        for _149a491157fc in _68a7a4eeea94:
            _7bc116611282 = _68a7a4eeea94[_149a491157fc]
            _904783ff4d2c = _31645fe66d6c._00cc97563355(_149a491157fc, _4e161416dfa9)
            _155dd247d0d6 = _7bc116611282._191358ea6f73() if _e45cbc4997b7(_7bc116611282, _50728aa02373._9bb48afd74d0) else _4ccaf31d72a4(_7bc116611282)
            _ab50476194ab = _904783ff4d2c._191358ea6f73() if _e45cbc4997b7(_904783ff4d2c, _50728aa02373._9bb48afd74d0) else _4ccaf31d72a4(_904783ff4d2c) if _904783ff4d2c else _4e161416dfa9
            if _ab50476194ab is not _4e161416dfa9:
                _7896f99b0df4 = _a734c6fdb8f9(_ab50476194ab, _fd77f17a0e69)
                _90f99d6e2445 = _f176af0cb1d8(_7896f99b0df4, _1dfe0f012e02, _149a491157fc == 1 or _c9fb71b462f0, _149a491157fc)
                _5b191594e4e4 = _a734c6fdb8f9(_155dd247d0d6, _fd77f17a0e69)
                _0cce36059a9e = _f176af0cb1d8(_5b191594e4e4, _1dfe0f012e02, _149a491157fc == 1 or _c9fb71b462f0, _149a491157fc)
                if _c04de5307634(_0cce36059a9e) < _c04de5307634(_90f99d6e2445):
                    _0cce36059a9e += [0] * (_c04de5307634(_90f99d6e2445) - _c04de5307634(_0cce36059a9e))
                elif _c04de5307634(_0cce36059a9e) > _c04de5307634(_90f99d6e2445):
                    _0cce36059a9e = _0cce36059a9e[:_c04de5307634(_90f99d6e2445)]
            else:
                _5b191594e4e4 = _a734c6fdb8f9(_155dd247d0d6, _fd77f17a0e69)
                _0cce36059a9e = _f176af0cb1d8(_5b191594e4e4, _1dfe0f012e02, _149a491157fc == 1 or _c9fb71b462f0, _149a491157fc)
                _90f99d6e2445 = [_a82cdf733388] * _c04de5307634(_0cce36059a9e)
            _572cfc777a7d[_149a491157fc] = _50728aa02373._3dbff4cf99c3(_0cce36059a9e, _d8e1905f3566=_a6c009dfc46f, _3cd1c5f8fa33=_50728aa02373._3fb0d7cc4522)
            _93d54042441a[_149a491157fc] = _50728aa02373._3dbff4cf99c3(_90f99d6e2445, _d8e1905f3566=_a6c009dfc46f, _3cd1c5f8fa33=_50728aa02373._3fb0d7cc4522)
        return _572cfc777a7d, _93d54042441a

    def _83af5b3cc32f(self, _8e084a53c4d8):
        _50728aa02373._d3b8f44143da._d6f3c712f05a._2c1fc7aa0e26(self._64d8707f1003(), _f6097005a8cb=1.0)
    
    def _961f3b47901d(self, _8e084a53c4d8):
        for _d6f10372766c in self._64d8707f1003():
            if _d6f10372766c is not _4e161416dfa9:
                _d6f10372766c._2f3ff8b4fad5._0728f2256900(-5, 5)

    def _d2deabde5eae(self):
        _d3c2f6a4ff72 = 0
        for _d6f10372766c in self._64d8707f1003():
            if _d6f10372766c._71754d81f14f is not _4e161416dfa9:
                _22fbafed3e73 = _d6f10372766c._71754d81f14f._b3ebf0b67645()._2f3ff8b4fad5._c60a60d5fd0c(2)
                _d3c2f6a4ff72 += _22fbafed3e73._16635e6db8b4() ** 2
        return _d3c2f6a4ff72 ** 0.5  # L2 norm

    def _562c10f560c6(self):
        _e463bfe9d793 = [_7bc116611282 for _7bc116611282 in self._64d8707f1003() if _7bc116611282._42db6d892803]
        if not _e463bfe9d793:
            _8ae9b9c98c60("No trainable parameters. Skipping optimizer creation.")
            return _4e161416dfa9
        
        _a690016c687d = _55bfb331d152(lambda _7bc116611282: _7bc116611282._42db6d892803, self._64d8707f1003())

        _17b73bf76ed3 = {
            "adamw": _50728aa02373._c3845b88981d._381e40e22e6f,
            "adamax": _50728aa02373._c3845b88981d._28a78f96e2bb,
            "adam": _50728aa02373._c3845b88981d._0f423a9513be,
        }
        _aa9c0e4827d4 = _17b73bf76ed3._00cc97563355(self._14ac7b3739ac._685365dcc0e7(), _50728aa02373._c3845b88981d._0f423a9513be)

        _8e084a53c4d8 = _aa9c0e4827d4(_a690016c687d, _b47245a4392b=self._33138853af63._b47245a4392b, _1981331c605d=0.001)

        _87f8c3213850 = self._643f30b37f38._796f7367a84e
        _582b3c8a0636 = _de060d8085c7._819bf97e178f(0.1 * _87f8c3213850)

        _4d48386f28ce = _50728aa02373._c3845b88981d._31723127c3d8._33209ce2e33f(_8e084a53c4d8, _c5728b96808a=lambda _51161ea55216: (_51161ea55216 + 1) / _582b3c8a0636)

        _40a1b40ff91b = _50728aa02373._c3845b88981d._31723127c3d8._64db82148d6a(
            _8e084a53c4d8,
            _722bf4357102=_46d5cf4b20eb(1, _87f8c3213850 - _582b3c8a0636),
            _9d7b4cff20a0=2,
            _7e2d289e7ca7=1e-6
        )
        _31723127c3d8 = _50728aa02373._c3845b88981d._31723127c3d8._ea3548251843(
            _8e084a53c4d8,
            _b1cc480c350b=[_4d48386f28ce, _40a1b40ff91b],
            _9ecabc1351ce=[_582b3c8a0636]
        )
        return {"optimizer": _8e084a53c4d8, "lr_scheduler": {"scheduler": _31723127c3d8, "interval": "epoch", "monitor": "val_loss"}}
