# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _1c3867de70ad, _7e1cca09b9ec
import copy
from _89a37338a1ec import _3d7ca7ae455f
import _8e0b29820b37
import math
import os
from typing import _8aae822b6389
import _98a63548b8d5 as _756e428e76f2
import _de23386ffdeb as _f0440a081492
import _ce4f1ce004ed
import _7f3afba14a76 as _79a0cd0194c3
from _348f6cbc9ac3._28bee0219691._7cd20af4bfdf._3f8b250f46ce import _748ceb1b1ff1
from _4e8f5196abd8 import _b876051e9353, _8b7f156b98d9, _634d17f5123a, _8e733f4704cf, _6b44eb4199c6

from _442edbdc3078._fa63967f34a3._b74fe390204d._3c846e63fb57 import _e29d60209210
from _442edbdc3078._fa63967f34a3._0753a3d77ab0._c9c314d7181c import _811ece3531ca
from _442edbdc3078._fa63967f34a3._0753a3d77ab0._9e87e65d028d import _f9c58f759cbf
from _442edbdc3078._fa63967f34a3._0753a3d77ab0._5a877d60971d import _be94393d281b
from _442edbdc3078._fa63967f34a3._da39d261c179._d9ebaefe54a6 import _88f1d2d4860f
# expose only the classifier from the module
_8b998bd9d8f4 = ["GenLLMLanguageIdentificationClassifier"]

_b4020c24db28 = 'cuda' if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b() else 'cpu'
_7b22af62185e = _1e5ae9a9efdd  # global frozen embedding (kept for compatibility)

    
class _2cd4f4109454(_79a0cd0194c3._24466a66777a):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _292afdd79696(_ce4f1ce004ed._800570aa3b44._c1a0d6d1dfc8):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _9303380561f3(self, _424ae9a17d31: _90d5f478a3a0, _71ac95a0e279: _90d5f478a3a0 = 64):
            _cf5f92f82c60()._3733260a88f1()
            self._2e4fa5abb743 = _ce4f1ce004ed._800570aa3b44._42c60ea1a1dc(_424ae9a17d31, _71ac95a0e279, _aab7ff198b60=_aa1a3ac9b062)
            self._c81b6b1f9e61 = _ce4f1ce004ed._800570aa3b44._1baf698fdfe2(_1b8c23526afc=_5eb8602d2310)
            self._92c138832e0f = _ce4f1ce004ed._800570aa3b44._42c60ea1a1dc(_71ac95a0e279, _424ae9a17d31, _aab7ff198b60=_aa1a3ac9b062)
            # start adapter near-zero so initial behavior is identity
            _ce4f1ce004ed._800570aa3b44._2eaec108d921._847dcef6eada(self._92c138832e0f._1cc58f02cc64)
            _ce4f1ce004ed._800570aa3b44._2eaec108d921._c1897987c0c3(self._2e4fa5abb743._1cc58f02cc64, _828513110181=math._5399e1f8fe83(5))

        def _9eaf84d6abe0(self, _17dd1a5c197b: _ce4f1ce004ed._9ef5ebd0563c) -> _ce4f1ce004ed._9ef5ebd0563c:
            # supports x shape (B, L, D) or (B, D)
            if _17dd1a5c197b._424ae9a17d31() == 2:
                _ae753ab839dc = self._92c138832e0f(self._c81b6b1f9e61(self._2e4fa5abb743(_17dd1a5c197b)))
                return _17dd1a5c197b + _ae753ab839dc
            _9cfd26dfa1fe, _d94f8e485fc5, _201cc06fc88b = _17dd1a5c197b._bae29eac854a
            _cdf9cb9eceb4 = _17dd1a5c197b._3c1a219503fb(-1, _201cc06fc88b)                    # (B*L, D)
            _cdf9cb9eceb4 = self._92c138832e0f(self._c81b6b1f9e61(self._2e4fa5abb743(_cdf9cb9eceb4)))  # (B*L, D)
            _cdf9cb9eceb4 = _cdf9cb9eceb4._3c1a219503fb(_9cfd26dfa1fe, _d94f8e485fc5, _201cc06fc88b)
            return _17dd1a5c197b + _cdf9cb9eceb4
        
    class _0fe7fc757b9d(_ce4f1ce004ed._800570aa3b44._c1a0d6d1dfc8):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _9303380561f3(self, _692e8aee8ca1, _e209be998ad4=-5, _bd0c0b4b6440=5):
            _cf5f92f82c60()._3733260a88f1()
            self._692e8aee8ca1 = _692e8aee8ca1
            self._e209be998ad4 = _e209be998ad4
            self._bd0c0b4b6440 = _bd0c0b4b6440
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _9eaf84d6abe0(self, *_7b20723ef4cc, **_93e80b6e30e1):
            _7b20723ef4cc = _255b729b7126(
                _7f64c0017b58._75312abd023b(_ce4f1ce004ed._107c6b1f7dcf)._518c0d0554f7(-10, 10) if _b11ec8a2a613(_7f64c0017b58, _ce4f1ce004ed._9ef5ebd0563c) and _7f64c0017b58._ea6f3221ac70 != _ce4f1ce004ed._107c6b1f7dcf else _7f64c0017b58
                for _7f64c0017b58 in _7b20723ef4cc
            )
            for _516e63e03e48, _7f64c0017b58 in _188f3e52ae6a(_7b20723ef4cc):
                if _b11ec8a2a613(_7f64c0017b58, _ce4f1ce004ed._9ef5ebd0563c) and not _ce4f1ce004ed._8abf813616a3(_7f64c0017b58)._05f82477c92f():
                    _7f64c0017b58 = _ce4f1ce004ed._2d76992d0bd5(_7f64c0017b58)
            _1704016d0e51 = self._692e8aee8ca1(*_7b20723ef4cc, **_93e80b6e30e1)
            if _b11ec8a2a613(_1704016d0e51, _ce4f1ce004ed._9ef5ebd0563c):
                _1704016d0e51 = _1704016d0e51._75312abd023b(_ce4f1ce004ed._107c6b1f7dcf)
                if not _ce4f1ce004ed._8abf813616a3(_1704016d0e51)._05f82477c92f():
                    _1704016d0e51 = _ce4f1ce004ed._2d76992d0bd5(_1704016d0e51)
                _1704016d0e51._e320f66fe953(self._e209be998ad4, self._bd0c0b4b6440)
            return _1704016d0e51

    # --- original __init__ signature and body preserved ---
    def _9303380561f3(
        self,
        _3ea53e387189,
        _f8e959efa328,
        _7b53309afd5b,
        _b7e80a993b5b,
        _80cb2b5f88a2,
        _5c6503c0967c,
        _c3196c638ea5,
        _7ddb9056b70d,
        _c75d892478a9,
        _bb7328b9f0b5,
        _e6012ccafeed,
        _d6c4f6ca30d6: _90d5f478a3a0 = 20,
        _58a3b330e458 = _1e5ae9a9efdd,
        _11522512a655=_1e5ae9a9efdd,
        _484f996c0c14=0.9,
        _4e804c3780d3:_a30cf1b915d2=_1e5ae9a9efdd,
    ):
        _cf5f92f82c60(_8a25ebe17656, self)._3733260a88f1()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._8234d229f01f({
            "lr": _00b0089067aa(_7b53309afd5b),
            "optimizer": _a30cf1b915d2(_b7e80a993b5b),
            "num_backbone_model_units_unfrozen": _90d5f478a3a0(_c3196c638ea5),
            "loss_type": _a30cf1b915d2(_7ddb9056b70d),
            "is_train": _6941a31e5379(_c75d892478a9),
            "random_seed": _90d5f478a3a0(_d6c4f6ca30d6),
        })
        self._d6c4f6ca30d6 = _d6c4f6ca30d6
        _79a0cd0194c3._74514354d8a5(_d6c4f6ca30d6, _d4b149114031=_5eb8602d2310)
        _ce4f1ce004ed._9bb51a0768c6(_d6c4f6ca30d6)
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            _ce4f1ce004ed._a96b38544560._d790348cad84(_d6c4f6ca30d6)
        _756e428e76f2.random._dfd51259f45c(_d6c4f6ca30d6)
        self._11522512a655 = _90d5f478a3a0(_11522512a655) if _11522512a655 is not _1e5ae9a9efdd else _1e5ae9a9efdd
        self._bb7328b9f0b5 = _bb7328b9f0b5
        self._4e804c3780d3 = _4e804c3780d3
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._bb7328b9f0b5._59fe6141df74 and "<PAD>" not in self._bb7328b9f0b5._2d7410f4661b():
            self._bb7328b9f0b5._bd58874c6c55(["<PAD>"], _4156f5e0b6ab=_aa1a3ac9b062)
            _87bf06e9a381 = self._bb7328b9f0b5._5f9b18cd2874("<PAD>")
            _ffc4f4a776cc(f"Added padding token  <PAD> with (id: {_87bf06e9a381})")
        
        self._02b85a278855 = _bb7328b9f0b5._a66c5102c9b5(" ", _880faf3dc0e0=_aa1a3ac9b062)[0]
        self._3680894c959b = (
            _ce4f1ce004ed._2f948f47b688("cuda:{}"._b5bf5841241e(_5c6503c0967c["gpu_local_rank"]))
            if _5c6503c0967c["gpu_local_rank"] != -1
            else "cpu"
        )
        self._58a3b330e458 = _58a3b330e458
        self._484f996c0c14 = _484f996c0c14
        self._f8e959efa328 =  ["unk"] + _f8e959efa328 if self._484f996c0c14 > 0 else _f8e959efa328
        self._4b51e4fc0f56 = _f41720717511(self._f8e959efa328)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._f818931ef0a7 = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _ffc0d4f9937c in self._f8e959efa328:
            if _f41720717511(self._bb7328b9f0b5._a66c5102c9b5(_ffc0d4f9937c, _880faf3dc0e0=_aa1a3ac9b062)) > 1:
                token = f"{_ffc0d4f9937c}"
                if token not in self._bb7328b9f0b5._2d7410f4661b():
                    self._bb7328b9f0b5._bd58874c6c55([token], _4156f5e0b6ab=_aa1a3ac9b062)
                    _87bf06e9a381 = self._bb7328b9f0b5._5f9b18cd2874(token)
                    _ffc4f4a776cc(f"Added class '{_ffc0d4f9937c}' Token: {token} (id: {_87bf06e9a381})")

        # Map every class to single token ID
        self._f818931ef0a7 = {
            _46dabc4170ab: [self._bb7328b9f0b5._5f9b18cd2874(f"{_ffc0d4f9937c}")]
            for _46dabc4170ab, _ffc0d4f9937c in _188f3e52ae6a(self._f8e959efa328)
        }

        self._cbe73041bf8b = {_255b729b7126(_0bda0f737723): _5c230fd5d9ee for _5c230fd5d9ee, _0bda0f737723 in self._f818931ef0a7._4f3906ac6de3()}
        self._0ed9a993b670 = _7e1cca09b9ec(_15cc7dfaec56)
        for _1f4ef11df82c, _0bda0f737723 in self._f818931ef0a7._4f3906ac6de3():
            self._0ed9a993b670[_f41720717511(_0bda0f737723)]._ab923f31365d((_1f4ef11df82c, _0bda0f737723))
        self._caf61f9c620f = 0
        _ffc4f4a776cc(f"SEQ {self._f818931ef0a7} and {self._cbe73041bf8b}")
        self._698a781d762c = _bb7328b9f0b5._59fe6141df74 or _bb7328b9f0b5._b4e9ae975b08
        self._80cb2b5f88a2 = _80cb2b5f88a2
        self._e71fa9d40eb6 = "multiclass"
        self._f0f5d6024680 = -100
        self._51dc63f5f4fc = _bb7328b9f0b5._a66c5102c9b5("assistant<|end_header_id|>\n\n", _880faf3dc0e0=_aa1a3ac9b062)
        self._f9a9f3406bd1 = self._ff7ff1845bf6()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._675894eb6a50 = _3ea53e387189
        # Resize vocab based token embeddings
        self._675894eb6a50._180baa158675(_f41720717511(self._bb7328b9f0b5))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._675894eb6a50._389a40d4d116(_aa1a3ac9b062)
        _e1bd36f57522 = _88f1d2d4860f()  # bfloat16 or float16

        for _c326f065a98e, _692e8aee8ca1 in self._6f0b3ab7d8da():
            if not _d6b24850d042(_874118ee4b17._b40af3a668ce for _874118ee4b17 in _692e8aee8ca1._361a7bb0e5c4(_eec1461090e1=_aa1a3ac9b062)):
                # FROZEN → BF16 (save memory)
                _692e8aee8ca1._75312abd023b(_ea6f3221ac70=_e1bd36f57522)
            else:
                # TRAINABLE → FP32 (stable grads)
                _692e8aee8ca1._75312abd023b(_ea6f3221ac70=_ce4f1ce004ed._107c6b1f7dcf)
        self._675894eb6a50._75312abd023b(self._3680894c959b)
        if _54e75872403c(self._675894eb6a50, "gradient_checkpointing_enable"):
            self._675894eb6a50._de52f33577c0()
        # determine embedding dim robustly from model config if available
        _a5eaaf912e8e = _6a28713a7c2d(_6a28713a7c2d(self._675894eb6a50, "config", _1e5ae9a9efdd), "hidden_size", _1e5ae9a9efdd)
        if _a5eaaf912e8e is _1e5ae9a9efdd:
            # fallback to common default — change if your model uses a different hidden size
            _a5eaaf912e8e = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _54e75872403c(self._675894eb6a50, "lm_head") and _6a28713a7c2d(self._675894eb6a50, "lm_head") is not _1e5ae9a9efdd:
            self._5af8a0af1e74 = self._675894eb6a50._9ad190d1738b
        else:
            _294350aa9c6b = _6a28713a7c2d(self._675894eb6a50, "get_output_embeddings", _1e5ae9a9efdd)
            self._5af8a0af1e74 = _294350aa9c6b() if _75a91d0e575e(_294350aa9c6b) else _1e5ae9a9efdd

        # mark presence and ensure module (if any) is on the same device
        self._b37d64426d86 = self._5af8a0af1e74 is not _1e5ae9a9efdd
        if self._b37d64426d86:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._5af8a0af1e74._75312abd023b(self._3680894c959b)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._0c3fb2dac776 = self._e932ad807add(_424ae9a17d31=_a5eaaf912e8e, _71ac95a0e279=64)
        self._0c3fb2dac776._75312abd023b(self._3680894c959b)
        for _874118ee4b17 in self._0c3fb2dac776._361a7bb0e5c4():
            _874118ee4b17._b40af3a668ce = _5eb8602d2310
            
        if _c3196c638ea5 > 0:
            if "llama" in self._58a3b330e458:
                for _c6c25b688485 in self._675894eb6a50._361a7bb0e5c4():
                    if not _c6c25b688485._cf7bd90ecfba:
                        _c6c25b688485 = _c6c25b688485._dc415e5e766f()
                    _c6c25b688485._b40af3a668ce = _aa1a3ac9b062  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _60bbc319be36 = self._675894eb6a50._1e060206d938._6abda6235230  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _168403a56254 in _60bbc319be36[-_c3196c638ea5:]:
                    for _c6c25b688485 in _168403a56254._361a7bb0e5c4():
                        if _b11ec8a2a613(_c6c25b688485, _ce4f1ce004ed._9ef5ebd0563c) and (_c6c25b688485._988169618648() or _ce4f1ce004ed._205ad2370614(_c6c25b688485)):
                            _c6c25b688485._b40af3a668ce = _5eb8602d2310
                if _54e75872403c(self._675894eb6a50, "lm_head"):
                    self._675894eb6a50._9ad190d1738b._b40af3a668ce = _5eb8602d2310

        self._907aaba5cc9f = 1
        _ffc4f4a776cc(f"DEBUG xth_batch init {self._907aaba5cc9f}")
        global _7b22af62185e
        _7b22af62185e = copy._0c2acd22523a(self._675894eb6a50)._a81ce705e7e9()
        self._7b53309afd5b = _7b53309afd5b

        self._46707e1142b0 = {}
        self._e006f5dce1b9 = {}

        # Loss function initialization
        if _7ddb9056b70d._3bf8318587bc() == "class_weighted_cross_entropy_loss":
            self._e006f5dce1b9['criterion'] = _f9c58f759cbf(_80cb2b5f88a2=self._80cb2b5f88a2,
                                                            _2f948f47b688=self._3680894c959b,
                                                            _09ed6bbaf7ff=self._f0f5d6024680,
                                                            _9028eba877ca=self._02b85a278855)
        elif _7ddb9056b70d._3bf8318587bc() == "focal_loss":
            self._e006f5dce1b9['criterion'] = _be94393d281b(_0e425f10b653=0.25,
                                                     _2f948f47b688=self._3680894c959b,
                                                     _09ed6bbaf7ff=self._f0f5d6024680,
                                                     _9028eba877ca=self._02b85a278855)
        elif _7ddb9056b70d._3bf8318587bc() == "class_weighted_focal_loss":
            self._e006f5dce1b9['criterion'] = _be94393d281b(_0e425f10b653=self._80cb2b5f88a2,
                                                     _2f948f47b688=self._3680894c959b,
                                                     _09ed6bbaf7ff=self._f0f5d6024680,
                                                     _9028eba877ca=self._02b85a278855)
        elif _7ddb9056b70d._3bf8318587bc() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._e006f5dce1b9['criterion'] = _811ece3531ca(_0e425f10b653=self._80cb2b5f88a2,
                                                                      _ff1a287f5181='type1',
                                                                      _2f948f47b688=self._3680894c959b,
                                                                      _09ed6bbaf7ff=self._f0f5d6024680,
                                                                      _9028eba877ca=self._02b85a278855)
        elif _7ddb9056b70d._3bf8318587bc() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._e006f5dce1b9['criterion'] = _811ece3531ca(_0e425f10b653=self._80cb2b5f88a2,
                                                                      _ff1a287f5181='type2',
                                                                      _2f948f47b688=self._3680894c959b,
                                                                      _09ed6bbaf7ff=self._f0f5d6024680,
                                                                      _9028eba877ca=self._02b85a278855)
        elif _7ddb9056b70d._3bf8318587bc() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._e006f5dce1b9['criterion'] = _811ece3531ca(_0e425f10b653=self._80cb2b5f88a2,
                                                                      _ff1a287f5181='type3',
                                                                      _2f948f47b688=self._3680894c959b,
                                                                      _09ed6bbaf7ff=self._f0f5d6024680,
                                                                      _9028eba877ca=self._02b85a278855)
        else:
            self._e006f5dce1b9['criterion'] = _f9c58f759cbf(_2f948f47b688=self._3680894c959b,
                                                            _09ed6bbaf7ff=self._f0f5d6024680,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._c50897eb71ed = 0.99
        self._fbc761fce414 = 0.3
        self._b81cd207e5f0 = 0.30
        self._a797f6cc9685 = 0.25
        self._448ef02f53c6 = 0.6
        self._4a01af83f553 = 0.995
        self._9465d1eeb664 = 0.60
        self._e1ce3015638e = 0.20
        self._654c9cbb84a1 = _6a28713a7c2d(self, "batch_counter", 0)


        self._10002ca5c877 = []
        self._1009735c9c88 = []

        self._1be6cc768f32 = _b7e80a993b5b._3bf8318587bc()
        self._3f2365b3e9d8()

        self._cfaffe168da9(self._675894eb6a50)
    
    def _b63625855ccf(self):
        # rebuild all metrics on the correct device
        self._46707e1142b0['micro_accuracy'] = _b876051e9353(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3="micro",
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['macro_accuracy'] = _b876051e9353(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3="macro",
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['macro_precision'] = _634d17f5123a(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3="macro",
            _6edd7a5d40a3=self. _e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['macro_recall'] = _8e733f4704cf(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3="macro",
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['macro_f1'] = _6b44eb4199c6(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3="macro",
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['classwise_accuracy'] = _b876051e9353(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3=_1e5ae9a9efdd,
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['classwise_precision'] = _634d17f5123a(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3=_1e5ae9a9efdd,
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['classwise_recall'] = _8e733f4704cf(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3=_1e5ae9a9efdd,
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['classwise_f1'] = _6b44eb4199c6(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _2394fdd573d3=_1e5ae9a9efdd,
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)

        self._46707e1142b0['confmat'] = _8b7f156b98d9(
            _4b51e4fc0f56=_f41720717511(self._f8e959efa328),
            _6edd7a5d40a3=self._e71fa9d40eb6,
            _09ed6bbaf7ff=self._f0f5d6024680,
        )._75312abd023b(self._3680894c959b)


    def _09e63ea23425(self, _7f4c236462d8=_1e5ae9a9efdd):
        """Calculate batch counts and set xth_batch_to_consider."""
        _a82eb2c74816 = 0
        _886d1e52c5b5 = 0
        if self._136b9f4582c6._dc5224b7e5c9 is not _1e5ae9a9efdd:
            if _54e75872403c(self._136b9f4582c6._dc5224b7e5c9, 'train_dataset') and self._136b9f4582c6._dc5224b7e5c9._ba4aea0423e8 is not _1e5ae9a9efdd:
                _a82eb2c74816 = _f41720717511(self._136b9f4582c6._dc5224b7e5c9._ba4aea0423e8)
            if _54e75872403c(self._136b9f4582c6._dc5224b7e5c9, 'val_dataset') and self._136b9f4582c6._dc5224b7e5c9._490970c6e3bf is not _1e5ae9a9efdd:
                _886d1e52c5b5 = _f41720717511(self._136b9f4582c6._dc5224b7e5c9._490970c6e3bf)
            _0fe8337539ab = self._136b9f4582c6._dc5224b7e5c9._0fe8337539ab
            _5c6875561869 = (_a82eb2c74816 + _0fe8337539ab - 1) // _0fe8337539ab if _a82eb2c74816 > 0 else 1
            _9ace66d0e43c = (_886d1e52c5b5 + _0fe8337539ab - 1) // _0fe8337539ab if _886d1e52c5b5 > 0 else 1
            _3cb08a9b94cb = _0a2f3b4b9be5(_5c6875561869, _9ace66d0e43c) if _886d1e52c5b5 > 0 else _5c6875561869
            _0eaaa97ba89e = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._907aaba5cc9f = 1
            _ffc4f4a776cc(f"DEBUG Batch Info: num_train_batches={_5c6875561869}, num_val_batches={_9ace66d0e43c}, xth_batch_to_consider={self._907aaba5cc9f}")

    def _ff11940689eb(self, _c3b248e4bee7, _d02d03f0f0d8):
        if _c3b248e4bee7._3bf8318587bc() == "parametric_relu":
            return _ce4f1ce004ed._800570aa3b44._36f5a645f207(_d02d03f0f0d8=1)
        elif _c3b248e4bee7._3bf8318587bc() == "leaky_relu":
            return _ce4f1ce004ed._800570aa3b44._7f2df8a51d45(_1b8c23526afc=_aa1a3ac9b062)
        else:
            return _ce4f1ce004ed._800570aa3b44._1baf698fdfe2(_1b8c23526afc=_aa1a3ac9b062)

    def _5361f5ea4f9e(self, _692e8aee8ca1, _0649c8327420=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _c326f065a98e, _4a112dc15247 in _692e8aee8ca1._1d5fc9ea3582():
            _c81e993c3ccf = f"{_0649c8327420}.{_c326f065a98e}" if _0649c8327420 else _c326f065a98e

            def _062dd816e08c(_3043d0193d39, _7f64c0017b58, _ae753ab839dc):
                if _b11ec8a2a613(_ae753ab839dc, _ce4f1ce004ed._9ef5ebd0563c) and _ae753ab839dc._519f80e92bc0()._d6b24850d042():
                    _ffc4f4a776cc(f"NaN detected in {_c81e993c3ccf} ({_3043d0193d39._0fe05a7aa729.__name__}) ({_ae753ab839dc._ea6f3221ac70})")

            _4a112dc15247._3ffecc5526b4(_f8b76b2ca355)

            self._cfaffe168da9(_4a112dc15247, _c81e993c3ccf)

    def _d178373ec22e(self, _692e8aee8ca1):
        return _d6b24850d042(_874118ee4b17._b40af3a668ce for _874118ee4b17 in _692e8aee8ca1._361a7bb0e5c4())

    def _216b33cdc6a9(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _0f5b46e561cb = []
        for _c326f065a98e, _692e8aee8ca1 in self._6f0b3ab7d8da():
            if not self._44ca8fbc7c39(_692e8aee8ca1):
                continue
            _7d54510bc4c4 = (
                "norm" in _c326f065a98e._98ba3098af1b() or 
                "linear4bit" in _c326f065a98e._98ba3098af1b() or 
                _d6b24850d042(_c81b6b1f9e61 in _c326f065a98e._98ba3098af1b() for _c81b6b1f9e61 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _c326f065a98e._98ba3098af1b() or 
                "dropout" in _c326f065a98e._98ba3098af1b() or 
                _b11ec8a2a613(_692e8aee8ca1, (_748ceb1b1ff1, _ce4f1ce004ed._800570aa3b44._42c60ea1a1dc, _ce4f1ce004ed._800570aa3b44._5e095c1b2f85))
            )
            if _7d54510bc4c4:
                if _54e75872403c(_692e8aee8ca1, "eps"):
                    _692e8aee8ca1._981c85ce9864 = 1e-3
                _692e8aee8ca1 = _692e8aee8ca1._75312abd023b(_ce4f1ce004ed._107c6b1f7dcf)
                if not _b11ec8a2a613(_692e8aee8ca1, _8a25ebe17656._61afe8126eb4):
                    _0f5b46e561cb._ab923f31365d((_c326f065a98e, _8a25ebe17656._61afe8126eb4(_692e8aee8ca1, _e209be998ad4=-10, _bd0c0b4b6440=10)))
        for _c326f065a98e, _56f2ceca748c in _0f5b46e561cb:
            _6cef7233f743, _bf0a3f059974 = self._e4f0d770fb2d(_c326f065a98e)
            if _6cef7233f743 is not _1e5ae9a9efdd:
                _f453ec14ae37(_6cef7233f743, _bf0a3f059974, _56f2ceca748c)

    def _0f23e56e5316(self, _492dbb9756ba):
        """Finds the parent module and attribute name given the full module path."""
        _b1a4ba65e00d = _492dbb9756ba._dea4a0ee332f('.')
        _51e96e87a44f = self
        for _6fdc1070107d in _b1a4ba65e00d[:-1]:
            _51e96e87a44f = _6a28713a7c2d(_51e96e87a44f, _6fdc1070107d, _1e5ae9a9efdd)
            if _51e96e87a44f is _1e5ae9a9efdd:
                return _1e5ae9a9efdd, _1e5ae9a9efdd
        return _51e96e87a44f, _b1a4ba65e00d[-1]

    def _220bc7a5bbe6(self, _2a7d289baa64: _ce4f1ce004ed._9ef5ebd0563c, _e1a6a85c19c0: _ce4f1ce004ed._9ef5ebd0563c, _75148e4753bb: _ce4f1ce004ed._9ef5ebd0563c) -> _7366a02b9424:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _2f948f47b688 = _2a7d289baa64._2f948f47b688

        # 1) gating w (use cached per-example teacher_conf if available)
        _8277abe3a687 = _6a28713a7c2d(self, "_last_teacher_conf", _1e5ae9a9efdd)
        if _8277abe3a687 is _1e5ae9a9efdd:
            # no teacher info => w = 0 (no distillation)
            _5e1155345df3 = 0.0
        else:
            _034ee89a6294 = (_8277abe3a687 >= _00b0089067aa(_6a28713a7c2d(self, "teacher_conf_tau", 0.6)))._00b0089067aa()
            _5e1155345df3 = _00b0089067aa(_034ee89a6294._a7ba277cdbd3()._31f1b2ea0a41()._c5ad376f4247()) if _034ee89a6294._b984b20bc4a7() > 0 else 0.0

        # apply gating to the batch scalars
        _6f81fbdf681b = _e1a6a85c19c0 * _00b0089067aa(_5e1155345df3)
        _6f9d43fe3eaa = _75148e4753bb * _00b0089067aa(_5e1155345df3)

        # 2) EMAs for autoscaling
        _3015c9b37d4f = _00b0089067aa((_6f81fbdf681b + _6f9d43fe3eaa)._dc415e5e766f()._31f1b2ea0a41()._c5ad376f4247())
        _de2ed72ff8bd = _00b0089067aa(_2a7d289baa64._dc415e5e766f()._31f1b2ea0a41()._c5ad376f4247())
        if _6a28713a7c2d(self, "ema_task", _1e5ae9a9efdd) is _1e5ae9a9efdd:
            self._4984871b4d7e = _de2ed72ff8bd
            self._0e7ed7041581 = _3015c9b37d4f + 1e-12
        else:
            _0e425f10b653 = _00b0089067aa(_6a28713a7c2d(self, "ema_alpha", 0.99))
            self._4984871b4d7e = _0e425f10b653 * _00b0089067aa(self._4984871b4d7e) + (1.0 - _0e425f10b653) * _de2ed72ff8bd
            self._0e7ed7041581  = _0e425f10b653 * _00b0089067aa(self._0e7ed7041581)  + (1.0 - _0e425f10b653) * _3015c9b37d4f

        _5a51e6d70bd4 = _00b0089067aa(_6a28713a7c2d(self, "distill_target_ratio", 0.3))
        _57345ba644d6 = (_00b0089067aa(self._4984871b4d7e) / (_00b0089067aa(self._0e7ed7041581) + 1e-12)) * _5a51e6d70bd4
        _7471fce8f920 = _00b0089067aa(_57345ba644d6)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _91925b025d8f = _00b0089067aa(_6a28713a7c2d(self._136b9f4582c6, "current_epoch", _6a28713a7c2d(self._136b9f4582c6, "global_step", 0.0)))
        _6831bb3b260a = _00b0089067aa(_b1db98d974f3(1, _6a28713a7c2d(self._136b9f4582c6, "max_epochs", 1)))
        _4d3c61922c48 = _0a2f3b4b9be5(_b1db98d974f3(_91925b025d8f / _6831bb3b260a, 0.0), 1.0)
        _900ab64fb724 = 0.30
        _0bfae14bdfa0 = _00b0089067aa(_6a28713a7c2d(self, "kl_base", 0.30)) * _0a2f3b4b9be5(_4d3c61922c48 / _900ab64fb724, 1.0)
        _a797f6cc9685 = _00b0089067aa(_6a28713a7c2d(self, "cos_base", 0.25))
        _74feaa07843e = _a797f6cc9685 + (0.10 - _a797f6cc9685) * _4d3c61922c48

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _0115543ac25b = _00b0089067aa(self._b413ee7cb85d._a7ba277cdbd3()._31f1b2ea0a41()._c5ad376f4247()) if _6a28713a7c2d(self, "_last_teacher_conf", _1e5ae9a9efdd) is not _1e5ae9a9efdd else 0.0
        if _6a28713a7c2d(self, "ema_teacher_conf", _1e5ae9a9efdd) is _1e5ae9a9efdd:
            self._1e03a0942272 = _0115543ac25b
        else:
            _9cfd26dfa1fe = _00b0089067aa(_6a28713a7c2d(self, "teacher_conf_beta", 0.995))
            self._1e03a0942272 = _9cfd26dfa1fe * _00b0089067aa(self._1e03a0942272) + (1.0 - _9cfd26dfa1fe) * _0115543ac25b

        _9465d1eeb664 = _00b0089067aa(_6a28713a7c2d(self, "tau_warn", 0.60))
        _e1ce3015638e = _00b0089067aa(_6a28713a7c2d(self, "tau_detect", 0.20))
        _e94765adec55 = _b1db98d974f3(1e-12, (_9465d1eeb664 - _e1ce3015638e))
        _2ef38e42ae53 = (_00b0089067aa(self._1e03a0942272) - _e1ce3015638e) / _e94765adec55
        _2ef38e42ae53 = _b1db98d974f3(0.0, _0a2f3b4b9be5(1.0, _2ef38e42ae53))

        _f26097653a1d = _0bfae14bdfa0 * _2ef38e42ae53
        _1dadcd2b3ccc = _74feaa07843e * _2ef38e42ae53

        # 5) final aux term
        _bddab6a2432a = _ce4f1ce004ed._4adcbff5be65(0.0, _2f948f47b688=_2f948f47b688)
        _bddab6a2432a = _bddab6a2432a + (_f26097653a1d * _6f81fbdf681b + _1dadcd2b3ccc * _6f9d43fe3eaa) * _00b0089067aa(_7471fce8f920)

        # diagnostics
        _ae753ab839dc = {
            "aux_term": _bddab6a2432a,
            "kl_batch": _e1a6a85c19c0,
            "contrast_batch": _75148e4753bb,
            "kl_loss": _6f81fbdf681b,
            "contrastive_loss": _6f9d43fe3eaa,
            "w_mean": _5e1155345df3,
            "aux_scale": _00b0089067aa(_7471fce8f920),
            "lambda_kl_eff": _00b0089067aa(_f26097653a1d),
            "lambda_cos_eff": _00b0089067aa(_1dadcd2b3ccc),
            "teacher_conf_mean": _00b0089067aa(self._1e03a0942272),
            "shift_r": _00b0089067aa(_2ef38e42ae53)
        }
        return _ae753ab839dc

    def _9eaf84d6abe0(self, _c707bea84a5d):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _c707bea84a5d = _c707bea84a5d._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)
        _cd59944b7152 = (_c707bea84a5d != self._bb7328b9f0b5._59fe6141df74)._75312abd023b(_ea6f3221ac70=_ce4f1ce004ed._6941a31e5379, _2f948f47b688=self._3680894c959b, _758992430a0b=_5eb8602d2310)

        # model forward (request hidden states)
        _e6735e1b32db = self._675894eb6a50(
            _c707bea84a5d=_c707bea84a5d,
            _cd59944b7152=_cd59944b7152,
            _d5b2977b9012=_5eb8602d2310,
            _a30b8296b7c7=_5eb8602d2310,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _3e2d479ae863 = _6a28713a7c2d(_e6735e1b32db, "last_hidden_state", _1e5ae9a9efdd)
        if _3e2d479ae863 is _1e5ae9a9efdd:
            _3e2d479ae863 = _e6735e1b32db._3a741d29bcb0[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _3e2d479ae863._ea6f3221ac70 != _ce4f1ce004ed._107c6b1f7dcf:
            _3e2d479ae863 = _3e2d479ae863._75312abd023b(_ce4f1ce004ed._107c6b1f7dcf)
        _ae5abee78734 = self._0c3fb2dac776(_3e2d479ae863)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._b37d64426d86:
            _c6fd137e3881 = self._5af8a0af1e74(_ae5abee78734)
        else:
            _c6fd137e3881 = _e6735e1b32db._c6fd137e3881


        _c6fd137e3881 = _c6fd137e3881._75312abd023b(_ce4f1ce004ed._107c6b1f7dcf)._518c0d0554f7(-20, 20)

        # default zero scalars
        _6f81fbdf681b = _ce4f1ce004ed._4adcbff5be65(0.0, _2f948f47b688=self._3680894c959b)
        _6f9d43fe3eaa = _ce4f1ce004ed._4adcbff5be65(0.0, _2f948f47b688=self._3680894c959b)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _3ea550bab938 = _6a28713a7c2d(self, "trainer", _1e5ae9a9efdd)
        _9e48421a7107 = _aa1a3ac9b062
        if _3ea550bab938 is not _1e5ae9a9efdd:
            _9e48421a7107 = _6941a31e5379(_6a28713a7c2d(self._136b9f4582c6, "training", _aa1a3ac9b062) or _6a28713a7c2d(self._136b9f4582c6, "validating", _aa1a3ac9b062))

        if _9e48421a7107 and (_6a28713a7c2d(self, "batch_counter", 0) % _6a28713a7c2d(self, "xth_batch_to_consider", 1) == 0):
            with _ce4f1ce004ed._f6384fd6ec88():
                _e2ea9bb56213 = _7b22af62185e(
                    _c707bea84a5d=_c707bea84a5d,
                    _cd59944b7152=_cd59944b7152,
                    _d5b2977b9012=_5eb8602d2310,
                    _a30b8296b7c7=_5eb8602d2310,
                )
                _6f757e021b11 = _6a28713a7c2d(_e2ea9bb56213, "last_hidden_state", _1e5ae9a9efdd)
                if _6f757e021b11 is _1e5ae9a9efdd:
                    _6f757e021b11 = _e2ea9bb56213._3a741d29bcb0[-1]

            # compute embedding-level KL + contrastive (scalar)
            _6f81fbdf681b, _6f9d43fe3eaa = self._8e88e0d50379(_ae5abee78734, _6f757e021b11, _2f948f47b688=self._3680894c959b)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _7be61854245c(_17dd1a5c197b): return _17dd1a5c197b._a7ba277cdbd3(_424ae9a17d31=1) if _17dd1a5c197b._424ae9a17d31() == 3 else _17dd1a5c197b
            _52865a80c7d3 = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._4c56644f852e(_830680650557(_ae5abee78734), _874118ee4b17=2, _424ae9a17d31=-1, _981c85ce9864=1e-6)
            _bbd9ace008b7 = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._4c56644f852e(_830680650557(_6f757e021b11), _874118ee4b17=2, _424ae9a17d31=-1, _981c85ce9864=1e-6)
            _f7826f3cfd4b = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._757595f2b674(_52865a80c7d3, _bbd9ace008b7, _424ae9a17d31=-1)  # [-1,1]
            _8277abe3a687 = _f7826f3cfd4b._518c0d0554f7(_0a2f3b4b9be5=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._99ad4a4a5862 = _ae5abee78734._dc415e5e766f()
            self._e0e2540f2373 = _6f757e021b11._dc415e5e766f()
            self._b413ee7cb85d = _8277abe3a687._dc415e5e766f()  # shape (B,)

        # increment counter
        self._654c9cbb84a1 = _6a28713a7c2d(self, "batch_counter", 0) + 1

        return _c6fd137e3881, _6f81fbdf681b, _6f9d43fe3eaa


    def _492605a20cdc(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _ac1599da62c4(_692e8aee8ca1, _7b20723ef4cc, _febd664de38f):
            if _d6b24850d042(_7f64c0017b58._ea6f3221ac70 == _ce4f1ce004ed._d0b4f206d3da for _7f64c0017b58 in _7b20723ef4cc if _b11ec8a2a613(_7f64c0017b58, _ce4f1ce004ed._9ef5ebd0563c)):
                _ffc4f4a776cc(f"Layer {_692e8aee8ca1._0fe05a7aa729.__name__} is using float16!")

        for _fa906b7b026c in self._9a201af4761f():
            _a1d898af120d = _fa906b7b026c._3ffecc5526b4(_24d2857651be)
            self._489df6c2f4af._ab923f31365d(_a1d898af120d)

    def _f1a0fcdfb09c(self):
        """Remove all registered forward hooks."""
        for _a1d898af120d in _6a28713a7c2d(self, "amp_hooks", []):
            _a1d898af120d._d66072030e59()
        self._489df6c2f4af = []

    def _8bdd6d4c9a30(self, _c707bea84a5d, _e23744c8fe21, _e2ecf236398e):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _f367c1ad3855 = [self._bb7328b9f0b5._8895b4d80e0a(_76d57ab2f228) for _76d57ab2f228 in _c707bea84a5d]
        _bec4075a5ee3, _48ac994ab167 = [], []

        for _799a9ec3bd8d, _cc23045c2fa5, _c6a6b90bcb7f in _f2bd1ff41614(_f367c1ad3855, _e23744c8fe21, _e2ecf236398e):
            for token, _0ff59db32008, _8c03d383d362 in _f2bd1ff41614(_799a9ec3bd8d, _cc23045c2fa5, _c6a6b90bcb7f):
                if token == self._bb7328b9f0b5._91ad7f520dcf or _8c03d383d362 == self._f0f5d6024680:
                    continue

                _574199c29b62 = (
                    token._99b9b0651538("##") or
                    token._99b9b0651538("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _574199c29b62:
                    continue

                _bec4075a5ee3._ab923f31365d(_0ff59db32008._c5ad376f4247())
                _48ac994ab167._ab923f31365d(_8c03d383d362._c5ad376f4247())

        return _ce4f1ce004ed._4adcbff5be65(_bec4075a5ee3), _ce4f1ce004ed._4adcbff5be65(_48ac994ab167)

    def _6aa2c84c2e1d(self):
        _4a53a20b6ae0 = _ce4f1ce004ed._107c6b1f7dcf
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            _f9ac1c7ff114, _75e9696e6c28 = _ce4f1ce004ed._a96b38544560._d049defc6db2()
            if _f9ac1c7ff114 >= 8:
                _4a53a20b6ae0 = _ce4f1ce004ed._9e23dcedc46d
            else:
                _4a53a20b6ae0 = _ce4f1ce004ed._d0b4f206d3da
        return _4a53a20b6ae0

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _8c96eedf0f22(
        self,
        _5e1eb482f281: _ce4f1ce004ed._9ef5ebd0563c,
        _4a5ff3254615: _ce4f1ce004ed._9ef5ebd0563c,
        _2f948f47b688: _a30cf1b915d2 = "cpu",
    ) -> _8aae822b6389[_ce4f1ce004ed._9ef5ebd0563c, _ce4f1ce004ed._9ef5ebd0563c]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _3dd778cf1181 = 2.0
            # NaN/Inf guard
            _5e1eb482f281 = _5e1eb482f281._518c0d0554f7(_0a2f3b4b9be5=-30, _b1db98d974f3=30)
            _4a5ff3254615 = _4a5ff3254615._518c0d0554f7(_0a2f3b4b9be5=-30, _b1db98d974f3=30)

            # Move once if needed
            _2b1f38f404d0 = _ce4f1ce004ed._2f948f47b688(_2f948f47b688)
            if _5e1eb482f281._2f948f47b688 != _2b1f38f404d0:
                _5e1eb482f281 = _5e1eb482f281._75312abd023b(_2f948f47b688=_2b1f38f404d0, _758992430a0b=_5eb8602d2310, _ea6f3221ac70=self._f9a9f3406bd1)
                _4a5ff3254615 = _4a5ff3254615._75312abd023b(_2f948f47b688=_2b1f38f404d0, _758992430a0b=_5eb8602d2310, _ea6f3221ac70=self._f9a9f3406bd1)

            _0fe8337539ab = _5e1eb482f281._743a579b523d(0)
            _a5eaaf912e8e = _5e1eb482f281._743a579b523d(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _8de8c412e23f = (_0fe8337539ab * _a5eaaf912e8e) > 32_000_000

            if not _8de8c412e23f or _0fe8337539ab <= 8:
                # Direct computation
                _c1f138ab2bb4 = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._b925e867c31d(_5e1eb482f281 / _3dd778cf1181, _424ae9a17d31=-1)
                _e9c61c92fc41 = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._f97a85a0778e(_4a5ff3254615 / _3dd778cf1181, _424ae9a17d31=-1)
                _6f81fbdf681b = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._343d26acaecd(_c1f138ab2bb4, _e9c61c92fc41, _fdc4f63d3e64="batchmean") * (_3dd778cf1181 * _3dd778cf1181)
                _6f9d43fe3eaa = 1 - _ce4f1ce004ed._800570aa3b44._cfc08260d81a._757595f2b674(_5e1eb482f281, _4a5ff3254615, _424ae9a17d31=-1)._a7ba277cdbd3()
                return _6f81fbdf681b, _6f9d43fe3eaa

            # Chunked mode for large inputs
            _e04446c46d15 = _b1db98d974f3(1, _0fe8337539ab // 8)
            _b4bab2507c32, _37f7a85b443c = [], []

            for _516e63e03e48 in _19ac5d4ef0b7(0, _0fe8337539ab, _e04446c46d15):
                _39ac1da89a62 = _5e1eb482f281[_516e63e03e48:_516e63e03e48 + _e04446c46d15]
                _aa59a8f98e55 = _4a5ff3254615[_516e63e03e48:_516e63e03e48 + _e04446c46d15]

                _c1f138ab2bb4 = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._b925e867c31d(_39ac1da89a62 / _3dd778cf1181, _424ae9a17d31=-1)
                _e9c61c92fc41 = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._f97a85a0778e(_aa59a8f98e55 / _3dd778cf1181, _424ae9a17d31=-1)

                _8a6a1e7bbff9 = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._343d26acaecd(_c1f138ab2bb4, _e9c61c92fc41, _fdc4f63d3e64="batchmean") * (_3dd778cf1181 * _3dd778cf1181)
                _ffb853572f1b = _ce4f1ce004ed._800570aa3b44._cfc08260d81a._757595f2b674(_39ac1da89a62, _aa59a8f98e55, _424ae9a17d31=-1)._a7ba277cdbd3()
                _65bc86b267d4 = 1 - _ffb853572f1b

                _b4bab2507c32._ab923f31365d(_8a6a1e7bbff9)
                _37f7a85b443c._ab923f31365d(_65bc86b267d4)

            _6f81fbdf681b = _ce4f1ce004ed._0321d6bd6e06(_b4bab2507c32)._a7ba277cdbd3()
            _6f9d43fe3eaa = _ce4f1ce004ed._0321d6bd6e06(_37f7a85b443c)._a7ba277cdbd3()
            return _6f81fbdf681b, _6f9d43fe3eaa

        except _27377e7cf517 as _6d3ebee63288:
            raise _9b24530d4786(f"KL/contrastive loss computation failed: {_a30cf1b915d2(_6d3ebee63288)}")


    def _a3c49364242a(self, _13bba5cf4b24, _5ed394088021):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _c707bea84a5d = _13bba5cf4b24["input_ids"]
            _ce088dfbc057 = _13bba5cf4b24["labels"]
            _1eac215c62c7 = _13bba5cf4b24._c1038ba364ef("prompt_lens", _1e5ae9a9efdd)
            _0fe8337539ab = _c707bea84a5d._743a579b523d(0)

            # move to device
            _c707bea84a5d = _c707bea84a5d._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)
            _ce088dfbc057 = _ce088dfbc057._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _febd664de38f, _e1a6a85c19c0, _75148e4753bb = self(_c707bea84a5d)

            # causal LM shift for next-token classification (unchanged)
            _dd25714c7a29 = _febd664de38f[:, :-1, :]._7022f8309abb()
            _926708fe0db2 = _ce088dfbc057[:, 1:]._7022f8309abb()
            _b8552523553e = _dd25714c7a29._3c1a219503fb(-1, _dd25714c7a29._743a579b523d(-1))
            _216f0f583f5d = _926708fe0db2._3c1a219503fb(-1)

            # classification/task loss
            _eb140c0af7b8 = self._e006f5dce1b9['criterion'](_b8552523553e, _216f0f583f5d)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _e1a6a85c19c0 = _ce4f1ce004ed._2d76992d0bd5(_e1a6a85c19c0, _78b8573dfd6c=0.0, _bf3ede357e41=0.0, _8d09be7d943a=0.0)
            _75148e4753bb = _ce4f1ce004ed._2d76992d0bd5(_75148e4753bb, _78b8573dfd6c=0.0, _bf3ede357e41=0.0, _8d09be7d943a=0.0)
            _eb140c0af7b8 = _ce4f1ce004ed._2d76992d0bd5(_eb140c0af7b8, _78b8573dfd6c=0.0, _bf3ede357e41=0.0, _8d09be7d943a=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _746dddcac99d = self._becea5efca23(_eb140c0af7b8, _e1a6a85c19c0, _75148e4753bb)
            _bddab6a2432a = _746dddcac99d["aux_term"]

            # final combined loss (single-equation)
            _359d83548fb3 = _eb140c0af7b8 + _bddab6a2432a

            # Optional NaN print as before (keeps your original check)
            if _ce4f1ce004ed._519f80e92bc0(_eb140c0af7b8):
                _ffc4f4a776cc(f"Step {_5ed394088021}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _0caae5abc67d = {
                "epoch": _00b0089067aa(_6a28713a7c2d(self, "current_epoch", _6a28713a7c2d(self._136b9f4582c6, "current_epoch", 0))),
                "train_kl_loss": _746dddcac99d._c1038ba364ef("kl_loss", _e1a6a85c19c0)._dc415e5e766f() if _b11ec8a2a613(_746dddcac99d._c1038ba364ef("kl_loss", _e1a6a85c19c0), _ce4f1ce004ed._9ef5ebd0563c) else _746dddcac99d._c1038ba364ef("kl_loss", _e1a6a85c19c0),
                "train_contrastive_loss": _746dddcac99d._c1038ba364ef("contrastive_loss", _75148e4753bb)._dc415e5e766f() if _b11ec8a2a613(_746dddcac99d._c1038ba364ef("contrastive_loss", _75148e4753bb), _ce4f1ce004ed._9ef5ebd0563c) else _746dddcac99d._c1038ba364ef("contrastive_loss", _75148e4753bb),
                "train_classification_loss": _eb140c0af7b8._dc415e5e766f(),
                "train_loss": _359d83548fb3._dc415e5e766f(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _00b0089067aa(_6a28713a7c2d(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _746dddcac99d._c1038ba364ef("lambda_kl_eff", _00b0089067aa(_6a28713a7c2d(self, "kl_base", 0.30))),
                "train_lambda_contrast": _746dddcac99d._c1038ba364ef("lambda_cos_eff", _00b0089067aa(_6a28713a7c2d(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _50f56c732146 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _50f56c732146 in _746dddcac99d:
                    _e759c36cfa24 = _746dddcac99d[_50f56c732146]
                    # convert single-element tensors to python floats for logging
                    if _b11ec8a2a613(_e759c36cfa24, _ce4f1ce004ed._9ef5ebd0563c) and _e759c36cfa24._b984b20bc4a7() == 1:
                        _0caae5abc67d[f"train_{_50f56c732146}"] = _00b0089067aa(_e759c36cfa24._dc415e5e766f()._31f1b2ea0a41()._c5ad376f4247())
                    else:
                        _0caae5abc67d[f"train_{_50f56c732146}"] = _e759c36cfa24

            # log exactly like you did
            self._a0746d72386f(
                _0caae5abc67d,
                _0fe8337539ab=_0fe8337539ab,
                _4adf9e2b424c=_aa1a3ac9b062,
                _9fd8b3f730f4=_5eb8602d2310,
                _483edca5e571=_aa1a3ac9b062,
                _571cac3cc0b6=_5eb8602d2310,
                _66cf074e116c=_5eb8602d2310,
            )

            # free references as you did
            del _c707bea84a5d, _ce088dfbc057, _febd664de38f, _e1a6a85c19c0, _eb140c0af7b8, _75148e4753bb, _926708fe0db2, _dd25714c7a29, _216f0f583f5d, _b8552523553e

            return _359d83548fb3

        except _27377e7cf517 as _6d3ebee63288:
            raise _9b24530d4786(f"Error in training_step: {_6d3ebee63288}") from _6d3ebee63288

    def _e6bf9aeeb616(self):
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            _ce4f1ce004ed._a96b38544560._881a64a4753a()
        _8e0b29820b37._31832b3008fd()
        return _cf5f92f82c60()._a4e9737fc017()

    def _cc2059119d1d(self, _13bba5cf4b24, _5ed394088021):
        _c707bea84a5d      = _13bba5cf4b24["input_ids"]._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)
        _ce088dfbc057         = _13bba5cf4b24["labels"]._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)
        _1cc95d04e98c     = _13bba5cf4b24._c1038ba364ef("lang_codes", _1e5ae9a9efdd)
        _234edc5edd7e     = _13bba5cf4b24._c1038ba364ef("sample_ids", _1e5ae9a9efdd)
        _c5e5dc1d9e1a      = _13bba5cf4b24._c1038ba364ef("chunk_ids", _1e5ae9a9efdd)
        _90618ad7c3a1 = _13bba5cf4b24._c1038ba364ef("word_positions", _1e5ae9a9efdd)
        _1eac215c62c7    = _13bba5cf4b24._c1038ba364ef("prompt_lens", _1e5ae9a9efdd)
        _6b640f44f0f9 = _13bba5cf4b24._c1038ba364ef("num_chunks", _1e5ae9a9efdd)

        _0fe8337539ab = _c707bea84a5d._743a579b523d(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _febd664de38f, _e1a6a85c19c0, _75148e4753bb = self(_c707bea84a5d)

        # causal LM shift for next-token classification (same as training)
        _dd25714c7a29 = _febd664de38f[:, :-1, :]._7022f8309abb()
        _926708fe0db2 = _ce088dfbc057[:, 1:]._7022f8309abb()
        _b8552523553e = _dd25714c7a29._3c1a219503fb(-1, _dd25714c7a29._743a579b523d(-1))
        _216f0f583f5d = _926708fe0db2._3c1a219503fb(-1)

        if _5ed394088021 == 0:
            try:
                _ffc4f4a776cc(
                    f"VAL TEST BATCH {_5ed394088021} Input IDs: {_c707bea84a5d._5508f9b3eb03()[0]}, "
                    f"Predictions: {_ce4f1ce004ed._d3a2ac7c87d4(_dd25714c7a29, _424ae9a17d31=-1)._5508f9b3eb03()[0]}, "
                    f"Labels: {_926708fe0db2._5508f9b3eb03()[0]}"
                )
            except _27377e7cf517:
                # printing should never crash validation
                pass

        # classification loss
        _eb140c0af7b8 = self._e006f5dce1b9['criterion'](_b8552523553e, _216f0f583f5d)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _e1a6a85c19c0 = _ce4f1ce004ed._2d76992d0bd5(_e1a6a85c19c0, _78b8573dfd6c=0.0, _bf3ede357e41=0.0, _8d09be7d943a=0.0)
        _75148e4753bb = _ce4f1ce004ed._2d76992d0bd5(_75148e4753bb, _78b8573dfd6c=0.0, _bf3ede357e41=0.0, _8d09be7d943a=0.0)
        _eb140c0af7b8 = _ce4f1ce004ed._2d76992d0bd5(_eb140c0af7b8, _78b8573dfd6c=0.0, _bf3ede357e41=0.0, _8d09be7d943a=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _746dddcac99d = self._becea5efca23(_eb140c0af7b8, _e1a6a85c19c0, _75148e4753bb)
        _bddab6a2432a = _746dddcac99d["aux_term"]
        _359d83548fb3 = _eb140c0af7b8 + _bddab6a2432a

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _a0746d72386f = {
            "val_kl_loss": _00b0089067aa(_746dddcac99d._c1038ba364ef("kl_loss", _e1a6a85c19c0)._dc415e5e766f()._31f1b2ea0a41()._c5ad376f4247()) if _b11ec8a2a613(_746dddcac99d._c1038ba364ef("kl_loss", _e1a6a85c19c0), _ce4f1ce004ed._9ef5ebd0563c) else _00b0089067aa(_746dddcac99d._c1038ba364ef("kl_loss", _e1a6a85c19c0)),
            "val_contrastive_loss": _00b0089067aa(_746dddcac99d._c1038ba364ef("contrastive_loss", _75148e4753bb)._dc415e5e766f()._31f1b2ea0a41()._c5ad376f4247()) if _b11ec8a2a613(_746dddcac99d._c1038ba364ef("contrastive_loss", _75148e4753bb), _ce4f1ce004ed._9ef5ebd0563c) else _00b0089067aa(_746dddcac99d._c1038ba364ef("contrastive_loss", _75148e4753bb)),
            "val_classification_loss": _00b0089067aa(_eb140c0af7b8._dc415e5e766f()._31f1b2ea0a41()._c5ad376f4247()),
            "val_loss": _00b0089067aa(_359d83548fb3._dc415e5e766f()._31f1b2ea0a41()._c5ad376f4247()),
        }

        # include effective lambdas and others if provided by aux
        _a0746d72386f["val_lambda_kl"] = _00b0089067aa(_746dddcac99d._c1038ba364ef("lambda_kl", _746dddcac99d._c1038ba364ef("lambda_kl_eff", _00b0089067aa(_6a28713a7c2d(self, "kl_base", 0.30)))))
        _a0746d72386f["val_lambda_contrast"] = _00b0089067aa(_746dddcac99d._c1038ba364ef("lambda_cos", _746dddcac99d._c1038ba364ef("lambda_cos_eff", _00b0089067aa(_6a28713a7c2d(self, "cos_base", 0.25)))))
        _a0746d72386f["val_w_mean"] = _00b0089067aa(_746dddcac99d._c1038ba364ef("w_mean", 0.0))
        _a0746d72386f["val_aux_scale"] = _00b0089067aa(_746dddcac99d._c1038ba364ef("aux_scale", 0.0))
        _a0746d72386f["val_shift_r"] = _00b0089067aa(_746dddcac99d._c1038ba364ef("shift_r", 0.0))
        _a0746d72386f["val_teacher_conf_mean"] = _00b0089067aa(_746dddcac99d._c1038ba364ef("teacher_conf_mean", 0.0))

        self._a0746d72386f(
            _a0746d72386f,
            _0fe8337539ab=_0fe8337539ab,
            _4adf9e2b424c=_aa1a3ac9b062,
            _9fd8b3f730f4=_5eb8602d2310,
            _483edca5e571=_aa1a3ac9b062,
            _571cac3cc0b6=_5eb8602d2310,
            _66cf074e116c=_5eb8602d2310,
        )

        # build preds and labels per example (preserve your previous behavior)
        _f7cee8969066 = []
        _79aaa970ddb6 = []
        for _516e63e03e48 in _19ac5d4ef0b7(_0fe8337539ab):
            _2623072ead25 = _febd664de38f[_516e63e03e48]
            _8c03d383d362 = _ce088dfbc057[_516e63e03e48]
            _cb4a00844e43 = _ce4f1ce004ed._d3a2ac7c87d4(_2623072ead25, _424ae9a17d31=-1)
            _aee6e4e65ebf = _8c03d383d362
            _f7cee8969066._ab923f31365d(_cb4a00844e43)
            _79aaa970ddb6._ab923f31365d(_aee6e4e65ebf)

        _1704016d0e51 = {
            "lang_codes": _1cc95d04e98c,
            "preds": _f7cee8969066,
            "labels": _79aaa970ddb6,
            "sample_ids": _234edc5edd7e,
            "chunk_ids": _c5e5dc1d9e1a,
            "word_positions": _90618ad7c3a1,
            "val_loss": _359d83548fb3,
            "prompt_lens": _1eac215c62c7,
            "num_chunks": _6b640f44f0f9,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._10002ca5c877._ab923f31365d(_1704016d0e51)

        # explicit frees (same as you had)
        del _c707bea84a5d, _ce088dfbc057, _febd664de38f, _b8552523553e, _216f0f583f5d, _dd25714c7a29, _926708fe0db2
        del _e1a6a85c19c0, _75148e4753bb, _eb140c0af7b8, _f7cee8969066, _79aaa970ddb6

        return _1704016d0e51


    def _becd721a3ac3(self, _56dc8ef34571, _7c728e9d0e42, _11522512a655=_1e5ae9a9efdd):
        _28b9c3a1e4b1 = os._ea25040034cd()
        _997d8a176c51 = f"trial_{_11522512a655}" if _11522512a655 is not _1e5ae9a9efdd else "default"
        _ffc4f4a776cc(f"[DEBUG rank={_ce4f1ce004ed._7030509b4428._13b0798d60af() if _ce4f1ce004ed._7030509b4428._c716cf4f0b3c() else 0}] metrics_dict confusion_matrix sum={_0e0d0e8e174a(_0e0d0e8e174a(_f6fe3a8520ae) for _f6fe3a8520ae in _56dc8ef34571['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _f3ac0df5c9de = os._74df2cf25778._370e1ee5c862(_28b9c3a1e4b1, "metrics", self._4e804c3780d3,  _997d8a176c51)
        os._4a7b48aa088a(_f3ac0df5c9de, _f76a277b038d=_5eb8602d2310)
        _40317695e314 = os._74df2cf25778._370e1ee5c862(_f3ac0df5c9de, _7c728e9d0e42)
        _7e8a4462fc3c = _f0440a081492._36bea645d758(_56dc8ef34571)
        _7e8a4462fc3c._00ae2c7fccab(_40317695e314, _228025b3b10b=_aa1a3ac9b062)
        _ffc4f4a776cc(f"[metrics] Saved {_40317695e314}")

    def _0f0707b5c638(self):
        # pick correct device for this rank
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            if _ce4f1ce004ed._7030509b4428._c716cf4f0b3c():
                _a820e26071c6 = _ce4f1ce004ed._7030509b4428._13b0798d60af()
            else:
                _a820e26071c6 = 0
            _ce4f1ce004ed._a96b38544560._8fef5ee64e7d(_a820e26071c6)
            self._3680894c959b = _ce4f1ce004ed._2f948f47b688(f"cuda:{_a820e26071c6}")
        else:
            self._3680894c959b = _ce4f1ce004ed._2f948f47b688("cpu")

        self._ef6b6e3eb36b()

    def _6ee8e23cfd86(self):
        _febd664de38f = _6a28713a7c2d(self, "_validation_outputs", _1e5ae9a9efdd)
        if not _febd664de38f:
            return

        _5680583ee890, _b69be28eaaba, _a2606f2bce26, _f6448ac29eb5 = \
            self._33b138c1e9b4(_febd664de38f)

        _3412172d39f4, _e9c797abecef = [], []
        for _31d6ac577266 in _5194ccd20a8a(_a2606f2bce26._168bd6d79108()):
            _73f3b7a88ba8 = _5680583ee890[_31d6ac577266]._5508f9b3eb03()
            _8534c904e7e2 = _b69be28eaaba[_31d6ac577266]._5508f9b3eb03()
            _f4e934d96684 = _a2606f2bce26[_31d6ac577266]
            _fae437f8cdd7 = _f6448ac29eb5[_31d6ac577266]
            if _f4e934d96684._b984b20bc4a7() > 0 and _fae437f8cdd7._b984b20bc4a7() > 0:
                _3412172d39f4._ab923f31365d(_f4e934d96684)
                _e9c797abecef._ab923f31365d(_fae437f8cdd7)

        if not _3412172d39f4:
            _ffc4f4a776cc("[VAL END] Nothing to score.")
            self._10002ca5c877._4c22c096ffea()
            return

        _afc724ac3e41 = _ce4f1ce004ed._01bef4989b13(_3412172d39f4)._75312abd023b(_2f948f47b688=self._46707e1142b0['micro_accuracy']._2f948f47b688, _758992430a0b=_5eb8602d2310)
        _ce088dfbc057 = _ce4f1ce004ed._01bef4989b13(_e9c797abecef)._75312abd023b(_2f948f47b688=self._46707e1142b0['micro_accuracy']._2f948f47b688, _758992430a0b=_5eb8602d2310)

        self._46707e1142b0['micro_accuracy']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_accuracy']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_precision']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_recall']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_f1']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_accuracy']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_precision']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_recall']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_f1']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['confmat']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)

        _bb9efcd53912  = self._46707e1142b0['micro_accuracy']._2e06cfcd3314()._c5ad376f4247()
        _802dc907e12f  = self._46707e1142b0['macro_accuracy']._2e06cfcd3314()._c5ad376f4247()
        _8aedfafdf337 = self._46707e1142b0['macro_precision']._2e06cfcd3314()._c5ad376f4247()
        _2d2714ab1c3b    = self._46707e1142b0['macro_recall']._2e06cfcd3314()._c5ad376f4247()
        _2a347156d0ce        = self._46707e1142b0['macro_f1']._2e06cfcd3314()._c5ad376f4247()

        self._cc19ebd6b1d6("val_accuracy", _802dc907e12f, _66cf074e116c=_5eb8602d2310)

        try:
            _b4b8174a34a0 = self._9a79f7e15152
            _56dc8ef34571 = {
                "epoch": [_b4b8174a34a0],
                "class_names": [self._f8e959efa328],
                "micro_accuracy": [_bb9efcd53912],
                "macro_accuracy": [_802dc907e12f],
                "macro_precision": [_8aedfafdf337],
                "macro_recall": [_2d2714ab1c3b],
                "macro_f1": [_2a347156d0ce],
                "classwise_accuracy": [self._46707e1142b0['classwise_accuracy']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "classwise_precision": [self._46707e1142b0['classwise_precision']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "classwise_recall": [self._46707e1142b0['classwise_recall']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "classwise_f1": [self._46707e1142b0['classwise_f1']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "confusion_matrix": [self._46707e1142b0['confmat']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
            }
            self._0231d1a13569(_56dc8ef34571, f"val_epoch_{_b4b8174a34a0}.csv", _11522512a655=self._11522512a655)
        except _27377e7cf517 as _6d3ebee63288:
            _ffc4f4a776cc(f"[VAL END] save metrics FAILED: {_6d3ebee63288}")

        # cleanup
        self._46707e1142b0['micro_accuracy']._4387caa84ae4(); self._46707e1142b0['macro_accuracy']._4387caa84ae4()
        self._46707e1142b0['macro_precision']._4387caa84ae4(); self._46707e1142b0['macro_recall']._4387caa84ae4(); self._46707e1142b0['macro_f1']._4387caa84ae4()
        self._46707e1142b0['classwise_accuracy']._4387caa84ae4(); self._46707e1142b0['classwise_precision']._4387caa84ae4()
        self._46707e1142b0['classwise_recall']._4387caa84ae4(); self._46707e1142b0['classwise_f1']._4387caa84ae4()
        self._46707e1142b0['confmat']._4387caa84ae4(); self._10002ca5c877._4c22c096ffea()
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            _ce4f1ce004ed._a96b38544560._881a64a4753a()
        _ffc4f4a776cc("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_ce4f1ce004ed._f6384fd6ec88()
    def _726ae5cecf87(self, _c707bea84a5d: _ce4f1ce004ed._9ef5ebd0563c, **_93e80b6e30e1):
        _93e80b6e30e1._a7e2217cee07("pad_token_id", _1e5ae9a9efdd)
        _93e80b6e30e1._a7e2217cee07("attention_mask", _1e5ae9a9efdd)
        return self._675894eb6a50._64964671f6cf(
            _c707bea84a5d=_c707bea84a5d,
            _cd59944b7152=(_c707bea84a5d != self._bb7328b9f0b5._59fe6141df74),
            _59fe6141df74=self._bb7328b9f0b5._59fe6141df74,
            _b4e9ae975b08=self._bb7328b9f0b5._b4e9ae975b08,
            **_93e80b6e30e1
        )

    def _347682a2a566(self, _13bba5cf4b24, _5ed394088021):
        _c707bea84a5d = _13bba5cf4b24["input_ids"]._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)
        _ce088dfbc057    = _13bba5cf4b24["labels"]._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)
        _1cc95d04e98c     = _13bba5cf4b24._c1038ba364ef("lang_codes", _1e5ae9a9efdd)
        _234edc5edd7e     = _13bba5cf4b24._c1038ba364ef("sample_ids", _1e5ae9a9efdd)
        _c5e5dc1d9e1a      = _13bba5cf4b24._c1038ba364ef("chunk_ids", _1e5ae9a9efdd)
        _90618ad7c3a1 = _13bba5cf4b24._c1038ba364ef("word_positions", _1e5ae9a9efdd)
        _1eac215c62c7    = _13bba5cf4b24._c1038ba364ef("prompt_lens", _1e5ae9a9efdd)
        _6b640f44f0f9 = _13bba5cf4b24._c1038ba364ef("num_chunks", _1e5ae9a9efdd)

        _0fe8337539ab = _c707bea84a5d._743a579b523d(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _dfcf6a20fdb3 = self._64964671f6cf(
            _c707bea84a5d,
            _a61cbd52bc2f=32,
            _890bb31a52c5=_aa1a3ac9b062,
            _f48a8e4f017e=_1e5ae9a9efdd,     # for deterministic answers
            _1b8aa6a4f8eb=_1e5ae9a9efdd,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _f7cee8969066 = []
        _79aaa970ddb6 = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _516e63e03e48 in _19ac5d4ef0b7(_0fe8337539ab):
            _f7cee8969066._ab923f31365d(_dfcf6a20fdb3[_516e63e03e48])   # FULL sequence
            _79aaa970ddb6._ab923f31365d(_ce088dfbc057[_516e63e03e48])          # FULL labels


        _1704016d0e51 = {
            "lang_codes": _1cc95d04e98c,
            "preds": _f7cee8969066,
            "labels": _79aaa970ddb6,
            "sample_ids": _234edc5edd7e,
            "chunk_ids": _c5e5dc1d9e1a,
            "word_positions": _90618ad7c3a1,
            "prompt_lens": _1eac215c62c7,
            "num_chunks": _6b640f44f0f9,
        }

        self._1009735c9c88._ab923f31365d(_1704016d0e51)

        # Exact same cleanup as before
        del _c707bea84a5d, _ce088dfbc057, _dfcf6a20fdb3, _f7cee8969066, _79aaa970ddb6

        return _1704016d0e51

    def _c4a8f1a3baf2(self):
        # pick correct device for this rank
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            if _ce4f1ce004ed._7030509b4428._c716cf4f0b3c():
                _a820e26071c6 = _ce4f1ce004ed._7030509b4428._13b0798d60af()
            else:
                _a820e26071c6 = 0
            _ce4f1ce004ed._a96b38544560._8fef5ee64e7d(_a820e26071c6)
            self._3680894c959b = _ce4f1ce004ed._2f948f47b688(f"cuda:{_a820e26071c6}")
        else:
            self._3680894c959b = _ce4f1ce004ed._2f948f47b688("cpu")

        self._ef6b6e3eb36b()
        
    def _8991876451e4(self):
        _febd664de38f = _6a28713a7c2d(self, "_test_outputs", _1e5ae9a9efdd)
        _ffc4f4a776cc(f"[DEBUG rank={_ce4f1ce004ed._7030509b4428._13b0798d60af()}] outputs_len={_f41720717511(_febd664de38f)}")
        if not _febd664de38f:
            return

        _5680583ee890, _b69be28eaaba, _a2606f2bce26, _f6448ac29eb5 = \
            self._33b138c1e9b4(_febd664de38f)

        _3412172d39f4, _e9c797abecef = [], []
        for _31d6ac577266 in _5194ccd20a8a(_a2606f2bce26._168bd6d79108()):
            _73f3b7a88ba8 = _5680583ee890[_31d6ac577266]._5508f9b3eb03()
            _8534c904e7e2 = _b69be28eaaba[_31d6ac577266]._5508f9b3eb03()
            _f4e934d96684 = _a2606f2bce26[_31d6ac577266]
            _fae437f8cdd7 = _f6448ac29eb5[_31d6ac577266]

            if _f4e934d96684._b984b20bc4a7() > 0 and _fae437f8cdd7._b984b20bc4a7() > 0:
                _3412172d39f4._ab923f31365d(_f4e934d96684)
                _e9c797abecef._ab923f31365d(_fae437f8cdd7)

        if not _3412172d39f4:
            _ffc4f4a776cc("[TEST END] Nothing to score.")
            self._10002ca5c877._4c22c096ffea()
            return

        _afc724ac3e41 = _ce4f1ce004ed._01bef4989b13(_3412172d39f4)._75312abd023b(_2f948f47b688=self._46707e1142b0['micro_accuracy']._2f948f47b688, _758992430a0b=_5eb8602d2310)
        _ce088dfbc057 = _ce4f1ce004ed._01bef4989b13(_e9c797abecef)._75312abd023b(_2f948f47b688=self._46707e1142b0['micro_accuracy']._2f948f47b688, _758992430a0b=_5eb8602d2310)

        self._46707e1142b0['micro_accuracy']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_accuracy']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_precision']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_recall']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['macro_f1']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_accuracy']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_precision']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_recall']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['classwise_f1']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)
        self._46707e1142b0['confmat']._1ea42fea63dd(_afc724ac3e41, _ce088dfbc057)

        _bb9efcd53912  = self._46707e1142b0['micro_accuracy']._2e06cfcd3314()._c5ad376f4247()
        _802dc907e12f  = self._46707e1142b0['macro_accuracy']._2e06cfcd3314()._c5ad376f4247()
        _8aedfafdf337 = self._46707e1142b0['macro_precision']._2e06cfcd3314()._c5ad376f4247()
        _2d2714ab1c3b    = self._46707e1142b0['macro_recall']._2e06cfcd3314()._c5ad376f4247()
        _2a347156d0ce        = self._46707e1142b0['macro_f1']._2e06cfcd3314()._c5ad376f4247()

        self._cc19ebd6b1d6("test_accuracy", _802dc907e12f, _66cf074e116c=_5eb8602d2310)

        try:
            _b4b8174a34a0 = self._9a79f7e15152
            _56dc8ef34571 = {
                "epoch": [_b4b8174a34a0],
                "class_names": [self._f8e959efa328],
                "micro_accuracy": [_bb9efcd53912],
                "macro_accuracy": [_802dc907e12f],
                "macro_precision": [_8aedfafdf337],
                "macro_recall": [_2d2714ab1c3b],
                "macro_f1": [_2a347156d0ce],
                "classwise_accuracy": [self._46707e1142b0['classwise_accuracy']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "classwise_precision": [self._46707e1142b0['classwise_precision']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "classwise_recall": [self._46707e1142b0['classwise_recall']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "classwise_f1": [self._46707e1142b0['classwise_f1']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
                "confusion_matrix": [self._46707e1142b0['confmat']._2e06cfcd3314()._75312abd023b(_2f948f47b688="cpu")._98a63548b8d5()._5508f9b3eb03()],
            }
            self._0231d1a13569(_56dc8ef34571, f"test_final.csv", _11522512a655=self._11522512a655)
        except _27377e7cf517 as _6d3ebee63288:
            _ffc4f4a776cc(f"[TEST END] save metrics FAILED: {_6d3ebee63288}")

        # cleanup
        self._46707e1142b0['micro_accuracy']._4387caa84ae4(); self._46707e1142b0['macro_accuracy']._4387caa84ae4()
        self._46707e1142b0['macro_precision']._4387caa84ae4(); self._46707e1142b0['macro_recall']._4387caa84ae4(); self._46707e1142b0['macro_f1']._4387caa84ae4()
        self._46707e1142b0['classwise_accuracy']._4387caa84ae4(); self._46707e1142b0['classwise_precision']._4387caa84ae4()
        self._46707e1142b0['classwise_recall']._4387caa84ae4(); self._46707e1142b0['classwise_f1']._4387caa84ae4()
        self._46707e1142b0['confmat']._4387caa84ae4(); self._10002ca5c877._4c22c096ffea()
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            _ce4f1ce004ed._a96b38544560._881a64a4753a()
        _ffc4f4a776cc("[TEST END] Finished and cleaned up.")

    def _4488925b7449(self, _13bba5cf4b24, _5ed394088021, _c74497099ab2=0):
        """Optimized prediction step with efficient memory handling."""
        _c707bea84a5d, _ = _13bba5cf4b24
        _c707bea84a5d = _c707bea84a5d._75312abd023b(self._3680894c959b, _758992430a0b=_5eb8602d2310)
        _febd664de38f, _, _ = self(_c707bea84a5d)
        _b3fee0db4a5b = _ce4f1ce004ed._d3a2ac7c87d4(_febd664de38f, _424ae9a17d31=-1)
        del _c707bea84a5d, _febd664de38f
        if _ce4f1ce004ed._a96b38544560._883ec1f2ef5b():
            _ce4f1ce004ed._a96b38544560._881a64a4753a()
        return {"predictions": _b3fee0db4a5b._31f1b2ea0a41()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _247fbf22af6f(self, _f367c1ad3855, _28e10e0d9b9c):
        # if sep token not present then just tuple the tokens and return
        if _28e10e0d9b9c is _1e5ae9a9efdd:
            return [(_a90c9df9c012,) for _a90c9df9c012 in _f367c1ad3855]

        _c932a29f8881 = []
        _b0c15c6a638a = []

        for _a90c9df9c012 in _f367c1ad3855:
            if _a90c9df9c012 == _28e10e0d9b9c:
                if _b0c15c6a638a:
                    _c932a29f8881._ab923f31365d(_255b729b7126(_b0c15c6a638a))
                    _b0c15c6a638a = []
            else:
                if _28e10e0d9b9c == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _a90c9df9c012 in _b0c15c6a638a:
                        continue
                    else:
                        _b0c15c6a638a._ab923f31365d(_a90c9df9c012)
                    
                else:
                    _b0c15c6a638a._ab923f31365d(_a90c9df9c012)

        if _b0c15c6a638a:
            _c932a29f8881._ab923f31365d(_255b729b7126(_b0c15c6a638a))

        return _c932a29f8881

    def _66e2da43d3d7(self, _7c11e846bcd3, _e7cce769361e="exact_match", _e939fd67b406=_1e5ae9a9efdd):
        if not _7c11e846bcd3:
            return _e939fd67b406

        if _e7cce769361e == "exact_match":
            return _7c11e846bcd3[0] if _05f82477c92f(_a9a81b3897cb == _7c11e846bcd3[0] for _a9a81b3897cb in _7c11e846bcd3) else _e939fd67b406

        if _e7cce769361e == "most_common":
            return _1c3867de70ad(_7c11e846bcd3)._f6fe3d8365cb(1)[0][0]

        if _e7cce769361e == "first":
            return _7c11e846bcd3[0]

        raise _1c9527cc8339(f"Unknown vote mode: {_e7cce769361e}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _485cbb1c46a6(self, _febd664de38f, _d60d6abe4d87=_5eb8602d2310, _2b1f38f404d0="cpu"):
        from collections import _7e1cca09b9ec
        import _ce4f1ce004ed

        _09ed6bbaf7ff = self._f0f5d6024680
        _28e10e0d9b9c = self._02b85a278855
        _254b7fd3393f = self._caf61f9c620f

        def _84197025b27b(_17dd1a5c197b):
            if _b11ec8a2a613(_17dd1a5c197b, _ce4f1ce004ed._9ef5ebd0563c):
                return _17dd1a5c197b._dc415e5e766f()._75312abd023b(_2f948f47b688=_2b1f38f404d0)._c0b6f1485fe6(-1)._5508f9b3eb03()
            return _15cc7dfaec56(_17dd1a5c197b) if _b11ec8a2a613(_17dd1a5c197b, (_15cc7dfaec56, _255b729b7126)) else [_17dd1a5c197b]

        _c414c67e50c1 = _b68998af30fa()
        _78ad5d3fb0ab = _7e1cca09b9ec(_15cc7dfaec56)
        _955c726661a1 = _7e1cca09b9ec(_90d5f478a3a0)
        _17617f4e9866 = []

        if _d60d6abe4d87:
            _ffc4f4a776cc(f"[reconcile] start: num_outputs={_f41720717511(_febd664de38f)}")

        for _ae753ab839dc in _febd664de38f:
            _234edc5edd7e = _ae753ab839dc["sample_ids"]
            _c5e5dc1d9e1a = _ae753ab839dc["chunk_ids"]
            _7c1aa7e858e3 = _ae753ab839dc["preds"]
            _739ffbbdc119 = _ae753ab839dc["labels"]
            _90618ad7c3a1 = _ae753ab839dc["word_positions"]
            _1eac215c62c7 = _ae753ab839dc["prompt_lens"]
            _d0fe202f3a59 = _ae753ab839dc["num_chunks"]

            for _516e63e03e48, _31d6ac577266 in _188f3e52ae6a(_234edc5edd7e):
                _5c230fd5d9ee = _90d5f478a3a0(_c5e5dc1d9e1a[_516e63e03e48])
                if (_31d6ac577266, _5c230fd5d9ee) in _c414c67e50c1:
                    continue
                _c414c67e50c1._43cb49457888((_31d6ac577266, _5c230fd5d9ee))

                _955c726661a1[_31d6ac577266] = _90d5f478a3a0(_d0fe202f3a59[_516e63e03e48])
                _fb123de8a478 = _90d5f478a3a0(_1eac215c62c7[_516e63e03e48])
                _df1f2c635bf9 = _7d6eb304edec(_90618ad7c3a1[_516e63e03e48])
                _0d59b786bde9 = _7d6eb304edec(_7c1aa7e858e3[_516e63e03e48])[_fb123de8a478:]
                _e518165bf30c = _7d6eb304edec(_739ffbbdc119[_516e63e03e48])[_fb123de8a478:]

                _2b00f61c2098 = [_874118ee4b17 for _874118ee4b17 in _0d59b786bde9 if _874118ee4b17 != _09ed6bbaf7ff]
                _a5a7454e538a = [_d94f8e485fc5 for _d94f8e485fc5 in _e518165bf30c if _d94f8e485fc5 != _09ed6bbaf7ff]

                if _31d6ac577266 not in _17617f4e9866:
                    _17617f4e9866._ab923f31365d(_31d6ac577266)

                _78ad5d3fb0ab[_31d6ac577266]._ab923f31365d((_5c230fd5d9ee, _df1f2c635bf9, _2b00f61c2098, _a5a7454e538a))

        _a7200b11592f = _1e5ae9a9efdd
        _5680583ee890 = {}
        _b69be28eaaba = {}

        for _31d6ac577266 in _17617f4e9866:
            _2bf4b2edd337 = _78ad5d3fb0ab[_31d6ac577266]
            if _f41720717511(_2bf4b2edd337) != _955c726661a1[_31d6ac577266]:
                if _d60d6abe4d87:
                    _ffc4f4a776cc(f"Skipping sample {_31d6ac577266}: expected {_955c726661a1[_31d6ac577266]} chunks, got {_f41720717511(_2bf4b2edd337)}")
                continue

            _2bf4b2edd337._0ea75da9c175(_43a7c8b1029c=lambda _17dd1a5c197b: _17dd1a5c197b[0])

            if _a7200b11592f is _1e5ae9a9efdd and _f41720717511(_2bf4b2edd337) > 1:
                _a7200b11592f = _31d6ac577266

            # Split into words
            _1a23ee021613 = []
            for _5c230fd5d9ee, _e63011b4c208, _cd903099ca15, _e0b4f7f4f1ba in _2bf4b2edd337:
                _2cbeb4863072 = self._954788567ca2(_e63011b4c208, -1)
                _47e4f3f19710 = self._954788567ca2(_cd903099ca15, _28e10e0d9b9c)
                _3b023a717ee2 = self._954788567ca2(_e0b4f7f4f1ba, _28e10e0d9b9c)
                _cc6bb39181c7 = _f41720717511(_2cbeb4863072)
                if _f41720717511(_47e4f3f19710) < _cc6bb39181c7:
                    _47e4f3f19710 += [(_254b7fd3393f,)] * (_cc6bb39181c7 - _f41720717511(_47e4f3f19710))
                if _f41720717511(_3b023a717ee2) < _cc6bb39181c7:
                    _3b023a717ee2 += [(_09ed6bbaf7ff,)] * (_cc6bb39181c7 - _f41720717511(_3b023a717ee2))
                _1a23ee021613._ab923f31365d((_2cbeb4863072, _47e4f3f19710, _3b023a717ee2))

            # Vote per word position
            _1cf567db9ddb = _7e1cca09b9ec(_15cc7dfaec56)
            _fbfaac298af6 = _7e1cca09b9ec(_15cc7dfaec56)
            for _2cbeb4863072, _47e4f3f19710, _3b023a717ee2 in _1a23ee021613:
                for _57617f559859, _74189a22a890, _7dd8319785c1 in _f2bd1ff41614(_2cbeb4863072, _47e4f3f19710, _3b023a717ee2):
                    _e63011b4c208 = _57617f559859[0]
                    _1cf567db9ddb[_e63011b4c208]._ab923f31365d(_74189a22a890)
                    _fbfaac298af6[_e63011b4c208]._ab923f31365d(_7dd8319785c1)

            _086cfed3ac27 = _5194ccd20a8a(_1cf567db9ddb._168bd6d79108())

            _2743c7f44aac = [self._28b7c1091d50(_1cf567db9ddb[_874118ee4b17], _e7cce769361e="exact_match", _e939fd67b406=(_254b7fd3393f,)) for _874118ee4b17 in _086cfed3ac27]
            _1a52884f487d = []
            for _874118ee4b17 in _086cfed3ac27:
                _15e0f181aba6 = _fbfaac298af6[_874118ee4b17]
                _0d662612efb0 = self._28b7c1091d50(_15e0f181aba6, _e7cce769361e="exact_match", _e939fd67b406=_1e5ae9a9efdd)
                if _0d662612efb0 is _1e5ae9a9efdd:
                    for _9e724ba92ea2 in _15e0f181aba6:
                        if _09ed6bbaf7ff not in _9e724ba92ea2:
                            _0d662612efb0 = _9e724ba92ea2
                            break
                    if _0d662612efb0 is _1e5ae9a9efdd:
                        _0d662612efb0 = _15e0f181aba6[0]
                _1a52884f487d._ab923f31365d(_0d662612efb0)

            # Reconstruct
            _a4552a2dcc59 = []
            _660fa854fa56 = []
            for _516e63e03e48 in _19ac5d4ef0b7(_f41720717511(_086cfed3ac27)):
                _a4552a2dcc59._1f063bdcff41(_2743c7f44aac[_516e63e03e48])
                _660fa854fa56._1f063bdcff41(_1a52884f487d[_516e63e03e48])
                if _516e63e03e48 < _f41720717511(_086cfed3ac27) - 1:
                    _a4552a2dcc59._ab923f31365d(_28e10e0d9b9c)
                    _660fa854fa56._ab923f31365d(_28e10e0d9b9c)

            _ffc4f4a776cc(f"check labels final {(_0e0d0e8e174a(1 for _17dd1a5c197b in _660fa854fa56 if _17dd1a5c197b == _28e10e0d9b9c))}")

            _5680583ee890[_31d6ac577266] = _ce4f1ce004ed._4adcbff5be65(_a4552a2dcc59, _2f948f47b688=_2b1f38f404d0)
            _b69be28eaaba[_31d6ac577266] = _ce4f1ce004ed._4adcbff5be65(_660fa854fa56, _2f948f47b688=_2b1f38f404d0)

        if _d60d6abe4d87 and _a7200b11592f is not _1e5ae9a9efdd:
            _ffc4f4a776cc(f"[SUMMARY] reconciled samples in batch = {_f41720717511(_17617f4e9866)} "
                f"sid={_a7200b11592f} total_preds={_f41720717511(_5680583ee890[_a7200b11592f])} "
                f"total_labels={_f41720717511(_b69be28eaaba[_a7200b11592f])} "
                f"raw_preds {_5680583ee890[_a7200b11592f]} and raw_labels {_b69be28eaaba[_a7200b11592f]} "
                f"chunks {_78ad5d3fb0ab[_a7200b11592f]}")

        _c4622398d6e1 = _0e0d0e8e174a(_f41720717511(_d94f8e485fc5) for _d94f8e485fc5 in _b69be28eaaba._7c11e846bcd3())
        _ffc4f4a776cc(f"Total reconciled labels: {_c4622398d6e1}")

        _27bc2b8a27c3, _c5d86114f965 = self._cd3140c04db5(
            _5680583ee890, _b69be28eaaba, _d60d6abe4d87=_d60d6abe4d87, _2b1f38f404d0=_2b1f38f404d0
        )
        _3f3feeab78f1 = _0e0d0e8e174a(_f41720717511(_d94f8e485fc5) for _d94f8e485fc5 in _c5d86114f965._7c11e846bcd3())
        _ffc4f4a776cc(f"Total reconciled labels classes: {_3f3feeab78f1}")

        _07a78c86f40b = _ce4f1ce004ed._7030509b4428._13b0798d60af() if _ce4f1ce004ed._7030509b4428._c716cf4f0b3c() else -1
        _ffc4f4a776cc(f"Rank {_07a78c86f40b} samples are {_17617f4e9866}")

        return _5680583ee890, _b69be28eaaba, _27bc2b8a27c3, _c5d86114f965

    def _c7322e664953(self, _5680583ee890, _b69be28eaaba, _d60d6abe4d87=_5eb8602d2310, _2b1f38f404d0="cpu"):
        _cbe73041bf8b = _6a28713a7c2d(self, "seq2class", {})
        _28e10e0d9b9c = _6a28713a7c2d(self, "tokenizer_separator_token", _1e5ae9a9efdd)
        _09ed6bbaf7ff = _6a28713a7c2d(self, "ignore_idx", -100)
        
        def _7c48d03784c8(_f367c1ad3855, _94874483aa69):
            _c932a29f8881 = []
            _84618156464e = []
            for _516e63e03e48, token in _188f3e52ae6a(_f367c1ad3855):
                if token == _94874483aa69 and _84618156464e:
                    _c932a29f8881._ab923f31365d(_84618156464e)
                    _84618156464e = []
                elif token != _94874483aa69:
                    _84618156464e._ab923f31365d(token)
            if _84618156464e:
                _c932a29f8881._ab923f31365d(_84618156464e)
            return _c932a29f8881
        
        def _f07a3e133716(_1b04aa69ae90, _cbe73041bf8b, _d60d6abe4d87, _31d6ac577266):
            _ae753ab839dc = []
            _d68f21e4f376 = _5194ccd20a8a(_cbe73041bf8b._168bd6d79108(), _43a7c8b1029c=_f41720717511, _c90e896e0e89=_5eb8602d2310)
            for _516e63e03e48, _1806525e4f4a in _188f3e52ae6a(_1b04aa69ae90, 1):
                _624f4f51f0ca = _255b729b7126(_1806525e4f4a)
                _badc5495980d = self._caf61f9c620f
                for _43a7c8b1029c in _d68f21e4f376:
                    if _f41720717511(_624f4f51f0ca) >= _f41720717511(_43a7c8b1029c) and _624f4f51f0ca[:_f41720717511(_43a7c8b1029c)] == _43a7c8b1029c:
                        _badc5495980d = _cbe73041bf8b[_43a7c8b1029c]
                        break
                _ae753ab839dc._ab923f31365d(_badc5495980d)

            return _ae753ab839dc
        
        _a2606f2bce26, _f6448ac29eb5 = {}, {}
        for _31d6ac577266 in _5680583ee890:
            _874118ee4b17 = _5680583ee890[_31d6ac577266]
            _d94f8e485fc5 = _b69be28eaaba._c1038ba364ef(_31d6ac577266, _1e5ae9a9efdd)
            _afc724ac3e41 = _874118ee4b17._5508f9b3eb03() if _b11ec8a2a613(_874118ee4b17, _ce4f1ce004ed._9ef5ebd0563c) else _15cc7dfaec56(_874118ee4b17)
            _ce088dfbc057 = _d94f8e485fc5._5508f9b3eb03() if _b11ec8a2a613(_d94f8e485fc5, _ce4f1ce004ed._9ef5ebd0563c) else _15cc7dfaec56(_d94f8e485fc5) if _d94f8e485fc5 else _1e5ae9a9efdd
            if _ce088dfbc057 is not _1e5ae9a9efdd:
                _c5289da8305e = _57c87a83896a(_ce088dfbc057, _28e10e0d9b9c)
                _314b0bc4c258 = _cbe126802873(_c5289da8305e, _cbe73041bf8b, _31d6ac577266 == 1 or _d60d6abe4d87, _31d6ac577266)
                _2222322b7d6a = _57c87a83896a(_afc724ac3e41, _28e10e0d9b9c)
                _b87c0336fb3b = _cbe126802873(_2222322b7d6a, _cbe73041bf8b, _31d6ac577266 == 1 or _d60d6abe4d87, _31d6ac577266)
                if _f41720717511(_b87c0336fb3b) < _f41720717511(_314b0bc4c258):
                    _b87c0336fb3b += [0] * (_f41720717511(_314b0bc4c258) - _f41720717511(_b87c0336fb3b))
                elif _f41720717511(_b87c0336fb3b) > _f41720717511(_314b0bc4c258):
                    _b87c0336fb3b = _b87c0336fb3b[:_f41720717511(_314b0bc4c258)]
            else:
                _2222322b7d6a = _57c87a83896a(_afc724ac3e41, _28e10e0d9b9c)
                _b87c0336fb3b = _cbe126802873(_2222322b7d6a, _cbe73041bf8b, _31d6ac577266 == 1 or _d60d6abe4d87, _31d6ac577266)
                _314b0bc4c258 = [_09ed6bbaf7ff] * _f41720717511(_b87c0336fb3b)
            _a2606f2bce26[_31d6ac577266] = _ce4f1ce004ed._4adcbff5be65(_b87c0336fb3b, _2f948f47b688=_2b1f38f404d0, _ea6f3221ac70=_ce4f1ce004ed._fe5e966b03b5)
            _f6448ac29eb5[_31d6ac577266] = _ce4f1ce004ed._4adcbff5be65(_314b0bc4c258, _2f948f47b688=_2b1f38f404d0, _ea6f3221ac70=_ce4f1ce004ed._fe5e966b03b5)
        return _a2606f2bce26, _f6448ac29eb5

    def _c06ecd0775b4(self, _b7e80a993b5b):
        _ce4f1ce004ed._800570aa3b44._da39d261c179._9a99b445cb4c(self._361a7bb0e5c4(), _5bf35fefe5d7=1.0)
    
    def _a1ba02815375(self, _b7e80a993b5b):
        for _c6c25b688485 in self._361a7bb0e5c4():
            if _c6c25b688485 is not _1e5ae9a9efdd:
                _c6c25b688485._94ac33f1dcd6._e320f66fe953(-5, 5)

    def _bc464eb222da(self):
        _99d85e9b5141 = 0
        for _c6c25b688485 in self._361a7bb0e5c4():
            if _c6c25b688485._be64dbea5aba is not _1e5ae9a9efdd:
                _cb4f552fc7a4 = _c6c25b688485._be64dbea5aba._dc415e5e766f()._94ac33f1dcd6._094d92b40d85(2)
                _99d85e9b5141 += _cb4f552fc7a4._c5ad376f4247() ** 2
        return _99d85e9b5141 ** 0.5  # L2 norm

    def _2d58aace41b8(self):
        _53ae92ebc5d7 = [_874118ee4b17 for _874118ee4b17 in self._361a7bb0e5c4() if _874118ee4b17._b40af3a668ce]
        if not _53ae92ebc5d7:
            _ffc4f4a776cc("No trainable parameters. Skipping optimizer creation.")
            return _1e5ae9a9efdd
        
        _b4b525d474c3 = _2c9fc8ed2beb(lambda _874118ee4b17: _874118ee4b17._b40af3a668ce, self._361a7bb0e5c4())

        _20cceb0e9425 = {
            "adamw": _ce4f1ce004ed._f3ad76562693._c8b9b5b93928,
            "adamax": _ce4f1ce004ed._f3ad76562693._7402fe525578,
            "adam": _ce4f1ce004ed._f3ad76562693._ba12dded5020,
        }
        _9fd7f6028e82 = _20cceb0e9425._c1038ba364ef(self._1be6cc768f32._98ba3098af1b(), _ce4f1ce004ed._f3ad76562693._ba12dded5020)

        _b7e80a993b5b = _9fd7f6028e82(_b4b525d474c3, _7b53309afd5b=self._ff714fd89459._7b53309afd5b, _498b45053b46=0.001)

        _019bcd210954 = self._136b9f4582c6._6831bb3b260a
        _e5bda5467eaa = math._b8209cca5bc2(0.1 * _019bcd210954)

        _91883a028484 = _ce4f1ce004ed._f3ad76562693._ab6bd98135ec._af0095406910(_b7e80a993b5b, _0b89922b8cbf=lambda _91925b025d8f: (_91925b025d8f + 1) / _e5bda5467eaa)

        _4e6460e041ba = _ce4f1ce004ed._f3ad76562693._ab6bd98135ec._8331fd989d31(
            _b7e80a993b5b,
            _2c3b21822cc1=_b1db98d974f3(1, _019bcd210954 - _e5bda5467eaa),
            _05672e46ab27=2,
            _fbaae4e322f5=1e-6
        )
        _ab6bd98135ec = _ce4f1ce004ed._f3ad76562693._ab6bd98135ec._49e269cff202(
            _b7e80a993b5b,
            _d5c5e6458fe6=[_91883a028484, _4e6460e041ba],
            _226528091a01=[_e5bda5467eaa]
        )
        return {"optimizer": _b7e80a993b5b, "lr_scheduler": {"scheduler": _ab6bd98135ec, "interval": "epoch", "monitor": "val_loss"}}
