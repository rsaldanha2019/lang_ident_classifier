# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the authora if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import ast
from collections import Counter, OrderedDict, defaultdict
import copy
import math
import os
import numpy as np
import pandas as pd
import torch
import lightning as pl
import bitsandbytes
from torchmetrics import Accuracy, ConfusionMatrix, Precision, Recall, F1Score
from torch.amp import autocast
from cachetools import LRUCache
from lightning.pytorch.utilities.rank_zero import rank_zero_only
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset
from lang_ident_classifier.language.loss.class_weighted_focal_loss_with_adaptive_focus import ClassWeightedFocalLossWithAdaptiveFocus
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
from lang_ident_classifier.language.accuracy.class_weighted_accuracy import ClassWeightedAccuracy
from transformers import AutoModelForSeq2SeqLM
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# Global cache (NOT in model class)
FROZEN_EMBEDDING = None  
# MAX_OLD_EMBS = 1000  # Limit the cache size

# class LRUCacheDict(OrderedDict):
#     def __init__(self, max_size):
#         self.max_size = max_size
#         super().__init__()

#     def __getitem__(self, key):
#         value = super().__getitem__(key)
#         self.move_to_end(key)
#         return value

#     def __setitem__(self, key, value):
#         if key in self:
#             self.move_to_end(key)
#         elif len(self) >= self.max_size:
#             self.popitem(last=False)  # Remove LRU item
#         super().__setitem__(key, value)

# OLD_EMB_TRAIN = LRUCacheDict(max_size=MAX_OLD_EMBS)
# OLD_EMB_VAL = LRUCacheDict(max_size=MAX_OLD_EMBS)

class SafeModuleWrapper(torch.nn.Module):
    def __init__(self, module, clamp_min=-5, clamp_max=5):
        super().__init__()
        self.module = module
        # self.module = module.to(dtype=torch.float32)  # Convert module to FP32
        # for param in self.module.parameters():
        #     param.data = param.data.to(torch.float32)
        # for buffer in self.module.buffers():
        #     buffer.data = buffer.data.to(torch.float32)
        
        self.clamp_min = clamp_min
        self.clamp_max = clamp_max

    # def forward(self, *inputs, **kwargs):
    #     # Ensure all inputs are float32 if they are tensors
    #     inputs = tuple(inp.float() if isinstance(inp, torch.Tensor) else inp for inp in inputs)
        
    #     # Logging dtype info
    #     # param_dtypes = {name: param.dtype for name, param in self.module.named_parameters()}
    #     # buffer_dtypes = {name: buffer.dtype for name, buffer in self.module.named_buffers()}
    #     # print(f"[Forward Pass] {self.module.__class__.__name__} running")
    #     # print(f"  - Parameters Dtype: {param_dtypes if param_dtypes else 'No Parameters'}")
    #     # print(f"  - Buffers Dtype: {buffer_dtypes if buffer_dtypes else 'No Buffers'}")

    #     # Forward pass
    #     output = self.module(*inputs, **kwargs)
        
    #     # Convert output to FP32 and clamp if necessary
    #     if isinstance(output, torch.Tensor):
    #         output = torch.clamp(output.float(), min=self.clamp_min, max=self.clamp_max)
    #         return torch.nan_to_num(output)
    #     return output  # If it's not a tensor, return as is

    def forward(self, *inputs, **kwargs):
        # Efficient input dtype conversion
        inputs = tuple(inp.to(torch.float32) if isinstance(inp, torch.Tensor) and inp.dtype != torch.float32 else inp
                       for inp in inputs)

        # Forward pass
        output = self.module(*inputs, **kwargs)

        # Apply clamping efficiently
        if isinstance(output, torch.Tensor):
            output = output.to(torch.float32)  # Ensure float32
            output.clamp_(self.clamp_min, self.clamp_max)  # In-place clamping
            if torch.isnan(output).any():
                output = torch.nan_to_num(output)  # Handle NaNs only if they exist
            return output

        return output  # Return non-tensor outputs as is
    
class LanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        pretrained_embedding_model,
        class_names,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_backbone_model_units_unfrozen,
        loss_type,
        num_fc_layers,
        activation_function_for_layer,
        add_dropout_after_embedding,
        is_train,
        tokenizer,
        random_seed: int = 20,
        pretrained_model_embedding_name = None,
        trial_number=None,
        decision_threshold=0.0
    ):
        super(LanguageIdentificationClassifier, self).__init__()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self.save_hyperparameters({
            "lr": float(lr),
            "optimizer": str(optimizer),
            "num_backbone_model_units_unfrozen": int(num_backbone_model_units_unfrozen),
            "loss_type": str(loss_type),
            "num_fc_layers": int(num_fc_layers),
            "activation_function_for_layer": str(activation_function_for_layer),
            "add_dropout_after_embedding": bool(add_dropout_after_embedding),
            "is_train": bool(is_train),
            "random_seed": int(random_seed),
        })
        # print(f"HPARAMS {self.hparams}")
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
        np.random.seed(random_seed)
        self.trial_number = int(trial_number) if trial_number is not None else None
        self.tokenizer = tokenizer
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.pretrained_model_embedding_name = pretrained_model_embedding_name
        self.num_classes = len(class_names) # we dont prepend unk so that loss is on known classes
        self.class_names = ["unk"] + class_names if decision_threshold > 0 else class_names # adding unknown to existing clases please take care where you use
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.ignore_idx = -100
        self.decision_threshold = decision_threshold

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self.embedding = pretrained_embedding_model
        # # Convert LayerNorm inside self.embedding to FP32
        # for module in self.modules():
        #     if isinstance(module, torch.nn.LayerNorm):
        #         module.to(torch.float32)  # Convert weights & buffers to FP32
        #         module.weight.data = module.weight.data.to(torch.float32)
        #         if module.bias is not None:
        #             module.bias.data = module.bias.data.to(torch.float32)
        self.embedding.requires_grad_(False).to(self.curr_device)

        self.num_fc_layers = num_fc_layers
        self.activation_function_for_layer = activation_function_for_layer
        self.num_backbone_model_units_unfrozen = num_backbone_model_units_unfrozen
        
        # Unfreeze specific layers of the encoder
        if num_backbone_model_units_unfrozen > 0:
            if "mt5" in self.pretrained_model_embedding_name:
                for param in self.embedding.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = False  # Freeze all layers initially
                
                if num_backbone_model_units_unfrozen > 0:
                    for block in self.embedding.encoder.block[-num_backbone_model_units_unfrozen:]:  # <-- Fix here
                        # for name, submodule in block.named_modules():
                        #     if "dropout" in name.lower():  # Check if "dropout" is in the module name
                        #         submodule.train()  # Ensure Dropout layers are not frozen
                        for param in block.parameters():
                            if not param.is_leaf:
                                param = param.detach()
                            if isinstance(param, torch.Tensor) and (param.is_floating_point() or torch.is_complex(param)):
                                param.requires_grad = True

            # elif "mbart" in self.pretrained_model_embedding_name:
            #     for param in self.embedding.parameters():
            #         if not param.is_leaf:
            #             param = param.detach()
            #         param.requires_grad = False  # Freeze all layers initially
                
            #     if num_backbone_model_units_unfrozen > 0:
            #         for param in self.embedding.model.encoder.layers[-(num_backbone_model_units_unfrozen)].parameters():
            #             if not param.is_leaf:
            #                 param = param.detach()
            #             param.requires_grad = True
            elif "mbart" in self.pretrained_model_embedding_name:
                for param in self.embedding.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = False  # Freeze all layers initially
                
                if num_backbone_model_units_unfrozen > 0:
                    for layer in self.embedding.model.encoder.layers[-num_backbone_model_units_unfrozen:]:  # ✅ Fix
                        # for name, submodule in layer.named_modules():
                        #     if "dropout" in name.lower():  # Check if "dropout" is in the module name
                        #         submodule.train()  # Ensure Dropout layers are not frozen
                        for param in layer.parameters():
                            if not param.is_leaf:
                                param = param.detach()
                            param.requires_grad = True
            else:
                for param in self.embedding.pooler.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = True
                if num_backbone_model_units_unfrozen > 1:
                    for param in self.embedding.encoder.layer[-(num_backbone_model_units_unfrozen-1)].parameters():
                        if not param.is_leaf:
                            param = param.detach()
                        param.requires_grad = True

        self.add_dropout_after_embedding = add_dropout_after_embedding
        if add_dropout_after_embedding:
            self.dropout = torch.nn.Dropout(0.1, inplace=False)
        
        # Define FC layers
        if num_fc_layers == 1:
            start_input_features = self.embedding.config.hidden_size
            end_output_features = self.num_classes
            if activation_function_for_layer:
                setattr(self, f"fc_with_{activation_function_for_layer}_activation_1", torch.nn.Sequential(
                    # torch.nn.LayerNorm(start_input_features, dtype=torch.float32),
                    torch.nn.Linear(start_input_features, end_output_features),
                    torch.nn.LayerNorm(end_output_features),
                    self._get_activation_function_instance(activation_function_for_layer,end_output_features)
                ))
            else:
                setattr(self, f"fc_1", torch.nn.Linear(start_input_features, end_output_features))
        else:
            start_input_features = self.embedding.config.hidden_size
            end_output_features = self.num_classes
            for layer_idx in range(num_fc_layers):
                if layer_idx == 0:
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 != num_fc_layers:
                    in_features = start_input_features
                    out_features = in_features//2
                elif layer_idx+1 == num_fc_layers:
                    in_features = start_input_features
                    out_features = end_output_features
                # setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
                # if activation_function_for_layer and layer_idx+1 < num_fc_layers:
                #     setattr(self, f"{activation_function_for_layer}_{layer_idx+1}", self._get_activation_function_instance(activation_function_for_layer, out_features))
                if activation_function_for_layer and layer_idx+1 < num_fc_layers:
                    setattr(self, f"fc_with_{activation_function_for_layer}_activation_{layer_idx+1}", torch.nn.Sequential(
                        # torch.nn.LayerNorm(start_input_features, dtype=torch.float32),
                        torch.nn.Linear(start_input_features, out_features),
                        torch.nn.LayerNorm(out_features),
                        self._get_activation_function_instance(activation_function_for_layer, out_features) if activation_function_for_layer and layer_idx+1 < num_fc_layers else torch.nn.Identity()
                    ))
                else:
                    setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
                start_input_features = out_features

        # Loss function initialization
        if loss_type.casefold() == "class_weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, device=self.curr_device, ignore_index=self.ignore_idx)
        elif loss_type.casefold() == "focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=0.25, device=self.curr_device, ignore_index=self.ignore_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, device=self.curr_device, ignore_index=self.ignore_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type1', device=self.curr_device, ignore_index=self.ignore_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type2', device=self.curr_device, ignore_index=self.ignore_idx)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type3', device=self.curr_device, ignore_index=self.ignore_idx)
        else:
            self._criterion = ClassWeightedCrossEntropyLoss(device=self.curr_device, ignore_index=self.ignore_idx)
        
        # self._accuracy = ClassWeightedAccuracy(
        #         # device=self.curr_device,
        #         class_weights=self.class_weights,
        #         # num_classes=self.num_classes,
        #         num_classes=self.tokenizer.vocab_size,
        #         # task=self.classification_task,
        #         ignore_index=self.ignore_padding_token_idx,
        #         average="custom",
        #     ).to('cpu')
        self._micro_accuracy = Accuracy(
            num_classes=len(class_names),
            average="micro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")
        self._macro_accuracy = Accuracy(
            num_classes=len(class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")
        self._macro_precision = Precision(
            num_classes=len(class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")
        self._macro_recall = Recall(
            num_classes=len(class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")
        self._macro_f1 = F1Score(
            num_classes=len(class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        # Classwise metrics (per-class values, tensor of shape [num_classes])
        self._classwise_accuracy = Accuracy(
            num_classes=len(class_names),
            average=None,   # <-- per-class instead of macro/micro
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._classwise_precision = Precision(
            num_classes=len(class_names),
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._classwise_recall = Recall(
            num_classes=len(class_names),
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._classwise_f1 = F1Score(
            num_classes=len(class_names),
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._confmat = ConfusionMatrix(
            num_classes=len(class_names),
            task=self.classification_task,
            normalize=None,  # can also be "true" for row-normalized
            ignore_index=self.ignore_idx,
        ).to("cpu")

        
        self.optimizer_name = optimizer.casefold()
        self.fix_embedding_layers()
        # Load old model ONCE but prevent PyTorch from tracking it
        global FROZEN_EMBEDDING 
        FROZEN_EMBEDDING = copy.deepcopy(self.embedding).eval()
        self._validation_outputs = []
        self._test_outputs = []
        # for param in OLD_EMBEDDING_CACHE.parameters():
        #     param.requires_grad = False  # Ensure it's frozen

        # self.amp_hooks = []
        # self.register_amp_hooks()
        # self.fix_layernorm(self.embedding)
        # Clone and freeze old embeddings
        self.register_nan_hooks(self.embedding)
        self.initialize_weights(self.curr_device, num_fc_layers)
    
    def register_nan_hooks(self, module, prefix=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for name, child in module.named_children():
            full_name = f"{prefix}.{name}" if prefix else name  # Keep full layer path

            # Hook function to check for NaNs in forward pass
            def detect_nan_hook(mod, inp, out):
                if isinstance(out, torch.Tensor) and out.isnan().any():
                    print(f"NaN detected in {full_name} ({mod.__class__.__name__}) ({out.dtype})")

            child.register_forward_hook(detect_nan_hook)

            # Recursively apply to children
            self.register_nan_hooks(child, full_name)
    
    def has_trainable_params(self, module):
        return any(p.requires_grad for p in module.parameters())  # Includes submodules
    
    def fix_embedding_layers(self):
        """Convert LayerNorm, activations, dropout, and attention layers to float32 and wrap them safely."""

        updates = []

        for name, module in self.named_modules():
            if not self.has_trainable_params(module):
                continue  # Skip frozen layers

            # Identify LayerNorm modules
            is_norm = "norm" in name.lower() or isinstance(module, (torch.nn.LayerNorm, getattr(torch.nn, "MT5LayerNorm", torch.nn.LayerNorm)))
            
            # Identify common activation functions (gated for complex layers in mt5 blocks for NaN)
            is_act = any(act in name.lower() for act in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"])
            
            # Identify dropout layers
            is_dropout = "dropout" in name.lower() or isinstance(module, torch.nn.Dropout)
            
            # Identify attention modules
            is_attention = "attention" in name.lower()

            if is_norm:
                module.eps = 1e-5  # Ensure stability for LayerNorm

            if is_norm or is_act or is_attention: #is attnetion added to remove the mixed type
                module.to(torch.float32)  # Use float32 for stability
                if not isinstance(module, SafeModuleWrapper):
                    updates.append((name, SafeModuleWrapper(module)))  # Wrap for safe forward pass

        # Apply wrapped modules
        for name, new_module in updates:
            parent_module, attr = self.get_parent_and_attr(name)
            if parent_module is not None:
                setattr(parent_module, attr, new_module)


    def get_parent_and_attr(self, module_name):
        """Finds the parent module and attribute name given the full module path."""
        parts = module_name.split('.')
        parent = self  # Start from the main model
        for part in parts[:-1]:  # Traverse down but stop at the parent
            parent = getattr(parent, part, None)
            if parent is None:
                return None, None
        return parent, parts[-1]  # Return parent module and final attribute

    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            # return torch.nn.PReLU(num_parameters=num_parameters)
            return torch.nn.PReLU(num_parameters=1)
        elif activation_function_for_layer.casefold() == "leaky_relu":
            return torch.nn.LeakyReLU(inplace=False)
        else:
            return torch.nn.ReLU(inplace=False) # in place tensor modifications disabled due to issues in gradient 

    def initialize_weights(self, device, num_fc_layers):
        def _initialize_weights(m):
            if hasattr(m, "weight") and m.weight.dim() > 1:
                # print(f"Initializing {m}")
                m.to(device)
                torch.nn.init.xavier_uniform_(m.weight.data)
                # if m.bias is not None:  # Initialize bias as well
                #     torch.nn.init.zeros_(m.bias.data)
        
        # for layer_idx in range(num_fc_layers):
        #     layer = getattr(self, f"fc_{layer_idx+1}")
        #     layer.apply(_initialize_weights)
        fc_layers = [layer for name, layer in self._modules.items() if name.startswith("fc_")]
        # print(f"Initializing layers {fc_layers}")
        for layer in fc_layers:
            layer.apply(_initialize_weights)

    def forward(self, input_ids, labels=None):
        """Optimized forward pass with minimal GPU memory usage."""

        # Move input to the correct device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)

        # Create attention mask: 1 for non-pad tokens, 0 for pad tokens
        attention_mask = (input_ids != self.tokenizer.pad_token_id).long().to(self.curr_device, non_blocking=True)

        frozen_embedding_output = None  # Initialize to avoid referencing uninitialized variables
        
        # with torch.no_grad():  # Disable gradient tracking for frozen embeddings
        if "mt5" in self.pretrained_model_embedding_name:
            embedding_output = self.embedding.encoder(input_ids, attention_mask).last_hidden_state
            # old_embedding_output = self.compute_frozen_embeddings(input_ids, attention_mask)
            if self.num_backbone_model_units_unfrozen > 0 and (self.trainer.training or self.trainer.validating):
                # frozen_embedding_output = FROZEN_EMBEDDING.encoder(input_ids, attention_mask).last_hidden_state.clone()
                frozen_embedding_output = FROZEN_EMBEDDING.encoder(input_ids, attention_mask).last_hidden_state.detach()

        elif "mbart" in self.pretrained_model_embedding_name:
            embedding_output = self.embedding.model.encoder(input_ids, attention_mask).last_hidden_state
            if self.num_backbone_model_units_unfrozen > 0 and (self.trainer.training or self.trainer.validating):
                # frozen_embedding_output = FROZEN_EMBEDDING.model.encoder(input_ids, attention_mask).last_hidden_state.clone()
                frozen_embedding_output = FROZEN_EMBEDDING.model.encoder(input_ids, attention_mask).last_hidden_state.detach()
        else:
            embedding_output = self.embedding(input_ids, attention_mask).last_hidden_state
            if self.num_backbone_model_units_unfrozen > 0 and (self.trainer.training or self.trainer.validating):
                # frozen_embedding_output = FROZEN_EMBEDDING(input_ids, attention_mask).last_hidden_state.clone()
                frozen_embedding_output = FROZEN_EMBEDDING(input_ids, attention_mask).last_hidden_state.detach()

        # Compute KL and contrastive loss efficiently (offloaded to CPU when possible)
        # kl_loss = torch.tensor(0.0, device=self.curr_device)
        # contrastive_loss = torch.tensor(0.0, device=self.curr_device)
        kl_loss = (embedding_output * 0).sum()
        contrastive_loss = (embedding_output * 0).sum()
        if self.num_backbone_model_units_unfrozen > 0 and (self.trainer.training or self.trainer.validating):
            kl_loss, contrastive_loss = self.compute_kl_contrastive_loss(
                embedding_output, frozen_embedding_output, device=self.curr_device
            )

        # Dropout layer if enabled
        output = self.dropout(embedding_output) if self.add_dropout_after_embedding else embedding_output

        # Fully connected layers (loop efficiently)
        for layer_idx in range(self.num_fc_layers):
            layer = getattr(self, f"fc_with_{self.activation_function_for_layer}_activation_{layer_idx+1}", None) or \
                    getattr(self, f"fc_{layer_idx+1}")
            output = layer(output)

        # Explicitly remove large tensors from memory to free up GPU
        del input_ids, attention_mask, embedding_output, frozen_embedding_output  
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free unused memory

        return output, kl_loss, contrastive_loss

    def register_amp_hooks(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def hook_fn(module, inputs, outputs):
            if any(inp.dtype == torch.float16 for inp in inputs if isinstance(inp, torch.Tensor)):
                print(f"Layer {module.__class__.__name__} is using float16!")

        # Attach hooks to all layers in self.model
        for submodule in self.modules():
            hook = submodule.register_forward_hook(hook_fn)
            self.amp_hooks.append(hook)  # Store hooks to remove them later if needed

    def remove_hooks(self):
        """Remove all registered forward hooks."""
        for hook in getattr(self, "amp_hooks", []):
            hook.remove()
        self.amp_hooks = []

    def align_tokens_to_words(self, input_ids, token_preds, token_labels):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        tokens = [self.tokenizer.convert_ids_to_tokens(ids) for ids in input_ids]
        word_preds, word_labels = [], []
        
        for token_seq, pred_seq, label_seq in zip(tokens, token_preds, token_labels):
            for token, pred, label in zip(token_seq, pred_seq, label_seq):
                if token == self.tokenizer.pad_token or label == self.ignore_idx:
                    continue  # Skip padding & ignored labels

                # Detect subword tokens (model-specific handling)
                is_subword = (
                    token.startswith("##") or  # BERT/RoBERTa (WordPiece)
                    token.startswith("▁") or   # IndicBERT/mT5 (SentencePiece)
                    token in ["<unk>", "<pad>"]  # Generic unknown/padding tokens
                )

                if is_subword:
                    continue  # Ignore subword parts, keep only first part's label
                
                # Store the first subword’s label as word-level
                word_preds.append(pred.item())
                word_labels.append(label.item())

        return torch.tensor(word_preds), torch.tensor(word_labels)

    def compute_kl_contrastive_loss(self, new_emb_cpu, old_emb_cpu, device="cuda"):
        """Computes KL divergence and contrastive loss efficiently with minimal GPU usage."""
        
        # Ensure tensors are detached and moved to CPU for lightweight loss computation
        # new_emb_cpu = new_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)
        # old_emb_cpu = old_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)
        new_emb_cpu = new_emb_cpu.clamp(min=-30, max=30)
        old_emb_cpu = old_emb_cpu.clamp(min=-30, max=30)
        T = 2.0 # Temperature fixed in Hinto et al 2015 set at 2 or 3 most cases works
        # Compute KL divergence using more stable log-softmax
        new_emb_log = torch.nn.functional.log_softmax(new_emb_cpu/T, dim=-1)
        old_emb_prob = torch.nn.functional.softmax(old_emb_cpu/T, dim=-1)
        latent_dim = new_emb_log.shape[-1]  # Safe for [batch, dim]
        kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean")* (T * T) / latent_dim

        # Compute cosine similarity for contrastive loss No scaling on temp for constractive since cosine is scale invariant
        embedding_drift = torch.nn.functional.cosine_similarity(new_emb_cpu, old_emb_cpu, dim=-1).mean()
        contrastive_loss = 1 - embedding_drift

        # Free CPU memory after computation
        del new_emb_cpu, old_emb_cpu
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Ensure GPU stays clean

        # Move results back to GPU if necessary
        return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    
    def training_step(self, batch, batch_idx):
        """Optimized training step with reduced memory footprint and improved stability."""
        # input_ids, labels = batch
        input_ids = batch["input_ids"]
        labels = batch["labels"]
        batch_size = input_ids.size(0)

        # Ensure data is on the correct device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        labels = labels.to(self.curr_device, non_blocking=True)

        # Forward pass
        outputs, kl_loss, contrastive_loss = self(input_ids)

        # Flatten outputs and labels for loss computation
        outputs = outputs.contiguous().view(-1, outputs.shape[-1])
        labels = labels.contiguous().view(-1)

        # Compute classification loss
        loss = self._criterion(outputs, labels)

        # Ensure KL and contrastive loss values are finite
        # loss = torch.nan_to_num(loss, nan=0.0)
        # kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
        # contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)
        # Replace NaNs while preserving autograd graph
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)


        # Combine losses with scaling factors
        # loss += 0.05 * kl_loss + 0.05 * contrastive_loss
        epoch = float(self.trainer.current_epoch)
        lambda_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
        lambda_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
        combined_loss = loss + lambda_kl * kl_loss + lambda_contrast * contrastive_loss

        # Convert logits to predicted labels
        # with torch.no_grad():  # Prevent gradient tracking for metrics
        #     predicted_labels = torch.argmax(outputs, dim=1)
        #     accuracy = self._accuracy(predicted_labels, labels)
        #     precision = self._precision(predicted_labels, labels)
        #     recall = self._recall(predicted_labels, labels)
        #     f1 = self._f1(predicted_labels, labels)

        # Check for NaN loss and log issue
        if torch.isnan(loss):
            print(f"Step {batch_idx}: NaN loss detected!")

        # Store training metrics
        # train_metrics = {
        #     "epoch": float(self.current_epoch),  # Ensure rounding for distributed training
        #     "train_kl_loss": kl_loss.detach(),
        #     "train_contrastive_loss": contrastive_loss.detach(),
        #     "train_loss": loss.detach(),
        #     "train_accuracy": accuracy,
        #     "train_precision": precision,
        #     "train_recall": recall,
        #     "train_f1": f1,
        # }

        # Store training metrics
        train_metrics = {
            "epoch": float(self.current_epoch),
            "train_kl_loss": kl_loss.detach(),
            "train_contrastive_loss": contrastive_loss.detach(),
            "train_classification_loss": loss.detach(),
            "train_loss": combined_loss.detach(),
            "train_lambda_kl": lambda_kl,
            "train_lambda_contrast": lambda_contrast,
        }

        # Log metrics without unnecessary sync overhead
        # self.log_dict(
        #     train_metrics,
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=False,
        #     logger=True,
        #     sync_dist=True,  # Sync across GPUs in distributed training
        # )
        self.log_dict(
            train_metrics,
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,  # Sync across GPUs in distributed training
        )

        # Explicitly delete tensors to free memory
        del input_ids, labels, outputs, 
        # del predicted_labels
        # if torch.cuda.is_available():
        #     torch.cuda.empty_cache()  # Free GPU memory
        return combined_loss

    def on_train_epoch_end(self):
        if torch.cuda.is_available():  # Empty cache less frequently
            torch.cuda.empty_cache()
        return super().on_train_epoch_end()
    
    def validation_step(self, batch, batch_idx):
        """Optimized validation step with better memory handling and stability."""
        # if batch_idx == 0:
        #     print(f"\n[VAL STEP] Batch {batch_idx}")
        #     print("input_ids shape:", batch["input_ids"].shape)
        #     print("labels shape:", batch["labels"].shape)
        #     print("labels min/max:", batch["labels"].min().item(), batch["labels"].max().item())
        #     print("sample_ids:", batch["sample_ids"][:5])  # first 5 sample ids
        #     print("chunk_ids:", batch["chunk_ids"][:5])
        #     print("word_positions lengths:", [len(wp) for wp in batch["word_positions"][:5]])
        #     print("labels:", batch["labels"])

        # input_ids, labels = batch
        input_ids = batch["input_ids"].to(self.curr_device, non_blocking=True)
        labels = batch["labels"].to(self.curr_device, non_blocking=True)
        lang_codes_list = batch["lang_codes"]
        sample_ids = batch["sample_ids"]
        chunk_ids = batch["chunk_ids"]
        word_positions = batch["word_positions"]
        batch_size = input_ids.size(0)

        # Forward pass
        logits, kl_loss, contrastive_loss = self(input_ids)

        # Flatten outputs and labels for loss computation
        flattened_logits = logits.contiguous().view(-1, logits.shape[-1])
        flattened_labels = labels.contiguous().view(-1)

        # Handle NaN/Inf values in logits
        if torch.isnan(flattened_logits).any() or torch.isinf(flattened_logits).any():
            print(f"Validation Step {batch_idx}: NaN detected in logits!\n{flattened_logits}")

        # Compute classification loss
        loss = self._criterion(flattened_logits, flattened_labels)

        # Ensure KL and contrastive loss values are finite
        # loss = torch.nan_to_num(loss, nan=0.0)
        # kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
        # contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)
        # Replace NaNs while preserving autograd graph
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)


        # Combine losses with scaling factors
        # loss += 0.05 * kl_loss + 0.05 * contrastive_loss
        epoch = float(self.trainer.current_epoch)
        lambda_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
        lambda_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
        combined_loss = loss + lambda_kl * kl_loss + lambda_contrast * contrastive_loss

        self.log_dict(
            {
                "val_kl_loss": kl_loss.detach(),
                "val_contrastive_loss": contrastive_loss.detach(),
                "val_classification_loss": loss.detach(),
                "val_loss": combined_loss.detach(),
                "val_lambda_kl": lambda_kl,
                "val_lambda_contrast": lambda_contrast,
            },
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        preds_list = []
        labels_list = []

        # for i in range(batch_size):
        #     logit = outputs[i]       # (seq_len, vocab)
        #     label = labels[i]       # (seq_len,)
        #     mask = label != self.ignore_idx

        #     valid_pred = torch.argmax(logit[mask], dim=-1)  # (valid_len,)
        #     valid_label = label[mask]                       # (valid_len,)

        #     preds_list.append(valid_pred)
        #     labels_list.append(valid_label)

        for i in range(batch_size):
            logit = logits[i]  # (seq_len, vocab)
            label = labels[i]  # (seq_len,)
            mask = label != self.ignore_idx
            valid_logit = logit[mask]  # (valid_len, vocab)
            valid_label = label[mask]  # (valid_len,)
            
            if self.decision_threshold > 0:
                # Compute softmax probabilities
                probs = torch.nn.functional.softmax(valid_logit, dim=-1)  # (valid_len, N)
                max_prob, valid_pred = probs.max(dim=-1)  # (valid_len,)
                
                # Apply unk logic
                is_unk = max_prob < self.decision_threshold  # (valid_len,)
                valid_pred = valid_pred.clone() + 1  # Shift: eng=0 -> 1, ...
                valid_pred[is_unk] = 0  # Unk at 0
                
                # Shift true labels
                valid_label = valid_label.clone() + 1  # Shift: eng=0 -> 1, ...
                del probs, max_prob, is_unk
            else:
                valid_pred = valid_logit.argmax(dim=-1)
                valid_label = valid_label
            
            preds_list.append(valid_pred)
            labels_list.append(valid_label)

            # Freeing inside the loop, after appending
            del valid_logit

        output = {
            "lang_codes": lang_codes_list,
            "preds": preds_list,
            "labels": labels_list,
            "sample_ids": sample_ids,
            "chunk_ids": chunk_ids,
            "word_positions": word_positions,
            "val_loss": combined_loss,
        }

        self._validation_outputs.append(output)

        # Detect NaN loss and log issue
        if torch.isnan(combined_loss):
            print(f"Validation Step {batch_idx}: NaN loss detected!\nInput IDs: {input_ids}\nLabels: {labels}\nOutputs: {logits}")

        # Convert logits to predicted labels
        # with torch.no_grad():  # Avoid tracking gradients for metrics
        #     predicted_labels = torch.argmax(outputs, dim=1)
        #     accuracy = self._accuracy(predicted_labels, labels)
        #     precision = self._precision(predicted_labels, labels)
        #     recall = self._recall(predicted_labels, labels)
        #     f1 = self._f1(predicted_labels, labels)

        # Store validation metrics
        self.log_dict(
            {
                "val_kl_loss": kl_loss.detach(),
                "val_contrastive_loss": contrastive_loss.detach(),
                "val_classification_loss": loss.detach(),
                "val_loss": combined_loss.detach(),
                "val_lambda_kl": lambda_kl,
                "val_lambda_contrast": lambda_contrast,
            },
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )


        # Explicitly delete tensors to free memory
        del input_ids, labels, logits, 
        # del predicted_labels
        # if torch.cuda.is_available():
        #     torch.cuda.empty_cache()  # Free GPU memory

        return output

    def _save_metrics_to_csv(self, metrics_dict, filename, trial_number=None):
        """Helper to save metrics to CSV in per-trial directory."""
        # Figure out project dir (Lightning usually has self.logger.log_dir)
        project_dir = os.getcwd()
        trial_id = f"trial_{trial_number}" if trial_number is not None else "default"

        save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        os.makedirs(save_dir, exist_ok=True)

        filepath = os.path.join(save_dir, filename)
        df = pd.DataFrame(metrics_dict)
        df.to_csv(filepath, index=False)
        print(f"[metrics] Saved {filepath}")

    def gather_preds_labels(self, preds, labels):
        world_size = torch.distributed.get_world_size()

        # Convert to list (so they can vary in length)
        local_data = (preds.cpu().tolist(), labels.cpu().tolist())
        gathered = [None for _ in range(world_size)]
        torch.distributed.all_gather_object(gathered, local_data)

        # Flatten
        all_preds, all_labels = [], []
        for p, l in gathered:
            all_preds.extend(p)
            all_labels.extend(l)

        return torch.tensor(all_preds, dtype=torch.long), torch.tensor(all_labels, dtype=torch.long)

    def on_validation_epoch_end(self):
        if not self._validation_outputs:
            print("[on_validation_epoch_end] No validation outputs to process.")
            return

        preds, labels = self.reconcile_chunks(self._validation_outputs)

        device = self._micro_accuracy.device
        preds, labels = preds.to(device), labels.to(device)

        try:
            # Update all metrics
            self._micro_accuracy.update(preds, labels)
            self._macro_accuracy.update(preds, labels)
            self._macro_precision.update(preds, labels)
            self._macro_recall.update(preds, labels)
            self._macro_f1.update(preds, labels)

            self._classwise_accuracy.update(preds, labels)
            self._classwise_precision.update(preds, labels)
            self._classwise_recall.update(preds, labels)
            self._classwise_f1.update(preds, labels)

            self._confmat.update(preds, labels)

            # Compute results
            final_micro_accuracy = self._micro_accuracy.compute().item()
            final_macro_accuracy = self._macro_accuracy.compute().item()
            final_macro_precision = self._macro_precision.compute().item()
            final_macro_recall = self._macro_recall.compute().item()
            final_macro_f1 = self._macro_f1.compute().item()

            final_classwise_accuracy = self._classwise_accuracy.compute().cpu().numpy()
            final_classwise_precision = self._classwise_precision.compute().cpu().numpy()
            final_classwise_recall = self._classwise_recall.compute().cpu().numpy()
            final_classwise_f1 = self._classwise_f1.compute().cpu().numpy()

            final_confmat = self._confmat.compute().cpu().numpy()

        except Exception as e:
            print(f"[on_validation_epoch_end] Exception: {e}")
            return

        # Log macro metrics to Lightning
        self.log("val_accuracy", final_macro_accuracy, sync_dist=True)

        # Save full metrics to CSV
        trial = getattr(self, "trial", None)  # if Optuna trial is attached
        epoch_idx = self.current_epoch
        metrics_dict = {
            "epoch": [epoch_idx],
            "class_names": [self.class_names],
            "micro_accuracy": [final_micro_accuracy],
            "macro_accuracy": [final_macro_accuracy],
            "macro_precision": [final_macro_precision],
            "macro_recall": [final_macro_recall],
            "macro_f1": [final_macro_f1],
            "classwise_accuracy": [final_classwise_accuracy.tolist()],
            "classwise_precision": [final_classwise_precision.tolist()],
            "classwise_recall": [final_classwise_recall.tolist()],
            "classwise_f1": [final_classwise_f1.tolist()],
            "confusion_matrix": [final_confmat.tolist()],
        }

        self._save_metrics_to_csv(metrics_dict, f"val_epoch_{epoch_idx}.csv", trial_number=self.trial_number)

        # Reset all
        self._micro_accuracy.reset()
        self._macro_accuracy.reset()
        self._macro_precision.reset()
        self._macro_recall.reset()
        self._macro_f1.reset()

        self._classwise_accuracy.reset()
        self._classwise_precision.reset()
        self._classwise_recall.reset()
        self._classwise_f1.reset()
        self._confmat.reset()
        self._validation_outputs.clear()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def reconcile_chunks(self, outputs):
        def to_list(x):
            if isinstance(x, torch.Tensor):
                return x.detach().cpu().reshape(-1).tolist()
            if isinstance(x, np.ndarray):
                return x.reshape(-1).tolist()
            if isinstance(x, (list, tuple)):
                return list(x)
            return [x]

        final_preds, final_labels, final_sids = [], [], []
        seen_chunks = set()  # track (sid, chunk_id)

        # --- iterate over all sample_ids across all ranks ---
        for out in outputs:
            sample_ids     = out["sample_ids"]
            chunk_ids      = out["chunk_ids"]
            chunk_preds    = out["preds"]
            chunk_labels   = out["labels"]
            word_positions = out["word_positions"]

            for i, sid in enumerate(sample_ids):
                cid = int(chunk_ids[i])

                if (sid, cid) in seen_chunks:
                    continue  # already processed this chunk from another rank
                seen_chunks.add((sid, cid))

                preds_i     = to_list(chunk_preds[i])
                labels_i    = to_list(chunk_labels[i])
                positions_i = to_list(word_positions[i])

                if not (len(positions_i) == len(preds_i) == len(labels_i)):
                    print(f"[WARN] mismatch sid={sid} cid={cid}: "
                        f"pos={len(positions_i)} preds={len(preds_i)} labels={len(labels_i)}")
                    continue

                # accumulate into sample-level storage
                if sid not in final_sids:
                    final_sids.append(sid)

                if 'chunks_by_sid' not in locals():
                    chunks_by_sid = defaultdict(list)
                chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))

        # --- reconcile per sample ---
        for sid in final_sids:
            chunks = chunks_by_sid[sid]
            chunks.sort(key=lambda x: x[0])  # sort by chunk_id

            pos_to_preds = defaultdict(list)
            pos_to_labels = defaultdict(list)

            for cid, positions, preds, labels in chunks:
                for pos, pred, lab in zip(positions, preds, labels):
                    pos_to_preds[int(pos)].append(int(pred))
                    pos_to_labels[int(pos)].append(int(lab))

            preds_final, labels_final = [], []
            for pos in sorted(pos_to_preds.keys()):
                pred = Counter(pos_to_preds[pos]).most_common(1)[0][0]
                preds_final.append(pred)
                if pos in pos_to_labels:
                    lab = Counter(pos_to_labels[pos]).most_common(1)[0][0]
                    labels_final.append(lab)

            final_preds.extend(preds_final)
            final_labels.extend(labels_final if labels_final else [-100] * len(preds_final))

            # DEBUG
            print(f"[DEBUG] sid={sid} chunks={len(chunks)} "
                f"unique_positions={len(pos_to_preds)} "
                f"final_preds={len(preds_final)} final_labels={len(labels_final)}")

        print(f"[SUMMARY] reconciled samples={len(final_sids)} "
            f"total_preds={len(final_preds)} total_labels={len(final_labels)}")

        return (
            torch.tensor(final_preds, device="cpu"),
            torch.tensor(final_labels, device="cpu"),
        )


    # LAST WORKING VERSION
    # def reconcile_chunks(self, outputs):
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor):
    #             return x.detach().cpu().reshape(-1).tolist()
    #         if isinstance(x, np.ndarray):
    #             return x.reshape(-1).tolist()
    #         if isinstance(x, (list, tuple)):
    #             return list(x)
    #         # scalar
    #         return [x]

    #     chunks_by_sample = defaultdict(list)

    #     # --- gather all chunks grouped by sample_id ---
    #     for out in outputs:
    #         lang_codes     = out["lang_codes"]
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         src_words      = out.get("src_words", None)  # optional list of words per sample

    #         for i in range(len(sample_ids)):
    #             sid         = sample_ids[i]
    #             lc          = lang_codes[i]
    #             preds_i     = to_list(chunk_preds[i])
    #             labels_i    = to_list(chunk_labels[i])
    #             positions_i = to_list(word_positions[i])

    #             # --- robust alignment ---
    #             # Case: a single prediction for the whole chunk -> broadcast to all words
    #             if len(preds_i) == 1 and len(positions_i) > 1:
    #                 preds_i = preds_i * len(positions_i)
    #             if len(labels_i) == 1 and len(positions_i) > 1:
    #                 labels_i = labels_i * len(positions_i)
            
    #             # Hard align to common length
    #             L = min(len(positions_i), len(preds_i), len(labels_i))
    #             if L == 0:
    #                 continue
    #             positions_i = positions_i[:L]
    #             preds_i     = preds_i[:L]
    #             labels_i    = labels_i[:L]

    #             chunks_by_sample[sid].append(
    #                 (int(chunk_ids[i]), positions_i, preds_i, labels_i, lc, src_words)
    #             )

    #     final_preds, final_labels, final_sample_ids = [], [], []

    #     # --- reconcile per sample ---
    #     for sid, chunks in chunks_by_sample.items():
    #         # sort by chunk_id (deterministic)
    #         chunks.sort(key=lambda x: x[0])

    #         pos_to_preds = defaultdict(list)
    #         pos_to_labels = defaultdict(list)
    #         words_map = {}

    #         for cid, positions, preds, labels, lc, words in chunks:
    #             for pos, pred, lab in zip(positions, preds, labels):
    #                 pos_to_preds[int(pos)].append(int(pred))
    #                 pos_to_labels[int(pos)].append(int(lab))
    #                 if words is not None and int(pos) < len(words):
    #                     words_map[int(pos)] = words[int(pos)]

    #         # finalize with majority vote (or single value)
    #         preds_final, labels_final, words_final = [], [], []
    #         for pos in sorted(pos_to_preds.keys()):
    #             preds_final.append(Counter(pos_to_preds[pos]).most_common(1)[0][0])
    #             labels_final.append(Counter(pos_to_labels[pos]).most_common(1)[0][0])
    #             if words_map:
    #                 words_final.append(words_map.get(pos, f"<pos{pos}>"))

    #         # simple debug for any multi-chunk sample
    #         if len(chunks) > 1:
    #             print(f"[DEBUG] reconciled sample_id={sid} from {len(chunks)} chunks", flush=True)
    #             if words_final:
    #                 print("  words       :", words_final, flush=True)
    #             print("  preds_final :", preds_final, flush=True)
    #             print("  labels_final:", labels_final, flush=True)

    #         if sid not in final_sample_ids:
    #             final_preds.extend(preds_final)
    #             final_labels.extend(labels_final)
    #             final_sample_ids.extend([sid])

    #     return torch.tensor(final_preds, device="cpu"), torch.tensor(final_labels, device="cpu"),



    def test_step(self, batch, batch_idx):
        """Optimized test step for memory-efficient evaluation."""

        # with torch.inference_mode():  # More efficient than torch.no_grad()
        with torch.no_grad():
            # Move batch to GPU with non_blocking
            input_ids = batch["input_ids"].to(self.curr_device, non_blocking=True)
            labels = batch["labels"].to(self.curr_device, non_blocking=True)
            lang_codes_list = batch["lang_codes"]
            sample_ids = batch["sample_ids"]
            chunk_ids = batch["chunk_ids"]
            word_positions = batch["word_positions"]
            batch_size = input_ids.size(0)

            # Forward pass (without KL and contrastive loss)
            outputs, _, _ = self(input_ids)
            preds_list = []
            labels_list = []

            # for i in range(batch_size):
            #     logit = outputs[i]       # (seq_len, vocab)
            #     label = labels[i]       # (seq_len,)
            #     mask = label != self.ignore_idx

            #     valid_pred = torch.argmax(logit[mask], dim=-1).cpu()  # (valid_len,)
            #     valid_label = label[mask].cpu()                        # (valid_len,)

            #     preds_list.append(valid_pred)
            #     labels_list.append(valid_label)

            for i in range(batch_size):
                logit = outputs[i]  # (seq_len, vocab)
                label = labels[i]  # (seq_len,)
                mask = label != self.ignore_idx
                valid_logit = logit[mask]  # (valid_len, vocab)
                valid_label = label[mask]  # (valid_len,)
                
                if self.decision_threshold > 0:
                    # Compute softmax probabilities
                    probs = torch.nn.functional.softmax(valid_logit, dim=-1)  # (valid_len, N)
                    max_prob, valid_pred = probs.max(dim=-1)  # (valid_len,)
                    
                    # Apply unk logic
                    is_unk = max_prob < self.decision_threshold  # (valid_len,)
                    valid_pred = valid_pred.clone() + 1  # Shift: eng=0 -> 1, ...
                    valid_pred[is_unk] = 0  # Unk at 0
                    
                    # Shift true labels
                    valid_label = valid_label.clone() + 1  # Shift: eng=0 -> 1, ...
                    del probs, max_prob, is_unk
                else:
                    valid_pred = valid_logit.argmax(dim=-1)
                    valid_label = valid_label
                
                preds_list.append(valid_pred)
                labels_list.append(valid_label)

                # Freeing inside the loop, after appending
                del valid_logit

            output = {
                "lang_codes": lang_codes_list,
                "preds": preds_list,
                "labels": labels_list,
                "sample_ids": sample_ids,
                "chunk_ids": chunk_ids,
                "word_positions": word_positions,
            }

            self._test_outputs.append(output)

            # Compute evaluation metrics
            # accuracy = self._accuracy(predicted_labels, labels)
            # precision = self._precision(predicted_labels, labels)
            # recall = self._recall(predicted_labels, labels)
            # f1 = self._f1(predicted_labels, labels)

            # Log test metrics
            # self.log_dict(
            #     {
            #         "test_accuracy": accuracy,
            #         "test_precision": precision,
            #         "test_recall": recall,
            #         "test_f1": f1,
            #     },
            #     on_epoch=True,
            #     sync_dist=True,  # Sync across distributed devices
            # )
            output = {
                "lang_codes": lang_codes_list,
                "preds": preds_list,
                "labels": labels_list,
                "sample_ids": sample_ids,
                "chunk_ids": chunk_ids,
                "word_positions": word_positions,
            }

            self._test_outputs.append(output)
            # Explicitly delete tensors to free memory
            del input_ids, labels, outputs
            # if batch_idx % 50 == 0 and torch.cuda.is_available():  # Empty cache less frequently
            # if torch.cuda.is_available():  # Empty cache less frequently
            #     torch.cuda.empty_cache()

            # return {"predictions": predicted_labels}  # Kept on GPU for batch processing
            return output

    def on_test_epoch_end(self):
        outputs = getattr(self, "_test_outputs", None)
        if outputs is None or len(outputs) == 0:
            print("[on_test_epoch_end] No test outputs to process.")
            return

        preds, labels = self.reconcile_chunks(outputs)

        device = self._micro_accuracy.device
        preds, labels = preds.to(device), labels.to(device)

        try:
            # Update metrics
            self._micro_accuracy.update(preds, labels)
            self._macro_accuracy.update(preds, labels)
            self._macro_precision.update(preds, labels)
            self._macro_recall.update(preds, labels)
            self._macro_f1.update(preds, labels)

            self._classwise_accuracy.update(preds, labels)
            self._classwise_precision.update(preds, labels)
            self._classwise_recall.update(preds, labels)
            self._classwise_f1.update(preds, labels)
            self._confmat.update(preds, labels)

            # Compute results
            final_micro_accuracy = self._micro_accuracy.compute().item()
            final_macro_accuracy = self._macro_accuracy.compute().item()
            final_macro_precision = self._macro_precision.compute().item()
            final_macro_recall = self._macro_recall.compute().item()
            final_macro_f1 = self._macro_f1.compute().item()

            final_classwise_accuracy = self._classwise_accuracy.compute().cpu().numpy()
            final_classwise_precision = self._classwise_precision.compute().cpu().numpy()
            final_classwise_recall = self._classwise_recall.compute().cpu().numpy()
            final_classwise_f1 = self._classwise_f1.compute().cpu().numpy()

            final_confmat = self._confmat.compute().cpu().numpy()

        except Exception as e:
            print(f"[on_test_epoch_end] Exception: {e}")
            return

        # Log macro metrics to Lightning
        self.log("test_accuracy", final_macro_accuracy, sync_dist=True)

        # Save full metrics to CSV
        trial = getattr(self, "trial", None)
        metrics_dict = {
            "class_names": [self.class_names],
            "micro_accuracy": [final_micro_accuracy],
            "macro_accuracy": [final_macro_accuracy],
            "macro_precision": [final_macro_precision],
            "macro_recall": [final_macro_recall],
            "macro_f1": [final_macro_f1],
            "classwise_accuracy": [final_classwise_accuracy.tolist()],
            "classwise_precision": [final_classwise_precision.tolist()],
            "classwise_recall": [final_classwise_recall.tolist()],
            "classwise_f1": [final_classwise_f1.tolist()],
            "confusion_matrix": [final_confmat.tolist()],
        }
        self._save_metrics_to_csv(metrics_dict, "test_final.csv", trial_number=self.trial_number)

        # Reset
        self._micro_accuracy.reset()
        self._macro_accuracy.reset()
        self._macro_precision.reset()
        self._macro_recall.reset()
        self._macro_f1.reset()
        self._classwise_accuracy.reset()
        self._classwise_precision.reset()
        self._classwise_recall.reset()
        self._classwise_f1.reset()
        self._confmat.reset()
        self._test_outputs.clear()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        """Optimized prediction step with efficient memory handling."""
        input_ids = batch[0]  # Assume first element is input_ids (labels not needed)

        # Move tensors to device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)

        # Forward pass (without computing KL or contrastive loss)
        outputs, _, _ = self(input_ids)  # [batch_size, seq_len, N]
        outputs = outputs.contiguous().view(-1, outputs.shape[-1])  # [batch_size * seq_len, N]

        if self.decision_threshold > 0:
            # Softmax probabilities
            probs = torch.nn.functional.softmax(outputs, dim=-1)  # [batch_size * seq_len, N]
            max_prob, pred = probs.max(dim=-1)  # [batch_size * seq_len]

            # Apply UNK logic
            is_unk = max_prob < self.decision_threshold
            final_class = pred + 1              # shift right: eng=0 → 1, ...
            final_class[is_unk] = 0             # low-confidence → unk=0

            # Build probability tensor for N+1 classes
            full_probs = torch.zeros(outputs.size(0), self.num_classes + 1, device=outputs.device)
            full_probs[~is_unk, 1:] = probs[~is_unk]
            full_probs[is_unk, 0] = 1.0

        else:
            # Standard prediction (no UNK)
            probs = torch.nn.functional.softmax(outputs, dim=-1)  # [batch_size * seq_len, N]
            final_class = probs.argmax(dim=-1)                    # [batch_size * seq_len]
            full_probs = probs                                    # [batch_size * seq_len, N]

        # Explicitly delete temporary tensors
        del input_ids, outputs
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free GPU memory

        return {
            "predictions": final_class.cpu(),
            "probs": full_probs.cpu()
        }


    # def predict_step(self, batch, batch_idx, dataloader_idx=0):
    #     """Optimized prediction step with efficient memory handling."""

    #     input_ids, _ = batch  # Labels are not needed

    #     # Move tensors to device
    #     input_ids = input_ids.to(self.curr_device, non_blocking=True)

    #     # Forward pass (without computing KL or contrastive loss)
    #     outputs, _, _ = self(input_ids)
    #     predicted_labels = torch.argmax(outputs, dim=-1)

    #     # Explicitly delete tensors to free memory
    #     del input_ids, outputs
    #     if torch.cuda.is_available():
    #         torch.cuda.empty_cache()  # Free GPU memory

    #     return {"predictions": predicted_labels.cpu()}

    
    def on_before_optimizer_step(self, optimizer):
        # Compute gradient norm before clipping
        # grad_norm_before = self._compute_grad_norm()

        # Clip gradients
        # self.clip_gradients(
        #     optimizer, gradient_clip_val=1.0, gradient_clip_algorithm="value"
        # )
        # Manual clipping
        # torch.nn.utils.clip_grad_value_(self.parameters(), clip_value=1.0)
        torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)


        # Compute gradient norm after clipping
        # grad_norm_after = self._compute_grad_norm()

        # # Log both norms
        # self.log("grad_norm/before", grad_norm_before, prog_bar=True, on_step=True)
        # self.log("grad_norm/after", grad_norm_after, prog_bar=True, on_step=True)
    
    def on_after_optimizer_step(self, optimizer):
        for param in self.parameters():
            if param is not None:
                param.data.clamp_(-5, 5)

    def _compute_grad_norm(self):
        total_norm = 0
        for param in self.parameters():
            if param.grad is not None:
                param_norm = param.grad.detach().data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5  # L2 norm

    def configure_optimizers(self):
        """Configures optimizer and learning rate scheduler."""
        
        # Filter trainable parameters
        model_parameters = filter(lambda p: p.requires_grad, self.parameters())

        # Select optimizer
        optimizers = {
            "adamw": torch.optim.AdamW,
            "adamax": torch.optim.Adamax,
            "adam": torch.optim.Adam,
        }

        optimizer_class = optimizers.get(self.optimizer_name.lower(), torch.optim.AdamW)  # Default to Adam

        optimizer = optimizer_class(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Uncomment if using bitsandbytes optimizers
        # if self.optimizer_name == "adamw":
        #     optimizer = bitsandbytes.optim.AdamW(model_parameters, lr=self.hparams.lr, weight_decay=0.001)
        # elif self.optimizer_name == "adam":
        #     optimizer = bitsandbytes.optim.Adam(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Learning rate scheduler
        # lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        #     optimizer, mode="min", factor=0.1, patience=3, cooldown=3, min_lr=1e-8, verbose=True
        # )
        # lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=2, eta_min=1e-6)
    

        # Warmup: 10% of total epochs, rounded up
        total_epochs = self.trainer.max_epochs
        warmup_epochs = math.ceil(0.1 * total_epochs)

        # Warmup LR schedule: linear increase
        warmup_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda epoch: (epoch + 1) / warmup_epochs)

        # CosineAnnealingWarmRestarts after warmup
        cosine_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer,
            T_0=max(1, total_epochs - warmup_epochs),
            T_mult=2,
            eta_min=1e-6
        )

        # Combine both in a SequentialLR
        lr_scheduler = torch.optim.lr_scheduler.SequentialLR(
            optimizer,
            schedulers=[warmup_scheduler, cosine_scheduler],
            milestones=[warmup_epochs]
        )
        # Debugging/logging (if needed)
        # print(f"Using optimizer: {self.optimizer_name}")
        # print(f"Initial learning rate: {self.hparams.lr}")
        # print(f"Weight decay: 0.001")
        
        return {"optimizer": optimizer, "lr_scheduler": {"scheduler": lr_scheduler, "interval": "epoch", "monitor": "val_loss"}}

