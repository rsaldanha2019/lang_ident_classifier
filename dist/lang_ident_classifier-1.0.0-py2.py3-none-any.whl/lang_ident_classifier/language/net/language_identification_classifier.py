# -*- coding: utf-8 -*-
"""
Language Identification Classifier
Handles language identification using a transformer-based model with custom loss functions.
"""
import math
import os
from collections import _231273736dcc, _7ec522c0aff3
from copy import _8fd4b8b0b0df
from typing import _f57952c8b841, _56584f733d4c, _a88d0e489242, _906d908ac8ed
from _5b087de0ecdf import _ec1d9fda8065

import _244030b86668 as _e2b9de59569f
import _f99954c79c46 as _bf3a979581d6
import _2280c10a6419 as _e01ba5602f2c
import _effb2d0502aa
from _82282bb1b6a5 import _57f36f1bd32a, _bbd7d07630cf, _8fd2fa67f4a3, _d6c3ae82ac3b, _fcfb3fbd5032

from _a247b0952bf6._6c55247c240e._b22be26a2a05._4d9b11d8a884 import _7e5be0faac77
from _a247b0952bf6._6c55247c240e._5b514bd667c2._c80d1fc33b33 import _71aa06d90a81
from _a247b0952bf6._6c55247c240e._5b514bd667c2._b7cef4a84c1a import _1fb27876c842
from _a247b0952bf6._6c55247c240e._5b514bd667c2._4476c004583b import _396307122704
from _a247b0952bf6._6c55247c240e._46ed5769bc0a._67704f03449f import _449684af1ffd

# Only export the classifier as public API
_168366160cd7 = ["LanguageIdentificationClassifier"]

_1b807c30fd1f = 'cuda' if _effb2d0502aa._359038a79392._167c9e2b7227() else 'cpu'
_71419e992e14 = _59f90d54f6ef

class _d77bd157289c(_e2b9de59569f._17f39b749859):
    """Classifier for language identification using a transformer-based model."""

    class _ad7986959162(_effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _3e3ab4485816(self, _0ab175d4f958: _8aaf69883c2a, _9a63c96fe8a4: _8aaf69883c2a = 64):
            _a96b6506ada9()._ffbe87b45cfc()
            self._0daffc46aa6c = _effb2d0502aa._e49d31a4c8f7._474a62749155(_0ab175d4f958, _9a63c96fe8a4, _08893c4fe419=_625b066368b1)
            self._425052097432 = _effb2d0502aa._e49d31a4c8f7._5cfe87e36bda(_9f83f21adc25=_00af90ed2be9)
            self._24f3d92308eb = _effb2d0502aa._e49d31a4c8f7._474a62749155(_9a63c96fe8a4, _0ab175d4f958, _08893c4fe419=_625b066368b1)
            # start adapter near-zero so initial behavior is identity
            _effb2d0502aa._e49d31a4c8f7._c22e44b69c5d._8c32520f2de2(self._24f3d92308eb._28a13f4340f4)
            _effb2d0502aa._e49d31a4c8f7._c22e44b69c5d._34bcf11238d2(self._0daffc46aa6c._28a13f4340f4, _a0a6e8c2d34f=math._564a1da0f381(5))

        def _db3a97f30af8(self, _ca6f9f458fc3: _effb2d0502aa._432098c93ca7) -> _effb2d0502aa._432098c93ca7:
            # supports x shape (B, L, D) or (B, D)
            if _ca6f9f458fc3._0ab175d4f958() == 2:
                _73909e2f257c = self._24f3d92308eb(self._425052097432(self._0daffc46aa6c(_ca6f9f458fc3)))
                return _ca6f9f458fc3 + _73909e2f257c
            _0049ea6b4f92, _de230b17d4bb, _170770ca5d77 = _ca6f9f458fc3._281dc383df6a
            _5aeb536bb6c6 = _ca6f9f458fc3._d97c606f10be(-1, _170770ca5d77)                    # (B*L, D)
            _5aeb536bb6c6 = self._24f3d92308eb(self._425052097432(self._0daffc46aa6c(_5aeb536bb6c6)))  # (B*L, D)
            _5aeb536bb6c6 = _5aeb536bb6c6._d97c606f10be(_0049ea6b4f92, _de230b17d4bb, _170770ca5d77)
            return _ca6f9f458fc3 + _5aeb536bb6c6

    class _0a376780bf00(_effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2):
        """Wraps a module to ensure stable forward pass with clamping and NaN handling."""
        
        def _3e3ab4485816(self, _45daa96c5ff2: _effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2, _5b3ff3fc5aaa: _c206dc789dd6 = -5.0, _a358bcfcee66: _c206dc789dd6 = 5.0):
            """
            Initialize the wrapper with a module and clamping bounds.

            Args:
                module (torch.nn.Module): Module to wrap.
                clamp_min (float): Minimum value for clamping.
                clamp_max (float): Maximum value for clamping.

            Raises:
                ValueError: If module is None or invalid.
            """
            if _45daa96c5ff2 is _59f90d54f6ef:
                raise _ba2bf025b59c("Module cannot be None")
            _a96b6506ada9()._ffbe87b45cfc()
            self._45daa96c5ff2 = _45daa96c5ff2
            self._5b3ff3fc5aaa = _5b3ff3fc5aaa
            self._a358bcfcee66 = _a358bcfcee66

        def _db3a97f30af8(self, *_93df5edc77d0, **_20bc7ddd8b04) -> _effb2d0502aa._432098c93ca7:
            """
            Forward pass with dtype conversion, clamping, and NaN handling.

            Args:
                *inputs: Input tensors or other arguments.
                **kwargs: Keyword arguments for the module.

            Returns:
                torch.Tensor: Processed output tensor.

            Raises:
                RuntimeError: If forward pass fails.
            """
            try:
                _93df5edc77d0 = _b67da2ea0bfb(
                    _5c89c3bb2f15._9c22b2d3029d(_effb2d0502aa._6ff29276e45b) if _51f455f4dbdf(_5c89c3bb2f15, _effb2d0502aa._432098c93ca7) and _5c89c3bb2f15._543679ac4eaf != _effb2d0502aa._6ff29276e45b else _5c89c3bb2f15
                    for _5c89c3bb2f15 in _93df5edc77d0
                )
                _eaa97e1cf273 = self._45daa96c5ff2(*_93df5edc77d0, **_20bc7ddd8b04)
                if _51f455f4dbdf(_eaa97e1cf273, _effb2d0502aa._432098c93ca7):
                    _eaa97e1cf273 = _eaa97e1cf273._9c22b2d3029d(_effb2d0502aa._6ff29276e45b)
                    _eaa97e1cf273._21bc7c33ee6d(self._5b3ff3fc5aaa, self._a358bcfcee66)
                    _eaa97e1cf273 = _effb2d0502aa._4bcb66829f12(_eaa97e1cf273)
                return _eaa97e1cf273
            except _395ea8367b5d as _2a81597229bb:
                raise _b4a5d0f7913f(f"Forward pass failed in {self._45daa96c5ff2._c04de71ba43c.__name__}: {_f2886d8dff98(_2a81597229bb)}")

    def _3e3ab4485816(
        self,
        _42729244dc7a: _effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2,
        _5afd3b837a91: _56584f733d4c[_f2886d8dff98],
        _1a8467b235df: _c206dc789dd6,
        _fbc11569d483: _f2886d8dff98,
        _e4eb4f6543a3: _effb2d0502aa._432098c93ca7,
        _2a93522566e8: _f57952c8b841,
        _ec29d502ac4e: _8aaf69883c2a,
        _2e2389e1e874: _f2886d8dff98,
        _d1958238b52d: _8aaf69883c2a,
        _05067b0f4fa7: _f2886d8dff98,
        _2aefdcc872c9: _13f059273cf2,
        _61e0507ad909: _13f059273cf2,
        _8325ef334f7a: _6638af90098a,
        _2cb179c3ca16: _8aaf69883c2a = 20,
        _3a6ad696b51e: _a88d0e489242[_f2886d8dff98] = _59f90d54f6ef,
        _4c53d5d6ede2: _a88d0e489242[_8aaf69883c2a] = _59f90d54f6ef,
        _a1745e9adf69: _c206dc789dd6 = 0.0,
        _ab1a48e53cc8: _f2886d8dff98 = _59f90d54f6ef
    ):
        """
        Initialize the language identification classifier.

        Args:
            pretrained_embedding_model (torch.nn.Module): Pretrained transformer model.
            class_names (List[str]): List of class names.
            lr (float): Learning rate.
            optimizer (str): Optimizer name (adamw, adamax, adam).
            class_weights (torch.Tensor): Class weights for loss computation.
            device_dict (Dict): Device configuration.
            num_backbone_model_units_unfrozen (int): Number of backbone layers to unfreeze.
            loss_type (str): Type of loss function.
            num_fc_layers (int): Number of fully connected layers.
            activation_function_for_layer (str): Activation function for FC layers.
            add_dropout_after_embedding (bool): Whether to add dropout after embedding.
            is_train (bool): Training mode flag.
            tokenizer (object): Tokenizer instance.
            random_seed (int): Random seed for reproducibility.
            pretrained_model_embedding_name (Optional[str]): Name of pretrained embedding model.
            trial_number (Optional[int]): Trial number for experiment tracking.
            decision_threshold (float): Threshold for unknown class detection.
            model_config_name (Optional[str]): model_config_name to create hold metrics in dir

        Raises:
            ValueError: If invalid parameters are provided.
        """
        if not _5afd3b837a91:
            raise _ba2bf025b59c("class_names cannot be empty")
        if _d1958238b52d < 1:
            raise _ba2bf025b59c("num_fc_layers must be at least 1")
        if _42729244dc7a is _59f90d54f6ef:
            raise _ba2bf025b59c("pretrained_embedding_model cannot be None")
        if _8325ef334f7a is _59f90d54f6ef:
            raise _ba2bf025b59c("tokenizer cannot be None")
        
        _a96b6506ada9()._ffbe87b45cfc()
        self._6b127103c55b({
            "lr": _c206dc789dd6(_1a8467b235df),
            "optimizer": _f2886d8dff98(_fbc11569d483),
            "num_backbone_model_units_unfrozen": _8aaf69883c2a(_ec29d502ac4e),
            "loss_type": _f2886d8dff98(_2e2389e1e874),
            "num_fc_layers": _8aaf69883c2a(_d1958238b52d),
            "activation_function_for_layer": _f2886d8dff98(_05067b0f4fa7),
            "add_dropout_after_embedding": _13f059273cf2(_2aefdcc872c9),
            "is_train": _13f059273cf2(_61e0507ad909),
            "random_seed": _8aaf69883c2a(_2cb179c3ca16),
        })
        
        self._2cb179c3ca16 = _2cb179c3ca16
        _e2b9de59569f._daedf0a96a07(_2cb179c3ca16, _2a803b76863e=_00af90ed2be9)
        _effb2d0502aa._5a69c55ca286(_2cb179c3ca16)
        if _effb2d0502aa._359038a79392._167c9e2b7227():
            _effb2d0502aa._359038a79392._b7ca46337e76(_2cb179c3ca16)
        _bf3a979581d6.random._9f9b6f1dd0e1(_2cb179c3ca16)
        
        self._4c53d5d6ede2 = _8aaf69883c2a(_4c53d5d6ede2) if _4c53d5d6ede2 is not _59f90d54f6ef else _59f90d54f6ef
        self._8325ef334f7a = _8325ef334f7a
        self._c60d51a7ffad = (
            _effb2d0502aa._7fc363cb1e17(f"cuda:{_2a93522566e8['gpu_local_rank']}") if _2a93522566e8._66544238defc("gpu_local_rank", -1) != -1 else "cpu"
        )
        self._ab1a48e53cc8 = _ab1a48e53cc8
        self._3a6ad696b51e = _3a6ad696b51e
        # self.num_classes = len(class_names)
        self._a1745e9adf69 = _a1745e9adf69
        self._5afd3b837a91 = ["unk"] + _5afd3b837a91 if _a1745e9adf69 > 0 else _5afd3b837a91
        self._2e7f95139797 = _dc2a39c075c4(self._5afd3b837a91)
        self._e4eb4f6543a3 = _e4eb4f6543a3
        self._0aadf23a90a7 = "multiclass"
        self._46a5c65b346d = -100
        self._a3734eda7da8 = {}
        self._5168494e4fe2 = {}
        
        self._4e0b2fc621ab = _42729244dc7a
        # self.embedding.requires_grad_(False).to(self.curr_device)
        self._4e0b2fc621ab._f94772cebcd5(_625b066368b1)
        _b2ff998e8eb1 = _449684af1ffd()  # bfloat16 or float16
        for _9311099a99af, _45daa96c5ff2 in self._da0ab4aae094():
            if not _d52f720a99ad(_75978cbb5238._a39efe640400 for _75978cbb5238 in _45daa96c5ff2._010b8718ab47(_14a84abd9a32=_625b066368b1)):
                # FROZEN → BF16 (save memory)
                _45daa96c5ff2._9c22b2d3029d(_543679ac4eaf=_b2ff998e8eb1)
            else:
                # TRAINABLE → FP32 (stable grads)
                _45daa96c5ff2._9c22b2d3029d(_543679ac4eaf=_effb2d0502aa._6ff29276e45b)
        self._4e0b2fc621ab._9c22b2d3029d(self._c60d51a7ffad)
        if _1c4cdc43d6f9(self._4e0b2fc621ab, "gradient_checkpointing_enable"):
            self._4e0b2fc621ab._b6b514dd7f2f()
        # determine embedding dim robustly from model config if available
        _772a7c326844 = _001b2615eac9(_001b2615eac9(self._4e0b2fc621ab, "config", _59f90d54f6ef), "hidden_size", _59f90d54f6ef)
        if _772a7c326844 is _59f90d54f6ef:
            # fallback to common default — change if your model uses a different hidden size
            _772a7c326844 = 768

        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._eeaf6a7910eb = self._5b90cb71c62c(_0ab175d4f958=_772a7c326844, _9a63c96fe8a4=64)
        for _75978cbb5238 in self._eeaf6a7910eb._010b8718ab47():
            _75978cbb5238._a39efe640400 = _00af90ed2be9

        self._d1958238b52d = _d1958238b52d
        self._05067b0f4fa7 = _05067b0f4fa7
        self._ec29d502ac4e = _ec29d502ac4e
        
        if _ec29d502ac4e > 0:
            for _68c735bcce70 in self._4e0b2fc621ab._11be0c420a89._010b8718ab47():
                _68c735bcce70._a39efe640400 = _00af90ed2be9
            if _ec29d502ac4e > 1:
                for _68c735bcce70 in self._4e0b2fc621ab._772a1caedc7b._5cfd56c5d968[-(_ec29d502ac4e-1):]._010b8718ab47():
                    _68c735bcce70._a39efe640400 = _00af90ed2be9
        
        self._2aefdcc872c9 = _2aefdcc872c9
        if _2aefdcc872c9:
            self._48bb46eede5a = _effb2d0502aa._e49d31a4c8f7._f54da2ffab8f(0.1, _9f83f21adc25=_625b066368b1)
        
        self._c32335431cdd()
        self._81f34d57023d(_2e2389e1e874)
        self._8adc282b9a3d = []
        self._378618190fdb = []
        self._6199612f594c = self._499a70d730f1._fbc11569d483._e6cf7a74696a()
        # self._setup_metrics()
        
        global _71419e992e14
        _71419e992e14 = _8fd4b8b0b0df(self._4e0b2fc621ab)._9abeb3d8517d()
        self._7bf2bcc75fe2(self._4e0b2fc621ab)
        self._39a9d8cbe198(self._c60d51a7ffad, _d1958238b52d)
        self._ae20fe4b79f7()

        self._b2c02839d72e = 0.99
        self._10b8655c0ca2 = 0.3
        self._00562ba0c4bc = 0.30
        self._37b8adb27c49 = 0.25
        self._9ee528392fa0 = 0.6
        self._987045111973 = 0.995
        self._c9395603e025 = 0.60
        self._0e1373123915 = 0.20

    def _b8d7097a43f3(self) -> _59f90d54f6ef:
        """
        Set up fully connected layers with optional activation functions.

        Raises:
            RuntimeError: If layer setup fails.
        """
        try:
            _13a8e3c2af94 = self._4e0b2fc621ab._f1f022d16388._3b99775b646a
            _52dcbc2e774e = self._2e7f95139797
            
            if self._d1958238b52d == 1:
                if self._05067b0f4fa7:
                    _300a89754c7f(self, f"fc_with_{self._05067b0f4fa7}_activation_1", _effb2d0502aa._e49d31a4c8f7._04c7e3416143(
                        _effb2d0502aa._e49d31a4c8f7._474a62749155(_13a8e3c2af94, _52dcbc2e774e),
                        _effb2d0502aa._e49d31a4c8f7._3aae87d116d0(_52dcbc2e774e),
                        self._9b1400b42942(self._05067b0f4fa7, _52dcbc2e774e)
                    ))
                else:
                    _300a89754c7f(self, "fc_1", _effb2d0502aa._e49d31a4c8f7._474a62749155(_13a8e3c2af94, _52dcbc2e774e))
            else:
                _cfa2b332741a = _13a8e3c2af94
                for _ee7fbe1a3c55 in _6bcb548ebe38(self._d1958238b52d):
                    _1c87d596540d = _52dcbc2e774e if _ee7fbe1a3c55 + 1 == self._d1958238b52d else _cfa2b332741a // 2
                    if self._05067b0f4fa7 and _ee7fbe1a3c55 + 1 < self._d1958238b52d:
                        _300a89754c7f(self, f"fc_with_{self._05067b0f4fa7}_activation_{_ee7fbe1a3c55+1}", _effb2d0502aa._e49d31a4c8f7._04c7e3416143(
                            _effb2d0502aa._e49d31a4c8f7._474a62749155(_cfa2b332741a, _1c87d596540d),
                            _effb2d0502aa._e49d31a4c8f7._3aae87d116d0(_1c87d596540d),
                            self._9b1400b42942(self._05067b0f4fa7, _1c87d596540d)
                        ))
                    else:
                        _300a89754c7f(self, f"fc_{_ee7fbe1a3c55+1}", _effb2d0502aa._e49d31a4c8f7._474a62749155(_cfa2b332741a, _1c87d596540d))
                    _cfa2b332741a = _1c87d596540d
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Failed to set up FC layers: {_f2886d8dff98(_2a81597229bb)}")

    def _9cb0aefc8b74(self, _2e2389e1e874: _f2886d8dff98) -> _59f90d54f6ef:
        """
        Initialize the loss function based on the specified type.

        Args:
            loss_type (str): Type of loss function.

        Raises:
            ValueError: If loss_type is unsupported.
        """
        _2e2389e1e874 = _2e2389e1e874._e6cf7a74696a()
        _3cf2628a6cb3 = {
            "class_weighted_cross_entropy_loss": _71aa06d90a81,
            "focal_loss": lambda: _1fb27876c842(_63fa388fb333=0.25, _7fc363cb1e17=self._c60d51a7ffad, _aed22da0f45d=self._46a5c65b346d),
            "class_weighted_focal_loss": lambda: _1fb27876c842(_63fa388fb333=self._e4eb4f6543a3, _7fc363cb1e17=self._c60d51a7ffad, _aed22da0f45d=self._46a5c65b346d),
            "class_weighted_focal_loss_with_adaptive_focus_type1": lambda: _396307122704(_63fa388fb333=self._e4eb4f6543a3, _ef9722f89a09='type1', _7fc363cb1e17=self._c60d51a7ffad, _aed22da0f45d=self._46a5c65b346d),
            "class_weighted_focal_loss_with_adaptive_focus_type2": lambda: _396307122704(_63fa388fb333=self._e4eb4f6543a3, _ef9722f89a09='type2', _7fc363cb1e17=self._c60d51a7ffad, _aed22da0f45d=self._46a5c65b346d),
            "class_weighted_focal_loss_with_adaptive_focus_type3": lambda: _396307122704(_63fa388fb333=self._e4eb4f6543a3, _ef9722f89a09='type3', _7fc363cb1e17=self._c60d51a7ffad, _aed22da0f45d=self._46a5c65b346d),
        }
        if _2e2389e1e874 not in _3cf2628a6cb3:
            raise _ba2bf025b59c(f"Unsupported loss_type: {_2e2389e1e874}")
        self._a3734eda7da8['criterion'] = _3cf2628a6cb3[_2e2389e1e874]()

    # def _setup_metrics(self) -> None:
    #     """
    #     Initialize metrics for evaluation.

    #     Raises:
    #         RuntimeError: If metric setup fails.
    #     """
    #     try:
    #         metrics_params = {
    #             "num_classes": self.num_classes,
    #             "task": self.classification_task,
    #             "ignore_index": self.ignore_idx
    #         }
    #         self.metrics['micro_accuracy'] = Accuracy(average="micro", **metrics_params).to("cpu")
    #         self.metrics['macro_accuracy'] = Accuracy(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_precision'] = Precision(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_recall'] = Recall(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_f1'] = F1Score(average="macro", **metrics_params).to("cpu")
    #         self.metrics['classwise_accuracy'] = Accuracy(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_precision'] = Precision(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_recall'] = Recall(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_f1'] = F1Score(average=None, **metrics_params).to("cpu")
    #         self.metrics['confmat'] = ConfusionMatrix(normalize=None, **metrics_params).to("cpu")
    #     except Exception as e:
    #         raise RuntimeError(f"Failed to set up metrics: {str(e)}")

    def _de66ec473e5c(self):
        # rebuild all metrics on the correct device
        self._5168494e4fe2['micro_accuracy'] = _57f36f1bd32a(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717="micro",
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['macro_accuracy'] = _57f36f1bd32a(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717="macro",
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['macro_precision'] = _d6c3ae82ac3b(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717="macro",
            _99b1df9e8208=self. _0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['macro_recall'] = _fcfb3fbd5032(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717="macro",
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['macro_f1'] = _8fd2fa67f4a3(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717="macro",
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['classwise_accuracy'] = _57f36f1bd32a(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717=_59f90d54f6ef,
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['classwise_precision'] = _d6c3ae82ac3b(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717=_59f90d54f6ef,
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['classwise_recall'] = _fcfb3fbd5032(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717=_59f90d54f6ef,
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['classwise_f1'] = _8fd2fa67f4a3(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _ecfb70822717=_59f90d54f6ef,
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

        self._5168494e4fe2['confmat'] = _bbd7d07630cf(
            _2e7f95139797=_dc2a39c075c4(self._5afd3b837a91),
            _99b1df9e8208=self._0aadf23a90a7,
            _aed22da0f45d=self._46a5c65b346d,
        )._9c22b2d3029d(self._c60d51a7ffad)

    def _8c8bb9160c27(self, _45daa96c5ff2: _effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2, _0376768a122a: _f2886d8dff98 = "") -> _59f90d54f6ef:
        """
        Recursively attach hooks to detect NaNs in forward pass.

        Args:
            module (torch.nn.Module): Module to attach hooks to.
            prefix (str): Prefix for module naming.

        Raises:
            RuntimeError: If hook registration fails.
        """
        try:
            for _9311099a99af, _0c83eec945f4 in _45daa96c5ff2._f4e40e67e8a3():
                _1e1213b10668 = f"{_0376768a122a}.{_9311099a99af}" if _0376768a122a else _9311099a99af
                def _9bba7b548ed8(_7b77b60660f9, _5c89c3bb2f15, _73909e2f257c):
                    if _51f455f4dbdf(_73909e2f257c, _effb2d0502aa._432098c93ca7) and _73909e2f257c._74eb3b82a547()._d52f720a99ad():
                        _68b2f4d199a1(f"NaN detected in {_1e1213b10668} ({_7b77b60660f9._c04de71ba43c.__name__}) (dtype={_73909e2f257c._543679ac4eaf})")
                _0c83eec945f4._bc46c7cbd969(_77570c072e6a)
                self._7bf2bcc75fe2(_0c83eec945f4, _1e1213b10668)
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Failed to register NaN hooks: {_f2886d8dff98(_2a81597229bb)}")

    def _5ec5602050a8(self, _45daa96c5ff2: _effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2) -> _13f059273cf2:
        """
        Check if a module has trainable parameters.

        Args:
            module (torch.nn.Module): Module to check.

        Returns:
            bool: True if module has trainable parameters.
        """
        return _d52f720a99ad(_75978cbb5238._a39efe640400 for _75978cbb5238 in _45daa96c5ff2._010b8718ab47())

    def _dea79091342b(self) -> _59f90d54f6ef:
        """
        Convert specific layers to float32 and wrap them for stability.

        Raises:
            RuntimeError: If layer wrapping fails.
        """
        try:
            _db8270ea62b8 = []
            for _9311099a99af, _45daa96c5ff2 in self._da0ab4aae094():
                if not self._5ec7cc9dca2a(_45daa96c5ff2):
                    continue
                _63d6c06eb59b = "norm" in _9311099a99af._c58970313cbe() or _51f455f4dbdf(_45daa96c5ff2, _effb2d0502aa._e49d31a4c8f7._3aae87d116d0)
                _21a32b423ceb = _d52f720a99ad(_425052097432 in _9311099a99af._c58970313cbe() for _425052097432 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"])
                _aadaa4593fa7 = "dropout" in _9311099a99af._c58970313cbe() or _51f455f4dbdf(_45daa96c5ff2, _effb2d0502aa._e49d31a4c8f7._f54da2ffab8f)
                _1c32aec305cd = "attention" in _9311099a99af._c58970313cbe()
                if _63d6c06eb59b:
                    _45daa96c5ff2._4b790835393b = 1e-5
                if _63d6c06eb59b or _21a32b423ceb or _1c32aec305cd:
                    _45daa96c5ff2._9c22b2d3029d(_effb2d0502aa._6ff29276e45b)
                    if not _51f455f4dbdf(_45daa96c5ff2, _4b578264091c._05e604afc268):
                        _db8270ea62b8._b965a8eeebe6((_9311099a99af, _4b578264091c._05e604afc268(_45daa96c5ff2)))
            for _9311099a99af, _050bdf2edfae in _db8270ea62b8:
                _5f7fe751f83d, _17d055b32160 = self._77e51c7fe3c1(_9311099a99af)
                if _5f7fe751f83d is not _59f90d54f6ef:
                    _300a89754c7f(_5f7fe751f83d, _17d055b32160, _050bdf2edfae)
                else:
                    raise _b4a5d0f7913f(f"Cannot find parent module for {_9311099a99af}")
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Failed to fix embedding layers: {_f2886d8dff98(_2a81597229bb)}")

    def _1758a07049b9(self, _d4d92c008933: _f2886d8dff98) -> _906d908ac8ed[_a88d0e489242[_effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2], _a88d0e489242[_f2886d8dff98]]:
        """
        Find parent module and attribute name for a given module path.

        Args:
            module_name (str): Full module path.

        Returns:
            Tuple[Optional[torch.nn.Module], Optional[str]]: Parent module and attribute name.

        Raises:
            RuntimeError: If module path is invalid.
        """
        try:
            _5b6b71476691 = _d4d92c008933._0e34d3345a04('.')
            _5f7fe751f83d = self
            for _169d3d42f88d in _5b6b71476691[:-1]:
                _5f7fe751f83d = _001b2615eac9(_5f7fe751f83d, _169d3d42f88d, _59f90d54f6ef)
                if _5f7fe751f83d is _59f90d54f6ef:
                    raise _b4a5d0f7913f(f"Invalid module path: {_d4d92c008933}")
            return _5f7fe751f83d, _5b6b71476691[-1]
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Failed to get parent and attribute for {_d4d92c008933}: {_f2886d8dff98(_2a81597229bb)}")

    def _de60aeda8de5(self, _bfe0aa80f82f: _f2886d8dff98, _b73c5414b70f: _8aaf69883c2a) -> _effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2:
        """
        Get activation function instance.

        Args:
            activation_function (str): Name of the activation function.
            num_parameters (int): Number of parameters for the activation.

        Returns:
            torch.nn.Module: Activation function instance.

        Raises:
            ValueError: If activation function is unsupported.
        """
        _bfe0aa80f82f = _bfe0aa80f82f._e6cf7a74696a()
        if _bfe0aa80f82f == "parametric_relu":
            return _effb2d0502aa._e49d31a4c8f7._9a121b21f1c3(_b73c5414b70f=1)
        elif _bfe0aa80f82f == "leaky_relu":
            return _effb2d0502aa._e49d31a4c8f7._d8dfdb474bd8(_9f83f21adc25=_625b066368b1)
        elif _bfe0aa80f82f == "relu":
            return _effb2d0502aa._e49d31a4c8f7._5cfe87e36bda(_9f83f21adc25=_625b066368b1)
        raise _ba2bf025b59c(f"Unsupported activation function: {_bfe0aa80f82f}")

    def _a10550398b82(self, _7fc363cb1e17: _effb2d0502aa._7fc363cb1e17, _d1958238b52d: _8aaf69883c2a) -> _59f90d54f6ef:
        """
        Initialize weights for fully connected layers.

        Args:
            device (torch.device): Device to initialize weights on.
            num_fc_layers (int): Number of fully connected layers.

        Raises:
            RuntimeError: If weight initialization fails.
        """
        try:
            def _933f3f20d87f(_864ff98915a3: _effb2d0502aa._e49d31a4c8f7._8f8a4d75c2e2) -> _59f90d54f6ef:
                if _1c4cdc43d6f9(_864ff98915a3, "weight") and _864ff98915a3._28a13f4340f4._0ab175d4f958() > 1:
                    _864ff98915a3._9c22b2d3029d(_7fc363cb1e17)
                    _effb2d0502aa._e49d31a4c8f7._c22e44b69c5d._9e7c8f391b54(_864ff98915a3._28a13f4340f4._8cf0299c03d5)
            _125f4d843cdb = [_5cfd56c5d968 for _9311099a99af, _5cfd56c5d968 in self._6fb1cd7b712e._d9a6be17bc89() if _9311099a99af._12141017163f("fc_")]
            if not _125f4d843cdb:
                raise _b4a5d0f7913f("No FC layers found for initialization")
            for _5cfd56c5d968 in _125f4d843cdb:
                _5cfd56c5d968._c25ec43cc6df(_1682647a4eca)
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Failed to initialize weights: {_f2886d8dff98(_2a81597229bb)}")

    def _db3a97f30af8(self, _d015af6f7c15: _effb2d0502aa._432098c93ca7) -> _906d908ac8ed[_effb2d0502aa._432098c93ca7, _effb2d0502aa._432098c93ca7, _effb2d0502aa._432098c93ca7]:
        try:
            _d015af6f7c15 = _d015af6f7c15._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
            _3880621a46b7 = (_d015af6f7c15 != self._8325ef334f7a._eb35287e04af)._4dea04cfa3e8()._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)

            _aca8fbc74684 = self._4e0b2fc621ab(_d015af6f7c15, _3880621a46b7)._cb66e9073d8c
            _aca8fbc74684 = self._eeaf6a7910eb(_aca8fbc74684)

            _bfd9d6c05327 = _effb2d0502aa._bdf670bbd62c(0.0, _7fc363cb1e17=self._c60d51a7ffad)
            _54b4c521e9ec = _effb2d0502aa._bdf670bbd62c(0.0, _7fc363cb1e17=self._c60d51a7ffad)

            # compute embedding-level distillation occasionally (same guard you had)
            if self._ec29d502ac4e > 0 and (_001b2615eac9(self, "trainer", _59f90d54f6ef) is not _59f90d54f6ef) and (self._5a5f887e6d1b._7854e830ea21 or self._5a5f887e6d1b._30015aca8308):
                with _effb2d0502aa._75fa2ef671da():
                    _cd710a96fdc9 = _71419e992e14(_d015af6f7c15, _3880621a46b7)._cb66e9073d8c
                _bfd9d6c05327, _54b4c521e9ec = self._bbf304e954ff(_aca8fbc74684, _cd710a96fdc9, self._c60d51a7ffad)

                # cache pooled reps and teacher_conf for the aux helper (detach to avoid graphs)
                def _3e32e3112586(_ca6f9f458fc3): return _ca6f9f458fc3._d63c27d2bd2c(_0ab175d4f958=1) if _ca6f9f458fc3._0ab175d4f958() == 3 else _ca6f9f458fc3
                _567583ac2ca1 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._9a2904b49e79(_caafae3ae5de(_aca8fbc74684), _75978cbb5238=2, _0ab175d4f958=-1, _4b790835393b=1e-6)
                _cd4de8d68a8c = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._9a2904b49e79(_caafae3ae5de(_cd710a96fdc9), _75978cbb5238=2, _0ab175d4f958=-1, _4b790835393b=1e-6)
                _79cb722f0119 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._b66b4db71caf(_567583ac2ca1, _cd4de8d68a8c, _0ab175d4f958=-1)  # [-1,1]
                _e3433e129c69 = _79cb722f0119._045d6032351e(_54375d103905=0.0)  # treat negatives as 0

                self._c1d422cbd64c = _567583ac2ca1._feed2da7ebaa()
                self._623294be78d6 = _cd4de8d68a8c._feed2da7ebaa()
                self._958763d37b93 = _e3433e129c69._feed2da7ebaa()

            _eaa97e1cf273 = self._48bb46eede5a(_aca8fbc74684) if self._2aefdcc872c9 else _aca8fbc74684
            for _ee7fbe1a3c55 in _6bcb548ebe38(self._d1958238b52d):
                _5cfd56c5d968 = _001b2615eac9(self, f"fc_with_{self._05067b0f4fa7}_activation_{_ee7fbe1a3c55+1}", _59f90d54f6ef) or _001b2615eac9(self, f"fc_{_ee7fbe1a3c55+1}")
                _eaa97e1cf273 = _5cfd56c5d968(_eaa97e1cf273)

            return _eaa97e1cf273, _bfd9d6c05327, _54b4c521e9ec

        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Forward pass failed: {_f2886d8dff98(_2a81597229bb)}")


    # def compute_kl_contrastive_loss(self, new_emb: torch.Tensor, old_emb: torch.Tensor, device: str) -> Tuple[torch.Tensor, torch.Tensor]:
    #     """
    #     Compute KL divergence and contrastive loss.

    #     Args:
    #         new_emb (torch.Tensor): New embeddings.
    #         old_emb (torch.Tensor): Old embeddings.
    #         device (str): Device to perform computations on.

    #     Returns:
    #         Tuple[torch.Tensor, torch.Tensor]: KL loss and contrastive loss.

    #     Raises:
    #         RuntimeError: If loss computation fails.
    #     """
    #     try:
    #         new_emb = new_emb.clamp(min=-30, max=30)
    #         old_emb = old_emb.clamp(min=-30, max=30)
    #         T = 2.0
    #         new_emb_log = torch.nn.functional.log_softmax(new_emb / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_emb / T, dim=-1)
    #         latent_dim = new_emb_log.shape[-1]
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / latent_dim
    #         contrastive_loss = 1 - torch.nn.functional.cosine_similarity(new_emb, old_emb, dim=-1).mean()
            
    #         del new_emb, old_emb
    #         if torch.cuda.is_available():
    #             torch.cuda.empty_cache()
    #         return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    #     except Exception as e:
    #         raise RuntimeError(f"KL/contrastive loss computation failed: {str(e)}")

    def _5feab0ed5711(self, _4455e718da87: _effb2d0502aa._432098c93ca7, _32dbe5b05e5b: _effb2d0502aa._432098c93ca7, _bc0482f122f6: _effb2d0502aa._432098c93ca7) -> _bf285c9ec296:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf (if available) for gating w.
        Returns dict with aux_term and diagnostics for logging.
        """
        _7fc363cb1e17 = _4455e718da87._7fc363cb1e17

        # 1) gating w using cached teacher_conf
        _e3433e129c69 = _001b2615eac9(self, "_last_teacher_conf", _59f90d54f6ef)
        if _e3433e129c69 is _59f90d54f6ef:
            _e3ac40f955e5 = 0.0
        else:
            _ba921da28369 = _c206dc789dd6(_001b2615eac9(self, "teacher_conf_tau", 0.6))
            _0774b1d26cc8 = (_e3433e129c69 >= _ba921da28369)._c206dc789dd6()
            _e3ac40f955e5 = _c206dc789dd6(_0774b1d26cc8._d63c27d2bd2c()._0aed325eab0c()._0b46f93c5f39()) if _0774b1d26cc8._42ac742edb82() > 0 else 0.0

        # apply gating to batch scalars
        _bfd9d6c05327 = _c206dc789dd6(_32dbe5b05e5b._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()) * _c206dc789dd6(_e3ac40f955e5)
        _54b4c521e9ec = _c206dc789dd6(_bc0482f122f6._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()) * _c206dc789dd6(_e3ac40f955e5)

        # 2) EMA autoscale (s(t))
        _d8d786660048 = _bfd9d6c05327 + _54b4c521e9ec
        _0fb9821c6278 = _c206dc789dd6(_4455e718da87._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39())

        if _001b2615eac9(self, "ema_task", _59f90d54f6ef) is _59f90d54f6ef:
            self._50dde55a6be6 = _0fb9821c6278
            self._2d5372e87b99 = _d8d786660048 + 1e-12
        else:
            _63fa388fb333 = _c206dc789dd6(_001b2615eac9(self, "ema_alpha", 0.99))
            self._50dde55a6be6 = _63fa388fb333 * _c206dc789dd6(self._50dde55a6be6) + (1.0 - _63fa388fb333) * _0fb9821c6278
            self._2d5372e87b99 = _63fa388fb333 * _c206dc789dd6(self._2d5372e87b99) + (1.0 - _63fa388fb333) * _d8d786660048

        _55b1a422e045 = _c206dc789dd6(_001b2615eac9(self, "distill_target_ratio", 0.3))
        _d8cd32e3efd7 = (_c206dc789dd6(self._50dde55a6be6) / (_c206dc789dd6(self._2d5372e87b99) + 1e-12)) * _55b1a422e045
        _aa3ff5d0c8ac = _c206dc789dd6(_d8cd32e3efd7)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _177e86c54d75 = _c206dc789dd6(_001b2615eac9(self._5a5f887e6d1b, "current_epoch", 0.0)) if _001b2615eac9(self, "trainer", _59f90d54f6ef) is not _59f90d54f6ef else 0.0
        _8532787a6ee7 = _c206dc789dd6(_bdbe859be58f(1, _001b2615eac9(self._5a5f887e6d1b, "max_epochs", 1))) if _001b2615eac9(self, "trainer", _59f90d54f6ef) is not _59f90d54f6ef else 1.0
        _e66e5e0dff65 = _54375d103905(_bdbe859be58f(_177e86c54d75 / _8532787a6ee7, 0.0), 1.0)

        _245156533de2 = _c206dc789dd6(_001b2615eac9(self, "kl_warmup_frac", 0.30))
        _a003989e1496 = _c206dc789dd6(_001b2615eac9(self, "kl_base", 0.30)) * _54375d103905(_e66e5e0dff65 / _245156533de2, 1.0)
        _37b8adb27c49 = _c206dc789dd6(_001b2615eac9(self, "cos_base", 0.25))
        _9f63634afa1d = _37b8adb27c49 + (0.10 - _37b8adb27c49) * _e66e5e0dff65

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _eb9936c31d27 = _c206dc789dd6(self._958763d37b93._d63c27d2bd2c()._0aed325eab0c()._0b46f93c5f39()) if _001b2615eac9(self, "_last_teacher_conf", _59f90d54f6ef) is not _59f90d54f6ef else 0.0
        if _001b2615eac9(self, "ema_teacher_conf", _59f90d54f6ef) is _59f90d54f6ef:
            self._a01c185a1f34 = _eb9936c31d27
        else:
            _0049ea6b4f92 = _c206dc789dd6(_001b2615eac9(self, "teacher_conf_beta", 0.995))
            self._a01c185a1f34 = _0049ea6b4f92 * _c206dc789dd6(self._a01c185a1f34) + (1.0 - _0049ea6b4f92) * _eb9936c31d27

        _c9395603e025 = _c206dc789dd6(_001b2615eac9(self, "tau_warn", 0.60))
        _0e1373123915 = _c206dc789dd6(_001b2615eac9(self, "tau_detect", 0.20))
        _51cb81d33b2e = _bdbe859be58f(1e-12, (_c9395603e025 - _0e1373123915))
        _a0b8a02e2e73 = (_c206dc789dd6(self._a01c185a1f34) - _0e1373123915) / _51cb81d33b2e
        _a0b8a02e2e73 = _bdbe859be58f(0.0, _54375d103905(1.0, _a0b8a02e2e73))

        _2bed09f280b2 = _a003989e1496 * _a0b8a02e2e73
        _e7abb8692d93 = _9f63634afa1d * _a0b8a02e2e73

        # 5) final aux term (as scalar tensor on device)
        _b8d923513574 = (_2bed09f280b2 * _bfd9d6c05327 + _e7abb8692d93 * _54b4c521e9ec) * _c206dc789dd6(_aa3ff5d0c8ac)
        _8a84099e0e7d = _effb2d0502aa._bdf670bbd62c(_b8d923513574, _7fc363cb1e17=_7fc363cb1e17, _543679ac4eaf=_effb2d0502aa._6ff29276e45b)

        # diagnostics
        _73909e2f257c = {
            "aux_term": _8a84099e0e7d,
            "kl_batch": _32dbe5b05e5b,
            "contrast_batch": _bc0482f122f6,
            "kl_loss_gated": _bfd9d6c05327,
            "contrastive_loss_gated": _54b4c521e9ec,
            "w_mean": _e3ac40f955e5,
            "aux_scale": _c206dc789dd6(_aa3ff5d0c8ac),
            "lambda_kl_eff": _c206dc789dd6(_2bed09f280b2),
            "lambda_cos_eff": _c206dc789dd6(_e7abb8692d93),
            "teacher_conf_mean": _c206dc789dd6(self._a01c185a1f34),
            "shift_r": _c206dc789dd6(_a0b8a02e2e73)
        }
        return _73909e2f257c


    def _4285e6e9d291(
        self,
        _84a0d60d04bd: _effb2d0502aa._432098c93ca7,
        _4b03928b27af: _effb2d0502aa._432098c93ca7,
        _7fc363cb1e17: _f2886d8dff98 = "cpu",
    ) -> _906d908ac8ed[_effb2d0502aa._432098c93ca7, _effb2d0502aa._432098c93ca7]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _59cd363ecd29 = 2.0
            # NaN/Inf guard
            _84a0d60d04bd = _84a0d60d04bd._045d6032351e(_54375d103905=-30, _bdbe859be58f=30)
            _4b03928b27af = _4b03928b27af._045d6032351e(_54375d103905=-30, _bdbe859be58f=30)

            # Move once if needed
            _9c72e81a4a29 = _effb2d0502aa._7fc363cb1e17(_7fc363cb1e17)
            if _84a0d60d04bd._7fc363cb1e17 != _9c72e81a4a29:
                _84a0d60d04bd = _84a0d60d04bd._9c22b2d3029d(_7fc363cb1e17=_9c72e81a4a29, _aea729ff861d=_00af90ed2be9, _543679ac4eaf=self._18a24211df56)
                _4b03928b27af = _4b03928b27af._9c22b2d3029d(_7fc363cb1e17=_9c72e81a4a29, _aea729ff861d=_00af90ed2be9, _543679ac4eaf=self._18a24211df56)

            _8874a04d8eb5 = _84a0d60d04bd._8a54f1ff6954(0)
            _772a7c326844 = _84a0d60d04bd._8a54f1ff6954(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _eb781a03d773 = (_8874a04d8eb5 * _772a7c326844) > 32_000_000

            if not _eb781a03d773 or _8874a04d8eb5 <= 8:
                # Direct computation
                _3d3800fb724d = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._77f270294813(_84a0d60d04bd / _59cd363ecd29, _0ab175d4f958=-1)
                _ba0759b38fde = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._8ce118ef1cbd(_4b03928b27af / _59cd363ecd29, _0ab175d4f958=-1)
                _bfd9d6c05327 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._30690e7338af(_3d3800fb724d, _ba0759b38fde, _6b8a61a92ce7="batchmean") * (_59cd363ecd29 * _59cd363ecd29)
                _54b4c521e9ec = 1 - _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._b66b4db71caf(_84a0d60d04bd, _4b03928b27af, _0ab175d4f958=-1)._d63c27d2bd2c()
                return _bfd9d6c05327, _54b4c521e9ec

            # Chunked mode for large inputs
            _d61e804880a2 = _bdbe859be58f(1, _8874a04d8eb5 // 8)
            _beddfc0898b8, _62f356b12e56 = [], []

            for _5cabb221ee81 in _6bcb548ebe38(0, _8874a04d8eb5, _d61e804880a2):
                _a267e25e89f7 = _84a0d60d04bd[_5cabb221ee81:_5cabb221ee81 + _d61e804880a2]
                _6826642bf80a = _4b03928b27af[_5cabb221ee81:_5cabb221ee81 + _d61e804880a2]

                _3d3800fb724d = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._77f270294813(_a267e25e89f7 / _59cd363ecd29, _0ab175d4f958=-1)
                _ba0759b38fde = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._8ce118ef1cbd(_6826642bf80a / _59cd363ecd29, _0ab175d4f958=-1)

                _a759d28fe1af = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._30690e7338af(_3d3800fb724d, _ba0759b38fde, _6b8a61a92ce7="batchmean") * (_59cd363ecd29 * _59cd363ecd29)
                _7c0c68023483 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._b66b4db71caf(_a267e25e89f7, _6826642bf80a, _0ab175d4f958=-1)._d63c27d2bd2c()
                _4dfd005a0832 = 1 - _7c0c68023483

                _beddfc0898b8._b965a8eeebe6(_a759d28fe1af)
                _62f356b12e56._b965a8eeebe6(_4dfd005a0832)

            _bfd9d6c05327 = _effb2d0502aa._6549a93357a9(_beddfc0898b8)._d63c27d2bd2c()
            _54b4c521e9ec = _effb2d0502aa._6549a93357a9(_62f356b12e56)._d63c27d2bd2c()
            return _bfd9d6c05327, _54b4c521e9ec

        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"KL/contrastive loss computation failed: {_f2886d8dff98(_2a81597229bb)}")


    def _1fbc6014a5cb(self, _982998fe2060: _f57952c8b841, _13178d7fb38e: _8aaf69883c2a) -> _effb2d0502aa._432098c93ca7:
        """
        Perform a training step.

        Args:
            batch (Dict): Batch containing input_ids and labels.
            batch_idx (int): Batch index.

        Returns:
            torch.Tensor: Combined loss.

        Raises:
            RuntimeError: If training step fails.
        """
        try:
            if "input_ids" not in _982998fe2060 or "labels" not in _982998fe2060:
                raise _b4a5d0f7913f("Batch missing input_ids or labels")
            _d015af6f7c15 = _982998fe2060["input_ids"]._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
            _37cf2e40de35 = _982998fe2060["labels"]._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
            _8874a04d8eb5 = _d015af6f7c15._8a54f1ff6954(0)

            _830e5610e240, _32dbe5b05e5b, _bc0482f122f6 = self(_d015af6f7c15)
            _830e5610e240 = _830e5610e240._cb5e8b41fe5f()._d97c606f10be(-1, _830e5610e240._281dc383df6a[-1])
            _142d9535e3ff = _37cf2e40de35._cb5e8b41fe5f()._d97c606f10be(-1)

            _4455e718da87 = self._a3734eda7da8['criterion'](_830e5610e240, _142d9535e3ff)
            _4455e718da87 = _effb2d0502aa._4bcb66829f12(_4455e718da87, _4f94527c830f=0.0, _ebff17fd1eff=0.0, _69b6ff975b4b=0.0)

            # compute aux using helper (this uses cached teacher_conf from forward)
            _515dd23546a9 = self._8b2ca526ba75(_4455e718da87, _32dbe5b05e5b, _bc0482f122f6)
            _8a84099e0e7d = _515dd23546a9["aux_term"]

            _7d080687e2f6 = _4455e718da87 + _8a84099e0e7d

            # logging (keeps fields to reconstruct equation)
            self._63c3d68722ee(
                {
                    "epoch": _c206dc789dd6(self._094e7adcee86),
                    "train_task_loss": _c206dc789dd6(_4455e718da87._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()),
                    "train_kl_batch": _c206dc789dd6(_515dd23546a9._66544238defc("kl_batch", 0.0)._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()) if _51f455f4dbdf(_515dd23546a9._66544238defc("kl_batch", _59f90d54f6ef), _effb2d0502aa._432098c93ca7) else _c206dc789dd6(_515dd23546a9._66544238defc("kl_batch", 0.0)),
                    "train_contrast_batch": _c206dc789dd6(_515dd23546a9._66544238defc("contrast_batch", 0.0)._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()) if _51f455f4dbdf(_515dd23546a9._66544238defc("contrast_batch", _59f90d54f6ef), _effb2d0502aa._432098c93ca7) else _c206dc789dd6(_515dd23546a9._66544238defc("contrast_batch", 0.0)),
                    "train_w_mean": _c206dc789dd6(_515dd23546a9._66544238defc("w_mean", 0.0)),
                    "train_aux_scale": _c206dc789dd6(_515dd23546a9._66544238defc("aux_scale", _515dd23546a9._66544238defc("aux_scale", 0.0))),
                    "train_lambda_kl_eff": _c206dc789dd6(_515dd23546a9._66544238defc("lambda_kl_eff", 0.0)),
                    "train_lambda_cos_eff": _c206dc789dd6(_515dd23546a9._66544238defc("lambda_cos_eff", 0.0)),
                    "train_shift_r": _c206dc789dd6(_515dd23546a9._66544238defc("shift_r", 0.0)),
                    "train_loss": _c206dc789dd6(_7d080687e2f6._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()),
                },
                _8874a04d8eb5=_8874a04d8eb5,
                _63e78aa92f4d=_625b066368b1,
                _a535eac2e953=_00af90ed2be9,
                _049c4171b655=_625b066368b1,
                _b5b003e409b4=_00af90ed2be9,
                _3df960743de5=_00af90ed2be9,
            )

            return _7d080687e2f6

        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Training step {_13178d7fb38e} failed: {_f2886d8dff98(_2a81597229bb)}")


    def _a2512eda8b5f(self) -> _59f90d54f6ef:
        """
        Handle end of training epoch.

        Raises:
            RuntimeError: If epoch end processing fails.
        """
        try:
            if _effb2d0502aa._359038a79392._167c9e2b7227():
                _effb2d0502aa._359038a79392._53dc03a15dc5()
            _a96b6506ada9()._9214979c2043()
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Training epoch end failed: {_f2886d8dff98(_2a81597229bb)}")

    def _44eb7bd0af0a(self, _982998fe2060: _f57952c8b841, _13178d7fb38e: _8aaf69883c2a) -> _f57952c8b841:
        """
        Perform a validation step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Validation outputs.

        Raises:
            RuntimeError: If validation step fails.
        """
        try:
            if "input_ids" not in _982998fe2060 or "labels" not in _982998fe2060:
                raise _b4a5d0f7913f("Batch missing input_ids or labels")
            _d015af6f7c15 = _982998fe2060["input_ids"]._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
            _37cf2e40de35 = _982998fe2060["labels"]._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
            _1e9aa794473c = _982998fe2060["lang_codes"]
            _d476a6e0261c = _982998fe2060["sample_ids"]
            _13cc6669c518 = _982998fe2060["chunk_ids"]
            _12d8cb249527 = _982998fe2060["word_positions"]
            _8874a04d8eb5 = _d015af6f7c15._8a54f1ff6954(0)

            _8ae401d24ed1, _32dbe5b05e5b, _bc0482f122f6 = self(_d015af6f7c15)
            _ea8cb2ff3b6e = _8ae401d24ed1._cb5e8b41fe5f()._d97c606f10be(-1, _8ae401d24ed1._281dc383df6a[-1])
            _bb767e98d033 = _37cf2e40de35._cb5e8b41fe5f()._d97c606f10be(-1)

            _4455e718da87 = self._a3734eda7da8['criterion'](_ea8cb2ff3b6e, _bb767e98d033)
            _4455e718da87 = _effb2d0502aa._4bcb66829f12(_4455e718da87)

            _515dd23546a9 = self._8b2ca526ba75(_4455e718da87, _32dbe5b05e5b, _bc0482f122f6)
            _8a84099e0e7d = _515dd23546a9["aux_term"]
            _7d080687e2f6 = _4455e718da87 + _8a84099e0e7d

            # logging
            self._63c3d68722ee(
                {
                    "val_kl_batch": _c206dc789dd6(_515dd23546a9._66544238defc("kl_batch", 0.0)._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()) if _51f455f4dbdf(_515dd23546a9._66544238defc("kl_batch", _59f90d54f6ef), _effb2d0502aa._432098c93ca7) else _c206dc789dd6(_515dd23546a9._66544238defc("kl_batch", 0.0)),
                    "val_contrast_batch": _c206dc789dd6(_515dd23546a9._66544238defc("contrast_batch", 0.0)._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()) if _51f455f4dbdf(_515dd23546a9._66544238defc("contrast_batch", _59f90d54f6ef), _effb2d0502aa._432098c93ca7) else _c206dc789dd6(_515dd23546a9._66544238defc("contrast_batch", 0.0)),
                    "val_task_loss": _c206dc789dd6(_4455e718da87._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()),
                    "val_aux_scale": _c206dc789dd6(_515dd23546a9._66544238defc("aux_scale", 0.0)),
                    "val_w_mean": _c206dc789dd6(_515dd23546a9._66544238defc("w_mean", 0.0)),
                    "val_lambda_kl_eff": _c206dc789dd6(_515dd23546a9._66544238defc("lambda_kl_eff", 0.0)),
                    "val_lambda_cos_eff": _c206dc789dd6(_515dd23546a9._66544238defc("lambda_cos_eff", 0.0)),
                    "val_shift_r": _c206dc789dd6(_515dd23546a9._66544238defc("shift_r", 0.0)),
                    "val_loss": _c206dc789dd6(_7d080687e2f6._feed2da7ebaa()._0aed325eab0c()._0b46f93c5f39()),
                },
                _8874a04d8eb5=_8874a04d8eb5,
                _63e78aa92f4d=_625b066368b1,
                _a535eac2e953=_00af90ed2be9,
                _049c4171b655=_625b066368b1,
                _b5b003e409b4=_00af90ed2be9,
                _3df960743de5=_00af90ed2be9,
            )

            # per-example preds/labels (preserve your decision_threshold logic)
            _49c7403e6856, _df2376fe0e37 = [], []
            for _5cabb221ee81 in _6bcb548ebe38(_8874a04d8eb5):
                _2a2365beecd5 = _8ae401d24ed1[_5cabb221ee81]
                _c192f20934bf = _37cf2e40de35[_5cabb221ee81]
                _71765dc6d009 = _c192f20934bf != self._46a5c65b346d
                _dce4fbfea53d = _2a2365beecd5[_71765dc6d009]
                _9fe02faa6d12 = _c192f20934bf[_71765dc6d009]

                if self._a1745e9adf69 > 0:
                    _b85547bbf0f4 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._8ce118ef1cbd(_dce4fbfea53d, _0ab175d4f958=-1)
                    _4751d7b0aab5, _724c2213b644 = _b85547bbf0f4._bdbe859be58f(_0ab175d4f958=-1)
                    _8a04302a084f = _4751d7b0aab5 < self._a1745e9adf69
                    _724c2213b644 = _724c2213b644._1dd0fe4b9f23() + 1
                    _724c2213b644[_8a04302a084f] = 0
                    _9fe02faa6d12 = _9fe02faa6d12._1dd0fe4b9f23() + 1
                    del _b85547bbf0f4, _4751d7b0aab5, _8a04302a084f
                else:
                    _724c2213b644 = _dce4fbfea53d._a88abfb1a643(_0ab175d4f958=-1)

                _49c7403e6856._b965a8eeebe6(_724c2213b644)
                _df2376fe0e37._b965a8eeebe6(_9fe02faa6d12)
                del _dce4fbfea53d

            _eaa97e1cf273 = {
                "lang_codes": _1e9aa794473c,
                "preds": _49c7403e6856,
                "labels": _df2376fe0e37,
                "sample_ids": _d476a6e0261c,
                "chunk_ids": _13cc6669c518,
                "word_positions": _12d8cb249527,
                "val_loss": _7d080687e2f6
            }
            self._8adc282b9a3d._b965a8eeebe6(_eaa97e1cf273)

            # cleanup
            del _d015af6f7c15, _37cf2e40de35, _8ae401d24ed1
            if _effb2d0502aa._359038a79392._167c9e2b7227():
                _effb2d0502aa._359038a79392._53dc03a15dc5()
            return _eaa97e1cf273

        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Validation step {_13178d7fb38e} failed: {_f2886d8dff98(_2a81597229bb)}")


    def _cdf7477b815f(self, _f707497ca5f2: _f57952c8b841, _858aa969ce49: _f2886d8dff98, _4c53d5d6ede2: _a88d0e489242[_8aaf69883c2a] = _59f90d54f6ef) -> _59f90d54f6ef:
        """
        Save metrics to a CSV file.

        Args:
            metrics_dict (Dict): Metrics to save.
            filename (str): Output filename.
            trial_number (Optional[int]): Trial number for directory.

        Raises:
            RuntimeError: If saving to CSV fails.
        """
        try:
            _f1f9801b8cf1 = os._e0b73d9878d3()
            _9afa9ef7cc69 = f"trial_{_4c53d5d6ede2}" if _4c53d5d6ede2 is not _59f90d54f6ef else "default"
            # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
            _b6ad3b44b63e = os._b3802bf11538._fca0fda52b5f(_f1f9801b8cf1, "metrics", self._ab1a48e53cc8, _9afa9ef7cc69)
            os._dc6231839a94(_b6ad3b44b63e, _62f6686c255a=_00af90ed2be9)
            _90012bc325d8 = os._b3802bf11538._fca0fda52b5f(_b6ad3b44b63e, _858aa969ce49)
            _ea75bf12790c = _e01ba5602f2c._b68d40b6f14b(_f707497ca5f2)
            _ea75bf12790c._717a2e290125(_90012bc325d8, _aad71d0e67a7=_625b066368b1)
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Failed to save metrics to {_858aa969ce49}: {_f2886d8dff98(_2a81597229bb)}")

    def _b78ec03e126b(self):
        # pick correct device for this rank
        if _effb2d0502aa._359038a79392._167c9e2b7227():
            if _effb2d0502aa._2c47805b053f._de0b144ffcb5():
                _93e332fbcdfc = _effb2d0502aa._2c47805b053f._f37b9650de95()
            else:
                _93e332fbcdfc = 0
            _effb2d0502aa._359038a79392._7256b878f48f(_93e332fbcdfc)
            self._c60d51a7ffad = _effb2d0502aa._7fc363cb1e17(f"cuda:{_93e332fbcdfc}")
        else:
            self._c60d51a7ffad = _effb2d0502aa._7fc363cb1e17("cpu")

        self._eb0b2589b4e6()

    def _d53560ee63a1(self) -> _59f90d54f6ef:
        """
        Handle end of validation epoch.

        Raises:
            RuntimeError: If validation epoch end processing fails.
        """
        try:
            if not self._8adc282b9a3d:
                _68b2f4d199a1("[on_validation_epoch_end] No validation outputs to process.")
                return
            
            _e5ea1e4ee314, _37cf2e40de35 = self._9aa5d35f8721(self._8adc282b9a3d)
            _7fc363cb1e17 = self._5168494e4fe2['micro_accuracy']._7fc363cb1e17
            _e5ea1e4ee314, _37cf2e40de35 = _e5ea1e4ee314._9c22b2d3029d(_7fc363cb1e17), _37cf2e40de35._9c22b2d3029d(_7fc363cb1e17)
            
            self._5168494e4fe2['micro_accuracy']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_accuracy']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_precision']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_recall']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_f1']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_accuracy']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_precision']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_recall']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_f1']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['confmat']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            
            _05a58e366f83 = self._5168494e4fe2['micro_accuracy']._c157e9ca664f()._0b46f93c5f39()
            _ded2c6c13315 = self._5168494e4fe2['macro_accuracy']._c157e9ca664f()._0b46f93c5f39()
            _652441d63444 = self._5168494e4fe2['macro_precision']._c157e9ca664f()._0b46f93c5f39()
            _2015ccad206d = self._5168494e4fe2['macro_recall']._c157e9ca664f()._0b46f93c5f39()
            _0bc26fa68171 = self._5168494e4fe2['macro_f1']._c157e9ca664f()._0b46f93c5f39()
            _47bc1f4f543f = self._5168494e4fe2['classwise_accuracy']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _3368af0c1b3b = self._5168494e4fe2['classwise_precision']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _c1a2025280aa = self._5168494e4fe2['classwise_recall']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _93ab05819488 = self._5168494e4fe2['classwise_f1']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _aa150809b7e5 = self._5168494e4fe2['confmat']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            
            self._c58049561cb9("val_accuracy", _ded2c6c13315, _3df960743de5=_00af90ed2be9)
            
            _f707497ca5f2 = {
                "epoch": [self._094e7adcee86],
                "class_names": [self._5afd3b837a91],
                "micro_accuracy": [_05a58e366f83],
                "macro_accuracy": [_ded2c6c13315],
                "macro_precision": [_652441d63444],
                "macro_recall": [_2015ccad206d],
                "macro_f1": [_0bc26fa68171],
                "classwise_accuracy": [_47bc1f4f543f._ecf81d0c3024()],
                "classwise_precision": [_3368af0c1b3b._ecf81d0c3024()],
                "classwise_recall": [_c1a2025280aa._ecf81d0c3024()],
                "classwise_f1": [_93ab05819488._ecf81d0c3024()],
                "confusion_matrix": [_aa150809b7e5._ecf81d0c3024()],
            }
            self._cd686c0533bb(_f707497ca5f2, f"val_epoch_{self._094e7adcee86}.csv", self._4c53d5d6ede2)
            
            self._5168494e4fe2['micro_accuracy']._84f5334c5c1c()
            self._5168494e4fe2['macro_accuracy']._84f5334c5c1c()
            self._5168494e4fe2['macro_precision']._84f5334c5c1c()
            self._5168494e4fe2['macro_recall']._84f5334c5c1c()
            self._5168494e4fe2['macro_f1']._84f5334c5c1c()
            self._5168494e4fe2['classwise_accuracy']._84f5334c5c1c()
            self._5168494e4fe2['classwise_precision']._84f5334c5c1c()
            self._5168494e4fe2['classwise_recall']._84f5334c5c1c()
            self._5168494e4fe2['classwise_f1']._84f5334c5c1c()
            self._5168494e4fe2['confmat']._84f5334c5c1c()
            self._8adc282b9a3d._74febc348e37()
            
            if _effb2d0502aa._359038a79392._167c9e2b7227():
                _effb2d0502aa._359038a79392._53dc03a15dc5()
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Validation epoch end failed: {_f2886d8dff98(_2a81597229bb)}")

    def _2e2cf20ff7d5(self, _830e5610e240: _56584f733d4c[_f57952c8b841]) -> _906d908ac8ed[_effb2d0502aa._432098c93ca7, _effb2d0502aa._432098c93ca7]:
        """
        Reconcile chunked predictions and labels.

        Args:
            outputs (List[Dict]): Validation/test outputs.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: Reconciled predictions and labels.

        Raises:
            RuntimeError: If reconciliation fails.
        """
        try:
            def _b86466d4e5cc(_ca6f9f458fc3):
                if _51f455f4dbdf(_ca6f9f458fc3, _effb2d0502aa._432098c93ca7):
                    return _ca6f9f458fc3._feed2da7ebaa()._0aed325eab0c()._249c76b1c784(-1)._ecf81d0c3024()
                if _51f455f4dbdf(_ca6f9f458fc3, _bf3a979581d6._070e2aa1fa21):
                    return _ca6f9f458fc3._249c76b1c784(-1)._ecf81d0c3024()
                if _51f455f4dbdf(_ca6f9f458fc3, (_f6b56dad570c, _b67da2ea0bfb)):
                    return _f6b56dad570c(_ca6f9f458fc3)
                return [_ca6f9f458fc3]
            
            _e48a7eb538d2, _afa661976b1f, _eb84746a2289 = [], [], []
            _b6d2cf0af05b = _d8622e52d8b4()
            _8dc1ed685d7e = _7ec522c0aff3(_f6b56dad570c)
            
            for _73909e2f257c in _830e5610e240:
                if not _70831df769f8(_06a625579b2c in _73909e2f257c for _06a625579b2c in ["sample_ids", "chunk_ids", "preds", "labels", "word_positions"]):
                    raise _b4a5d0f7913f("Output dictionary missing required keys")
                _d476a6e0261c = _73909e2f257c["sample_ids"]
                _13cc6669c518 = _73909e2f257c["chunk_ids"]
                _c2a435c45f27 = _73909e2f257c["preds"]
                _205019fe6936 = _73909e2f257c["labels"]
                _12d8cb249527 = _73909e2f257c["word_positions"]
                
                for _5cabb221ee81, _b6e62fbfee53 in _167e1d05f639(_d476a6e0261c):
                    _c6f9b77bddc0 = _8aaf69883c2a(_13cc6669c518[_5cabb221ee81])
                    if (_b6e62fbfee53, _c6f9b77bddc0) in _b6d2cf0af05b:
                        continue
                    _b6d2cf0af05b._b4e435c2ce29((_b6e62fbfee53, _c6f9b77bddc0))
                    _1d6a3635fff5 = _d51fb815ac7c(_c2a435c45f27[_5cabb221ee81])
                    _221fc0eb57d2 = _d51fb815ac7c(_205019fe6936[_5cabb221ee81])
                    _b7b46f6f1e37 = _d51fb815ac7c(_12d8cb249527[_5cabb221ee81])
                    
                    if not (_dc2a39c075c4(_b7b46f6f1e37) == _dc2a39c075c4(_1d6a3635fff5) == _dc2a39c075c4(_221fc0eb57d2)):
                        _68b2f4d199a1(
                            f"[WARN] mismatch sid={_b6e62fbfee53} cid={_c6f9b77bddc0}: "
                            f"pos={_dc2a39c075c4(_b7b46f6f1e37)} preds={_dc2a39c075c4(_1d6a3635fff5)} labels={_dc2a39c075c4(_221fc0eb57d2)}"
                        )
                        continue
                    
                    if _b6e62fbfee53 not in _eb84746a2289:
                        _eb84746a2289._b965a8eeebe6(_b6e62fbfee53)
                    _8dc1ed685d7e[_b6e62fbfee53]._b965a8eeebe6((_c6f9b77bddc0, _b7b46f6f1e37, _1d6a3635fff5, _221fc0eb57d2))
            
            for _b6e62fbfee53 in _eb84746a2289:
                _bafb6d0f7537 = _8dc1ed685d7e[_b6e62fbfee53]
                _bafb6d0f7537._94a5a46e7c2c(_06a625579b2c=lambda _ca6f9f458fc3: _ca6f9f458fc3[0])
                _915a5ea823a6 = _7ec522c0aff3(_f6b56dad570c)
                _1d4c342e7898 = _7ec522c0aff3(_f6b56dad570c)
                
                for _c6f9b77bddc0, _eb30d28cd993, _e5ea1e4ee314, _37cf2e40de35 in _bafb6d0f7537:
                    for _ff8ce1758b0c, _f74360643777, _b57f4f793b81 in _25fa26837d2f(_eb30d28cd993, _e5ea1e4ee314, _37cf2e40de35):
                        _915a5ea823a6[_8aaf69883c2a(_ff8ce1758b0c)]._b965a8eeebe6(_8aaf69883c2a(_f74360643777))
                        _1d4c342e7898[_8aaf69883c2a(_ff8ce1758b0c)]._b965a8eeebe6(_8aaf69883c2a(_b57f4f793b81))
                
                _6ccc56542363, _a1e570b496cc = [], []
                for _ff8ce1758b0c in _bd50ba1ac86e(_915a5ea823a6._72b3147f8e34()):
                    _f74360643777 = _231273736dcc(_915a5ea823a6[_ff8ce1758b0c])._bafc5f0c98af(1)[0][0]
                    _6ccc56542363._b965a8eeebe6(_f74360643777)
                    _b57f4f793b81 = _231273736dcc(_1d4c342e7898[_ff8ce1758b0c])._bafc5f0c98af(1)[0][0] if _ff8ce1758b0c in _1d4c342e7898 else -100
                    _a1e570b496cc._b965a8eeebe6(_b57f4f793b81)
                
                _e48a7eb538d2._b60c73fc85b8(_6ccc56542363)
                _afa661976b1f._b60c73fc85b8(_a1e570b496cc)
            
            return _effb2d0502aa._bdf670bbd62c(_e48a7eb538d2, _7fc363cb1e17="cpu"), _effb2d0502aa._bdf670bbd62c(_afa661976b1f, _7fc363cb1e17="cpu")
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Chunk reconciliation failed: {_f2886d8dff98(_2a81597229bb)}")

    def _c52c0b195033(self, _982998fe2060: _f57952c8b841, _13178d7fb38e: _8aaf69883c2a) -> _f57952c8b841:
        """
        Perform a test step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Test outputs.

        Raises:
            RuntimeError: If test step fails.
        """
        try:
            if "input_ids" not in _982998fe2060 or "labels" not in _982998fe2060:
                raise _b4a5d0f7913f("Batch missing input_ids or labels")
            with _effb2d0502aa._75fa2ef671da():
                _d015af6f7c15 = _982998fe2060["input_ids"]._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
                _37cf2e40de35 = _982998fe2060["labels"]._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
                _1e9aa794473c = _982998fe2060["lang_codes"]
                _d476a6e0261c = _982998fe2060["sample_ids"]
                _13cc6669c518 = _982998fe2060["chunk_ids"]
                _12d8cb249527 = _982998fe2060["word_positions"]
                _8874a04d8eb5 = _d015af6f7c15._8a54f1ff6954(0)

                _8ae401d24ed1, _32dbe5b05e5b, _bc0482f122f6 = self(_d015af6f7c15)

                _ea8cb2ff3b6e = _8ae401d24ed1._cb5e8b41fe5f()._d97c606f10be(-1, _8ae401d24ed1._281dc383df6a[-1])
                _bb767e98d033 = _37cf2e40de35._cb5e8b41fe5f()._d97c606f10be(-1)

                _49c7403e6856, _df2376fe0e37 = [], []
                for _5cabb221ee81 in _6bcb548ebe38(_8874a04d8eb5):
                    _2a2365beecd5 = _8ae401d24ed1[_5cabb221ee81]
                    _c192f20934bf = _37cf2e40de35[_5cabb221ee81]
                    _71765dc6d009 = _c192f20934bf != self._46a5c65b346d
                    _dce4fbfea53d = _2a2365beecd5[_71765dc6d009]
                    _9fe02faa6d12 = _c192f20934bf[_71765dc6d009]

                    if self._a1745e9adf69 > 0:
                        _b85547bbf0f4 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._8ce118ef1cbd(_dce4fbfea53d, _0ab175d4f958=-1)
                        _4751d7b0aab5, _724c2213b644 = _b85547bbf0f4._bdbe859be58f(_0ab175d4f958=-1)
                        _8a04302a084f = _4751d7b0aab5 < self._a1745e9adf69
                        _724c2213b644 = _724c2213b644._1dd0fe4b9f23() + 1
                        _724c2213b644[_8a04302a084f] = 0
                        _9fe02faa6d12 = _9fe02faa6d12._1dd0fe4b9f23() + 1
                        del _b85547bbf0f4, _4751d7b0aab5, _8a04302a084f
                    else:
                        _724c2213b644 = _dce4fbfea53d._a88abfb1a643(_0ab175d4f958=-1)

                    _49c7403e6856._b965a8eeebe6(_724c2213b644)
                    _df2376fe0e37._b965a8eeebe6(_9fe02faa6d12)
                    del _dce4fbfea53d

                _eaa97e1cf273 = {
                    "lang_codes": _1e9aa794473c,
                    "preds": _49c7403e6856,
                    "labels": _df2376fe0e37,
                    "sample_ids": _d476a6e0261c,
                    "chunk_ids": _13cc6669c518,
                    "word_positions": _12d8cb249527,
                }
                self._378618190fdb._b965a8eeebe6(_eaa97e1cf273)

                # cleanup
                del _d015af6f7c15, _37cf2e40de35, _8ae401d24ed1
                if _effb2d0502aa._359038a79392._167c9e2b7227():
                    _effb2d0502aa._359038a79392._53dc03a15dc5()
                return _eaa97e1cf273
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Test step {_13178d7fb38e} failed: {_f2886d8dff98(_2a81597229bb)}")

    def _6490d5ceca78(self):
        # pick correct device for this rank
        if _effb2d0502aa._359038a79392._167c9e2b7227():
            if _effb2d0502aa._2c47805b053f._de0b144ffcb5():
                _93e332fbcdfc = _effb2d0502aa._2c47805b053f._f37b9650de95()
            else:
                _93e332fbcdfc = 0
            _effb2d0502aa._359038a79392._7256b878f48f(_93e332fbcdfc)
            self._c60d51a7ffad = _effb2d0502aa._7fc363cb1e17(f"cuda:{_93e332fbcdfc}")
        else:
            self._c60d51a7ffad = _effb2d0502aa._7fc363cb1e17("cpu")

        self._eb0b2589b4e6()

    def _d2413d257ec7(self) -> _59f90d54f6ef:
        """
        Handle end of test epoch.

        Raises:
            RuntimeError: If test epoch end processing fails.
        """
        try:
            if not self._378618190fdb:
                _68b2f4d199a1("[on_test_epoch_end] No test outputs to process.")
                return
            
            _e5ea1e4ee314, _37cf2e40de35 = self._9aa5d35f8721(self._378618190fdb)
            _7fc363cb1e17 = self._5168494e4fe2['micro_accuracy']._7fc363cb1e17
            _e5ea1e4ee314, _37cf2e40de35 = _e5ea1e4ee314._9c22b2d3029d(_7fc363cb1e17), _37cf2e40de35._9c22b2d3029d(_7fc363cb1e17)
            
            self._5168494e4fe2['micro_accuracy']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_accuracy']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_precision']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_recall']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['macro_f1']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_accuracy']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_precision']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_recall']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['classwise_f1']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            self._5168494e4fe2['confmat']._68e1009eb174(_e5ea1e4ee314, _37cf2e40de35)
            
            _05a58e366f83 = self._5168494e4fe2['micro_accuracy']._c157e9ca664f()._0b46f93c5f39()
            _ded2c6c13315 = self._5168494e4fe2['macro_accuracy']._c157e9ca664f()._0b46f93c5f39()
            _652441d63444 = self._5168494e4fe2['macro_precision']._c157e9ca664f()._0b46f93c5f39()
            _2015ccad206d = self._5168494e4fe2['macro_recall']._c157e9ca664f()._0b46f93c5f39()
            _0bc26fa68171 = self._5168494e4fe2['macro_f1']._c157e9ca664f()._0b46f93c5f39()
            _47bc1f4f543f = self._5168494e4fe2['classwise_accuracy']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _3368af0c1b3b = self._5168494e4fe2['classwise_precision']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _c1a2025280aa = self._5168494e4fe2['classwise_recall']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _93ab05819488 = self._5168494e4fe2['classwise_f1']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            _aa150809b7e5 = self._5168494e4fe2['confmat']._c157e9ca664f()._0aed325eab0c()._f99954c79c46()
            
            self._c58049561cb9("test_accuracy", _ded2c6c13315, _3df960743de5=_00af90ed2be9)
            
            _f707497ca5f2 = {
                "class_names": [self._5afd3b837a91],
                "micro_accuracy": [_05a58e366f83],
                "macro_accuracy": [_ded2c6c13315],
                "macro_precision": [_652441d63444],
                "macro_recall": [_2015ccad206d],
                "macro_f1": [_0bc26fa68171],
                "classwise_accuracy": [_47bc1f4f543f._ecf81d0c3024()],
                "classwise_precision": [_3368af0c1b3b._ecf81d0c3024()],
                "classwise_recall": [_c1a2025280aa._ecf81d0c3024()],
                "classwise_f1": [_93ab05819488._ecf81d0c3024()],
                "confusion_matrix": [_aa150809b7e5._ecf81d0c3024()],
            }
            self._cd686c0533bb(_f707497ca5f2, "test_final.csv", self._4c53d5d6ede2)
            
            self._5168494e4fe2['micro_accuracy']._84f5334c5c1c()
            self._5168494e4fe2['macro_accuracy']._84f5334c5c1c()
            self._5168494e4fe2['macro_precision']._84f5334c5c1c()
            self._5168494e4fe2['macro_recall']._84f5334c5c1c()
            self._5168494e4fe2['macro_f1']._84f5334c5c1c()
            self._5168494e4fe2['classwise_accuracy']._84f5334c5c1c()
            self._5168494e4fe2['classwise_precision']._84f5334c5c1c()
            self._5168494e4fe2['classwise_recall']._84f5334c5c1c()
            self._5168494e4fe2['classwise_f1']._84f5334c5c1c()
            self._5168494e4fe2['confmat']._84f5334c5c1c()
            self._378618190fdb._74febc348e37()
            
            if _effb2d0502aa._359038a79392._167c9e2b7227():
                _effb2d0502aa._359038a79392._53dc03a15dc5()
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Test epoch end failed: {_f2886d8dff98(_2a81597229bb)}")

    def _8b7fe5fcf74e(self, _982998fe2060: _f57952c8b841, _13178d7fb38e: _8aaf69883c2a, _a2e762030392: _8aaf69883c2a = 0) -> _f57952c8b841:
        """
        Perform a prediction step.

        Args:
            batch (Dict): Batch containing input_ids.
            batch_idx (int): Batch index.
            dataloader_idx (int): Dataloader index.

        Returns:
            Dict: Predictions and probabilities.

        Raises:
            RuntimeError: If prediction step fails.
        """
        try:
            if not _982998fe2060 or not _51f455f4dbdf(_982998fe2060, (_f6b56dad570c, _b67da2ea0bfb)) or not _982998fe2060[0]:
                raise _b4a5d0f7913f("Invalid batch input for prediction")
            _d015af6f7c15 = _982998fe2060[0]._9c22b2d3029d(self._c60d51a7ffad, _aea729ff861d=_00af90ed2be9)
            _830e5610e240, _, _ = self(_d015af6f7c15)
            _830e5610e240 = _830e5610e240._cb5e8b41fe5f()._d97c606f10be(-1, _830e5610e240._281dc383df6a[-1])
            
            if self._a1745e9adf69 > 0:
                _b85547bbf0f4 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._8ce118ef1cbd(_830e5610e240, _0ab175d4f958=-1)
                _4751d7b0aab5, _f74360643777 = _b85547bbf0f4._bdbe859be58f(_0ab175d4f958=-1)
                _8a04302a084f = _4751d7b0aab5 < self._a1745e9adf69
                _13acf242bec5 = _f74360643777 + 1
                _13acf242bec5[_8a04302a084f] = 0
                _d36172232b6e = _effb2d0502aa._4e4c03ff5d9a(_830e5610e240._8a54f1ff6954(0), self._2e7f95139797 + 1, _7fc363cb1e17=_830e5610e240._7fc363cb1e17)
                _d36172232b6e[~_8a04302a084f, 1:] = _b85547bbf0f4[~_8a04302a084f]
                _d36172232b6e[_8a04302a084f, 0] = 1.0
            else:
                _b85547bbf0f4 = _effb2d0502aa._e49d31a4c8f7._c0898a1fdbf3._8ce118ef1cbd(_830e5610e240, _0ab175d4f958=-1)
                _13acf242bec5 = _b85547bbf0f4._a88abfb1a643(_0ab175d4f958=-1)
                _d36172232b6e = _b85547bbf0f4
            
            del _d015af6f7c15, _830e5610e240
            if _effb2d0502aa._359038a79392._167c9e2b7227():
                _effb2d0502aa._359038a79392._53dc03a15dc5()
            return {
                "predictions": _13acf242bec5._0aed325eab0c(),
                "probs": _d36172232b6e._0aed325eab0c()
            }
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Predict step {_13178d7fb38e} failed: {_f2886d8dff98(_2a81597229bb)}")

    def _c729dfcc875f(self, _fbc11569d483) -> _59f90d54f6ef:
        """
        Handle operations before optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If gradient clipping fails.
        """
        try:
            _effb2d0502aa._e49d31a4c8f7._46ed5769bc0a._0d22cc082214(self._010b8718ab47(), _a48399b6d43d=1.0)
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Gradient clipping failed: {_f2886d8dff98(_2a81597229bb)}")

    def _c851109bcec0(self, _fbc11569d483) -> _59f90d54f6ef:
        """
        Handle operations after optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If parameter clamping fails.
        """
        try:
            for _68c735bcce70 in self._010b8718ab47():
                if _68c735bcce70 is not _59f90d54f6ef:
                    _68c735bcce70._8cf0299c03d5._21bc7c33ee6d(-5, 5)
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Parameter clamping failed: {_f2886d8dff98(_2a81597229bb)}")

    def _35f3a5572f50(self) -> _c206dc789dd6:
        """
        Compute gradient norm.

        Returns:
            float: L2 gradient norm.

        Raises:
            RuntimeError: If gradient norm computation fails.
        """
        try:
            _d268606a0259 = 0
            for _68c735bcce70 in self._010b8718ab47():
                if _68c735bcce70._8ad4c84871df is not _59f90d54f6ef:
                    _e56dc2c6737c = _68c735bcce70._8ad4c84871df._feed2da7ebaa()._8cf0299c03d5._a3869f549713(2)
                    _d268606a0259 += _e56dc2c6737c._0b46f93c5f39() ** 2
            return _d268606a0259 ** 0.5
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Gradient norm computation failed: {_f2886d8dff98(_2a81597229bb)}")

    def _53f154ee2536(self) -> _f57952c8b841:
        """
        Configure optimizer and learning rate scheduler.

        Returns:
            Dict: Optimizer and scheduler configuration.

        Raises:
            RuntimeError: If optimizer configuration fails.
        """
        try:
            _c348fe618fa0 = _50e3b5ecca66(lambda _75978cbb5238: _75978cbb5238._a39efe640400, self._010b8718ab47())
            _e0e90b55e6a9 = {
                "adamw": _effb2d0502aa._32b079344db1._34986042a7f4,
                "adamax": _effb2d0502aa._32b079344db1._9aaa00b4bd61,
                "adam": _effb2d0502aa._32b079344db1._ca00cdf78340,
            }
            _484c2147bbbc = _e0e90b55e6a9._66544238defc(self._6199612f594c._c58970313cbe())
            if _484c2147bbbc is _59f90d54f6ef:
                raise _b4a5d0f7913f(f"Unsupported optimizer: {self._6199612f594c}")
            _fbc11569d483 = _484c2147bbbc(_c348fe618fa0, _1a8467b235df=self._499a70d730f1._1a8467b235df, _d19620f215fe=0.001)
            
            _4dda435323fa = self._5a5f887e6d1b._8532787a6ee7
            _1f4120505441 = math._c26bd14dd7a1(0.1 * _4dda435323fa)
            _e146101e48fb = _effb2d0502aa._32b079344db1._21b44192e094._1d7ad5af7930(_fbc11569d483, _a2a59c8028a3=lambda _177e86c54d75: (_177e86c54d75 + 1) / _1f4120505441)
            _d9f8b61c8081 = _effb2d0502aa._32b079344db1._21b44192e094._2e1daf42bef1(
                _fbc11569d483,
                _bd6c2229b94b=_bdbe859be58f(1, _4dda435323fa - _1f4120505441),
                _868cdf9985da=2,
                _ea82af41d478=1e-6
            )
            _21b44192e094 = _effb2d0502aa._32b079344db1._21b44192e094._97675e0e9803(
                _fbc11569d483,
                _1dd42ce3f9c6=[_e146101e48fb, _d9f8b61c8081],
                _ae37833d28a7=[_1f4120505441]
            )
            
            return {"optimizer": _fbc11569d483, "lr_scheduler": {"scheduler": _21b44192e094, "interval": "epoch", "monitor": "val_loss"}}
        except _395ea8367b5d as _2a81597229bb:
            raise _b4a5d0f7913f(f"Optimizer configuration failed: {_f2886d8dff98(_2a81597229bb)}")