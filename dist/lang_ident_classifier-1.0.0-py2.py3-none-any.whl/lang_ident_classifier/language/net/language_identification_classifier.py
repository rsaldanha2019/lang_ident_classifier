# -*- coding: utf-8 -*-
"""
Language Identification Classifier
Handles language identification using a transformer-based model with custom loss functions.
"""
import math
import os
from collections import _f43440b26940, _06b640faa123
from copy import _193b2237a5a3
from typing import _a849f9c0ef19, _abd44b492713, _f73669f51f57, _867b209dcb37
from _e29640b12cc0 import _b8ee05b876ec

import _abf60ee57564 as _bb182a5974de
import _b1e52b577f39 as _558256843c34
import _16ce4de4b7a1 as _97b9d7ee2e58
import _5b9363f5efd2
from _4fb4dd2b9deb import _0788e40fa1e8, _4cbf4234a739, _6edd4a1151b6, _08254612c41a, _03145083905b

from _b9a15aeb06fc._4d0d5724f8d3._4a6419e8f574._cd5c6897a0c4 import _f385e59ae954
from _b9a15aeb06fc._4d0d5724f8d3._9fe178db3167._aa9c15eb9daa import _7ca7688238b0
from _b9a15aeb06fc._4d0d5724f8d3._9fe178db3167._2c9465245e08 import _b620118ad382
from _b9a15aeb06fc._4d0d5724f8d3._9fe178db3167._129ca005e2f9 import _bd8e1f82dea8
from _b9a15aeb06fc._4d0d5724f8d3._9e63b43e1cc8._9f448b26dc5e import _917499b64474

# Only export the classifier as public API
_5c6c2ea09b7f = ["LanguageIdentificationClassifier"]

_0bfd5439b614 = 'cuda' if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75() else 'cpu'
_ee3b8822555e = _4e8b8387415a

class _2fda50f63d71(_bb182a5974de._9ea6b85a4ca0):
    """Classifier for language identification using a transformer-based model."""

    class _6585dd6070c0(_5b9363f5efd2._a701ad31d0c3._199728bd57a9):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _e59d40eed44f(self, _02449d00843c: _23f8a5c1449b, _d8d3634ee748: _23f8a5c1449b = 64):
            _d56cf4c12a0f()._c9e62a998f2b()
            self._75f80cddb639 = _5b9363f5efd2._a701ad31d0c3._fa1bff8f3033(_02449d00843c, _d8d3634ee748, _7323f4698347=_35c5a7889cac)
            self._7877bed8198b = _5b9363f5efd2._a701ad31d0c3._e3db76e3e570(_351a870024c2=_5ab71833f02e)
            self._b7045cd41497 = _5b9363f5efd2._a701ad31d0c3._fa1bff8f3033(_d8d3634ee748, _02449d00843c, _7323f4698347=_35c5a7889cac)
            # start adapter near-zero so initial behavior is identity
            _5b9363f5efd2._a701ad31d0c3._457ed79eabbf._a04989a94cc9(self._b7045cd41497._99ffd400db55)
            _5b9363f5efd2._a701ad31d0c3._457ed79eabbf._3374fa5f7f1c(self._75f80cddb639._99ffd400db55, _7675ad5dc9d4=math._5f9d594f8862(5))

        def _90423594d3c8(self, _623972d7c27a: _5b9363f5efd2._3a6b9ed98fbc) -> _5b9363f5efd2._3a6b9ed98fbc:
            # supports x shape (B, L, D) or (B, D)
            if _623972d7c27a._02449d00843c() == 2:
                _f5714cbf9016 = self._b7045cd41497(self._7877bed8198b(self._75f80cddb639(_623972d7c27a)))
                return _623972d7c27a + _f5714cbf9016
            _48763dcc051f, _02906ab5dfc2, _d808b59a08e2 = _623972d7c27a._3cbab77972c1
            _457128cd982c = _623972d7c27a._e16deb8f94ab(-1, _d808b59a08e2)                    # (B*L, D)
            _457128cd982c = self._b7045cd41497(self._7877bed8198b(self._75f80cddb639(_457128cd982c)))  # (B*L, D)
            _457128cd982c = _457128cd982c._e16deb8f94ab(_48763dcc051f, _02906ab5dfc2, _d808b59a08e2)
            return _623972d7c27a + _457128cd982c

    class _84c738d18bde(_5b9363f5efd2._a701ad31d0c3._199728bd57a9):
        """Wraps a module to ensure stable forward pass with clamping and NaN handling."""
        
        def _e59d40eed44f(self, _9a5ddf51a300: _5b9363f5efd2._a701ad31d0c3._199728bd57a9, _8280baa41fc9: _5f08c5a575e6 = -5.0, _06441705c0c9: _5f08c5a575e6 = 5.0):
            """
            Initialize the wrapper with a module and clamping bounds.

            Args:
                module (torch.nn.Module): Module to wrap.
                clamp_min (float): Minimum value for clamping.
                clamp_max (float): Maximum value for clamping.

            Raises:
                ValueError: If module is None or invalid.
            """
            if _9a5ddf51a300 is _4e8b8387415a:
                raise _64cdc164593c("Module cannot be None")
            _d56cf4c12a0f()._c9e62a998f2b()
            self._9a5ddf51a300 = _9a5ddf51a300
            self._8280baa41fc9 = _8280baa41fc9
            self._06441705c0c9 = _06441705c0c9

        def _90423594d3c8(self, *_a011c170c70f, **_824bad41153d) -> _5b9363f5efd2._3a6b9ed98fbc:
            """
            Forward pass with dtype conversion, clamping, and NaN handling.

            Args:
                *inputs: Input tensors or other arguments.
                **kwargs: Keyword arguments for the module.

            Returns:
                torch.Tensor: Processed output tensor.

            Raises:
                RuntimeError: If forward pass fails.
            """
            try:
                _a011c170c70f = _7f14b99618f1(
                    _600b8fed3e0c._829885f15bb8(_5b9363f5efd2._8d4db84729b7) if _b49d5a854a66(_600b8fed3e0c, _5b9363f5efd2._3a6b9ed98fbc) and _600b8fed3e0c._4556f41c6a85 != _5b9363f5efd2._8d4db84729b7 else _600b8fed3e0c
                    for _600b8fed3e0c in _a011c170c70f
                )
                _ec7d1d137806 = self._9a5ddf51a300(*_a011c170c70f, **_824bad41153d)
                if _b49d5a854a66(_ec7d1d137806, _5b9363f5efd2._3a6b9ed98fbc):
                    _ec7d1d137806 = _ec7d1d137806._829885f15bb8(_5b9363f5efd2._8d4db84729b7)
                    _ec7d1d137806._213ba12e8a9e(self._8280baa41fc9, self._06441705c0c9)
                    _ec7d1d137806 = _5b9363f5efd2._39fc936b027a(_ec7d1d137806)
                return _ec7d1d137806
            except _722dbb2c298f as _ca135ba4fa58:
                raise _9f65ca2b2575(f"Forward pass failed in {self._9a5ddf51a300._08d0ec0d98e2.__name__}: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _e59d40eed44f(
        self,
        _f071d1ff51ec: _5b9363f5efd2._a701ad31d0c3._199728bd57a9,
        _f612e1b537f9: _abd44b492713[_5dbbdadb3289],
        _0a859ac520c1: _5f08c5a575e6,
        _327279339662: _5dbbdadb3289,
        _7572f9917907: _5b9363f5efd2._3a6b9ed98fbc,
        _7cd339d06ff1: _a849f9c0ef19,
        _edcb5b0628ef: _23f8a5c1449b,
        _f76680241af8: _5dbbdadb3289,
        _c0dc04265ed4: _23f8a5c1449b,
        _bad45b309658: _5dbbdadb3289,
        _2863466db70d: _c4b760e130aa,
        _80be238a8c0d: _c4b760e130aa,
        _4e4fe4f14431: _7ce4d472ac46,
        _7004466064aa: _23f8a5c1449b = 20,
        _6ee85d1e89bb: _f73669f51f57[_5dbbdadb3289] = _4e8b8387415a,
        _2e7f4a3ee3b1: _f73669f51f57[_23f8a5c1449b] = _4e8b8387415a,
        _c04de7ca86b7: _5f08c5a575e6 = 0.0,
        _27dac0d00d06: _5dbbdadb3289 = _4e8b8387415a
    ):
        """
        Initialize the language identification classifier.

        Args:
            pretrained_embedding_model (torch.nn.Module): Pretrained transformer model.
            class_names (List[str]): List of class names.
            lr (float): Learning rate.
            optimizer (str): Optimizer name (adamw, adamax, adam).
            class_weights (torch.Tensor): Class weights for loss computation.
            device_dict (Dict): Device configuration.
            num_backbone_model_units_unfrozen (int): Number of backbone layers to unfreeze.
            loss_type (str): Type of loss function.
            num_fc_layers (int): Number of fully connected layers.
            activation_function_for_layer (str): Activation function for FC layers.
            add_dropout_after_embedding (bool): Whether to add dropout after embedding.
            is_train (bool): Training mode flag.
            tokenizer (object): Tokenizer instance.
            random_seed (int): Random seed for reproducibility.
            pretrained_model_embedding_name (Optional[str]): Name of pretrained embedding model.
            trial_number (Optional[int]): Trial number for experiment tracking.
            decision_threshold (float): Threshold for unknown class detection.
            model_config_name (Optional[str]): model_config_name to create hold metrics in dir

        Raises:
            ValueError: If invalid parameters are provided.
        """
        if not _f612e1b537f9:
            raise _64cdc164593c("class_names cannot be empty")
        if _c0dc04265ed4 < 1:
            raise _64cdc164593c("num_fc_layers must be at least 1")
        if _f071d1ff51ec is _4e8b8387415a:
            raise _64cdc164593c("pretrained_embedding_model cannot be None")
        if _4e4fe4f14431 is _4e8b8387415a:
            raise _64cdc164593c("tokenizer cannot be None")
        
        _d56cf4c12a0f()._c9e62a998f2b()
        self._83070fdf85b3({
            "lr": _5f08c5a575e6(_0a859ac520c1),
            "optimizer": _5dbbdadb3289(_327279339662),
            "num_backbone_model_units_unfrozen": _23f8a5c1449b(_edcb5b0628ef),
            "loss_type": _5dbbdadb3289(_f76680241af8),
            "num_fc_layers": _23f8a5c1449b(_c0dc04265ed4),
            "activation_function_for_layer": _5dbbdadb3289(_bad45b309658),
            "add_dropout_after_embedding": _c4b760e130aa(_2863466db70d),
            "is_train": _c4b760e130aa(_80be238a8c0d),
            "random_seed": _23f8a5c1449b(_7004466064aa),
        })
        
        self._7004466064aa = _7004466064aa
        _bb182a5974de._bcb1d2092258(_7004466064aa, _991b4018f150=_5ab71833f02e)
        _5b9363f5efd2._6c9f1576ac2e(_7004466064aa)
        if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
            _5b9363f5efd2._ad562bc7cc40._e32c01cd67f7(_7004466064aa)
        _558256843c34.random._68c2becd560a(_7004466064aa)
        
        self._2e7f4a3ee3b1 = _23f8a5c1449b(_2e7f4a3ee3b1) if _2e7f4a3ee3b1 is not _4e8b8387415a else _4e8b8387415a
        self._4e4fe4f14431 = _4e4fe4f14431
        self._abb8a295637d = (
            _5b9363f5efd2._17b405a77947(f"cuda:{_7cd339d06ff1['gpu_local_rank']}") if _7cd339d06ff1._1be95c7334a4("gpu_local_rank", -1) != -1 else "cpu"
        )
        self._27dac0d00d06 = _27dac0d00d06
        self._6ee85d1e89bb = _6ee85d1e89bb
        # self.num_classes = len(class_names)
        self._c04de7ca86b7 = _c04de7ca86b7
        self._f612e1b537f9 = ["unk"] + _f612e1b537f9 if _c04de7ca86b7 > 0 else _f612e1b537f9
        self._4ef82fe6d545 = _b235e0c360bd(self._f612e1b537f9)
        self._7572f9917907 = _7572f9917907
        self._e697d089cff2 = "multiclass"
        self._21a3a286caff = -100
        self._9823a93341fb = {}
        self._4f6bfb0afd14 = {}
        
        self._d790645efbc0 = _f071d1ff51ec
        # self.embedding.requires_grad_(False).to(self.curr_device)
        self._d790645efbc0._88da103e0995(_35c5a7889cac)
        _601ae37af404 = _917499b64474()  # bfloat16 or float16
        for _d8810f380120, _9a5ddf51a300 in self._5f8e3242fdc5():
            if not _d82d0d099ffc(_0c13493da9df._81a1fb02951b for _0c13493da9df in _9a5ddf51a300._8a77deb924e3(_3e86853277c0=_35c5a7889cac)):
                # FROZEN → BF16 (save memory)
                _9a5ddf51a300._829885f15bb8(_4556f41c6a85=_601ae37af404)
            else:
                # TRAINABLE → FP32 (stable grads)
                _9a5ddf51a300._829885f15bb8(_4556f41c6a85=_5b9363f5efd2._8d4db84729b7)
        self._d790645efbc0._829885f15bb8(self._abb8a295637d)
        if _e2687dd42561(self._d790645efbc0, "gradient_checkpointing_enable"):
            self._d790645efbc0._d61063d708c3()
        # determine embedding dim robustly from model config if available
        _5c78251c156d = _cdff328ede93(_cdff328ede93(self._d790645efbc0, "config", _4e8b8387415a), "hidden_size", _4e8b8387415a)
        if _5c78251c156d is _4e8b8387415a:
            # fallback to common default — change if your model uses a different hidden size
            _5c78251c156d = 768

        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._03aada4d6141 = self._ae26631aea3b(_02449d00843c=_5c78251c156d, _d8d3634ee748=64)
        for _0c13493da9df in self._03aada4d6141._8a77deb924e3():
            _0c13493da9df._81a1fb02951b = _5ab71833f02e

        self._c0dc04265ed4 = _c0dc04265ed4
        self._bad45b309658 = _bad45b309658
        self._edcb5b0628ef = _edcb5b0628ef
        
        if _edcb5b0628ef > 0:
            for _b043400234c8 in self._d790645efbc0._55bc26898143._8a77deb924e3():
                _b043400234c8._81a1fb02951b = _5ab71833f02e
            if _edcb5b0628ef > 1:
                for _b043400234c8 in self._d790645efbc0._b00b90a78136._c351b1b3f90f[-(_edcb5b0628ef-1):]._8a77deb924e3():
                    _b043400234c8._81a1fb02951b = _5ab71833f02e
        
        self._2863466db70d = _2863466db70d
        if _2863466db70d:
            self._a81778dc3956 = _5b9363f5efd2._a701ad31d0c3._b7719dfe9647(0.1, _351a870024c2=_35c5a7889cac)
        
        self._e9167c9a7bf3()
        self._5b1d34e62aaa(_f76680241af8)
        self._894bf5d90c55 = []
        self._6f57940509c3 = []
        self._1dd3c89179c6 = self._c28e2e455dd1._327279339662._794296c4770f()
        # self._setup_metrics()
        
        global _ee3b8822555e
        _ee3b8822555e = _193b2237a5a3(self._d790645efbc0)._7d115cb2df91()
        self._2b34705233fa(self._d790645efbc0)
        self._e0fc464ce7a8(self._abb8a295637d, _c0dc04265ed4)
        self._ad08a468ac64()

        self._ae5fa980f2f9 = 0.99
        self._ecf0406d2ddd = 0.3
        self._64c76939d508 = 0.30
        self._2180189275d5 = 0.25
        self._ec22f7eeeb0b = 0.6
        self._b536d295d038 = 0.995
        self._eb413e9625cf = 0.60
        self._b80969fc58a9 = 0.20

    def _5097cdffab74(self) -> _4e8b8387415a:
        """
        Set up fully connected layers with optional activation functions.

        Raises:
            RuntimeError: If layer setup fails.
        """
        try:
            _3f3e1b4a7f3a = self._d790645efbc0._ca3242014599._f62aba8b5ecf
            _145f6b714d5e = self._4ef82fe6d545
            
            if self._c0dc04265ed4 == 1:
                if self._bad45b309658:
                    _e2dca7fab7c7(self, f"fc_with_{self._bad45b309658}_activation_1", _5b9363f5efd2._a701ad31d0c3._d9fbf4e9a5fd(
                        _5b9363f5efd2._a701ad31d0c3._fa1bff8f3033(_3f3e1b4a7f3a, _145f6b714d5e),
                        _5b9363f5efd2._a701ad31d0c3._d425b41383d5(_145f6b714d5e),
                        self._84000011f05f(self._bad45b309658, _145f6b714d5e)
                    ))
                else:
                    _e2dca7fab7c7(self, "fc_1", _5b9363f5efd2._a701ad31d0c3._fa1bff8f3033(_3f3e1b4a7f3a, _145f6b714d5e))
            else:
                _9e1f51a942cc = _3f3e1b4a7f3a
                for _6ee24621f68d in _6689b309ab94(self._c0dc04265ed4):
                    _740af4ef6329 = _145f6b714d5e if _6ee24621f68d + 1 == self._c0dc04265ed4 else _9e1f51a942cc // 2
                    if self._bad45b309658 and _6ee24621f68d + 1 < self._c0dc04265ed4:
                        _e2dca7fab7c7(self, f"fc_with_{self._bad45b309658}_activation_{_6ee24621f68d+1}", _5b9363f5efd2._a701ad31d0c3._d9fbf4e9a5fd(
                            _5b9363f5efd2._a701ad31d0c3._fa1bff8f3033(_9e1f51a942cc, _740af4ef6329),
                            _5b9363f5efd2._a701ad31d0c3._d425b41383d5(_740af4ef6329),
                            self._84000011f05f(self._bad45b309658, _740af4ef6329)
                        ))
                    else:
                        _e2dca7fab7c7(self, f"fc_{_6ee24621f68d+1}", _5b9363f5efd2._a701ad31d0c3._fa1bff8f3033(_9e1f51a942cc, _740af4ef6329))
                    _9e1f51a942cc = _740af4ef6329
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Failed to set up FC layers: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _f96ee9c11a0c(self, _f76680241af8: _5dbbdadb3289) -> _4e8b8387415a:
        """
        Initialize the loss function based on the specified type.

        Args:
            loss_type (str): Type of loss function.

        Raises:
            ValueError: If loss_type is unsupported.
        """
        _f76680241af8 = _f76680241af8._794296c4770f()
        _281b7c93a454 = {
            "class_weighted_cross_entropy_loss": _7ca7688238b0,
            "focal_loss": lambda: _b620118ad382(_3db13daeafac=0.25, _17b405a77947=self._abb8a295637d, _dc8f575c2aea=self._21a3a286caff),
            "class_weighted_focal_loss": lambda: _b620118ad382(_3db13daeafac=self._7572f9917907, _17b405a77947=self._abb8a295637d, _dc8f575c2aea=self._21a3a286caff),
            "class_weighted_focal_loss_with_adaptive_focus_type1": lambda: _bd8e1f82dea8(_3db13daeafac=self._7572f9917907, _ba03b80f3371='type1', _17b405a77947=self._abb8a295637d, _dc8f575c2aea=self._21a3a286caff),
            "class_weighted_focal_loss_with_adaptive_focus_type2": lambda: _bd8e1f82dea8(_3db13daeafac=self._7572f9917907, _ba03b80f3371='type2', _17b405a77947=self._abb8a295637d, _dc8f575c2aea=self._21a3a286caff),
            "class_weighted_focal_loss_with_adaptive_focus_type3": lambda: _bd8e1f82dea8(_3db13daeafac=self._7572f9917907, _ba03b80f3371='type3', _17b405a77947=self._abb8a295637d, _dc8f575c2aea=self._21a3a286caff),
        }
        if _f76680241af8 not in _281b7c93a454:
            raise _64cdc164593c(f"Unsupported loss_type: {_f76680241af8}")
        self._9823a93341fb['criterion'] = _281b7c93a454[_f76680241af8]()

    # def _setup_metrics(self) -> None:
    #     """
    #     Initialize metrics for evaluation.

    #     Raises:
    #         RuntimeError: If metric setup fails.
    #     """
    #     try:
    #         metrics_params = {
    #             "num_classes": self.num_classes,
    #             "task": self.classification_task,
    #             "ignore_index": self.ignore_idx
    #         }
    #         self.metrics['micro_accuracy'] = Accuracy(average="micro", **metrics_params).to("cpu")
    #         self.metrics['macro_accuracy'] = Accuracy(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_precision'] = Precision(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_recall'] = Recall(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_f1'] = F1Score(average="macro", **metrics_params).to("cpu")
    #         self.metrics['classwise_accuracy'] = Accuracy(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_precision'] = Precision(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_recall'] = Recall(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_f1'] = F1Score(average=None, **metrics_params).to("cpu")
    #         self.metrics['confmat'] = ConfusionMatrix(normalize=None, **metrics_params).to("cpu")
    #     except Exception as e:
    #         raise RuntimeError(f"Failed to set up metrics: {str(e)}")

    def _92528bccef1e(self):
        # rebuild all metrics on the correct device
        self._4f6bfb0afd14['micro_accuracy'] = _0788e40fa1e8(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05="micro",
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['macro_accuracy'] = _0788e40fa1e8(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05="macro",
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['macro_precision'] = _08254612c41a(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05="macro",
            _11479f2bed98=self. _e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['macro_recall'] = _03145083905b(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05="macro",
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['macro_f1'] = _6edd4a1151b6(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05="macro",
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['classwise_accuracy'] = _0788e40fa1e8(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05=_4e8b8387415a,
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['classwise_precision'] = _08254612c41a(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05=_4e8b8387415a,
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['classwise_recall'] = _03145083905b(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05=_4e8b8387415a,
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['classwise_f1'] = _6edd4a1151b6(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _f7133fe81f05=_4e8b8387415a,
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

        self._4f6bfb0afd14['confmat'] = _4cbf4234a739(
            _4ef82fe6d545=_b235e0c360bd(self._f612e1b537f9),
            _11479f2bed98=self._e697d089cff2,
            _dc8f575c2aea=self._21a3a286caff,
        )._829885f15bb8(self._abb8a295637d)

    def _70cb987c2336(self, _9a5ddf51a300: _5b9363f5efd2._a701ad31d0c3._199728bd57a9, _9769b0a7b072: _5dbbdadb3289 = "") -> _4e8b8387415a:
        """
        Recursively attach hooks to detect NaNs in forward pass.

        Args:
            module (torch.nn.Module): Module to attach hooks to.
            prefix (str): Prefix for module naming.

        Raises:
            RuntimeError: If hook registration fails.
        """
        try:
            for _d8810f380120, _5d6a873a73ec in _9a5ddf51a300._247d484188e7():
                _0be2457a4a35 = f"{_9769b0a7b072}.{_d8810f380120}" if _9769b0a7b072 else _d8810f380120
                def _6983835ef1ba(_9326a1c1c1bf, _600b8fed3e0c, _f5714cbf9016):
                    if _b49d5a854a66(_f5714cbf9016, _5b9363f5efd2._3a6b9ed98fbc) and _f5714cbf9016._bcb2442395dc()._d82d0d099ffc():
                        _b23c1983b039(f"NaN detected in {_0be2457a4a35} ({_9326a1c1c1bf._08d0ec0d98e2.__name__}) (dtype={_f5714cbf9016._4556f41c6a85})")
                _5d6a873a73ec._f9381b248c92(_6be5352b5908)
                self._2b34705233fa(_5d6a873a73ec, _0be2457a4a35)
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Failed to register NaN hooks: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _505964013655(self, _9a5ddf51a300: _5b9363f5efd2._a701ad31d0c3._199728bd57a9) -> _c4b760e130aa:
        """
        Check if a module has trainable parameters.

        Args:
            module (torch.nn.Module): Module to check.

        Returns:
            bool: True if module has trainable parameters.
        """
        return _d82d0d099ffc(_0c13493da9df._81a1fb02951b for _0c13493da9df in _9a5ddf51a300._8a77deb924e3())

    def _4d6a813e6cd0(self) -> _4e8b8387415a:
        """
        Convert specific layers to float32 and wrap them for stability.

        Raises:
            RuntimeError: If layer wrapping fails.
        """
        try:
            _61f68d87e06c = []
            for _d8810f380120, _9a5ddf51a300 in self._5f8e3242fdc5():
                if not self._6caac64b6958(_9a5ddf51a300):
                    continue
                _0f7bf2676bcd = "norm" in _d8810f380120._c17da237573d() or _b49d5a854a66(_9a5ddf51a300, _5b9363f5efd2._a701ad31d0c3._d425b41383d5)
                _b673e6ddb442 = _d82d0d099ffc(_7877bed8198b in _d8810f380120._c17da237573d() for _7877bed8198b in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"])
                _de74b940a02f = "dropout" in _d8810f380120._c17da237573d() or _b49d5a854a66(_9a5ddf51a300, _5b9363f5efd2._a701ad31d0c3._b7719dfe9647)
                _079221c0cffc = "attention" in _d8810f380120._c17da237573d()
                if _0f7bf2676bcd:
                    _9a5ddf51a300._fa631053a2c8 = 1e-5
                if _0f7bf2676bcd or _b673e6ddb442 or _079221c0cffc:
                    _9a5ddf51a300._829885f15bb8(_5b9363f5efd2._8d4db84729b7)
                    if not _b49d5a854a66(_9a5ddf51a300, _bbe725ac30e8._480b832d2106):
                        _61f68d87e06c._662319d234e1((_d8810f380120, _bbe725ac30e8._480b832d2106(_9a5ddf51a300)))
            for _d8810f380120, _a8f1ea104d3c in _61f68d87e06c:
                _b1d288d6eca5, _208f490e51c4 = self._c568e7172008(_d8810f380120)
                if _b1d288d6eca5 is not _4e8b8387415a:
                    _e2dca7fab7c7(_b1d288d6eca5, _208f490e51c4, _a8f1ea104d3c)
                else:
                    raise _9f65ca2b2575(f"Cannot find parent module for {_d8810f380120}")
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Failed to fix embedding layers: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _0bceac4ea660(self, _a4fd43f605b3: _5dbbdadb3289) -> _867b209dcb37[_f73669f51f57[_5b9363f5efd2._a701ad31d0c3._199728bd57a9], _f73669f51f57[_5dbbdadb3289]]:
        """
        Find parent module and attribute name for a given module path.

        Args:
            module_name (str): Full module path.

        Returns:
            Tuple[Optional[torch.nn.Module], Optional[str]]: Parent module and attribute name.

        Raises:
            RuntimeError: If module path is invalid.
        """
        try:
            _3e8c7e36798c = _a4fd43f605b3._5219665bebf8('.')
            _b1d288d6eca5 = self
            for _aa325d886e10 in _3e8c7e36798c[:-1]:
                _b1d288d6eca5 = _cdff328ede93(_b1d288d6eca5, _aa325d886e10, _4e8b8387415a)
                if _b1d288d6eca5 is _4e8b8387415a:
                    raise _9f65ca2b2575(f"Invalid module path: {_a4fd43f605b3}")
            return _b1d288d6eca5, _3e8c7e36798c[-1]
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Failed to get parent and attribute for {_a4fd43f605b3}: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _b7fce9c37174(self, _8530f04ff355: _5dbbdadb3289, _8bd1ccb79c61: _23f8a5c1449b) -> _5b9363f5efd2._a701ad31d0c3._199728bd57a9:
        """
        Get activation function instance.

        Args:
            activation_function (str): Name of the activation function.
            num_parameters (int): Number of parameters for the activation.

        Returns:
            torch.nn.Module: Activation function instance.

        Raises:
            ValueError: If activation function is unsupported.
        """
        _8530f04ff355 = _8530f04ff355._794296c4770f()
        if _8530f04ff355 == "parametric_relu":
            return _5b9363f5efd2._a701ad31d0c3._cc9f83138081(_8bd1ccb79c61=1)
        elif _8530f04ff355 == "leaky_relu":
            return _5b9363f5efd2._a701ad31d0c3._3a46b24e3fa9(_351a870024c2=_35c5a7889cac)
        elif _8530f04ff355 == "relu":
            return _5b9363f5efd2._a701ad31d0c3._e3db76e3e570(_351a870024c2=_35c5a7889cac)
        raise _64cdc164593c(f"Unsupported activation function: {_8530f04ff355}")

    def _81a61040bdfd(self, _17b405a77947: _5b9363f5efd2._17b405a77947, _c0dc04265ed4: _23f8a5c1449b) -> _4e8b8387415a:
        """
        Initialize weights for fully connected layers.

        Args:
            device (torch.device): Device to initialize weights on.
            num_fc_layers (int): Number of fully connected layers.

        Raises:
            RuntimeError: If weight initialization fails.
        """
        try:
            def _d9b854aae1d7(_542ecf8e3009: _5b9363f5efd2._a701ad31d0c3._199728bd57a9) -> _4e8b8387415a:
                if _e2687dd42561(_542ecf8e3009, "weight") and _542ecf8e3009._99ffd400db55._02449d00843c() > 1:
                    _542ecf8e3009._829885f15bb8(_17b405a77947)
                    _5b9363f5efd2._a701ad31d0c3._457ed79eabbf._93c77f74e7b7(_542ecf8e3009._99ffd400db55._37b925af1a92)
            _39129c11f885 = [_c351b1b3f90f for _d8810f380120, _c351b1b3f90f in self._9fd4d281a3ac._2904b063fe9c() if _d8810f380120._89a869d2b428("fc_")]
            if not _39129c11f885:
                raise _9f65ca2b2575("No FC layers found for initialization")
            for _c351b1b3f90f in _39129c11f885:
                _c351b1b3f90f._beb9504338f5(_21c98f30c1ef)
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Failed to initialize weights: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _90423594d3c8(self, _25e2e425f0a7: _5b9363f5efd2._3a6b9ed98fbc) -> _867b209dcb37[_5b9363f5efd2._3a6b9ed98fbc, _5b9363f5efd2._3a6b9ed98fbc, _5b9363f5efd2._3a6b9ed98fbc]:
        try:
            _25e2e425f0a7 = _25e2e425f0a7._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
            _51a6cb96f85e = (_25e2e425f0a7 != self._4e4fe4f14431._09c2c0d59378)._9d4331b2455e()._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)

            _5891a01461a6 = self._d790645efbc0(_25e2e425f0a7, _51a6cb96f85e)._81bd8bceb1d2
            _5891a01461a6 = self._03aada4d6141(_5891a01461a6)

            _5535627d7d12 = _5b9363f5efd2._cd0730554c1c(0.0, _17b405a77947=self._abb8a295637d)
            _982bf76e28b2 = _5b9363f5efd2._cd0730554c1c(0.0, _17b405a77947=self._abb8a295637d)

            # compute embedding-level distillation occasionally (same guard you had)
            if self._edcb5b0628ef > 0 and (_cdff328ede93(self, "trainer", _4e8b8387415a) is not _4e8b8387415a) and (self._ca78c0470cfe._c96c9ae0b247 or self._ca78c0470cfe._841b0d59d199):
                with _5b9363f5efd2._58516bdd66bf():
                    _ff7d3b66b5b0 = _ee3b8822555e(_25e2e425f0a7, _51a6cb96f85e)._81bd8bceb1d2
                _5535627d7d12, _982bf76e28b2 = self._f622a793dc17(_5891a01461a6, _ff7d3b66b5b0, self._abb8a295637d)

                # cache pooled reps and teacher_conf for the aux helper (detach to avoid graphs)
                def _783cf3530461(_623972d7c27a): return _623972d7c27a._0f47c8595d2c(_02449d00843c=1) if _623972d7c27a._02449d00843c() == 3 else _623972d7c27a
                _29aeda2d6410 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._03da7392ef46(_1133cb982098(_5891a01461a6), _0c13493da9df=2, _02449d00843c=-1, _fa631053a2c8=1e-6)
                _5ce22fca6f97 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._03da7392ef46(_1133cb982098(_ff7d3b66b5b0), _0c13493da9df=2, _02449d00843c=-1, _fa631053a2c8=1e-6)
                _9d0b3efd0bc4 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._e3ed365cf59b(_29aeda2d6410, _5ce22fca6f97, _02449d00843c=-1)  # [-1,1]
                _2c43bafd47d1 = _9d0b3efd0bc4._d725f486582d(_98fdab66c44c=0.0)  # treat negatives as 0

                self._26ea21b511af = _29aeda2d6410._daf944e6c776()
                self._95af0d595ce8 = _5ce22fca6f97._daf944e6c776()
                self._82281e7339a5 = _2c43bafd47d1._daf944e6c776()

            _ec7d1d137806 = self._a81778dc3956(_5891a01461a6) if self._2863466db70d else _5891a01461a6
            for _6ee24621f68d in _6689b309ab94(self._c0dc04265ed4):
                _c351b1b3f90f = _cdff328ede93(self, f"fc_with_{self._bad45b309658}_activation_{_6ee24621f68d+1}", _4e8b8387415a) or _cdff328ede93(self, f"fc_{_6ee24621f68d+1}")
                _ec7d1d137806 = _c351b1b3f90f(_ec7d1d137806)

            return _ec7d1d137806, _5535627d7d12, _982bf76e28b2

        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Forward pass failed: {_5dbbdadb3289(_ca135ba4fa58)}")


    # def compute_kl_contrastive_loss(self, new_emb: torch.Tensor, old_emb: torch.Tensor, device: str) -> Tuple[torch.Tensor, torch.Tensor]:
    #     """
    #     Compute KL divergence and contrastive loss.

    #     Args:
    #         new_emb (torch.Tensor): New embeddings.
    #         old_emb (torch.Tensor): Old embeddings.
    #         device (str): Device to perform computations on.

    #     Returns:
    #         Tuple[torch.Tensor, torch.Tensor]: KL loss and contrastive loss.

    #     Raises:
    #         RuntimeError: If loss computation fails.
    #     """
    #     try:
    #         new_emb = new_emb.clamp(min=-30, max=30)
    #         old_emb = old_emb.clamp(min=-30, max=30)
    #         T = 2.0
    #         new_emb_log = torch.nn.functional.log_softmax(new_emb / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_emb / T, dim=-1)
    #         latent_dim = new_emb_log.shape[-1]
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / latent_dim
    #         contrastive_loss = 1 - torch.nn.functional.cosine_similarity(new_emb, old_emb, dim=-1).mean()
            
    #         del new_emb, old_emb
    #         if torch.cuda.is_available():
    #             torch.cuda.empty_cache()
    #         return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    #     except Exception as e:
    #         raise RuntimeError(f"KL/contrastive loss computation failed: {str(e)}")

    def _acda35c12603(self, _e161364d7d1c: _5b9363f5efd2._3a6b9ed98fbc, _e430ab72cd09: _5b9363f5efd2._3a6b9ed98fbc, _6b17bfd9f0f3: _5b9363f5efd2._3a6b9ed98fbc) -> _392d3075a79c:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf (if available) for gating w.
        Returns dict with aux_term and diagnostics for logging.
        """
        _17b405a77947 = _e161364d7d1c._17b405a77947

        # 1) gating w using cached teacher_conf
        _2c43bafd47d1 = _cdff328ede93(self, "_last_teacher_conf", _4e8b8387415a)
        if _2c43bafd47d1 is _4e8b8387415a:
            _dc039b86f5c1 = 0.0
        else:
            _2ac7b82b48f0 = _5f08c5a575e6(_cdff328ede93(self, "teacher_conf_tau", 0.6))
            _804625eaa4a4 = (_2c43bafd47d1 >= _2ac7b82b48f0)._5f08c5a575e6()
            _dc039b86f5c1 = _5f08c5a575e6(_804625eaa4a4._0f47c8595d2c()._3f03981900cf()._affc8bfac33f()) if _804625eaa4a4._dc9316b89916() > 0 else 0.0

        # apply gating to batch scalars
        _5535627d7d12 = _5f08c5a575e6(_e430ab72cd09._daf944e6c776()._3f03981900cf()._affc8bfac33f()) * _5f08c5a575e6(_dc039b86f5c1)
        _982bf76e28b2 = _5f08c5a575e6(_6b17bfd9f0f3._daf944e6c776()._3f03981900cf()._affc8bfac33f()) * _5f08c5a575e6(_dc039b86f5c1)

        # 2) EMA autoscale (s(t))
        _23b08079f1cb = _5535627d7d12 + _982bf76e28b2
        _27626810970f = _5f08c5a575e6(_e161364d7d1c._daf944e6c776()._3f03981900cf()._affc8bfac33f())

        if _cdff328ede93(self, "ema_task", _4e8b8387415a) is _4e8b8387415a:
            self._830c8da722b5 = _27626810970f
            self._99d9372f35fd = _23b08079f1cb + 1e-12
        else:
            _3db13daeafac = _5f08c5a575e6(_cdff328ede93(self, "ema_alpha", 0.99))
            self._830c8da722b5 = _3db13daeafac * _5f08c5a575e6(self._830c8da722b5) + (1.0 - _3db13daeafac) * _27626810970f
            self._99d9372f35fd = _3db13daeafac * _5f08c5a575e6(self._99d9372f35fd) + (1.0 - _3db13daeafac) * _23b08079f1cb

        _7a4050705624 = _5f08c5a575e6(_cdff328ede93(self, "distill_target_ratio", 0.3))
        _3a9a6d4d97cd = (_5f08c5a575e6(self._830c8da722b5) / (_5f08c5a575e6(self._99d9372f35fd) + 1e-12)) * _7a4050705624
        _93b918c35fe7 = _5f08c5a575e6(_3a9a6d4d97cd)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _396cb083ee2f = _5f08c5a575e6(_cdff328ede93(self._ca78c0470cfe, "current_epoch", 0.0)) if _cdff328ede93(self, "trainer", _4e8b8387415a) is not _4e8b8387415a else 0.0
        _ea54edf0187e = _5f08c5a575e6(_5f367bc4303f(1, _cdff328ede93(self._ca78c0470cfe, "max_epochs", 1))) if _cdff328ede93(self, "trainer", _4e8b8387415a) is not _4e8b8387415a else 1.0
        _c818ce97c7b9 = _98fdab66c44c(_5f367bc4303f(_396cb083ee2f / _ea54edf0187e, 0.0), 1.0)

        _844f2f37fe55 = _5f08c5a575e6(_cdff328ede93(self, "kl_warmup_frac", 0.30))
        _cac52ef7f1a1 = _5f08c5a575e6(_cdff328ede93(self, "kl_base", 0.30)) * _98fdab66c44c(_c818ce97c7b9 / _844f2f37fe55, 1.0)
        _2180189275d5 = _5f08c5a575e6(_cdff328ede93(self, "cos_base", 0.25))
        _557f5a8c81d9 = _2180189275d5 + (0.10 - _2180189275d5) * _c818ce97c7b9

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _653667644549 = _5f08c5a575e6(self._82281e7339a5._0f47c8595d2c()._3f03981900cf()._affc8bfac33f()) if _cdff328ede93(self, "_last_teacher_conf", _4e8b8387415a) is not _4e8b8387415a else 0.0
        if _cdff328ede93(self, "ema_teacher_conf", _4e8b8387415a) is _4e8b8387415a:
            self._02de359ba324 = _653667644549
        else:
            _48763dcc051f = _5f08c5a575e6(_cdff328ede93(self, "teacher_conf_beta", 0.995))
            self._02de359ba324 = _48763dcc051f * _5f08c5a575e6(self._02de359ba324) + (1.0 - _48763dcc051f) * _653667644549

        _eb413e9625cf = _5f08c5a575e6(_cdff328ede93(self, "tau_warn", 0.60))
        _b80969fc58a9 = _5f08c5a575e6(_cdff328ede93(self, "tau_detect", 0.20))
        _461b22e9cdc1 = _5f367bc4303f(1e-12, (_eb413e9625cf - _b80969fc58a9))
        _f94d6ee37d1e = (_5f08c5a575e6(self._02de359ba324) - _b80969fc58a9) / _461b22e9cdc1
        _f94d6ee37d1e = _5f367bc4303f(0.0, _98fdab66c44c(1.0, _f94d6ee37d1e))

        _91ff18403b05 = _cac52ef7f1a1 * _f94d6ee37d1e
        _0d668367dc65 = _557f5a8c81d9 * _f94d6ee37d1e

        # 5) final aux term (as scalar tensor on device)
        _e930886c9005 = (_91ff18403b05 * _5535627d7d12 + _0d668367dc65 * _982bf76e28b2) * _5f08c5a575e6(_93b918c35fe7)
        _9ed83fd7fd51 = _5b9363f5efd2._cd0730554c1c(_e930886c9005, _17b405a77947=_17b405a77947, _4556f41c6a85=_5b9363f5efd2._8d4db84729b7)

        # diagnostics
        _f5714cbf9016 = {
            "aux_term": _9ed83fd7fd51,
            "kl_batch": _e430ab72cd09,
            "contrast_batch": _6b17bfd9f0f3,
            "kl_loss_gated": _5535627d7d12,
            "contrastive_loss_gated": _982bf76e28b2,
            "w_mean": _dc039b86f5c1,
            "aux_scale": _5f08c5a575e6(_93b918c35fe7),
            "lambda_kl_eff": _5f08c5a575e6(_91ff18403b05),
            "lambda_cos_eff": _5f08c5a575e6(_0d668367dc65),
            "teacher_conf_mean": _5f08c5a575e6(self._02de359ba324),
            "shift_r": _5f08c5a575e6(_f94d6ee37d1e)
        }
        return _f5714cbf9016


    def _72870518eaff(
        self,
        _e36244c6522b: _5b9363f5efd2._3a6b9ed98fbc,
        _b13379b13991: _5b9363f5efd2._3a6b9ed98fbc,
        _17b405a77947: _5dbbdadb3289 = "cpu",
    ) -> _867b209dcb37[_5b9363f5efd2._3a6b9ed98fbc, _5b9363f5efd2._3a6b9ed98fbc]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _160abfac3426 = 2.0
            # NaN/Inf guard
            _e36244c6522b = _e36244c6522b._d725f486582d(_98fdab66c44c=-30, _5f367bc4303f=30)
            _b13379b13991 = _b13379b13991._d725f486582d(_98fdab66c44c=-30, _5f367bc4303f=30)

            # Move once if needed
            _767d9a26dcf4 = _5b9363f5efd2._17b405a77947(_17b405a77947)
            if _e36244c6522b._17b405a77947 != _767d9a26dcf4:
                _e36244c6522b = _e36244c6522b._829885f15bb8(_17b405a77947=_767d9a26dcf4, _0302544c8f1d=_5ab71833f02e, _4556f41c6a85=self._cd4158fe88c0)
                _b13379b13991 = _b13379b13991._829885f15bb8(_17b405a77947=_767d9a26dcf4, _0302544c8f1d=_5ab71833f02e, _4556f41c6a85=self._cd4158fe88c0)

            _9d10a85b9ac2 = _e36244c6522b._6412747ef5cb(0)
            _5c78251c156d = _e36244c6522b._6412747ef5cb(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _73bbac4a53ce = (_9d10a85b9ac2 * _5c78251c156d) > 32_000_000

            if not _73bbac4a53ce or _9d10a85b9ac2 <= 8:
                # Direct computation
                _24ee32a4b2b2 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._001a509732fd(_e36244c6522b / _160abfac3426, _02449d00843c=-1)
                _0327dd1fea79 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._6ad24140fba2(_b13379b13991 / _160abfac3426, _02449d00843c=-1)
                _5535627d7d12 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._9ff822c9bdf9(_24ee32a4b2b2, _0327dd1fea79, _90510a74d05d="batchmean") * (_160abfac3426 * _160abfac3426)
                _982bf76e28b2 = 1 - _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._e3ed365cf59b(_e36244c6522b, _b13379b13991, _02449d00843c=-1)._0f47c8595d2c()
                return _5535627d7d12, _982bf76e28b2

            # Chunked mode for large inputs
            _a5ae61e11869 = _5f367bc4303f(1, _9d10a85b9ac2 // 8)
            _56d774ee87b0, _949cee3d2681 = [], []

            for _9d84c912c668 in _6689b309ab94(0, _9d10a85b9ac2, _a5ae61e11869):
                _9b77ab4c0af4 = _e36244c6522b[_9d84c912c668:_9d84c912c668 + _a5ae61e11869]
                _2ef8985aa1d4 = _b13379b13991[_9d84c912c668:_9d84c912c668 + _a5ae61e11869]

                _24ee32a4b2b2 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._001a509732fd(_9b77ab4c0af4 / _160abfac3426, _02449d00843c=-1)
                _0327dd1fea79 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._6ad24140fba2(_2ef8985aa1d4 / _160abfac3426, _02449d00843c=-1)

                _8d45aee7949c = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._9ff822c9bdf9(_24ee32a4b2b2, _0327dd1fea79, _90510a74d05d="batchmean") * (_160abfac3426 * _160abfac3426)
                _3fde459734e3 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._e3ed365cf59b(_9b77ab4c0af4, _2ef8985aa1d4, _02449d00843c=-1)._0f47c8595d2c()
                _853334e37285 = 1 - _3fde459734e3

                _56d774ee87b0._662319d234e1(_8d45aee7949c)
                _949cee3d2681._662319d234e1(_853334e37285)

            _5535627d7d12 = _5b9363f5efd2._358342873c45(_56d774ee87b0)._0f47c8595d2c()
            _982bf76e28b2 = _5b9363f5efd2._358342873c45(_949cee3d2681)._0f47c8595d2c()
            return _5535627d7d12, _982bf76e28b2

        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"KL/contrastive loss computation failed: {_5dbbdadb3289(_ca135ba4fa58)}")


    def _8a8fdbe86aac(self, _80cc938d6a53: _a849f9c0ef19, _30f87554ee23: _23f8a5c1449b) -> _5b9363f5efd2._3a6b9ed98fbc:
        """
        Perform a training step.

        Args:
            batch (Dict): Batch containing input_ids and labels.
            batch_idx (int): Batch index.

        Returns:
            torch.Tensor: Combined loss.

        Raises:
            RuntimeError: If training step fails.
        """
        try:
            if "input_ids" not in _80cc938d6a53 or "labels" not in _80cc938d6a53:
                raise _9f65ca2b2575("Batch missing input_ids or labels")
            _25e2e425f0a7 = _80cc938d6a53["input_ids"]._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
            _3edd7ac70561 = _80cc938d6a53["labels"]._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
            _9d10a85b9ac2 = _25e2e425f0a7._6412747ef5cb(0)

            _a7fcc664b002, _e430ab72cd09, _6b17bfd9f0f3 = self(_25e2e425f0a7)
            _a7fcc664b002 = _a7fcc664b002._9ef36f1d955c()._e16deb8f94ab(-1, _a7fcc664b002._3cbab77972c1[-1])
            _24af67e190f7 = _3edd7ac70561._9ef36f1d955c()._e16deb8f94ab(-1)

            _e161364d7d1c = self._9823a93341fb['criterion'](_a7fcc664b002, _24af67e190f7)
            _e161364d7d1c = _5b9363f5efd2._39fc936b027a(_e161364d7d1c, _54ce5721eab8=0.0, _ee731b4e02db=0.0, _2a3542de6255=0.0)

            # compute aux using helper (this uses cached teacher_conf from forward)
            _149e95f7a045 = self._56a28a3d8e95(_e161364d7d1c, _e430ab72cd09, _6b17bfd9f0f3)
            _9ed83fd7fd51 = _149e95f7a045["aux_term"]

            _c5a0a3ded738 = _e161364d7d1c + _9ed83fd7fd51

            # logging (keeps fields to reconstruct equation)
            self._8e26cf911cee(
                {
                    "epoch": _5f08c5a575e6(self._2e8074dcbdcf),
                    "train_task_loss": _5f08c5a575e6(_e161364d7d1c._daf944e6c776()._3f03981900cf()._affc8bfac33f()),
                    "train_kl_batch": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("kl_batch", 0.0)._daf944e6c776()._3f03981900cf()._affc8bfac33f()) if _b49d5a854a66(_149e95f7a045._1be95c7334a4("kl_batch", _4e8b8387415a), _5b9363f5efd2._3a6b9ed98fbc) else _5f08c5a575e6(_149e95f7a045._1be95c7334a4("kl_batch", 0.0)),
                    "train_contrast_batch": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("contrast_batch", 0.0)._daf944e6c776()._3f03981900cf()._affc8bfac33f()) if _b49d5a854a66(_149e95f7a045._1be95c7334a4("contrast_batch", _4e8b8387415a), _5b9363f5efd2._3a6b9ed98fbc) else _5f08c5a575e6(_149e95f7a045._1be95c7334a4("contrast_batch", 0.0)),
                    "train_w_mean": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("w_mean", 0.0)),
                    "train_aux_scale": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("aux_scale", _149e95f7a045._1be95c7334a4("aux_scale", 0.0))),
                    "train_lambda_kl_eff": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("lambda_kl_eff", 0.0)),
                    "train_lambda_cos_eff": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("lambda_cos_eff", 0.0)),
                    "train_shift_r": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("shift_r", 0.0)),
                    "train_loss": _5f08c5a575e6(_c5a0a3ded738._daf944e6c776()._3f03981900cf()._affc8bfac33f()),
                },
                _9d10a85b9ac2=_9d10a85b9ac2,
                _f1f486f7be79=_35c5a7889cac,
                _4beccbd21fa8=_5ab71833f02e,
                _943744714de5=_35c5a7889cac,
                _91f5609c50a5=_5ab71833f02e,
                _defd1da0568e=_5ab71833f02e,
            )

            return _c5a0a3ded738

        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Training step {_30f87554ee23} failed: {_5dbbdadb3289(_ca135ba4fa58)}")


    def _e8352005f916(self) -> _4e8b8387415a:
        """
        Handle end of training epoch.

        Raises:
            RuntimeError: If epoch end processing fails.
        """
        try:
            if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
                _5b9363f5efd2._ad562bc7cc40._6d379fa38926()
            _d56cf4c12a0f()._25171332aa2c()
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Training epoch end failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _738fda49bf4e(self, _80cc938d6a53: _a849f9c0ef19, _30f87554ee23: _23f8a5c1449b) -> _a849f9c0ef19:
        """
        Perform a validation step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Validation outputs.

        Raises:
            RuntimeError: If validation step fails.
        """
        try:
            if "input_ids" not in _80cc938d6a53 or "labels" not in _80cc938d6a53:
                raise _9f65ca2b2575("Batch missing input_ids or labels")
            _25e2e425f0a7 = _80cc938d6a53["input_ids"]._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
            _3edd7ac70561 = _80cc938d6a53["labels"]._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
            _49eb8e6d124d = _80cc938d6a53["lang_codes"]
            _ecf7a5aeb5ba = _80cc938d6a53["sample_ids"]
            _1545d018aaf3 = _80cc938d6a53["chunk_ids"]
            _7702057478cc = _80cc938d6a53["word_positions"]
            _9d10a85b9ac2 = _25e2e425f0a7._6412747ef5cb(0)

            _a9278a31e446, _e430ab72cd09, _6b17bfd9f0f3 = self(_25e2e425f0a7)
            _96115818f5d5 = _a9278a31e446._9ef36f1d955c()._e16deb8f94ab(-1, _a9278a31e446._3cbab77972c1[-1])
            _1df3baa96032 = _3edd7ac70561._9ef36f1d955c()._e16deb8f94ab(-1)

            _e161364d7d1c = self._9823a93341fb['criterion'](_96115818f5d5, _1df3baa96032)
            _e161364d7d1c = _5b9363f5efd2._39fc936b027a(_e161364d7d1c)

            _149e95f7a045 = self._56a28a3d8e95(_e161364d7d1c, _e430ab72cd09, _6b17bfd9f0f3)
            _9ed83fd7fd51 = _149e95f7a045["aux_term"]
            _c5a0a3ded738 = _e161364d7d1c + _9ed83fd7fd51

            # logging
            self._8e26cf911cee(
                {
                    "val_kl_batch": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("kl_batch", 0.0)._daf944e6c776()._3f03981900cf()._affc8bfac33f()) if _b49d5a854a66(_149e95f7a045._1be95c7334a4("kl_batch", _4e8b8387415a), _5b9363f5efd2._3a6b9ed98fbc) else _5f08c5a575e6(_149e95f7a045._1be95c7334a4("kl_batch", 0.0)),
                    "val_contrast_batch": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("contrast_batch", 0.0)._daf944e6c776()._3f03981900cf()._affc8bfac33f()) if _b49d5a854a66(_149e95f7a045._1be95c7334a4("contrast_batch", _4e8b8387415a), _5b9363f5efd2._3a6b9ed98fbc) else _5f08c5a575e6(_149e95f7a045._1be95c7334a4("contrast_batch", 0.0)),
                    "val_task_loss": _5f08c5a575e6(_e161364d7d1c._daf944e6c776()._3f03981900cf()._affc8bfac33f()),
                    "val_aux_scale": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("aux_scale", 0.0)),
                    "val_w_mean": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("w_mean", 0.0)),
                    "val_lambda_kl_eff": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("lambda_kl_eff", 0.0)),
                    "val_lambda_cos_eff": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("lambda_cos_eff", 0.0)),
                    "val_shift_r": _5f08c5a575e6(_149e95f7a045._1be95c7334a4("shift_r", 0.0)),
                    "val_loss": _5f08c5a575e6(_c5a0a3ded738._daf944e6c776()._3f03981900cf()._affc8bfac33f()),
                },
                _9d10a85b9ac2=_9d10a85b9ac2,
                _f1f486f7be79=_35c5a7889cac,
                _4beccbd21fa8=_5ab71833f02e,
                _943744714de5=_35c5a7889cac,
                _91f5609c50a5=_5ab71833f02e,
                _defd1da0568e=_5ab71833f02e,
            )

            # per-example preds/labels (preserve your decision_threshold logic)
            _477e6ae9c6a0, _155c835d3e43 = [], []
            for _9d84c912c668 in _6689b309ab94(_9d10a85b9ac2):
                _08e3b5b0a60b = _a9278a31e446[_9d84c912c668]
                _7aae2b95db35 = _3edd7ac70561[_9d84c912c668]
                _77e49876f71d = _7aae2b95db35 != self._21a3a286caff
                _941f352e58bd = _08e3b5b0a60b[_77e49876f71d]
                _343b62b6fc2b = _7aae2b95db35[_77e49876f71d]

                if self._c04de7ca86b7 > 0:
                    _07af703ef127 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._6ad24140fba2(_941f352e58bd, _02449d00843c=-1)
                    _896bf6b24817, _607c2ecbd62a = _07af703ef127._5f367bc4303f(_02449d00843c=-1)
                    _71b8d232c2f1 = _896bf6b24817 < self._c04de7ca86b7
                    _607c2ecbd62a = _607c2ecbd62a._d5e19bf223eb() + 1
                    _607c2ecbd62a[_71b8d232c2f1] = 0
                    _343b62b6fc2b = _343b62b6fc2b._d5e19bf223eb() + 1
                    del _07af703ef127, _896bf6b24817, _71b8d232c2f1
                else:
                    _607c2ecbd62a = _941f352e58bd._31c6bad1f247(_02449d00843c=-1)

                _477e6ae9c6a0._662319d234e1(_607c2ecbd62a)
                _155c835d3e43._662319d234e1(_343b62b6fc2b)
                del _941f352e58bd

            _ec7d1d137806 = {
                "lang_codes": _49eb8e6d124d,
                "preds": _477e6ae9c6a0,
                "labels": _155c835d3e43,
                "sample_ids": _ecf7a5aeb5ba,
                "chunk_ids": _1545d018aaf3,
                "word_positions": _7702057478cc,
                "val_loss": _c5a0a3ded738
            }
            self._894bf5d90c55._662319d234e1(_ec7d1d137806)

            # cleanup
            del _25e2e425f0a7, _3edd7ac70561, _a9278a31e446
            if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
                _5b9363f5efd2._ad562bc7cc40._6d379fa38926()
            return _ec7d1d137806

        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Validation step {_30f87554ee23} failed: {_5dbbdadb3289(_ca135ba4fa58)}")


    def _4904739e3c92(self, _48e796dfa86d: _a849f9c0ef19, _6ecdb96885d4: _5dbbdadb3289, _2e7f4a3ee3b1: _f73669f51f57[_23f8a5c1449b] = _4e8b8387415a) -> _4e8b8387415a:
        """
        Save metrics to a CSV file.

        Args:
            metrics_dict (Dict): Metrics to save.
            filename (str): Output filename.
            trial_number (Optional[int]): Trial number for directory.

        Raises:
            RuntimeError: If saving to CSV fails.
        """
        try:
            _353d49c0c133 = os._457de5712aab()
            _f5dd8cc0c388 = f"trial_{_2e7f4a3ee3b1}" if _2e7f4a3ee3b1 is not _4e8b8387415a else "default"
            # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
            _874f160c307d = os._74fc11279186._9032b04952b3(_353d49c0c133, "metrics", self._27dac0d00d06, _f5dd8cc0c388)
            os._c46245c740e8(_874f160c307d, _4e4d793e693f=_5ab71833f02e)
            _e8ffa7ccb1c9 = os._74fc11279186._9032b04952b3(_874f160c307d, _6ecdb96885d4)
            _32010009ff2d = _97b9d7ee2e58._50ef3eec7054(_48e796dfa86d)
            _32010009ff2d._a85f76ac6ce5(_e8ffa7ccb1c9, _af916ab662ba=_35c5a7889cac)
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Failed to save metrics to {_6ecdb96885d4}: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _fad52bfa4ff9(self):
        # pick correct device for this rank
        if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
            if _5b9363f5efd2._4713d5d607f6._17feb4a22a20():
                _06f3fec84a84 = _5b9363f5efd2._4713d5d607f6._364e5b6d1d7c()
            else:
                _06f3fec84a84 = 0
            _5b9363f5efd2._ad562bc7cc40._873139e8ec7a(_06f3fec84a84)
            self._abb8a295637d = _5b9363f5efd2._17b405a77947(f"cuda:{_06f3fec84a84}")
        else:
            self._abb8a295637d = _5b9363f5efd2._17b405a77947("cpu")

        self._711b5b150b50()

    def _350bb3f10044(self) -> _4e8b8387415a:
        """
        Handle end of validation epoch.

        Raises:
            RuntimeError: If validation epoch end processing fails.
        """
        try:
            if not self._894bf5d90c55:
                _b23c1983b039("[on_validation_epoch_end] No validation outputs to process.")
                return
            
            _fbed7a899df2, _3edd7ac70561 = self._c3c7f71c3a33(self._894bf5d90c55)
            _17b405a77947 = self._4f6bfb0afd14['micro_accuracy']._17b405a77947
            _fbed7a899df2, _3edd7ac70561 = _fbed7a899df2._829885f15bb8(_17b405a77947), _3edd7ac70561._829885f15bb8(_17b405a77947)
            
            self._4f6bfb0afd14['micro_accuracy']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_accuracy']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_precision']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_recall']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_f1']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_accuracy']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_precision']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_recall']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_f1']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['confmat']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            
            _0555feed33d1 = self._4f6bfb0afd14['micro_accuracy']._bd69952c7368()._affc8bfac33f()
            _06d01596c1b8 = self._4f6bfb0afd14['macro_accuracy']._bd69952c7368()._affc8bfac33f()
            _e4098900a9ad = self._4f6bfb0afd14['macro_precision']._bd69952c7368()._affc8bfac33f()
            _4165eae75d74 = self._4f6bfb0afd14['macro_recall']._bd69952c7368()._affc8bfac33f()
            _8b769ccebaf5 = self._4f6bfb0afd14['macro_f1']._bd69952c7368()._affc8bfac33f()
            _4b1c51dba984 = self._4f6bfb0afd14['classwise_accuracy']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _483b7bcb9a32 = self._4f6bfb0afd14['classwise_precision']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _ba96be41b645 = self._4f6bfb0afd14['classwise_recall']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _df3059adcddb = self._4f6bfb0afd14['classwise_f1']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _3b9f36418cba = self._4f6bfb0afd14['confmat']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            
            self._10c6dec40e9d("val_accuracy", _06d01596c1b8, _defd1da0568e=_5ab71833f02e)
            
            _48e796dfa86d = {
                "epoch": [self._2e8074dcbdcf],
                "class_names": [self._f612e1b537f9],
                "micro_accuracy": [_0555feed33d1],
                "macro_accuracy": [_06d01596c1b8],
                "macro_precision": [_e4098900a9ad],
                "macro_recall": [_4165eae75d74],
                "macro_f1": [_8b769ccebaf5],
                "classwise_accuracy": [_4b1c51dba984._a714dd08c090()],
                "classwise_precision": [_483b7bcb9a32._a714dd08c090()],
                "classwise_recall": [_ba96be41b645._a714dd08c090()],
                "classwise_f1": [_df3059adcddb._a714dd08c090()],
                "confusion_matrix": [_3b9f36418cba._a714dd08c090()],
            }
            self._8d0d53845c9a(_48e796dfa86d, f"val_epoch_{self._2e8074dcbdcf}.csv", self._2e7f4a3ee3b1)
            
            self._4f6bfb0afd14['micro_accuracy']._eb89d230dc97()
            self._4f6bfb0afd14['macro_accuracy']._eb89d230dc97()
            self._4f6bfb0afd14['macro_precision']._eb89d230dc97()
            self._4f6bfb0afd14['macro_recall']._eb89d230dc97()
            self._4f6bfb0afd14['macro_f1']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_accuracy']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_precision']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_recall']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_f1']._eb89d230dc97()
            self._4f6bfb0afd14['confmat']._eb89d230dc97()
            self._894bf5d90c55._0b2a9494c3a6()
            
            if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
                _5b9363f5efd2._ad562bc7cc40._6d379fa38926()
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Validation epoch end failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _7938cdd69df6(self, _a7fcc664b002: _abd44b492713[_a849f9c0ef19]) -> _867b209dcb37[_5b9363f5efd2._3a6b9ed98fbc, _5b9363f5efd2._3a6b9ed98fbc]:
        """
        Reconcile chunked predictions and labels.

        Args:
            outputs (List[Dict]): Validation/test outputs.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: Reconciled predictions and labels.

        Raises:
            RuntimeError: If reconciliation fails.
        """
        try:
            def _c016991ae3c4(_623972d7c27a):
                if _b49d5a854a66(_623972d7c27a, _5b9363f5efd2._3a6b9ed98fbc):
                    return _623972d7c27a._daf944e6c776()._3f03981900cf()._7299485ba3ed(-1)._a714dd08c090()
                if _b49d5a854a66(_623972d7c27a, _558256843c34._fa040a576f1d):
                    return _623972d7c27a._7299485ba3ed(-1)._a714dd08c090()
                if _b49d5a854a66(_623972d7c27a, (_07f4cf44ac0e, _7f14b99618f1)):
                    return _07f4cf44ac0e(_623972d7c27a)
                return [_623972d7c27a]
            
            _b9658e875263, _36f3c293f886, _27994fa969b5 = [], [], []
            _f02f4f85f259 = _683afeb04b08()
            _d4459b75a731 = _06b640faa123(_07f4cf44ac0e)
            
            for _f5714cbf9016 in _a7fcc664b002:
                if not _22957c03f57c(_2bfa66f5117d in _f5714cbf9016 for _2bfa66f5117d in ["sample_ids", "chunk_ids", "preds", "labels", "word_positions"]):
                    raise _9f65ca2b2575("Output dictionary missing required keys")
                _ecf7a5aeb5ba = _f5714cbf9016["sample_ids"]
                _1545d018aaf3 = _f5714cbf9016["chunk_ids"]
                _9fb557e75798 = _f5714cbf9016["preds"]
                _87ee9a6a34b3 = _f5714cbf9016["labels"]
                _7702057478cc = _f5714cbf9016["word_positions"]
                
                for _9d84c912c668, _2e2f0b401c06 in _bd589f555e4a(_ecf7a5aeb5ba):
                    _6eeda0eac331 = _23f8a5c1449b(_1545d018aaf3[_9d84c912c668])
                    if (_2e2f0b401c06, _6eeda0eac331) in _f02f4f85f259:
                        continue
                    _f02f4f85f259._6ce6239ffa35((_2e2f0b401c06, _6eeda0eac331))
                    _62afe7e594db = _e7cef346bdda(_9fb557e75798[_9d84c912c668])
                    _b3128005213a = _e7cef346bdda(_87ee9a6a34b3[_9d84c912c668])
                    _7e4dd2333575 = _e7cef346bdda(_7702057478cc[_9d84c912c668])
                    
                    if not (_b235e0c360bd(_7e4dd2333575) == _b235e0c360bd(_62afe7e594db) == _b235e0c360bd(_b3128005213a)):
                        _b23c1983b039(
                            f"[WARN] mismatch sid={_2e2f0b401c06} cid={_6eeda0eac331}: "
                            f"pos={_b235e0c360bd(_7e4dd2333575)} preds={_b235e0c360bd(_62afe7e594db)} labels={_b235e0c360bd(_b3128005213a)}"
                        )
                        continue
                    
                    if _2e2f0b401c06 not in _27994fa969b5:
                        _27994fa969b5._662319d234e1(_2e2f0b401c06)
                    _d4459b75a731[_2e2f0b401c06]._662319d234e1((_6eeda0eac331, _7e4dd2333575, _62afe7e594db, _b3128005213a))
            
            for _2e2f0b401c06 in _27994fa969b5:
                _fbb151502e69 = _d4459b75a731[_2e2f0b401c06]
                _fbb151502e69._c876cd61e37d(_2bfa66f5117d=lambda _623972d7c27a: _623972d7c27a[0])
                _4926ad80f1f8 = _06b640faa123(_07f4cf44ac0e)
                _31df24a1f220 = _06b640faa123(_07f4cf44ac0e)
                
                for _6eeda0eac331, _d26d09458b36, _fbed7a899df2, _3edd7ac70561 in _fbb151502e69:
                    for _f42ea503893b, _16645d62e2bc, _e4fd3eba21fc in _5d2343e27476(_d26d09458b36, _fbed7a899df2, _3edd7ac70561):
                        _4926ad80f1f8[_23f8a5c1449b(_f42ea503893b)]._662319d234e1(_23f8a5c1449b(_16645d62e2bc))
                        _31df24a1f220[_23f8a5c1449b(_f42ea503893b)]._662319d234e1(_23f8a5c1449b(_e4fd3eba21fc))
                
                _83b866ecceed, _587adf4d35ac = [], []
                for _f42ea503893b in _448ba390b0b2(_4926ad80f1f8._1be436e1d4ee()):
                    _16645d62e2bc = _f43440b26940(_4926ad80f1f8[_f42ea503893b])._968763168b8b(1)[0][0]
                    _83b866ecceed._662319d234e1(_16645d62e2bc)
                    _e4fd3eba21fc = _f43440b26940(_31df24a1f220[_f42ea503893b])._968763168b8b(1)[0][0] if _f42ea503893b in _31df24a1f220 else -100
                    _587adf4d35ac._662319d234e1(_e4fd3eba21fc)
                
                _b9658e875263._c851f54674be(_83b866ecceed)
                _36f3c293f886._c851f54674be(_587adf4d35ac)
            
            return _5b9363f5efd2._cd0730554c1c(_b9658e875263, _17b405a77947="cpu"), _5b9363f5efd2._cd0730554c1c(_36f3c293f886, _17b405a77947="cpu")
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Chunk reconciliation failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _ee6b0054758c(self, _80cc938d6a53: _a849f9c0ef19, _30f87554ee23: _23f8a5c1449b) -> _a849f9c0ef19:
        """
        Perform a test step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Test outputs.

        Raises:
            RuntimeError: If test step fails.
        """
        try:
            if "input_ids" not in _80cc938d6a53 or "labels" not in _80cc938d6a53:
                raise _9f65ca2b2575("Batch missing input_ids or labels")
            with _5b9363f5efd2._58516bdd66bf():
                _25e2e425f0a7 = _80cc938d6a53["input_ids"]._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
                _3edd7ac70561 = _80cc938d6a53["labels"]._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
                _49eb8e6d124d = _80cc938d6a53["lang_codes"]
                _ecf7a5aeb5ba = _80cc938d6a53["sample_ids"]
                _1545d018aaf3 = _80cc938d6a53["chunk_ids"]
                _7702057478cc = _80cc938d6a53["word_positions"]
                _9d10a85b9ac2 = _25e2e425f0a7._6412747ef5cb(0)

                _a9278a31e446, _e430ab72cd09, _6b17bfd9f0f3 = self(_25e2e425f0a7)

                _96115818f5d5 = _a9278a31e446._9ef36f1d955c()._e16deb8f94ab(-1, _a9278a31e446._3cbab77972c1[-1])
                _1df3baa96032 = _3edd7ac70561._9ef36f1d955c()._e16deb8f94ab(-1)

                _477e6ae9c6a0, _155c835d3e43 = [], []
                for _9d84c912c668 in _6689b309ab94(_9d10a85b9ac2):
                    _08e3b5b0a60b = _a9278a31e446[_9d84c912c668]
                    _7aae2b95db35 = _3edd7ac70561[_9d84c912c668]
                    _77e49876f71d = _7aae2b95db35 != self._21a3a286caff
                    _941f352e58bd = _08e3b5b0a60b[_77e49876f71d]
                    _343b62b6fc2b = _7aae2b95db35[_77e49876f71d]

                    if self._c04de7ca86b7 > 0:
                        _07af703ef127 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._6ad24140fba2(_941f352e58bd, _02449d00843c=-1)
                        _896bf6b24817, _607c2ecbd62a = _07af703ef127._5f367bc4303f(_02449d00843c=-1)
                        _71b8d232c2f1 = _896bf6b24817 < self._c04de7ca86b7
                        _607c2ecbd62a = _607c2ecbd62a._d5e19bf223eb() + 1
                        _607c2ecbd62a[_71b8d232c2f1] = 0
                        _343b62b6fc2b = _343b62b6fc2b._d5e19bf223eb() + 1
                        del _07af703ef127, _896bf6b24817, _71b8d232c2f1
                    else:
                        _607c2ecbd62a = _941f352e58bd._31c6bad1f247(_02449d00843c=-1)

                    _477e6ae9c6a0._662319d234e1(_607c2ecbd62a)
                    _155c835d3e43._662319d234e1(_343b62b6fc2b)
                    del _941f352e58bd

                _ec7d1d137806 = {
                    "lang_codes": _49eb8e6d124d,
                    "preds": _477e6ae9c6a0,
                    "labels": _155c835d3e43,
                    "sample_ids": _ecf7a5aeb5ba,
                    "chunk_ids": _1545d018aaf3,
                    "word_positions": _7702057478cc,
                }
                self._6f57940509c3._662319d234e1(_ec7d1d137806)

                # cleanup
                del _25e2e425f0a7, _3edd7ac70561, _a9278a31e446
                if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
                    _5b9363f5efd2._ad562bc7cc40._6d379fa38926()
                return _ec7d1d137806
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Test step {_30f87554ee23} failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _8fe1614b789f(self):
        # pick correct device for this rank
        if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
            if _5b9363f5efd2._4713d5d607f6._17feb4a22a20():
                _06f3fec84a84 = _5b9363f5efd2._4713d5d607f6._364e5b6d1d7c()
            else:
                _06f3fec84a84 = 0
            _5b9363f5efd2._ad562bc7cc40._873139e8ec7a(_06f3fec84a84)
            self._abb8a295637d = _5b9363f5efd2._17b405a77947(f"cuda:{_06f3fec84a84}")
        else:
            self._abb8a295637d = _5b9363f5efd2._17b405a77947("cpu")

        self._711b5b150b50()

    def _7aadf9a80401(self) -> _4e8b8387415a:
        """
        Handle end of test epoch.

        Raises:
            RuntimeError: If test epoch end processing fails.
        """
        try:
            if not self._6f57940509c3:
                _b23c1983b039("[on_test_epoch_end] No test outputs to process.")
                return
            
            _fbed7a899df2, _3edd7ac70561 = self._c3c7f71c3a33(self._6f57940509c3)
            _17b405a77947 = self._4f6bfb0afd14['micro_accuracy']._17b405a77947
            _fbed7a899df2, _3edd7ac70561 = _fbed7a899df2._829885f15bb8(_17b405a77947), _3edd7ac70561._829885f15bb8(_17b405a77947)
            
            self._4f6bfb0afd14['micro_accuracy']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_accuracy']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_precision']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_recall']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['macro_f1']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_accuracy']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_precision']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_recall']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['classwise_f1']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            self._4f6bfb0afd14['confmat']._ec20573b6303(_fbed7a899df2, _3edd7ac70561)
            
            _0555feed33d1 = self._4f6bfb0afd14['micro_accuracy']._bd69952c7368()._affc8bfac33f()
            _06d01596c1b8 = self._4f6bfb0afd14['macro_accuracy']._bd69952c7368()._affc8bfac33f()
            _e4098900a9ad = self._4f6bfb0afd14['macro_precision']._bd69952c7368()._affc8bfac33f()
            _4165eae75d74 = self._4f6bfb0afd14['macro_recall']._bd69952c7368()._affc8bfac33f()
            _8b769ccebaf5 = self._4f6bfb0afd14['macro_f1']._bd69952c7368()._affc8bfac33f()
            _4b1c51dba984 = self._4f6bfb0afd14['classwise_accuracy']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _483b7bcb9a32 = self._4f6bfb0afd14['classwise_precision']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _ba96be41b645 = self._4f6bfb0afd14['classwise_recall']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _df3059adcddb = self._4f6bfb0afd14['classwise_f1']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            _3b9f36418cba = self._4f6bfb0afd14['confmat']._bd69952c7368()._3f03981900cf()._b1e52b577f39()
            
            self._10c6dec40e9d("test_accuracy", _06d01596c1b8, _defd1da0568e=_5ab71833f02e)
            
            _48e796dfa86d = {
                "class_names": [self._f612e1b537f9],
                "micro_accuracy": [_0555feed33d1],
                "macro_accuracy": [_06d01596c1b8],
                "macro_precision": [_e4098900a9ad],
                "macro_recall": [_4165eae75d74],
                "macro_f1": [_8b769ccebaf5],
                "classwise_accuracy": [_4b1c51dba984._a714dd08c090()],
                "classwise_precision": [_483b7bcb9a32._a714dd08c090()],
                "classwise_recall": [_ba96be41b645._a714dd08c090()],
                "classwise_f1": [_df3059adcddb._a714dd08c090()],
                "confusion_matrix": [_3b9f36418cba._a714dd08c090()],
            }
            self._8d0d53845c9a(_48e796dfa86d, "test_final.csv", self._2e7f4a3ee3b1)
            
            self._4f6bfb0afd14['micro_accuracy']._eb89d230dc97()
            self._4f6bfb0afd14['macro_accuracy']._eb89d230dc97()
            self._4f6bfb0afd14['macro_precision']._eb89d230dc97()
            self._4f6bfb0afd14['macro_recall']._eb89d230dc97()
            self._4f6bfb0afd14['macro_f1']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_accuracy']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_precision']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_recall']._eb89d230dc97()
            self._4f6bfb0afd14['classwise_f1']._eb89d230dc97()
            self._4f6bfb0afd14['confmat']._eb89d230dc97()
            self._6f57940509c3._0b2a9494c3a6()
            
            if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
                _5b9363f5efd2._ad562bc7cc40._6d379fa38926()
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Test epoch end failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _9b7b86277922(self, _80cc938d6a53: _a849f9c0ef19, _30f87554ee23: _23f8a5c1449b, _c0052cafae37: _23f8a5c1449b = 0) -> _a849f9c0ef19:
        """
        Perform a prediction step.

        Args:
            batch (Dict): Batch containing input_ids.
            batch_idx (int): Batch index.
            dataloader_idx (int): Dataloader index.

        Returns:
            Dict: Predictions and probabilities.

        Raises:
            RuntimeError: If prediction step fails.
        """
        try:
            if not _80cc938d6a53 or not _b49d5a854a66(_80cc938d6a53, (_07f4cf44ac0e, _7f14b99618f1)) or not _80cc938d6a53[0]:
                raise _9f65ca2b2575("Invalid batch input for prediction")
            _25e2e425f0a7 = _80cc938d6a53[0]._829885f15bb8(self._abb8a295637d, _0302544c8f1d=_5ab71833f02e)
            _a7fcc664b002, _, _ = self(_25e2e425f0a7)
            _a7fcc664b002 = _a7fcc664b002._9ef36f1d955c()._e16deb8f94ab(-1, _a7fcc664b002._3cbab77972c1[-1])
            
            if self._c04de7ca86b7 > 0:
                _07af703ef127 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._6ad24140fba2(_a7fcc664b002, _02449d00843c=-1)
                _896bf6b24817, _16645d62e2bc = _07af703ef127._5f367bc4303f(_02449d00843c=-1)
                _71b8d232c2f1 = _896bf6b24817 < self._c04de7ca86b7
                _561e3b44b6c2 = _16645d62e2bc + 1
                _561e3b44b6c2[_71b8d232c2f1] = 0
                _a55788f3a5ea = _5b9363f5efd2._7f682e1694c3(_a7fcc664b002._6412747ef5cb(0), self._4ef82fe6d545 + 1, _17b405a77947=_a7fcc664b002._17b405a77947)
                _a55788f3a5ea[~_71b8d232c2f1, 1:] = _07af703ef127[~_71b8d232c2f1]
                _a55788f3a5ea[_71b8d232c2f1, 0] = 1.0
            else:
                _07af703ef127 = _5b9363f5efd2._a701ad31d0c3._ccb17a78cd45._6ad24140fba2(_a7fcc664b002, _02449d00843c=-1)
                _561e3b44b6c2 = _07af703ef127._31c6bad1f247(_02449d00843c=-1)
                _a55788f3a5ea = _07af703ef127
            
            del _25e2e425f0a7, _a7fcc664b002
            if _5b9363f5efd2._ad562bc7cc40._2ff8514f5c75():
                _5b9363f5efd2._ad562bc7cc40._6d379fa38926()
            return {
                "predictions": _561e3b44b6c2._3f03981900cf(),
                "probs": _a55788f3a5ea._3f03981900cf()
            }
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Predict step {_30f87554ee23} failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _19327f45e885(self, _327279339662) -> _4e8b8387415a:
        """
        Handle operations before optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If gradient clipping fails.
        """
        try:
            _5b9363f5efd2._a701ad31d0c3._9e63b43e1cc8._e6e299b6f235(self._8a77deb924e3(), _4261d601a88a=1.0)
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Gradient clipping failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _61b0affaf315(self, _327279339662) -> _4e8b8387415a:
        """
        Handle operations after optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If parameter clamping fails.
        """
        try:
            for _b043400234c8 in self._8a77deb924e3():
                if _b043400234c8 is not _4e8b8387415a:
                    _b043400234c8._37b925af1a92._213ba12e8a9e(-5, 5)
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Parameter clamping failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _024ed60c294a(self) -> _5f08c5a575e6:
        """
        Compute gradient norm.

        Returns:
            float: L2 gradient norm.

        Raises:
            RuntimeError: If gradient norm computation fails.
        """
        try:
            _7526b6d8788c = 0
            for _b043400234c8 in self._8a77deb924e3():
                if _b043400234c8._4f969c241314 is not _4e8b8387415a:
                    _114096a9bb7c = _b043400234c8._4f969c241314._daf944e6c776()._37b925af1a92._0fe24163aee2(2)
                    _7526b6d8788c += _114096a9bb7c._affc8bfac33f() ** 2
            return _7526b6d8788c ** 0.5
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Gradient norm computation failed: {_5dbbdadb3289(_ca135ba4fa58)}")

    def _186246b78328(self) -> _a849f9c0ef19:
        """
        Configure optimizer and learning rate scheduler.

        Returns:
            Dict: Optimizer and scheduler configuration.

        Raises:
            RuntimeError: If optimizer configuration fails.
        """
        try:
            _582326424711 = _76e523f5e60f(lambda _0c13493da9df: _0c13493da9df._81a1fb02951b, self._8a77deb924e3())
            _5740c5254f22 = {
                "adamw": _5b9363f5efd2._438187a7b2cc._8fe7c0b2db45,
                "adamax": _5b9363f5efd2._438187a7b2cc._48e61cd8c2c3,
                "adam": _5b9363f5efd2._438187a7b2cc._451cc204b52c,
            }
            _0356302489fe = _5740c5254f22._1be95c7334a4(self._1dd3c89179c6._c17da237573d())
            if _0356302489fe is _4e8b8387415a:
                raise _9f65ca2b2575(f"Unsupported optimizer: {self._1dd3c89179c6}")
            _327279339662 = _0356302489fe(_582326424711, _0a859ac520c1=self._c28e2e455dd1._0a859ac520c1, _a572bff8a9ea=0.001)
            
            _3a7a199254e3 = self._ca78c0470cfe._ea54edf0187e
            _2b18dd68f8f1 = math._e87f4faa6267(0.1 * _3a7a199254e3)
            _d41d0202ead4 = _5b9363f5efd2._438187a7b2cc._edb35fa394e3._187fdc380b51(_327279339662, _42d808ecebf5=lambda _396cb083ee2f: (_396cb083ee2f + 1) / _2b18dd68f8f1)
            _f4e8279b2bb9 = _5b9363f5efd2._438187a7b2cc._edb35fa394e3._f01c0867be5b(
                _327279339662,
                _a5a53207b999=_5f367bc4303f(1, _3a7a199254e3 - _2b18dd68f8f1),
                _e2b3e13b3331=2,
                _f0fcf4636397=1e-6
            )
            _edb35fa394e3 = _5b9363f5efd2._438187a7b2cc._edb35fa394e3._286e09fef924(
                _327279339662,
                _b8a33aafdb81=[_d41d0202ead4, _f4e8279b2bb9],
                _f52a68a715f8=[_2b18dd68f8f1]
            )
            
            return {"optimizer": _327279339662, "lr_scheduler": {"scheduler": _edb35fa394e3, "interval": "epoch", "monitor": "val_loss"}}
        except _722dbb2c298f as _ca135ba4fa58:
            raise _9f65ca2b2575(f"Optimizer configuration failed: {_5dbbdadb3289(_ca135ba4fa58)}")