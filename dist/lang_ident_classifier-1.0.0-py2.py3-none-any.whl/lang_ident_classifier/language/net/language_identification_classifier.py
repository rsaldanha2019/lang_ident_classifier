# -*- coding: utf-8 -*-
"""
Language Identification Classifier
Handles language identification using a transformer-based model with custom loss functions.
"""
import _9dbc6338cdb4
import _2eec472af096
from _ae323e98e03e import _b830de4d9e73, _51f3f18f8abc
from _580b4836b305 import _0a9744333d8c
from _ac1c4beacba6 import _5415586b6f14, _1aa275558dd2, _228671365af9, _e1bbfdd21ec0
from _95d755505b36 import _31375a1d122e

import _dc14271ea750 as _fe4665d47819
import _62076b8ca668 as _ab7f0728004e
import _e560a52cc9c0 as _d881ac4a11c3
import _b67e8959a394
from _82e9bd12e610 import _0aef665dfd31, _df5a543d7d8e, _5f459b4c573d, _2615b580d4b6, _0dc8d1833ce7

from _b9ed128ff58c._9fbf83d4efe7._17f98c264c01._0efa5608d2a4 import _e17ac37dcedb
from _b9ed128ff58c._9fbf83d4efe7._f9f8a3047e65._b63cd945504d import _d19c6d131a36
from _b9ed128ff58c._9fbf83d4efe7._f9f8a3047e65._0fb0f48dd5b0 import _52a078e749d0
from _b9ed128ff58c._9fbf83d4efe7._f9f8a3047e65._0ae87ca3dd3a import _db712ac4cf7d
from _b9ed128ff58c._9fbf83d4efe7._8267d8217094._a4ae41f1474d import _ee70d737a662

# Only export the classifier as public API
_5192b423a4cb = ["LanguageIdentificationClassifier"]

_0b4357ece2ce = 'cuda' if _b67e8959a394._5794de131c5d._d46d58d540b7() else 'cpu'
_8b78898dc050 = _d64f9d90d0ed

class _1abdfebe8023(_fe4665d47819._722edd9ddf3c):
    """Classifier for language identification using a transformer-based model."""

    class _11ca2864a45f(_b67e8959a394._c4cd796e566e._ae9fd5eb393f):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _c2fd2a11ca97(self, _88a78044a571: _ad71b2b9a4b4, _bb409e3460dc: _ad71b2b9a4b4 = 64):
            _e5d1d6d04afe()._6a2fda9f6b01()
            self._629611d8f7b7 = _b67e8959a394._c4cd796e566e._46f3768dde6e(_88a78044a571, _bb409e3460dc, _068c6726bf5d=_1113cd560423)
            self._030c3c507355 = _b67e8959a394._c4cd796e566e._c32f52a1e4d6(_ec47dfedcc75=_0f2f94fabf98)
            self._9d6060de7d0f = _b67e8959a394._c4cd796e566e._46f3768dde6e(_bb409e3460dc, _88a78044a571, _068c6726bf5d=_1113cd560423)
            # start adapter near-zero so initial behavior is identity
            _b67e8959a394._c4cd796e566e._ac092a5425d4._957fa6c7a6fd(self._9d6060de7d0f._6860e6c80c0f)
            _b67e8959a394._c4cd796e566e._ac092a5425d4._7b18d2f1f1be(self._629611d8f7b7._6860e6c80c0f, _4c21b086671e=_9dbc6338cdb4._a0c7c3f32cb1(5))

        def _f416e84631e6(self, _eec6253e82f5: _b67e8959a394._bb88bd652b08) -> _b67e8959a394._bb88bd652b08:
            # supports x shape (B, L, D) or (B, D)
            if _eec6253e82f5._88a78044a571() == 2:
                _e45644f30050 = self._9d6060de7d0f(self._030c3c507355(self._629611d8f7b7(_eec6253e82f5)))
                return _eec6253e82f5 + _e45644f30050
            _bb7528f397e5, _07f49943c809, _e085c9dc582c = _eec6253e82f5._25fa029ec1f0
            _d9283329e933 = _eec6253e82f5._66c160b6a0ac(-1, _e085c9dc582c)                    # (B*L, D)
            _d9283329e933 = self._9d6060de7d0f(self._030c3c507355(self._629611d8f7b7(_d9283329e933)))  # (B*L, D)
            _d9283329e933 = _d9283329e933._66c160b6a0ac(_bb7528f397e5, _07f49943c809, _e085c9dc582c)
            return _eec6253e82f5 + _d9283329e933

    class _e94267ca07eb(_b67e8959a394._c4cd796e566e._ae9fd5eb393f):
        """Wraps a module to ensure stable forward pass with clamping and NaN handling."""
        
        def _c2fd2a11ca97(self, _f1f88cd00811: _b67e8959a394._c4cd796e566e._ae9fd5eb393f, _e0ff25f8224e: _9b5a9bb69d68 = -5.0, _568b7a3ce24c: _9b5a9bb69d68 = 5.0):
            """
            Initialize the wrapper with a module and clamping bounds.

            Args:
                module (torch.nn.Module): Module to wrap.
                clamp_min (float): Minimum value for clamping.
                clamp_max (float): Maximum value for clamping.

            Raises:
                ValueError: If module is None or invalid.
            """
            if _f1f88cd00811 is _d64f9d90d0ed:
                raise _5803a67f95ec("Module cannot be None")
            _e5d1d6d04afe()._6a2fda9f6b01()
            self._f1f88cd00811 = _f1f88cd00811
            self._e0ff25f8224e = _e0ff25f8224e
            self._568b7a3ce24c = _568b7a3ce24c

        def _f416e84631e6(self, *_41ea31912b11, **_2b88144b0be5) -> _b67e8959a394._bb88bd652b08:
            """
            Forward pass with dtype conversion, clamping, and NaN handling.

            Args:
                *inputs: Input tensors or other arguments.
                **kwargs: Keyword arguments for the module.

            Returns:
                torch.Tensor: Processed output tensor.

            Raises:
                RuntimeError: If forward pass fails.
            """
            try:
                _41ea31912b11 = _5568f2ad3fba(
                    _b3ea6bbef83b._09cff1d91d55(_b67e8959a394._ecfe0095f9bf) if _e064459892d9(_b3ea6bbef83b, _b67e8959a394._bb88bd652b08) and _b3ea6bbef83b._5bd382a746d8 != _b67e8959a394._ecfe0095f9bf else _b3ea6bbef83b
                    for _b3ea6bbef83b in _41ea31912b11
                )
                _85d891389491 = self._f1f88cd00811(*_41ea31912b11, **_2b88144b0be5)
                if _e064459892d9(_85d891389491, _b67e8959a394._bb88bd652b08):
                    _85d891389491 = _85d891389491._09cff1d91d55(_b67e8959a394._ecfe0095f9bf)
                    _85d891389491._addead0dec90(self._e0ff25f8224e, self._568b7a3ce24c)
                    _85d891389491 = _b67e8959a394._f4a4504ff7c8(_85d891389491)
                return _85d891389491
            except _5a4d3b79f5fe as _ff37d74b2c1b:
                raise _a6fb1e9c2cdc(f"Forward pass failed in {self._f1f88cd00811._d813b9854297.__name__}: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _c2fd2a11ca97(
        self,
        _2f7d012cf6a3: _b67e8959a394._c4cd796e566e._ae9fd5eb393f,
        _792bf15363bc: _1aa275558dd2[_3e4dfb6239c1],
        _a1c896dac2c2: _9b5a9bb69d68,
        _8a3b82e178be: _3e4dfb6239c1,
        _9d1243d312d8: _b67e8959a394._bb88bd652b08,
        _367cba02b564: _5415586b6f14,
        _d0dd3ff4df12: _ad71b2b9a4b4,
        _6b4a5f331938: _3e4dfb6239c1,
        _1ad1aa7dfe6b: _ad71b2b9a4b4,
        _9641858f5c6b: _3e4dfb6239c1,
        _2fd298f259a0: _455ee9a25995,
        _739a1ba68a6b: _455ee9a25995,
        _11552664579b: _056692e03c9f,
        _2ffa3f811b54: _ad71b2b9a4b4 = 20,
        _15f2d0c89ba8: _228671365af9[_3e4dfb6239c1] = _d64f9d90d0ed,
        _7fdb8b248e5a: _228671365af9[_ad71b2b9a4b4] = _d64f9d90d0ed,
        _9f4b340d739a: _9b5a9bb69d68 = 0.0,
        _5cd209296a78: _3e4dfb6239c1 = _d64f9d90d0ed
    ):
        """
        Initialize the language identification classifier.

        Args:
            pretrained_embedding_model (torch.nn.Module): Pretrained transformer model.
            class_names (List[str]): List of class names.
            lr (float): Learning rate.
            optimizer (str): Optimizer name (adamw, adamax, adam).
            class_weights (torch.Tensor): Class weights for loss computation.
            device_dict (Dict): Device configuration.
            num_backbone_model_units_unfrozen (int): Number of backbone layers to unfreeze.
            loss_type (str): Type of loss function.
            num_fc_layers (int): Number of fully connected layers.
            activation_function_for_layer (str): Activation function for FC layers.
            add_dropout_after_embedding (bool): Whether to add dropout after embedding.
            is_train (bool): Training mode flag.
            tokenizer (object): Tokenizer instance.
            random_seed (int): Random seed for reproducibility.
            pretrained_model_embedding_name (Optional[str]): Name of pretrained embedding model.
            trial_number (Optional[int]): Trial number for experiment tracking.
            decision_threshold (float): Threshold for unknown class detection.
            model_config_name (Optional[str]): model_config_name to create hold metrics in dir

        Raises:
            ValueError: If invalid parameters are provided.
        """
        if not _792bf15363bc:
            raise _5803a67f95ec("class_names cannot be empty")
        if _1ad1aa7dfe6b < 1:
            raise _5803a67f95ec("num_fc_layers must be at least 1")
        if _2f7d012cf6a3 is _d64f9d90d0ed:
            raise _5803a67f95ec("pretrained_embedding_model cannot be None")
        if _11552664579b is _d64f9d90d0ed:
            raise _5803a67f95ec("tokenizer cannot be None")
        
        _e5d1d6d04afe()._6a2fda9f6b01()
        self._fa7c7d5fca87({
            "lr": _9b5a9bb69d68(_a1c896dac2c2),
            "optimizer": _3e4dfb6239c1(_8a3b82e178be),
            "num_backbone_model_units_unfrozen": _ad71b2b9a4b4(_d0dd3ff4df12),
            "loss_type": _3e4dfb6239c1(_6b4a5f331938),
            "num_fc_layers": _ad71b2b9a4b4(_1ad1aa7dfe6b),
            "activation_function_for_layer": _3e4dfb6239c1(_9641858f5c6b),
            "add_dropout_after_embedding": _455ee9a25995(_2fd298f259a0),
            "is_train": _455ee9a25995(_739a1ba68a6b),
            "random_seed": _ad71b2b9a4b4(_2ffa3f811b54),
        })
        
        self._2ffa3f811b54 = _2ffa3f811b54
        _fe4665d47819._2185595768ca(_2ffa3f811b54, _179a361197dd=_0f2f94fabf98)
        _b67e8959a394._b4ada862bbb8(_2ffa3f811b54)
        if _b67e8959a394._5794de131c5d._d46d58d540b7():
            _b67e8959a394._5794de131c5d._f8c1e6cfacfa(_2ffa3f811b54)
        _ab7f0728004e._8e201df3ffde._92c1e014116d(_2ffa3f811b54)
        
        self._7fdb8b248e5a = _ad71b2b9a4b4(_7fdb8b248e5a) if _7fdb8b248e5a is not _d64f9d90d0ed else _d64f9d90d0ed
        self._11552664579b = _11552664579b
        self._79fdf038a139 = (
            _b67e8959a394._483b9eaee422(f"cuda:{_367cba02b564['gpu_local_rank']}") if _367cba02b564._d84900812a5b("gpu_local_rank", -1) != -1 else "cpu"
        )
        self._5cd209296a78 = _5cd209296a78
        self._15f2d0c89ba8 = _15f2d0c89ba8
        # self.num_classes = len(class_names)
        self._9f4b340d739a = _9f4b340d739a
        self._792bf15363bc = ["unk"] + _792bf15363bc if _9f4b340d739a > 0 else _792bf15363bc
        self._e2720c3127bd = _90459ce7f9fd(self._792bf15363bc)
        self._9d1243d312d8 = _9d1243d312d8
        self._45628b11b0e4 = "multiclass"
        self._a5d6c68bcdd9 = -100
        self._89fb17e88d85 = {}
        self._44ed23dad1d2 = {}
        
        self._f2ea4cc052be = _2f7d012cf6a3
        # self.embedding.requires_grad_(False).to(self.curr_device)
        self._f2ea4cc052be._10aee938e40d(_1113cd560423)
        _99ebf3f62423 = _ee70d737a662()  # bfloat16 or float16
        for _089109334dd0, _f1f88cd00811 in self._7d175920e056():
            if not _a53f1cf68f10(_5a0ee6b94409._9e08c6dcf03a for _5a0ee6b94409 in _f1f88cd00811._981cf19a4c8b(_d23d3ed51480=_1113cd560423)):
                # FROZEN → BF16 (save memory)
                _f1f88cd00811._09cff1d91d55(_5bd382a746d8=_99ebf3f62423)
            else:
                # TRAINABLE → FP32 (stable grads)
                _f1f88cd00811._09cff1d91d55(_5bd382a746d8=_b67e8959a394._ecfe0095f9bf)
        self._f2ea4cc052be._09cff1d91d55(self._79fdf038a139)
        if _b9795a2f9318(self._f2ea4cc052be, "gradient_checkpointing_enable"):
            self._f2ea4cc052be._bda048062049()
        # determine embedding dim robustly from model config if available
        _befca2ac8da6 = _fc33dfcad1dd(_fc33dfcad1dd(self._f2ea4cc052be, "config", _d64f9d90d0ed), "hidden_size", _d64f9d90d0ed)
        if _befca2ac8da6 is _d64f9d90d0ed:
            # fallback to common default — change if your model uses a different hidden size
            _befca2ac8da6 = 768

        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._934c1e558802 = self._1753df10631a(_88a78044a571=_befca2ac8da6, _bb409e3460dc=64)
        for _5a0ee6b94409 in self._934c1e558802._981cf19a4c8b():
            _5a0ee6b94409._9e08c6dcf03a = _0f2f94fabf98

        self._1ad1aa7dfe6b = _1ad1aa7dfe6b
        self._9641858f5c6b = _9641858f5c6b
        self._d0dd3ff4df12 = _d0dd3ff4df12
        
        if _d0dd3ff4df12 > 0:
            for _cb119fd1510e in self._f2ea4cc052be._0c891ef2d1f6._981cf19a4c8b():
                _cb119fd1510e._9e08c6dcf03a = _0f2f94fabf98
            if _d0dd3ff4df12 > 1:
                for _cb119fd1510e in self._f2ea4cc052be._bbddc08228d8._054ac2aae3c1[-(_d0dd3ff4df12-1):]._981cf19a4c8b():
                    _cb119fd1510e._9e08c6dcf03a = _0f2f94fabf98
        
        self._2fd298f259a0 = _2fd298f259a0
        if _2fd298f259a0:
            self._232c0110b338 = _b67e8959a394._c4cd796e566e._3566ea256a45(0.1, _ec47dfedcc75=_1113cd560423)
        
        self._d219e08e9b1e()
        self._547b0c746d66(_6b4a5f331938)
        self._f8f73dd100a6 = []
        self._52ae6f15ff48 = []
        self._8a93534749df = self._ac51dba121fe._8a3b82e178be._493a55988342()
        # self._setup_metrics()
        
        global _8b78898dc050
        _8b78898dc050 = _0a9744333d8c(self._f2ea4cc052be)._159c9153f524()
        self._106099008870(self._f2ea4cc052be)
        self._639c31e78b7e(self._79fdf038a139, _1ad1aa7dfe6b)
        self._541b7ed36175()

        self._79e3571d6578 = 0.99
        self._062e9bf2ee8c = 0.3
        self._a4576790777d = 0.30
        self._84f3bfca1736 = 0.25
        self._fb0a3040406f = 0.6
        self._bf454b7b2ac4 = 0.995
        self._19a805c5b2f6 = 0.60
        self._7509ba186544 = 0.20

    def _b6cbe951e240(self) -> _d64f9d90d0ed:
        """
        Set up fully connected layers with optional activation functions.

        Raises:
            RuntimeError: If layer setup fails.
        """
        try:
            _019f0286ac2f = self._f2ea4cc052be._e82710301003._22254524c701
            _7fc3aca92bc4 = self._e2720c3127bd
            
            if self._1ad1aa7dfe6b == 1:
                if self._9641858f5c6b:
                    _0e43bb9d61a1(self, f"fc_with_{self._9641858f5c6b}_activation_1", _b67e8959a394._c4cd796e566e._665b68c98368(
                        _b67e8959a394._c4cd796e566e._46f3768dde6e(_019f0286ac2f, _7fc3aca92bc4),
                        _b67e8959a394._c4cd796e566e._7ca76fb93fa3(_7fc3aca92bc4),
                        self._b6e5725d6b64(self._9641858f5c6b, _7fc3aca92bc4)
                    ))
                else:
                    _0e43bb9d61a1(self, "fc_1", _b67e8959a394._c4cd796e566e._46f3768dde6e(_019f0286ac2f, _7fc3aca92bc4))
            else:
                _9804352d5951 = _019f0286ac2f
                for _028682c47e93 in _58957850bb58(self._1ad1aa7dfe6b):
                    _42f05ea7b855 = _7fc3aca92bc4 if _028682c47e93 + 1 == self._1ad1aa7dfe6b else _9804352d5951 // 2
                    if self._9641858f5c6b and _028682c47e93 + 1 < self._1ad1aa7dfe6b:
                        _0e43bb9d61a1(self, f"fc_with_{self._9641858f5c6b}_activation_{_028682c47e93+1}", _b67e8959a394._c4cd796e566e._665b68c98368(
                            _b67e8959a394._c4cd796e566e._46f3768dde6e(_9804352d5951, _42f05ea7b855),
                            _b67e8959a394._c4cd796e566e._7ca76fb93fa3(_42f05ea7b855),
                            self._b6e5725d6b64(self._9641858f5c6b, _42f05ea7b855)
                        ))
                    else:
                        _0e43bb9d61a1(self, f"fc_{_028682c47e93+1}", _b67e8959a394._c4cd796e566e._46f3768dde6e(_9804352d5951, _42f05ea7b855))
                    _9804352d5951 = _42f05ea7b855
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Failed to set up FC layers: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _72a2a81ca9df(self, _6b4a5f331938: _3e4dfb6239c1) -> _d64f9d90d0ed:
        """
        Initialize the loss function based on the specified type.

        Args:
            loss_type (str): Type of loss function.

        Raises:
            ValueError: If loss_type is unsupported.
        """
        _6b4a5f331938 = _6b4a5f331938._493a55988342()
        _f860ea5af662 = {
            "class_weighted_cross_entropy_loss": _d19c6d131a36,
            "focal_loss": lambda: _52a078e749d0(_a40b1d9ed971=0.25, _483b9eaee422=self._79fdf038a139, _f948a66d4d07=self._a5d6c68bcdd9),
            "class_weighted_focal_loss": lambda: _52a078e749d0(_a40b1d9ed971=self._9d1243d312d8, _483b9eaee422=self._79fdf038a139, _f948a66d4d07=self._a5d6c68bcdd9),
            "class_weighted_focal_loss_with_adaptive_focus_type1": lambda: _db712ac4cf7d(_a40b1d9ed971=self._9d1243d312d8, _b622401e8742='type1', _483b9eaee422=self._79fdf038a139, _f948a66d4d07=self._a5d6c68bcdd9),
            "class_weighted_focal_loss_with_adaptive_focus_type2": lambda: _db712ac4cf7d(_a40b1d9ed971=self._9d1243d312d8, _b622401e8742='type2', _483b9eaee422=self._79fdf038a139, _f948a66d4d07=self._a5d6c68bcdd9),
            "class_weighted_focal_loss_with_adaptive_focus_type3": lambda: _db712ac4cf7d(_a40b1d9ed971=self._9d1243d312d8, _b622401e8742='type3', _483b9eaee422=self._79fdf038a139, _f948a66d4d07=self._a5d6c68bcdd9),
        }
        if _6b4a5f331938 not in _f860ea5af662:
            raise _5803a67f95ec(f"Unsupported loss_type: {_6b4a5f331938}")
        self._89fb17e88d85['criterion'] = _f860ea5af662[_6b4a5f331938]()

    # def _setup_metrics(self) -> None:
    #     """
    #     Initialize metrics for evaluation.

    #     Raises:
    #         RuntimeError: If metric setup fails.
    #     """
    #     try:
    #         metrics_params = {
    #             "num_classes": self.num_classes,
    #             "task": self.classification_task,
    #             "ignore_index": self.ignore_idx
    #         }
    #         self.metrics['micro_accuracy'] = Accuracy(average="micro", **metrics_params).to("cpu")
    #         self.metrics['macro_accuracy'] = Accuracy(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_precision'] = Precision(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_recall'] = Recall(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_f1'] = F1Score(average="macro", **metrics_params).to("cpu")
    #         self.metrics['classwise_accuracy'] = Accuracy(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_precision'] = Precision(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_recall'] = Recall(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_f1'] = F1Score(average=None, **metrics_params).to("cpu")
    #         self.metrics['confmat'] = ConfusionMatrix(normalize=None, **metrics_params).to("cpu")
    #     except Exception as e:
    #         raise RuntimeError(f"Failed to set up metrics: {str(e)}")

    def _9db6aa958280(self):
        # rebuild all metrics on the correct device
        self._44ed23dad1d2['micro_accuracy'] = _0aef665dfd31(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02="micro",
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['macro_accuracy'] = _0aef665dfd31(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02="macro",
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['macro_precision'] = _2615b580d4b6(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02="macro",
            _0d0f73a43a43=self. _45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['macro_recall'] = _0dc8d1833ce7(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02="macro",
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['macro_f1'] = _5f459b4c573d(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02="macro",
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['classwise_accuracy'] = _0aef665dfd31(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02=_d64f9d90d0ed,
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['classwise_precision'] = _2615b580d4b6(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02=_d64f9d90d0ed,
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['classwise_recall'] = _0dc8d1833ce7(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02=_d64f9d90d0ed,
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['classwise_f1'] = _5f459b4c573d(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _769b87591e02=_d64f9d90d0ed,
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

        self._44ed23dad1d2['confmat'] = _df5a543d7d8e(
            _e2720c3127bd=_90459ce7f9fd(self._792bf15363bc),
            _0d0f73a43a43=self._45628b11b0e4,
            _f948a66d4d07=self._a5d6c68bcdd9,
        )._09cff1d91d55(self._79fdf038a139)

    def _2bfe35754dc4(self, _f1f88cd00811: _b67e8959a394._c4cd796e566e._ae9fd5eb393f, _195d8a944eab: _3e4dfb6239c1 = "") -> _d64f9d90d0ed:
        """
        Recursively attach hooks to detect NaNs in forward pass.

        Args:
            module (torch.nn.Module): Module to attach hooks to.
            prefix (str): Prefix for module naming.

        Raises:
            RuntimeError: If hook registration fails.
        """
        try:
            for _089109334dd0, _8e68b370ce82 in _f1f88cd00811._d5457a78679e():
                _be5eb40ff538 = f"{_195d8a944eab}.{_089109334dd0}" if _195d8a944eab else _089109334dd0
                def _45e6e09c2835(_b344ab7e20b0, _b3ea6bbef83b, _e45644f30050):
                    if _e064459892d9(_e45644f30050, _b67e8959a394._bb88bd652b08) and _e45644f30050._76d26badda58()._a53f1cf68f10():
                        _506e58c33b15(f"NaN detected in {_be5eb40ff538} ({_b344ab7e20b0._d813b9854297.__name__}) (dtype={_e45644f30050._5bd382a746d8})")
                _8e68b370ce82._b26e8ef093f9(_8864bd666816)
                self._106099008870(_8e68b370ce82, _be5eb40ff538)
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Failed to register NaN hooks: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _faf4cb749ea5(self, _f1f88cd00811: _b67e8959a394._c4cd796e566e._ae9fd5eb393f) -> _455ee9a25995:
        """
        Check if a module has trainable parameters.

        Args:
            module (torch.nn.Module): Module to check.

        Returns:
            bool: True if module has trainable parameters.
        """
        return _a53f1cf68f10(_5a0ee6b94409._9e08c6dcf03a for _5a0ee6b94409 in _f1f88cd00811._981cf19a4c8b())

    def _e8df7734d9bb(self) -> _d64f9d90d0ed:
        """
        Convert specific layers to float32 and wrap them for stability.

        Raises:
            RuntimeError: If layer wrapping fails.
        """
        try:
            _e700b78506cb = []
            for _089109334dd0, _f1f88cd00811 in self._7d175920e056():
                if not self._ea7425cff065(_f1f88cd00811):
                    continue
                _17ae55ea4164 = "norm" in _089109334dd0._afad6bb453da() or _e064459892d9(_f1f88cd00811, _b67e8959a394._c4cd796e566e._7ca76fb93fa3)
                _9a561ee9de34 = _a53f1cf68f10(_030c3c507355 in _089109334dd0._afad6bb453da() for _030c3c507355 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"])
                _0e33626f5417 = "dropout" in _089109334dd0._afad6bb453da() or _e064459892d9(_f1f88cd00811, _b67e8959a394._c4cd796e566e._3566ea256a45)
                _05e12cac1c3b = "attention" in _089109334dd0._afad6bb453da()
                if _17ae55ea4164:
                    _f1f88cd00811._dac326b0e813 = 1e-5
                if _17ae55ea4164 or _9a561ee9de34 or _05e12cac1c3b:
                    _f1f88cd00811._09cff1d91d55(_b67e8959a394._ecfe0095f9bf)
                    if not _e064459892d9(_f1f88cd00811, _cda3b01638cb._3b542c230eda):
                        _e700b78506cb._36c00d73c69d((_089109334dd0, _cda3b01638cb._3b542c230eda(_f1f88cd00811)))
            for _089109334dd0, _e61b3d5814eb in _e700b78506cb:
                _0812d10d377c, _69b00720ad95 = self._26bf6ef43e48(_089109334dd0)
                if _0812d10d377c is not _d64f9d90d0ed:
                    _0e43bb9d61a1(_0812d10d377c, _69b00720ad95, _e61b3d5814eb)
                else:
                    raise _a6fb1e9c2cdc(f"Cannot find parent module for {_089109334dd0}")
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Failed to fix embedding layers: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _bae16657440b(self, _05905179e53a: _3e4dfb6239c1) -> _e1bbfdd21ec0[_228671365af9[_b67e8959a394._c4cd796e566e._ae9fd5eb393f], _228671365af9[_3e4dfb6239c1]]:
        """
        Find parent module and attribute name for a given module path.

        Args:
            module_name (str): Full module path.

        Returns:
            Tuple[Optional[torch.nn.Module], Optional[str]]: Parent module and attribute name.

        Raises:
            RuntimeError: If module path is invalid.
        """
        try:
            _35f2e09f2dcb = _05905179e53a._09539db30a04('.')
            _0812d10d377c = self
            for _37f62f567937 in _35f2e09f2dcb[:-1]:
                _0812d10d377c = _fc33dfcad1dd(_0812d10d377c, _37f62f567937, _d64f9d90d0ed)
                if _0812d10d377c is _d64f9d90d0ed:
                    raise _a6fb1e9c2cdc(f"Invalid module path: {_05905179e53a}")
            return _0812d10d377c, _35f2e09f2dcb[-1]
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Failed to get parent and attribute for {_05905179e53a}: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _e936f1badfe2(self, _bfaa82c02e1a: _3e4dfb6239c1, _bd08547e92cf: _ad71b2b9a4b4) -> _b67e8959a394._c4cd796e566e._ae9fd5eb393f:
        """
        Get activation function instance.

        Args:
            activation_function (str): Name of the activation function.
            num_parameters (int): Number of parameters for the activation.

        Returns:
            torch.nn.Module: Activation function instance.

        Raises:
            ValueError: If activation function is unsupported.
        """
        _bfaa82c02e1a = _bfaa82c02e1a._493a55988342()
        if _bfaa82c02e1a == "parametric_relu":
            return _b67e8959a394._c4cd796e566e._03c976876353(_bd08547e92cf=1)
        elif _bfaa82c02e1a == "leaky_relu":
            return _b67e8959a394._c4cd796e566e._2bc989fab9d5(_ec47dfedcc75=_1113cd560423)
        elif _bfaa82c02e1a == "relu":
            return _b67e8959a394._c4cd796e566e._c32f52a1e4d6(_ec47dfedcc75=_1113cd560423)
        raise _5803a67f95ec(f"Unsupported activation function: {_bfaa82c02e1a}")

    def _57e9d23bb2c6(self, _483b9eaee422: _b67e8959a394._483b9eaee422, _1ad1aa7dfe6b: _ad71b2b9a4b4) -> _d64f9d90d0ed:
        """
        Initialize weights for fully connected layers.

        Args:
            device (torch.device): Device to initialize weights on.
            num_fc_layers (int): Number of fully connected layers.

        Raises:
            RuntimeError: If weight initialization fails.
        """
        try:
            def _0eec802dac6a(_24c930d708e7: _b67e8959a394._c4cd796e566e._ae9fd5eb393f) -> _d64f9d90d0ed:
                if _b9795a2f9318(_24c930d708e7, "weight") and _24c930d708e7._6860e6c80c0f._88a78044a571() > 1:
                    _24c930d708e7._09cff1d91d55(_483b9eaee422)
                    _b67e8959a394._c4cd796e566e._ac092a5425d4._957eba196fba(_24c930d708e7._6860e6c80c0f._346ceaab3ed0)
            _b0c4027b0c0e = [_054ac2aae3c1 for _089109334dd0, _054ac2aae3c1 in self._dca8f8cb7bd8._2661b8f72a71() if _089109334dd0._b2db8823638e("fc_")]
            if not _b0c4027b0c0e:
                raise _a6fb1e9c2cdc("No FC layers found for initialization")
            for _054ac2aae3c1 in _b0c4027b0c0e:
                _054ac2aae3c1._2190a96b8b71(_87a81d658d74)
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Failed to initialize weights: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _f416e84631e6(self, _7110d7683b48: _b67e8959a394._bb88bd652b08) -> _e1bbfdd21ec0[_b67e8959a394._bb88bd652b08, _b67e8959a394._bb88bd652b08, _b67e8959a394._bb88bd652b08]:
        try:
            _7110d7683b48 = _7110d7683b48._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
            _bb7eebcf3368 = (_7110d7683b48 != self._11552664579b._48f7433cb543)._de7d642ab686()._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)

            _56dde3b62547 = self._f2ea4cc052be(_7110d7683b48, _bb7eebcf3368)._918d7923f4ef
            _56dde3b62547 = self._934c1e558802(_56dde3b62547)

            _7e894a94ffdf = _b67e8959a394._9b6cc06f6ed1(0.0, _483b9eaee422=self._79fdf038a139)
            _cd9966b92138 = _b67e8959a394._9b6cc06f6ed1(0.0, _483b9eaee422=self._79fdf038a139)

            # compute embedding-level distillation occasionally (same guard you had)
            if self._d0dd3ff4df12 > 0 and (_fc33dfcad1dd(self, "trainer", _d64f9d90d0ed) is not _d64f9d90d0ed) and (self._43ae5566919e._4d449ccc5a2d or self._43ae5566919e._08383e83984a):
                with _b67e8959a394._c96160ab11cf():
                    _506d8d96075a = _8b78898dc050(_7110d7683b48, _bb7eebcf3368)._918d7923f4ef
                _7e894a94ffdf, _cd9966b92138 = self._572f9acccd04(_56dde3b62547, _506d8d96075a, self._79fdf038a139)

                # cache pooled reps and teacher_conf for the aux helper (detach to avoid graphs)
                def _58133cd9f50b(_eec6253e82f5): return _eec6253e82f5._5426641df5e8(_88a78044a571=1) if _eec6253e82f5._88a78044a571() == 3 else _eec6253e82f5
                _88c85f98cfb1 = _b67e8959a394._c4cd796e566e._e8ca3833f599._578f0c59f5ea(_a1b27a47de37(_56dde3b62547), _5a0ee6b94409=2, _88a78044a571=-1, _dac326b0e813=1e-6)
                _530e6c6727dc = _b67e8959a394._c4cd796e566e._e8ca3833f599._578f0c59f5ea(_a1b27a47de37(_506d8d96075a), _5a0ee6b94409=2, _88a78044a571=-1, _dac326b0e813=1e-6)
                _fb800bed445c = _b67e8959a394._c4cd796e566e._e8ca3833f599._d8407b2bf4fe(_88c85f98cfb1, _530e6c6727dc, _88a78044a571=-1)  # [-1,1]
                _c4edeb8523e5 = _fb800bed445c._73faff9fc02e(_b668b01636c7=0.0)  # treat negatives as 0

                self._e6c5a52f15f6 = _88c85f98cfb1._61018ea30ff2()
                self._7ff4d0dd5e59 = _530e6c6727dc._61018ea30ff2()
                self._ae65f41e4331 = _c4edeb8523e5._61018ea30ff2()

            _85d891389491 = self._232c0110b338(_56dde3b62547) if self._2fd298f259a0 else _56dde3b62547
            for _028682c47e93 in _58957850bb58(self._1ad1aa7dfe6b):
                _054ac2aae3c1 = _fc33dfcad1dd(self, f"fc_with_{self._9641858f5c6b}_activation_{_028682c47e93+1}", _d64f9d90d0ed) or _fc33dfcad1dd(self, f"fc_{_028682c47e93+1}")
                _85d891389491 = _054ac2aae3c1(_85d891389491)

            return _85d891389491, _7e894a94ffdf, _cd9966b92138

        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Forward pass failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")


    # def compute_kl_contrastive_loss(self, new_emb: torch.Tensor, old_emb: torch.Tensor, device: str) -> Tuple[torch.Tensor, torch.Tensor]:
    #     """
    #     Compute KL divergence and contrastive loss.

    #     Args:
    #         new_emb (torch.Tensor): New embeddings.
    #         old_emb (torch.Tensor): Old embeddings.
    #         device (str): Device to perform computations on.

    #     Returns:
    #         Tuple[torch.Tensor, torch.Tensor]: KL loss and contrastive loss.

    #     Raises:
    #         RuntimeError: If loss computation fails.
    #     """
    #     try:
    #         new_emb = new_emb.clamp(min=-30, max=30)
    #         old_emb = old_emb.clamp(min=-30, max=30)
    #         T = 2.0
    #         new_emb_log = torch.nn.functional.log_softmax(new_emb / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_emb / T, dim=-1)
    #         latent_dim = new_emb_log.shape[-1]
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / latent_dim
    #         contrastive_loss = 1 - torch.nn.functional.cosine_similarity(new_emb, old_emb, dim=-1).mean()
            
    #         del new_emb, old_emb
    #         if torch.cuda.is_available():
    #             torch.cuda.empty_cache()
    #         return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    #     except Exception as e:
    #         raise RuntimeError(f"KL/contrastive loss computation failed: {str(e)}")

    def _31998b2f2218(self, _9f5e61d88c5a: _b67e8959a394._bb88bd652b08, _6b294f0032f8: _b67e8959a394._bb88bd652b08, _5135a4b30052: _b67e8959a394._bb88bd652b08) -> _ab6612f9203b:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf (if available) for gating w.
        Returns dict with aux_term and diagnostics for logging.
        """
        _483b9eaee422 = _9f5e61d88c5a._483b9eaee422

        # 1) gating w using cached teacher_conf
        _c4edeb8523e5 = _fc33dfcad1dd(self, "_last_teacher_conf", _d64f9d90d0ed)
        if _c4edeb8523e5 is _d64f9d90d0ed:
            _d915dfb1b42a = 0.0
        else:
            _d365b98e3282 = _9b5a9bb69d68(_fc33dfcad1dd(self, "teacher_conf_tau", 0.6))
            _d5d1c9bcc064 = (_c4edeb8523e5 >= _d365b98e3282)._9b5a9bb69d68()
            _d915dfb1b42a = _9b5a9bb69d68(_d5d1c9bcc064._5426641df5e8()._5ea46ae5ec49()._efe9ad6b7064()) if _d5d1c9bcc064._fe0afc99c8d5() > 0 else 0.0

        # apply gating to batch scalars
        _7e894a94ffdf = _9b5a9bb69d68(_6b294f0032f8._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()) * _9b5a9bb69d68(_d915dfb1b42a)
        _cd9966b92138 = _9b5a9bb69d68(_5135a4b30052._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()) * _9b5a9bb69d68(_d915dfb1b42a)

        # 2) EMA autoscale (s(t))
        _1e731941e9a8 = _7e894a94ffdf + _cd9966b92138
        _ac75b5e44741 = _9b5a9bb69d68(_9f5e61d88c5a._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064())

        if _fc33dfcad1dd(self, "ema_task", _d64f9d90d0ed) is _d64f9d90d0ed:
            self._cd0ef3fb96ba = _ac75b5e44741
            self._f427e1af54b4 = _1e731941e9a8 + 1e-12
        else:
            _a40b1d9ed971 = _9b5a9bb69d68(_fc33dfcad1dd(self, "ema_alpha", 0.99))
            self._cd0ef3fb96ba = _a40b1d9ed971 * _9b5a9bb69d68(self._cd0ef3fb96ba) + (1.0 - _a40b1d9ed971) * _ac75b5e44741
            self._f427e1af54b4 = _a40b1d9ed971 * _9b5a9bb69d68(self._f427e1af54b4) + (1.0 - _a40b1d9ed971) * _1e731941e9a8

        _405830f0be23 = _9b5a9bb69d68(_fc33dfcad1dd(self, "distill_target_ratio", 0.3))
        _ee4975d45679 = (_9b5a9bb69d68(self._cd0ef3fb96ba) / (_9b5a9bb69d68(self._f427e1af54b4) + 1e-12)) * _405830f0be23
        _0b1ad77e29d0 = _9b5a9bb69d68(_ee4975d45679)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _520bc1293b28 = _9b5a9bb69d68(_fc33dfcad1dd(self._43ae5566919e, "current_epoch", 0.0)) if _fc33dfcad1dd(self, "trainer", _d64f9d90d0ed) is not _d64f9d90d0ed else 0.0
        _c832b1ff7f92 = _9b5a9bb69d68(_86faf5e42092(1, _fc33dfcad1dd(self._43ae5566919e, "max_epochs", 1))) if _fc33dfcad1dd(self, "trainer", _d64f9d90d0ed) is not _d64f9d90d0ed else 1.0
        _a82b37ff2ddf = _b668b01636c7(_86faf5e42092(_520bc1293b28 / _c832b1ff7f92, 0.0), 1.0)

        _8974b7315615 = _9b5a9bb69d68(_fc33dfcad1dd(self, "kl_warmup_frac", 0.30))
        _12bb64d641ec = _9b5a9bb69d68(_fc33dfcad1dd(self, "kl_base", 0.30)) * _b668b01636c7(_a82b37ff2ddf / _8974b7315615, 1.0)
        _84f3bfca1736 = _9b5a9bb69d68(_fc33dfcad1dd(self, "cos_base", 0.25))
        _1c9afa28678b = _84f3bfca1736 + (0.10 - _84f3bfca1736) * _a82b37ff2ddf

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _1668732e10af = _9b5a9bb69d68(self._ae65f41e4331._5426641df5e8()._5ea46ae5ec49()._efe9ad6b7064()) if _fc33dfcad1dd(self, "_last_teacher_conf", _d64f9d90d0ed) is not _d64f9d90d0ed else 0.0
        if _fc33dfcad1dd(self, "ema_teacher_conf", _d64f9d90d0ed) is _d64f9d90d0ed:
            self._c899dadfb9a3 = _1668732e10af
        else:
            _bb7528f397e5 = _9b5a9bb69d68(_fc33dfcad1dd(self, "teacher_conf_beta", 0.995))
            self._c899dadfb9a3 = _bb7528f397e5 * _9b5a9bb69d68(self._c899dadfb9a3) + (1.0 - _bb7528f397e5) * _1668732e10af

        _19a805c5b2f6 = _9b5a9bb69d68(_fc33dfcad1dd(self, "tau_warn", 0.60))
        _7509ba186544 = _9b5a9bb69d68(_fc33dfcad1dd(self, "tau_detect", 0.20))
        _4de183c24016 = _86faf5e42092(1e-12, (_19a805c5b2f6 - _7509ba186544))
        _f854c26202bb = (_9b5a9bb69d68(self._c899dadfb9a3) - _7509ba186544) / _4de183c24016
        _f854c26202bb = _86faf5e42092(0.0, _b668b01636c7(1.0, _f854c26202bb))

        _3d15d0fd682b = _12bb64d641ec * _f854c26202bb
        _cfb79c2f223e = _1c9afa28678b * _f854c26202bb

        # 5) final aux term (as scalar tensor on device)
        _691265307e78 = (_3d15d0fd682b * _7e894a94ffdf + _cfb79c2f223e * _cd9966b92138) * _9b5a9bb69d68(_0b1ad77e29d0)
        _741279ee3155 = _b67e8959a394._9b6cc06f6ed1(_691265307e78, _483b9eaee422=_483b9eaee422, _5bd382a746d8=_b67e8959a394._ecfe0095f9bf)

        # diagnostics
        _e45644f30050 = {
            "aux_term": _741279ee3155,
            "kl_batch": _6b294f0032f8,
            "contrast_batch": _5135a4b30052,
            "kl_loss_gated": _7e894a94ffdf,
            "contrastive_loss_gated": _cd9966b92138,
            "w_mean": _d915dfb1b42a,
            "aux_scale": _9b5a9bb69d68(_0b1ad77e29d0),
            "lambda_kl_eff": _9b5a9bb69d68(_3d15d0fd682b),
            "lambda_cos_eff": _9b5a9bb69d68(_cfb79c2f223e),
            "teacher_conf_mean": _9b5a9bb69d68(self._c899dadfb9a3),
            "shift_r": _9b5a9bb69d68(_f854c26202bb)
        }
        return _e45644f30050


    def _84f82316f37f(
        self,
        _ba288b472f84: _b67e8959a394._bb88bd652b08,
        _0e715ffcb557: _b67e8959a394._bb88bd652b08,
        _483b9eaee422: _3e4dfb6239c1 = "cpu",
    ) -> _e1bbfdd21ec0[_b67e8959a394._bb88bd652b08, _b67e8959a394._bb88bd652b08]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _0c519022bc4d = 2.0
            # NaN/Inf guard
            _ba288b472f84 = _ba288b472f84._73faff9fc02e(_b668b01636c7=-30, _86faf5e42092=30)
            _0e715ffcb557 = _0e715ffcb557._73faff9fc02e(_b668b01636c7=-30, _86faf5e42092=30)

            # Move once if needed
            _a21c30959ad9 = _b67e8959a394._483b9eaee422(_483b9eaee422)
            if _ba288b472f84._483b9eaee422 != _a21c30959ad9:
                _ba288b472f84 = _ba288b472f84._09cff1d91d55(_483b9eaee422=_a21c30959ad9, _82bb5571cb39=_0f2f94fabf98, _5bd382a746d8=self._854ae0dd5747)
                _0e715ffcb557 = _0e715ffcb557._09cff1d91d55(_483b9eaee422=_a21c30959ad9, _82bb5571cb39=_0f2f94fabf98, _5bd382a746d8=self._854ae0dd5747)

            _16f70f1e959f = _ba288b472f84._aba660c532b5(0)
            _befca2ac8da6 = _ba288b472f84._aba660c532b5(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _1a57e9dbdc0e = (_16f70f1e959f * _befca2ac8da6) > 32_000_000

            if not _1a57e9dbdc0e or _16f70f1e959f <= 8:
                # Direct computation
                _ae879d02c3e5 = _b67e8959a394._c4cd796e566e._e8ca3833f599._a90bd9b9ba10(_ba288b472f84 / _0c519022bc4d, _88a78044a571=-1)
                _ba2ac3f217bf = _b67e8959a394._c4cd796e566e._e8ca3833f599._65e9174c23ad(_0e715ffcb557 / _0c519022bc4d, _88a78044a571=-1)
                _7e894a94ffdf = _b67e8959a394._c4cd796e566e._e8ca3833f599._f4e6f827fe22(_ae879d02c3e5, _ba2ac3f217bf, _1b3a0ececa32="batchmean") * (_0c519022bc4d * _0c519022bc4d)
                _cd9966b92138 = 1 - _b67e8959a394._c4cd796e566e._e8ca3833f599._d8407b2bf4fe(_ba288b472f84, _0e715ffcb557, _88a78044a571=-1)._5426641df5e8()
                return _7e894a94ffdf, _cd9966b92138

            # Chunked mode for large inputs
            _fe5d890d9ee7 = _86faf5e42092(1, _16f70f1e959f // 8)
            _2c45ec5ca531, _9102fa37c905 = [], []

            for _18424842e6b9 in _58957850bb58(0, _16f70f1e959f, _fe5d890d9ee7):
                _78f1a89d095c = _ba288b472f84[_18424842e6b9:_18424842e6b9 + _fe5d890d9ee7]
                _c263f539aed1 = _0e715ffcb557[_18424842e6b9:_18424842e6b9 + _fe5d890d9ee7]

                _ae879d02c3e5 = _b67e8959a394._c4cd796e566e._e8ca3833f599._a90bd9b9ba10(_78f1a89d095c / _0c519022bc4d, _88a78044a571=-1)
                _ba2ac3f217bf = _b67e8959a394._c4cd796e566e._e8ca3833f599._65e9174c23ad(_c263f539aed1 / _0c519022bc4d, _88a78044a571=-1)

                _73134511244e = _b67e8959a394._c4cd796e566e._e8ca3833f599._f4e6f827fe22(_ae879d02c3e5, _ba2ac3f217bf, _1b3a0ececa32="batchmean") * (_0c519022bc4d * _0c519022bc4d)
                _ee587cd29904 = _b67e8959a394._c4cd796e566e._e8ca3833f599._d8407b2bf4fe(_78f1a89d095c, _c263f539aed1, _88a78044a571=-1)._5426641df5e8()
                _62b08c623205 = 1 - _ee587cd29904

                _2c45ec5ca531._36c00d73c69d(_73134511244e)
                _9102fa37c905._36c00d73c69d(_62b08c623205)

            _7e894a94ffdf = _b67e8959a394._3f6ed85f6cfb(_2c45ec5ca531)._5426641df5e8()
            _cd9966b92138 = _b67e8959a394._3f6ed85f6cfb(_9102fa37c905)._5426641df5e8()
            return _7e894a94ffdf, _cd9966b92138

        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"KL/contrastive loss computation failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")


    def _c994c4a50d8e(self, _521313a365b5: _5415586b6f14, _b59e1f870256: _ad71b2b9a4b4) -> _b67e8959a394._bb88bd652b08:
        """
        Perform a training step.

        Args:
            batch (Dict): Batch containing input_ids and labels.
            batch_idx (int): Batch index.

        Returns:
            torch.Tensor: Combined loss.

        Raises:
            RuntimeError: If training step fails.
        """
        try:
            if "input_ids" not in _521313a365b5 or "labels" not in _521313a365b5:
                raise _a6fb1e9c2cdc("Batch missing input_ids or labels")
            _7110d7683b48 = _521313a365b5["input_ids"]._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
            _ee2d4835cac7 = _521313a365b5["labels"]._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
            _16f70f1e959f = _7110d7683b48._aba660c532b5(0)

            _6fc92a88854c, _6b294f0032f8, _5135a4b30052 = self(_7110d7683b48)
            _6fc92a88854c = _6fc92a88854c._2f8007d1727d()._66c160b6a0ac(-1, _6fc92a88854c._25fa029ec1f0[-1])
            _6870d721fcd7 = _ee2d4835cac7._2f8007d1727d()._66c160b6a0ac(-1)

            _9f5e61d88c5a = self._89fb17e88d85['criterion'](_6fc92a88854c, _6870d721fcd7)
            _9f5e61d88c5a = _b67e8959a394._f4a4504ff7c8(_9f5e61d88c5a, _0326eacd8cf5=0.0, _f46cd3b2f126=0.0, _f24862b41ddd=0.0)

            # compute aux using helper (this uses cached teacher_conf from forward)
            _2702bdf7e201 = self._185ae2129095(_9f5e61d88c5a, _6b294f0032f8, _5135a4b30052)
            _741279ee3155 = _2702bdf7e201["aux_term"]

            _775762fbfb8c = _9f5e61d88c5a + _741279ee3155

            # logging (keeps fields to reconstruct equation)
            self._29b445e5a247(
                {
                    "epoch": _9b5a9bb69d68(self._231f4cb6ec7f),
                    "train_task_loss": _9b5a9bb69d68(_9f5e61d88c5a._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()),
                    "train_kl_batch": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("kl_batch", 0.0)._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()) if _e064459892d9(_2702bdf7e201._d84900812a5b("kl_batch", _d64f9d90d0ed), _b67e8959a394._bb88bd652b08) else _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("kl_batch", 0.0)),
                    "train_contrast_batch": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("contrast_batch", 0.0)._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()) if _e064459892d9(_2702bdf7e201._d84900812a5b("contrast_batch", _d64f9d90d0ed), _b67e8959a394._bb88bd652b08) else _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("contrast_batch", 0.0)),
                    "train_w_mean": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("w_mean", 0.0)),
                    "train_aux_scale": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("aux_scale", _2702bdf7e201._d84900812a5b("aux_scale", 0.0))),
                    "train_lambda_kl_eff": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("lambda_kl_eff", 0.0)),
                    "train_lambda_cos_eff": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("lambda_cos_eff", 0.0)),
                    "train_shift_r": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("shift_r", 0.0)),
                    "train_loss": _9b5a9bb69d68(_775762fbfb8c._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()),
                },
                _16f70f1e959f=_16f70f1e959f,
                _3b589e8aee20=_1113cd560423,
                _82bc0ae17ac3=_0f2f94fabf98,
                _c22509dc89f9=_1113cd560423,
                _6417863e1ce5=_0f2f94fabf98,
                _57f065560c36=_0f2f94fabf98,
            )

            return _775762fbfb8c

        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Training step {_b59e1f870256} failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")


    def _2ab7fdec2e70(self) -> _d64f9d90d0ed:
        """
        Handle end of training epoch.

        Raises:
            RuntimeError: If epoch end processing fails.
        """
        try:
            if _b67e8959a394._5794de131c5d._d46d58d540b7():
                _b67e8959a394._5794de131c5d._ee04b124f8e6()
            _e5d1d6d04afe()._15c7fb078394()
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Training epoch end failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _e7fc3aff5400(self, _521313a365b5: _5415586b6f14, _b59e1f870256: _ad71b2b9a4b4) -> _5415586b6f14:
        """
        Perform a validation step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Validation outputs.

        Raises:
            RuntimeError: If validation step fails.
        """
        try:
            if "input_ids" not in _521313a365b5 or "labels" not in _521313a365b5:
                raise _a6fb1e9c2cdc("Batch missing input_ids or labels")
            _7110d7683b48 = _521313a365b5["input_ids"]._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
            _ee2d4835cac7 = _521313a365b5["labels"]._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
            _9f04c07b9f59 = _521313a365b5["lang_codes"]
            _93faf679ff38 = _521313a365b5["sample_ids"]
            _f6acca84dcd2 = _521313a365b5["chunk_ids"]
            _15d415cd28ab = _521313a365b5["word_positions"]
            _16f70f1e959f = _7110d7683b48._aba660c532b5(0)

            _c1fad6733b78, _6b294f0032f8, _5135a4b30052 = self(_7110d7683b48)
            _13789ed178f0 = _c1fad6733b78._2f8007d1727d()._66c160b6a0ac(-1, _c1fad6733b78._25fa029ec1f0[-1])
            _93e9634691dd = _ee2d4835cac7._2f8007d1727d()._66c160b6a0ac(-1)

            _9f5e61d88c5a = self._89fb17e88d85['criterion'](_13789ed178f0, _93e9634691dd)
            _9f5e61d88c5a = _b67e8959a394._f4a4504ff7c8(_9f5e61d88c5a)

            _2702bdf7e201 = self._185ae2129095(_9f5e61d88c5a, _6b294f0032f8, _5135a4b30052)
            _741279ee3155 = _2702bdf7e201["aux_term"]
            _775762fbfb8c = _9f5e61d88c5a + _741279ee3155

            # logging
            self._29b445e5a247(
                {
                    "val_kl_batch": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("kl_batch", 0.0)._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()) if _e064459892d9(_2702bdf7e201._d84900812a5b("kl_batch", _d64f9d90d0ed), _b67e8959a394._bb88bd652b08) else _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("kl_batch", 0.0)),
                    "val_contrast_batch": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("contrast_batch", 0.0)._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()) if _e064459892d9(_2702bdf7e201._d84900812a5b("contrast_batch", _d64f9d90d0ed), _b67e8959a394._bb88bd652b08) else _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("contrast_batch", 0.0)),
                    "val_task_loss": _9b5a9bb69d68(_9f5e61d88c5a._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()),
                    "val_aux_scale": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("aux_scale", 0.0)),
                    "val_w_mean": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("w_mean", 0.0)),
                    "val_lambda_kl_eff": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("lambda_kl_eff", 0.0)),
                    "val_lambda_cos_eff": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("lambda_cos_eff", 0.0)),
                    "val_shift_r": _9b5a9bb69d68(_2702bdf7e201._d84900812a5b("shift_r", 0.0)),
                    "val_loss": _9b5a9bb69d68(_775762fbfb8c._61018ea30ff2()._5ea46ae5ec49()._efe9ad6b7064()),
                },
                _16f70f1e959f=_16f70f1e959f,
                _3b589e8aee20=_1113cd560423,
                _82bc0ae17ac3=_0f2f94fabf98,
                _c22509dc89f9=_1113cd560423,
                _6417863e1ce5=_0f2f94fabf98,
                _57f065560c36=_0f2f94fabf98,
            )

            # per-example preds/labels (preserve your decision_threshold logic)
            _e40211d5f229, _8473d2c5b4dc = [], []
            for _18424842e6b9 in _58957850bb58(_16f70f1e959f):
                _413540d615fe = _c1fad6733b78[_18424842e6b9]
                _e408d0b7020b = _ee2d4835cac7[_18424842e6b9]
                _675b06381dbb = _e408d0b7020b != self._a5d6c68bcdd9
                _651d6c113fe0 = _413540d615fe[_675b06381dbb]
                _431e6abedc33 = _e408d0b7020b[_675b06381dbb]

                if self._9f4b340d739a > 0:
                    _b8b56761787c = _b67e8959a394._c4cd796e566e._e8ca3833f599._65e9174c23ad(_651d6c113fe0, _88a78044a571=-1)
                    _b1b8adb42c9d, _c0e22c6367d9 = _b8b56761787c._86faf5e42092(_88a78044a571=-1)
                    _ceacf8642c0b = _b1b8adb42c9d < self._9f4b340d739a
                    _c0e22c6367d9 = _c0e22c6367d9._ec176466d642() + 1
                    _c0e22c6367d9[_ceacf8642c0b] = 0
                    _431e6abedc33 = _431e6abedc33._ec176466d642() + 1
                    del _b8b56761787c, _b1b8adb42c9d, _ceacf8642c0b
                else:
                    _c0e22c6367d9 = _651d6c113fe0._3ab795b59fcc(_88a78044a571=-1)

                _e40211d5f229._36c00d73c69d(_c0e22c6367d9)
                _8473d2c5b4dc._36c00d73c69d(_431e6abedc33)
                del _651d6c113fe0

            _85d891389491 = {
                "lang_codes": _9f04c07b9f59,
                "preds": _e40211d5f229,
                "labels": _8473d2c5b4dc,
                "sample_ids": _93faf679ff38,
                "chunk_ids": _f6acca84dcd2,
                "word_positions": _15d415cd28ab,
                "val_loss": _775762fbfb8c
            }
            self._f8f73dd100a6._36c00d73c69d(_85d891389491)

            # cleanup
            del _7110d7683b48, _ee2d4835cac7, _c1fad6733b78
            if _b67e8959a394._5794de131c5d._d46d58d540b7():
                _b67e8959a394._5794de131c5d._ee04b124f8e6()
            return _85d891389491

        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Validation step {_b59e1f870256} failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")


    def _1c8fe5c3bc12(self, _1b43e53a9e7a: _5415586b6f14, _1a76bc2a8805: _3e4dfb6239c1, _7fdb8b248e5a: _228671365af9[_ad71b2b9a4b4] = _d64f9d90d0ed) -> _d64f9d90d0ed:
        """
        Save metrics to a CSV file.

        Args:
            metrics_dict (Dict): Metrics to save.
            filename (str): Output filename.
            trial_number (Optional[int]): Trial number for directory.

        Raises:
            RuntimeError: If saving to CSV fails.
        """
        try:
            _8cefd7cbadae = _2eec472af096._831afd30c0bd()
            _edd23a9372f0 = f"trial_{_7fdb8b248e5a}" if _7fdb8b248e5a is not _d64f9d90d0ed else "default"
            # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
            _5a5ca8557f54 = _2eec472af096._5d3867968e49._aaae7b424503(_8cefd7cbadae, "metrics", self._5cd209296a78, _edd23a9372f0)
            _2eec472af096._e98b20433eff(_5a5ca8557f54, _ec8bd870b7cb=_0f2f94fabf98)
            _390a403a3bb8 = _2eec472af096._5d3867968e49._aaae7b424503(_5a5ca8557f54, _1a76bc2a8805)
            _87ab98992ff2 = _d881ac4a11c3._cbfb7214c82a(_1b43e53a9e7a)
            _87ab98992ff2._50e9b72d227c(_390a403a3bb8, _5320dee6228d=_1113cd560423)
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Failed to save metrics to {_1a76bc2a8805}: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _98d2deba97ad(self):
        # pick correct device for this rank
        if _b67e8959a394._5794de131c5d._d46d58d540b7():
            if _b67e8959a394._93ddaf9b189d._9db5bc8c18b6():
                _19f0046558fa = _b67e8959a394._93ddaf9b189d._a7eecf3a7ae3()
            else:
                _19f0046558fa = 0
            _b67e8959a394._5794de131c5d._e0bdef661604(_19f0046558fa)
            self._79fdf038a139 = _b67e8959a394._483b9eaee422(f"cuda:{_19f0046558fa}")
        else:
            self._79fdf038a139 = _b67e8959a394._483b9eaee422("cpu")

        self._2a4f64b4205b()

    def _d4a73c9f99d6(self) -> _d64f9d90d0ed:
        """
        Handle end of validation epoch.

        Raises:
            RuntimeError: If validation epoch end processing fails.
        """
        try:
            if not self._f8f73dd100a6:
                _506e58c33b15("[on_validation_epoch_end] No validation outputs to process.")
                return
            
            _6ba05d7dc60c, _ee2d4835cac7 = self._2dfaede01120(self._f8f73dd100a6)
            _483b9eaee422 = self._44ed23dad1d2['micro_accuracy']._483b9eaee422
            _6ba05d7dc60c, _ee2d4835cac7 = _6ba05d7dc60c._09cff1d91d55(_483b9eaee422), _ee2d4835cac7._09cff1d91d55(_483b9eaee422)
            
            self._44ed23dad1d2['micro_accuracy']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_accuracy']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_precision']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_recall']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_f1']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_accuracy']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_precision']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_recall']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_f1']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['confmat']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            
            _f5b703b876d3 = self._44ed23dad1d2['micro_accuracy']._f56aa056f661()._efe9ad6b7064()
            _40a28b4a2901 = self._44ed23dad1d2['macro_accuracy']._f56aa056f661()._efe9ad6b7064()
            _71f95ea63cec = self._44ed23dad1d2['macro_precision']._f56aa056f661()._efe9ad6b7064()
            _a7824a0611a7 = self._44ed23dad1d2['macro_recall']._f56aa056f661()._efe9ad6b7064()
            _4f7f2381737c = self._44ed23dad1d2['macro_f1']._f56aa056f661()._efe9ad6b7064()
            _fd4499915fba = self._44ed23dad1d2['classwise_accuracy']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _9ab14e349ae4 = self._44ed23dad1d2['classwise_precision']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _95e91e833943 = self._44ed23dad1d2['classwise_recall']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _6090c2d50701 = self._44ed23dad1d2['classwise_f1']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _481e4891cd51 = self._44ed23dad1d2['confmat']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            
            self._baccd87d83fe("val_accuracy", _40a28b4a2901, _57f065560c36=_0f2f94fabf98)
            
            _1b43e53a9e7a = {
                "epoch": [self._231f4cb6ec7f],
                "class_names": [self._792bf15363bc],
                "micro_accuracy": [_f5b703b876d3],
                "macro_accuracy": [_40a28b4a2901],
                "macro_precision": [_71f95ea63cec],
                "macro_recall": [_a7824a0611a7],
                "macro_f1": [_4f7f2381737c],
                "classwise_accuracy": [_fd4499915fba._84c48d33fbd4()],
                "classwise_precision": [_9ab14e349ae4._84c48d33fbd4()],
                "classwise_recall": [_95e91e833943._84c48d33fbd4()],
                "classwise_f1": [_6090c2d50701._84c48d33fbd4()],
                "confusion_matrix": [_481e4891cd51._84c48d33fbd4()],
            }
            self._211831ee8354(_1b43e53a9e7a, f"val_epoch_{self._231f4cb6ec7f}.csv", self._7fdb8b248e5a)
            
            self._44ed23dad1d2['micro_accuracy']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_accuracy']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_precision']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_recall']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_f1']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_accuracy']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_precision']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_recall']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_f1']._ab6c5ae3a213()
            self._44ed23dad1d2['confmat']._ab6c5ae3a213()
            self._f8f73dd100a6._e0ef5c8e7f33()
            
            if _b67e8959a394._5794de131c5d._d46d58d540b7():
                _b67e8959a394._5794de131c5d._ee04b124f8e6()
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Validation epoch end failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _fb11d8b5c49b(self, _6fc92a88854c: _1aa275558dd2[_5415586b6f14]) -> _e1bbfdd21ec0[_b67e8959a394._bb88bd652b08, _b67e8959a394._bb88bd652b08]:
        """
        Reconcile chunked predictions and labels.

        Args:
            outputs (List[Dict]): Validation/test outputs.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: Reconciled predictions and labels.

        Raises:
            RuntimeError: If reconciliation fails.
        """
        try:
            def _690566ff5b8e(_eec6253e82f5):
                if _e064459892d9(_eec6253e82f5, _b67e8959a394._bb88bd652b08):
                    return _eec6253e82f5._61018ea30ff2()._5ea46ae5ec49()._a712e790496d(-1)._84c48d33fbd4()
                if _e064459892d9(_eec6253e82f5, _ab7f0728004e._96e0fdc07be7):
                    return _eec6253e82f5._a712e790496d(-1)._84c48d33fbd4()
                if _e064459892d9(_eec6253e82f5, (_ba675c36e1d2, _5568f2ad3fba)):
                    return _ba675c36e1d2(_eec6253e82f5)
                return [_eec6253e82f5]
            
            _720fa674c2d9, _8af9aa98fadf, _624f52fb8961 = [], [], []
            _632ffcbc95d2 = _6c3349c16883()
            _1879e4c3bf06 = _51f3f18f8abc(_ba675c36e1d2)
            
            for _e45644f30050 in _6fc92a88854c:
                if not _5f91fd21f6a3(_f7ac0df207af in _e45644f30050 for _f7ac0df207af in ["sample_ids", "chunk_ids", "preds", "labels", "word_positions"]):
                    raise _a6fb1e9c2cdc("Output dictionary missing required keys")
                _93faf679ff38 = _e45644f30050["sample_ids"]
                _f6acca84dcd2 = _e45644f30050["chunk_ids"]
                _d734c0f2343b = _e45644f30050["preds"]
                _e74bed296903 = _e45644f30050["labels"]
                _15d415cd28ab = _e45644f30050["word_positions"]
                
                for _18424842e6b9, _61eba9de71c3 in _b8389bdf1e6c(_93faf679ff38):
                    _c4a102803fe8 = _ad71b2b9a4b4(_f6acca84dcd2[_18424842e6b9])
                    if (_61eba9de71c3, _c4a102803fe8) in _632ffcbc95d2:
                        continue
                    _632ffcbc95d2._58114dbee001((_61eba9de71c3, _c4a102803fe8))
                    _ec22cc8609e4 = _0c0ae1a4c67e(_d734c0f2343b[_18424842e6b9])
                    _7617ae0533d8 = _0c0ae1a4c67e(_e74bed296903[_18424842e6b9])
                    _bc88d0a8ed60 = _0c0ae1a4c67e(_15d415cd28ab[_18424842e6b9])
                    
                    if not (_90459ce7f9fd(_bc88d0a8ed60) == _90459ce7f9fd(_ec22cc8609e4) == _90459ce7f9fd(_7617ae0533d8)):
                        _506e58c33b15(
                            f"[WARN] mismatch sid={_61eba9de71c3} cid={_c4a102803fe8}: "
                            f"pos={_90459ce7f9fd(_bc88d0a8ed60)} preds={_90459ce7f9fd(_ec22cc8609e4)} labels={_90459ce7f9fd(_7617ae0533d8)}"
                        )
                        continue
                    
                    if _61eba9de71c3 not in _624f52fb8961:
                        _624f52fb8961._36c00d73c69d(_61eba9de71c3)
                    _1879e4c3bf06[_61eba9de71c3]._36c00d73c69d((_c4a102803fe8, _bc88d0a8ed60, _ec22cc8609e4, _7617ae0533d8))
            
            for _61eba9de71c3 in _624f52fb8961:
                _e3da31d0e16c = _1879e4c3bf06[_61eba9de71c3]
                _e3da31d0e16c._d5f170c0cbea(_f7ac0df207af=lambda _eec6253e82f5: _eec6253e82f5[0])
                _5b3af59259d0 = _51f3f18f8abc(_ba675c36e1d2)
                _d5a783164cad = _51f3f18f8abc(_ba675c36e1d2)
                
                for _c4a102803fe8, _84b25ecc29cd, _6ba05d7dc60c, _ee2d4835cac7 in _e3da31d0e16c:
                    for _68367e549034, _25a7b1bcc8f6, _9205813c16cf in _b22c80a3e0de(_84b25ecc29cd, _6ba05d7dc60c, _ee2d4835cac7):
                        _5b3af59259d0[_ad71b2b9a4b4(_68367e549034)]._36c00d73c69d(_ad71b2b9a4b4(_25a7b1bcc8f6))
                        _d5a783164cad[_ad71b2b9a4b4(_68367e549034)]._36c00d73c69d(_ad71b2b9a4b4(_9205813c16cf))
                
                _402454083c5c, _d19fe3ecc311 = [], []
                for _68367e549034 in _bfec8738f3b8(_5b3af59259d0._bf5f0ffc5c34()):
                    _25a7b1bcc8f6 = _b830de4d9e73(_5b3af59259d0[_68367e549034])._b6193c797581(1)[0][0]
                    _402454083c5c._36c00d73c69d(_25a7b1bcc8f6)
                    _9205813c16cf = _b830de4d9e73(_d5a783164cad[_68367e549034])._b6193c797581(1)[0][0] if _68367e549034 in _d5a783164cad else -100
                    _d19fe3ecc311._36c00d73c69d(_9205813c16cf)
                
                _720fa674c2d9._32b28ab857fa(_402454083c5c)
                _8af9aa98fadf._32b28ab857fa(_d19fe3ecc311)
            
            return _b67e8959a394._9b6cc06f6ed1(_720fa674c2d9, _483b9eaee422="cpu"), _b67e8959a394._9b6cc06f6ed1(_8af9aa98fadf, _483b9eaee422="cpu")
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Chunk reconciliation failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _96127c0f41e5(self, _521313a365b5: _5415586b6f14, _b59e1f870256: _ad71b2b9a4b4) -> _5415586b6f14:
        """
        Perform a test step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Test outputs.

        Raises:
            RuntimeError: If test step fails.
        """
        try:
            if "input_ids" not in _521313a365b5 or "labels" not in _521313a365b5:
                raise _a6fb1e9c2cdc("Batch missing input_ids or labels")
            with _b67e8959a394._c96160ab11cf():
                _7110d7683b48 = _521313a365b5["input_ids"]._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
                _ee2d4835cac7 = _521313a365b5["labels"]._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
                _9f04c07b9f59 = _521313a365b5["lang_codes"]
                _93faf679ff38 = _521313a365b5["sample_ids"]
                _f6acca84dcd2 = _521313a365b5["chunk_ids"]
                _15d415cd28ab = _521313a365b5["word_positions"]
                _16f70f1e959f = _7110d7683b48._aba660c532b5(0)

                _c1fad6733b78, _6b294f0032f8, _5135a4b30052 = self(_7110d7683b48)

                _13789ed178f0 = _c1fad6733b78._2f8007d1727d()._66c160b6a0ac(-1, _c1fad6733b78._25fa029ec1f0[-1])
                _93e9634691dd = _ee2d4835cac7._2f8007d1727d()._66c160b6a0ac(-1)

                _e40211d5f229, _8473d2c5b4dc = [], []
                for _18424842e6b9 in _58957850bb58(_16f70f1e959f):
                    _413540d615fe = _c1fad6733b78[_18424842e6b9]
                    _e408d0b7020b = _ee2d4835cac7[_18424842e6b9]
                    _675b06381dbb = _e408d0b7020b != self._a5d6c68bcdd9
                    _651d6c113fe0 = _413540d615fe[_675b06381dbb]
                    _431e6abedc33 = _e408d0b7020b[_675b06381dbb]

                    if self._9f4b340d739a > 0:
                        _b8b56761787c = _b67e8959a394._c4cd796e566e._e8ca3833f599._65e9174c23ad(_651d6c113fe0, _88a78044a571=-1)
                        _b1b8adb42c9d, _c0e22c6367d9 = _b8b56761787c._86faf5e42092(_88a78044a571=-1)
                        _ceacf8642c0b = _b1b8adb42c9d < self._9f4b340d739a
                        _c0e22c6367d9 = _c0e22c6367d9._ec176466d642() + 1
                        _c0e22c6367d9[_ceacf8642c0b] = 0
                        _431e6abedc33 = _431e6abedc33._ec176466d642() + 1
                        del _b8b56761787c, _b1b8adb42c9d, _ceacf8642c0b
                    else:
                        _c0e22c6367d9 = _651d6c113fe0._3ab795b59fcc(_88a78044a571=-1)

                    _e40211d5f229._36c00d73c69d(_c0e22c6367d9)
                    _8473d2c5b4dc._36c00d73c69d(_431e6abedc33)
                    del _651d6c113fe0

                _85d891389491 = {
                    "lang_codes": _9f04c07b9f59,
                    "preds": _e40211d5f229,
                    "labels": _8473d2c5b4dc,
                    "sample_ids": _93faf679ff38,
                    "chunk_ids": _f6acca84dcd2,
                    "word_positions": _15d415cd28ab,
                }
                self._52ae6f15ff48._36c00d73c69d(_85d891389491)

                # cleanup
                del _7110d7683b48, _ee2d4835cac7, _c1fad6733b78
                if _b67e8959a394._5794de131c5d._d46d58d540b7():
                    _b67e8959a394._5794de131c5d._ee04b124f8e6()
                return _85d891389491
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Test step {_b59e1f870256} failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _cbfb89ee5258(self):
        # pick correct device for this rank
        if _b67e8959a394._5794de131c5d._d46d58d540b7():
            if _b67e8959a394._93ddaf9b189d._9db5bc8c18b6():
                _19f0046558fa = _b67e8959a394._93ddaf9b189d._a7eecf3a7ae3()
            else:
                _19f0046558fa = 0
            _b67e8959a394._5794de131c5d._e0bdef661604(_19f0046558fa)
            self._79fdf038a139 = _b67e8959a394._483b9eaee422(f"cuda:{_19f0046558fa}")
        else:
            self._79fdf038a139 = _b67e8959a394._483b9eaee422("cpu")

        self._2a4f64b4205b()

    def _ec9ae54ee7c2(self) -> _d64f9d90d0ed:
        """
        Handle end of test epoch.

        Raises:
            RuntimeError: If test epoch end processing fails.
        """
        try:
            if not self._52ae6f15ff48:
                _506e58c33b15("[on_test_epoch_end] No test outputs to process.")
                return
            
            _6ba05d7dc60c, _ee2d4835cac7 = self._2dfaede01120(self._52ae6f15ff48)
            _483b9eaee422 = self._44ed23dad1d2['micro_accuracy']._483b9eaee422
            _6ba05d7dc60c, _ee2d4835cac7 = _6ba05d7dc60c._09cff1d91d55(_483b9eaee422), _ee2d4835cac7._09cff1d91d55(_483b9eaee422)
            
            self._44ed23dad1d2['micro_accuracy']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_accuracy']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_precision']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_recall']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['macro_f1']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_accuracy']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_precision']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_recall']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['classwise_f1']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            self._44ed23dad1d2['confmat']._a469d000c8a2(_6ba05d7dc60c, _ee2d4835cac7)
            
            _f5b703b876d3 = self._44ed23dad1d2['micro_accuracy']._f56aa056f661()._efe9ad6b7064()
            _40a28b4a2901 = self._44ed23dad1d2['macro_accuracy']._f56aa056f661()._efe9ad6b7064()
            _71f95ea63cec = self._44ed23dad1d2['macro_precision']._f56aa056f661()._efe9ad6b7064()
            _a7824a0611a7 = self._44ed23dad1d2['macro_recall']._f56aa056f661()._efe9ad6b7064()
            _4f7f2381737c = self._44ed23dad1d2['macro_f1']._f56aa056f661()._efe9ad6b7064()
            _fd4499915fba = self._44ed23dad1d2['classwise_accuracy']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _9ab14e349ae4 = self._44ed23dad1d2['classwise_precision']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _95e91e833943 = self._44ed23dad1d2['classwise_recall']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _6090c2d50701 = self._44ed23dad1d2['classwise_f1']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            _481e4891cd51 = self._44ed23dad1d2['confmat']._f56aa056f661()._5ea46ae5ec49()._62076b8ca668()
            
            self._baccd87d83fe("test_accuracy", _40a28b4a2901, _57f065560c36=_0f2f94fabf98)
            
            _1b43e53a9e7a = {
                "class_names": [self._792bf15363bc],
                "micro_accuracy": [_f5b703b876d3],
                "macro_accuracy": [_40a28b4a2901],
                "macro_precision": [_71f95ea63cec],
                "macro_recall": [_a7824a0611a7],
                "macro_f1": [_4f7f2381737c],
                "classwise_accuracy": [_fd4499915fba._84c48d33fbd4()],
                "classwise_precision": [_9ab14e349ae4._84c48d33fbd4()],
                "classwise_recall": [_95e91e833943._84c48d33fbd4()],
                "classwise_f1": [_6090c2d50701._84c48d33fbd4()],
                "confusion_matrix": [_481e4891cd51._84c48d33fbd4()],
            }
            self._211831ee8354(_1b43e53a9e7a, "test_final.csv", self._7fdb8b248e5a)
            
            self._44ed23dad1d2['micro_accuracy']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_accuracy']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_precision']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_recall']._ab6c5ae3a213()
            self._44ed23dad1d2['macro_f1']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_accuracy']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_precision']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_recall']._ab6c5ae3a213()
            self._44ed23dad1d2['classwise_f1']._ab6c5ae3a213()
            self._44ed23dad1d2['confmat']._ab6c5ae3a213()
            self._52ae6f15ff48._e0ef5c8e7f33()
            
            if _b67e8959a394._5794de131c5d._d46d58d540b7():
                _b67e8959a394._5794de131c5d._ee04b124f8e6()
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Test epoch end failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _13e1b4a2655b(self, _521313a365b5: _5415586b6f14, _b59e1f870256: _ad71b2b9a4b4, _c93c546ee6ee: _ad71b2b9a4b4 = 0) -> _5415586b6f14:
        """
        Perform a prediction step.

        Args:
            batch (Dict): Batch containing input_ids.
            batch_idx (int): Batch index.
            dataloader_idx (int): Dataloader index.

        Returns:
            Dict: Predictions and probabilities.

        Raises:
            RuntimeError: If prediction step fails.
        """
        try:
            if not _521313a365b5 or not _e064459892d9(_521313a365b5, (_ba675c36e1d2, _5568f2ad3fba)) or not _521313a365b5[0]:
                raise _a6fb1e9c2cdc("Invalid batch input for prediction")
            _7110d7683b48 = _521313a365b5[0]._09cff1d91d55(self._79fdf038a139, _82bb5571cb39=_0f2f94fabf98)
            _6fc92a88854c, _, _ = self(_7110d7683b48)
            _6fc92a88854c = _6fc92a88854c._2f8007d1727d()._66c160b6a0ac(-1, _6fc92a88854c._25fa029ec1f0[-1])
            
            if self._9f4b340d739a > 0:
                _b8b56761787c = _b67e8959a394._c4cd796e566e._e8ca3833f599._65e9174c23ad(_6fc92a88854c, _88a78044a571=-1)
                _b1b8adb42c9d, _25a7b1bcc8f6 = _b8b56761787c._86faf5e42092(_88a78044a571=-1)
                _ceacf8642c0b = _b1b8adb42c9d < self._9f4b340d739a
                _3d88f00fc9ee = _25a7b1bcc8f6 + 1
                _3d88f00fc9ee[_ceacf8642c0b] = 0
                _6c834cb005ee = _b67e8959a394._4034b61a8cf3(_6fc92a88854c._aba660c532b5(0), self._e2720c3127bd + 1, _483b9eaee422=_6fc92a88854c._483b9eaee422)
                _6c834cb005ee[~_ceacf8642c0b, 1:] = _b8b56761787c[~_ceacf8642c0b]
                _6c834cb005ee[_ceacf8642c0b, 0] = 1.0
            else:
                _b8b56761787c = _b67e8959a394._c4cd796e566e._e8ca3833f599._65e9174c23ad(_6fc92a88854c, _88a78044a571=-1)
                _3d88f00fc9ee = _b8b56761787c._3ab795b59fcc(_88a78044a571=-1)
                _6c834cb005ee = _b8b56761787c
            
            del _7110d7683b48, _6fc92a88854c
            if _b67e8959a394._5794de131c5d._d46d58d540b7():
                _b67e8959a394._5794de131c5d._ee04b124f8e6()
            return {
                "predictions": _3d88f00fc9ee._5ea46ae5ec49(),
                "probs": _6c834cb005ee._5ea46ae5ec49()
            }
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Predict step {_b59e1f870256} failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _364f9d6ab351(self, _8a3b82e178be) -> _d64f9d90d0ed:
        """
        Handle operations before optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If gradient clipping fails.
        """
        try:
            _b67e8959a394._c4cd796e566e._8267d8217094._cc8c6ca80c8f(self._981cf19a4c8b(), _6c6843ed60a0=1.0)
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Gradient clipping failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _2108a362867e(self, _8a3b82e178be) -> _d64f9d90d0ed:
        """
        Handle operations after optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If parameter clamping fails.
        """
        try:
            for _cb119fd1510e in self._981cf19a4c8b():
                if _cb119fd1510e is not _d64f9d90d0ed:
                    _cb119fd1510e._346ceaab3ed0._addead0dec90(-5, 5)
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Parameter clamping failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _4639d12156a5(self) -> _9b5a9bb69d68:
        """
        Compute gradient norm.

        Returns:
            float: L2 gradient norm.

        Raises:
            RuntimeError: If gradient norm computation fails.
        """
        try:
            _3185352fb81a = 0
            for _cb119fd1510e in self._981cf19a4c8b():
                if _cb119fd1510e._9750b311f776 is not _d64f9d90d0ed:
                    _67cd8aff2e8d = _cb119fd1510e._9750b311f776._61018ea30ff2()._346ceaab3ed0._4b3c98e32d23(2)
                    _3185352fb81a += _67cd8aff2e8d._efe9ad6b7064() ** 2
            return _3185352fb81a ** 0.5
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Gradient norm computation failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")

    def _603e0a7e0b1d(self) -> _5415586b6f14:
        """
        Configure optimizer and learning rate scheduler.

        Returns:
            Dict: Optimizer and scheduler configuration.

        Raises:
            RuntimeError: If optimizer configuration fails.
        """
        try:
            _b6575297f231 = _44426c05c8bd(lambda _5a0ee6b94409: _5a0ee6b94409._9e08c6dcf03a, self._981cf19a4c8b())
            _722e63c1b05e = {
                "adamw": _b67e8959a394._6c559e40179b._8c20940eb078,
                "adamax": _b67e8959a394._6c559e40179b._4a88a4daaa71,
                "adam": _b67e8959a394._6c559e40179b._d1ec01d4e43d,
            }
            _5045b283033c = _722e63c1b05e._d84900812a5b(self._8a93534749df._afad6bb453da())
            if _5045b283033c is _d64f9d90d0ed:
                raise _a6fb1e9c2cdc(f"Unsupported optimizer: {self._8a93534749df}")
            _8a3b82e178be = _5045b283033c(_b6575297f231, _a1c896dac2c2=self._ac51dba121fe._a1c896dac2c2, _9547bbebe3a5=0.001)
            
            _1c9004f413ec = self._43ae5566919e._c832b1ff7f92
            _cc4d1ef7e37f = _9dbc6338cdb4._2711f50db9f0(0.1 * _1c9004f413ec)
            _3b598d9a997c = _b67e8959a394._6c559e40179b._393fd7ba999f._7e443facea52(_8a3b82e178be, _7070e8171d98=lambda _520bc1293b28: (_520bc1293b28 + 1) / _cc4d1ef7e37f)
            _24f4034f67e9 = _b67e8959a394._6c559e40179b._393fd7ba999f._2aa6da66620d(
                _8a3b82e178be,
                _60529b358d9f=_86faf5e42092(1, _1c9004f413ec - _cc4d1ef7e37f),
                _ed4d40349678=2,
                _f5f531454608=1e-6
            )
            _393fd7ba999f = _b67e8959a394._6c559e40179b._393fd7ba999f._f2dc3ba09edc(
                _8a3b82e178be,
                _9d9786d465a0=[_3b598d9a997c, _24f4034f67e9],
                _dc46eb14f30c=[_cc4d1ef7e37f]
            )
            
            return {"optimizer": _8a3b82e178be, "lr_scheduler": {"scheduler": _393fd7ba999f, "interval": "epoch", "monitor": "val_loss"}}
        except _5a4d3b79f5fe as _ff37d74b2c1b:
            raise _a6fb1e9c2cdc(f"Optimizer configuration failed: {_3e4dfb6239c1(_ff37d74b2c1b)}")