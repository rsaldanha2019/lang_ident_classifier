# -*- coding: utf-8 -*-
"""
Language Identification Classifier
Handles language identification using a transformer-based model with custom loss functions.
"""
import math
import os
from collections import _0fb7076be352, _c13375c5e01f
from copy import _f1d7a7c899fa
from typing import _692ece4c23ab, _9dc7f1b0ec0f, _dda8c396b8e2, _3cdf98b89cb5
from _2c71cac0b416 import _bedf00def873

import _936c1dd1dc71 as _78806ca926de
import _2dec7070d8c8 as _28d8e8cf26fc
import _bc63c936f21c as _a7f67741e6d9
import _61af91e84e63
from _92a714362866 import _b49f3be1bd30, _e789035a9de3, _5c5410dc878f, _55b0d9006d90, _a6574fa72f84

from _0e12f0ddc138._333a09a83c03._715a7d1cab5a._dcec0868d3e5 import _60653e6eff40
from _0e12f0ddc138._333a09a83c03._e8dab70aea29._eb98dd30607d import _4b39656f66c0
from _0e12f0ddc138._333a09a83c03._e8dab70aea29._4581c1688e03 import _5906733f6272
from _0e12f0ddc138._333a09a83c03._e8dab70aea29._9a2186dbb043 import _d4e07ff9fbee
from _0e12f0ddc138._333a09a83c03._d99cb5329b5b._401400a2d74d import _76363e932dca

# Only export the classifier as public API
_6f74e7ec8155 = ["LanguageIdentificationClassifier"]

_7222dce84ccb = 'cuda' if _61af91e84e63._9297a007d1d5._64f6ffde7348() else 'cpu'
_d61530796ddc = _4a328dff1530

class _647638040aa6(_78806ca926de._fae1823880cd):
    """Classifier for language identification using a transformer-based model."""

    class _dec180d369c8(_61af91e84e63._d3be613714f8._fed580f2c114):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _73437390995f(self, _eaaeef774707: _a082b0de9a9e, _73eb56fd84cb: _a082b0de9a9e = 64):
            _d8125ea8cf8b()._bc3c5508dd23()
            self._9f080b3836a8 = _61af91e84e63._d3be613714f8._93ef9dcd30fb(_eaaeef774707, _73eb56fd84cb, _4b6275adc58e=_421bcb69e7f5)
            self._ff34f80bd6a7 = _61af91e84e63._d3be613714f8._2fec36e71130(_880b8bcd2070=_3643ccc6e610)
            self._a4bd3a9affff = _61af91e84e63._d3be613714f8._93ef9dcd30fb(_73eb56fd84cb, _eaaeef774707, _4b6275adc58e=_421bcb69e7f5)
            # start adapter near-zero so initial behavior is identity
            _61af91e84e63._d3be613714f8._bde1046ebf2c._c87394ff7c3a(self._a4bd3a9affff._89f2c5756c4a)
            _61af91e84e63._d3be613714f8._bde1046ebf2c._905aa3aab102(self._9f080b3836a8._89f2c5756c4a, _bda12f2b2fdd=math._16690144aaa1(5))

        def _5c8aa057111d(self, _ea34d03ffc1f: _61af91e84e63._be48cc0d1bda) -> _61af91e84e63._be48cc0d1bda:
            # supports x shape (B, L, D) or (B, D)
            if _ea34d03ffc1f._eaaeef774707() == 2:
                _af902460f19b = self._a4bd3a9affff(self._ff34f80bd6a7(self._9f080b3836a8(_ea34d03ffc1f)))
                return _ea34d03ffc1f + _af902460f19b
            _64161d067cb2, _1d65ede381c7, _4fa609cadd7f = _ea34d03ffc1f._82d1a372a435
            _bb83b98195ce = _ea34d03ffc1f._c08f1c12df67(-1, _4fa609cadd7f)                    # (B*L, D)
            _bb83b98195ce = self._a4bd3a9affff(self._ff34f80bd6a7(self._9f080b3836a8(_bb83b98195ce)))  # (B*L, D)
            _bb83b98195ce = _bb83b98195ce._c08f1c12df67(_64161d067cb2, _1d65ede381c7, _4fa609cadd7f)
            return _ea34d03ffc1f + _bb83b98195ce

    class _e702cf3b05f4(_61af91e84e63._d3be613714f8._fed580f2c114):
        """Wraps a module to ensure stable forward pass with clamping and NaN handling."""
        
        def _73437390995f(self, _9bc209bc8994: _61af91e84e63._d3be613714f8._fed580f2c114, _cb0ae217f13a: _6730d2d2e3af = -5.0, _9d86c82edfa8: _6730d2d2e3af = 5.0):
            """
            Initialize the wrapper with a module and clamping bounds.

            Args:
                module (torch.nn.Module): Module to wrap.
                clamp_min (float): Minimum value for clamping.
                clamp_max (float): Maximum value for clamping.

            Raises:
                ValueError: If module is None or invalid.
            """
            if _9bc209bc8994 is _4a328dff1530:
                raise _ba4704ebd752("Module cannot be None")
            _d8125ea8cf8b()._bc3c5508dd23()
            self._9bc209bc8994 = _9bc209bc8994
            self._cb0ae217f13a = _cb0ae217f13a
            self._9d86c82edfa8 = _9d86c82edfa8

        def _5c8aa057111d(self, *_b39c870f18c1, **_875341028739) -> _61af91e84e63._be48cc0d1bda:
            """
            Forward pass with dtype conversion, clamping, and NaN handling.

            Args:
                *inputs: Input tensors or other arguments.
                **kwargs: Keyword arguments for the module.

            Returns:
                torch.Tensor: Processed output tensor.

            Raises:
                RuntimeError: If forward pass fails.
            """
            try:
                _b39c870f18c1 = _4aa51c54a539(
                    _1ac00166a42a._1da1851d7e30(_61af91e84e63._b673a748a22d) if _fcd8eaf6a0af(_1ac00166a42a, _61af91e84e63._be48cc0d1bda) and _1ac00166a42a._8e30217ea01e != _61af91e84e63._b673a748a22d else _1ac00166a42a
                    for _1ac00166a42a in _b39c870f18c1
                )
                _96de6a50f13f = self._9bc209bc8994(*_b39c870f18c1, **_875341028739)
                if _fcd8eaf6a0af(_96de6a50f13f, _61af91e84e63._be48cc0d1bda):
                    _96de6a50f13f = _96de6a50f13f._1da1851d7e30(_61af91e84e63._b673a748a22d)
                    _96de6a50f13f._422831b45d57(self._cb0ae217f13a, self._9d86c82edfa8)
                    _96de6a50f13f = _61af91e84e63._2fff8379bab8(_96de6a50f13f)
                return _96de6a50f13f
            except _a8c2d0c95582 as _e5767feaca6b:
                raise _5a312977fe30(f"Forward pass failed in {self._9bc209bc8994._024f9c7ad564.__name__}: {_de411abc6586(_e5767feaca6b)}")

    def _73437390995f(
        self,
        _5fceca719538: _61af91e84e63._d3be613714f8._fed580f2c114,
        _35e554a9007e: _9dc7f1b0ec0f[_de411abc6586],
        _5ad076cd9fb3: _6730d2d2e3af,
        _e84db2145793: _de411abc6586,
        _1ab2cf820469: _61af91e84e63._be48cc0d1bda,
        _6feff523a007: _692ece4c23ab,
        _d0dd790ed8ef: _a082b0de9a9e,
        _69e137d84c37: _de411abc6586,
        _44ae71f39e64: _a082b0de9a9e,
        _fb2dd8674c5e: _de411abc6586,
        _627fab13f990: _e9e16cdd7fa2,
        _ac4290266ea4: _e9e16cdd7fa2,
        _cecd77e38770: _18e6f484096e,
        _d9e17d53f3cc: _a082b0de9a9e = 20,
        _9810b8b243c8: _dda8c396b8e2[_de411abc6586] = _4a328dff1530,
        _0fe9c908b72a: _dda8c396b8e2[_a082b0de9a9e] = _4a328dff1530,
        _203232df722d: _6730d2d2e3af = 0.0,
        _fc10d41ce29a: _de411abc6586 = _4a328dff1530
    ):
        """
        Initialize the language identification classifier.

        Args:
            pretrained_embedding_model (torch.nn.Module): Pretrained transformer model.
            class_names (List[str]): List of class names.
            lr (float): Learning rate.
            optimizer (str): Optimizer name (adamw, adamax, adam).
            class_weights (torch.Tensor): Class weights for loss computation.
            device_dict (Dict): Device configuration.
            num_backbone_model_units_unfrozen (int): Number of backbone layers to unfreeze.
            loss_type (str): Type of loss function.
            num_fc_layers (int): Number of fully connected layers.
            activation_function_for_layer (str): Activation function for FC layers.
            add_dropout_after_embedding (bool): Whether to add dropout after embedding.
            is_train (bool): Training mode flag.
            tokenizer (object): Tokenizer instance.
            random_seed (int): Random seed for reproducibility.
            pretrained_model_embedding_name (Optional[str]): Name of pretrained embedding model.
            trial_number (Optional[int]): Trial number for experiment tracking.
            decision_threshold (float): Threshold for unknown class detection.
            model_config_name (Optional[str]): model_config_name to create hold metrics in dir

        Raises:
            ValueError: If invalid parameters are provided.
        """
        if not _35e554a9007e:
            raise _ba4704ebd752("class_names cannot be empty")
        if _44ae71f39e64 < 1:
            raise _ba4704ebd752("num_fc_layers must be at least 1")
        if _5fceca719538 is _4a328dff1530:
            raise _ba4704ebd752("pretrained_embedding_model cannot be None")
        if _cecd77e38770 is _4a328dff1530:
            raise _ba4704ebd752("tokenizer cannot be None")
        
        _d8125ea8cf8b()._bc3c5508dd23()
        self._a71b012917a2({
            "lr": _6730d2d2e3af(_5ad076cd9fb3),
            "optimizer": _de411abc6586(_e84db2145793),
            "num_backbone_model_units_unfrozen": _a082b0de9a9e(_d0dd790ed8ef),
            "loss_type": _de411abc6586(_69e137d84c37),
            "num_fc_layers": _a082b0de9a9e(_44ae71f39e64),
            "activation_function_for_layer": _de411abc6586(_fb2dd8674c5e),
            "add_dropout_after_embedding": _e9e16cdd7fa2(_627fab13f990),
            "is_train": _e9e16cdd7fa2(_ac4290266ea4),
            "random_seed": _a082b0de9a9e(_d9e17d53f3cc),
        })
        
        self._d9e17d53f3cc = _d9e17d53f3cc
        _78806ca926de._3dea5fec9eb8(_d9e17d53f3cc, _76c28b94f67a=_3643ccc6e610)
        _61af91e84e63._c7ee85591482(_d9e17d53f3cc)
        if _61af91e84e63._9297a007d1d5._64f6ffde7348():
            _61af91e84e63._9297a007d1d5._a1674e2da315(_d9e17d53f3cc)
        _28d8e8cf26fc.random._86ee31dae69f(_d9e17d53f3cc)
        
        self._0fe9c908b72a = _a082b0de9a9e(_0fe9c908b72a) if _0fe9c908b72a is not _4a328dff1530 else _4a328dff1530
        self._cecd77e38770 = _cecd77e38770
        self._e4ebc744260b = (
            _61af91e84e63._9575589dfd0e(f"cuda:{_6feff523a007['gpu_local_rank']}") if _6feff523a007._35525cc484f1("gpu_local_rank", -1) != -1 else "cpu"
        )
        self._fc10d41ce29a = _fc10d41ce29a
        self._9810b8b243c8 = _9810b8b243c8
        # self.num_classes = len(class_names)
        self._203232df722d = _203232df722d
        self._35e554a9007e = ["unk"] + _35e554a9007e if _203232df722d > 0 else _35e554a9007e
        self._226466dba5a5 = _0a17d5ca9f82(self._35e554a9007e)
        self._1ab2cf820469 = _1ab2cf820469
        self._de6b448180b2 = "multiclass"
        self._d217d261443e = -100
        self._ea6cb5845025 = {}
        self._a68afcab98e4 = {}
        
        self._31090ebc2422 = _5fceca719538
        # self.embedding.requires_grad_(False).to(self.curr_device)
        self._31090ebc2422._aa9012ff3d1c(_421bcb69e7f5)
        _41b5ecf5527c = _76363e932dca()  # bfloat16 or float16
        for _bcd352f8a5fc, _9bc209bc8994 in self._9c4fc9cbc4de():
            if not _58d048dc2281(_848b3f25827d._e43643663781 for _848b3f25827d in _9bc209bc8994._29899e46342e(_c9b56d276412=_421bcb69e7f5)):
                # FROZEN → BF16 (save memory)
                _9bc209bc8994._1da1851d7e30(_8e30217ea01e=_41b5ecf5527c)
            else:
                # TRAINABLE → FP32 (stable grads)
                _9bc209bc8994._1da1851d7e30(_8e30217ea01e=_61af91e84e63._b673a748a22d)
        self._31090ebc2422._1da1851d7e30(self._e4ebc744260b)
        if _1485171d7e16(self._31090ebc2422, "gradient_checkpointing_enable"):
            self._31090ebc2422._3488e305d3fe()
        # determine embedding dim robustly from model config if available
        _fc7f3397fb3b = _f2ae187b80a1(_f2ae187b80a1(self._31090ebc2422, "config", _4a328dff1530), "hidden_size", _4a328dff1530)
        if _fc7f3397fb3b is _4a328dff1530:
            # fallback to common default — change if your model uses a different hidden size
            _fc7f3397fb3b = 768

        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._17d58766a614 = self._453bc965dbcd(_eaaeef774707=_fc7f3397fb3b, _73eb56fd84cb=64)
        for _848b3f25827d in self._17d58766a614._29899e46342e():
            _848b3f25827d._e43643663781 = _3643ccc6e610

        self._44ae71f39e64 = _44ae71f39e64
        self._fb2dd8674c5e = _fb2dd8674c5e
        self._d0dd790ed8ef = _d0dd790ed8ef
        
        if _d0dd790ed8ef > 0:
            for _3a7ce409128e in self._31090ebc2422._adab213f26fb._29899e46342e():
                _3a7ce409128e._e43643663781 = _3643ccc6e610
            if _d0dd790ed8ef > 1:
                for _3a7ce409128e in self._31090ebc2422._028dd418c615._1d104d7522cc[-(_d0dd790ed8ef-1):]._29899e46342e():
                    _3a7ce409128e._e43643663781 = _3643ccc6e610
        
        self._627fab13f990 = _627fab13f990
        if _627fab13f990:
            self._f9c238fb0f79 = _61af91e84e63._d3be613714f8._37f3246dc7db(0.1, _880b8bcd2070=_421bcb69e7f5)
        
        self._57e26cffe221()
        self._c81bfc804447(_69e137d84c37)
        self._e1b7a1ca47f1 = []
        self._5ef953983ce8 = []
        self._876ca67bdb56 = self._3f65bac737e4._e84db2145793._eed5be1560a7()
        # self._setup_metrics()
        
        global _d61530796ddc
        _d61530796ddc = _f1d7a7c899fa(self._31090ebc2422)._08b806e11fe0()
        self._66f63560c51a(self._31090ebc2422)
        self._8618baf4111d(self._e4ebc744260b, _44ae71f39e64)
        self._9e1cabd490f6()

        self._2627c4a2bc88 = 0.99
        self._7c8588d7473e = 0.3
        self._2e18a81209eb = 0.30
        self._f546adb82ce0 = 0.25
        self._f82c5d96b816 = 0.6
        self._87386dfffc64 = 0.995
        self._2b480fbab31d = 0.60
        self._27d237e5e29e = 0.20

    def _3df6cc041e69(self) -> _4a328dff1530:
        """
        Set up fully connected layers with optional activation functions.

        Raises:
            RuntimeError: If layer setup fails.
        """
        try:
            _f263cfce8e25 = self._31090ebc2422._89896f4f6aef._a05670a125b9
            _6e63d4eee769 = self._226466dba5a5
            
            if self._44ae71f39e64 == 1:
                if self._fb2dd8674c5e:
                    _cd1551b9a57f(self, f"fc_with_{self._fb2dd8674c5e}_activation_1", _61af91e84e63._d3be613714f8._2d5968c10eeb(
                        _61af91e84e63._d3be613714f8._93ef9dcd30fb(_f263cfce8e25, _6e63d4eee769),
                        _61af91e84e63._d3be613714f8._9fd58e02c6af(_6e63d4eee769),
                        self._623048abd1d4(self._fb2dd8674c5e, _6e63d4eee769)
                    ))
                else:
                    _cd1551b9a57f(self, "fc_1", _61af91e84e63._d3be613714f8._93ef9dcd30fb(_f263cfce8e25, _6e63d4eee769))
            else:
                _ea77380033b5 = _f263cfce8e25
                for _d86bfd6d93e0 in _5c2ff69034f5(self._44ae71f39e64):
                    _a80803915bc0 = _6e63d4eee769 if _d86bfd6d93e0 + 1 == self._44ae71f39e64 else _ea77380033b5 // 2
                    if self._fb2dd8674c5e and _d86bfd6d93e0 + 1 < self._44ae71f39e64:
                        _cd1551b9a57f(self, f"fc_with_{self._fb2dd8674c5e}_activation_{_d86bfd6d93e0+1}", _61af91e84e63._d3be613714f8._2d5968c10eeb(
                            _61af91e84e63._d3be613714f8._93ef9dcd30fb(_ea77380033b5, _a80803915bc0),
                            _61af91e84e63._d3be613714f8._9fd58e02c6af(_a80803915bc0),
                            self._623048abd1d4(self._fb2dd8674c5e, _a80803915bc0)
                        ))
                    else:
                        _cd1551b9a57f(self, f"fc_{_d86bfd6d93e0+1}", _61af91e84e63._d3be613714f8._93ef9dcd30fb(_ea77380033b5, _a80803915bc0))
                    _ea77380033b5 = _a80803915bc0
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Failed to set up FC layers: {_de411abc6586(_e5767feaca6b)}")

    def _d17779670285(self, _69e137d84c37: _de411abc6586) -> _4a328dff1530:
        """
        Initialize the loss function based on the specified type.

        Args:
            loss_type (str): Type of loss function.

        Raises:
            ValueError: If loss_type is unsupported.
        """
        _69e137d84c37 = _69e137d84c37._eed5be1560a7()
        _eacddb636fe6 = {
            "class_weighted_cross_entropy_loss": _4b39656f66c0,
            "focal_loss": lambda: _5906733f6272(_7265ff078b91=0.25, _9575589dfd0e=self._e4ebc744260b, _408f43582732=self._d217d261443e),
            "class_weighted_focal_loss": lambda: _5906733f6272(_7265ff078b91=self._1ab2cf820469, _9575589dfd0e=self._e4ebc744260b, _408f43582732=self._d217d261443e),
            "class_weighted_focal_loss_with_adaptive_focus_type1": lambda: _d4e07ff9fbee(_7265ff078b91=self._1ab2cf820469, _dbe26e52341f='type1', _9575589dfd0e=self._e4ebc744260b, _408f43582732=self._d217d261443e),
            "class_weighted_focal_loss_with_adaptive_focus_type2": lambda: _d4e07ff9fbee(_7265ff078b91=self._1ab2cf820469, _dbe26e52341f='type2', _9575589dfd0e=self._e4ebc744260b, _408f43582732=self._d217d261443e),
            "class_weighted_focal_loss_with_adaptive_focus_type3": lambda: _d4e07ff9fbee(_7265ff078b91=self._1ab2cf820469, _dbe26e52341f='type3', _9575589dfd0e=self._e4ebc744260b, _408f43582732=self._d217d261443e),
        }
        if _69e137d84c37 not in _eacddb636fe6:
            raise _ba4704ebd752(f"Unsupported loss_type: {_69e137d84c37}")
        self._ea6cb5845025['criterion'] = _eacddb636fe6[_69e137d84c37]()

    # def _setup_metrics(self) -> None:
    #     """
    #     Initialize metrics for evaluation.

    #     Raises:
    #         RuntimeError: If metric setup fails.
    #     """
    #     try:
    #         metrics_params = {
    #             "num_classes": self.num_classes,
    #             "task": self.classification_task,
    #             "ignore_index": self.ignore_idx
    #         }
    #         self.metrics['micro_accuracy'] = Accuracy(average="micro", **metrics_params).to("cpu")
    #         self.metrics['macro_accuracy'] = Accuracy(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_precision'] = Precision(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_recall'] = Recall(average="macro", **metrics_params).to("cpu")
    #         self.metrics['macro_f1'] = F1Score(average="macro", **metrics_params).to("cpu")
    #         self.metrics['classwise_accuracy'] = Accuracy(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_precision'] = Precision(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_recall'] = Recall(average=None, **metrics_params).to("cpu")
    #         self.metrics['classwise_f1'] = F1Score(average=None, **metrics_params).to("cpu")
    #         self.metrics['confmat'] = ConfusionMatrix(normalize=None, **metrics_params).to("cpu")
    #     except Exception as e:
    #         raise RuntimeError(f"Failed to set up metrics: {str(e)}")

    def _fb9840349160(self):
        # rebuild all metrics on the correct device
        self._a68afcab98e4['micro_accuracy'] = _b49f3be1bd30(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52="micro",
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['macro_accuracy'] = _b49f3be1bd30(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52="macro",
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['macro_precision'] = _55b0d9006d90(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52="macro",
            _c6ad17551733=self. _de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['macro_recall'] = _a6574fa72f84(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52="macro",
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['macro_f1'] = _5c5410dc878f(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52="macro",
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['classwise_accuracy'] = _b49f3be1bd30(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52=_4a328dff1530,
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['classwise_precision'] = _55b0d9006d90(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52=_4a328dff1530,
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['classwise_recall'] = _a6574fa72f84(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52=_4a328dff1530,
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['classwise_f1'] = _5c5410dc878f(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _aaec7b0d5a52=_4a328dff1530,
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

        self._a68afcab98e4['confmat'] = _e789035a9de3(
            _226466dba5a5=_0a17d5ca9f82(self._35e554a9007e),
            _c6ad17551733=self._de6b448180b2,
            _408f43582732=self._d217d261443e,
        )._1da1851d7e30(self._e4ebc744260b)

    def _869126187de5(self, _9bc209bc8994: _61af91e84e63._d3be613714f8._fed580f2c114, _3034e75cc9de: _de411abc6586 = "") -> _4a328dff1530:
        """
        Recursively attach hooks to detect NaNs in forward pass.

        Args:
            module (torch.nn.Module): Module to attach hooks to.
            prefix (str): Prefix for module naming.

        Raises:
            RuntimeError: If hook registration fails.
        """
        try:
            for _bcd352f8a5fc, _ea9620def638 in _9bc209bc8994._e9726144d5ab():
                _b96c8f5a1ad4 = f"{_3034e75cc9de}.{_bcd352f8a5fc}" if _3034e75cc9de else _bcd352f8a5fc
                def _a8f993a9edb2(_3e8b9b4dbe4c, _1ac00166a42a, _af902460f19b):
                    if _fcd8eaf6a0af(_af902460f19b, _61af91e84e63._be48cc0d1bda) and _af902460f19b._a4bdceabebb9()._58d048dc2281():
                        _3017c0005445(f"NaN detected in {_b96c8f5a1ad4} ({_3e8b9b4dbe4c._024f9c7ad564.__name__}) (dtype={_af902460f19b._8e30217ea01e})")
                _ea9620def638._632f8b8bf215(_343cdeb65bab)
                self._66f63560c51a(_ea9620def638, _b96c8f5a1ad4)
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Failed to register NaN hooks: {_de411abc6586(_e5767feaca6b)}")

    def _8b2094d5ce9d(self, _9bc209bc8994: _61af91e84e63._d3be613714f8._fed580f2c114) -> _e9e16cdd7fa2:
        """
        Check if a module has trainable parameters.

        Args:
            module (torch.nn.Module): Module to check.

        Returns:
            bool: True if module has trainable parameters.
        """
        return _58d048dc2281(_848b3f25827d._e43643663781 for _848b3f25827d in _9bc209bc8994._29899e46342e())

    def _70c031cce595(self) -> _4a328dff1530:
        """
        Convert specific layers to float32 and wrap them for stability.

        Raises:
            RuntimeError: If layer wrapping fails.
        """
        try:
            _737cf219094b = []
            for _bcd352f8a5fc, _9bc209bc8994 in self._9c4fc9cbc4de():
                if not self._c93f9f2243cd(_9bc209bc8994):
                    continue
                _c58155a57e72 = "norm" in _bcd352f8a5fc._9a1fd12d08ea() or _fcd8eaf6a0af(_9bc209bc8994, _61af91e84e63._d3be613714f8._9fd58e02c6af)
                _de46f6690d3b = _58d048dc2281(_ff34f80bd6a7 in _bcd352f8a5fc._9a1fd12d08ea() for _ff34f80bd6a7 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"])
                _bd2069c593f5 = "dropout" in _bcd352f8a5fc._9a1fd12d08ea() or _fcd8eaf6a0af(_9bc209bc8994, _61af91e84e63._d3be613714f8._37f3246dc7db)
                _c8f4da9d6f87 = "attention" in _bcd352f8a5fc._9a1fd12d08ea()
                if _c58155a57e72:
                    _9bc209bc8994._dc237ad6daa1 = 1e-5
                if _c58155a57e72 or _de46f6690d3b or _c8f4da9d6f87:
                    _9bc209bc8994._1da1851d7e30(_61af91e84e63._b673a748a22d)
                    if not _fcd8eaf6a0af(_9bc209bc8994, _417c79747300._19d71e3ab24e):
                        _737cf219094b._e19b38b20635((_bcd352f8a5fc, _417c79747300._19d71e3ab24e(_9bc209bc8994)))
            for _bcd352f8a5fc, _9c254d8fe8ed in _737cf219094b:
                _e61716cf1dcb, _30692de71441 = self._341254759ba5(_bcd352f8a5fc)
                if _e61716cf1dcb is not _4a328dff1530:
                    _cd1551b9a57f(_e61716cf1dcb, _30692de71441, _9c254d8fe8ed)
                else:
                    raise _5a312977fe30(f"Cannot find parent module for {_bcd352f8a5fc}")
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Failed to fix embedding layers: {_de411abc6586(_e5767feaca6b)}")

    def _8d7cc984732f(self, _00e29bc83c07: _de411abc6586) -> _3cdf98b89cb5[_dda8c396b8e2[_61af91e84e63._d3be613714f8._fed580f2c114], _dda8c396b8e2[_de411abc6586]]:
        """
        Find parent module and attribute name for a given module path.

        Args:
            module_name (str): Full module path.

        Returns:
            Tuple[Optional[torch.nn.Module], Optional[str]]: Parent module and attribute name.

        Raises:
            RuntimeError: If module path is invalid.
        """
        try:
            _4db1b00d90fa = _00e29bc83c07._11e2938258db('.')
            _e61716cf1dcb = self
            for _bf4afe8c4239 in _4db1b00d90fa[:-1]:
                _e61716cf1dcb = _f2ae187b80a1(_e61716cf1dcb, _bf4afe8c4239, _4a328dff1530)
                if _e61716cf1dcb is _4a328dff1530:
                    raise _5a312977fe30(f"Invalid module path: {_00e29bc83c07}")
            return _e61716cf1dcb, _4db1b00d90fa[-1]
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Failed to get parent and attribute for {_00e29bc83c07}: {_de411abc6586(_e5767feaca6b)}")

    def _a6c56e34f306(self, _2c9af977b6ce: _de411abc6586, _730e635bbdd6: _a082b0de9a9e) -> _61af91e84e63._d3be613714f8._fed580f2c114:
        """
        Get activation function instance.

        Args:
            activation_function (str): Name of the activation function.
            num_parameters (int): Number of parameters for the activation.

        Returns:
            torch.nn.Module: Activation function instance.

        Raises:
            ValueError: If activation function is unsupported.
        """
        _2c9af977b6ce = _2c9af977b6ce._eed5be1560a7()
        if _2c9af977b6ce == "parametric_relu":
            return _61af91e84e63._d3be613714f8._8e02cbcf5a31(_730e635bbdd6=1)
        elif _2c9af977b6ce == "leaky_relu":
            return _61af91e84e63._d3be613714f8._2f9faa4fceaa(_880b8bcd2070=_421bcb69e7f5)
        elif _2c9af977b6ce == "relu":
            return _61af91e84e63._d3be613714f8._2fec36e71130(_880b8bcd2070=_421bcb69e7f5)
        raise _ba4704ebd752(f"Unsupported activation function: {_2c9af977b6ce}")

    def _5deb45bdc77e(self, _9575589dfd0e: _61af91e84e63._9575589dfd0e, _44ae71f39e64: _a082b0de9a9e) -> _4a328dff1530:
        """
        Initialize weights for fully connected layers.

        Args:
            device (torch.device): Device to initialize weights on.
            num_fc_layers (int): Number of fully connected layers.

        Raises:
            RuntimeError: If weight initialization fails.
        """
        try:
            def _72f643a2f83c(_c130b640f775: _61af91e84e63._d3be613714f8._fed580f2c114) -> _4a328dff1530:
                if _1485171d7e16(_c130b640f775, "weight") and _c130b640f775._89f2c5756c4a._eaaeef774707() > 1:
                    _c130b640f775._1da1851d7e30(_9575589dfd0e)
                    _61af91e84e63._d3be613714f8._bde1046ebf2c._87794cf1373e(_c130b640f775._89f2c5756c4a._c4ede1fadde9)
            _a362c4bedebe = [_1d104d7522cc for _bcd352f8a5fc, _1d104d7522cc in self._3526a020ea0d._75005ad2e3aa() if _bcd352f8a5fc._80142deb828b("fc_")]
            if not _a362c4bedebe:
                raise _5a312977fe30("No FC layers found for initialization")
            for _1d104d7522cc in _a362c4bedebe:
                _1d104d7522cc._8d5fe54327f1(_bd20c41d1b09)
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Failed to initialize weights: {_de411abc6586(_e5767feaca6b)}")

    def _5c8aa057111d(self, _864cbfe63652: _61af91e84e63._be48cc0d1bda) -> _3cdf98b89cb5[_61af91e84e63._be48cc0d1bda, _61af91e84e63._be48cc0d1bda, _61af91e84e63._be48cc0d1bda]:
        try:
            _864cbfe63652 = _864cbfe63652._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
            _f291152efc64 = (_864cbfe63652 != self._cecd77e38770._0ace16b48cb4)._dfbbbe1e8076()._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)

            _1bee25ea6069 = self._31090ebc2422(_864cbfe63652, _f291152efc64)._5ef50ca31426
            _1bee25ea6069 = self._17d58766a614(_1bee25ea6069)

            _f7a3bbe00b5a = _61af91e84e63._33b87a7d8664(0.0, _9575589dfd0e=self._e4ebc744260b)
            _dcebfc469acd = _61af91e84e63._33b87a7d8664(0.0, _9575589dfd0e=self._e4ebc744260b)

            # compute embedding-level distillation occasionally (same guard you had)
            if self._d0dd790ed8ef > 0 and (_f2ae187b80a1(self, "trainer", _4a328dff1530) is not _4a328dff1530) and (self._1ee1389e80ab._66329b7d2046 or self._1ee1389e80ab._62b661be58d4):
                with _61af91e84e63._e9c99322e85e():
                    _db567c00cb08 = _d61530796ddc(_864cbfe63652, _f291152efc64)._5ef50ca31426
                _f7a3bbe00b5a, _dcebfc469acd = self._b1eb504fc471(_1bee25ea6069, _db567c00cb08, self._e4ebc744260b)

                # cache pooled reps and teacher_conf for the aux helper (detach to avoid graphs)
                def _6700c7c1dd1f(_ea34d03ffc1f): return _ea34d03ffc1f._b41e01a7dfd9(_eaaeef774707=1) if _ea34d03ffc1f._eaaeef774707() == 3 else _ea34d03ffc1f
                _0bef36d58f48 = _61af91e84e63._d3be613714f8._57c29a175835._f5bc4db2cf14(_50980117c47c(_1bee25ea6069), _848b3f25827d=2, _eaaeef774707=-1, _dc237ad6daa1=1e-6)
                _0c4cb0d8a813 = _61af91e84e63._d3be613714f8._57c29a175835._f5bc4db2cf14(_50980117c47c(_db567c00cb08), _848b3f25827d=2, _eaaeef774707=-1, _dc237ad6daa1=1e-6)
                _85cdaa015daf = _61af91e84e63._d3be613714f8._57c29a175835._2ad3a2c9e7ab(_0bef36d58f48, _0c4cb0d8a813, _eaaeef774707=-1)  # [-1,1]
                _d2b2f9bf7d88 = _85cdaa015daf._30fb826dfba5(_650f92407ed1=0.0)  # treat negatives as 0

                self._5a5dc5fa6bdc = _0bef36d58f48._c16a3210f423()
                self._582f0554a1c0 = _0c4cb0d8a813._c16a3210f423()
                self._7763e4149d12 = _d2b2f9bf7d88._c16a3210f423()

            _96de6a50f13f = self._f9c238fb0f79(_1bee25ea6069) if self._627fab13f990 else _1bee25ea6069
            for _d86bfd6d93e0 in _5c2ff69034f5(self._44ae71f39e64):
                _1d104d7522cc = _f2ae187b80a1(self, f"fc_with_{self._fb2dd8674c5e}_activation_{_d86bfd6d93e0+1}", _4a328dff1530) or _f2ae187b80a1(self, f"fc_{_d86bfd6d93e0+1}")
                _96de6a50f13f = _1d104d7522cc(_96de6a50f13f)

            return _96de6a50f13f, _f7a3bbe00b5a, _dcebfc469acd

        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Forward pass failed: {_de411abc6586(_e5767feaca6b)}")


    # def compute_kl_contrastive_loss(self, new_emb: torch.Tensor, old_emb: torch.Tensor, device: str) -> Tuple[torch.Tensor, torch.Tensor]:
    #     """
    #     Compute KL divergence and contrastive loss.

    #     Args:
    #         new_emb (torch.Tensor): New embeddings.
    #         old_emb (torch.Tensor): Old embeddings.
    #         device (str): Device to perform computations on.

    #     Returns:
    #         Tuple[torch.Tensor, torch.Tensor]: KL loss and contrastive loss.

    #     Raises:
    #         RuntimeError: If loss computation fails.
    #     """
    #     try:
    #         new_emb = new_emb.clamp(min=-30, max=30)
    #         old_emb = old_emb.clamp(min=-30, max=30)
    #         T = 2.0
    #         new_emb_log = torch.nn.functional.log_softmax(new_emb / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_emb / T, dim=-1)
    #         latent_dim = new_emb_log.shape[-1]
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / latent_dim
    #         contrastive_loss = 1 - torch.nn.functional.cosine_similarity(new_emb, old_emb, dim=-1).mean()
            
    #         del new_emb, old_emb
    #         if torch.cuda.is_available():
    #             torch.cuda.empty_cache()
    #         return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    #     except Exception as e:
    #         raise RuntimeError(f"KL/contrastive loss computation failed: {str(e)}")

    def _fb029c7402fc(self, _1f391891f8fe: _61af91e84e63._be48cc0d1bda, _6061cd65b978: _61af91e84e63._be48cc0d1bda, _d199e7b9062c: _61af91e84e63._be48cc0d1bda) -> _60ed9f8d167c:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf (if available) for gating w.
        Returns dict with aux_term and diagnostics for logging.
        """
        _9575589dfd0e = _1f391891f8fe._9575589dfd0e

        # 1) gating w using cached teacher_conf
        _d2b2f9bf7d88 = _f2ae187b80a1(self, "_last_teacher_conf", _4a328dff1530)
        if _d2b2f9bf7d88 is _4a328dff1530:
            _b00fe55b7935 = 0.0
        else:
            _09a7350ec4c9 = _6730d2d2e3af(_f2ae187b80a1(self, "teacher_conf_tau", 0.6))
            _525f70342e07 = (_d2b2f9bf7d88 >= _09a7350ec4c9)._6730d2d2e3af()
            _b00fe55b7935 = _6730d2d2e3af(_525f70342e07._b41e01a7dfd9()._dad78c684f3a()._faadbf227818()) if _525f70342e07._2ea874dbc2cf() > 0 else 0.0

        # apply gating to batch scalars
        _f7a3bbe00b5a = _6730d2d2e3af(_6061cd65b978._c16a3210f423()._dad78c684f3a()._faadbf227818()) * _6730d2d2e3af(_b00fe55b7935)
        _dcebfc469acd = _6730d2d2e3af(_d199e7b9062c._c16a3210f423()._dad78c684f3a()._faadbf227818()) * _6730d2d2e3af(_b00fe55b7935)

        # 2) EMA autoscale (s(t))
        _73fbd5d35880 = _f7a3bbe00b5a + _dcebfc469acd
        _cf51e70c89d6 = _6730d2d2e3af(_1f391891f8fe._c16a3210f423()._dad78c684f3a()._faadbf227818())

        if _f2ae187b80a1(self, "ema_task", _4a328dff1530) is _4a328dff1530:
            self._3d15f48ad5a4 = _cf51e70c89d6
            self._980407c57d28 = _73fbd5d35880 + 1e-12
        else:
            _7265ff078b91 = _6730d2d2e3af(_f2ae187b80a1(self, "ema_alpha", 0.99))
            self._3d15f48ad5a4 = _7265ff078b91 * _6730d2d2e3af(self._3d15f48ad5a4) + (1.0 - _7265ff078b91) * _cf51e70c89d6
            self._980407c57d28 = _7265ff078b91 * _6730d2d2e3af(self._980407c57d28) + (1.0 - _7265ff078b91) * _73fbd5d35880

        _2903a9ce1322 = _6730d2d2e3af(_f2ae187b80a1(self, "distill_target_ratio", 0.3))
        _98749d555f79 = (_6730d2d2e3af(self._3d15f48ad5a4) / (_6730d2d2e3af(self._980407c57d28) + 1e-12)) * _2903a9ce1322
        _5d84d65ca505 = _6730d2d2e3af(_98749d555f79)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _ca8d32c36492 = _6730d2d2e3af(_f2ae187b80a1(self._1ee1389e80ab, "current_epoch", 0.0)) if _f2ae187b80a1(self, "trainer", _4a328dff1530) is not _4a328dff1530 else 0.0
        _3db3e560ff89 = _6730d2d2e3af(_fdd31b0a4a89(1, _f2ae187b80a1(self._1ee1389e80ab, "max_epochs", 1))) if _f2ae187b80a1(self, "trainer", _4a328dff1530) is not _4a328dff1530 else 1.0
        _4177fb2930a9 = _650f92407ed1(_fdd31b0a4a89(_ca8d32c36492 / _3db3e560ff89, 0.0), 1.0)

        _1256012b7d09 = _6730d2d2e3af(_f2ae187b80a1(self, "kl_warmup_frac", 0.30))
        _2a079c793388 = _6730d2d2e3af(_f2ae187b80a1(self, "kl_base", 0.30)) * _650f92407ed1(_4177fb2930a9 / _1256012b7d09, 1.0)
        _f546adb82ce0 = _6730d2d2e3af(_f2ae187b80a1(self, "cos_base", 0.25))
        _6c771fd6994a = _f546adb82ce0 + (0.10 - _f546adb82ce0) * _4177fb2930a9

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _b22081fe1956 = _6730d2d2e3af(self._7763e4149d12._b41e01a7dfd9()._dad78c684f3a()._faadbf227818()) if _f2ae187b80a1(self, "_last_teacher_conf", _4a328dff1530) is not _4a328dff1530 else 0.0
        if _f2ae187b80a1(self, "ema_teacher_conf", _4a328dff1530) is _4a328dff1530:
            self._78af6feda95e = _b22081fe1956
        else:
            _64161d067cb2 = _6730d2d2e3af(_f2ae187b80a1(self, "teacher_conf_beta", 0.995))
            self._78af6feda95e = _64161d067cb2 * _6730d2d2e3af(self._78af6feda95e) + (1.0 - _64161d067cb2) * _b22081fe1956

        _2b480fbab31d = _6730d2d2e3af(_f2ae187b80a1(self, "tau_warn", 0.60))
        _27d237e5e29e = _6730d2d2e3af(_f2ae187b80a1(self, "tau_detect", 0.20))
        _c4eaf01cbf84 = _fdd31b0a4a89(1e-12, (_2b480fbab31d - _27d237e5e29e))
        _ecf1379392a0 = (_6730d2d2e3af(self._78af6feda95e) - _27d237e5e29e) / _c4eaf01cbf84
        _ecf1379392a0 = _fdd31b0a4a89(0.0, _650f92407ed1(1.0, _ecf1379392a0))

        _ae7b140d5f3b = _2a079c793388 * _ecf1379392a0
        _a7ed523d5149 = _6c771fd6994a * _ecf1379392a0

        # 5) final aux term (as scalar tensor on device)
        _a3c4f06c0608 = (_ae7b140d5f3b * _f7a3bbe00b5a + _a7ed523d5149 * _dcebfc469acd) * _6730d2d2e3af(_5d84d65ca505)
        _c88447649dea = _61af91e84e63._33b87a7d8664(_a3c4f06c0608, _9575589dfd0e=_9575589dfd0e, _8e30217ea01e=_61af91e84e63._b673a748a22d)

        # diagnostics
        _af902460f19b = {
            "aux_term": _c88447649dea,
            "kl_batch": _6061cd65b978,
            "contrast_batch": _d199e7b9062c,
            "kl_loss_gated": _f7a3bbe00b5a,
            "contrastive_loss_gated": _dcebfc469acd,
            "w_mean": _b00fe55b7935,
            "aux_scale": _6730d2d2e3af(_5d84d65ca505),
            "lambda_kl_eff": _6730d2d2e3af(_ae7b140d5f3b),
            "lambda_cos_eff": _6730d2d2e3af(_a7ed523d5149),
            "teacher_conf_mean": _6730d2d2e3af(self._78af6feda95e),
            "shift_r": _6730d2d2e3af(_ecf1379392a0)
        }
        return _af902460f19b


    def _6f35eedc3609(
        self,
        _d7bd4b1f353b: _61af91e84e63._be48cc0d1bda,
        _af90ba75e176: _61af91e84e63._be48cc0d1bda,
        _9575589dfd0e: _de411abc6586 = "cpu",
    ) -> _3cdf98b89cb5[_61af91e84e63._be48cc0d1bda, _61af91e84e63._be48cc0d1bda]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _37e1bb9e9b85 = 2.0
            # NaN/Inf guard
            _d7bd4b1f353b = _d7bd4b1f353b._30fb826dfba5(_650f92407ed1=-30, _fdd31b0a4a89=30)
            _af90ba75e176 = _af90ba75e176._30fb826dfba5(_650f92407ed1=-30, _fdd31b0a4a89=30)

            # Move once if needed
            _b096b65e5d26 = _61af91e84e63._9575589dfd0e(_9575589dfd0e)
            if _d7bd4b1f353b._9575589dfd0e != _b096b65e5d26:
                _d7bd4b1f353b = _d7bd4b1f353b._1da1851d7e30(_9575589dfd0e=_b096b65e5d26, _0a144ca3ba8f=_3643ccc6e610, _8e30217ea01e=self._6fc240f0599a)
                _af90ba75e176 = _af90ba75e176._1da1851d7e30(_9575589dfd0e=_b096b65e5d26, _0a144ca3ba8f=_3643ccc6e610, _8e30217ea01e=self._6fc240f0599a)

            _51e5cf723019 = _d7bd4b1f353b._93ae794a1d43(0)
            _fc7f3397fb3b = _d7bd4b1f353b._93ae794a1d43(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _2c81e4df93aa = (_51e5cf723019 * _fc7f3397fb3b) > 32_000_000

            if not _2c81e4df93aa or _51e5cf723019 <= 8:
                # Direct computation
                _e631bebaeff0 = _61af91e84e63._d3be613714f8._57c29a175835._57a5e5bb47a7(_d7bd4b1f353b / _37e1bb9e9b85, _eaaeef774707=-1)
                _3aae6b45fb74 = _61af91e84e63._d3be613714f8._57c29a175835._17641d043033(_af90ba75e176 / _37e1bb9e9b85, _eaaeef774707=-1)
                _f7a3bbe00b5a = _61af91e84e63._d3be613714f8._57c29a175835._6abba5efe836(_e631bebaeff0, _3aae6b45fb74, _58cb96e362ff="batchmean") * (_37e1bb9e9b85 * _37e1bb9e9b85)
                _dcebfc469acd = 1 - _61af91e84e63._d3be613714f8._57c29a175835._2ad3a2c9e7ab(_d7bd4b1f353b, _af90ba75e176, _eaaeef774707=-1)._b41e01a7dfd9()
                return _f7a3bbe00b5a, _dcebfc469acd

            # Chunked mode for large inputs
            _a7d04fdaf1f1 = _fdd31b0a4a89(1, _51e5cf723019 // 8)
            _f1a2d13368d6, _0da043d90915 = [], []

            for _aed40bea82e8 in _5c2ff69034f5(0, _51e5cf723019, _a7d04fdaf1f1):
                _110c2e4f73ea = _d7bd4b1f353b[_aed40bea82e8:_aed40bea82e8 + _a7d04fdaf1f1]
                _7043a9ecf261 = _af90ba75e176[_aed40bea82e8:_aed40bea82e8 + _a7d04fdaf1f1]

                _e631bebaeff0 = _61af91e84e63._d3be613714f8._57c29a175835._57a5e5bb47a7(_110c2e4f73ea / _37e1bb9e9b85, _eaaeef774707=-1)
                _3aae6b45fb74 = _61af91e84e63._d3be613714f8._57c29a175835._17641d043033(_7043a9ecf261 / _37e1bb9e9b85, _eaaeef774707=-1)

                _92f7eca27510 = _61af91e84e63._d3be613714f8._57c29a175835._6abba5efe836(_e631bebaeff0, _3aae6b45fb74, _58cb96e362ff="batchmean") * (_37e1bb9e9b85 * _37e1bb9e9b85)
                _aa6212f85bb2 = _61af91e84e63._d3be613714f8._57c29a175835._2ad3a2c9e7ab(_110c2e4f73ea, _7043a9ecf261, _eaaeef774707=-1)._b41e01a7dfd9()
                _1b5db2fbdd57 = 1 - _aa6212f85bb2

                _f1a2d13368d6._e19b38b20635(_92f7eca27510)
                _0da043d90915._e19b38b20635(_1b5db2fbdd57)

            _f7a3bbe00b5a = _61af91e84e63._b4310951c1ec(_f1a2d13368d6)._b41e01a7dfd9()
            _dcebfc469acd = _61af91e84e63._b4310951c1ec(_0da043d90915)._b41e01a7dfd9()
            return _f7a3bbe00b5a, _dcebfc469acd

        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"KL/contrastive loss computation failed: {_de411abc6586(_e5767feaca6b)}")


    def _ebfc2d8c32a5(self, _2fd53825a757: _692ece4c23ab, _d2323a8f2915: _a082b0de9a9e) -> _61af91e84e63._be48cc0d1bda:
        """
        Perform a training step.

        Args:
            batch (Dict): Batch containing input_ids and labels.
            batch_idx (int): Batch index.

        Returns:
            torch.Tensor: Combined loss.

        Raises:
            RuntimeError: If training step fails.
        """
        try:
            if "input_ids" not in _2fd53825a757 or "labels" not in _2fd53825a757:
                raise _5a312977fe30("Batch missing input_ids or labels")
            _864cbfe63652 = _2fd53825a757["input_ids"]._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
            _5563223a3d99 = _2fd53825a757["labels"]._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
            _51e5cf723019 = _864cbfe63652._93ae794a1d43(0)

            _814ff968da45, _6061cd65b978, _d199e7b9062c = self(_864cbfe63652)
            _814ff968da45 = _814ff968da45._4c16fd2b227c()._c08f1c12df67(-1, _814ff968da45._82d1a372a435[-1])
            _d4d45a9dbb3f = _5563223a3d99._4c16fd2b227c()._c08f1c12df67(-1)

            _1f391891f8fe = self._ea6cb5845025['criterion'](_814ff968da45, _d4d45a9dbb3f)
            _1f391891f8fe = _61af91e84e63._2fff8379bab8(_1f391891f8fe, _9f2757d3ec32=0.0, _24f626e7795f=0.0, _80420c9c7a82=0.0)

            # compute aux using helper (this uses cached teacher_conf from forward)
            _f8c09d14c7f5 = self._668c622ed52f(_1f391891f8fe, _6061cd65b978, _d199e7b9062c)
            _c88447649dea = _f8c09d14c7f5["aux_term"]

            _1b04ae6cf3b6 = _1f391891f8fe + _c88447649dea

            # logging (keeps fields to reconstruct equation)
            self._442fea3138f4(
                {
                    "epoch": _6730d2d2e3af(self._657588131e79),
                    "train_task_loss": _6730d2d2e3af(_1f391891f8fe._c16a3210f423()._dad78c684f3a()._faadbf227818()),
                    "train_kl_batch": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("kl_batch", 0.0)._c16a3210f423()._dad78c684f3a()._faadbf227818()) if _fcd8eaf6a0af(_f8c09d14c7f5._35525cc484f1("kl_batch", _4a328dff1530), _61af91e84e63._be48cc0d1bda) else _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("kl_batch", 0.0)),
                    "train_contrast_batch": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("contrast_batch", 0.0)._c16a3210f423()._dad78c684f3a()._faadbf227818()) if _fcd8eaf6a0af(_f8c09d14c7f5._35525cc484f1("contrast_batch", _4a328dff1530), _61af91e84e63._be48cc0d1bda) else _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("contrast_batch", 0.0)),
                    "train_w_mean": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("w_mean", 0.0)),
                    "train_aux_scale": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("aux_scale", _f8c09d14c7f5._35525cc484f1("aux_scale", 0.0))),
                    "train_lambda_kl_eff": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("lambda_kl_eff", 0.0)),
                    "train_lambda_cos_eff": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("lambda_cos_eff", 0.0)),
                    "train_shift_r": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("shift_r", 0.0)),
                    "train_loss": _6730d2d2e3af(_1b04ae6cf3b6._c16a3210f423()._dad78c684f3a()._faadbf227818()),
                },
                _51e5cf723019=_51e5cf723019,
                _f486b48b4f8e=_421bcb69e7f5,
                _401559a5eb78=_3643ccc6e610,
                _5d87e95d4ef8=_421bcb69e7f5,
                _b32aa8bd0e76=_3643ccc6e610,
                _816e201c1098=_3643ccc6e610,
            )

            return _1b04ae6cf3b6

        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Training step {_d2323a8f2915} failed: {_de411abc6586(_e5767feaca6b)}")


    def _5ac907680b30(self) -> _4a328dff1530:
        """
        Handle end of training epoch.

        Raises:
            RuntimeError: If epoch end processing fails.
        """
        try:
            if _61af91e84e63._9297a007d1d5._64f6ffde7348():
                _61af91e84e63._9297a007d1d5._50eee1c94531()
            _d8125ea8cf8b()._f01e293cda8a()
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Training epoch end failed: {_de411abc6586(_e5767feaca6b)}")

    def _a0d7afb0b71e(self, _2fd53825a757: _692ece4c23ab, _d2323a8f2915: _a082b0de9a9e) -> _692ece4c23ab:
        """
        Perform a validation step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Validation outputs.

        Raises:
            RuntimeError: If validation step fails.
        """
        try:
            if "input_ids" not in _2fd53825a757 or "labels" not in _2fd53825a757:
                raise _5a312977fe30("Batch missing input_ids or labels")
            _864cbfe63652 = _2fd53825a757["input_ids"]._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
            _5563223a3d99 = _2fd53825a757["labels"]._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
            _12fd68e8a0fd = _2fd53825a757["lang_codes"]
            _afc2f1929594 = _2fd53825a757["sample_ids"]
            _7168220e8008 = _2fd53825a757["chunk_ids"]
            _243ce67efff6 = _2fd53825a757["word_positions"]
            _51e5cf723019 = _864cbfe63652._93ae794a1d43(0)

            _923d44ff4344, _6061cd65b978, _d199e7b9062c = self(_864cbfe63652)
            _71e54fb1656a = _923d44ff4344._4c16fd2b227c()._c08f1c12df67(-1, _923d44ff4344._82d1a372a435[-1])
            _b4040e2fdc74 = _5563223a3d99._4c16fd2b227c()._c08f1c12df67(-1)

            _1f391891f8fe = self._ea6cb5845025['criterion'](_71e54fb1656a, _b4040e2fdc74)
            _1f391891f8fe = _61af91e84e63._2fff8379bab8(_1f391891f8fe)

            _f8c09d14c7f5 = self._668c622ed52f(_1f391891f8fe, _6061cd65b978, _d199e7b9062c)
            _c88447649dea = _f8c09d14c7f5["aux_term"]
            _1b04ae6cf3b6 = _1f391891f8fe + _c88447649dea

            # logging
            self._442fea3138f4(
                {
                    "val_kl_batch": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("kl_batch", 0.0)._c16a3210f423()._dad78c684f3a()._faadbf227818()) if _fcd8eaf6a0af(_f8c09d14c7f5._35525cc484f1("kl_batch", _4a328dff1530), _61af91e84e63._be48cc0d1bda) else _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("kl_batch", 0.0)),
                    "val_contrast_batch": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("contrast_batch", 0.0)._c16a3210f423()._dad78c684f3a()._faadbf227818()) if _fcd8eaf6a0af(_f8c09d14c7f5._35525cc484f1("contrast_batch", _4a328dff1530), _61af91e84e63._be48cc0d1bda) else _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("contrast_batch", 0.0)),
                    "val_task_loss": _6730d2d2e3af(_1f391891f8fe._c16a3210f423()._dad78c684f3a()._faadbf227818()),
                    "val_aux_scale": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("aux_scale", 0.0)),
                    "val_w_mean": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("w_mean", 0.0)),
                    "val_lambda_kl_eff": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("lambda_kl_eff", 0.0)),
                    "val_lambda_cos_eff": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("lambda_cos_eff", 0.0)),
                    "val_shift_r": _6730d2d2e3af(_f8c09d14c7f5._35525cc484f1("shift_r", 0.0)),
                    "val_loss": _6730d2d2e3af(_1b04ae6cf3b6._c16a3210f423()._dad78c684f3a()._faadbf227818()),
                },
                _51e5cf723019=_51e5cf723019,
                _f486b48b4f8e=_421bcb69e7f5,
                _401559a5eb78=_3643ccc6e610,
                _5d87e95d4ef8=_421bcb69e7f5,
                _b32aa8bd0e76=_3643ccc6e610,
                _816e201c1098=_3643ccc6e610,
            )

            # per-example preds/labels (preserve your decision_threshold logic)
            _aa6af8d7062a, _55c12933214c = [], []
            for _aed40bea82e8 in _5c2ff69034f5(_51e5cf723019):
                _b471248f7ebc = _923d44ff4344[_aed40bea82e8]
                _2c96cf83a584 = _5563223a3d99[_aed40bea82e8]
                _ef6cc419c087 = _2c96cf83a584 != self._d217d261443e
                _1c62dbd107fe = _b471248f7ebc[_ef6cc419c087]
                _89ba9897f54f = _2c96cf83a584[_ef6cc419c087]

                if self._203232df722d > 0:
                    _90003b2b277f = _61af91e84e63._d3be613714f8._57c29a175835._17641d043033(_1c62dbd107fe, _eaaeef774707=-1)
                    _d083b029a3a6, _b4f15fca1ccd = _90003b2b277f._fdd31b0a4a89(_eaaeef774707=-1)
                    _54e4b7f59056 = _d083b029a3a6 < self._203232df722d
                    _b4f15fca1ccd = _b4f15fca1ccd._5d79505282d4() + 1
                    _b4f15fca1ccd[_54e4b7f59056] = 0
                    _89ba9897f54f = _89ba9897f54f._5d79505282d4() + 1
                    del _90003b2b277f, _d083b029a3a6, _54e4b7f59056
                else:
                    _b4f15fca1ccd = _1c62dbd107fe._e39a5c85af9a(_eaaeef774707=-1)

                _aa6af8d7062a._e19b38b20635(_b4f15fca1ccd)
                _55c12933214c._e19b38b20635(_89ba9897f54f)
                del _1c62dbd107fe

            _96de6a50f13f = {
                "lang_codes": _12fd68e8a0fd,
                "preds": _aa6af8d7062a,
                "labels": _55c12933214c,
                "sample_ids": _afc2f1929594,
                "chunk_ids": _7168220e8008,
                "word_positions": _243ce67efff6,
                "val_loss": _1b04ae6cf3b6
            }
            self._e1b7a1ca47f1._e19b38b20635(_96de6a50f13f)

            # cleanup
            del _864cbfe63652, _5563223a3d99, _923d44ff4344
            if _61af91e84e63._9297a007d1d5._64f6ffde7348():
                _61af91e84e63._9297a007d1d5._50eee1c94531()
            return _96de6a50f13f

        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Validation step {_d2323a8f2915} failed: {_de411abc6586(_e5767feaca6b)}")


    def _ff6e48bb078e(self, _1a24745db84f: _692ece4c23ab, _770d8f7ffb96: _de411abc6586, _0fe9c908b72a: _dda8c396b8e2[_a082b0de9a9e] = _4a328dff1530) -> _4a328dff1530:
        """
        Save metrics to a CSV file.

        Args:
            metrics_dict (Dict): Metrics to save.
            filename (str): Output filename.
            trial_number (Optional[int]): Trial number for directory.

        Raises:
            RuntimeError: If saving to CSV fails.
        """
        try:
            _66a6b779c82d = os._27500070d4d2()
            _16d08f6e25aa = f"trial_{_0fe9c908b72a}" if _0fe9c908b72a is not _4a328dff1530 else "default"
            # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
            _26e6b557abd9 = os._55b3983299aa._8d3552b9a0c0(_66a6b779c82d, "metrics", self._fc10d41ce29a, _16d08f6e25aa)
            os._e4f2392314ad(_26e6b557abd9, _a8828a016066=_3643ccc6e610)
            _a8ffa9c4670e = os._55b3983299aa._8d3552b9a0c0(_26e6b557abd9, _770d8f7ffb96)
            _c1ae17da842b = _a7f67741e6d9._f01327e8d95c(_1a24745db84f)
            _c1ae17da842b._f45fb1d63749(_a8ffa9c4670e, _535be97f5582=_421bcb69e7f5)
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Failed to save metrics to {_770d8f7ffb96}: {_de411abc6586(_e5767feaca6b)}")

    def _bad21b3b5ba6(self):
        # pick correct device for this rank
        if _61af91e84e63._9297a007d1d5._64f6ffde7348():
            if _61af91e84e63._a92926e1b9f7._e317509d807d():
                _371cda80d2f5 = _61af91e84e63._a92926e1b9f7._537295b203a7()
            else:
                _371cda80d2f5 = 0
            _61af91e84e63._9297a007d1d5._f0b140b28669(_371cda80d2f5)
            self._e4ebc744260b = _61af91e84e63._9575589dfd0e(f"cuda:{_371cda80d2f5}")
        else:
            self._e4ebc744260b = _61af91e84e63._9575589dfd0e("cpu")

        self._fa57724eb8a2()

    def _b65a36beb627(self) -> _4a328dff1530:
        """
        Handle end of validation epoch.

        Raises:
            RuntimeError: If validation epoch end processing fails.
        """
        try:
            if not self._e1b7a1ca47f1:
                _3017c0005445("[on_validation_epoch_end] No validation outputs to process.")
                return
            
            _c5481b970449, _5563223a3d99 = self._2cecd78c5173(self._e1b7a1ca47f1)
            _9575589dfd0e = self._a68afcab98e4['micro_accuracy']._9575589dfd0e
            _c5481b970449, _5563223a3d99 = _c5481b970449._1da1851d7e30(_9575589dfd0e), _5563223a3d99._1da1851d7e30(_9575589dfd0e)
            
            self._a68afcab98e4['micro_accuracy']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_accuracy']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_precision']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_recall']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_f1']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_accuracy']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_precision']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_recall']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_f1']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['confmat']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            
            _d431563c6ad0 = self._a68afcab98e4['micro_accuracy']._0724739633e6()._faadbf227818()
            _c381376114cb = self._a68afcab98e4['macro_accuracy']._0724739633e6()._faadbf227818()
            _4c9d31f52c02 = self._a68afcab98e4['macro_precision']._0724739633e6()._faadbf227818()
            _a1945170ab79 = self._a68afcab98e4['macro_recall']._0724739633e6()._faadbf227818()
            _f97c20ee3190 = self._a68afcab98e4['macro_f1']._0724739633e6()._faadbf227818()
            _3ab457204f4f = self._a68afcab98e4['classwise_accuracy']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _be2acb62a7a4 = self._a68afcab98e4['classwise_precision']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _d38838c31be6 = self._a68afcab98e4['classwise_recall']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _975fe600c987 = self._a68afcab98e4['classwise_f1']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _766f26eda5bf = self._a68afcab98e4['confmat']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            
            self._026ae0c12d2e("val_accuracy", _c381376114cb, _816e201c1098=_3643ccc6e610)
            
            _1a24745db84f = {
                "epoch": [self._657588131e79],
                "class_names": [self._35e554a9007e],
                "micro_accuracy": [_d431563c6ad0],
                "macro_accuracy": [_c381376114cb],
                "macro_precision": [_4c9d31f52c02],
                "macro_recall": [_a1945170ab79],
                "macro_f1": [_f97c20ee3190],
                "classwise_accuracy": [_3ab457204f4f._9f4dd6518243()],
                "classwise_precision": [_be2acb62a7a4._9f4dd6518243()],
                "classwise_recall": [_d38838c31be6._9f4dd6518243()],
                "classwise_f1": [_975fe600c987._9f4dd6518243()],
                "confusion_matrix": [_766f26eda5bf._9f4dd6518243()],
            }
            self._a61fdbf9a082(_1a24745db84f, f"val_epoch_{self._657588131e79}.csv", self._0fe9c908b72a)
            
            self._a68afcab98e4['micro_accuracy']._327443be888e()
            self._a68afcab98e4['macro_accuracy']._327443be888e()
            self._a68afcab98e4['macro_precision']._327443be888e()
            self._a68afcab98e4['macro_recall']._327443be888e()
            self._a68afcab98e4['macro_f1']._327443be888e()
            self._a68afcab98e4['classwise_accuracy']._327443be888e()
            self._a68afcab98e4['classwise_precision']._327443be888e()
            self._a68afcab98e4['classwise_recall']._327443be888e()
            self._a68afcab98e4['classwise_f1']._327443be888e()
            self._a68afcab98e4['confmat']._327443be888e()
            self._e1b7a1ca47f1._cdf98258baaf()
            
            if _61af91e84e63._9297a007d1d5._64f6ffde7348():
                _61af91e84e63._9297a007d1d5._50eee1c94531()
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Validation epoch end failed: {_de411abc6586(_e5767feaca6b)}")

    def _c00b33fa5008(self, _814ff968da45: _9dc7f1b0ec0f[_692ece4c23ab]) -> _3cdf98b89cb5[_61af91e84e63._be48cc0d1bda, _61af91e84e63._be48cc0d1bda]:
        """
        Reconcile chunked predictions and labels.

        Args:
            outputs (List[Dict]): Validation/test outputs.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: Reconciled predictions and labels.

        Raises:
            RuntimeError: If reconciliation fails.
        """
        try:
            def _3401196b93da(_ea34d03ffc1f):
                if _fcd8eaf6a0af(_ea34d03ffc1f, _61af91e84e63._be48cc0d1bda):
                    return _ea34d03ffc1f._c16a3210f423()._dad78c684f3a()._1c3926e46fb3(-1)._9f4dd6518243()
                if _fcd8eaf6a0af(_ea34d03ffc1f, _28d8e8cf26fc._b8cfda483e3a):
                    return _ea34d03ffc1f._1c3926e46fb3(-1)._9f4dd6518243()
                if _fcd8eaf6a0af(_ea34d03ffc1f, (_f24e38d9704e, _4aa51c54a539)):
                    return _f24e38d9704e(_ea34d03ffc1f)
                return [_ea34d03ffc1f]
            
            _c7a1a821f223, _a89845e1c93c, _ae9e6fce4834 = [], [], []
            _780c12403594 = _c1e8f6661915()
            _9d8d201511ad = _c13375c5e01f(_f24e38d9704e)
            
            for _af902460f19b in _814ff968da45:
                if not _32f341694efc(_29925c8be636 in _af902460f19b for _29925c8be636 in ["sample_ids", "chunk_ids", "preds", "labels", "word_positions"]):
                    raise _5a312977fe30("Output dictionary missing required keys")
                _afc2f1929594 = _af902460f19b["sample_ids"]
                _7168220e8008 = _af902460f19b["chunk_ids"]
                _f265391c5c4e = _af902460f19b["preds"]
                _4d58a3f85094 = _af902460f19b["labels"]
                _243ce67efff6 = _af902460f19b["word_positions"]
                
                for _aed40bea82e8, _bfd45d8ce50b in _cd747740cdb2(_afc2f1929594):
                    _36f87590ee25 = _a082b0de9a9e(_7168220e8008[_aed40bea82e8])
                    if (_bfd45d8ce50b, _36f87590ee25) in _780c12403594:
                        continue
                    _780c12403594._e5e4bd7c57ac((_bfd45d8ce50b, _36f87590ee25))
                    _9b9448777e93 = _b42d9022b96a(_f265391c5c4e[_aed40bea82e8])
                    _e56021e8948c = _b42d9022b96a(_4d58a3f85094[_aed40bea82e8])
                    _4b4849e39acb = _b42d9022b96a(_243ce67efff6[_aed40bea82e8])
                    
                    if not (_0a17d5ca9f82(_4b4849e39acb) == _0a17d5ca9f82(_9b9448777e93) == _0a17d5ca9f82(_e56021e8948c)):
                        _3017c0005445(
                            f"[WARN] mismatch sid={_bfd45d8ce50b} cid={_36f87590ee25}: "
                            f"pos={_0a17d5ca9f82(_4b4849e39acb)} preds={_0a17d5ca9f82(_9b9448777e93)} labels={_0a17d5ca9f82(_e56021e8948c)}"
                        )
                        continue
                    
                    if _bfd45d8ce50b not in _ae9e6fce4834:
                        _ae9e6fce4834._e19b38b20635(_bfd45d8ce50b)
                    _9d8d201511ad[_bfd45d8ce50b]._e19b38b20635((_36f87590ee25, _4b4849e39acb, _9b9448777e93, _e56021e8948c))
            
            for _bfd45d8ce50b in _ae9e6fce4834:
                _8890d7856367 = _9d8d201511ad[_bfd45d8ce50b]
                _8890d7856367._3ad99fc94959(_29925c8be636=lambda _ea34d03ffc1f: _ea34d03ffc1f[0])
                _f0f11194d221 = _c13375c5e01f(_f24e38d9704e)
                _16d245f4bf84 = _c13375c5e01f(_f24e38d9704e)
                
                for _36f87590ee25, _c4cda9539283, _c5481b970449, _5563223a3d99 in _8890d7856367:
                    for _e7810e2a2a1b, _a056d52aae00, _631f8395653c in _4465dccc1bc9(_c4cda9539283, _c5481b970449, _5563223a3d99):
                        _f0f11194d221[_a082b0de9a9e(_e7810e2a2a1b)]._e19b38b20635(_a082b0de9a9e(_a056d52aae00))
                        _16d245f4bf84[_a082b0de9a9e(_e7810e2a2a1b)]._e19b38b20635(_a082b0de9a9e(_631f8395653c))
                
                _b92b6141a763, _92942c64ae63 = [], []
                for _e7810e2a2a1b in _470f570876e4(_f0f11194d221._0124407b3b43()):
                    _a056d52aae00 = _0fb7076be352(_f0f11194d221[_e7810e2a2a1b])._432533f569c1(1)[0][0]
                    _b92b6141a763._e19b38b20635(_a056d52aae00)
                    _631f8395653c = _0fb7076be352(_16d245f4bf84[_e7810e2a2a1b])._432533f569c1(1)[0][0] if _e7810e2a2a1b in _16d245f4bf84 else -100
                    _92942c64ae63._e19b38b20635(_631f8395653c)
                
                _c7a1a821f223._4c38bdc2d950(_b92b6141a763)
                _a89845e1c93c._4c38bdc2d950(_92942c64ae63)
            
            return _61af91e84e63._33b87a7d8664(_c7a1a821f223, _9575589dfd0e="cpu"), _61af91e84e63._33b87a7d8664(_a89845e1c93c, _9575589dfd0e="cpu")
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Chunk reconciliation failed: {_de411abc6586(_e5767feaca6b)}")

    def _cf1015bb8d03(self, _2fd53825a757: _692ece4c23ab, _d2323a8f2915: _a082b0de9a9e) -> _692ece4c23ab:
        """
        Perform a test step.

        Args:
            batch (Dict): Batch containing input_ids, labels, and metadata.
            batch_idx (int): Batch index.

        Returns:
            Dict: Test outputs.

        Raises:
            RuntimeError: If test step fails.
        """
        try:
            if "input_ids" not in _2fd53825a757 or "labels" not in _2fd53825a757:
                raise _5a312977fe30("Batch missing input_ids or labels")
            with _61af91e84e63._e9c99322e85e():
                _864cbfe63652 = _2fd53825a757["input_ids"]._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
                _5563223a3d99 = _2fd53825a757["labels"]._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
                _12fd68e8a0fd = _2fd53825a757["lang_codes"]
                _afc2f1929594 = _2fd53825a757["sample_ids"]
                _7168220e8008 = _2fd53825a757["chunk_ids"]
                _243ce67efff6 = _2fd53825a757["word_positions"]
                _51e5cf723019 = _864cbfe63652._93ae794a1d43(0)

                _923d44ff4344, _6061cd65b978, _d199e7b9062c = self(_864cbfe63652)

                _71e54fb1656a = _923d44ff4344._4c16fd2b227c()._c08f1c12df67(-1, _923d44ff4344._82d1a372a435[-1])
                _b4040e2fdc74 = _5563223a3d99._4c16fd2b227c()._c08f1c12df67(-1)

                _aa6af8d7062a, _55c12933214c = [], []
                for _aed40bea82e8 in _5c2ff69034f5(_51e5cf723019):
                    _b471248f7ebc = _923d44ff4344[_aed40bea82e8]
                    _2c96cf83a584 = _5563223a3d99[_aed40bea82e8]
                    _ef6cc419c087 = _2c96cf83a584 != self._d217d261443e
                    _1c62dbd107fe = _b471248f7ebc[_ef6cc419c087]
                    _89ba9897f54f = _2c96cf83a584[_ef6cc419c087]

                    if self._203232df722d > 0:
                        _90003b2b277f = _61af91e84e63._d3be613714f8._57c29a175835._17641d043033(_1c62dbd107fe, _eaaeef774707=-1)
                        _d083b029a3a6, _b4f15fca1ccd = _90003b2b277f._fdd31b0a4a89(_eaaeef774707=-1)
                        _54e4b7f59056 = _d083b029a3a6 < self._203232df722d
                        _b4f15fca1ccd = _b4f15fca1ccd._5d79505282d4() + 1
                        _b4f15fca1ccd[_54e4b7f59056] = 0
                        _89ba9897f54f = _89ba9897f54f._5d79505282d4() + 1
                        del _90003b2b277f, _d083b029a3a6, _54e4b7f59056
                    else:
                        _b4f15fca1ccd = _1c62dbd107fe._e39a5c85af9a(_eaaeef774707=-1)

                    _aa6af8d7062a._e19b38b20635(_b4f15fca1ccd)
                    _55c12933214c._e19b38b20635(_89ba9897f54f)
                    del _1c62dbd107fe

                _96de6a50f13f = {
                    "lang_codes": _12fd68e8a0fd,
                    "preds": _aa6af8d7062a,
                    "labels": _55c12933214c,
                    "sample_ids": _afc2f1929594,
                    "chunk_ids": _7168220e8008,
                    "word_positions": _243ce67efff6,
                }
                self._5ef953983ce8._e19b38b20635(_96de6a50f13f)

                # cleanup
                del _864cbfe63652, _5563223a3d99, _923d44ff4344
                if _61af91e84e63._9297a007d1d5._64f6ffde7348():
                    _61af91e84e63._9297a007d1d5._50eee1c94531()
                return _96de6a50f13f
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Test step {_d2323a8f2915} failed: {_de411abc6586(_e5767feaca6b)}")

    def _cdda14c4dd6b(self):
        # pick correct device for this rank
        if _61af91e84e63._9297a007d1d5._64f6ffde7348():
            if _61af91e84e63._a92926e1b9f7._e317509d807d():
                _371cda80d2f5 = _61af91e84e63._a92926e1b9f7._537295b203a7()
            else:
                _371cda80d2f5 = 0
            _61af91e84e63._9297a007d1d5._f0b140b28669(_371cda80d2f5)
            self._e4ebc744260b = _61af91e84e63._9575589dfd0e(f"cuda:{_371cda80d2f5}")
        else:
            self._e4ebc744260b = _61af91e84e63._9575589dfd0e("cpu")

        self._fa57724eb8a2()

    def _204b9dbae35d(self) -> _4a328dff1530:
        """
        Handle end of test epoch.

        Raises:
            RuntimeError: If test epoch end processing fails.
        """
        try:
            if not self._5ef953983ce8:
                _3017c0005445("[on_test_epoch_end] No test outputs to process.")
                return
            
            _c5481b970449, _5563223a3d99 = self._2cecd78c5173(self._5ef953983ce8)
            _9575589dfd0e = self._a68afcab98e4['micro_accuracy']._9575589dfd0e
            _c5481b970449, _5563223a3d99 = _c5481b970449._1da1851d7e30(_9575589dfd0e), _5563223a3d99._1da1851d7e30(_9575589dfd0e)
            
            self._a68afcab98e4['micro_accuracy']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_accuracy']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_precision']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_recall']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['macro_f1']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_accuracy']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_precision']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_recall']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['classwise_f1']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            self._a68afcab98e4['confmat']._fb1cddc9b7f6(_c5481b970449, _5563223a3d99)
            
            _d431563c6ad0 = self._a68afcab98e4['micro_accuracy']._0724739633e6()._faadbf227818()
            _c381376114cb = self._a68afcab98e4['macro_accuracy']._0724739633e6()._faadbf227818()
            _4c9d31f52c02 = self._a68afcab98e4['macro_precision']._0724739633e6()._faadbf227818()
            _a1945170ab79 = self._a68afcab98e4['macro_recall']._0724739633e6()._faadbf227818()
            _f97c20ee3190 = self._a68afcab98e4['macro_f1']._0724739633e6()._faadbf227818()
            _3ab457204f4f = self._a68afcab98e4['classwise_accuracy']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _be2acb62a7a4 = self._a68afcab98e4['classwise_precision']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _d38838c31be6 = self._a68afcab98e4['classwise_recall']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _975fe600c987 = self._a68afcab98e4['classwise_f1']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            _766f26eda5bf = self._a68afcab98e4['confmat']._0724739633e6()._dad78c684f3a()._2dec7070d8c8()
            
            self._026ae0c12d2e("test_accuracy", _c381376114cb, _816e201c1098=_3643ccc6e610)
            
            _1a24745db84f = {
                "class_names": [self._35e554a9007e],
                "micro_accuracy": [_d431563c6ad0],
                "macro_accuracy": [_c381376114cb],
                "macro_precision": [_4c9d31f52c02],
                "macro_recall": [_a1945170ab79],
                "macro_f1": [_f97c20ee3190],
                "classwise_accuracy": [_3ab457204f4f._9f4dd6518243()],
                "classwise_precision": [_be2acb62a7a4._9f4dd6518243()],
                "classwise_recall": [_d38838c31be6._9f4dd6518243()],
                "classwise_f1": [_975fe600c987._9f4dd6518243()],
                "confusion_matrix": [_766f26eda5bf._9f4dd6518243()],
            }
            self._a61fdbf9a082(_1a24745db84f, "test_final.csv", self._0fe9c908b72a)
            
            self._a68afcab98e4['micro_accuracy']._327443be888e()
            self._a68afcab98e4['macro_accuracy']._327443be888e()
            self._a68afcab98e4['macro_precision']._327443be888e()
            self._a68afcab98e4['macro_recall']._327443be888e()
            self._a68afcab98e4['macro_f1']._327443be888e()
            self._a68afcab98e4['classwise_accuracy']._327443be888e()
            self._a68afcab98e4['classwise_precision']._327443be888e()
            self._a68afcab98e4['classwise_recall']._327443be888e()
            self._a68afcab98e4['classwise_f1']._327443be888e()
            self._a68afcab98e4['confmat']._327443be888e()
            self._5ef953983ce8._cdf98258baaf()
            
            if _61af91e84e63._9297a007d1d5._64f6ffde7348():
                _61af91e84e63._9297a007d1d5._50eee1c94531()
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Test epoch end failed: {_de411abc6586(_e5767feaca6b)}")

    def _3150633300ca(self, _2fd53825a757: _692ece4c23ab, _d2323a8f2915: _a082b0de9a9e, _e8a059fb08f1: _a082b0de9a9e = 0) -> _692ece4c23ab:
        """
        Perform a prediction step.

        Args:
            batch (Dict): Batch containing input_ids.
            batch_idx (int): Batch index.
            dataloader_idx (int): Dataloader index.

        Returns:
            Dict: Predictions and probabilities.

        Raises:
            RuntimeError: If prediction step fails.
        """
        try:
            if not _2fd53825a757 or not _fcd8eaf6a0af(_2fd53825a757, (_f24e38d9704e, _4aa51c54a539)) or not _2fd53825a757[0]:
                raise _5a312977fe30("Invalid batch input for prediction")
            _864cbfe63652 = _2fd53825a757[0]._1da1851d7e30(self._e4ebc744260b, _0a144ca3ba8f=_3643ccc6e610)
            _814ff968da45, _, _ = self(_864cbfe63652)
            _814ff968da45 = _814ff968da45._4c16fd2b227c()._c08f1c12df67(-1, _814ff968da45._82d1a372a435[-1])
            
            if self._203232df722d > 0:
                _90003b2b277f = _61af91e84e63._d3be613714f8._57c29a175835._17641d043033(_814ff968da45, _eaaeef774707=-1)
                _d083b029a3a6, _a056d52aae00 = _90003b2b277f._fdd31b0a4a89(_eaaeef774707=-1)
                _54e4b7f59056 = _d083b029a3a6 < self._203232df722d
                _9ab18098d5f8 = _a056d52aae00 + 1
                _9ab18098d5f8[_54e4b7f59056] = 0
                _4f8e5c1531cc = _61af91e84e63._e746752d2230(_814ff968da45._93ae794a1d43(0), self._226466dba5a5 + 1, _9575589dfd0e=_814ff968da45._9575589dfd0e)
                _4f8e5c1531cc[~_54e4b7f59056, 1:] = _90003b2b277f[~_54e4b7f59056]
                _4f8e5c1531cc[_54e4b7f59056, 0] = 1.0
            else:
                _90003b2b277f = _61af91e84e63._d3be613714f8._57c29a175835._17641d043033(_814ff968da45, _eaaeef774707=-1)
                _9ab18098d5f8 = _90003b2b277f._e39a5c85af9a(_eaaeef774707=-1)
                _4f8e5c1531cc = _90003b2b277f
            
            del _864cbfe63652, _814ff968da45
            if _61af91e84e63._9297a007d1d5._64f6ffde7348():
                _61af91e84e63._9297a007d1d5._50eee1c94531()
            return {
                "predictions": _9ab18098d5f8._dad78c684f3a(),
                "probs": _4f8e5c1531cc._dad78c684f3a()
            }
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Predict step {_d2323a8f2915} failed: {_de411abc6586(_e5767feaca6b)}")

    def _c6ba7e57d93e(self, _e84db2145793) -> _4a328dff1530:
        """
        Handle operations before optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If gradient clipping fails.
        """
        try:
            _61af91e84e63._d3be613714f8._d99cb5329b5b._c144bcff5d57(self._29899e46342e(), _da5719dbfb5c=1.0)
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Gradient clipping failed: {_de411abc6586(_e5767feaca6b)}")

    def _72d795b53bc8(self, _e84db2145793) -> _4a328dff1530:
        """
        Handle operations after optimizer step.

        Args:
            optimizer: Optimizer instance.

        Raises:
            RuntimeError: If parameter clamping fails.
        """
        try:
            for _3a7ce409128e in self._29899e46342e():
                if _3a7ce409128e is not _4a328dff1530:
                    _3a7ce409128e._c4ede1fadde9._422831b45d57(-5, 5)
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Parameter clamping failed: {_de411abc6586(_e5767feaca6b)}")

    def _a0134f475dcb(self) -> _6730d2d2e3af:
        """
        Compute gradient norm.

        Returns:
            float: L2 gradient norm.

        Raises:
            RuntimeError: If gradient norm computation fails.
        """
        try:
            _0cc80d755aec = 0
            for _3a7ce409128e in self._29899e46342e():
                if _3a7ce409128e._b1988afad717 is not _4a328dff1530:
                    _df2e3fb304d1 = _3a7ce409128e._b1988afad717._c16a3210f423()._c4ede1fadde9._c84d867287bb(2)
                    _0cc80d755aec += _df2e3fb304d1._faadbf227818() ** 2
            return _0cc80d755aec ** 0.5
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Gradient norm computation failed: {_de411abc6586(_e5767feaca6b)}")

    def _9c631db49954(self) -> _692ece4c23ab:
        """
        Configure optimizer and learning rate scheduler.

        Returns:
            Dict: Optimizer and scheduler configuration.

        Raises:
            RuntimeError: If optimizer configuration fails.
        """
        try:
            _6135c0ced3c3 = _9f9525132ab6(lambda _848b3f25827d: _848b3f25827d._e43643663781, self._29899e46342e())
            _c65101ed35ab = {
                "adamw": _61af91e84e63._2a82396b4510._7524e9faf2f9,
                "adamax": _61af91e84e63._2a82396b4510._67da3bcd3c68,
                "adam": _61af91e84e63._2a82396b4510._43fbf2e6d090,
            }
            _0b384df55323 = _c65101ed35ab._35525cc484f1(self._876ca67bdb56._9a1fd12d08ea())
            if _0b384df55323 is _4a328dff1530:
                raise _5a312977fe30(f"Unsupported optimizer: {self._876ca67bdb56}")
            _e84db2145793 = _0b384df55323(_6135c0ced3c3, _5ad076cd9fb3=self._3f65bac737e4._5ad076cd9fb3, _86a4d757440f=0.001)
            
            _80560433e05f = self._1ee1389e80ab._3db3e560ff89
            _7e8792b59613 = math._f3e59bb4de27(0.1 * _80560433e05f)
            _d4ad260b6ed0 = _61af91e84e63._2a82396b4510._fd792b198509._b05c060c2125(_e84db2145793, _53727f9f4e93=lambda _ca8d32c36492: (_ca8d32c36492 + 1) / _7e8792b59613)
            _a5558d6bd763 = _61af91e84e63._2a82396b4510._fd792b198509._93f5b583a283(
                _e84db2145793,
                _bbf77998ef40=_fdd31b0a4a89(1, _80560433e05f - _7e8792b59613),
                _61696e20ed74=2,
                _2feeaca5304e=1e-6
            )
            _fd792b198509 = _61af91e84e63._2a82396b4510._fd792b198509._769fef44d0f9(
                _e84db2145793,
                _b6995b9b8f2d=[_d4ad260b6ed0, _a5558d6bd763],
                _bac5a269658e=[_7e8792b59613]
            )
            
            return {"optimizer": _e84db2145793, "lr_scheduler": {"scheduler": _fd792b198509, "interval": "epoch", "monitor": "val_loss"}}
        except _a8c2d0c95582 as _e5767feaca6b:
            raise _5a312977fe30(f"Optimizer configuration failed: {_de411abc6586(_e5767feaca6b)}")