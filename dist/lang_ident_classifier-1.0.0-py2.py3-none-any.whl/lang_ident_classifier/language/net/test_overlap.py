
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(2797, 41694, 2), (19598, 49810, 2), (6881, 62911, 2), (60298, 58047, 2), (8699, 51765, 2), (65272, 34307, 2), (62159, 13516, 2), (13863, 48546, 2), (44251, 38091, 2), (2123, 45343, 2), (37452, 42221, 2), (16722, 40602, 2), (36320, 52696, 2), (22446, 25739, 2), (15599, 35698, 2), (10173, 64799, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('qDOOHA==')
_nonce = base64.b64decode('ikHY314DLTwZ9Aig')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('8Cn5eNcauzOMevDXoVxi/eUar68vHAL1ki8KJDIPaiuIUuPX0GJQ9LIseSTQC8w409kyd/AgEgbnZXRPyebjg5eOZkA24Qyp6tHDVntyzxSLFIwXaQQqtTyvSy+gpBTCSDA+HCJMd4rbU/xH728mVXhWpZVHnT8052WwAqjUGm/1nRdQcClI7DQ/B0iEVhbT0/otspmdmqmQaVnu20KjjZC+ax4dAvonVOKc+cZ/cgOh6MV9v3LF0x+SbaPxAl8X81W/cxfl2AoLhGZ5EgPZBkObv/LEUWnfTs79F6vBZeCAaEL7eO+63GU8GUoguRpyuj46BFpSInqWg03CggKNWCJ9UciZ93BCYjy3JvvUqRk7XPHVegbl0hV24NBxI+0RuhbukbawC3zFRm1OGLh+9/RPTc9jBzmHA9aNjCAiLokS3iobFPg9VCjIXZrERyZcCjK1CmSAdLc5HAv+ylo4qJCFR/uqB5TPPEFbrrBLXjOPwvuDOHUk3Xm6oAXlwZyHXHVv4uEPiAZFYvM8s/razU6NXvlcVjsgqY9JYtT9vN/GwZzrOa6L3R2FrYcdtXyfEtUTUocar+3ldj0o92ZC9mPlwk45KLZa9elA7+9/ta5cPMUkWFtVh8aGXifFBUWVX1i9p6+ZvL3YWD5YW03ld51Y/BI3gxJE+4jgshFy8rllhu6aArbKUoz843RY4OyPQaT9M/EmxmlpdSnwbCt6/6pAM1TwJNIe5lm++uggQ5obD6WXHvOwuAiWVxFg7pRp9+vgo8Wa53sXvAw0djeA3sgkSaaDuQY1KfJm6qDBC7eSD4D2W+w61rHW+GGwiSRGb4T5bjaWqUtzPhCz+v7NXH8X6rooB4fZFSYEdC8nVxICZVT+pU+in3382X9rvPSck10M/CKAJKSj+xgKYGK6vIuvTihqYCg1BTj8soTVTjsAOixKEmiVC9u6VD1S63feqMr2RcXxn+nZSBpqQj+jjY1t8TiNo6PyHn7DZs2tlTvZCkuuCKe3eMHP9cZdvH44swNIDuDNeRU9gpTHs4+3Yp5JdtFUTE6AORt7EO0/sm2RmQZOTITqcPdQ28CHvgTOnwTTXDA3vwlCtYv9E3GWUadL7Hp1Qqa7h2hKPbWrPFt5ajwPx2nVYOa4LmWEm4vuzxsrHlKFf5/OmVM+eCg8R9LAEPURdA335UTADrPP1CjegrBqv8J3BmneAXIR+WII+JgCqwWrHB/Le/th0ISmvqHK/GhwK+5/lBpgY9OLISoJv+bDjEW601MkKCEIF8yx3b/kLaqlkqfn+2WEe+lKhcp/BF2KOjDVKTD60/Fg4USI9ytHeHUy9/sVGybBQa4wWY9MWe+wBMwDEF32FKAr99Z15Kj74SwgL3UgZhjl2N4Z/vcnRnvh3TEVp2OEr88Mj68pM8BbEj6nVIN1eYDcQzEj/m3DtphVdsW52GnWbQh7p2aOmYy9XhtbLH0lloH6J245b5Vk/nCTXYr5tAh4AYlLsI2Iv0OsQytjEBgRDwW4gEm82MkuK5mVCj+5gT3E5sapb/LTdP2jNuEJk4QKaS43tAtZcG1nO7O8TIAsPaqxSt/731rfjWTHpmP1L16nWugINADwt/r+RYFKROU3/f7MeeyAXZjV/6vBdZOhzmLlotWswRjjB/0JNZhLFTYaDt9ZgF/oITNv3qxHtLn7S/aJGU0DTs7uwk5FqD6LkwZNsT6/pz3WnZyK5Bd1zyUpa1J70xaFvKupGBNt+kXCILwYjd3QyLoGSTVLrgcZsMxPFXn3WBMbvDipoiA3J7RtkRif//pL8wl8T4E400M+AmfV1kpWjQWLz/3uY6g4jeqQGQ4h9B1dvummsDAtaoY0aP8s6TdijiLpOnwraFRz2LebY4BUBJ7gghnIahOBn0YIvCukU5lKqj6cxRvN+3nowMgWDNHsDynAe05c7lBoTAKxN7ZcKdNg9CIzqxznqWrXXle+3gvy8xmhWdqUqRQWS+hhgk4sLy8uCPxZ1C566EuW17A7ZDg66/gdUvArHwGWP73tnIQNM5RJyIbDqi3RGemo5GTDpyLjEVgFxfPB1HsFPK7ksjrrwmTOwn0DMxgcaJiIvglWdU1JOK+ji3vo510x58a4TlRAECnkKAjy7Bqc3follJ+ZgQtzzuVOgqs8Sk6YTukChLQjTlomxJN2bYjig7/0oT6pH+KjvIEQsg+MabqJhKA1PbxN6NJ/Ss4LMMPXFE0Dg/0/h7K75n6zt5lGyAoijNr33Nj6pNWcRHbc4dHMiBSZ+72iyG6VNX69oGXybFLo9lwrDZjk8hsY+n3WiTP5FN+y9MJU+PLIISlPPjQADo3hHuExmHX/sN/li70srmjfQQh8KThnwGTfihZ/74fwqPU1HRcnhkgNBK0h0k9B7ZapVpOcYcxg16shDInDUN8C1L9SJhDiiHdjI8AE29Nhx2AHuhigIiuXG6dOCitLP005cm0wJTUpAGk8bPlGYeEmwsEeKv20GWXad8eBRUTSigUCTC5lBLKWgqGGv+Fbb77YJ9AM0Yx46m0lxnaOHJfaMW9iP//rLge54GfAlwEtGxOOjltkIoH3X4rT1fc8glRUo1l+bBAt+VLyQW4MKcZVuwivteJe6Scsw5IUOBj8DX7cBfmDMBchDScbjPykvuaIl7/HxlzCwQCEhbIBoDZIj3/D5fh/YyDzdHP/0/Z2sBVxJLxfTDZkvqRjpG5uUhrJQPHaL8ILdZctIB4E2f1rB5QFso/CcK+4fgnQ2WuLxixBhwxoi5odwvPZUYfZfuoKcAsZQXxsT3dWtaTTTKdtv7WPJvV9RRoEWlXxp4hq12nREc12gErHtQ1jiRsCJqZ5mV2j9dhbEJ7rRxpUFGSp8HC2cfqtFilQnL/AHti+ekan6dnIdgGCTthoHll5QmT4Rf06dTXF1e3vWj4eV3F7r4+pPoGbAheVVVUmALfZ35zlasyGGW26yN9wH6z5asBXCPurHtA8t753zk4vyAlsx+2XDRGlb0b3t3rJ+J3QhB0RoygUvk/zLOCBwLt10DlwTEmHAfT68UntwRi3Ski/CY3+sVp4scjUZamqSfXDQDlkPp7haBgmZEdljLDnRgkW8r+53jaXHH9PHbwOEE9kS/tdwJ9B5H+GGTfPlkOWBvzks5QA0zGEtE5tWFGnW6SadfUifr6mRTxXKIcFDHfJRf2aXYbdQfrA8fhtXEjuj3BYMbA80FrU6WIrwFTIoYuKI6LQ3V4+7nbybjNoMVlP+NNdrOHGnZGqXoD2g1h6k2rQKvmT8BMn5U785DJpOVkT2ahNh3a3GE+PoxkUojWzLz0Us5XLiJeFMBIpqY/l6EZxA79M4Rm9C/42ATnF8dI2WWwhlO3TTC/3PkJ1YZ6BLWGVlJKiOONTMu4A1qov7bLnIh+8M4b39trCIsIR+SJHYYabRSlAMmOMxBnvWd+4c71+4A72ZUP7JG4Rwge7Oz0iciM0Gbp83svUH5DDT7TMI6QGcVj665FnLMpEEizCo27kZn2G2Lp3Y/dl4A+g0MCEQKs5E9MjjFTGorzwmvyUPfR7uVN6F5N+42prg3M1lRjz3ASbIb9+ZmFf8w3QdNLw6DA/SfDsG0PfzkdQIqoAsnUbdB8itAPViH7IfbLWWZVDgvH6u+2aDnNOswHzvKdhrWKynrp6avMwoBQMU42egqpTwhqstcOFgJ7DdiQhy8Rnyk9hnCLqeXJJyJvc81ob3iYYJpr3aX4L9SLDkS3K9bbo+udxB7Icee/kNbxglkLeQ59Gr0JGhKatkKH3A4xzpjWkhslL/mE4FibzDAjEnTiRDH1nlluobRwc5rwJYSUiSjXAqwtufDgr58OSmu4k58DA3mqt1mBH0t7C7NpMnAxHRAtEbJPPtClofxfVG3/Tjeo7Iy9t0bAptLH93msjIVaKxSFtmuEwnCkvTg2kpAMKkoJ7CGpjY4t+2wvbAk3G5XdPX7Uh5Y9baKgEsho2fDDLJiscdc96XLt5c54sgh/qrytKfpPG/glcOpR6XsV4eJf3zG8Sumcc3EkM044XMcD2F9SElRB4uUqphcmWMIKyxjQ388lMgaoQZSb41RdWdRNL40IQKAeYw6PwUrDMy3mmdJhVNRZwgZ5e5t79PQnenK/YO+//NDRdM3U5AiOKvY2ctYVXFHlaL/Zeyy81SAbkc2VbjfjkRABfQ6yN3GQfmg+J2ca25/+AyjHkKpJSautcDUlTr1mLykk8CA9bf1YjlA7CkGDhDZTbjNa+YPd5ZCA++4SmN/sRlTHH7wZuOBzEziq+gKSS2gnzGDhyNHt+aSe9hChPCbJFnn0b6S1y6J8B8C2k06wLktjUBCIJMmqJAtJDqhv/H+ndA3IEAfKD9RFCDQM/5FA8IEyZx0iYbcID33kOrTIqCewyjgt4crqdA8dlXC8G4wSD7xM+qDAyY5C4wCjzkBLKEMP+9ROR26Mt2g3nVBLxNiGM+mzQvMRl8coq23eMLGcv6l/uB24Hybm8Ym3A0wtU3SrN1j5Smj7HFvvPcOg4LdW/HQOTXE6t5mrGXcTyUzTyUjjKvGJiBQcTbE3Ct8Z+c6RZthW7lJ+EAwe13sWpS8l8QOSWb1MGuUzCUfKvCQSXcn5GYjnbEgCaQl+3yibTDSiE53fok3GqQ+hXT00aUaDIFI6xj2MQ6kD4pleCX6Hfv7ai4CoU1aNR29SmwAMYkM1kgQT0vFsxT35IZtrsC9PoFGgYSmR/h7XihdDoBpG/xaFmkcpCAFcp2EMox9gFYAKdm4lTagUmZ2j0MSJ3g3iG5k8m3BkI61h4S9Y2ST461EC/HdMRMgcUfxbgt12TnGtpMNMWKO2D35zhcoX0JZ959/TlZlItBcL9PsDs8yXuCLgE1TEBK8KsGDq1MI/HWiTzuG8EKj1/tKhKyI61RjXG7pC+stTytWMyvy94upY9SDhhJHKV0cNztgQ4QlMJwgZhAHy3xp2IZ3TA00Il1g/QZ1IA4jogOQtHmhz/77cmOZaKFmg1a0Sd33FLzm8ZFMBgj6JT9n3Qm4UxtQRqcJW7w03joKJ72h9iHZu8k6zKg0MKBSWvmR44jJvdGKun3tYkj27xOd09amRdM1v6+Ung8tl44waC/0cJUkTfjMgRQKZWM74+gppUFX+/ofwxvKBluUp/upva5mMOSFXXSSuLTyDZNKQTShMbft58TmutWS4IuURpF1AEbTQ4RmLUdWRFPDBs3ZBeFnouV+nuzdsPIQDeUasa6FUAPB0iEKOw0me0UZTVGDJnxc/1hg6Hwc5GEOBzEjdfdcKkhP/Z0+XTosDoBGQLpu74ULcHo1V2TWVsAa6ZWllAkGq3kM+qOy/tWVovC7uw58gPOg2oLSsC9lL3lzXStO5l6HDh/Y90AM33WGCNbhRJzxcHOx4iWYaCeCXraqaYSmFOgo3KM/dTu9fxZEZRcvZK89LizMAk9I+WVJTRMNz602LTLqC1V1Pvfw0TOuinjAC5SHQx3iR+e70CEJQ6CxRshloi0zXCxX2Czg/EDGE0Ke3OPGh4u0NHbrcJ3VlLa/ujTpp3liJzdfki4iKIV6rRh89ElJPNVwDT7FQ=')
_tag = base64.b64decode('eXL1Mp8zWZvIJM3Oq+fubw==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
