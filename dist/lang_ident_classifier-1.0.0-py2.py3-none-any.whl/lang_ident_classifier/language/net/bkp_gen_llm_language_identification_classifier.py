# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from _d6ab9383440c import _f3cbd0c15e92
import _fd007ae3edcd
from _da7368983917 import _4152b1c4ef8c
import _28af3b34e719
import _de778e62821f
import _4d3d441f86ab
from _fe71e3dd47a1 import _9cdec0862b18
import _e04276b3bdfa as _1e2b6a0189a2
import _00c65b70d24e as _4d1b180152de
import _a4cb8ed367e3
import _4a23a9eaee6e as _51c93225ddd2
from _5680984c0b5b._138a805c5046._cc1277db0afa._28d7da2dadd9 import _6156cb5cedb1
from _55b9c3674cd9 import _4b9c71a63881, _5708014fff86, _66eeef8de6d9, _dc5e0931a5a5, _9b4b976f78ec

from _e8028525a75e._82aa3446cc8e._817790f5830b._7a7d157945d2 import _83fa5fc8d396
from _e8028525a75e._82aa3446cc8e._265463477260._025b85045e76 import _8ef632256ca2
from _e8028525a75e._82aa3446cc8e._265463477260._03683bca76b7 import _1ac95ead7df4
from _e8028525a75e._82aa3446cc8e._265463477260._8ac684bc9baa import _ce47f3e00b34
from _e8028525a75e._82aa3446cc8e._f24b133db086._80241cba92d8 import _3e6aca7eab06
# expose only the classifier from the module
_362de7437da2 = ["GenLLMLanguageIdentificationClassifier"]

_840cf7774873 = 'cuda' if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042() else 'cpu'
_7377a7cd0ebf = _de2bbc67ebe9  # global frozen embedding (kept for compatibility)

class _bb3e768b94ad(_51c93225ddd2._ede801de1483):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _eee2d414fb61(_a4cb8ed367e3._e74dc8d2dc43._53ffc48625a4):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _f295862577f3(self, _3bfb5cff0f28: _3b8ed8ee71dc, _9c3665491ed0: _3b8ed8ee71dc = 64):
            _f678a18b4554()._9162d54fe2c7()
            self._236464a75c10 = _a4cb8ed367e3._e74dc8d2dc43._929fa73f12d3(_3bfb5cff0f28, _9c3665491ed0, _0c13d5842f3b=_450c540b12f6)
            self._d839e3e4362a = _a4cb8ed367e3._e74dc8d2dc43._f3e07434c411(_73787235c231=_04770ef21697)
            self._3c3892b83f1b = _a4cb8ed367e3._e74dc8d2dc43._929fa73f12d3(_9c3665491ed0, _3bfb5cff0f28, _0c13d5842f3b=_450c540b12f6)
            # start adapter near-zero so initial behavior is identity
            _a4cb8ed367e3._e74dc8d2dc43._5f63975dc396._289dc851e4a5(self._3c3892b83f1b._e03bdc63f959)
            _a4cb8ed367e3._e74dc8d2dc43._5f63975dc396._d2ee6c33ea00(self._236464a75c10._e03bdc63f959, _5d68ee21676d=_de778e62821f._e5c02a4cf556(5))

        def _1a61ef9c75a0(self, _18ecc877bf3a: _a4cb8ed367e3._16691f8fa3f4) -> _a4cb8ed367e3._16691f8fa3f4:
            # supports x shape (B, L, D) or (B, D)
            if _18ecc877bf3a._3bfb5cff0f28() == 2:
                _da11fcc07e70 = self._3c3892b83f1b(self._d839e3e4362a(self._236464a75c10(_18ecc877bf3a)))
                return _18ecc877bf3a + _da11fcc07e70
            _55b64f8bdd28, _61edad14fb7d, _4f4284f1393b = _18ecc877bf3a._cdf1acb5e498
            _994378389bb0 = _18ecc877bf3a._14119f862212(-1, _4f4284f1393b)                    # (B*L, D)
            _994378389bb0 = self._3c3892b83f1b(self._d839e3e4362a(self._236464a75c10(_994378389bb0)))  # (B*L, D)
            _994378389bb0 = _994378389bb0._14119f862212(_55b64f8bdd28, _61edad14fb7d, _4f4284f1393b)
            return _18ecc877bf3a + _994378389bb0
        
    class _2b88afd717a4(_a4cb8ed367e3._e74dc8d2dc43._53ffc48625a4):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _f295862577f3(self, _e29134623030, _01667390aa3f=-5, _a6d8a1999cc1=5):
            _f678a18b4554()._9162d54fe2c7()
            self._e29134623030 = _e29134623030
            self._01667390aa3f = _01667390aa3f
            self._a6d8a1999cc1 = _a6d8a1999cc1
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _1a61ef9c75a0(self, *_e5a343c35156, **_5bcfe6815e19):
            _e5a343c35156 = _dcd8a39f67d9(
                _a5972968f284._55e10776ec94(_a4cb8ed367e3._4ed3e0c42556)._3b612d5234ab(-10, 10) if _28640f8ea606(_a5972968f284, _a4cb8ed367e3._16691f8fa3f4) and _a5972968f284._fe384459fbb5 != _a4cb8ed367e3._4ed3e0c42556 else _a5972968f284
                for _a5972968f284 in _e5a343c35156
            )
            for _adb50f6ca53a, _a5972968f284 in _38c1bce97c99(_e5a343c35156):
                if _28640f8ea606(_a5972968f284, _a4cb8ed367e3._16691f8fa3f4) and not _a4cb8ed367e3._78b16e33edb6(_a5972968f284)._6752092ad5cd():
                    _a5972968f284 = _a4cb8ed367e3._81272a32356a(_a5972968f284)
            _f0d8669d26aa = self._e29134623030(*_e5a343c35156, **_5bcfe6815e19)
            if _28640f8ea606(_f0d8669d26aa, _a4cb8ed367e3._16691f8fa3f4):
                _f0d8669d26aa = _f0d8669d26aa._55e10776ec94(_a4cb8ed367e3._4ed3e0c42556)
                if not _a4cb8ed367e3._78b16e33edb6(_f0d8669d26aa)._6752092ad5cd():
                    _f0d8669d26aa = _a4cb8ed367e3._81272a32356a(_f0d8669d26aa)
                _f0d8669d26aa._8ad5cc6d675e(self._01667390aa3f, self._a6d8a1999cc1)
            return _f0d8669d26aa

    # --- original __init__ signature and body preserved ---
    def _f295862577f3(
        self,
        _c2a1e3e5a21d,
        _3a2ef9f28f9f,
        _f5f858703379,
        _03118cf5c23c,
        _ba4aff99f957,
        _1d09047fd5fb,
        _f29edb489256,
        _0365dd0e06e2,
        _19cbe5706def,
        _bf8e80376dc5,
        _67d77eeb072b,
        _82ba58967d20: _3b8ed8ee71dc = 20,
        _3de7c8cb00ad = _de2bbc67ebe9,
        _bacfb250e741=_de2bbc67ebe9,
        _74fe6ee7cc80=0.9,
        _7ce6f747408f:_7dceaef94846=_de2bbc67ebe9,
    ):
        _f678a18b4554(_84650320c6bf, self)._9162d54fe2c7()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._948128e34ea8({
            "lr": _7d7e6017c913(_f5f858703379),
            "optimizer": _7dceaef94846(_03118cf5c23c),
            "num_backbone_model_units_unfrozen": _3b8ed8ee71dc(_f29edb489256),
            "loss_type": _7dceaef94846(_0365dd0e06e2),
            "is_train": _73722fe36730(_19cbe5706def),
            "random_seed": _3b8ed8ee71dc(_82ba58967d20),
        })
        self._82ba58967d20 = _82ba58967d20
        _51c93225ddd2._60a0ba2c4800(_82ba58967d20, _ff35b03f5ea2=_04770ef21697)
        _a4cb8ed367e3._238fb0d0f44c(_82ba58967d20)
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            _a4cb8ed367e3._feeb3aadf1a0._c4d8bc98e5d1(_82ba58967d20)
        _1e2b6a0189a2._dcc14b8fcbd2._1565d9beec52(_82ba58967d20)
        self._bacfb250e741 = _3b8ed8ee71dc(_bacfb250e741) if _bacfb250e741 is not _de2bbc67ebe9 else _de2bbc67ebe9
        self._bf8e80376dc5 = _bf8e80376dc5
        self._7ce6f747408f = _7ce6f747408f
        # TODO: REMOVE THIS HARDCODING
        if not self._bf8e80376dc5._4c99a5cf6a46:
            self._bf8e80376dc5._4c99a5cf6a46 = 128004  # <|finetune_right_pad_id|>
        self._b38d9df8a1df = _bf8e80376dc5._ce72385f7956(" ", _63c21a2dc92d=_450c540b12f6)[0]
        self._251b03368c66 = (
            _a4cb8ed367e3._6f78e92fd981("cuda:{}"._38b9d065e939(_1d09047fd5fb["gpu_local_rank"]))
            if _1d09047fd5fb["gpu_local_rank"] != -1
            else "cpu"
        )
        self._3de7c8cb00ad = _3de7c8cb00ad
        self._b632a3efbd1f = _66f48939deb7(_3a2ef9f28f9f)
        self._74fe6ee7cc80 = _74fe6ee7cc80
        self._3a2ef9f28f9f =  ["unk"] + _3a2ef9f28f9f if self._74fe6ee7cc80 > 0 else _3a2ef9f28f9f
        self._c39a802ef867 = {}
        for _dc9278f849b4, _a0d9035b3ea7 in _38c1bce97c99(self._3a2ef9f28f9f):
            _3d48d26c1d1c = self._bf8e80376dc5._ce72385f7956(_a0d9035b3ea7, _63c21a2dc92d=_450c540b12f6)
            self._c39a802ef867[_dc9278f849b4] = _3d48d26c1d1c
        self._af6208279c83 = {_dcd8a39f67d9(_3d48d26c1d1c): _18b603d022e3 for _18b603d022e3, _3d48d26c1d1c in self._c39a802ef867._d9d308093632()}
        self._30e12ed4d8ba = _f3cbd0c15e92(_49f4cbafc07e)
        for _5800511edbe2, _3d48d26c1d1c in self._c39a802ef867._d9d308093632():
            self._30e12ed4d8ba[_66f48939deb7(_3d48d26c1d1c)]._c87d6debe366((_5800511edbe2, _3d48d26c1d1c))
        self._50e1abc69672 = 0
        _42f25067f63b(f"SEQ {self._c39a802ef867} and {self._af6208279c83}")
        self._f2b04c98c793 = _bf8e80376dc5._4c99a5cf6a46 or _bf8e80376dc5._546757cd06a8
        self._ba4aff99f957 = _ba4aff99f957
        self._e07c4aadd518 = "multiclass"
        self._8998152c8b24 = -100
        self._b2d28c384d9f = _bf8e80376dc5._ce72385f7956("assistant<|end_header_id|>\n\n", _63c21a2dc92d=_450c540b12f6)
        self._651232d32ea5 = self._b480dfb6fe0d()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._b9e71008125d = _c2a1e3e5a21d
        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._b9e71008125d._15ce2d629ec2(_450c540b12f6)
        _c10119caae17 = _3e6aca7eab06()  # bfloat16 or float16

        for _ec7d54214fc2, _e29134623030 in self._058791ac88bb():
            if not _19044bafd402(_67b4a24ed3f1._6fe78e811eac for _67b4a24ed3f1 in _e29134623030._e25ab13a243d(_5db171bdec3e=_450c540b12f6)):
                # FROZEN → BF16 (save memory)
                _e29134623030._55e10776ec94(_fe384459fbb5=_c10119caae17)
            else:
                # TRAINABLE → FP32 (stable grads)
                _e29134623030._55e10776ec94(_fe384459fbb5=_a4cb8ed367e3._4ed3e0c42556)
        self._b9e71008125d._55e10776ec94(self._251b03368c66)
        if _102b85b973e7(self._b9e71008125d, "gradient_checkpointing_enable"):
            self._b9e71008125d._523955e70f6c()
        # determine embedding dim robustly from model config if available
        _8bf1ec1ab9f3 = _9b447463bd94(_9b447463bd94(self._b9e71008125d, "config", _de2bbc67ebe9), "hidden_size", _de2bbc67ebe9)
        if _8bf1ec1ab9f3 is _de2bbc67ebe9:
            # fallback to common default — change if your model uses a different hidden size
            _8bf1ec1ab9f3 = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _102b85b973e7(self._b9e71008125d, "lm_head") and _9b447463bd94(self._b9e71008125d, "lm_head") is not _de2bbc67ebe9:
            self._f82e9b65c474 = self._b9e71008125d._5173bec54a4e
        else:
            _e9a39c50621c = _9b447463bd94(self._b9e71008125d, "get_output_embeddings", _de2bbc67ebe9)
            self._f82e9b65c474 = _e9a39c50621c() if _2333b101f740(_e9a39c50621c) else _de2bbc67ebe9

        # mark presence and ensure module (if any) is on the same device
        self._505911f01e3e = self._f82e9b65c474 is not _de2bbc67ebe9
        if self._505911f01e3e:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._f82e9b65c474._55e10776ec94(self._251b03368c66)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._b401f2be550d = self._7b41caf86c08(_3bfb5cff0f28=_8bf1ec1ab9f3, _9c3665491ed0=64)
        self._b401f2be550d._55e10776ec94(self._251b03368c66)
        for _67b4a24ed3f1 in self._b401f2be550d._e25ab13a243d():
            _67b4a24ed3f1._6fe78e811eac = _04770ef21697
            
        if _f29edb489256 > 0:
            if "llama" in self._3de7c8cb00ad:
                for _e35293137da2 in self._b9e71008125d._e25ab13a243d():
                    if not _e35293137da2._a4b6c327a224:
                        _e35293137da2 = _e35293137da2._24c81606afc9()
                    _e35293137da2._6fe78e811eac = _450c540b12f6  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _c1d29fb2dc3b = self._b9e71008125d._e724248b3b1f._a66de6505670  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _b660ef22ed22 in _c1d29fb2dc3b[-_f29edb489256:]:
                    for _e35293137da2 in _b660ef22ed22._e25ab13a243d():
                        if _28640f8ea606(_e35293137da2, _a4cb8ed367e3._16691f8fa3f4) and (_e35293137da2._3e388635b369() or _a4cb8ed367e3._39a9c57ec5a4(_e35293137da2)):
                            _e35293137da2._6fe78e811eac = _04770ef21697
                if _102b85b973e7(self._b9e71008125d, "lm_head"):
                    self._b9e71008125d._5173bec54a4e._6fe78e811eac = _04770ef21697

        self._6000ca7350aa = 1
        _42f25067f63b(f"DEBUG xth_batch init {self._6000ca7350aa}")
        global _7377a7cd0ebf
        _7377a7cd0ebf = _fd007ae3edcd._2bf45e894e9d(self._b9e71008125d)._eff6b96482ca()
        self._f5f858703379 = _f5f858703379

        self._6badf1225ef8 = {}
        self._23b2f4a826f3 = {}

        # Loss function initialization
        if _0365dd0e06e2._c2c20df93c03() == "class_weighted_cross_entropy_loss":
            self._23b2f4a826f3['criterion'] = _1ac95ead7df4(_ba4aff99f957=self._ba4aff99f957,
                                                            _6f78e92fd981=self._251b03368c66,
                                                            _9a8a0a38871a=self._8998152c8b24,
                                                            _3b547cd0697e=self._b38d9df8a1df)
        elif _0365dd0e06e2._c2c20df93c03() == "focal_loss":
            self._23b2f4a826f3['criterion'] = _ce47f3e00b34(_1046fff47234=0.25,
                                                     _6f78e92fd981=self._251b03368c66,
                                                     _9a8a0a38871a=self._8998152c8b24,
                                                     _3b547cd0697e=self._b38d9df8a1df)
        elif _0365dd0e06e2._c2c20df93c03() == "class_weighted_focal_loss":
            self._23b2f4a826f3['criterion'] = _ce47f3e00b34(_1046fff47234=self._ba4aff99f957,
                                                     _6f78e92fd981=self._251b03368c66,
                                                     _9a8a0a38871a=self._8998152c8b24,
                                                     _3b547cd0697e=self._b38d9df8a1df)
        elif _0365dd0e06e2._c2c20df93c03() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._23b2f4a826f3['criterion'] = _8ef632256ca2(_1046fff47234=self._ba4aff99f957,
                                                                      _0b95332e93d3='type1',
                                                                      _6f78e92fd981=self._251b03368c66,
                                                                      _9a8a0a38871a=self._8998152c8b24,
                                                                      _3b547cd0697e=self._b38d9df8a1df)
        elif _0365dd0e06e2._c2c20df93c03() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._23b2f4a826f3['criterion'] = _8ef632256ca2(_1046fff47234=self._ba4aff99f957,
                                                                      _0b95332e93d3='type2',
                                                                      _6f78e92fd981=self._251b03368c66,
                                                                      _9a8a0a38871a=self._8998152c8b24,
                                                                      _3b547cd0697e=self._b38d9df8a1df)
        elif _0365dd0e06e2._c2c20df93c03() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._23b2f4a826f3['criterion'] = _8ef632256ca2(_1046fff47234=self._ba4aff99f957,
                                                                      _0b95332e93d3='type3',
                                                                      _6f78e92fd981=self._251b03368c66,
                                                                      _9a8a0a38871a=self._8998152c8b24,
                                                                      _3b547cd0697e=self._b38d9df8a1df)
        else:
            self._23b2f4a826f3['criterion'] = _1ac95ead7df4(_6f78e92fd981=self._251b03368c66,
                                                            _9a8a0a38871a=self._8998152c8b24,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._df78039a3c21 = 0.99
        self._40d6b159c80d = 0.3
        self._b25916df1348 = 0.30
        self._3bb3673ab568 = 0.25
        self._9e3621c310df = 0.6
        self._917fd9ea735b = 0.995
        self._3082b6b03c2d = 0.60
        self._e8762847be73 = 0.20
        self._7e977c33e935 = _9b447463bd94(self, "batch_counter", 0)


        self._cc1752e0a210 = []
        self._72204dd3bd02 = []

        self._0534b1f3d7d2 = _03118cf5c23c._c2c20df93c03()
        self._b21029770942()

        self._6339c91a6257(self._b9e71008125d)
    
    def _cf48b5e4e583(self):
        # rebuild all metrics on the correct device
        self._6badf1225ef8['micro_accuracy'] = _4b9c71a63881(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39="micro",
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['macro_accuracy'] = _4b9c71a63881(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39="macro",
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['macro_precision'] = _66eeef8de6d9(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39="macro",
            _a5e8aede25c0=self. _e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['macro_recall'] = _dc5e0931a5a5(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39="macro",
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['macro_f1'] = _9b4b976f78ec(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39="macro",
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['classwise_accuracy'] = _4b9c71a63881(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39=_de2bbc67ebe9,
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['classwise_precision'] = _66eeef8de6d9(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39=_de2bbc67ebe9,
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['classwise_recall'] = _dc5e0931a5a5(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39=_de2bbc67ebe9,
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['classwise_f1'] = _9b4b976f78ec(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _b6e1799acf39=_de2bbc67ebe9,
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)

        self._6badf1225ef8['confmat'] = _5708014fff86(
            _b632a3efbd1f=_66f48939deb7(self._3a2ef9f28f9f),
            _a5e8aede25c0=self._e07c4aadd518,
            _9a8a0a38871a=self._8998152c8b24,
        )._55e10776ec94(self._251b03368c66)


    def _4f28e0fc74b6(self, _6990479c703d=_de2bbc67ebe9):
        """Calculate batch counts and set xth_batch_to_consider."""
        _9d98b79b65f8 = 0
        _89b9ffdff694 = 0
        if self._68885214b293._0fec37696858 is not _de2bbc67ebe9:
            if _102b85b973e7(self._68885214b293._0fec37696858, 'train_dataset') and self._68885214b293._0fec37696858._10f28c674fc0 is not _de2bbc67ebe9:
                _9d98b79b65f8 = _66f48939deb7(self._68885214b293._0fec37696858._10f28c674fc0)
            if _102b85b973e7(self._68885214b293._0fec37696858, 'val_dataset') and self._68885214b293._0fec37696858._d294aceb1b31 is not _de2bbc67ebe9:
                _89b9ffdff694 = _66f48939deb7(self._68885214b293._0fec37696858._d294aceb1b31)
            _14da4aae841e = self._68885214b293._0fec37696858._14da4aae841e
            _e9f807ca7725 = (_9d98b79b65f8 + _14da4aae841e - 1) // _14da4aae841e if _9d98b79b65f8 > 0 else 1
            _065c44bdc386 = (_89b9ffdff694 + _14da4aae841e - 1) // _14da4aae841e if _89b9ffdff694 > 0 else 1
            _79f74d553dfa = _6f7fe9839cd7(_e9f807ca7725, _065c44bdc386) if _89b9ffdff694 > 0 else _e9f807ca7725
            _37e8b3ddfb03 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._6000ca7350aa = 1
            _42f25067f63b(f"DEBUG Batch Info: num_train_batches={_e9f807ca7725}, num_val_batches={_065c44bdc386}, xth_batch_to_consider={self._6000ca7350aa}")

    def _8d5f9b028027(self, _f6dc796a2b81, _7714dfc7429e):
        if _f6dc796a2b81._c2c20df93c03() == "parametric_relu":
            return _a4cb8ed367e3._e74dc8d2dc43._96b9233b796a(_7714dfc7429e=1)
        elif _f6dc796a2b81._c2c20df93c03() == "leaky_relu":
            return _a4cb8ed367e3._e74dc8d2dc43._f68daa3967d8(_73787235c231=_450c540b12f6)
        else:
            return _a4cb8ed367e3._e74dc8d2dc43._f3e07434c411(_73787235c231=_450c540b12f6)

    def _4fd808fecc58(self, _e29134623030, _0a9bbdffce74=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _ec7d54214fc2, _71997f19a4ad in _e29134623030._9959571ede5e():
            _f7d700d6d143 = f"{_0a9bbdffce74}.{_ec7d54214fc2}" if _0a9bbdffce74 else _ec7d54214fc2

            def _6dc415abe5ec(_b45a88be879e, _a5972968f284, _da11fcc07e70):
                if _28640f8ea606(_da11fcc07e70, _a4cb8ed367e3._16691f8fa3f4) and _da11fcc07e70._f9aa2828eb31()._19044bafd402():
                    _42f25067f63b(f"NaN detected in {_f7d700d6d143} ({_b45a88be879e._0d349233a128.__name__}) ({_da11fcc07e70._fe384459fbb5})")

            _71997f19a4ad._ca24032b6db7(_881275d64ead)

            self._6339c91a6257(_71997f19a4ad, _f7d700d6d143)

    def _9f761f68b640(self, _e29134623030):
        return _19044bafd402(_67b4a24ed3f1._6fe78e811eac for _67b4a24ed3f1 in _e29134623030._e25ab13a243d())

    def _420b95cc39aa(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _5cea1afc5435 = []
        for _ec7d54214fc2, _e29134623030 in self._058791ac88bb():
            if not self._121410f86382(_e29134623030):
                continue
            _1d43b04a800f = (
                "norm" in _ec7d54214fc2._898eb84f9710() or 
                "linear4bit" in _ec7d54214fc2._898eb84f9710() or 
                _19044bafd402(_d839e3e4362a in _ec7d54214fc2._898eb84f9710() for _d839e3e4362a in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _ec7d54214fc2._898eb84f9710() or 
                "dropout" in _ec7d54214fc2._898eb84f9710() or 
                _28640f8ea606(_e29134623030, (_6156cb5cedb1, _a4cb8ed367e3._e74dc8d2dc43._929fa73f12d3, _a4cb8ed367e3._e74dc8d2dc43._8d43ba075426))
            )
            if _1d43b04a800f:
                if _102b85b973e7(_e29134623030, "eps"):
                    _e29134623030._e45ad21b43dd = 1e-3
                _e29134623030 = _e29134623030._55e10776ec94(_a4cb8ed367e3._4ed3e0c42556)
                if not _28640f8ea606(_e29134623030, _84650320c6bf._370b08b4017d):
                    _5cea1afc5435._c87d6debe366((_ec7d54214fc2, _84650320c6bf._370b08b4017d(_e29134623030, _01667390aa3f=-10, _a6d8a1999cc1=10)))
        for _ec7d54214fc2, _43d1b53b64ee in _5cea1afc5435:
            _59a052287d6d, _c2dacafdebe2 = self._21cd914e6595(_ec7d54214fc2)
            if _59a052287d6d is not _de2bbc67ebe9:
                _88dde850c9ae(_59a052287d6d, _c2dacafdebe2, _43d1b53b64ee)

    def _322da26cb5a9(self, _5cc9248a734e):
        """Finds the parent module and attribute name given the full module path."""
        _0009c248436b = _5cc9248a734e._0b2b5ababf6f('.')
        _0b426c2bd92e = self
        for _9aa92ec1bca4 in _0009c248436b[:-1]:
            _0b426c2bd92e = _9b447463bd94(_0b426c2bd92e, _9aa92ec1bca4, _de2bbc67ebe9)
            if _0b426c2bd92e is _de2bbc67ebe9:
                return _de2bbc67ebe9, _de2bbc67ebe9
        return _0b426c2bd92e, _0009c248436b[-1]

    def _f0a631975d87(self, _4e88485ab994: _a4cb8ed367e3._16691f8fa3f4, _df57b075f033: _a4cb8ed367e3._16691f8fa3f4, _4e1e5aba803f: _a4cb8ed367e3._16691f8fa3f4) -> _63a49441692d:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _6f78e92fd981 = _4e88485ab994._6f78e92fd981

        # 1) gating w (use cached per-example teacher_conf if available)
        _fc96d21cb875 = _9b447463bd94(self, "_last_teacher_conf", _de2bbc67ebe9)
        if _fc96d21cb875 is _de2bbc67ebe9:
            # no teacher info => w = 0 (no distillation)
            _fbf769677918 = 0.0
        else:
            _92cf4fcee278 = (_fc96d21cb875 >= _7d7e6017c913(_9b447463bd94(self, "teacher_conf_tau", 0.6)))._7d7e6017c913()
            _fbf769677918 = _7d7e6017c913(_92cf4fcee278._a983ce9bc95f()._7dd6a12aeb0e()._654cef1c08fb()) if _92cf4fcee278._b0b231d889c3() > 0 else 0.0

        # apply gating to the batch scalars
        _5f251a692331 = _df57b075f033 * _7d7e6017c913(_fbf769677918)
        _b587126bf8dd = _4e1e5aba803f * _7d7e6017c913(_fbf769677918)

        # 2) EMAs for autoscaling
        _8fa39222f723 = _7d7e6017c913((_5f251a692331 + _b587126bf8dd)._24c81606afc9()._7dd6a12aeb0e()._654cef1c08fb())
        _21a12523b799 = _7d7e6017c913(_4e88485ab994._24c81606afc9()._7dd6a12aeb0e()._654cef1c08fb())
        if _9b447463bd94(self, "ema_task", _de2bbc67ebe9) is _de2bbc67ebe9:
            self._3366ccc27554 = _21a12523b799
            self._7473793f54f6 = _8fa39222f723 + 1e-12
        else:
            _1046fff47234 = _7d7e6017c913(_9b447463bd94(self, "ema_alpha", 0.99))
            self._3366ccc27554 = _1046fff47234 * _7d7e6017c913(self._3366ccc27554) + (1.0 - _1046fff47234) * _21a12523b799
            self._7473793f54f6  = _1046fff47234 * _7d7e6017c913(self._7473793f54f6)  + (1.0 - _1046fff47234) * _8fa39222f723

        _603838b474e6 = _7d7e6017c913(_9b447463bd94(self, "distill_target_ratio", 0.3))
        _e0eb3be5c893 = (_7d7e6017c913(self._3366ccc27554) / (_7d7e6017c913(self._7473793f54f6) + 1e-12)) * _603838b474e6
        _f16c8c5ed630 = _7d7e6017c913(_e0eb3be5c893)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _559a579bc6a0 = _7d7e6017c913(_9b447463bd94(self._68885214b293, "current_epoch", _9b447463bd94(self._68885214b293, "global_step", 0.0)))
        _bfc47f38205c = _7d7e6017c913(_6124eecaec69(1, _9b447463bd94(self._68885214b293, "max_epochs", 1)))
        _63ba109ccbd5 = _6f7fe9839cd7(_6124eecaec69(_559a579bc6a0 / _bfc47f38205c, 0.0), 1.0)
        _d5b2cb208938 = 0.30
        _e78b680ec669 = _7d7e6017c913(_9b447463bd94(self, "kl_base", 0.30)) * _6f7fe9839cd7(_63ba109ccbd5 / _d5b2cb208938, 1.0)
        _3bb3673ab568 = _7d7e6017c913(_9b447463bd94(self, "cos_base", 0.25))
        _cc9e98e1fb86 = _3bb3673ab568 + (0.10 - _3bb3673ab568) * _63ba109ccbd5

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _78c214339c60 = _7d7e6017c913(self._9cc766965e23._a983ce9bc95f()._7dd6a12aeb0e()._654cef1c08fb()) if _9b447463bd94(self, "_last_teacher_conf", _de2bbc67ebe9) is not _de2bbc67ebe9 else 0.0
        if _9b447463bd94(self, "ema_teacher_conf", _de2bbc67ebe9) is _de2bbc67ebe9:
            self._cee18e4e7501 = _78c214339c60
        else:
            _55b64f8bdd28 = _7d7e6017c913(_9b447463bd94(self, "teacher_conf_beta", 0.995))
            self._cee18e4e7501 = _55b64f8bdd28 * _7d7e6017c913(self._cee18e4e7501) + (1.0 - _55b64f8bdd28) * _78c214339c60

        _3082b6b03c2d = _7d7e6017c913(_9b447463bd94(self, "tau_warn", 0.60))
        _e8762847be73 = _7d7e6017c913(_9b447463bd94(self, "tau_detect", 0.20))
        _b8fc6a83fef1 = _6124eecaec69(1e-12, (_3082b6b03c2d - _e8762847be73))
        _44921d81928b = (_7d7e6017c913(self._cee18e4e7501) - _e8762847be73) / _b8fc6a83fef1
        _44921d81928b = _6124eecaec69(0.0, _6f7fe9839cd7(1.0, _44921d81928b))

        _a4f0b61bbb53 = _e78b680ec669 * _44921d81928b
        _d17bf026cf67 = _cc9e98e1fb86 * _44921d81928b

        # 5) final aux term
        _28e1a974f3c6 = _a4cb8ed367e3._73b31ea9cba9(0.0, _6f78e92fd981=_6f78e92fd981)
        _28e1a974f3c6 = _28e1a974f3c6 + (_a4f0b61bbb53 * _5f251a692331 + _d17bf026cf67 * _b587126bf8dd) * _7d7e6017c913(_f16c8c5ed630)

        # diagnostics
        _da11fcc07e70 = {
            "aux_term": _28e1a974f3c6,
            "kl_batch": _df57b075f033,
            "contrast_batch": _4e1e5aba803f,
            "kl_loss": _5f251a692331,
            "contrastive_loss": _b587126bf8dd,
            "w_mean": _fbf769677918,
            "aux_scale": _7d7e6017c913(_f16c8c5ed630),
            "lambda_kl_eff": _7d7e6017c913(_a4f0b61bbb53),
            "lambda_cos_eff": _7d7e6017c913(_d17bf026cf67),
            "teacher_conf_mean": _7d7e6017c913(self._cee18e4e7501),
            "shift_r": _7d7e6017c913(_44921d81928b)
        }
        return _da11fcc07e70

    def _1a61ef9c75a0(self, _c3cf90f4a7f0):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _c3cf90f4a7f0 = _c3cf90f4a7f0._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)
        _15a94a640c8d = (_c3cf90f4a7f0 != self._bf8e80376dc5._4c99a5cf6a46)._55e10776ec94(_fe384459fbb5=_a4cb8ed367e3._73722fe36730, _6f78e92fd981=self._251b03368c66, _70e42dbefc39=_04770ef21697)

        # model forward (request hidden states)
        _696103442c8f = self._b9e71008125d(
            _c3cf90f4a7f0=_c3cf90f4a7f0,
            _15a94a640c8d=_15a94a640c8d,
            _77c9f6636990=_04770ef21697,
            _ce7f056cf465=_04770ef21697,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _244262b6c168 = _9b447463bd94(_696103442c8f, "last_hidden_state", _de2bbc67ebe9)
        if _244262b6c168 is _de2bbc67ebe9:
            _244262b6c168 = _696103442c8f._7b0afa4cc35c[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _244262b6c168._fe384459fbb5 != _a4cb8ed367e3._4ed3e0c42556:
            _244262b6c168 = _244262b6c168._55e10776ec94(_a4cb8ed367e3._4ed3e0c42556)
        _3ed4570419f7 = self._b401f2be550d(_244262b6c168)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._505911f01e3e:
            _c66d788bd9b6 = self._f82e9b65c474(_3ed4570419f7)
        else:
            _c66d788bd9b6 = _696103442c8f._c66d788bd9b6


        _c66d788bd9b6 = _c66d788bd9b6._55e10776ec94(_a4cb8ed367e3._4ed3e0c42556)._3b612d5234ab(-20, 20)

        # default zero scalars
        _5f251a692331 = _a4cb8ed367e3._73b31ea9cba9(0.0, _6f78e92fd981=self._251b03368c66)
        _b587126bf8dd = _a4cb8ed367e3._73b31ea9cba9(0.0, _6f78e92fd981=self._251b03368c66)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _624a909cc26a = _9b447463bd94(self, "trainer", _de2bbc67ebe9)
        _35b2107b2dac = _450c540b12f6
        if _624a909cc26a is not _de2bbc67ebe9:
            _35b2107b2dac = _73722fe36730(_9b447463bd94(self._68885214b293, "training", _450c540b12f6) or _9b447463bd94(self._68885214b293, "validating", _450c540b12f6))

        if _35b2107b2dac and (_9b447463bd94(self, "batch_counter", 0) % _9b447463bd94(self, "xth_batch_to_consider", 1) == 0):
            with _a4cb8ed367e3._591e3288e08c():
                _fa626c4a21c5 = _7377a7cd0ebf(
                    _c3cf90f4a7f0=_c3cf90f4a7f0,
                    _15a94a640c8d=_15a94a640c8d,
                    _77c9f6636990=_04770ef21697,
                    _ce7f056cf465=_04770ef21697,
                )
                _f45f7b24e0ea = _9b447463bd94(_fa626c4a21c5, "last_hidden_state", _de2bbc67ebe9)
                if _f45f7b24e0ea is _de2bbc67ebe9:
                    _f45f7b24e0ea = _fa626c4a21c5._7b0afa4cc35c[-1]

            # compute embedding-level KL + contrastive (scalar)
            _5f251a692331, _b587126bf8dd = self._43437312b240(_3ed4570419f7, _f45f7b24e0ea, _6f78e92fd981=self._251b03368c66)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _db60b5097206(_18ecc877bf3a): return _18ecc877bf3a._a983ce9bc95f(_3bfb5cff0f28=1) if _18ecc877bf3a._3bfb5cff0f28() == 3 else _18ecc877bf3a
            _7f4aa2200ae7 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._80dc9f02e267(_ec24637ecfb9(_3ed4570419f7), _67b4a24ed3f1=2, _3bfb5cff0f28=-1, _e45ad21b43dd=1e-6)
            _c24e46a2295c = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._80dc9f02e267(_ec24637ecfb9(_f45f7b24e0ea), _67b4a24ed3f1=2, _3bfb5cff0f28=-1, _e45ad21b43dd=1e-6)
            _863c0554e484 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._33746df68baa(_7f4aa2200ae7, _c24e46a2295c, _3bfb5cff0f28=-1)  # [-1,1]
            _fc96d21cb875 = _863c0554e484._3b612d5234ab(_6f7fe9839cd7=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._73fd9ade6cc7 = _3ed4570419f7._24c81606afc9()
            self._fd233d0c8b28 = _f45f7b24e0ea._24c81606afc9()
            self._9cc766965e23 = _fc96d21cb875._24c81606afc9()  # shape (B,)

        # increment counter
        self._7e977c33e935 = _9b447463bd94(self, "batch_counter", 0) + 1

        return _c66d788bd9b6, _5f251a692331, _b587126bf8dd


    def _57ba906a8345(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _ebbe1b61a3a9(_e29134623030, _e5a343c35156, _6628cc710cf5):
            if _19044bafd402(_a5972968f284._fe384459fbb5 == _a4cb8ed367e3._16b16bd2ce5c for _a5972968f284 in _e5a343c35156 if _28640f8ea606(_a5972968f284, _a4cb8ed367e3._16691f8fa3f4)):
                _42f25067f63b(f"Layer {_e29134623030._0d349233a128.__name__} is using float16!")

        for _5d52b435a006 in self._d76ed9305c6d():
            _f7b40f03d096 = _5d52b435a006._ca24032b6db7(_a9fc6c14f788)
            self._584f100bc2b5._c87d6debe366(_f7b40f03d096)

    def _2da1a45c51c7(self):
        """Remove all registered forward hooks."""
        for _f7b40f03d096 in _9b447463bd94(self, "amp_hooks", []):
            _f7b40f03d096._86ea61906224()
        self._584f100bc2b5 = []

    def _7c1f0047bc54(self, _c3cf90f4a7f0, _a111551f732c, _0c6e964e8e7e):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _b227d65a35c8 = [self._bf8e80376dc5._38fbb11f3e53(_a9196c21d8d3) for _a9196c21d8d3 in _c3cf90f4a7f0]
        _60af9fca1147, _01c3a9c89def = [], []

        for _a1a80cf0b409, _287a922d746a, _c079fa004715 in _19a7488ddbb7(_b227d65a35c8, _a111551f732c, _0c6e964e8e7e):
            for _415bfe9f68c1, _da604dec5905, _a5124e61fa18 in _19a7488ddbb7(_a1a80cf0b409, _287a922d746a, _c079fa004715):
                if _415bfe9f68c1 == self._bf8e80376dc5._41ea35d8d594 or _a5124e61fa18 == self._8998152c8b24:
                    continue

                _3db12b082e17 = (
                    _415bfe9f68c1._c8c586e4b304("##") or
                    _415bfe9f68c1._c8c586e4b304("▁") or
                    _415bfe9f68c1 in ["<unk>", "<pad>"]
                )

                if _3db12b082e17:
                    continue

                _60af9fca1147._c87d6debe366(_da604dec5905._654cef1c08fb())
                _01c3a9c89def._c87d6debe366(_a5124e61fa18._654cef1c08fb())

        return _a4cb8ed367e3._73b31ea9cba9(_60af9fca1147), _a4cb8ed367e3._73b31ea9cba9(_01c3a9c89def)

    def _e26bd8320e24(self):
        _ab1f58aaf469 = _a4cb8ed367e3._4ed3e0c42556
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            _bd24c2cf621b, _10d32bb4a615 = _a4cb8ed367e3._feeb3aadf1a0._273e65441935()
            if _bd24c2cf621b >= 8:
                _ab1f58aaf469 = _a4cb8ed367e3._86d47c422f5b
            else:
                _ab1f58aaf469 = _a4cb8ed367e3._16b16bd2ce5c
        return _ab1f58aaf469

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _9c9080720567(
        self,
        _07854dc89d99: _a4cb8ed367e3._16691f8fa3f4,
        _7a5b7c0e0ef7: _a4cb8ed367e3._16691f8fa3f4,
        _6f78e92fd981: _7dceaef94846 = "cpu",
    ) -> _9cdec0862b18[_a4cb8ed367e3._16691f8fa3f4, _a4cb8ed367e3._16691f8fa3f4]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _b05723ee208c = 2.0
            # NaN/Inf guard
            _07854dc89d99 = _07854dc89d99._3b612d5234ab(_6f7fe9839cd7=-30, _6124eecaec69=30)
            _7a5b7c0e0ef7 = _7a5b7c0e0ef7._3b612d5234ab(_6f7fe9839cd7=-30, _6124eecaec69=30)

            # Move once if needed
            _04d122b99c86 = _a4cb8ed367e3._6f78e92fd981(_6f78e92fd981)
            if _07854dc89d99._6f78e92fd981 != _04d122b99c86:
                _07854dc89d99 = _07854dc89d99._55e10776ec94(_6f78e92fd981=_04d122b99c86, _70e42dbefc39=_04770ef21697, _fe384459fbb5=self._651232d32ea5)
                _7a5b7c0e0ef7 = _7a5b7c0e0ef7._55e10776ec94(_6f78e92fd981=_04d122b99c86, _70e42dbefc39=_04770ef21697, _fe384459fbb5=self._651232d32ea5)

            _14da4aae841e = _07854dc89d99._799713c732cb(0)
            _8bf1ec1ab9f3 = _07854dc89d99._799713c732cb(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _96735272fc0c = (_14da4aae841e * _8bf1ec1ab9f3) > 32_000_000

            if not _96735272fc0c or _14da4aae841e <= 8:
                # Direct computation
                _567788bd0264 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._3157b82485f7(_07854dc89d99 / _b05723ee208c, _3bfb5cff0f28=-1)
                _8ddbfab6d959 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._60c09a7fa1ac(_7a5b7c0e0ef7 / _b05723ee208c, _3bfb5cff0f28=-1)
                _5f251a692331 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._c00b85df7570(_567788bd0264, _8ddbfab6d959, _e579583301d9="batchmean") * (_b05723ee208c * _b05723ee208c)
                _b587126bf8dd = 1 - _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._33746df68baa(_07854dc89d99, _7a5b7c0e0ef7, _3bfb5cff0f28=-1)._a983ce9bc95f()
                return _5f251a692331, _b587126bf8dd

            # Chunked mode for large inputs
            _876466926f7d = _6124eecaec69(1, _14da4aae841e // 8)
            _2c2a3e0da2fd, _3f53b11319f1 = [], []

            for _adb50f6ca53a in _dd3afd5f0119(0, _14da4aae841e, _876466926f7d):
                _e87c5ce330a3 = _07854dc89d99[_adb50f6ca53a:_adb50f6ca53a + _876466926f7d]
                _e99ab823d6fe = _7a5b7c0e0ef7[_adb50f6ca53a:_adb50f6ca53a + _876466926f7d]

                _567788bd0264 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._3157b82485f7(_e87c5ce330a3 / _b05723ee208c, _3bfb5cff0f28=-1)
                _8ddbfab6d959 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._60c09a7fa1ac(_e99ab823d6fe / _b05723ee208c, _3bfb5cff0f28=-1)

                _3bd0692ae3fa = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._c00b85df7570(_567788bd0264, _8ddbfab6d959, _e579583301d9="batchmean") * (_b05723ee208c * _b05723ee208c)
                _d5b5b0d67025 = _a4cb8ed367e3._e74dc8d2dc43._73c50eb7700c._33746df68baa(_e87c5ce330a3, _e99ab823d6fe, _3bfb5cff0f28=-1)._a983ce9bc95f()
                _e2015f6b412d = 1 - _d5b5b0d67025

                _2c2a3e0da2fd._c87d6debe366(_3bd0692ae3fa)
                _3f53b11319f1._c87d6debe366(_e2015f6b412d)

            _5f251a692331 = _a4cb8ed367e3._6df9813c6796(_2c2a3e0da2fd)._a983ce9bc95f()
            _b587126bf8dd = _a4cb8ed367e3._6df9813c6796(_3f53b11319f1)._a983ce9bc95f()
            return _5f251a692331, _b587126bf8dd

        except _f02a48a95f7b as _e5a8288209fc:
            raise _66a0613a5d3e(f"KL/contrastive loss computation failed: {_7dceaef94846(_e5a8288209fc)}")


    def _f7caae2907e9(self, _c57cd35b8e87, _0fb392249512):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _c3cf90f4a7f0 = _c57cd35b8e87["input_ids"]
            _96a5e3af3a0d = _c57cd35b8e87["labels"]
            _54be019ff6b0 = _c57cd35b8e87._d5c03787f3f3("prompt_lens", _de2bbc67ebe9)
            _14da4aae841e = _c3cf90f4a7f0._799713c732cb(0)

            # move to device
            _c3cf90f4a7f0 = _c3cf90f4a7f0._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)
            _96a5e3af3a0d = _96a5e3af3a0d._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _6628cc710cf5, _df57b075f033, _4e1e5aba803f = self(_c3cf90f4a7f0)

            # causal LM shift for next-token classification (unchanged)
            _049108a9bd2c = _6628cc710cf5[:, :-1, :]._55aa48a8922c()
            _7bf9d15d1240 = _96a5e3af3a0d[:, 1:]._55aa48a8922c()
            _6793e6957402 = _049108a9bd2c._14119f862212(-1, _049108a9bd2c._799713c732cb(-1))
            _21d547a7ca68 = _7bf9d15d1240._14119f862212(-1)

            # classification/task loss
            _a2ba2685e0f7 = self._23b2f4a826f3['criterion'](_6793e6957402, _21d547a7ca68)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _df57b075f033 = _a4cb8ed367e3._81272a32356a(_df57b075f033, _fcb6fdc27af6=0.0, _11821f28afdd=0.0, _b5cf2a15269f=0.0)
            _4e1e5aba803f = _a4cb8ed367e3._81272a32356a(_4e1e5aba803f, _fcb6fdc27af6=0.0, _11821f28afdd=0.0, _b5cf2a15269f=0.0)
            _a2ba2685e0f7 = _a4cb8ed367e3._81272a32356a(_a2ba2685e0f7, _fcb6fdc27af6=0.0, _11821f28afdd=0.0, _b5cf2a15269f=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _49c3c52c1b14 = self._d8fd7a295967(_a2ba2685e0f7, _df57b075f033, _4e1e5aba803f)
            _28e1a974f3c6 = _49c3c52c1b14["aux_term"]

            # final combined loss (single-equation)
            _eacd80955027 = _a2ba2685e0f7 + _28e1a974f3c6

            # Optional NaN print as before (keeps your original check)
            if _a4cb8ed367e3._f9aa2828eb31(_a2ba2685e0f7):
                _42f25067f63b(f"Step {_0fb392249512}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _148388a839e8 = {
                "epoch": _7d7e6017c913(_9b447463bd94(self, "current_epoch", _9b447463bd94(self._68885214b293, "current_epoch", 0))),
                "train_kl_loss": _49c3c52c1b14._d5c03787f3f3("kl_loss", _df57b075f033)._24c81606afc9() if _28640f8ea606(_49c3c52c1b14._d5c03787f3f3("kl_loss", _df57b075f033), _a4cb8ed367e3._16691f8fa3f4) else _49c3c52c1b14._d5c03787f3f3("kl_loss", _df57b075f033),
                "train_contrastive_loss": _49c3c52c1b14._d5c03787f3f3("contrastive_loss", _4e1e5aba803f)._24c81606afc9() if _28640f8ea606(_49c3c52c1b14._d5c03787f3f3("contrastive_loss", _4e1e5aba803f), _a4cb8ed367e3._16691f8fa3f4) else _49c3c52c1b14._d5c03787f3f3("contrastive_loss", _4e1e5aba803f),
                "train_classification_loss": _a2ba2685e0f7._24c81606afc9(),
                "train_loss": _eacd80955027._24c81606afc9(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _7d7e6017c913(_9b447463bd94(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _49c3c52c1b14._d5c03787f3f3("lambda_kl_eff", _7d7e6017c913(_9b447463bd94(self, "kl_base", 0.30))),
                "train_lambda_contrast": _49c3c52c1b14._d5c03787f3f3("lambda_cos_eff", _7d7e6017c913(_9b447463bd94(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _ef32fb9e2dc5 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _ef32fb9e2dc5 in _49c3c52c1b14:
                    _5f4faafc5937 = _49c3c52c1b14[_ef32fb9e2dc5]
                    # convert single-element tensors to python floats for logging
                    if _28640f8ea606(_5f4faafc5937, _a4cb8ed367e3._16691f8fa3f4) and _5f4faafc5937._b0b231d889c3() == 1:
                        _148388a839e8[f"train_{_ef32fb9e2dc5}"] = _7d7e6017c913(_5f4faafc5937._24c81606afc9()._7dd6a12aeb0e()._654cef1c08fb())
                    else:
                        _148388a839e8[f"train_{_ef32fb9e2dc5}"] = _5f4faafc5937

            # log exactly like you did
            self._97a5c06c54c3(
                _148388a839e8,
                _14da4aae841e=_14da4aae841e,
                _1261c47ecfb9=_450c540b12f6,
                _2caed8fa4040=_04770ef21697,
                _b280de288398=_450c540b12f6,
                _25e624f63cdf=_04770ef21697,
                _fa786813e5b7=_04770ef21697,
            )

            # free references as you did
            del _c3cf90f4a7f0, _96a5e3af3a0d, _6628cc710cf5, _df57b075f033, _a2ba2685e0f7, _4e1e5aba803f, _7bf9d15d1240, _049108a9bd2c, _21d547a7ca68, _6793e6957402

            return _eacd80955027

        except _f02a48a95f7b as _e5a8288209fc:
            raise _66a0613a5d3e(f"Error in training_step: {_e5a8288209fc}") from _e5a8288209fc

    def _8a033e59349a(self):
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            _a4cb8ed367e3._feeb3aadf1a0._f0ce110aa994()
        _28af3b34e719._2edf57e607db()
        return _f678a18b4554()._4744cdbbc874()

    def _9462ac9f0ed4(self, _c57cd35b8e87, _0fb392249512):
        _c3cf90f4a7f0      = _c57cd35b8e87["input_ids"]._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)
        _96a5e3af3a0d         = _c57cd35b8e87["labels"]._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)
        _b1f1e842d83d     = _c57cd35b8e87._d5c03787f3f3("lang_codes", _de2bbc67ebe9)
        _1867ade212ac     = _c57cd35b8e87._d5c03787f3f3("sample_ids", _de2bbc67ebe9)
        _110d63d905eb      = _c57cd35b8e87._d5c03787f3f3("chunk_ids", _de2bbc67ebe9)
        _62c927c2a2a7 = _c57cd35b8e87._d5c03787f3f3("word_positions", _de2bbc67ebe9)
        _54be019ff6b0    = _c57cd35b8e87._d5c03787f3f3("prompt_lens", _de2bbc67ebe9)
        _7c3fed7ab9d9 = _c57cd35b8e87._d5c03787f3f3("num_chunks", _de2bbc67ebe9)

        _14da4aae841e = _c3cf90f4a7f0._799713c732cb(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _6628cc710cf5, _df57b075f033, _4e1e5aba803f = self(_c3cf90f4a7f0)

        # causal LM shift for next-token classification (same as training)
        _049108a9bd2c = _6628cc710cf5[:, :-1, :]._55aa48a8922c()
        _7bf9d15d1240 = _96a5e3af3a0d[:, 1:]._55aa48a8922c()
        _6793e6957402 = _049108a9bd2c._14119f862212(-1, _049108a9bd2c._799713c732cb(-1))
        _21d547a7ca68 = _7bf9d15d1240._14119f862212(-1)

        if _0fb392249512 == 0:
            try:
                _42f25067f63b(
                    f"VAL TEST BATCH {_0fb392249512} Input IDs: {_c3cf90f4a7f0._34ced47536a1()[0]}, "
                    f"Predictions: {_a4cb8ed367e3._f4b1c1ae158f(_049108a9bd2c, _3bfb5cff0f28=-1)._34ced47536a1()[0]}, "
                    f"Labels: {_7bf9d15d1240._34ced47536a1()[0]}"
                )
            except _f02a48a95f7b:
                # printing should never crash validation
                pass

        # classification loss
        _a2ba2685e0f7 = self._23b2f4a826f3['criterion'](_6793e6957402, _21d547a7ca68)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _df57b075f033 = _a4cb8ed367e3._81272a32356a(_df57b075f033, _fcb6fdc27af6=0.0, _11821f28afdd=0.0, _b5cf2a15269f=0.0)
        _4e1e5aba803f = _a4cb8ed367e3._81272a32356a(_4e1e5aba803f, _fcb6fdc27af6=0.0, _11821f28afdd=0.0, _b5cf2a15269f=0.0)
        _a2ba2685e0f7 = _a4cb8ed367e3._81272a32356a(_a2ba2685e0f7, _fcb6fdc27af6=0.0, _11821f28afdd=0.0, _b5cf2a15269f=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _49c3c52c1b14 = self._d8fd7a295967(_a2ba2685e0f7, _df57b075f033, _4e1e5aba803f)
        _28e1a974f3c6 = _49c3c52c1b14["aux_term"]
        _eacd80955027 = _a2ba2685e0f7 + _28e1a974f3c6

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _97a5c06c54c3 = {
            "val_kl_loss": _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("kl_loss", _df57b075f033)._24c81606afc9()._7dd6a12aeb0e()._654cef1c08fb()) if _28640f8ea606(_49c3c52c1b14._d5c03787f3f3("kl_loss", _df57b075f033), _a4cb8ed367e3._16691f8fa3f4) else _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("kl_loss", _df57b075f033)),
            "val_contrastive_loss": _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("contrastive_loss", _4e1e5aba803f)._24c81606afc9()._7dd6a12aeb0e()._654cef1c08fb()) if _28640f8ea606(_49c3c52c1b14._d5c03787f3f3("contrastive_loss", _4e1e5aba803f), _a4cb8ed367e3._16691f8fa3f4) else _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("contrastive_loss", _4e1e5aba803f)),
            "val_classification_loss": _7d7e6017c913(_a2ba2685e0f7._24c81606afc9()._7dd6a12aeb0e()._654cef1c08fb()),
            "val_loss": _7d7e6017c913(_eacd80955027._24c81606afc9()._7dd6a12aeb0e()._654cef1c08fb()),
        }

        # include effective lambdas and others if provided by aux
        _97a5c06c54c3["val_lambda_kl"] = _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("lambda_kl", _49c3c52c1b14._d5c03787f3f3("lambda_kl_eff", _7d7e6017c913(_9b447463bd94(self, "kl_base", 0.30)))))
        _97a5c06c54c3["val_lambda_contrast"] = _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("lambda_cos", _49c3c52c1b14._d5c03787f3f3("lambda_cos_eff", _7d7e6017c913(_9b447463bd94(self, "cos_base", 0.25)))))
        _97a5c06c54c3["val_w_mean"] = _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("w_mean", 0.0))
        _97a5c06c54c3["val_aux_scale"] = _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("aux_scale", 0.0))
        _97a5c06c54c3["val_shift_r"] = _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("shift_r", 0.0))
        _97a5c06c54c3["val_teacher_conf_mean"] = _7d7e6017c913(_49c3c52c1b14._d5c03787f3f3("teacher_conf_mean", 0.0))

        self._97a5c06c54c3(
            _97a5c06c54c3,
            _14da4aae841e=_14da4aae841e,
            _1261c47ecfb9=_450c540b12f6,
            _2caed8fa4040=_04770ef21697,
            _b280de288398=_450c540b12f6,
            _25e624f63cdf=_04770ef21697,
            _fa786813e5b7=_04770ef21697,
        )

        # build preds and labels per example (preserve your previous behavior)
        _66db02244ad0 = []
        _1630c04cf19a = []
        for _adb50f6ca53a in _dd3afd5f0119(_14da4aae841e):
            _f9790f75de75 = _6628cc710cf5[_adb50f6ca53a]
            _a5124e61fa18 = _96a5e3af3a0d[_adb50f6ca53a]
            _f38caf8f15d2 = _a4cb8ed367e3._f4b1c1ae158f(_f9790f75de75, _3bfb5cff0f28=-1)
            _5355c185fcd0 = _a5124e61fa18
            _66db02244ad0._c87d6debe366(_f38caf8f15d2)
            _1630c04cf19a._c87d6debe366(_5355c185fcd0)

        _f0d8669d26aa = {
            "lang_codes": _b1f1e842d83d,
            "preds": _66db02244ad0,
            "labels": _1630c04cf19a,
            "sample_ids": _1867ade212ac,
            "chunk_ids": _110d63d905eb,
            "word_positions": _62c927c2a2a7,
            "val_loss": _eacd80955027,
            "prompt_lens": _54be019ff6b0,
            "num_chunks": _7c3fed7ab9d9,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._cc1752e0a210._c87d6debe366(_f0d8669d26aa)

        # explicit frees (same as you had)
        del _c3cf90f4a7f0, _96a5e3af3a0d, _6628cc710cf5, _6793e6957402, _21d547a7ca68, _049108a9bd2c, _7bf9d15d1240
        del _df57b075f033, _4e1e5aba803f, _a2ba2685e0f7, _66db02244ad0, _1630c04cf19a

        return _f0d8669d26aa


    def _282d974832a0(self, _a87dd737c188, _12d3bf2c4679, _bacfb250e741=_de2bbc67ebe9):
        _9b8996f3805e = _4d3d441f86ab._7d5305207890()
        _45153501fd2d = f"trial_{_bacfb250e741}" if _bacfb250e741 is not _de2bbc67ebe9 else "default"
        _42f25067f63b(f"[DEBUG rank={_a4cb8ed367e3._6da18845c281._05f1b93a22c2() if _a4cb8ed367e3._6da18845c281._ee38cf2cb0e1() else 0}] metrics_dict confusion_matrix sum={_a2150877db5c(_a2150877db5c(_cb7fab40292a) for _cb7fab40292a in _a87dd737c188['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _43368532976f = _4d3d441f86ab._dcfad2759c16._7119043e1d0d(_9b8996f3805e, "metrics", self._7ce6f747408f,  _45153501fd2d)
        _4d3d441f86ab._154cacd049c1(_43368532976f, _fb48f79ff996=_04770ef21697)
        _7240b9351e16 = _4d3d441f86ab._dcfad2759c16._7119043e1d0d(_43368532976f, _12d3bf2c4679)
        _459ce7295ef7 = _4d1b180152de._21411c291ea2(_a87dd737c188)
        _459ce7295ef7._dc897472154c(_7240b9351e16, _5e6351b62383=_450c540b12f6)
        _42f25067f63b(f"[metrics] Saved {_7240b9351e16}")

    def _902512230c06(self):
        # pick correct device for this rank
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            if _a4cb8ed367e3._6da18845c281._ee38cf2cb0e1():
                _0b1f7708bdea = _a4cb8ed367e3._6da18845c281._05f1b93a22c2()
            else:
                _0b1f7708bdea = 0
            _a4cb8ed367e3._feeb3aadf1a0._11581130d891(_0b1f7708bdea)
            self._251b03368c66 = _a4cb8ed367e3._6f78e92fd981(f"cuda:{_0b1f7708bdea}")
        else:
            self._251b03368c66 = _a4cb8ed367e3._6f78e92fd981("cpu")

        self._d00d781d0243()

    def _b29b345a5370(self):
        _6628cc710cf5 = _9b447463bd94(self, "_validation_outputs", _de2bbc67ebe9)
        if not _6628cc710cf5:
            return

        _ed20b46c4d0c, _03cfa2f0d6b7, _44a99a70b809, _488b6c798f4b = \
            self._c901b375a525(_6628cc710cf5)

        _0f2d4e153542, _a2c9347149dd = [], []
        for _c35a4e005ade in _e35cd26fefe7(_44a99a70b809._2ad6a02f7933()):
            _43b74f8b9e42 = _ed20b46c4d0c[_c35a4e005ade]._34ced47536a1()
            _ec0a8c4eb042 = _03cfa2f0d6b7[_c35a4e005ade]._34ced47536a1()
            _b89298e387fd = _44a99a70b809[_c35a4e005ade]
            _d71f576b2e4a = _488b6c798f4b[_c35a4e005ade]
            if _b89298e387fd._b0b231d889c3() > 0 and _d71f576b2e4a._b0b231d889c3() > 0:
                _0f2d4e153542._c87d6debe366(_b89298e387fd)
                _a2c9347149dd._c87d6debe366(_d71f576b2e4a)

        if not _0f2d4e153542:
            _42f25067f63b("[VAL END] Nothing to score.")
            self._cc1752e0a210._7ca98e5c911b()
            return

        _febc0c43d910 = _a4cb8ed367e3._d55c5ab6ca43(_0f2d4e153542)._55e10776ec94(_6f78e92fd981=self._6badf1225ef8['micro_accuracy']._6f78e92fd981, _70e42dbefc39=_04770ef21697)
        _96a5e3af3a0d = _a4cb8ed367e3._d55c5ab6ca43(_a2c9347149dd)._55e10776ec94(_6f78e92fd981=self._6badf1225ef8['micro_accuracy']._6f78e92fd981, _70e42dbefc39=_04770ef21697)

        self._6badf1225ef8['micro_accuracy']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_accuracy']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_precision']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_recall']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_f1']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_accuracy']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_precision']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_recall']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_f1']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['confmat']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)

        _23710d847aca  = self._6badf1225ef8['micro_accuracy']._4b726b02a36b()._654cef1c08fb()
        _96ba21d7408d  = self._6badf1225ef8['macro_accuracy']._4b726b02a36b()._654cef1c08fb()
        _8999abd1f4d1 = self._6badf1225ef8['macro_precision']._4b726b02a36b()._654cef1c08fb()
        _3fee249679b8    = self._6badf1225ef8['macro_recall']._4b726b02a36b()._654cef1c08fb()
        _7a51b47bfdb5        = self._6badf1225ef8['macro_f1']._4b726b02a36b()._654cef1c08fb()

        self._b0deaf824987("val_accuracy", _96ba21d7408d, _fa786813e5b7=_04770ef21697)

        try:
            _09a6df77fccf = self._b1bfd78f77b2
            _a87dd737c188 = {
                "epoch": [_09a6df77fccf],
                "class_names": [self._3a2ef9f28f9f],
                "micro_accuracy": [_23710d847aca],
                "macro_accuracy": [_96ba21d7408d],
                "macro_precision": [_8999abd1f4d1],
                "macro_recall": [_3fee249679b8],
                "macro_f1": [_7a51b47bfdb5],
                "classwise_accuracy": [self._6badf1225ef8['classwise_accuracy']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "classwise_precision": [self._6badf1225ef8['classwise_precision']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "classwise_recall": [self._6badf1225ef8['classwise_recall']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "classwise_f1": [self._6badf1225ef8['classwise_f1']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "confusion_matrix": [self._6badf1225ef8['confmat']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
            }
            self._c81b3c6a5822(_a87dd737c188, f"val_epoch_{_09a6df77fccf}.csv", _bacfb250e741=self._bacfb250e741)
        except _f02a48a95f7b as _e5a8288209fc:
            _42f25067f63b(f"[VAL END] save metrics FAILED: {_e5a8288209fc}")

        # cleanup
        self._6badf1225ef8['micro_accuracy']._3cf2810e205d(); self._6badf1225ef8['macro_accuracy']._3cf2810e205d()
        self._6badf1225ef8['macro_precision']._3cf2810e205d(); self._6badf1225ef8['macro_recall']._3cf2810e205d(); self._6badf1225ef8['macro_f1']._3cf2810e205d()
        self._6badf1225ef8['classwise_accuracy']._3cf2810e205d(); self._6badf1225ef8['classwise_precision']._3cf2810e205d()
        self._6badf1225ef8['classwise_recall']._3cf2810e205d(); self._6badf1225ef8['classwise_f1']._3cf2810e205d()
        self._6badf1225ef8['confmat']._3cf2810e205d(); self._cc1752e0a210._7ca98e5c911b()
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            _a4cb8ed367e3._feeb3aadf1a0._f0ce110aa994()
        _42f25067f63b("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_a4cb8ed367e3._591e3288e08c()
    def _97d848f5ca7b(self, _c3cf90f4a7f0: _a4cb8ed367e3._16691f8fa3f4, **_5bcfe6815e19):
        _5bcfe6815e19._0bb7932cd516("pad_token_id", _de2bbc67ebe9)
        _5bcfe6815e19._0bb7932cd516("attention_mask", _de2bbc67ebe9)
        return self._b9e71008125d._830e8642939f(
            _c3cf90f4a7f0=_c3cf90f4a7f0,
            _15a94a640c8d=(_c3cf90f4a7f0 != self._bf8e80376dc5._4c99a5cf6a46),
            _4c99a5cf6a46=self._bf8e80376dc5._4c99a5cf6a46,
            _546757cd06a8=self._bf8e80376dc5._546757cd06a8,
            **_5bcfe6815e19
        )

    def _fd17e8b20ce6(self, _c57cd35b8e87, _0fb392249512):
        _c3cf90f4a7f0 = _c57cd35b8e87["input_ids"]._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)
        _96a5e3af3a0d    = _c57cd35b8e87["labels"]._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)
        _b1f1e842d83d     = _c57cd35b8e87._d5c03787f3f3("lang_codes", _de2bbc67ebe9)
        _1867ade212ac     = _c57cd35b8e87._d5c03787f3f3("sample_ids", _de2bbc67ebe9)
        _110d63d905eb      = _c57cd35b8e87._d5c03787f3f3("chunk_ids", _de2bbc67ebe9)
        _62c927c2a2a7 = _c57cd35b8e87._d5c03787f3f3("word_positions", _de2bbc67ebe9)
        _54be019ff6b0    = _c57cd35b8e87._d5c03787f3f3("prompt_lens", _de2bbc67ebe9)
        _7c3fed7ab9d9 = _c57cd35b8e87._d5c03787f3f3("num_chunks", _de2bbc67ebe9)

        _14da4aae841e = _c3cf90f4a7f0._799713c732cb(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _8e1d31675d56 = self._830e8642939f(
            _c3cf90f4a7f0,
            _9179e120a509=48,
            _9de2a83ab663=_450c540b12f6,
            _329262286d6b=_de2bbc67ebe9,     # or just add this
            _8a1650769b7d=_de2bbc67ebe9,
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _66db02244ad0 = []
        _1630c04cf19a = []
        for _adb50f6ca53a in _dd3afd5f0119(_14da4aae841e):
            _4912faf3ca34 = _8e1d31675d56[_adb50f6ca53a]                    # (seq_len,)
            _879cda74d0b1 = _96a5e3af3a0d[_adb50f6ca53a]
            _66db02244ad0._c87d6debe366(_4912faf3ca34)
            _1630c04cf19a._c87d6debe366(_879cda74d0b1)

        _f0d8669d26aa = {
            "lang_codes": _b1f1e842d83d,
            "preds": _66db02244ad0,
            "labels": _1630c04cf19a,
            "sample_ids": _1867ade212ac,
            "chunk_ids": _110d63d905eb,
            "word_positions": _62c927c2a2a7,
            "prompt_lens": _54be019ff6b0,
            "num_chunks": _7c3fed7ab9d9,
        }

        self._72204dd3bd02._c87d6debe366(_f0d8669d26aa)

        # Exact same cleanup as before
        del _c3cf90f4a7f0, _96a5e3af3a0d, _8e1d31675d56, _66db02244ad0, _1630c04cf19a

        return _f0d8669d26aa

    def _b3344f09fce4(self):
        # pick correct device for this rank
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            if _a4cb8ed367e3._6da18845c281._ee38cf2cb0e1():
                _0b1f7708bdea = _a4cb8ed367e3._6da18845c281._05f1b93a22c2()
            else:
                _0b1f7708bdea = 0
            _a4cb8ed367e3._feeb3aadf1a0._11581130d891(_0b1f7708bdea)
            self._251b03368c66 = _a4cb8ed367e3._6f78e92fd981(f"cuda:{_0b1f7708bdea}")
        else:
            self._251b03368c66 = _a4cb8ed367e3._6f78e92fd981("cpu")

        self._d00d781d0243()
        
    def _2ae0e39afb65(self):
        _6628cc710cf5 = _9b447463bd94(self, "_test_outputs", _de2bbc67ebe9)
        _42f25067f63b(f"[DEBUG rank={_a4cb8ed367e3._6da18845c281._05f1b93a22c2()}] outputs_len={_66f48939deb7(_6628cc710cf5)}")
        if not _6628cc710cf5:
            return

        _ed20b46c4d0c, _03cfa2f0d6b7, _44a99a70b809, _488b6c798f4b = \
            self._c901b375a525(_6628cc710cf5)

        _0f2d4e153542, _a2c9347149dd = [], []
        for _c35a4e005ade in _e35cd26fefe7(_44a99a70b809._2ad6a02f7933()):
            _43b74f8b9e42 = _ed20b46c4d0c[_c35a4e005ade]._34ced47536a1()
            _ec0a8c4eb042 = _03cfa2f0d6b7[_c35a4e005ade]._34ced47536a1()
            _b89298e387fd = _44a99a70b809[_c35a4e005ade]
            _d71f576b2e4a = _488b6c798f4b[_c35a4e005ade]

            if _b89298e387fd._b0b231d889c3() > 0 and _d71f576b2e4a._b0b231d889c3() > 0:
                _0f2d4e153542._c87d6debe366(_b89298e387fd)
                _a2c9347149dd._c87d6debe366(_d71f576b2e4a)

        if not _0f2d4e153542:
            _42f25067f63b("[TEST END] Nothing to score.")
            self._cc1752e0a210._7ca98e5c911b()
            return

        _febc0c43d910 = _a4cb8ed367e3._d55c5ab6ca43(_0f2d4e153542)._55e10776ec94(_6f78e92fd981=self._6badf1225ef8['micro_accuracy']._6f78e92fd981, _70e42dbefc39=_04770ef21697)
        _96a5e3af3a0d = _a4cb8ed367e3._d55c5ab6ca43(_a2c9347149dd)._55e10776ec94(_6f78e92fd981=self._6badf1225ef8['micro_accuracy']._6f78e92fd981, _70e42dbefc39=_04770ef21697)

        self._6badf1225ef8['micro_accuracy']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_accuracy']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_precision']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_recall']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['macro_f1']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_accuracy']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_precision']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_recall']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['classwise_f1']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)
        self._6badf1225ef8['confmat']._b8b541aee4c7(_febc0c43d910, _96a5e3af3a0d)

        _23710d847aca  = self._6badf1225ef8['micro_accuracy']._4b726b02a36b()._654cef1c08fb()
        _96ba21d7408d  = self._6badf1225ef8['macro_accuracy']._4b726b02a36b()._654cef1c08fb()
        _8999abd1f4d1 = self._6badf1225ef8['macro_precision']._4b726b02a36b()._654cef1c08fb()
        _3fee249679b8    = self._6badf1225ef8['macro_recall']._4b726b02a36b()._654cef1c08fb()
        _7a51b47bfdb5        = self._6badf1225ef8['macro_f1']._4b726b02a36b()._654cef1c08fb()

        self._b0deaf824987("test_accuracy", _96ba21d7408d, _fa786813e5b7=_04770ef21697)

        try:
            _09a6df77fccf = self._b1bfd78f77b2
            _a87dd737c188 = {
                "epoch": [_09a6df77fccf],
                "class_names": [self._3a2ef9f28f9f],
                "micro_accuracy": [_23710d847aca],
                "macro_accuracy": [_96ba21d7408d],
                "macro_precision": [_8999abd1f4d1],
                "macro_recall": [_3fee249679b8],
                "macro_f1": [_7a51b47bfdb5],
                "classwise_accuracy": [self._6badf1225ef8['classwise_accuracy']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "classwise_precision": [self._6badf1225ef8['classwise_precision']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "classwise_recall": [self._6badf1225ef8['classwise_recall']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "classwise_f1": [self._6badf1225ef8['classwise_f1']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
                "confusion_matrix": [self._6badf1225ef8['confmat']._4b726b02a36b()._55e10776ec94(_6f78e92fd981="cpu")._e04276b3bdfa()._34ced47536a1()],
            }
            self._c81b3c6a5822(_a87dd737c188, f"test_final.csv", _bacfb250e741=self._bacfb250e741)
        except _f02a48a95f7b as _e5a8288209fc:
            _42f25067f63b(f"[TEST END] save metrics FAILED: {_e5a8288209fc}")

        # cleanup
        self._6badf1225ef8['micro_accuracy']._3cf2810e205d(); self._6badf1225ef8['macro_accuracy']._3cf2810e205d()
        self._6badf1225ef8['macro_precision']._3cf2810e205d(); self._6badf1225ef8['macro_recall']._3cf2810e205d(); self._6badf1225ef8['macro_f1']._3cf2810e205d()
        self._6badf1225ef8['classwise_accuracy']._3cf2810e205d(); self._6badf1225ef8['classwise_precision']._3cf2810e205d()
        self._6badf1225ef8['classwise_recall']._3cf2810e205d(); self._6badf1225ef8['classwise_f1']._3cf2810e205d()
        self._6badf1225ef8['confmat']._3cf2810e205d(); self._cc1752e0a210._7ca98e5c911b()
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            _a4cb8ed367e3._feeb3aadf1a0._f0ce110aa994()
        _42f25067f63b("[TEST END] Finished and cleaned up.")

    def _2f5c48033e07(self, _c57cd35b8e87, _0fb392249512, _99cdd1d62caa=0):
        """Optimized prediction step with efficient memory handling."""
        _c3cf90f4a7f0, _ = _c57cd35b8e87
        _c3cf90f4a7f0 = _c3cf90f4a7f0._55e10776ec94(self._251b03368c66, _70e42dbefc39=_04770ef21697)
        _6628cc710cf5, _, _ = self(_c3cf90f4a7f0)
        _6a46a87f2b95 = _a4cb8ed367e3._f4b1c1ae158f(_6628cc710cf5, _3bfb5cff0f28=-1)
        del _c3cf90f4a7f0, _6628cc710cf5
        if _a4cb8ed367e3._feeb3aadf1a0._d4095d855042():
            _a4cb8ed367e3._feeb3aadf1a0._f0ce110aa994()
        return {"predictions": _6a46a87f2b95._7dd6a12aeb0e()}

    def _a55a74a1849d(self, _6628cc710cf5, _152350bc5e3d=_04770ef21697, _04d122b99c86="cpu"):
        from _d6ab9383440c import _f3cbd0c15e92, _f97b815022c6
        import _a4cb8ed367e3
        _9a8a0a38871a = self._8998152c8b24
        def _2134a0b9dd88(_18ecc877bf3a):
            if _28640f8ea606(_18ecc877bf3a, _a4cb8ed367e3._16691f8fa3f4): return _18ecc877bf3a._24c81606afc9()._55e10776ec94(_6f78e92fd981=_04d122b99c86, _70e42dbefc39=_04770ef21697)._77abed44a887(-1)._34ced47536a1()
            return _49f4cbafc07e(_18ecc877bf3a) if _28640f8ea606(_18ecc877bf3a, (_49f4cbafc07e, _dcd8a39f67d9)) else [_18ecc877bf3a]
        
        _dc606ad4474a = _39ea8626146e()
        _ed20b46c4d0c, _03cfa2f0d6b7, _085e4edf163f = {}, {}, []
        if _152350bc5e3d:
            _42f25067f63b(f"[reconcile] start: num_outputs={_66f48939deb7(_6628cc710cf5)}")
        

        _42f25067f63b(f"[DEBUG rank={_a4cb8ed367e3._6da18845c281._05f1b93a22c2()}] Before reconcile missing sample_ids={[_c35a4e005ade for _c35a4e005ade in _dd3afd5f0119(0 if _a4cb8ed367e3._6da18845c281._05f1b93a22c2() == 0 else 637, 637 if _a4cb8ed367e3._6da18845c281._05f1b93a22c2() == 0 else 1274) if _c35a4e005ade not in _39ea8626146e(_c35a4e005ade for _da11fcc07e70 in _6628cc710cf5 for _c35a4e005ade in _da11fcc07e70._d5c03787f3f3('sample_ids', []))]}")
        for _da11fcc07e70 in _6628cc710cf5:
            _1867ade212ac     = _da11fcc07e70["sample_ids"]
            _110d63d905eb      = _da11fcc07e70["chunk_ids"]
            _237f88d0174d    = _da11fcc07e70["preds"]
            _d99ed3e19b6e   = _da11fcc07e70["labels"]
            _62c927c2a2a7 = _da11fcc07e70["word_positions"]
            _54be019ff6b0 = _da11fcc07e70["prompt_lens"]
            _77609ec1ff2a = _da11fcc07e70["num_chunks"]

            for _adb50f6ca53a, _c35a4e005ade in _38c1bce97c99(_1867ade212ac):
                _18b603d022e3 = _3b8ed8ee71dc(_110d63d905eb[_adb50f6ca53a])

                if (_c35a4e005ade, _18b603d022e3) in _dc606ad4474a:
                    continue
                _dc606ad4474a._8385d93e515a((_c35a4e005ade, _18b603d022e3))

                _b542feb9cd48 = _3b8ed8ee71dc(_54be019ff6b0[_adb50f6ca53a])
                _32f373954e4b = _c27f9ed635b1(_62c927c2a2a7[_adb50f6ca53a])
                _a40e2b82ab17 = self._b2d28c384d9f
                # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
                _f37cd160e483  = _c27f9ed635b1(_237f88d0174d[_adb50f6ca53a])
                _581368f991d8 = _c27f9ed635b1(_d99ed3e19b6e[_adb50f6ca53a])

                # If preds are shorter than labels, they are generation-only (test)
                if _66f48939deb7(_f37cd160e483) < _66f48939deb7(_581368f991d8):
                    _8e585a054bb2  = _f37cd160e483
                    _412b983b4453 = _581368f991d8[_b542feb9cd48:]
                else:
                    _8e585a054bb2  = _f37cd160e483[_b542feb9cd48:]
                    _412b983b4453 = _581368f991d8[_b542feb9cd48:]
                if _c35a4e005ade not in _085e4edf163f:
                    _085e4edf163f._c87d6debe366(_c35a4e005ade)

                if 'chunks_by_sid' not in _1d41f5995499():
                    _c465cab97ca9 = _f3cbd0c15e92(_49f4cbafc07e)
                _c465cab97ca9[_c35a4e005ade]._c87d6debe366((_18b603d022e3, _32f373954e4b, _8e585a054bb2, _412b983b4453))
            
        _e2c3a378848a = _de2bbc67ebe9
        _0b1f7708bdea = _a4cb8ed367e3._6da18845c281._05f1b93a22c2() if _a4cb8ed367e3._6da18845c281._ee38cf2cb0e1() else 0
        _42f25067f63b(f"[DEBUG rank={_a4cb8ed367e3._6da18845c281._05f1b93a22c2()}] Missing sample_ids={[_c35a4e005ade for _c35a4e005ade in _dd3afd5f0119(0 if _a4cb8ed367e3._6da18845c281._05f1b93a22c2() == 0 else 637, 637 if _a4cb8ed367e3._6da18845c281._05f1b93a22c2() == 0 else 1274) if _c35a4e005ade not in _085e4edf163f]}")
        for _c35a4e005ade in _085e4edf163f:
            _9272e8ff8ea6 = _c465cab97ca9[_c35a4e005ade]
            _42f25067f63b(f"[WARN] Rank {_0b1f7708bdea} Missing chunks sample_id={_c35a4e005ade}, missing {_da11fcc07e70['num_chunks'][_adb50f6ca53a] - _66f48939deb7(_9272e8ff8ea6)} chunks") if _19044bafd402(_da11fcc07e70['sample_ids'][_adb50f6ca53a] == _c35a4e005ade and _da11fcc07e70['num_chunks'][_adb50f6ca53a] > _66f48939deb7(_9272e8ff8ea6) for _da11fcc07e70 in _6628cc710cf5 for _adb50f6ca53a in _dd3afd5f0119(_66f48939deb7(_da11fcc07e70['sample_ids']))) else _de2bbc67ebe9
            if _e2c3a378848a is _de2bbc67ebe9 and _66f48939deb7(_9272e8ff8ea6) > 1:
                _e2c3a378848a = _c35a4e005ade
            _9272e8ff8ea6._412b320b7d9d(_d1f309851bad=lambda _18ecc877bf3a: _18ecc877bf3a[0])
            _5815f04b46f7 = _f3cbd0c15e92(_49f4cbafc07e)
            _a2dbdbd41e35 = _f3cbd0c15e92(_49f4cbafc07e)
            _5e467df49ec8 = _f3cbd0c15e92(_49f4cbafc07e)
            _a9fcff413ed6 = _f3cbd0c15e92(_49f4cbafc07e)
            for _18b603d022e3, _5785c75077ee, _febc0c43d910, _96a5e3af3a0d in _9272e8ff8ea6:
                _a3eb7d3fec5c = {}
                _c362b3df680b = {}
                _7e9851154245 = _de2bbc67ebe9
                _0c4034e97e9c = []
                _31a3f1887f0f = []
                for _8dace4950e66, _17326523f26d, _e8cefa3525c5 in _19a7488ddbb7(_5785c75077ee, _febc0c43d910, _96a5e3af3a0d):
                    _dbed149d04ea = _3b8ed8ee71dc(_8dace4950e66)
                    if _dbed149d04ea >= 0:
                        if _dbed149d04ea != _7e9851154245:
                            if _7e9851154245 is not _de2bbc67ebe9:
                                _a3eb7d3fec5c[_7e9851154245] = _0c4034e97e9c[:]
                                _c362b3df680b[_7e9851154245] = _31a3f1887f0f[:]
                            _7e9851154245 = _dbed149d04ea
                            _0c4034e97e9c = [_3b8ed8ee71dc(_17326523f26d)]
                            _31a3f1887f0f = [_3b8ed8ee71dc(_e8cefa3525c5)]
                        else:
                            _0c4034e97e9c._c87d6debe366(_3b8ed8ee71dc(_17326523f26d))
                            _31a3f1887f0f._c87d6debe366(_3b8ed8ee71dc(_e8cefa3525c5))
                    else:
                        if _7e9851154245 is not _de2bbc67ebe9:
                            _a2dbdbd41e35[_7e9851154245]._c87d6debe366(_3b8ed8ee71dc(_17326523f26d))
                            _a9fcff413ed6[_7e9851154245]._c87d6debe366(_3b8ed8ee71dc(_e8cefa3525c5))
                if _7e9851154245 is not _de2bbc67ebe9:
                    _a3eb7d3fec5c[_7e9851154245] = _0c4034e97e9c[:]
                    _c362b3df680b[_7e9851154245] = _31a3f1887f0f[:]
                for _29b9cbc29a43, _744cb40af7dd in _a3eb7d3fec5c._d9d308093632():
                    _5815f04b46f7[_29b9cbc29a43]._c87d6debe366(_744cb40af7dd)
                    _5e467df49ec8[_29b9cbc29a43]._c87d6debe366(_c362b3df680b[_29b9cbc29a43])
            if not _5815f04b46f7:
                continue
            _4e0577b09576 = _6124eecaec69(_5815f04b46f7._2ad6a02f7933())
            _25e45013e223 = []
            _0878d3e0897f = []
            _628e979ded12 = _6a2c17ea1b22((_9c544a8c2b2a[0] for _9c544a8c2b2a, _4b568ae54cbe in self._af6208279c83._d9d308093632() if _4b568ae54cbe == 0), 3200)
            for _29b9cbc29a43 in _e35cd26fefe7(_5815f04b46f7._2ad6a02f7933()):
                _0fd7046f66b7 = _5815f04b46f7[_29b9cbc29a43]
                _979c9ddab0ff = _5e467df49ec8[_29b9cbc29a43]
                _70a948fb17f4 = _66f48939deb7(_979c9ddab0ff[0])
                _60af9fca1147 = []
                for _941165d66ca8 in _dd3afd5f0119(_70a948fb17f4):
                    _b46a62b0d4ac = [_d2408b0b1c80[_941165d66ca8] for _d2408b0b1c80 in _0fd7046f66b7 if _941165d66ca8 < _66f48939deb7(_d2408b0b1c80)]
                    while _66f48939deb7(_b46a62b0d4ac) < _66f48939deb7(_979c9ddab0ff):
                        _b46a62b0d4ac._c87d6debe366(_628e979ded12)
                    _cb83bf19766e = _f97b815022c6(_b46a62b0d4ac)._044dcc89b5c6(1)[0][0]
                    _60af9fca1147._c87d6debe366(_cb83bf19766e)
                _25e45013e223._fb72bcdd3858(_60af9fca1147[:_70a948fb17f4])
                _01c3a9c89def = []
                for _941165d66ca8 in _dd3afd5f0119(_70a948fb17f4):
                    _b46a62b0d4ac = [_d2408b0b1c80[_941165d66ca8] for _d2408b0b1c80 in _979c9ddab0ff]
                    _cb83bf19766e = _f97b815022c6(_b46a62b0d4ac)._044dcc89b5c6(1)[0][0]
                    _01c3a9c89def._c87d6debe366(_cb83bf19766e)
                _0878d3e0897f._fb72bcdd3858(_01c3a9c89def)
                if _29b9cbc29a43 < _4e0577b09576:
                    _f1691a7253f3 = _a2dbdbd41e35[_29b9cbc29a43]
                    if _f1691a7253f3:
                        _f227ad6ea4c0 = _f97b815022c6(_f1691a7253f3)._044dcc89b5c6(1)[0][0]
                        _25e45013e223._c87d6debe366(_f227ad6ea4c0)
                    _df254ce086d3 = _a9fcff413ed6[_29b9cbc29a43]
                    if _df254ce086d3:
                        _d1ca8aa9f199 = _f97b815022c6(_df254ce086d3)._044dcc89b5c6(1)[0][0]
                        _0878d3e0897f._c87d6debe366(_d1ca8aa9f199)
                    else:
                        _0878d3e0897f._c87d6debe366(self._b38d9df8a1df)
                        _25e45013e223._c87d6debe366(self._b38d9df8a1df)
            _628e979ded12 = _6a2c17ea1b22((_9c544a8c2b2a[0] for _9c544a8c2b2a, _4b568ae54cbe in self._af6208279c83._d9d308093632() if _4b568ae54cbe == 0), 3200)
            _c959b6233f45 = _a2150877db5c(1 for _adb50f6ca53a, _18ecc877bf3a in _38c1bce97c99(_0878d3e0897f) if _18ecc877bf3a != self._b38d9df8a1df and (_adb50f6ca53a == 0 or _0878d3e0897f[_adb50f6ca53a-1] == self._b38d9df8a1df))
            _87f9d273240f = _a2150877db5c(1 for _adb50f6ca53a, _18ecc877bf3a in _38c1bce97c99(_25e45013e223) if _18ecc877bf3a != self._b38d9df8a1df and (_adb50f6ca53a == 0 or _25e45013e223[_adb50f6ca53a-1] == self._b38d9df8a1df))
            if _87f9d273240f < _c959b6233f45:
                for _ in _dd3afd5f0119(_87f9d273240f, _c959b6233f45):
                    if _66f48939deb7(_25e45013e223) > 0 and _25e45013e223[-1] != self._b38d9df8a1df:
                        _25e45013e223._c87d6debe366(self._b38d9df8a1df)
                    _25e45013e223._c87d6debe366(_628e979ded12)
            elif _87f9d273240f > _c959b6233f45:
                _7ed04816cb87 = []
                _800704a95bda = 0
                for _adb50f6ca53a, _67b4a24ed3f1 in _38c1bce97c99(_25e45013e223):
                    if _67b4a24ed3f1 != self._b38d9df8a1df and (_adb50f6ca53a == 0 or _25e45013e223[_adb50f6ca53a-1] == self._b38d9df8a1df):
                        _800704a95bda += 1
                    if _800704a95bda <= _c959b6233f45:
                        _7ed04816cb87._c87d6debe366(_67b4a24ed3f1)
                    elif _67b4a24ed3f1 == self._b38d9df8a1df and _800704a95bda == _c959b6233f45:
                        _7ed04816cb87._c87d6debe366(_67b4a24ed3f1)
                        break
                _25e45013e223 = _7ed04816cb87

            _ed20b46c4d0c[_c35a4e005ade] = _a4cb8ed367e3._73b31ea9cba9(_25e45013e223, _6f78e92fd981=_04d122b99c86)
            _03cfa2f0d6b7[_c35a4e005ade] = _a4cb8ed367e3._73b31ea9cba9(_0878d3e0897f if _0878d3e0897f else [self._8998152c8b24] * _66f48939deb7(_25e45013e223), _6f78e92fd981=_04d122b99c86)

        if _152350bc5e3d and _e2c3a378848a:
            _42f25067f63b(f"[SUMMARY] reconciled samples in batch = {_66f48939deb7(_085e4edf163f)} \
                  sid={_e2c3a378848a} total_preds={_66f48939deb7(_ed20b46c4d0c[_e2c3a378848a])} total_labels={_66f48939deb7(_03cfa2f0d6b7[_e2c3a378848a])} \
                    raw_preds {_ed20b46c4d0c[_e2c3a378848a]} and raw_labels{_03cfa2f0d6b7[_e2c3a378848a]}\
                        chunks {_c465cab97ca9[_e2c3a378848a]}")
        
        _530f1647132a, _db52a60eee30 = self._0cc1af010e3c(_ed20b46c4d0c, _03cfa2f0d6b7, _152350bc5e3d=_152350bc5e3d, _04d122b99c86=_04d122b99c86)
        
        if _152350bc5e3d and _e2c3a378848a:
            _42f25067f63b(f"After Overlay [DEBUG sid={_e2c3a378848a}] raw_preds={_ed20b46c4d0c[_e2c3a378848a]} and raw_labels={_03cfa2f0d6b7[_e2c3a378848a]} and preds={_530f1647132a[_e2c3a378848a]} and labels={_db52a60eee30[_e2c3a378848a]}")
        
        return _ed20b46c4d0c, _03cfa2f0d6b7, _530f1647132a, _db52a60eee30

    def _62db85107932(self, _ed20b46c4d0c, _03cfa2f0d6b7, _152350bc5e3d=_04770ef21697, _04d122b99c86="cpu"):
        _af6208279c83 = _9b447463bd94(self, "seq2class", {})
        _e322bfdfaa94 = _9b447463bd94(self, "tokenizer_separator_token", _de2bbc67ebe9)
        _9a8a0a38871a = _9b447463bd94(self, "ignore_idx", -100)
        
        def _8439cd7f26b5(_b227d65a35c8, _abcdcaad9495):
            _48581943ed37 = []
            _7e9851154245 = []
            for _adb50f6ca53a, _415bfe9f68c1 in _38c1bce97c99(_b227d65a35c8):
                if _415bfe9f68c1 == _abcdcaad9495 and _7e9851154245:
                    _48581943ed37._c87d6debe366(_7e9851154245)
                    _7e9851154245 = []
                elif _415bfe9f68c1 != _abcdcaad9495:
                    _7e9851154245._c87d6debe366(_415bfe9f68c1)
            if _7e9851154245:
                _48581943ed37._c87d6debe366(_7e9851154245)
            return _48581943ed37
        
        def _d8e822eb770d(_f1227cc3f6fe, _af6208279c83, _152350bc5e3d, _c35a4e005ade):
            _da11fcc07e70 = []
            _fd3c766793e3 = _e35cd26fefe7(_af6208279c83._2ad6a02f7933(), _d1f309851bad=_66f48939deb7, _d50a811bddf0=_04770ef21697)
            for _adb50f6ca53a, _eb9d67772e36 in _38c1bce97c99(_f1227cc3f6fe, 1):
                _991d6ad637e5 = _dcd8a39f67d9(_eb9d67772e36)
                _2ba240fac366 = self._50e1abc69672
                for _d1f309851bad in _fd3c766793e3:
                    if _66f48939deb7(_991d6ad637e5) >= _66f48939deb7(_d1f309851bad) and _991d6ad637e5[:_66f48939deb7(_d1f309851bad)] == _d1f309851bad:
                        _2ba240fac366 = _af6208279c83[_d1f309851bad]
                        break
                _da11fcc07e70._c87d6debe366(_2ba240fac366)

            return _da11fcc07e70
        
        _44a99a70b809, _488b6c798f4b = {}, {}
        for _c35a4e005ade in _ed20b46c4d0c:
            _67b4a24ed3f1 = _ed20b46c4d0c[_c35a4e005ade]
            _61edad14fb7d = _03cfa2f0d6b7._d5c03787f3f3(_c35a4e005ade, _de2bbc67ebe9)
            _febc0c43d910 = _67b4a24ed3f1._34ced47536a1() if _28640f8ea606(_67b4a24ed3f1, _a4cb8ed367e3._16691f8fa3f4) else _49f4cbafc07e(_67b4a24ed3f1)
            _96a5e3af3a0d = _61edad14fb7d._34ced47536a1() if _28640f8ea606(_61edad14fb7d, _a4cb8ed367e3._16691f8fa3f4) else _49f4cbafc07e(_61edad14fb7d) if _61edad14fb7d else _de2bbc67ebe9
            if _96a5e3af3a0d is not _de2bbc67ebe9:
                _c959b6233f45 = _15a2b63500ab(_96a5e3af3a0d, _e322bfdfaa94)
                _b5014dd45bc0 = _3cf4c5069202(_c959b6233f45, _af6208279c83, _c35a4e005ade == 1 or _152350bc5e3d, _c35a4e005ade)
                _732de48b3001 = _15a2b63500ab(_febc0c43d910, _e322bfdfaa94)
                _13c54336e6e8 = _3cf4c5069202(_732de48b3001, _af6208279c83, _c35a4e005ade == 1 or _152350bc5e3d, _c35a4e005ade)
                if _66f48939deb7(_13c54336e6e8) < _66f48939deb7(_b5014dd45bc0):
                    _13c54336e6e8 += [0] * (_66f48939deb7(_b5014dd45bc0) - _66f48939deb7(_13c54336e6e8))
                elif _66f48939deb7(_13c54336e6e8) > _66f48939deb7(_b5014dd45bc0):
                    _13c54336e6e8 = _13c54336e6e8[:_66f48939deb7(_b5014dd45bc0)]
            else:
                _732de48b3001 = _15a2b63500ab(_febc0c43d910, _e322bfdfaa94)
                _13c54336e6e8 = _3cf4c5069202(_732de48b3001, _af6208279c83, _c35a4e005ade == 1 or _152350bc5e3d, _c35a4e005ade)
                _b5014dd45bc0 = [_9a8a0a38871a] * _66f48939deb7(_13c54336e6e8)
            _44a99a70b809[_c35a4e005ade] = _a4cb8ed367e3._73b31ea9cba9(_13c54336e6e8, _6f78e92fd981=_04d122b99c86, _fe384459fbb5=_a4cb8ed367e3._569482894568)
            _488b6c798f4b[_c35a4e005ade] = _a4cb8ed367e3._73b31ea9cba9(_b5014dd45bc0, _6f78e92fd981=_04d122b99c86, _fe384459fbb5=_a4cb8ed367e3._569482894568)
        return _44a99a70b809, _488b6c798f4b

    def _286b488c0fed(self, _03118cf5c23c):
        _a4cb8ed367e3._e74dc8d2dc43._f24b133db086._2aa4633fdb63(self._e25ab13a243d(), _0106dc5ff049=1.0)
    
    def _44d17fdf2ea4(self, _03118cf5c23c):
        for _e35293137da2 in self._e25ab13a243d():
            if _e35293137da2 is not _de2bbc67ebe9:
                _e35293137da2._c429285398ac._8ad5cc6d675e(-5, 5)

    def _c3a5c0746884(self):
        _01f84978c06b = 0
        for _e35293137da2 in self._e25ab13a243d():
            if _e35293137da2._0514284aaead is not _de2bbc67ebe9:
                _3ac4a997fb3d = _e35293137da2._0514284aaead._24c81606afc9()._c429285398ac._d168d395aa2d(2)
                _01f84978c06b += _3ac4a997fb3d._654cef1c08fb() ** 2
        return _01f84978c06b ** 0.5  # L2 norm

    def _39d62a8f3dcf(self):
        _d21def9f80bb = [_67b4a24ed3f1 for _67b4a24ed3f1 in self._e25ab13a243d() if _67b4a24ed3f1._6fe78e811eac]
        if not _d21def9f80bb:
            _42f25067f63b("No trainable parameters. Skipping optimizer creation.")
            return _de2bbc67ebe9
        
        _e4369a07b575 = _533f2b13de7e(lambda _67b4a24ed3f1: _67b4a24ed3f1._6fe78e811eac, self._e25ab13a243d())

        _fc94079057f2 = {
            "adamw": _a4cb8ed367e3._e18f278a59d1._04ac81c1407e,
            "adamax": _a4cb8ed367e3._e18f278a59d1._89c5f4089679,
            "adam": _a4cb8ed367e3._e18f278a59d1._c8ff9fb4d9d5,
        }
        _2319c428a770 = _fc94079057f2._d5c03787f3f3(self._0534b1f3d7d2._898eb84f9710(), _a4cb8ed367e3._e18f278a59d1._c8ff9fb4d9d5)

        _03118cf5c23c = _2319c428a770(_e4369a07b575, _f5f858703379=self._adfe4abc26e9._f5f858703379, _76064fabd00b=0.001)

        _e95b8d23bb48 = self._68885214b293._bfc47f38205c
        _8f6798f1dd8f = _de778e62821f._05441cf0593c(0.1 * _e95b8d23bb48)

        _808e8cd14d7f = _a4cb8ed367e3._e18f278a59d1._494e073000de._f4f68081eec7(_03118cf5c23c, _b0a8b72333bd=lambda _559a579bc6a0: (_559a579bc6a0 + 1) / _8f6798f1dd8f)

        _5a16ca5bbd4e = _a4cb8ed367e3._e18f278a59d1._494e073000de._985137ed15df(
            _03118cf5c23c,
            _8332d925a486=_6124eecaec69(1, _e95b8d23bb48 - _8f6798f1dd8f),
            _90cd1ce22a49=2,
            _f007f6b33d14=1e-6
        )
        _494e073000de = _a4cb8ed367e3._e18f278a59d1._494e073000de._fb3a6bb4b731(
            _03118cf5c23c,
            _17e304c923b6=[_808e8cd14d7f, _5a16ca5bbd4e],
            _d54dbf84f48c=[_8f6798f1dd8f]
        )
        return {"optimizer": _03118cf5c23c, "lr_scheduler": {"scheduler": _494e073000de, "interval": "epoch", "monitor": "val_loss"}}
