# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _90871b787201
import copy
from _9753f08ba847 import _1abeb692631b
import _b854f01ac396
import math
import os
from typing import _5a00f2f007cb
import _ac507d59111b as _bd5cc20ab380
import _b2f8c005038b as _47d878a6a81b
import _0316ac5a2b74
import _9e2e17f775e2 as _4f8b9c496c59
from _4ff89eafa9fc._0370936a93ed._e4bfbb7ff0ea._20c301fd1a1d import _f3027ecf18e1
from _546b3873f19e import _c37acc16d73f, _27626c002733, _5f1296571182, _bbc5a9151b03, _889088351f4f

from _f55620fcfe70._fc9e8161a60d._bd3498096fa6._3bdb6877d11b import _35a1d131f281
from _f55620fcfe70._fc9e8161a60d._21579a65300d._5c73969acd34 import _801b8b204252
from _f55620fcfe70._fc9e8161a60d._21579a65300d._d4f6e513b31f import _0649d6b8e615
from _f55620fcfe70._fc9e8161a60d._21579a65300d._126c03616cd6 import _ca8ae1317a4b
from _f55620fcfe70._fc9e8161a60d._b0dc184429f8._3b2a958d97f3 import _2c17ae8dbc5c
# expose only the classifier from the module
_372bc3cfd4cd = ["GenLLMLanguageIdentificationClassifier"]

_57b4403a3bd2 = 'cuda' if _0316ac5a2b74._0b653ba58228._66436d6c2198() else 'cpu'
_f9798733b3b1 = _2431e119344c  # global frozen embedding (kept for compatibility)

class _35b16afc9aee(_4f8b9c496c59._13751aee377d):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _133792c443c6(_0316ac5a2b74._92d99dcbe74a._df0ec14f0fbe):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _923283af5830(self, _fd99d22dec2b: _3ee47612a58e, _279fc48c2436: _3ee47612a58e = 64):
            _2a435abb5247()._fcf988d9f1db()
            self._f5935caa29c0 = _0316ac5a2b74._92d99dcbe74a._70ce095df902(_fd99d22dec2b, _279fc48c2436, _ff22e72ef552=_bbb3e95cc4a3)
            self._7376d36e9c98 = _0316ac5a2b74._92d99dcbe74a._96be78c6fa03(_2d62ef18676c=_4a8f86e6251f)
            self._d71dc4317101 = _0316ac5a2b74._92d99dcbe74a._70ce095df902(_279fc48c2436, _fd99d22dec2b, _ff22e72ef552=_bbb3e95cc4a3)
            # start adapter near-zero so initial behavior is identity
            _0316ac5a2b74._92d99dcbe74a._778be1c094cb._a4906cae0472(self._d71dc4317101._7c79cabc94e0)
            _0316ac5a2b74._92d99dcbe74a._778be1c094cb._720678f3461a(self._f5935caa29c0._7c79cabc94e0, _767989535fb3=math._35ba5bd44430(5))

        def _e2595b92d738(self, _1aaa11a79046: _0316ac5a2b74._4b8e10258290) -> _0316ac5a2b74._4b8e10258290:
            # supports x shape (B, L, D) or (B, D)
            if _1aaa11a79046._fd99d22dec2b() == 2:
                _72fa095b293f = self._d71dc4317101(self._7376d36e9c98(self._f5935caa29c0(_1aaa11a79046)))
                return _1aaa11a79046 + _72fa095b293f
            _1df2c27f88bd, _4ec31a9b597c, _07059bb4c0af = _1aaa11a79046._33ddbf7fc8d8
            _a21b3bebbf98 = _1aaa11a79046._0c960270e2ce(-1, _07059bb4c0af)                    # (B*L, D)
            _a21b3bebbf98 = self._d71dc4317101(self._7376d36e9c98(self._f5935caa29c0(_a21b3bebbf98)))  # (B*L, D)
            _a21b3bebbf98 = _a21b3bebbf98._0c960270e2ce(_1df2c27f88bd, _4ec31a9b597c, _07059bb4c0af)
            return _1aaa11a79046 + _a21b3bebbf98
        
    class _a99671733ca4(_0316ac5a2b74._92d99dcbe74a._df0ec14f0fbe):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _923283af5830(self, _de368f7a6279, _4d12ee3509ab=-5, _f763fc62cda7=5):
            _2a435abb5247()._fcf988d9f1db()
            self._de368f7a6279 = _de368f7a6279
            self._4d12ee3509ab = _4d12ee3509ab
            self._f763fc62cda7 = _f763fc62cda7
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _e2595b92d738(self, *_f0f66aa1a60b, **_c3e9883b5fb9):
            _f0f66aa1a60b = _1dbbb848faf7(
                _d7e203fa7fe6._aba6dfc59e20(_0316ac5a2b74._afae18f2e083)._53812eac6d7e(-10, 10) if _38e8db554ad0(_d7e203fa7fe6, _0316ac5a2b74._4b8e10258290) and _d7e203fa7fe6._56b5104fd8d1 != _0316ac5a2b74._afae18f2e083 else _d7e203fa7fe6
                for _d7e203fa7fe6 in _f0f66aa1a60b
            )
            for _b2d99ad60a18, _d7e203fa7fe6 in _a3851d993417(_f0f66aa1a60b):
                if _38e8db554ad0(_d7e203fa7fe6, _0316ac5a2b74._4b8e10258290) and not _0316ac5a2b74._e06656c36817(_d7e203fa7fe6)._e717e4938e4f():
                    _d7e203fa7fe6 = _0316ac5a2b74._0bce0e54111c(_d7e203fa7fe6)
            _2be583d3eafb = self._de368f7a6279(*_f0f66aa1a60b, **_c3e9883b5fb9)
            if _38e8db554ad0(_2be583d3eafb, _0316ac5a2b74._4b8e10258290):
                _2be583d3eafb = _2be583d3eafb._aba6dfc59e20(_0316ac5a2b74._afae18f2e083)
                if not _0316ac5a2b74._e06656c36817(_2be583d3eafb)._e717e4938e4f():
                    _2be583d3eafb = _0316ac5a2b74._0bce0e54111c(_2be583d3eafb)
                _2be583d3eafb._98be16b9b881(self._4d12ee3509ab, self._f763fc62cda7)
            return _2be583d3eafb

    # --- original __init__ signature and body preserved ---
    def _923283af5830(
        self,
        _6632210142ec,
        _abb73c99b2a7,
        _5cc404bcfd3d,
        _69749d296508,
        _f06e3ecb8b53,
        _93761b30a2d9,
        _fdc0d835011e,
        _0615d0c5cf90,
        _5fcaf40f7f5b,
        _f1efa6fb0aa4,
        _45eb1c685303,
        _9f89c2882725: _3ee47612a58e = 20,
        _c38a96c08199 = _2431e119344c,
        _6672ac0eca51=_2431e119344c,
        _d5e8f3abbbd8=0.9,
        _be56b12a3ddc:_1f58285b871e=_2431e119344c,
    ):
        _2a435abb5247(_94b41beb159a, self)._fcf988d9f1db()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._383ecdc73afc({
            "lr": _832e99df44d6(_5cc404bcfd3d),
            "optimizer": _1f58285b871e(_69749d296508),
            "num_backbone_model_units_unfrozen": _3ee47612a58e(_fdc0d835011e),
            "loss_type": _1f58285b871e(_0615d0c5cf90),
            "is_train": _2e010ab34ec6(_5fcaf40f7f5b),
            "random_seed": _3ee47612a58e(_9f89c2882725),
        })
        self._9f89c2882725 = _9f89c2882725
        _4f8b9c496c59._98d0638234d8(_9f89c2882725, _2e78bf5f3b4d=_4a8f86e6251f)
        _0316ac5a2b74._ef89da1f22df(_9f89c2882725)
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            _0316ac5a2b74._0b653ba58228._da1006cd6d22(_9f89c2882725)
        _bd5cc20ab380.random._7a2aa9173d2a(_9f89c2882725)
        self._6672ac0eca51 = _3ee47612a58e(_6672ac0eca51) if _6672ac0eca51 is not _2431e119344c else _2431e119344c
        self._f1efa6fb0aa4 = _f1efa6fb0aa4
        self._be56b12a3ddc = _be56b12a3ddc
        # TODO: REMOVE THIS HARDCODING
        if not self._f1efa6fb0aa4._4804eaf48caf:
            self._f1efa6fb0aa4._4804eaf48caf = 128004  # <|finetune_right_pad_id|>
        self._781dbdeb872d = _f1efa6fb0aa4._3b6163fee867(" ", _1e9ee16c5de0=_bbb3e95cc4a3)[0]
        self._bc4341c5ad90 = (
            _0316ac5a2b74._de41be4d9bd9("cuda:{}"._e51b35232cad(_93761b30a2d9["gpu_local_rank"]))
            if _93761b30a2d9["gpu_local_rank"] != -1
            else "cpu"
        )
        self._c38a96c08199 = _c38a96c08199
        self._434a460a665f = _ca4d7a12cacf(_abb73c99b2a7)
        self._d5e8f3abbbd8 = _d5e8f3abbbd8
        self._abb73c99b2a7 =  ["unk"] + _abb73c99b2a7 if self._d5e8f3abbbd8 > 0 else _abb73c99b2a7
        self._b24c80d05eac = {}
        for _b4b559b5d513, _e66cccdb811e in _a3851d993417(self._abb73c99b2a7):
            _733ad00c45f1 = self._f1efa6fb0aa4._3b6163fee867(_e66cccdb811e, _1e9ee16c5de0=_bbb3e95cc4a3)
            self._b24c80d05eac[_b4b559b5d513] = _733ad00c45f1
        self._db29576ae0c7 = {_1dbbb848faf7(_733ad00c45f1): _73073f258894 for _73073f258894, _733ad00c45f1 in self._b24c80d05eac._5d0c1d058390()}
        self._11e4e15d14b3 = _90871b787201(_79ec9ef38482)
        for _f3ff704d06cf, _733ad00c45f1 in self._b24c80d05eac._5d0c1d058390():
            self._11e4e15d14b3[_ca4d7a12cacf(_733ad00c45f1)]._b44262aeeb1d((_f3ff704d06cf, _733ad00c45f1))
        self._4a8500cbaa22 = 0
        _650354848ff9(f"SEQ {self._b24c80d05eac} and {self._db29576ae0c7}")
        self._5aafaf1ee8bc = _f1efa6fb0aa4._4804eaf48caf or _f1efa6fb0aa4._81c1471af2a0
        self._f06e3ecb8b53 = _f06e3ecb8b53
        self._37816b26d766 = "multiclass"
        self._531e8940e841 = -100
        self._00086b57250f = _f1efa6fb0aa4._3b6163fee867("assistant<|end_header_id|>\n\n", _1e9ee16c5de0=_bbb3e95cc4a3)
        self._e18c8b0df0fb = self._6331fc1836cb()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._689ab620be58 = _6632210142ec
        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._689ab620be58._2d28bec5425f(_bbb3e95cc4a3)
        _b66b92bfadb0 = _2c17ae8dbc5c()  # bfloat16 or float16

        for _4f095be1fce3, _de368f7a6279 in self._fa2bd6cc4a29():
            if not _ce3400912625(_601da9576fa0._22071fce29ba for _601da9576fa0 in _de368f7a6279._203e3f83c27d(_f448eed25f13=_bbb3e95cc4a3)):
                # FROZEN → BF16 (save memory)
                _de368f7a6279._aba6dfc59e20(_56b5104fd8d1=_b66b92bfadb0)
            else:
                # TRAINABLE → FP32 (stable grads)
                _de368f7a6279._aba6dfc59e20(_56b5104fd8d1=_0316ac5a2b74._afae18f2e083)
        self._689ab620be58._aba6dfc59e20(self._bc4341c5ad90)
        if _7b50f9daeee0(self._689ab620be58, "gradient_checkpointing_enable"):
            self._689ab620be58._43d0e6c6772f()
        # determine embedding dim robustly from model config if available
        _43639e08b2d4 = _4cfd48b7bf24(_4cfd48b7bf24(self._689ab620be58, "config", _2431e119344c), "hidden_size", _2431e119344c)
        if _43639e08b2d4 is _2431e119344c:
            # fallback to common default — change if your model uses a different hidden size
            _43639e08b2d4 = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _7b50f9daeee0(self._689ab620be58, "lm_head") and _4cfd48b7bf24(self._689ab620be58, "lm_head") is not _2431e119344c:
            self._37c983e99b25 = self._689ab620be58._941ee9b16267
        else:
            _64e81c82aa53 = _4cfd48b7bf24(self._689ab620be58, "get_output_embeddings", _2431e119344c)
            self._37c983e99b25 = _64e81c82aa53() if _3c1c285b31ee(_64e81c82aa53) else _2431e119344c

        # mark presence and ensure module (if any) is on the same device
        self._992c5e05768b = self._37c983e99b25 is not _2431e119344c
        if self._992c5e05768b:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._37c983e99b25._aba6dfc59e20(self._bc4341c5ad90)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._f3ba051aac0d = self._838b88a1139a(_fd99d22dec2b=_43639e08b2d4, _279fc48c2436=64)
        self._f3ba051aac0d._aba6dfc59e20(self._bc4341c5ad90)
        for _601da9576fa0 in self._f3ba051aac0d._203e3f83c27d():
            _601da9576fa0._22071fce29ba = _4a8f86e6251f
            
        if _fdc0d835011e > 0:
            if "llama" in self._c38a96c08199:
                for _06a3a953f9f1 in self._689ab620be58._203e3f83c27d():
                    if not _06a3a953f9f1._cab82d630c31:
                        _06a3a953f9f1 = _06a3a953f9f1._b6827c62d41e()
                    _06a3a953f9f1._22071fce29ba = _bbb3e95cc4a3  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _dbcb1c86e15b = self._689ab620be58._fc90280d66d3._137edbe280c1  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _f859b86be061 in _dbcb1c86e15b[-_fdc0d835011e:]:
                    for _06a3a953f9f1 in _f859b86be061._203e3f83c27d():
                        if _38e8db554ad0(_06a3a953f9f1, _0316ac5a2b74._4b8e10258290) and (_06a3a953f9f1._8bcfe713878b() or _0316ac5a2b74._f4c1c0d02571(_06a3a953f9f1)):
                            _06a3a953f9f1._22071fce29ba = _4a8f86e6251f
                if _7b50f9daeee0(self._689ab620be58, "lm_head"):
                    self._689ab620be58._941ee9b16267._22071fce29ba = _4a8f86e6251f

        self._6b312310834f = 1
        _650354848ff9(f"DEBUG xth_batch init {self._6b312310834f}")
        global _f9798733b3b1
        _f9798733b3b1 = copy._3faa74d864d9(self._689ab620be58)._849625a04b11()
        self._5cc404bcfd3d = _5cc404bcfd3d

        self._0f84737e86d4 = {}
        self._ee53fab5f091 = {}

        # Loss function initialization
        if _0615d0c5cf90._f56895b7a9a5() == "class_weighted_cross_entropy_loss":
            self._ee53fab5f091['criterion'] = _0649d6b8e615(_f06e3ecb8b53=self._f06e3ecb8b53,
                                                            _de41be4d9bd9=self._bc4341c5ad90,
                                                            _ee4d70a2e212=self._531e8940e841,
                                                            _7d484e52b935=self._781dbdeb872d)
        elif _0615d0c5cf90._f56895b7a9a5() == "focal_loss":
            self._ee53fab5f091['criterion'] = _ca8ae1317a4b(_915ed786bea6=0.25,
                                                     _de41be4d9bd9=self._bc4341c5ad90,
                                                     _ee4d70a2e212=self._531e8940e841,
                                                     _7d484e52b935=self._781dbdeb872d)
        elif _0615d0c5cf90._f56895b7a9a5() == "class_weighted_focal_loss":
            self._ee53fab5f091['criterion'] = _ca8ae1317a4b(_915ed786bea6=self._f06e3ecb8b53,
                                                     _de41be4d9bd9=self._bc4341c5ad90,
                                                     _ee4d70a2e212=self._531e8940e841,
                                                     _7d484e52b935=self._781dbdeb872d)
        elif _0615d0c5cf90._f56895b7a9a5() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._ee53fab5f091['criterion'] = _801b8b204252(_915ed786bea6=self._f06e3ecb8b53,
                                                                      _6a38d59d2604='type1',
                                                                      _de41be4d9bd9=self._bc4341c5ad90,
                                                                      _ee4d70a2e212=self._531e8940e841,
                                                                      _7d484e52b935=self._781dbdeb872d)
        elif _0615d0c5cf90._f56895b7a9a5() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._ee53fab5f091['criterion'] = _801b8b204252(_915ed786bea6=self._f06e3ecb8b53,
                                                                      _6a38d59d2604='type2',
                                                                      _de41be4d9bd9=self._bc4341c5ad90,
                                                                      _ee4d70a2e212=self._531e8940e841,
                                                                      _7d484e52b935=self._781dbdeb872d)
        elif _0615d0c5cf90._f56895b7a9a5() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._ee53fab5f091['criterion'] = _801b8b204252(_915ed786bea6=self._f06e3ecb8b53,
                                                                      _6a38d59d2604='type3',
                                                                      _de41be4d9bd9=self._bc4341c5ad90,
                                                                      _ee4d70a2e212=self._531e8940e841,
                                                                      _7d484e52b935=self._781dbdeb872d)
        else:
            self._ee53fab5f091['criterion'] = _0649d6b8e615(_de41be4d9bd9=self._bc4341c5ad90,
                                                            _ee4d70a2e212=self._531e8940e841,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._3560d2dcfa0f = 0.99
        self._c1c5e9904626 = 0.3
        self._2a61fd8bf9ff = 0.30
        self._12cb0ba73fa6 = 0.25
        self._f5974b6714df = 0.6
        self._5d1dd330dde0 = 0.995
        self._95eebdf9f4b4 = 0.60
        self._84ae41349396 = 0.20
        self._9e7e4b20f965 = _4cfd48b7bf24(self, "batch_counter", 0)


        self._9f3e3737ebd3 = []
        self._07b26759c977 = []

        self._09a3b6212085 = _69749d296508._f56895b7a9a5()
        self._068a1ec0c344()

        self._27a459b73a90(self._689ab620be58)
    
    def _89feccd9b17b(self):
        # rebuild all metrics on the correct device
        self._0f84737e86d4['micro_accuracy'] = _c37acc16d73f(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685="micro",
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['macro_accuracy'] = _c37acc16d73f(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685="macro",
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['macro_precision'] = _5f1296571182(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685="macro",
            _f8c692cfe001=self. _37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['macro_recall'] = _bbc5a9151b03(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685="macro",
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['macro_f1'] = _889088351f4f(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685="macro",
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['classwise_accuracy'] = _c37acc16d73f(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685=_2431e119344c,
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['classwise_precision'] = _5f1296571182(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685=_2431e119344c,
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['classwise_recall'] = _bbc5a9151b03(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685=_2431e119344c,
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['classwise_f1'] = _889088351f4f(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _d9a06fcb3685=_2431e119344c,
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)

        self._0f84737e86d4['confmat'] = _27626c002733(
            _434a460a665f=_ca4d7a12cacf(self._abb73c99b2a7),
            _f8c692cfe001=self._37816b26d766,
            _ee4d70a2e212=self._531e8940e841,
        )._aba6dfc59e20(self._bc4341c5ad90)


    def _e2dc64bee930(self, _00436ee3d027=_2431e119344c):
        """Calculate batch counts and set xth_batch_to_consider."""
        _67aaed422cb0 = 0
        _a5fd1f42d824 = 0
        if self._a8339ddd0952._ef11c35fe928 is not _2431e119344c:
            if _7b50f9daeee0(self._a8339ddd0952._ef11c35fe928, 'train_dataset') and self._a8339ddd0952._ef11c35fe928._22aff42f970d is not _2431e119344c:
                _67aaed422cb0 = _ca4d7a12cacf(self._a8339ddd0952._ef11c35fe928._22aff42f970d)
            if _7b50f9daeee0(self._a8339ddd0952._ef11c35fe928, 'val_dataset') and self._a8339ddd0952._ef11c35fe928._9932d20ccbab is not _2431e119344c:
                _a5fd1f42d824 = _ca4d7a12cacf(self._a8339ddd0952._ef11c35fe928._9932d20ccbab)
            _64029770c040 = self._a8339ddd0952._ef11c35fe928._64029770c040
            _db4d9406e8a9 = (_67aaed422cb0 + _64029770c040 - 1) // _64029770c040 if _67aaed422cb0 > 0 else 1
            _a74bcd5bd6db = (_a5fd1f42d824 + _64029770c040 - 1) // _64029770c040 if _a5fd1f42d824 > 0 else 1
            _079a65a46fa3 = _d9d082365132(_db4d9406e8a9, _a74bcd5bd6db) if _a5fd1f42d824 > 0 else _db4d9406e8a9
            _945ed8958a84 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._6b312310834f = 1
            _650354848ff9(f"DEBUG Batch Info: num_train_batches={_db4d9406e8a9}, num_val_batches={_a74bcd5bd6db}, xth_batch_to_consider={self._6b312310834f}")

    def _bc062dc51fc2(self, _c6ef709a65ac, _189a69054df9):
        if _c6ef709a65ac._f56895b7a9a5() == "parametric_relu":
            return _0316ac5a2b74._92d99dcbe74a._0abd2a7d6bbf(_189a69054df9=1)
        elif _c6ef709a65ac._f56895b7a9a5() == "leaky_relu":
            return _0316ac5a2b74._92d99dcbe74a._d99f71d5a8bc(_2d62ef18676c=_bbb3e95cc4a3)
        else:
            return _0316ac5a2b74._92d99dcbe74a._96be78c6fa03(_2d62ef18676c=_bbb3e95cc4a3)

    def _7fa21c2917be(self, _de368f7a6279, _d9873bacafe8=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _4f095be1fce3, _165469e868e5 in _de368f7a6279._70f20e9d2204():
            _8a75291309df = f"{_d9873bacafe8}.{_4f095be1fce3}" if _d9873bacafe8 else _4f095be1fce3

            def _50365f9ad446(_232d42ab9f41, _d7e203fa7fe6, _72fa095b293f):
                if _38e8db554ad0(_72fa095b293f, _0316ac5a2b74._4b8e10258290) and _72fa095b293f._ad01623a9a3e()._ce3400912625():
                    _650354848ff9(f"NaN detected in {_8a75291309df} ({_232d42ab9f41._262af9ce33f9.__name__}) ({_72fa095b293f._56b5104fd8d1})")

            _165469e868e5._be738193f2db(_c0325c881ebc)

            self._27a459b73a90(_165469e868e5, _8a75291309df)

    def _5493bb0245d4(self, _de368f7a6279):
        return _ce3400912625(_601da9576fa0._22071fce29ba for _601da9576fa0 in _de368f7a6279._203e3f83c27d())

    def _f2559cefd220(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _71abcb2240d0 = []
        for _4f095be1fce3, _de368f7a6279 in self._fa2bd6cc4a29():
            if not self._8495e733165d(_de368f7a6279):
                continue
            _3abf0210e79c = (
                "norm" in _4f095be1fce3._d6efc2941ebf() or 
                "linear4bit" in _4f095be1fce3._d6efc2941ebf() or 
                _ce3400912625(_7376d36e9c98 in _4f095be1fce3._d6efc2941ebf() for _7376d36e9c98 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _4f095be1fce3._d6efc2941ebf() or 
                "dropout" in _4f095be1fce3._d6efc2941ebf() or 
                _38e8db554ad0(_de368f7a6279, (_f3027ecf18e1, _0316ac5a2b74._92d99dcbe74a._70ce095df902, _0316ac5a2b74._92d99dcbe74a._a527a202b559))
            )
            if _3abf0210e79c:
                if _7b50f9daeee0(_de368f7a6279, "eps"):
                    _de368f7a6279._b330c3cdeaed = 1e-3
                _de368f7a6279 = _de368f7a6279._aba6dfc59e20(_0316ac5a2b74._afae18f2e083)
                if not _38e8db554ad0(_de368f7a6279, _94b41beb159a._81975af19b97):
                    _71abcb2240d0._b44262aeeb1d((_4f095be1fce3, _94b41beb159a._81975af19b97(_de368f7a6279, _4d12ee3509ab=-10, _f763fc62cda7=10)))
        for _4f095be1fce3, _ce96cd0c4728 in _71abcb2240d0:
            _680493ccc50f, _87330c819dfe = self._903c030dca4c(_4f095be1fce3)
            if _680493ccc50f is not _2431e119344c:
                _8f13fd6ba04c(_680493ccc50f, _87330c819dfe, _ce96cd0c4728)

    def _026a4af27bbc(self, _865e70744b17):
        """Finds the parent module and attribute name given the full module path."""
        _75b5606047b7 = _865e70744b17._bf0a10c1ba10('.')
        _194efcebaff4 = self
        for _0a4afdaf16c6 in _75b5606047b7[:-1]:
            _194efcebaff4 = _4cfd48b7bf24(_194efcebaff4, _0a4afdaf16c6, _2431e119344c)
            if _194efcebaff4 is _2431e119344c:
                return _2431e119344c, _2431e119344c
        return _194efcebaff4, _75b5606047b7[-1]

    def _d13dde762eac(self, _fdf343714dae: _0316ac5a2b74._4b8e10258290, _40025f692dbf: _0316ac5a2b74._4b8e10258290, _c54aeb3b6952: _0316ac5a2b74._4b8e10258290) -> _d6c0cdc322e4:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _de41be4d9bd9 = _fdf343714dae._de41be4d9bd9

        # 1) gating w (use cached per-example teacher_conf if available)
        _a93208aa62b0 = _4cfd48b7bf24(self, "_last_teacher_conf", _2431e119344c)
        if _a93208aa62b0 is _2431e119344c:
            # no teacher info => w = 0 (no distillation)
            _3f6fa38a3585 = 0.0
        else:
            _d6f12944a1c4 = (_a93208aa62b0 >= _832e99df44d6(_4cfd48b7bf24(self, "teacher_conf_tau", 0.6)))._832e99df44d6()
            _3f6fa38a3585 = _832e99df44d6(_d6f12944a1c4._eea34e082297()._53cb3759802b()._48cf0a8157ce()) if _d6f12944a1c4._379220d7f938() > 0 else 0.0

        # apply gating to the batch scalars
        _c07b462b35a5 = _40025f692dbf * _832e99df44d6(_3f6fa38a3585)
        _13333a533604 = _c54aeb3b6952 * _832e99df44d6(_3f6fa38a3585)

        # 2) EMAs for autoscaling
        _9b2a93c08527 = _832e99df44d6((_c07b462b35a5 + _13333a533604)._b6827c62d41e()._53cb3759802b()._48cf0a8157ce())
        _3b4876d0722e = _832e99df44d6(_fdf343714dae._b6827c62d41e()._53cb3759802b()._48cf0a8157ce())
        if _4cfd48b7bf24(self, "ema_task", _2431e119344c) is _2431e119344c:
            self._0a9314292613 = _3b4876d0722e
            self._42000dd45376 = _9b2a93c08527 + 1e-12
        else:
            _915ed786bea6 = _832e99df44d6(_4cfd48b7bf24(self, "ema_alpha", 0.99))
            self._0a9314292613 = _915ed786bea6 * _832e99df44d6(self._0a9314292613) + (1.0 - _915ed786bea6) * _3b4876d0722e
            self._42000dd45376  = _915ed786bea6 * _832e99df44d6(self._42000dd45376)  + (1.0 - _915ed786bea6) * _9b2a93c08527

        _4e52ec67605b = _832e99df44d6(_4cfd48b7bf24(self, "distill_target_ratio", 0.3))
        _7ec739d14ef5 = (_832e99df44d6(self._0a9314292613) / (_832e99df44d6(self._42000dd45376) + 1e-12)) * _4e52ec67605b
        _bdd312c0f81f = _832e99df44d6(_7ec739d14ef5)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _46bdb9afee04 = _832e99df44d6(_4cfd48b7bf24(self._a8339ddd0952, "current_epoch", _4cfd48b7bf24(self._a8339ddd0952, "global_step", 0.0)))
        _4f135671b19c = _832e99df44d6(_0f437448fea0(1, _4cfd48b7bf24(self._a8339ddd0952, "max_epochs", 1)))
        _43a18462daa9 = _d9d082365132(_0f437448fea0(_46bdb9afee04 / _4f135671b19c, 0.0), 1.0)
        _527d75d0d2a0 = 0.30
        _643d325de59b = _832e99df44d6(_4cfd48b7bf24(self, "kl_base", 0.30)) * _d9d082365132(_43a18462daa9 / _527d75d0d2a0, 1.0)
        _12cb0ba73fa6 = _832e99df44d6(_4cfd48b7bf24(self, "cos_base", 0.25))
        _79865b371eee = _12cb0ba73fa6 + (0.10 - _12cb0ba73fa6) * _43a18462daa9

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _d11bceea1404 = _832e99df44d6(self._bea39a0a1fe9._eea34e082297()._53cb3759802b()._48cf0a8157ce()) if _4cfd48b7bf24(self, "_last_teacher_conf", _2431e119344c) is not _2431e119344c else 0.0
        if _4cfd48b7bf24(self, "ema_teacher_conf", _2431e119344c) is _2431e119344c:
            self._52d7afceb69b = _d11bceea1404
        else:
            _1df2c27f88bd = _832e99df44d6(_4cfd48b7bf24(self, "teacher_conf_beta", 0.995))
            self._52d7afceb69b = _1df2c27f88bd * _832e99df44d6(self._52d7afceb69b) + (1.0 - _1df2c27f88bd) * _d11bceea1404

        _95eebdf9f4b4 = _832e99df44d6(_4cfd48b7bf24(self, "tau_warn", 0.60))
        _84ae41349396 = _832e99df44d6(_4cfd48b7bf24(self, "tau_detect", 0.20))
        _205174fe4156 = _0f437448fea0(1e-12, (_95eebdf9f4b4 - _84ae41349396))
        _6e737adf9b0b = (_832e99df44d6(self._52d7afceb69b) - _84ae41349396) / _205174fe4156
        _6e737adf9b0b = _0f437448fea0(0.0, _d9d082365132(1.0, _6e737adf9b0b))

        _8b4245615472 = _643d325de59b * _6e737adf9b0b
        _c362fc580c21 = _79865b371eee * _6e737adf9b0b

        # 5) final aux term
        _63d6c72e3f9e = _0316ac5a2b74._5812e5c7334e(0.0, _de41be4d9bd9=_de41be4d9bd9)
        _63d6c72e3f9e = _63d6c72e3f9e + (_8b4245615472 * _c07b462b35a5 + _c362fc580c21 * _13333a533604) * _832e99df44d6(_bdd312c0f81f)

        # diagnostics
        _72fa095b293f = {
            "aux_term": _63d6c72e3f9e,
            "kl_batch": _40025f692dbf,
            "contrast_batch": _c54aeb3b6952,
            "kl_loss": _c07b462b35a5,
            "contrastive_loss": _13333a533604,
            "w_mean": _3f6fa38a3585,
            "aux_scale": _832e99df44d6(_bdd312c0f81f),
            "lambda_kl_eff": _832e99df44d6(_8b4245615472),
            "lambda_cos_eff": _832e99df44d6(_c362fc580c21),
            "teacher_conf_mean": _832e99df44d6(self._52d7afceb69b),
            "shift_r": _832e99df44d6(_6e737adf9b0b)
        }
        return _72fa095b293f

    def _e2595b92d738(self, _0d00ddf3a705):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _0d00ddf3a705 = _0d00ddf3a705._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)
        _9965f4584976 = (_0d00ddf3a705 != self._f1efa6fb0aa4._4804eaf48caf)._aba6dfc59e20(_56b5104fd8d1=_0316ac5a2b74._2e010ab34ec6, _de41be4d9bd9=self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)

        # model forward (request hidden states)
        _c7d60be18cba = self._689ab620be58(
            _0d00ddf3a705=_0d00ddf3a705,
            _9965f4584976=_9965f4584976,
            _28c4aeef314a=_4a8f86e6251f,
            _c7d6c3b3dd7f=_4a8f86e6251f,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _eb7ded915f20 = _4cfd48b7bf24(_c7d60be18cba, "last_hidden_state", _2431e119344c)
        if _eb7ded915f20 is _2431e119344c:
            _eb7ded915f20 = _c7d60be18cba._dce44cd6a3cf[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _eb7ded915f20._56b5104fd8d1 != _0316ac5a2b74._afae18f2e083:
            _eb7ded915f20 = _eb7ded915f20._aba6dfc59e20(_0316ac5a2b74._afae18f2e083)
        _d6e0ab3043a4 = self._f3ba051aac0d(_eb7ded915f20)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._992c5e05768b:
            _f5af84caec8b = self._37c983e99b25(_d6e0ab3043a4)
        else:
            _f5af84caec8b = _c7d60be18cba._f5af84caec8b


        _f5af84caec8b = _f5af84caec8b._aba6dfc59e20(_0316ac5a2b74._afae18f2e083)._53812eac6d7e(-20, 20)

        # default zero scalars
        _c07b462b35a5 = _0316ac5a2b74._5812e5c7334e(0.0, _de41be4d9bd9=self._bc4341c5ad90)
        _13333a533604 = _0316ac5a2b74._5812e5c7334e(0.0, _de41be4d9bd9=self._bc4341c5ad90)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _12192b38f9ee = _4cfd48b7bf24(self, "trainer", _2431e119344c)
        _b66a912c2a43 = _bbb3e95cc4a3
        if _12192b38f9ee is not _2431e119344c:
            _b66a912c2a43 = _2e010ab34ec6(_4cfd48b7bf24(self._a8339ddd0952, "training", _bbb3e95cc4a3) or _4cfd48b7bf24(self._a8339ddd0952, "validating", _bbb3e95cc4a3))

        if _b66a912c2a43 and (_4cfd48b7bf24(self, "batch_counter", 0) % _4cfd48b7bf24(self, "xth_batch_to_consider", 1) == 0):
            with _0316ac5a2b74._cee19b726f3b():
                _167bc91becfb = _f9798733b3b1(
                    _0d00ddf3a705=_0d00ddf3a705,
                    _9965f4584976=_9965f4584976,
                    _28c4aeef314a=_4a8f86e6251f,
                    _c7d6c3b3dd7f=_4a8f86e6251f,
                )
                _2e97460b6151 = _4cfd48b7bf24(_167bc91becfb, "last_hidden_state", _2431e119344c)
                if _2e97460b6151 is _2431e119344c:
                    _2e97460b6151 = _167bc91becfb._dce44cd6a3cf[-1]

            # compute embedding-level KL + contrastive (scalar)
            _c07b462b35a5, _13333a533604 = self._ae60d58d8401(_d6e0ab3043a4, _2e97460b6151, _de41be4d9bd9=self._bc4341c5ad90)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _4568ed338f51(_1aaa11a79046): return _1aaa11a79046._eea34e082297(_fd99d22dec2b=1) if _1aaa11a79046._fd99d22dec2b() == 3 else _1aaa11a79046
            _4a266f7ea27e = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._595d1570ad6e(_fe7c2aa1eaeb(_d6e0ab3043a4), _601da9576fa0=2, _fd99d22dec2b=-1, _b330c3cdeaed=1e-6)
            _e110781db1ad = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._595d1570ad6e(_fe7c2aa1eaeb(_2e97460b6151), _601da9576fa0=2, _fd99d22dec2b=-1, _b330c3cdeaed=1e-6)
            _5ab5763f339d = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._116d0c36c5c7(_4a266f7ea27e, _e110781db1ad, _fd99d22dec2b=-1)  # [-1,1]
            _a93208aa62b0 = _5ab5763f339d._53812eac6d7e(_d9d082365132=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._3eef0c6d3da3 = _d6e0ab3043a4._b6827c62d41e()
            self._9d0f9a65f42f = _2e97460b6151._b6827c62d41e()
            self._bea39a0a1fe9 = _a93208aa62b0._b6827c62d41e()  # shape (B,)

        # increment counter
        self._9e7e4b20f965 = _4cfd48b7bf24(self, "batch_counter", 0) + 1

        return _f5af84caec8b, _c07b462b35a5, _13333a533604


    def _c3106ba2087a(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _03b789a870eb(_de368f7a6279, _f0f66aa1a60b, _6842d61eb3d2):
            if _ce3400912625(_d7e203fa7fe6._56b5104fd8d1 == _0316ac5a2b74._9b2e00506ad3 for _d7e203fa7fe6 in _f0f66aa1a60b if _38e8db554ad0(_d7e203fa7fe6, _0316ac5a2b74._4b8e10258290)):
                _650354848ff9(f"Layer {_de368f7a6279._262af9ce33f9.__name__} is using float16!")

        for _77581369f832 in self._cf535d6b6b9f():
            _f6ced704bc29 = _77581369f832._be738193f2db(_abf0dd621c94)
            self._4d2b888a24ff._b44262aeeb1d(_f6ced704bc29)

    def _aeae02d1d4fa(self):
        """Remove all registered forward hooks."""
        for _f6ced704bc29 in _4cfd48b7bf24(self, "amp_hooks", []):
            _f6ced704bc29._3ffab268e821()
        self._4d2b888a24ff = []

    def _9a5186d3fd12(self, _0d00ddf3a705, _16948e869b9b, _2983fed9c193):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _e2267f22bb42 = [self._f1efa6fb0aa4._7d698d9b6177(_fdda23b0e168) for _fdda23b0e168 in _0d00ddf3a705]
        _311514f86e42, _8c32ce612ccf = [], []

        for _d4970f26234a, _020f9542df89, _9e059438013a in _f8dda0191362(_e2267f22bb42, _16948e869b9b, _2983fed9c193):
            for token, _c765bd00a32c, _8c982ee503ca in _f8dda0191362(_d4970f26234a, _020f9542df89, _9e059438013a):
                if token == self._f1efa6fb0aa4._041dfc937e74 or _8c982ee503ca == self._531e8940e841:
                    continue

                _c2c6288ff6c5 = (
                    token._c84c7a2e08da("##") or
                    token._c84c7a2e08da("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _c2c6288ff6c5:
                    continue

                _311514f86e42._b44262aeeb1d(_c765bd00a32c._48cf0a8157ce())
                _8c32ce612ccf._b44262aeeb1d(_8c982ee503ca._48cf0a8157ce())

        return _0316ac5a2b74._5812e5c7334e(_311514f86e42), _0316ac5a2b74._5812e5c7334e(_8c32ce612ccf)

    def _f1316531d93a(self):
        _f99a800eebb3 = _0316ac5a2b74._afae18f2e083
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            _247869790e34, _105156d8752b = _0316ac5a2b74._0b653ba58228._eef741b9cf92()
            if _247869790e34 >= 8:
                _f99a800eebb3 = _0316ac5a2b74._e9c6040c4a4d
            else:
                _f99a800eebb3 = _0316ac5a2b74._9b2e00506ad3
        return _f99a800eebb3

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _8462a8d55062(
        self,
        _b53bbacee11e: _0316ac5a2b74._4b8e10258290,
        _43a6447a06ad: _0316ac5a2b74._4b8e10258290,
        _de41be4d9bd9: _1f58285b871e = "cpu",
    ) -> _5a00f2f007cb[_0316ac5a2b74._4b8e10258290, _0316ac5a2b74._4b8e10258290]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _bf3ff1f51950 = 2.0
            # NaN/Inf guard
            _b53bbacee11e = _b53bbacee11e._53812eac6d7e(_d9d082365132=-30, _0f437448fea0=30)
            _43a6447a06ad = _43a6447a06ad._53812eac6d7e(_d9d082365132=-30, _0f437448fea0=30)

            # Move once if needed
            _f948a4c9d4aa = _0316ac5a2b74._de41be4d9bd9(_de41be4d9bd9)
            if _b53bbacee11e._de41be4d9bd9 != _f948a4c9d4aa:
                _b53bbacee11e = _b53bbacee11e._aba6dfc59e20(_de41be4d9bd9=_f948a4c9d4aa, _659b96787449=_4a8f86e6251f, _56b5104fd8d1=self._e18c8b0df0fb)
                _43a6447a06ad = _43a6447a06ad._aba6dfc59e20(_de41be4d9bd9=_f948a4c9d4aa, _659b96787449=_4a8f86e6251f, _56b5104fd8d1=self._e18c8b0df0fb)

            _64029770c040 = _b53bbacee11e._1162f58bd894(0)
            _43639e08b2d4 = _b53bbacee11e._1162f58bd894(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _aa303470f787 = (_64029770c040 * _43639e08b2d4) > 32_000_000

            if not _aa303470f787 or _64029770c040 <= 8:
                # Direct computation
                _7bce1f47f13b = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._ec909b0bbe85(_b53bbacee11e / _bf3ff1f51950, _fd99d22dec2b=-1)
                _8aa5002ca61d = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._ad151565217e(_43a6447a06ad / _bf3ff1f51950, _fd99d22dec2b=-1)
                _c07b462b35a5 = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._c2557b88349c(_7bce1f47f13b, _8aa5002ca61d, _f8f2db641838="batchmean") * (_bf3ff1f51950 * _bf3ff1f51950)
                _13333a533604 = 1 - _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._116d0c36c5c7(_b53bbacee11e, _43a6447a06ad, _fd99d22dec2b=-1)._eea34e082297()
                return _c07b462b35a5, _13333a533604

            # Chunked mode for large inputs
            _0e46889f4ff1 = _0f437448fea0(1, _64029770c040 // 8)
            _988fa9ebe2b5, _a9dfe6eb50d6 = [], []

            for _b2d99ad60a18 in _51d785c4609a(0, _64029770c040, _0e46889f4ff1):
                _5e66b832be6d = _b53bbacee11e[_b2d99ad60a18:_b2d99ad60a18 + _0e46889f4ff1]
                _e5fde881e99a = _43a6447a06ad[_b2d99ad60a18:_b2d99ad60a18 + _0e46889f4ff1]

                _7bce1f47f13b = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._ec909b0bbe85(_5e66b832be6d / _bf3ff1f51950, _fd99d22dec2b=-1)
                _8aa5002ca61d = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._ad151565217e(_e5fde881e99a / _bf3ff1f51950, _fd99d22dec2b=-1)

                _bb9096d17d5e = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._c2557b88349c(_7bce1f47f13b, _8aa5002ca61d, _f8f2db641838="batchmean") * (_bf3ff1f51950 * _bf3ff1f51950)
                _8dbfe4963410 = _0316ac5a2b74._92d99dcbe74a._0d72d40602d5._116d0c36c5c7(_5e66b832be6d, _e5fde881e99a, _fd99d22dec2b=-1)._eea34e082297()
                _08e5b3f2d47d = 1 - _8dbfe4963410

                _988fa9ebe2b5._b44262aeeb1d(_bb9096d17d5e)
                _a9dfe6eb50d6._b44262aeeb1d(_08e5b3f2d47d)

            _c07b462b35a5 = _0316ac5a2b74._2f5f4d4fed09(_988fa9ebe2b5)._eea34e082297()
            _13333a533604 = _0316ac5a2b74._2f5f4d4fed09(_a9dfe6eb50d6)._eea34e082297()
            return _c07b462b35a5, _13333a533604

        except _50539114cf0b as _38d58eb6af52:
            raise _c49efcb69e02(f"KL/contrastive loss computation failed: {_1f58285b871e(_38d58eb6af52)}")


    def _58baeb5dfe80(self, _28795a8da928, _641063c9ab19):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _0d00ddf3a705 = _28795a8da928["input_ids"]
            _9e3936b45ed0 = _28795a8da928["labels"]
            _2077715b0576 = _28795a8da928._7241eb800c5f("prompt_lens", _2431e119344c)
            _64029770c040 = _0d00ddf3a705._1162f58bd894(0)

            # move to device
            _0d00ddf3a705 = _0d00ddf3a705._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)
            _9e3936b45ed0 = _9e3936b45ed0._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _6842d61eb3d2, _40025f692dbf, _c54aeb3b6952 = self(_0d00ddf3a705)

            # causal LM shift for next-token classification (unchanged)
            _b81ec501c321 = _6842d61eb3d2[:, :-1, :]._73501a522459()
            _40458a762d2e = _9e3936b45ed0[:, 1:]._73501a522459()
            _987315f1e539 = _b81ec501c321._0c960270e2ce(-1, _b81ec501c321._1162f58bd894(-1))
            _98779037d9f5 = _40458a762d2e._0c960270e2ce(-1)

            # classification/task loss
            _c542cf45350d = self._ee53fab5f091['criterion'](_987315f1e539, _98779037d9f5)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _40025f692dbf = _0316ac5a2b74._0bce0e54111c(_40025f692dbf, _24c5878633c5=0.0, _ba7e35e3b3f9=0.0, _64aa1e0b3a98=0.0)
            _c54aeb3b6952 = _0316ac5a2b74._0bce0e54111c(_c54aeb3b6952, _24c5878633c5=0.0, _ba7e35e3b3f9=0.0, _64aa1e0b3a98=0.0)
            _c542cf45350d = _0316ac5a2b74._0bce0e54111c(_c542cf45350d, _24c5878633c5=0.0, _ba7e35e3b3f9=0.0, _64aa1e0b3a98=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _0412c60489ad = self._a02c825e1ca5(_c542cf45350d, _40025f692dbf, _c54aeb3b6952)
            _63d6c72e3f9e = _0412c60489ad["aux_term"]

            # final combined loss (single-equation)
            _aa9f7e7f0f8d = _c542cf45350d + _63d6c72e3f9e

            # Optional NaN print as before (keeps your original check)
            if _0316ac5a2b74._ad01623a9a3e(_c542cf45350d):
                _650354848ff9(f"Step {_641063c9ab19}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _9741e7a810e0 = {
                "epoch": _832e99df44d6(_4cfd48b7bf24(self, "current_epoch", _4cfd48b7bf24(self._a8339ddd0952, "current_epoch", 0))),
                "train_kl_loss": _0412c60489ad._7241eb800c5f("kl_loss", _40025f692dbf)._b6827c62d41e() if _38e8db554ad0(_0412c60489ad._7241eb800c5f("kl_loss", _40025f692dbf), _0316ac5a2b74._4b8e10258290) else _0412c60489ad._7241eb800c5f("kl_loss", _40025f692dbf),
                "train_contrastive_loss": _0412c60489ad._7241eb800c5f("contrastive_loss", _c54aeb3b6952)._b6827c62d41e() if _38e8db554ad0(_0412c60489ad._7241eb800c5f("contrastive_loss", _c54aeb3b6952), _0316ac5a2b74._4b8e10258290) else _0412c60489ad._7241eb800c5f("contrastive_loss", _c54aeb3b6952),
                "train_classification_loss": _c542cf45350d._b6827c62d41e(),
                "train_loss": _aa9f7e7f0f8d._b6827c62d41e(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _832e99df44d6(_4cfd48b7bf24(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _0412c60489ad._7241eb800c5f("lambda_kl_eff", _832e99df44d6(_4cfd48b7bf24(self, "kl_base", 0.30))),
                "train_lambda_contrast": _0412c60489ad._7241eb800c5f("lambda_cos_eff", _832e99df44d6(_4cfd48b7bf24(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _7085fe3829a2 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _7085fe3829a2 in _0412c60489ad:
                    _70ada6ba9e21 = _0412c60489ad[_7085fe3829a2]
                    # convert single-element tensors to python floats for logging
                    if _38e8db554ad0(_70ada6ba9e21, _0316ac5a2b74._4b8e10258290) and _70ada6ba9e21._379220d7f938() == 1:
                        _9741e7a810e0[f"train_{_7085fe3829a2}"] = _832e99df44d6(_70ada6ba9e21._b6827c62d41e()._53cb3759802b()._48cf0a8157ce())
                    else:
                        _9741e7a810e0[f"train_{_7085fe3829a2}"] = _70ada6ba9e21

            # log exactly like you did
            self._43a4ad0c6adf(
                _9741e7a810e0,
                _64029770c040=_64029770c040,
                _ce7e4f491375=_bbb3e95cc4a3,
                _7ca53f7fe9ea=_4a8f86e6251f,
                _b5150c0522b7=_bbb3e95cc4a3,
                _e7bd89d85402=_4a8f86e6251f,
                _27441351ea79=_4a8f86e6251f,
            )

            # free references as you did
            del _0d00ddf3a705, _9e3936b45ed0, _6842d61eb3d2, _40025f692dbf, _c542cf45350d, _c54aeb3b6952, _40458a762d2e, _b81ec501c321, _98779037d9f5, _987315f1e539

            return _aa9f7e7f0f8d

        except _50539114cf0b as _38d58eb6af52:
            raise _c49efcb69e02(f"Error in training_step: {_38d58eb6af52}") from _38d58eb6af52

    def _d8c81f040da6(self):
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            _0316ac5a2b74._0b653ba58228._7788b0243100()
        _b854f01ac396._02a9a426ccc7()
        return _2a435abb5247()._c5fe12c5268b()

    def _6805f3915af8(self, _28795a8da928, _641063c9ab19):
        _0d00ddf3a705      = _28795a8da928["input_ids"]._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)
        _9e3936b45ed0         = _28795a8da928["labels"]._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)
        _6b5a6005954b     = _28795a8da928._7241eb800c5f("lang_codes", _2431e119344c)
        _167b54ad180a     = _28795a8da928._7241eb800c5f("sample_ids", _2431e119344c)
        _ad7e8fac28f6      = _28795a8da928._7241eb800c5f("chunk_ids", _2431e119344c)
        _bcf1e4ddf6a6 = _28795a8da928._7241eb800c5f("word_positions", _2431e119344c)
        _2077715b0576    = _28795a8da928._7241eb800c5f("prompt_lens", _2431e119344c)
        _eea3bab2327c = _28795a8da928._7241eb800c5f("num_chunks", _2431e119344c)

        _64029770c040 = _0d00ddf3a705._1162f58bd894(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _6842d61eb3d2, _40025f692dbf, _c54aeb3b6952 = self(_0d00ddf3a705)

        # causal LM shift for next-token classification (same as training)
        _b81ec501c321 = _6842d61eb3d2[:, :-1, :]._73501a522459()
        _40458a762d2e = _9e3936b45ed0[:, 1:]._73501a522459()
        _987315f1e539 = _b81ec501c321._0c960270e2ce(-1, _b81ec501c321._1162f58bd894(-1))
        _98779037d9f5 = _40458a762d2e._0c960270e2ce(-1)

        if _641063c9ab19 == 0:
            try:
                _650354848ff9(
                    f"VAL TEST BATCH {_641063c9ab19} Input IDs: {_0d00ddf3a705._2edd1561e9cf()[0]}, "
                    f"Predictions: {_0316ac5a2b74._78e0495107e7(_b81ec501c321, _fd99d22dec2b=-1)._2edd1561e9cf()[0]}, "
                    f"Labels: {_40458a762d2e._2edd1561e9cf()[0]}"
                )
            except _50539114cf0b:
                # printing should never crash validation
                pass

        # classification loss
        _c542cf45350d = self._ee53fab5f091['criterion'](_987315f1e539, _98779037d9f5)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _40025f692dbf = _0316ac5a2b74._0bce0e54111c(_40025f692dbf, _24c5878633c5=0.0, _ba7e35e3b3f9=0.0, _64aa1e0b3a98=0.0)
        _c54aeb3b6952 = _0316ac5a2b74._0bce0e54111c(_c54aeb3b6952, _24c5878633c5=0.0, _ba7e35e3b3f9=0.0, _64aa1e0b3a98=0.0)
        _c542cf45350d = _0316ac5a2b74._0bce0e54111c(_c542cf45350d, _24c5878633c5=0.0, _ba7e35e3b3f9=0.0, _64aa1e0b3a98=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _0412c60489ad = self._a02c825e1ca5(_c542cf45350d, _40025f692dbf, _c54aeb3b6952)
        _63d6c72e3f9e = _0412c60489ad["aux_term"]
        _aa9f7e7f0f8d = _c542cf45350d + _63d6c72e3f9e

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _43a4ad0c6adf = {
            "val_kl_loss": _832e99df44d6(_0412c60489ad._7241eb800c5f("kl_loss", _40025f692dbf)._b6827c62d41e()._53cb3759802b()._48cf0a8157ce()) if _38e8db554ad0(_0412c60489ad._7241eb800c5f("kl_loss", _40025f692dbf), _0316ac5a2b74._4b8e10258290) else _832e99df44d6(_0412c60489ad._7241eb800c5f("kl_loss", _40025f692dbf)),
            "val_contrastive_loss": _832e99df44d6(_0412c60489ad._7241eb800c5f("contrastive_loss", _c54aeb3b6952)._b6827c62d41e()._53cb3759802b()._48cf0a8157ce()) if _38e8db554ad0(_0412c60489ad._7241eb800c5f("contrastive_loss", _c54aeb3b6952), _0316ac5a2b74._4b8e10258290) else _832e99df44d6(_0412c60489ad._7241eb800c5f("contrastive_loss", _c54aeb3b6952)),
            "val_classification_loss": _832e99df44d6(_c542cf45350d._b6827c62d41e()._53cb3759802b()._48cf0a8157ce()),
            "val_loss": _832e99df44d6(_aa9f7e7f0f8d._b6827c62d41e()._53cb3759802b()._48cf0a8157ce()),
        }

        # include effective lambdas and others if provided by aux
        _43a4ad0c6adf["val_lambda_kl"] = _832e99df44d6(_0412c60489ad._7241eb800c5f("lambda_kl", _0412c60489ad._7241eb800c5f("lambda_kl_eff", _832e99df44d6(_4cfd48b7bf24(self, "kl_base", 0.30)))))
        _43a4ad0c6adf["val_lambda_contrast"] = _832e99df44d6(_0412c60489ad._7241eb800c5f("lambda_cos", _0412c60489ad._7241eb800c5f("lambda_cos_eff", _832e99df44d6(_4cfd48b7bf24(self, "cos_base", 0.25)))))
        _43a4ad0c6adf["val_w_mean"] = _832e99df44d6(_0412c60489ad._7241eb800c5f("w_mean", 0.0))
        _43a4ad0c6adf["val_aux_scale"] = _832e99df44d6(_0412c60489ad._7241eb800c5f("aux_scale", 0.0))
        _43a4ad0c6adf["val_shift_r"] = _832e99df44d6(_0412c60489ad._7241eb800c5f("shift_r", 0.0))
        _43a4ad0c6adf["val_teacher_conf_mean"] = _832e99df44d6(_0412c60489ad._7241eb800c5f("teacher_conf_mean", 0.0))

        self._43a4ad0c6adf(
            _43a4ad0c6adf,
            _64029770c040=_64029770c040,
            _ce7e4f491375=_bbb3e95cc4a3,
            _7ca53f7fe9ea=_4a8f86e6251f,
            _b5150c0522b7=_bbb3e95cc4a3,
            _e7bd89d85402=_4a8f86e6251f,
            _27441351ea79=_4a8f86e6251f,
        )

        # build preds and labels per example (preserve your previous behavior)
        _26c544317cf4 = []
        _8ab66eb53bbb = []
        for _b2d99ad60a18 in _51d785c4609a(_64029770c040):
            _12b32c10dd43 = _6842d61eb3d2[_b2d99ad60a18]
            _8c982ee503ca = _9e3936b45ed0[_b2d99ad60a18]
            _f1b587c08dab = _0316ac5a2b74._78e0495107e7(_12b32c10dd43, _fd99d22dec2b=-1)
            _1c062d72b492 = _8c982ee503ca
            _26c544317cf4._b44262aeeb1d(_f1b587c08dab)
            _8ab66eb53bbb._b44262aeeb1d(_1c062d72b492)

        _2be583d3eafb = {
            "lang_codes": _6b5a6005954b,
            "preds": _26c544317cf4,
            "labels": _8ab66eb53bbb,
            "sample_ids": _167b54ad180a,
            "chunk_ids": _ad7e8fac28f6,
            "word_positions": _bcf1e4ddf6a6,
            "val_loss": _aa9f7e7f0f8d,
            "prompt_lens": _2077715b0576,
            "num_chunks": _eea3bab2327c,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._9f3e3737ebd3._b44262aeeb1d(_2be583d3eafb)

        # explicit frees (same as you had)
        del _0d00ddf3a705, _9e3936b45ed0, _6842d61eb3d2, _987315f1e539, _98779037d9f5, _b81ec501c321, _40458a762d2e
        del _40025f692dbf, _c54aeb3b6952, _c542cf45350d, _26c544317cf4, _8ab66eb53bbb

        return _2be583d3eafb


    def _f2481a79c916(self, _baaeb5646e2c, _0cf632b170f7, _6672ac0eca51=_2431e119344c):
        _f386ad365977 = os._e2031c216cc8()
        _fd8f880ac752 = f"trial_{_6672ac0eca51}" if _6672ac0eca51 is not _2431e119344c else "default"
        _650354848ff9(f"[DEBUG rank={_0316ac5a2b74._bbc5d98781c5._bcbacdd7718d() if _0316ac5a2b74._bbc5d98781c5._0facdd3dae79() else 0}] metrics_dict confusion_matrix sum={_c3dc0238bdc6(_c3dc0238bdc6(_e6d30643595e) for _e6d30643595e in _baaeb5646e2c['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _3046d6e24f1d = os._d5d78efc0b74._1725717b90ba(_f386ad365977, "metrics", self._be56b12a3ddc,  _fd8f880ac752)
        os._7c0d7c474bed(_3046d6e24f1d, _b15cb906e3f0=_4a8f86e6251f)
        _18bd49654ad4 = os._d5d78efc0b74._1725717b90ba(_3046d6e24f1d, _0cf632b170f7)
        _3d5d41fe2710 = _47d878a6a81b._2b3333aef7a9(_baaeb5646e2c)
        _3d5d41fe2710._b5169f677439(_18bd49654ad4, _f10ca344de34=_bbb3e95cc4a3)
        _650354848ff9(f"[metrics] Saved {_18bd49654ad4}")

    def _e4ee146966a0(self):
        # pick correct device for this rank
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            if _0316ac5a2b74._bbc5d98781c5._0facdd3dae79():
                _b208a576d02d = _0316ac5a2b74._bbc5d98781c5._bcbacdd7718d()
            else:
                _b208a576d02d = 0
            _0316ac5a2b74._0b653ba58228._aee7e7ea6793(_b208a576d02d)
            self._bc4341c5ad90 = _0316ac5a2b74._de41be4d9bd9(f"cuda:{_b208a576d02d}")
        else:
            self._bc4341c5ad90 = _0316ac5a2b74._de41be4d9bd9("cpu")

        self._df193b647ac7()

    def _c85bb542db40(self):
        _6842d61eb3d2 = _4cfd48b7bf24(self, "_validation_outputs", _2431e119344c)
        if not _6842d61eb3d2:
            return

        _6b2a5138025f, _86f65696f17a, _f67c7c0735e8, _002f9baab13d = \
            self._3de3ff296b04(_6842d61eb3d2)

        _be4cb5dc1e15, _f1c71ecd8ad7 = [], []
        for _cac27fe58609 in _57dd3b64433a(_f67c7c0735e8._f86cca9e1852()):
            _22983bbd9567 = _6b2a5138025f[_cac27fe58609]._2edd1561e9cf()
            _c4e8637ae799 = _86f65696f17a[_cac27fe58609]._2edd1561e9cf()
            _9634f77a3774 = _f67c7c0735e8[_cac27fe58609]
            _4fbde69bf604 = _002f9baab13d[_cac27fe58609]
            if _9634f77a3774._379220d7f938() > 0 and _4fbde69bf604._379220d7f938() > 0:
                _be4cb5dc1e15._b44262aeeb1d(_9634f77a3774)
                _f1c71ecd8ad7._b44262aeeb1d(_4fbde69bf604)

        if not _be4cb5dc1e15:
            _650354848ff9("[VAL END] Nothing to score.")
            self._9f3e3737ebd3._8164957ef685()
            return

        _9e2f74ebc6ed = _0316ac5a2b74._5fce247fab28(_be4cb5dc1e15)._aba6dfc59e20(_de41be4d9bd9=self._0f84737e86d4['micro_accuracy']._de41be4d9bd9, _659b96787449=_4a8f86e6251f)
        _9e3936b45ed0 = _0316ac5a2b74._5fce247fab28(_f1c71ecd8ad7)._aba6dfc59e20(_de41be4d9bd9=self._0f84737e86d4['micro_accuracy']._de41be4d9bd9, _659b96787449=_4a8f86e6251f)

        self._0f84737e86d4['micro_accuracy']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_accuracy']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_precision']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_recall']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_f1']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_accuracy']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_precision']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_recall']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_f1']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['confmat']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)

        _9cdb1d455f43  = self._0f84737e86d4['micro_accuracy']._4dafa01621fd()._48cf0a8157ce()
        _a8552cafb2c1  = self._0f84737e86d4['macro_accuracy']._4dafa01621fd()._48cf0a8157ce()
        _b9c26c039fa3 = self._0f84737e86d4['macro_precision']._4dafa01621fd()._48cf0a8157ce()
        _1f955521ee22    = self._0f84737e86d4['macro_recall']._4dafa01621fd()._48cf0a8157ce()
        _ea8339e29e0f        = self._0f84737e86d4['macro_f1']._4dafa01621fd()._48cf0a8157ce()

        self._fed9ef52fd44("val_accuracy", _a8552cafb2c1, _27441351ea79=_4a8f86e6251f)

        try:
            _a7ccf6991faf = self._b38eaf9e3f2a
            _baaeb5646e2c = {
                "epoch": [_a7ccf6991faf],
                "class_names": [self._abb73c99b2a7],
                "micro_accuracy": [_9cdb1d455f43],
                "macro_accuracy": [_a8552cafb2c1],
                "macro_precision": [_b9c26c039fa3],
                "macro_recall": [_1f955521ee22],
                "macro_f1": [_ea8339e29e0f],
                "classwise_accuracy": [self._0f84737e86d4['classwise_accuracy']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "classwise_precision": [self._0f84737e86d4['classwise_precision']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "classwise_recall": [self._0f84737e86d4['classwise_recall']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "classwise_f1": [self._0f84737e86d4['classwise_f1']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "confusion_matrix": [self._0f84737e86d4['confmat']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
            }
            self._3da545734d05(_baaeb5646e2c, f"val_epoch_{_a7ccf6991faf}.csv", _6672ac0eca51=self._6672ac0eca51)
        except _50539114cf0b as _38d58eb6af52:
            _650354848ff9(f"[VAL END] save metrics FAILED: {_38d58eb6af52}")

        # cleanup
        self._0f84737e86d4['micro_accuracy']._9f2e6395c64e(); self._0f84737e86d4['macro_accuracy']._9f2e6395c64e()
        self._0f84737e86d4['macro_precision']._9f2e6395c64e(); self._0f84737e86d4['macro_recall']._9f2e6395c64e(); self._0f84737e86d4['macro_f1']._9f2e6395c64e()
        self._0f84737e86d4['classwise_accuracy']._9f2e6395c64e(); self._0f84737e86d4['classwise_precision']._9f2e6395c64e()
        self._0f84737e86d4['classwise_recall']._9f2e6395c64e(); self._0f84737e86d4['classwise_f1']._9f2e6395c64e()
        self._0f84737e86d4['confmat']._9f2e6395c64e(); self._9f3e3737ebd3._8164957ef685()
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            _0316ac5a2b74._0b653ba58228._7788b0243100()
        _650354848ff9("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_0316ac5a2b74._cee19b726f3b()
    def _8a27a69843c0(self, _0d00ddf3a705: _0316ac5a2b74._4b8e10258290, **_c3e9883b5fb9):
        _c3e9883b5fb9._d2e4a772ea4c("pad_token_id", _2431e119344c)
        _c3e9883b5fb9._d2e4a772ea4c("attention_mask", _2431e119344c)
        return self._689ab620be58._14ee093aa173(
            _0d00ddf3a705=_0d00ddf3a705,
            _9965f4584976=(_0d00ddf3a705 != self._f1efa6fb0aa4._4804eaf48caf),
            _4804eaf48caf=self._f1efa6fb0aa4._4804eaf48caf,
            _81c1471af2a0=self._f1efa6fb0aa4._81c1471af2a0,
            **_c3e9883b5fb9
        )

    def _13eb4ba94009(self, _28795a8da928, _641063c9ab19):
        _0d00ddf3a705 = _28795a8da928["input_ids"]._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)
        _9e3936b45ed0    = _28795a8da928["labels"]._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)
        _6b5a6005954b     = _28795a8da928._7241eb800c5f("lang_codes", _2431e119344c)
        _167b54ad180a     = _28795a8da928._7241eb800c5f("sample_ids", _2431e119344c)
        _ad7e8fac28f6      = _28795a8da928._7241eb800c5f("chunk_ids", _2431e119344c)
        _bcf1e4ddf6a6 = _28795a8da928._7241eb800c5f("word_positions", _2431e119344c)
        _2077715b0576    = _28795a8da928._7241eb800c5f("prompt_lens", _2431e119344c)
        _eea3bab2327c = _28795a8da928._7241eb800c5f("num_chunks", _2431e119344c)

        _64029770c040 = _0d00ddf3a705._1162f58bd894(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _6f3e194095e3 = self._14ee093aa173(
            _0d00ddf3a705,
            _785c243482d6=48,
            _d2e5986e5fcf=_bbb3e95cc4a3,
            _05264b7790bd=_2431e119344c,     # or just add this
            _5e0bd4350c24=_2431e119344c,
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _26c544317cf4 = []
        _8ab66eb53bbb = []
        for _b2d99ad60a18 in _51d785c4609a(_64029770c040):
            _373474e0ab2b = _6f3e194095e3[_b2d99ad60a18]                    # (seq_len,)
            _ecb47692a678 = _9e3936b45ed0[_b2d99ad60a18]
            _26c544317cf4._b44262aeeb1d(_373474e0ab2b)
            _8ab66eb53bbb._b44262aeeb1d(_ecb47692a678)

        _2be583d3eafb = {
            "lang_codes": _6b5a6005954b,
            "preds": _26c544317cf4,
            "labels": _8ab66eb53bbb,
            "sample_ids": _167b54ad180a,
            "chunk_ids": _ad7e8fac28f6,
            "word_positions": _bcf1e4ddf6a6,
            "prompt_lens": _2077715b0576,
            "num_chunks": _eea3bab2327c,
        }

        self._07b26759c977._b44262aeeb1d(_2be583d3eafb)

        # Exact same cleanup as before
        del _0d00ddf3a705, _9e3936b45ed0, _6f3e194095e3, _26c544317cf4, _8ab66eb53bbb

        return _2be583d3eafb

    def _1fcf65c1b851(self):
        # pick correct device for this rank
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            if _0316ac5a2b74._bbc5d98781c5._0facdd3dae79():
                _b208a576d02d = _0316ac5a2b74._bbc5d98781c5._bcbacdd7718d()
            else:
                _b208a576d02d = 0
            _0316ac5a2b74._0b653ba58228._aee7e7ea6793(_b208a576d02d)
            self._bc4341c5ad90 = _0316ac5a2b74._de41be4d9bd9(f"cuda:{_b208a576d02d}")
        else:
            self._bc4341c5ad90 = _0316ac5a2b74._de41be4d9bd9("cpu")

        self._df193b647ac7()
        
    def _b31b8732e4e1(self):
        _6842d61eb3d2 = _4cfd48b7bf24(self, "_test_outputs", _2431e119344c)
        _650354848ff9(f"[DEBUG rank={_0316ac5a2b74._bbc5d98781c5._bcbacdd7718d()}] outputs_len={_ca4d7a12cacf(_6842d61eb3d2)}")
        if not _6842d61eb3d2:
            return

        _6b2a5138025f, _86f65696f17a, _f67c7c0735e8, _002f9baab13d = \
            self._3de3ff296b04(_6842d61eb3d2)

        _be4cb5dc1e15, _f1c71ecd8ad7 = [], []
        for _cac27fe58609 in _57dd3b64433a(_f67c7c0735e8._f86cca9e1852()):
            _22983bbd9567 = _6b2a5138025f[_cac27fe58609]._2edd1561e9cf()
            _c4e8637ae799 = _86f65696f17a[_cac27fe58609]._2edd1561e9cf()
            _9634f77a3774 = _f67c7c0735e8[_cac27fe58609]
            _4fbde69bf604 = _002f9baab13d[_cac27fe58609]

            if _9634f77a3774._379220d7f938() > 0 and _4fbde69bf604._379220d7f938() > 0:
                _be4cb5dc1e15._b44262aeeb1d(_9634f77a3774)
                _f1c71ecd8ad7._b44262aeeb1d(_4fbde69bf604)

        if not _be4cb5dc1e15:
            _650354848ff9("[TEST END] Nothing to score.")
            self._9f3e3737ebd3._8164957ef685()
            return

        _9e2f74ebc6ed = _0316ac5a2b74._5fce247fab28(_be4cb5dc1e15)._aba6dfc59e20(_de41be4d9bd9=self._0f84737e86d4['micro_accuracy']._de41be4d9bd9, _659b96787449=_4a8f86e6251f)
        _9e3936b45ed0 = _0316ac5a2b74._5fce247fab28(_f1c71ecd8ad7)._aba6dfc59e20(_de41be4d9bd9=self._0f84737e86d4['micro_accuracy']._de41be4d9bd9, _659b96787449=_4a8f86e6251f)

        self._0f84737e86d4['micro_accuracy']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_accuracy']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_precision']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_recall']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['macro_f1']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_accuracy']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_precision']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_recall']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['classwise_f1']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)
        self._0f84737e86d4['confmat']._f813da5eb123(_9e2f74ebc6ed, _9e3936b45ed0)

        _9cdb1d455f43  = self._0f84737e86d4['micro_accuracy']._4dafa01621fd()._48cf0a8157ce()
        _a8552cafb2c1  = self._0f84737e86d4['macro_accuracy']._4dafa01621fd()._48cf0a8157ce()
        _b9c26c039fa3 = self._0f84737e86d4['macro_precision']._4dafa01621fd()._48cf0a8157ce()
        _1f955521ee22    = self._0f84737e86d4['macro_recall']._4dafa01621fd()._48cf0a8157ce()
        _ea8339e29e0f        = self._0f84737e86d4['macro_f1']._4dafa01621fd()._48cf0a8157ce()

        self._fed9ef52fd44("test_accuracy", _a8552cafb2c1, _27441351ea79=_4a8f86e6251f)

        try:
            _a7ccf6991faf = self._b38eaf9e3f2a
            _baaeb5646e2c = {
                "epoch": [_a7ccf6991faf],
                "class_names": [self._abb73c99b2a7],
                "micro_accuracy": [_9cdb1d455f43],
                "macro_accuracy": [_a8552cafb2c1],
                "macro_precision": [_b9c26c039fa3],
                "macro_recall": [_1f955521ee22],
                "macro_f1": [_ea8339e29e0f],
                "classwise_accuracy": [self._0f84737e86d4['classwise_accuracy']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "classwise_precision": [self._0f84737e86d4['classwise_precision']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "classwise_recall": [self._0f84737e86d4['classwise_recall']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "classwise_f1": [self._0f84737e86d4['classwise_f1']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
                "confusion_matrix": [self._0f84737e86d4['confmat']._4dafa01621fd()._aba6dfc59e20(_de41be4d9bd9="cpu")._ac507d59111b()._2edd1561e9cf()],
            }
            self._3da545734d05(_baaeb5646e2c, f"test_final.csv", _6672ac0eca51=self._6672ac0eca51)
        except _50539114cf0b as _38d58eb6af52:
            _650354848ff9(f"[TEST END] save metrics FAILED: {_38d58eb6af52}")

        # cleanup
        self._0f84737e86d4['micro_accuracy']._9f2e6395c64e(); self._0f84737e86d4['macro_accuracy']._9f2e6395c64e()
        self._0f84737e86d4['macro_precision']._9f2e6395c64e(); self._0f84737e86d4['macro_recall']._9f2e6395c64e(); self._0f84737e86d4['macro_f1']._9f2e6395c64e()
        self._0f84737e86d4['classwise_accuracy']._9f2e6395c64e(); self._0f84737e86d4['classwise_precision']._9f2e6395c64e()
        self._0f84737e86d4['classwise_recall']._9f2e6395c64e(); self._0f84737e86d4['classwise_f1']._9f2e6395c64e()
        self._0f84737e86d4['confmat']._9f2e6395c64e(); self._9f3e3737ebd3._8164957ef685()
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            _0316ac5a2b74._0b653ba58228._7788b0243100()
        _650354848ff9("[TEST END] Finished and cleaned up.")

    def _3da940ebc10b(self, _28795a8da928, _641063c9ab19, _8380fda4e18f=0):
        """Optimized prediction step with efficient memory handling."""
        _0d00ddf3a705, _ = _28795a8da928
        _0d00ddf3a705 = _0d00ddf3a705._aba6dfc59e20(self._bc4341c5ad90, _659b96787449=_4a8f86e6251f)
        _6842d61eb3d2, _, _ = self(_0d00ddf3a705)
        _ee7003bdfbb3 = _0316ac5a2b74._78e0495107e7(_6842d61eb3d2, _fd99d22dec2b=-1)
        del _0d00ddf3a705, _6842d61eb3d2
        if _0316ac5a2b74._0b653ba58228._66436d6c2198():
            _0316ac5a2b74._0b653ba58228._7788b0243100()
        return {"predictions": _ee7003bdfbb3._53cb3759802b()}

    def _ced75f894595(self, _6842d61eb3d2, _b9459c431942=_4a8f86e6251f, _f948a4c9d4aa="cpu"):
        from collections import _90871b787201, _a9d3c2dd8dce
        import _0316ac5a2b74
        _ee4d70a2e212 = self._531e8940e841
        def _f98d3573eee9(_1aaa11a79046):
            if _38e8db554ad0(_1aaa11a79046, _0316ac5a2b74._4b8e10258290): return _1aaa11a79046._b6827c62d41e()._aba6dfc59e20(_de41be4d9bd9=_f948a4c9d4aa, _659b96787449=_4a8f86e6251f)._a10de2b49693(-1)._2edd1561e9cf()
            return _79ec9ef38482(_1aaa11a79046) if _38e8db554ad0(_1aaa11a79046, (_79ec9ef38482, _1dbbb848faf7)) else [_1aaa11a79046]
        
        _7097542b488f = _ba14ef38b43a()
        _6b2a5138025f, _86f65696f17a, _b765f4850990 = {}, {}, []
        if _b9459c431942:
            _650354848ff9(f"[reconcile] start: num_outputs={_ca4d7a12cacf(_6842d61eb3d2)}")
        

        _650354848ff9(f"[DEBUG rank={_0316ac5a2b74._bbc5d98781c5._bcbacdd7718d()}] Before reconcile missing sample_ids={[_cac27fe58609 for _cac27fe58609 in _51d785c4609a(0 if _0316ac5a2b74._bbc5d98781c5._bcbacdd7718d() == 0 else 637, 637 if _0316ac5a2b74._bbc5d98781c5._bcbacdd7718d() == 0 else 1274) if _cac27fe58609 not in _ba14ef38b43a(_cac27fe58609 for _72fa095b293f in _6842d61eb3d2 for _cac27fe58609 in _72fa095b293f._7241eb800c5f('sample_ids', []))]}")
        for _72fa095b293f in _6842d61eb3d2:
            _167b54ad180a     = _72fa095b293f["sample_ids"]
            _ad7e8fac28f6      = _72fa095b293f["chunk_ids"]
            _c163a5abbdbc    = _72fa095b293f["preds"]
            _635322bae3d2   = _72fa095b293f["labels"]
            _bcf1e4ddf6a6 = _72fa095b293f["word_positions"]
            _2077715b0576 = _72fa095b293f["prompt_lens"]
            _f387f5d0532e = _72fa095b293f["num_chunks"]

            for _b2d99ad60a18, _cac27fe58609 in _a3851d993417(_167b54ad180a):
                _73073f258894 = _3ee47612a58e(_ad7e8fac28f6[_b2d99ad60a18])

                if (_cac27fe58609, _73073f258894) in _7097542b488f:
                    continue
                _7097542b488f._cfc6f760160f((_cac27fe58609, _73073f258894))

                _3e954d92949a = _3ee47612a58e(_2077715b0576[_b2d99ad60a18])
                _7ab32d19fe49 = _c1172243b6fb(_bcf1e4ddf6a6[_b2d99ad60a18])
                _8ab4b048e188 = self._00086b57250f
                # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
                _6ca3c4d8b2a6  = _c1172243b6fb(_c163a5abbdbc[_b2d99ad60a18])
                _ab9f26d6e1b3 = _c1172243b6fb(_635322bae3d2[_b2d99ad60a18])

                # If preds are shorter than labels, they are generation-only (test)
                if _ca4d7a12cacf(_6ca3c4d8b2a6) < _ca4d7a12cacf(_ab9f26d6e1b3):
                    _54af89b963bb  = _6ca3c4d8b2a6
                    _892a2ec7af0c = _ab9f26d6e1b3[_3e954d92949a:]
                else:
                    _54af89b963bb  = _6ca3c4d8b2a6[_3e954d92949a:]
                    _892a2ec7af0c = _ab9f26d6e1b3[_3e954d92949a:]
                if _cac27fe58609 not in _b765f4850990:
                    _b765f4850990._b44262aeeb1d(_cac27fe58609)

                if 'chunks_by_sid' not in _b59fe73f6d46():
                    _c99c95682352 = _90871b787201(_79ec9ef38482)
                _c99c95682352[_cac27fe58609]._b44262aeeb1d((_73073f258894, _7ab32d19fe49, _54af89b963bb, _892a2ec7af0c))
            
        _c89d0e7399df = _2431e119344c
        _b208a576d02d = _0316ac5a2b74._bbc5d98781c5._bcbacdd7718d() if _0316ac5a2b74._bbc5d98781c5._0facdd3dae79() else 0
        _650354848ff9(f"[DEBUG rank={_0316ac5a2b74._bbc5d98781c5._bcbacdd7718d()}] Missing sample_ids={[_cac27fe58609 for _cac27fe58609 in _51d785c4609a(0 if _0316ac5a2b74._bbc5d98781c5._bcbacdd7718d() == 0 else 637, 637 if _0316ac5a2b74._bbc5d98781c5._bcbacdd7718d() == 0 else 1274) if _cac27fe58609 not in _b765f4850990]}")
        for _cac27fe58609 in _b765f4850990:
            _725d3b6fbf64 = _c99c95682352[_cac27fe58609]
            _650354848ff9(f"[WARN] Rank {_b208a576d02d} Missing chunks sample_id={_cac27fe58609}, missing {_72fa095b293f['num_chunks'][_b2d99ad60a18] - _ca4d7a12cacf(_725d3b6fbf64)} chunks") if _ce3400912625(_72fa095b293f['sample_ids'][_b2d99ad60a18] == _cac27fe58609 and _72fa095b293f['num_chunks'][_b2d99ad60a18] > _ca4d7a12cacf(_725d3b6fbf64) for _72fa095b293f in _6842d61eb3d2 for _b2d99ad60a18 in _51d785c4609a(_ca4d7a12cacf(_72fa095b293f['sample_ids']))) else _2431e119344c
            if _c89d0e7399df is _2431e119344c and _ca4d7a12cacf(_725d3b6fbf64) > 1:
                _c89d0e7399df = _cac27fe58609
            _725d3b6fbf64._63564ce31053(_bdc99671525e=lambda _1aaa11a79046: _1aaa11a79046[0])
            _e8040aef597c = _90871b787201(_79ec9ef38482)
            _29fe20d7fe67 = _90871b787201(_79ec9ef38482)
            _6d8276f01d8d = _90871b787201(_79ec9ef38482)
            _4323fef27c10 = _90871b787201(_79ec9ef38482)
            for _73073f258894, _39b15841f5e4, _9e2f74ebc6ed, _9e3936b45ed0 in _725d3b6fbf64:
                _a061e37570ea = {}
                _d46b2181ce67 = {}
                _0a382739cecc = _2431e119344c
                _04f28812f886 = []
                _696f98b90b22 = []
                for _9c8f12f85752, _63acb5e2345a, _492679e9796e in _f8dda0191362(_39b15841f5e4, _9e2f74ebc6ed, _9e3936b45ed0):
                    _01573850f918 = _3ee47612a58e(_9c8f12f85752)
                    if _01573850f918 >= 0:
                        if _01573850f918 != _0a382739cecc:
                            if _0a382739cecc is not _2431e119344c:
                                _a061e37570ea[_0a382739cecc] = _04f28812f886[:]
                                _d46b2181ce67[_0a382739cecc] = _696f98b90b22[:]
                            _0a382739cecc = _01573850f918
                            _04f28812f886 = [_3ee47612a58e(_63acb5e2345a)]
                            _696f98b90b22 = [_3ee47612a58e(_492679e9796e)]
                        else:
                            _04f28812f886._b44262aeeb1d(_3ee47612a58e(_63acb5e2345a))
                            _696f98b90b22._b44262aeeb1d(_3ee47612a58e(_492679e9796e))
                    else:
                        if _0a382739cecc is not _2431e119344c:
                            _29fe20d7fe67[_0a382739cecc]._b44262aeeb1d(_3ee47612a58e(_63acb5e2345a))
                            _4323fef27c10[_0a382739cecc]._b44262aeeb1d(_3ee47612a58e(_492679e9796e))
                if _0a382739cecc is not _2431e119344c:
                    _a061e37570ea[_0a382739cecc] = _04f28812f886[:]
                    _d46b2181ce67[_0a382739cecc] = _696f98b90b22[:]
                for _2bdd634ea3a8, _9a40d1afd184 in _a061e37570ea._5d0c1d058390():
                    _e8040aef597c[_2bdd634ea3a8]._b44262aeeb1d(_9a40d1afd184)
                    _6d8276f01d8d[_2bdd634ea3a8]._b44262aeeb1d(_d46b2181ce67[_2bdd634ea3a8])
            if not _e8040aef597c:
                continue
            _8abe75b22c6d = _0f437448fea0(_e8040aef597c._f86cca9e1852())
            _7508b34c643f = []
            _4707d0bd4017 = []
            _ed851d101335 = _06de5987f0f4((_2642c329142a[0] for _2642c329142a, _a5232f1dc605 in self._db29576ae0c7._5d0c1d058390() if _a5232f1dc605 == 0), 3200)
            for _2bdd634ea3a8 in _57dd3b64433a(_e8040aef597c._f86cca9e1852()):
                _6e91c28e33fd = _e8040aef597c[_2bdd634ea3a8]
                _8a35f9808303 = _6d8276f01d8d[_2bdd634ea3a8]
                _ec81866a559c = _ca4d7a12cacf(_8a35f9808303[0])
                _311514f86e42 = []
                for _6526f9872d80 in _51d785c4609a(_ec81866a559c):
                    _9b2847c4cb0d = [_fde4d11333de[_6526f9872d80] for _fde4d11333de in _6e91c28e33fd if _6526f9872d80 < _ca4d7a12cacf(_fde4d11333de)]
                    while _ca4d7a12cacf(_9b2847c4cb0d) < _ca4d7a12cacf(_8a35f9808303):
                        _9b2847c4cb0d._b44262aeeb1d(_ed851d101335)
                    _e954fb29d159 = _a9d3c2dd8dce(_9b2847c4cb0d)._8f1618a0fe0a(1)[0][0]
                    _311514f86e42._b44262aeeb1d(_e954fb29d159)
                _7508b34c643f._0d69e8805766(_311514f86e42[:_ec81866a559c])
                _8c32ce612ccf = []
                for _6526f9872d80 in _51d785c4609a(_ec81866a559c):
                    _9b2847c4cb0d = [_fde4d11333de[_6526f9872d80] for _fde4d11333de in _8a35f9808303]
                    _e954fb29d159 = _a9d3c2dd8dce(_9b2847c4cb0d)._8f1618a0fe0a(1)[0][0]
                    _8c32ce612ccf._b44262aeeb1d(_e954fb29d159)
                _4707d0bd4017._0d69e8805766(_8c32ce612ccf)
                if _2bdd634ea3a8 < _8abe75b22c6d:
                    _d0d29666dee7 = _29fe20d7fe67[_2bdd634ea3a8]
                    if _d0d29666dee7:
                        _4e6e8997af87 = _a9d3c2dd8dce(_d0d29666dee7)._8f1618a0fe0a(1)[0][0]
                        _7508b34c643f._b44262aeeb1d(_4e6e8997af87)
                    _feb89cf32e96 = _4323fef27c10[_2bdd634ea3a8]
                    if _feb89cf32e96:
                        _d4002641dca3 = _a9d3c2dd8dce(_feb89cf32e96)._8f1618a0fe0a(1)[0][0]
                        _4707d0bd4017._b44262aeeb1d(_d4002641dca3)
                    else:
                        _4707d0bd4017._b44262aeeb1d(self._781dbdeb872d)
                        _7508b34c643f._b44262aeeb1d(self._781dbdeb872d)
            _ed851d101335 = _06de5987f0f4((_2642c329142a[0] for _2642c329142a, _a5232f1dc605 in self._db29576ae0c7._5d0c1d058390() if _a5232f1dc605 == 0), 3200)
            _6595b954fb3e = _c3dc0238bdc6(1 for _b2d99ad60a18, _1aaa11a79046 in _a3851d993417(_4707d0bd4017) if _1aaa11a79046 != self._781dbdeb872d and (_b2d99ad60a18 == 0 or _4707d0bd4017[_b2d99ad60a18-1] == self._781dbdeb872d))
            _08d5ada988d7 = _c3dc0238bdc6(1 for _b2d99ad60a18, _1aaa11a79046 in _a3851d993417(_7508b34c643f) if _1aaa11a79046 != self._781dbdeb872d and (_b2d99ad60a18 == 0 or _7508b34c643f[_b2d99ad60a18-1] == self._781dbdeb872d))
            if _08d5ada988d7 < _6595b954fb3e:
                for _ in _51d785c4609a(_08d5ada988d7, _6595b954fb3e):
                    if _ca4d7a12cacf(_7508b34c643f) > 0 and _7508b34c643f[-1] != self._781dbdeb872d:
                        _7508b34c643f._b44262aeeb1d(self._781dbdeb872d)
                    _7508b34c643f._b44262aeeb1d(_ed851d101335)
            elif _08d5ada988d7 > _6595b954fb3e:
                _a7f50af9e75d = []
                _bb8be72bf72f = 0
                for _b2d99ad60a18, _601da9576fa0 in _a3851d993417(_7508b34c643f):
                    if _601da9576fa0 != self._781dbdeb872d and (_b2d99ad60a18 == 0 or _7508b34c643f[_b2d99ad60a18-1] == self._781dbdeb872d):
                        _bb8be72bf72f += 1
                    if _bb8be72bf72f <= _6595b954fb3e:
                        _a7f50af9e75d._b44262aeeb1d(_601da9576fa0)
                    elif _601da9576fa0 == self._781dbdeb872d and _bb8be72bf72f == _6595b954fb3e:
                        _a7f50af9e75d._b44262aeeb1d(_601da9576fa0)
                        break
                _7508b34c643f = _a7f50af9e75d

            _6b2a5138025f[_cac27fe58609] = _0316ac5a2b74._5812e5c7334e(_7508b34c643f, _de41be4d9bd9=_f948a4c9d4aa)
            _86f65696f17a[_cac27fe58609] = _0316ac5a2b74._5812e5c7334e(_4707d0bd4017 if _4707d0bd4017 else [self._531e8940e841] * _ca4d7a12cacf(_7508b34c643f), _de41be4d9bd9=_f948a4c9d4aa)

        if _b9459c431942 and _c89d0e7399df:
            _650354848ff9(f"[SUMMARY] reconciled samples in batch = {_ca4d7a12cacf(_b765f4850990)} \
                  sid={_c89d0e7399df} total_preds={_ca4d7a12cacf(_6b2a5138025f[_c89d0e7399df])} total_labels={_ca4d7a12cacf(_86f65696f17a[_c89d0e7399df])} \
                    raw_preds {_6b2a5138025f[_c89d0e7399df]} and raw_labels{_86f65696f17a[_c89d0e7399df]}\
                        chunks {_c99c95682352[_c89d0e7399df]}")
        
        _948d6de0a21e, _b4948b4b71c5 = self._82443398d9ff(_6b2a5138025f, _86f65696f17a, _b9459c431942=_b9459c431942, _f948a4c9d4aa=_f948a4c9d4aa)
        
        if _b9459c431942 and _c89d0e7399df:
            _650354848ff9(f"After Overlay [DEBUG sid={_c89d0e7399df}] raw_preds={_6b2a5138025f[_c89d0e7399df]} and raw_labels={_86f65696f17a[_c89d0e7399df]} and preds={_948d6de0a21e[_c89d0e7399df]} and labels={_b4948b4b71c5[_c89d0e7399df]}")
        
        return _6b2a5138025f, _86f65696f17a, _948d6de0a21e, _b4948b4b71c5

    def _b68df34c4e49(self, _6b2a5138025f, _86f65696f17a, _b9459c431942=_4a8f86e6251f, _f948a4c9d4aa="cpu"):
        _db29576ae0c7 = _4cfd48b7bf24(self, "seq2class", {})
        _6adb287023a3 = _4cfd48b7bf24(self, "tokenizer_separator_token", _2431e119344c)
        _ee4d70a2e212 = _4cfd48b7bf24(self, "ignore_idx", -100)
        
        def _26103531c498(_e2267f22bb42, _8f3c50f395c5):
            _a117b8889bbc = []
            _0a382739cecc = []
            for _b2d99ad60a18, token in _a3851d993417(_e2267f22bb42):
                if token == _8f3c50f395c5 and _0a382739cecc:
                    _a117b8889bbc._b44262aeeb1d(_0a382739cecc)
                    _0a382739cecc = []
                elif token != _8f3c50f395c5:
                    _0a382739cecc._b44262aeeb1d(token)
            if _0a382739cecc:
                _a117b8889bbc._b44262aeeb1d(_0a382739cecc)
            return _a117b8889bbc
        
        def _6dbf6b945b1a(_c467a30aef3e, _db29576ae0c7, _b9459c431942, _cac27fe58609):
            _72fa095b293f = []
            _258442975f5f = _57dd3b64433a(_db29576ae0c7._f86cca9e1852(), _bdc99671525e=_ca4d7a12cacf, _88697f33c9b4=_4a8f86e6251f)
            for _b2d99ad60a18, _26eec6193a9f in _a3851d993417(_c467a30aef3e, 1):
                _4eaaefb1ccad = _1dbbb848faf7(_26eec6193a9f)
                _c8973388369c = self._4a8500cbaa22
                for _bdc99671525e in _258442975f5f:
                    if _ca4d7a12cacf(_4eaaefb1ccad) >= _ca4d7a12cacf(_bdc99671525e) and _4eaaefb1ccad[:_ca4d7a12cacf(_bdc99671525e)] == _bdc99671525e:
                        _c8973388369c = _db29576ae0c7[_bdc99671525e]
                        break
                _72fa095b293f._b44262aeeb1d(_c8973388369c)

            return _72fa095b293f
        
        _f67c7c0735e8, _002f9baab13d = {}, {}
        for _cac27fe58609 in _6b2a5138025f:
            _601da9576fa0 = _6b2a5138025f[_cac27fe58609]
            _4ec31a9b597c = _86f65696f17a._7241eb800c5f(_cac27fe58609, _2431e119344c)
            _9e2f74ebc6ed = _601da9576fa0._2edd1561e9cf() if _38e8db554ad0(_601da9576fa0, _0316ac5a2b74._4b8e10258290) else _79ec9ef38482(_601da9576fa0)
            _9e3936b45ed0 = _4ec31a9b597c._2edd1561e9cf() if _38e8db554ad0(_4ec31a9b597c, _0316ac5a2b74._4b8e10258290) else _79ec9ef38482(_4ec31a9b597c) if _4ec31a9b597c else _2431e119344c
            if _9e3936b45ed0 is not _2431e119344c:
                _6595b954fb3e = _67ea32d7414b(_9e3936b45ed0, _6adb287023a3)
                _014ed958f322 = _4e27752bf8fa(_6595b954fb3e, _db29576ae0c7, _cac27fe58609 == 1 or _b9459c431942, _cac27fe58609)
                _cb0510b2d0e2 = _67ea32d7414b(_9e2f74ebc6ed, _6adb287023a3)
                _5d915cbd1c58 = _4e27752bf8fa(_cb0510b2d0e2, _db29576ae0c7, _cac27fe58609 == 1 or _b9459c431942, _cac27fe58609)
                if _ca4d7a12cacf(_5d915cbd1c58) < _ca4d7a12cacf(_014ed958f322):
                    _5d915cbd1c58 += [0] * (_ca4d7a12cacf(_014ed958f322) - _ca4d7a12cacf(_5d915cbd1c58))
                elif _ca4d7a12cacf(_5d915cbd1c58) > _ca4d7a12cacf(_014ed958f322):
                    _5d915cbd1c58 = _5d915cbd1c58[:_ca4d7a12cacf(_014ed958f322)]
            else:
                _cb0510b2d0e2 = _67ea32d7414b(_9e2f74ebc6ed, _6adb287023a3)
                _5d915cbd1c58 = _4e27752bf8fa(_cb0510b2d0e2, _db29576ae0c7, _cac27fe58609 == 1 or _b9459c431942, _cac27fe58609)
                _014ed958f322 = [_ee4d70a2e212] * _ca4d7a12cacf(_5d915cbd1c58)
            _f67c7c0735e8[_cac27fe58609] = _0316ac5a2b74._5812e5c7334e(_5d915cbd1c58, _de41be4d9bd9=_f948a4c9d4aa, _56b5104fd8d1=_0316ac5a2b74._2bb7c287a5f5)
            _002f9baab13d[_cac27fe58609] = _0316ac5a2b74._5812e5c7334e(_014ed958f322, _de41be4d9bd9=_f948a4c9d4aa, _56b5104fd8d1=_0316ac5a2b74._2bb7c287a5f5)
        return _f67c7c0735e8, _002f9baab13d

    def _c522feb69a48(self, _69749d296508):
        _0316ac5a2b74._92d99dcbe74a._b0dc184429f8._999495dad463(self._203e3f83c27d(), _386db1a561e9=1.0)
    
    def _ccaa2774b984(self, _69749d296508):
        for _06a3a953f9f1 in self._203e3f83c27d():
            if _06a3a953f9f1 is not _2431e119344c:
                _06a3a953f9f1._6c442a7a6fd8._98be16b9b881(-5, 5)

    def _f7f38eb29780(self):
        _2fb7094c1487 = 0
        for _06a3a953f9f1 in self._203e3f83c27d():
            if _06a3a953f9f1._bd0b839d9df9 is not _2431e119344c:
                _7989b8c09264 = _06a3a953f9f1._bd0b839d9df9._b6827c62d41e()._6c442a7a6fd8._776491fc8ba6(2)
                _2fb7094c1487 += _7989b8c09264._48cf0a8157ce() ** 2
        return _2fb7094c1487 ** 0.5  # L2 norm

    def _bd7be9d47c01(self):
        _583df448a7d0 = [_601da9576fa0 for _601da9576fa0 in self._203e3f83c27d() if _601da9576fa0._22071fce29ba]
        if not _583df448a7d0:
            _650354848ff9("No trainable parameters. Skipping optimizer creation.")
            return _2431e119344c
        
        _8cc623541af7 = _0c337d2c4292(lambda _601da9576fa0: _601da9576fa0._22071fce29ba, self._203e3f83c27d())

        _6c75561e02d5 = {
            "adamw": _0316ac5a2b74._c7223e1b3091._01ca4427d573,
            "adamax": _0316ac5a2b74._c7223e1b3091._b226641f37cb,
            "adam": _0316ac5a2b74._c7223e1b3091._037849e01a7a,
        }
        _26d6c7bca05f = _6c75561e02d5._7241eb800c5f(self._09a3b6212085._d6efc2941ebf(), _0316ac5a2b74._c7223e1b3091._037849e01a7a)

        _69749d296508 = _26d6c7bca05f(_8cc623541af7, _5cc404bcfd3d=self._a050f175b47c._5cc404bcfd3d, _4b0bf5e46e4c=0.001)

        _56d30ec333f3 = self._a8339ddd0952._4f135671b19c
        _aea41445753d = math._3bb523cd1950(0.1 * _56d30ec333f3)

        _7ff68af53abe = _0316ac5a2b74._c7223e1b3091._79a872622c37._efe70f77787b(_69749d296508, _90b636c58855=lambda _46bdb9afee04: (_46bdb9afee04 + 1) / _aea41445753d)

        _364d4342a5d6 = _0316ac5a2b74._c7223e1b3091._79a872622c37._02e5161ecd19(
            _69749d296508,
            _7b15b133e004=_0f437448fea0(1, _56d30ec333f3 - _aea41445753d),
            _199ca407b026=2,
            _355cefe9a7ed=1e-6
        )
        _79a872622c37 = _0316ac5a2b74._c7223e1b3091._79a872622c37._397b27776c06(
            _69749d296508,
            _bd34f70d90e7=[_7ff68af53abe, _364d4342a5d6],
            _498c15e9abd1=[_aea41445753d]
        )
        return {"optimizer": _69749d296508, "lr_scheduler": {"scheduler": _79a872622c37, "interval": "epoch", "monitor": "val_loss"}}
