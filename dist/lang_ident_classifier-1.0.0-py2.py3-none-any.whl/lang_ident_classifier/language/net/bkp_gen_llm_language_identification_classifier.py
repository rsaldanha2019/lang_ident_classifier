# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _2a04b37f96c1
import copy
from _7c56efeb7744 import _61d7659bc88f
import _692b375dade2
import math
import os
from typing import _803e91eb97be
import _0ee37aaa65b6 as _b51c8673f055
import _c4cc964b30fc as _baffdc174071
import _6e39b26f9db2
import _e6245c646509 as _a7dfc6b6c179
from _cf3d9ed6dbda._91d96732c93b._6b8a73ffb073._6304a3085c55 import _4ef1531d7074
from _ce68961b7d8b import _baced92f376f, _67db7af15086, _3206ba251004, _a54d0ab8017e, _f41e01c2df9d

from _6849ba47c46c._a9e2c8f07c00._b1dd4ab7ea14._1d9e36b83707 import _44acd910c2a6
from _6849ba47c46c._a9e2c8f07c00._29e39cf605b0._715bc14ba8cd import _bed8442169f1
from _6849ba47c46c._a9e2c8f07c00._29e39cf605b0._b9980ffefdde import _d28794cab830
from _6849ba47c46c._a9e2c8f07c00._29e39cf605b0._b445f72b8833 import _35d29486c56d
from _6849ba47c46c._a9e2c8f07c00._57ee5d612c0f._15be7ef6f850 import _a3bfa0517661
# expose only the classifier from the module
_aac0ada8170f = ["GenLLMLanguageIdentificationClassifier"]

_973e68482c6b = 'cuda' if _6e39b26f9db2._f2f2c0372574._afa87b0ac178() else 'cpu'
_dc7f05032bea = _655b08c5fe91  # global frozen embedding (kept for compatibility)

class _88c654699f39(_a7dfc6b6c179._4db6c2312e7e):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _17b1006f6d4b(_6e39b26f9db2._c7b2c8b51ec0._a72ddb70a173):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _dae0a3c553e2(self, _473323112478: _b07597fe40e6, _b87dd459c4f3: _b07597fe40e6 = 64):
            _260e801f926b()._865fd2e19441()
            self._d98f1d9ff21d = _6e39b26f9db2._c7b2c8b51ec0._6baad3c0c85c(_473323112478, _b87dd459c4f3, _87ca723ce350=_e43b45db6833)
            self._b18bbdbb7a54 = _6e39b26f9db2._c7b2c8b51ec0._7266c80a92f7(_3471bd45f5c1=_b44310a17910)
            self._90edbb2ed648 = _6e39b26f9db2._c7b2c8b51ec0._6baad3c0c85c(_b87dd459c4f3, _473323112478, _87ca723ce350=_e43b45db6833)
            # start adapter near-zero so initial behavior is identity
            _6e39b26f9db2._c7b2c8b51ec0._88eb5e01231c._6d4f68a6f15d(self._90edbb2ed648._43f72da4b074)
            _6e39b26f9db2._c7b2c8b51ec0._88eb5e01231c._aaa65b78a942(self._d98f1d9ff21d._43f72da4b074, _e2495497034f=math._5f68d44b49d0(5))

        def _bac304b2bdba(self, _87de3915be94: _6e39b26f9db2._a3e1f82651b2) -> _6e39b26f9db2._a3e1f82651b2:
            # supports x shape (B, L, D) or (B, D)
            if _87de3915be94._473323112478() == 2:
                _7d35ac0118df = self._90edbb2ed648(self._b18bbdbb7a54(self._d98f1d9ff21d(_87de3915be94)))
                return _87de3915be94 + _7d35ac0118df
            _f3ccda38dfcc, _ca5d1268986c, _759ea3f2724d = _87de3915be94._c3536ba3afe1
            _3992af846ce9 = _87de3915be94._5a048acf0558(-1, _759ea3f2724d)                    # (B*L, D)
            _3992af846ce9 = self._90edbb2ed648(self._b18bbdbb7a54(self._d98f1d9ff21d(_3992af846ce9)))  # (B*L, D)
            _3992af846ce9 = _3992af846ce9._5a048acf0558(_f3ccda38dfcc, _ca5d1268986c, _759ea3f2724d)
            return _87de3915be94 + _3992af846ce9
        
    class _c4b759c647ba(_6e39b26f9db2._c7b2c8b51ec0._a72ddb70a173):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _dae0a3c553e2(self, _cc4afa884e4d, _b8c56f97c746=-5, _9640816031c6=5):
            _260e801f926b()._865fd2e19441()
            self._cc4afa884e4d = _cc4afa884e4d
            self._b8c56f97c746 = _b8c56f97c746
            self._9640816031c6 = _9640816031c6
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _bac304b2bdba(self, *_6272766c57b5, **_7eb2a2744739):
            _6272766c57b5 = _28695ff1c377(
                _913124d81f61._252728105cf7(_6e39b26f9db2._e29a06b2dd79)._3b49e250c2f2(-10, 10) if _6c54eb2d93e5(_913124d81f61, _6e39b26f9db2._a3e1f82651b2) and _913124d81f61._81eae2d9aed2 != _6e39b26f9db2._e29a06b2dd79 else _913124d81f61
                for _913124d81f61 in _6272766c57b5
            )
            for _9f1f0400de82, _913124d81f61 in _672aea193df6(_6272766c57b5):
                if _6c54eb2d93e5(_913124d81f61, _6e39b26f9db2._a3e1f82651b2) and not _6e39b26f9db2._31a0514d09d7(_913124d81f61)._0f35b2c66d14():
                    _913124d81f61 = _6e39b26f9db2._d52dec04a996(_913124d81f61)
            _9d77ebf27b7a = self._cc4afa884e4d(*_6272766c57b5, **_7eb2a2744739)
            if _6c54eb2d93e5(_9d77ebf27b7a, _6e39b26f9db2._a3e1f82651b2):
                _9d77ebf27b7a = _9d77ebf27b7a._252728105cf7(_6e39b26f9db2._e29a06b2dd79)
                if not _6e39b26f9db2._31a0514d09d7(_9d77ebf27b7a)._0f35b2c66d14():
                    _9d77ebf27b7a = _6e39b26f9db2._d52dec04a996(_9d77ebf27b7a)
                _9d77ebf27b7a._ce3d15796970(self._b8c56f97c746, self._9640816031c6)
            return _9d77ebf27b7a

    # --- original __init__ signature and body preserved ---
    def _dae0a3c553e2(
        self,
        _d7112363a049,
        _b34ef133a4a3,
        _447d9ad9ed6d,
        _445776b06522,
        _502afeef627f,
        _5771a15e400d,
        _d309e5a7f823,
        _1031990848c5,
        _c999d4074fbf,
        _efb3b07b4eef,
        _44d3b23ab51a,
        _1b28145a36c6: _b07597fe40e6 = 20,
        _ad59c3dd3e14 = _655b08c5fe91,
        _9631de5fbe65=_655b08c5fe91,
        _5d0483672c35=0.9,
        _7458dd3c6550:_467e81bbd7c5=_655b08c5fe91,
    ):
        _260e801f926b(_2b21f1897235, self)._865fd2e19441()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._0b2dd95fc53e({
            "lr": _956c71aa394b(_447d9ad9ed6d),
            "optimizer": _467e81bbd7c5(_445776b06522),
            "num_backbone_model_units_unfrozen": _b07597fe40e6(_d309e5a7f823),
            "loss_type": _467e81bbd7c5(_1031990848c5),
            "is_train": _e4a9bac68222(_c999d4074fbf),
            "random_seed": _b07597fe40e6(_1b28145a36c6),
        })
        self._1b28145a36c6 = _1b28145a36c6
        _a7dfc6b6c179._2e7895a2dd35(_1b28145a36c6, _2ff8830b371d=_b44310a17910)
        _6e39b26f9db2._491cf56fb968(_1b28145a36c6)
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            _6e39b26f9db2._f2f2c0372574._c846a8d0e064(_1b28145a36c6)
        _b51c8673f055.random._235e078c9090(_1b28145a36c6)
        self._9631de5fbe65 = _b07597fe40e6(_9631de5fbe65) if _9631de5fbe65 is not _655b08c5fe91 else _655b08c5fe91
        self._efb3b07b4eef = _efb3b07b4eef
        self._7458dd3c6550 = _7458dd3c6550
        # TODO: REMOVE THIS HARDCODING
        if not self._efb3b07b4eef._c4c30b80c075:
            self._efb3b07b4eef._c4c30b80c075 = 128004  # <|finetune_right_pad_id|>
        self._45cb1054b80e = _efb3b07b4eef._24694c18102b(" ", _48d314c775d7=_e43b45db6833)[0]
        self._de96aab61a3b = (
            _6e39b26f9db2._fcfd22e4e02c("cuda:{}"._647a15ea19d3(_5771a15e400d["gpu_local_rank"]))
            if _5771a15e400d["gpu_local_rank"] != -1
            else "cpu"
        )
        self._ad59c3dd3e14 = _ad59c3dd3e14
        self._86b43168b304 = _94a0187a3088(_b34ef133a4a3)
        self._5d0483672c35 = _5d0483672c35
        self._b34ef133a4a3 =  ["unk"] + _b34ef133a4a3 if self._5d0483672c35 > 0 else _b34ef133a4a3
        self._8abe358ca073 = {}
        for _a5d9ad9db5f7, _596d5523061c in _672aea193df6(self._b34ef133a4a3):
            _5726e47e301c = self._efb3b07b4eef._24694c18102b(_596d5523061c, _48d314c775d7=_e43b45db6833)
            self._8abe358ca073[_a5d9ad9db5f7] = _5726e47e301c
        self._222a93604bd8 = {_28695ff1c377(_5726e47e301c): _e6666c68f6f7 for _e6666c68f6f7, _5726e47e301c in self._8abe358ca073._9d8323b24593()}
        self._b6343d92e0fe = _2a04b37f96c1(_f46b8b43bca0)
        for _a8e75843f91f, _5726e47e301c in self._8abe358ca073._9d8323b24593():
            self._b6343d92e0fe[_94a0187a3088(_5726e47e301c)]._683f9fc99221((_a8e75843f91f, _5726e47e301c))
        self._3cc38e23ecb3 = 0
        _148e1ad1b78f(f"SEQ {self._8abe358ca073} and {self._222a93604bd8}")
        self._88093c4aa9de = _efb3b07b4eef._c4c30b80c075 or _efb3b07b4eef._951f6a9e7564
        self._502afeef627f = _502afeef627f
        self._2fb631f9cdac = "multiclass"
        self._ea33d091fa73 = -100
        self._21112401c1a6 = _efb3b07b4eef._24694c18102b("assistant<|end_header_id|>\n\n", _48d314c775d7=_e43b45db6833)
        self._16de4fa7815b = self._ee73a6f7ee4f()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._6b5c02afcdb8 = _d7112363a049
        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._6b5c02afcdb8._e06e36777e79(_e43b45db6833)
        _5ca53aaf1c6b = _a3bfa0517661()  # bfloat16 or float16

        for _5a89f7a420ca, _cc4afa884e4d in self._6c8d9eb9f12d():
            if not _0b0aa9575f71(_bfddf5bc912b._a151831100b0 for _bfddf5bc912b in _cc4afa884e4d._dbf7aaa35281(_632e9edde060=_e43b45db6833)):
                # FROZEN → BF16 (save memory)
                _cc4afa884e4d._252728105cf7(_81eae2d9aed2=_5ca53aaf1c6b)
            else:
                # TRAINABLE → FP32 (stable grads)
                _cc4afa884e4d._252728105cf7(_81eae2d9aed2=_6e39b26f9db2._e29a06b2dd79)
        self._6b5c02afcdb8._252728105cf7(self._de96aab61a3b)
        if _e9d210600695(self._6b5c02afcdb8, "gradient_checkpointing_enable"):
            self._6b5c02afcdb8._5f6e517dcf55()
        # determine embedding dim robustly from model config if available
        _5672acfa1739 = _adebc65e1a18(_adebc65e1a18(self._6b5c02afcdb8, "config", _655b08c5fe91), "hidden_size", _655b08c5fe91)
        if _5672acfa1739 is _655b08c5fe91:
            # fallback to common default — change if your model uses a different hidden size
            _5672acfa1739 = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _e9d210600695(self._6b5c02afcdb8, "lm_head") and _adebc65e1a18(self._6b5c02afcdb8, "lm_head") is not _655b08c5fe91:
            self._d193a92a8d98 = self._6b5c02afcdb8._ebf9587ba3b4
        else:
            _283c7dbfb818 = _adebc65e1a18(self._6b5c02afcdb8, "get_output_embeddings", _655b08c5fe91)
            self._d193a92a8d98 = _283c7dbfb818() if _0b2da1f294a5(_283c7dbfb818) else _655b08c5fe91

        # mark presence and ensure module (if any) is on the same device
        self._643b2e84f51b = self._d193a92a8d98 is not _655b08c5fe91
        if self._643b2e84f51b:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._d193a92a8d98._252728105cf7(self._de96aab61a3b)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._e8e8fd469240 = self._1fde1cf0de0b(_473323112478=_5672acfa1739, _b87dd459c4f3=64)
        self._e8e8fd469240._252728105cf7(self._de96aab61a3b)
        for _bfddf5bc912b in self._e8e8fd469240._dbf7aaa35281():
            _bfddf5bc912b._a151831100b0 = _b44310a17910
            
        if _d309e5a7f823 > 0:
            if "llama" in self._ad59c3dd3e14:
                for _69235d344bab in self._6b5c02afcdb8._dbf7aaa35281():
                    if not _69235d344bab._f5e174160843:
                        _69235d344bab = _69235d344bab._e13d37e5c6e0()
                    _69235d344bab._a151831100b0 = _e43b45db6833  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _4080e9c04efe = self._6b5c02afcdb8._9bc16666971d._675473d35934  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _5d4ca91ca7a4 in _4080e9c04efe[-_d309e5a7f823:]:
                    for _69235d344bab in _5d4ca91ca7a4._dbf7aaa35281():
                        if _6c54eb2d93e5(_69235d344bab, _6e39b26f9db2._a3e1f82651b2) and (_69235d344bab._03972f5e1ec7() or _6e39b26f9db2._2c61e0837bf5(_69235d344bab)):
                            _69235d344bab._a151831100b0 = _b44310a17910
                if _e9d210600695(self._6b5c02afcdb8, "lm_head"):
                    self._6b5c02afcdb8._ebf9587ba3b4._a151831100b0 = _b44310a17910

        self._b9bd0854bb44 = 1
        _148e1ad1b78f(f"DEBUG xth_batch init {self._b9bd0854bb44}")
        global _dc7f05032bea
        _dc7f05032bea = copy._d360547233e9(self._6b5c02afcdb8)._27870deb6f05()
        self._447d9ad9ed6d = _447d9ad9ed6d

        self._665ffedda66b = {}
        self._545c9449977d = {}

        # Loss function initialization
        if _1031990848c5._504048a1b38c() == "class_weighted_cross_entropy_loss":
            self._545c9449977d['criterion'] = _d28794cab830(_502afeef627f=self._502afeef627f,
                                                            _fcfd22e4e02c=self._de96aab61a3b,
                                                            _9640075cbece=self._ea33d091fa73,
                                                            _8160d397d169=self._45cb1054b80e)
        elif _1031990848c5._504048a1b38c() == "focal_loss":
            self._545c9449977d['criterion'] = _35d29486c56d(_98ab4fbdf6f9=0.25,
                                                     _fcfd22e4e02c=self._de96aab61a3b,
                                                     _9640075cbece=self._ea33d091fa73,
                                                     _8160d397d169=self._45cb1054b80e)
        elif _1031990848c5._504048a1b38c() == "class_weighted_focal_loss":
            self._545c9449977d['criterion'] = _35d29486c56d(_98ab4fbdf6f9=self._502afeef627f,
                                                     _fcfd22e4e02c=self._de96aab61a3b,
                                                     _9640075cbece=self._ea33d091fa73,
                                                     _8160d397d169=self._45cb1054b80e)
        elif _1031990848c5._504048a1b38c() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._545c9449977d['criterion'] = _bed8442169f1(_98ab4fbdf6f9=self._502afeef627f,
                                                                      _7c94db6fa9ae='type1',
                                                                      _fcfd22e4e02c=self._de96aab61a3b,
                                                                      _9640075cbece=self._ea33d091fa73,
                                                                      _8160d397d169=self._45cb1054b80e)
        elif _1031990848c5._504048a1b38c() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._545c9449977d['criterion'] = _bed8442169f1(_98ab4fbdf6f9=self._502afeef627f,
                                                                      _7c94db6fa9ae='type2',
                                                                      _fcfd22e4e02c=self._de96aab61a3b,
                                                                      _9640075cbece=self._ea33d091fa73,
                                                                      _8160d397d169=self._45cb1054b80e)
        elif _1031990848c5._504048a1b38c() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._545c9449977d['criterion'] = _bed8442169f1(_98ab4fbdf6f9=self._502afeef627f,
                                                                      _7c94db6fa9ae='type3',
                                                                      _fcfd22e4e02c=self._de96aab61a3b,
                                                                      _9640075cbece=self._ea33d091fa73,
                                                                      _8160d397d169=self._45cb1054b80e)
        else:
            self._545c9449977d['criterion'] = _d28794cab830(_fcfd22e4e02c=self._de96aab61a3b,
                                                            _9640075cbece=self._ea33d091fa73,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._9bbbc56a6d34 = 0.99
        self._c50036ebc47b = 0.3
        self._d3c781c4928b = 0.30
        self._51a1a8ef2da5 = 0.25
        self._badecb508e83 = 0.6
        self._b326fd9f8986 = 0.995
        self._cd252d1b60ae = 0.60
        self._1acc80cbc710 = 0.20
        self._ca795310af89 = _adebc65e1a18(self, "batch_counter", 0)


        self._86fa72d9ca61 = []
        self._7897c7f3d9c8 = []

        self._88636f00f7f4 = _445776b06522._504048a1b38c()
        self._34716902c115()

        self._4cb1e18e80d0(self._6b5c02afcdb8)
    
    def _b34bfeabc763(self):
        # rebuild all metrics on the correct device
        self._665ffedda66b['micro_accuracy'] = _baced92f376f(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1="micro",
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['macro_accuracy'] = _baced92f376f(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1="macro",
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['macro_precision'] = _3206ba251004(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1="macro",
            _8650b1dfe3b1=self. _2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['macro_recall'] = _a54d0ab8017e(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1="macro",
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['macro_f1'] = _f41e01c2df9d(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1="macro",
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['classwise_accuracy'] = _baced92f376f(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1=_655b08c5fe91,
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['classwise_precision'] = _3206ba251004(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1=_655b08c5fe91,
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['classwise_recall'] = _a54d0ab8017e(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1=_655b08c5fe91,
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['classwise_f1'] = _f41e01c2df9d(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _1b522e5e64d1=_655b08c5fe91,
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)

        self._665ffedda66b['confmat'] = _67db7af15086(
            _86b43168b304=_94a0187a3088(self._b34ef133a4a3),
            _8650b1dfe3b1=self._2fb631f9cdac,
            _9640075cbece=self._ea33d091fa73,
        )._252728105cf7(self._de96aab61a3b)


    def _04016f30f824(self, _5a79cc94c5f6=_655b08c5fe91):
        """Calculate batch counts and set xth_batch_to_consider."""
        _6b482ab3a871 = 0
        _1a41428185ea = 0
        if self._b5d64b644f3a._e81dd0e3e042 is not _655b08c5fe91:
            if _e9d210600695(self._b5d64b644f3a._e81dd0e3e042, 'train_dataset') and self._b5d64b644f3a._e81dd0e3e042._3b2bf234abf6 is not _655b08c5fe91:
                _6b482ab3a871 = _94a0187a3088(self._b5d64b644f3a._e81dd0e3e042._3b2bf234abf6)
            if _e9d210600695(self._b5d64b644f3a._e81dd0e3e042, 'val_dataset') and self._b5d64b644f3a._e81dd0e3e042._fc83ae2b93c1 is not _655b08c5fe91:
                _1a41428185ea = _94a0187a3088(self._b5d64b644f3a._e81dd0e3e042._fc83ae2b93c1)
            _a787c83eb64c = self._b5d64b644f3a._e81dd0e3e042._a787c83eb64c
            _fc8a515df64c = (_6b482ab3a871 + _a787c83eb64c - 1) // _a787c83eb64c if _6b482ab3a871 > 0 else 1
            _26c91abeedad = (_1a41428185ea + _a787c83eb64c - 1) // _a787c83eb64c if _1a41428185ea > 0 else 1
            _2b66a353794c = _257619fd0651(_fc8a515df64c, _26c91abeedad) if _1a41428185ea > 0 else _fc8a515df64c
            _8668a2a35861 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._b9bd0854bb44 = 1
            _148e1ad1b78f(f"DEBUG Batch Info: num_train_batches={_fc8a515df64c}, num_val_batches={_26c91abeedad}, xth_batch_to_consider={self._b9bd0854bb44}")

    def _5f0ff83bc747(self, _dfcce2a8fd80, _e389be83eec4):
        if _dfcce2a8fd80._504048a1b38c() == "parametric_relu":
            return _6e39b26f9db2._c7b2c8b51ec0._a6378d96d992(_e389be83eec4=1)
        elif _dfcce2a8fd80._504048a1b38c() == "leaky_relu":
            return _6e39b26f9db2._c7b2c8b51ec0._da5df131643b(_3471bd45f5c1=_e43b45db6833)
        else:
            return _6e39b26f9db2._c7b2c8b51ec0._7266c80a92f7(_3471bd45f5c1=_e43b45db6833)

    def _e16b29cc8193(self, _cc4afa884e4d, _d7fb8348c97e=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _5a89f7a420ca, _54620af0016c in _cc4afa884e4d._8e413e8ea974():
            _6034d7aa9e4b = f"{_d7fb8348c97e}.{_5a89f7a420ca}" if _d7fb8348c97e else _5a89f7a420ca

            def _bcacd410e163(_aed2e026f47e, _913124d81f61, _7d35ac0118df):
                if _6c54eb2d93e5(_7d35ac0118df, _6e39b26f9db2._a3e1f82651b2) and _7d35ac0118df._f6e606e6fc0f()._0b0aa9575f71():
                    _148e1ad1b78f(f"NaN detected in {_6034d7aa9e4b} ({_aed2e026f47e._fc3e34fca93a.__name__}) ({_7d35ac0118df._81eae2d9aed2})")

            _54620af0016c._398f67d8553f(_7b00964fe434)

            self._4cb1e18e80d0(_54620af0016c, _6034d7aa9e4b)

    def _1cb037e5328b(self, _cc4afa884e4d):
        return _0b0aa9575f71(_bfddf5bc912b._a151831100b0 for _bfddf5bc912b in _cc4afa884e4d._dbf7aaa35281())

    def _6b75b6d85541(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _e39c50b08e82 = []
        for _5a89f7a420ca, _cc4afa884e4d in self._6c8d9eb9f12d():
            if not self._08078fdb540a(_cc4afa884e4d):
                continue
            _b2cfce704fb2 = (
                "norm" in _5a89f7a420ca._da3fb4666307() or 
                "linear4bit" in _5a89f7a420ca._da3fb4666307() or 
                _0b0aa9575f71(_b18bbdbb7a54 in _5a89f7a420ca._da3fb4666307() for _b18bbdbb7a54 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _5a89f7a420ca._da3fb4666307() or 
                "dropout" in _5a89f7a420ca._da3fb4666307() or 
                _6c54eb2d93e5(_cc4afa884e4d, (_4ef1531d7074, _6e39b26f9db2._c7b2c8b51ec0._6baad3c0c85c, _6e39b26f9db2._c7b2c8b51ec0._0b3377e219c4))
            )
            if _b2cfce704fb2:
                if _e9d210600695(_cc4afa884e4d, "eps"):
                    _cc4afa884e4d._22ad0736624b = 1e-3
                _cc4afa884e4d = _cc4afa884e4d._252728105cf7(_6e39b26f9db2._e29a06b2dd79)
                if not _6c54eb2d93e5(_cc4afa884e4d, _2b21f1897235._dcd1caa73850):
                    _e39c50b08e82._683f9fc99221((_5a89f7a420ca, _2b21f1897235._dcd1caa73850(_cc4afa884e4d, _b8c56f97c746=-10, _9640816031c6=10)))
        for _5a89f7a420ca, _fbf2f310f097 in _e39c50b08e82:
            _f0479c938473, _9082de616d22 = self._357e3fcf5ae2(_5a89f7a420ca)
            if _f0479c938473 is not _655b08c5fe91:
                _3c40225c8dd1(_f0479c938473, _9082de616d22, _fbf2f310f097)

    def _86f1b9e65b5f(self, _d2159e87c5cd):
        """Finds the parent module and attribute name given the full module path."""
        _3a921ba8312d = _d2159e87c5cd._836737d64e12('.')
        _c8a2d2f0247a = self
        for _e9e7d8c77270 in _3a921ba8312d[:-1]:
            _c8a2d2f0247a = _adebc65e1a18(_c8a2d2f0247a, _e9e7d8c77270, _655b08c5fe91)
            if _c8a2d2f0247a is _655b08c5fe91:
                return _655b08c5fe91, _655b08c5fe91
        return _c8a2d2f0247a, _3a921ba8312d[-1]

    def _3e31c8ebc438(self, _383ae52550db: _6e39b26f9db2._a3e1f82651b2, _247ddc45385e: _6e39b26f9db2._a3e1f82651b2, _eea572d4c094: _6e39b26f9db2._a3e1f82651b2) -> _71714c416781:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _fcfd22e4e02c = _383ae52550db._fcfd22e4e02c

        # 1) gating w (use cached per-example teacher_conf if available)
        _77416d24cb3a = _adebc65e1a18(self, "_last_teacher_conf", _655b08c5fe91)
        if _77416d24cb3a is _655b08c5fe91:
            # no teacher info => w = 0 (no distillation)
            _7913d1ec4175 = 0.0
        else:
            _549e2ac3b2ce = (_77416d24cb3a >= _956c71aa394b(_adebc65e1a18(self, "teacher_conf_tau", 0.6)))._956c71aa394b()
            _7913d1ec4175 = _956c71aa394b(_549e2ac3b2ce._c1931ac55e79()._69017429bedd()._81d1e7f4f2c1()) if _549e2ac3b2ce._647341d67fcc() > 0 else 0.0

        # apply gating to the batch scalars
        _2acdccd60638 = _247ddc45385e * _956c71aa394b(_7913d1ec4175)
        _426da2164fd7 = _eea572d4c094 * _956c71aa394b(_7913d1ec4175)

        # 2) EMAs for autoscaling
        _2efbfdf9bea6 = _956c71aa394b((_2acdccd60638 + _426da2164fd7)._e13d37e5c6e0()._69017429bedd()._81d1e7f4f2c1())
        _595f46a7910b = _956c71aa394b(_383ae52550db._e13d37e5c6e0()._69017429bedd()._81d1e7f4f2c1())
        if _adebc65e1a18(self, "ema_task", _655b08c5fe91) is _655b08c5fe91:
            self._ddff52f0ed29 = _595f46a7910b
            self._b96a5e80f2e4 = _2efbfdf9bea6 + 1e-12
        else:
            _98ab4fbdf6f9 = _956c71aa394b(_adebc65e1a18(self, "ema_alpha", 0.99))
            self._ddff52f0ed29 = _98ab4fbdf6f9 * _956c71aa394b(self._ddff52f0ed29) + (1.0 - _98ab4fbdf6f9) * _595f46a7910b
            self._b96a5e80f2e4  = _98ab4fbdf6f9 * _956c71aa394b(self._b96a5e80f2e4)  + (1.0 - _98ab4fbdf6f9) * _2efbfdf9bea6

        _b7bdc25b609f = _956c71aa394b(_adebc65e1a18(self, "distill_target_ratio", 0.3))
        _cfdeb3e59c8a = (_956c71aa394b(self._ddff52f0ed29) / (_956c71aa394b(self._b96a5e80f2e4) + 1e-12)) * _b7bdc25b609f
        _17f03a8081e1 = _956c71aa394b(_cfdeb3e59c8a)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _af5bb8daefa7 = _956c71aa394b(_adebc65e1a18(self._b5d64b644f3a, "current_epoch", _adebc65e1a18(self._b5d64b644f3a, "global_step", 0.0)))
        _61d4824bac41 = _956c71aa394b(_a4ac10edb801(1, _adebc65e1a18(self._b5d64b644f3a, "max_epochs", 1)))
        _132d33a320dd = _257619fd0651(_a4ac10edb801(_af5bb8daefa7 / _61d4824bac41, 0.0), 1.0)
        _d25f9b3f48ac = 0.30
        _085ee29b944f = _956c71aa394b(_adebc65e1a18(self, "kl_base", 0.30)) * _257619fd0651(_132d33a320dd / _d25f9b3f48ac, 1.0)
        _51a1a8ef2da5 = _956c71aa394b(_adebc65e1a18(self, "cos_base", 0.25))
        _70f9d13623f3 = _51a1a8ef2da5 + (0.10 - _51a1a8ef2da5) * _132d33a320dd

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _67d77e0d8dcb = _956c71aa394b(self._efd219a93329._c1931ac55e79()._69017429bedd()._81d1e7f4f2c1()) if _adebc65e1a18(self, "_last_teacher_conf", _655b08c5fe91) is not _655b08c5fe91 else 0.0
        if _adebc65e1a18(self, "ema_teacher_conf", _655b08c5fe91) is _655b08c5fe91:
            self._9a1bf4431682 = _67d77e0d8dcb
        else:
            _f3ccda38dfcc = _956c71aa394b(_adebc65e1a18(self, "teacher_conf_beta", 0.995))
            self._9a1bf4431682 = _f3ccda38dfcc * _956c71aa394b(self._9a1bf4431682) + (1.0 - _f3ccda38dfcc) * _67d77e0d8dcb

        _cd252d1b60ae = _956c71aa394b(_adebc65e1a18(self, "tau_warn", 0.60))
        _1acc80cbc710 = _956c71aa394b(_adebc65e1a18(self, "tau_detect", 0.20))
        _51927225e0d7 = _a4ac10edb801(1e-12, (_cd252d1b60ae - _1acc80cbc710))
        _b0904a90c9b6 = (_956c71aa394b(self._9a1bf4431682) - _1acc80cbc710) / _51927225e0d7
        _b0904a90c9b6 = _a4ac10edb801(0.0, _257619fd0651(1.0, _b0904a90c9b6))

        _59b4ded86017 = _085ee29b944f * _b0904a90c9b6
        _2e9a63be5c70 = _70f9d13623f3 * _b0904a90c9b6

        # 5) final aux term
        _c92951d7ea35 = _6e39b26f9db2._1cdc812d94a5(0.0, _fcfd22e4e02c=_fcfd22e4e02c)
        _c92951d7ea35 = _c92951d7ea35 + (_59b4ded86017 * _2acdccd60638 + _2e9a63be5c70 * _426da2164fd7) * _956c71aa394b(_17f03a8081e1)

        # diagnostics
        _7d35ac0118df = {
            "aux_term": _c92951d7ea35,
            "kl_batch": _247ddc45385e,
            "contrast_batch": _eea572d4c094,
            "kl_loss": _2acdccd60638,
            "contrastive_loss": _426da2164fd7,
            "w_mean": _7913d1ec4175,
            "aux_scale": _956c71aa394b(_17f03a8081e1),
            "lambda_kl_eff": _956c71aa394b(_59b4ded86017),
            "lambda_cos_eff": _956c71aa394b(_2e9a63be5c70),
            "teacher_conf_mean": _956c71aa394b(self._9a1bf4431682),
            "shift_r": _956c71aa394b(_b0904a90c9b6)
        }
        return _7d35ac0118df

    def _bac304b2bdba(self, _47ef5efda800):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _47ef5efda800 = _47ef5efda800._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)
        _def6529d1a53 = (_47ef5efda800 != self._efb3b07b4eef._c4c30b80c075)._252728105cf7(_81eae2d9aed2=_6e39b26f9db2._e4a9bac68222, _fcfd22e4e02c=self._de96aab61a3b, _be3112fdac93=_b44310a17910)

        # model forward (request hidden states)
        _c7f89c527cb5 = self._6b5c02afcdb8(
            _47ef5efda800=_47ef5efda800,
            _def6529d1a53=_def6529d1a53,
            _507fd7c41312=_b44310a17910,
            _bb5976f4e266=_b44310a17910,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _3d95ef1d7cf6 = _adebc65e1a18(_c7f89c527cb5, "last_hidden_state", _655b08c5fe91)
        if _3d95ef1d7cf6 is _655b08c5fe91:
            _3d95ef1d7cf6 = _c7f89c527cb5._48900869efbe[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _3d95ef1d7cf6._81eae2d9aed2 != _6e39b26f9db2._e29a06b2dd79:
            _3d95ef1d7cf6 = _3d95ef1d7cf6._252728105cf7(_6e39b26f9db2._e29a06b2dd79)
        _65f5ca54c75d = self._e8e8fd469240(_3d95ef1d7cf6)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._643b2e84f51b:
            _45711d1e8efb = self._d193a92a8d98(_65f5ca54c75d)
        else:
            _45711d1e8efb = _c7f89c527cb5._45711d1e8efb


        _45711d1e8efb = _45711d1e8efb._252728105cf7(_6e39b26f9db2._e29a06b2dd79)._3b49e250c2f2(-20, 20)

        # default zero scalars
        _2acdccd60638 = _6e39b26f9db2._1cdc812d94a5(0.0, _fcfd22e4e02c=self._de96aab61a3b)
        _426da2164fd7 = _6e39b26f9db2._1cdc812d94a5(0.0, _fcfd22e4e02c=self._de96aab61a3b)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _d338e37664e0 = _adebc65e1a18(self, "trainer", _655b08c5fe91)
        _9b8a3f302ae1 = _e43b45db6833
        if _d338e37664e0 is not _655b08c5fe91:
            _9b8a3f302ae1 = _e4a9bac68222(_adebc65e1a18(self._b5d64b644f3a, "training", _e43b45db6833) or _adebc65e1a18(self._b5d64b644f3a, "validating", _e43b45db6833))

        if _9b8a3f302ae1 and (_adebc65e1a18(self, "batch_counter", 0) % _adebc65e1a18(self, "xth_batch_to_consider", 1) == 0):
            with _6e39b26f9db2._a358536ad6df():
                _1e1b1b841535 = _dc7f05032bea(
                    _47ef5efda800=_47ef5efda800,
                    _def6529d1a53=_def6529d1a53,
                    _507fd7c41312=_b44310a17910,
                    _bb5976f4e266=_b44310a17910,
                )
                _2bed5a02ed71 = _adebc65e1a18(_1e1b1b841535, "last_hidden_state", _655b08c5fe91)
                if _2bed5a02ed71 is _655b08c5fe91:
                    _2bed5a02ed71 = _1e1b1b841535._48900869efbe[-1]

            # compute embedding-level KL + contrastive (scalar)
            _2acdccd60638, _426da2164fd7 = self._13db523b8ee8(_65f5ca54c75d, _2bed5a02ed71, _fcfd22e4e02c=self._de96aab61a3b)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _c240dc5ef65e(_87de3915be94): return _87de3915be94._c1931ac55e79(_473323112478=1) if _87de3915be94._473323112478() == 3 else _87de3915be94
            _e8db3de2a274 = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._d36fb9d36b21(_236de3708846(_65f5ca54c75d), _bfddf5bc912b=2, _473323112478=-1, _22ad0736624b=1e-6)
            _7901e28f9b3b = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._d36fb9d36b21(_236de3708846(_2bed5a02ed71), _bfddf5bc912b=2, _473323112478=-1, _22ad0736624b=1e-6)
            _3336509de4e8 = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._0ce3ae700411(_e8db3de2a274, _7901e28f9b3b, _473323112478=-1)  # [-1,1]
            _77416d24cb3a = _3336509de4e8._3b49e250c2f2(_257619fd0651=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._aa940b85503c = _65f5ca54c75d._e13d37e5c6e0()
            self._df7a01335840 = _2bed5a02ed71._e13d37e5c6e0()
            self._efd219a93329 = _77416d24cb3a._e13d37e5c6e0()  # shape (B,)

        # increment counter
        self._ca795310af89 = _adebc65e1a18(self, "batch_counter", 0) + 1

        return _45711d1e8efb, _2acdccd60638, _426da2164fd7


    def _2ad571aaf251(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _7431ae9d86e6(_cc4afa884e4d, _6272766c57b5, _1308de7b36c4):
            if _0b0aa9575f71(_913124d81f61._81eae2d9aed2 == _6e39b26f9db2._fcdd381b614f for _913124d81f61 in _6272766c57b5 if _6c54eb2d93e5(_913124d81f61, _6e39b26f9db2._a3e1f82651b2)):
                _148e1ad1b78f(f"Layer {_cc4afa884e4d._fc3e34fca93a.__name__} is using float16!")

        for _d53a1c16470d in self._d167dc0721b9():
            _70ef71ae1d27 = _d53a1c16470d._398f67d8553f(_606fc5387786)
            self._0490bacd198d._683f9fc99221(_70ef71ae1d27)

    def _d3a6961a7a27(self):
        """Remove all registered forward hooks."""
        for _70ef71ae1d27 in _adebc65e1a18(self, "amp_hooks", []):
            _70ef71ae1d27._931c96ea1724()
        self._0490bacd198d = []

    def _f22dc24f0696(self, _47ef5efda800, _d8b0a5ad8d1d, _6d063427f55b):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _cc287a7aaccb = [self._efb3b07b4eef._9c6008484177(_826f92d1b84e) for _826f92d1b84e in _47ef5efda800]
        _e6a1f7e3779f, _2451911d2ec3 = [], []

        for _fb636c2e3d5d, _4740500347f4, _117a783b325c in _f32ebbba847c(_cc287a7aaccb, _d8b0a5ad8d1d, _6d063427f55b):
            for token, _bd01fc374d71, _a61a1ab1a7b1 in _f32ebbba847c(_fb636c2e3d5d, _4740500347f4, _117a783b325c):
                if token == self._efb3b07b4eef._ca44df157f2c or _a61a1ab1a7b1 == self._ea33d091fa73:
                    continue

                _d5f857fc3c98 = (
                    token._4e68351053b5("##") or
                    token._4e68351053b5("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _d5f857fc3c98:
                    continue

                _e6a1f7e3779f._683f9fc99221(_bd01fc374d71._81d1e7f4f2c1())
                _2451911d2ec3._683f9fc99221(_a61a1ab1a7b1._81d1e7f4f2c1())

        return _6e39b26f9db2._1cdc812d94a5(_e6a1f7e3779f), _6e39b26f9db2._1cdc812d94a5(_2451911d2ec3)

    def _72a89d6371cd(self):
        _f72fef66f2ec = _6e39b26f9db2._e29a06b2dd79
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            _78732e7c6940, _0d471264042c = _6e39b26f9db2._f2f2c0372574._41fd9636941a()
            if _78732e7c6940 >= 8:
                _f72fef66f2ec = _6e39b26f9db2._53fefb60292a
            else:
                _f72fef66f2ec = _6e39b26f9db2._fcdd381b614f
        return _f72fef66f2ec

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _72cc5f7eabe1(
        self,
        _bc543405d03c: _6e39b26f9db2._a3e1f82651b2,
        _ca6c8373672c: _6e39b26f9db2._a3e1f82651b2,
        _fcfd22e4e02c: _467e81bbd7c5 = "cpu",
    ) -> _803e91eb97be[_6e39b26f9db2._a3e1f82651b2, _6e39b26f9db2._a3e1f82651b2]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _7b84c4501d89 = 2.0
            # NaN/Inf guard
            _bc543405d03c = _bc543405d03c._3b49e250c2f2(_257619fd0651=-30, _a4ac10edb801=30)
            _ca6c8373672c = _ca6c8373672c._3b49e250c2f2(_257619fd0651=-30, _a4ac10edb801=30)

            # Move once if needed
            _218e27d7844d = _6e39b26f9db2._fcfd22e4e02c(_fcfd22e4e02c)
            if _bc543405d03c._fcfd22e4e02c != _218e27d7844d:
                _bc543405d03c = _bc543405d03c._252728105cf7(_fcfd22e4e02c=_218e27d7844d, _be3112fdac93=_b44310a17910, _81eae2d9aed2=self._16de4fa7815b)
                _ca6c8373672c = _ca6c8373672c._252728105cf7(_fcfd22e4e02c=_218e27d7844d, _be3112fdac93=_b44310a17910, _81eae2d9aed2=self._16de4fa7815b)

            _a787c83eb64c = _bc543405d03c._8ea694649487(0)
            _5672acfa1739 = _bc543405d03c._8ea694649487(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _cf588466e262 = (_a787c83eb64c * _5672acfa1739) > 32_000_000

            if not _cf588466e262 or _a787c83eb64c <= 8:
                # Direct computation
                _d6db03fd10a5 = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._648c17da96ed(_bc543405d03c / _7b84c4501d89, _473323112478=-1)
                _98bb666e7c7e = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._9188394d153e(_ca6c8373672c / _7b84c4501d89, _473323112478=-1)
                _2acdccd60638 = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._3c7361492bc2(_d6db03fd10a5, _98bb666e7c7e, _071d325883be="batchmean") * (_7b84c4501d89 * _7b84c4501d89)
                _426da2164fd7 = 1 - _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._0ce3ae700411(_bc543405d03c, _ca6c8373672c, _473323112478=-1)._c1931ac55e79()
                return _2acdccd60638, _426da2164fd7

            # Chunked mode for large inputs
            _7c9474ed8f9c = _a4ac10edb801(1, _a787c83eb64c // 8)
            _58e1287a1a2c, _3c4afa3eb75f = [], []

            for _9f1f0400de82 in _ca2a711e29a6(0, _a787c83eb64c, _7c9474ed8f9c):
                _659abdbd9f5b = _bc543405d03c[_9f1f0400de82:_9f1f0400de82 + _7c9474ed8f9c]
                _af49a6e826d2 = _ca6c8373672c[_9f1f0400de82:_9f1f0400de82 + _7c9474ed8f9c]

                _d6db03fd10a5 = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._648c17da96ed(_659abdbd9f5b / _7b84c4501d89, _473323112478=-1)
                _98bb666e7c7e = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._9188394d153e(_af49a6e826d2 / _7b84c4501d89, _473323112478=-1)

                _12e7e5add8f7 = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._3c7361492bc2(_d6db03fd10a5, _98bb666e7c7e, _071d325883be="batchmean") * (_7b84c4501d89 * _7b84c4501d89)
                _711c9e38d79f = _6e39b26f9db2._c7b2c8b51ec0._77d41512cc46._0ce3ae700411(_659abdbd9f5b, _af49a6e826d2, _473323112478=-1)._c1931ac55e79()
                _974ef017d5a6 = 1 - _711c9e38d79f

                _58e1287a1a2c._683f9fc99221(_12e7e5add8f7)
                _3c4afa3eb75f._683f9fc99221(_974ef017d5a6)

            _2acdccd60638 = _6e39b26f9db2._18956b8edcdf(_58e1287a1a2c)._c1931ac55e79()
            _426da2164fd7 = _6e39b26f9db2._18956b8edcdf(_3c4afa3eb75f)._c1931ac55e79()
            return _2acdccd60638, _426da2164fd7

        except _62f472c1e751 as _7101eea27e7a:
            raise _3894f6d90969(f"KL/contrastive loss computation failed: {_467e81bbd7c5(_7101eea27e7a)}")


    def _7c7635fc6f7a(self, _010ff4b2ac96, _df02db7ae65f):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _47ef5efda800 = _010ff4b2ac96["input_ids"]
            _646aff80fd11 = _010ff4b2ac96["labels"]
            _228d40fc640c = _010ff4b2ac96._8fc8629368db("prompt_lens", _655b08c5fe91)
            _a787c83eb64c = _47ef5efda800._8ea694649487(0)

            # move to device
            _47ef5efda800 = _47ef5efda800._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)
            _646aff80fd11 = _646aff80fd11._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _1308de7b36c4, _247ddc45385e, _eea572d4c094 = self(_47ef5efda800)

            # causal LM shift for next-token classification (unchanged)
            _f7ffa0110bfa = _1308de7b36c4[:, :-1, :]._e253429b1be6()
            _c10b306f53a5 = _646aff80fd11[:, 1:]._e253429b1be6()
            _0e9724a4f17b = _f7ffa0110bfa._5a048acf0558(-1, _f7ffa0110bfa._8ea694649487(-1))
            _79493f319ac3 = _c10b306f53a5._5a048acf0558(-1)

            # classification/task loss
            _73eca50a9f93 = self._545c9449977d['criterion'](_0e9724a4f17b, _79493f319ac3)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _247ddc45385e = _6e39b26f9db2._d52dec04a996(_247ddc45385e, _475b7a19a09f=0.0, _e7fa92a8b29d=0.0, _c635d3222f33=0.0)
            _eea572d4c094 = _6e39b26f9db2._d52dec04a996(_eea572d4c094, _475b7a19a09f=0.0, _e7fa92a8b29d=0.0, _c635d3222f33=0.0)
            _73eca50a9f93 = _6e39b26f9db2._d52dec04a996(_73eca50a9f93, _475b7a19a09f=0.0, _e7fa92a8b29d=0.0, _c635d3222f33=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _dfb10b6c3e32 = self._6eb0509dbb9d(_73eca50a9f93, _247ddc45385e, _eea572d4c094)
            _c92951d7ea35 = _dfb10b6c3e32["aux_term"]

            # final combined loss (single-equation)
            _38684eb9a026 = _73eca50a9f93 + _c92951d7ea35

            # Optional NaN print as before (keeps your original check)
            if _6e39b26f9db2._f6e606e6fc0f(_73eca50a9f93):
                _148e1ad1b78f(f"Step {_df02db7ae65f}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _82394c463e30 = {
                "epoch": _956c71aa394b(_adebc65e1a18(self, "current_epoch", _adebc65e1a18(self._b5d64b644f3a, "current_epoch", 0))),
                "train_kl_loss": _dfb10b6c3e32._8fc8629368db("kl_loss", _247ddc45385e)._e13d37e5c6e0() if _6c54eb2d93e5(_dfb10b6c3e32._8fc8629368db("kl_loss", _247ddc45385e), _6e39b26f9db2._a3e1f82651b2) else _dfb10b6c3e32._8fc8629368db("kl_loss", _247ddc45385e),
                "train_contrastive_loss": _dfb10b6c3e32._8fc8629368db("contrastive_loss", _eea572d4c094)._e13d37e5c6e0() if _6c54eb2d93e5(_dfb10b6c3e32._8fc8629368db("contrastive_loss", _eea572d4c094), _6e39b26f9db2._a3e1f82651b2) else _dfb10b6c3e32._8fc8629368db("contrastive_loss", _eea572d4c094),
                "train_classification_loss": _73eca50a9f93._e13d37e5c6e0(),
                "train_loss": _38684eb9a026._e13d37e5c6e0(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _956c71aa394b(_adebc65e1a18(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _dfb10b6c3e32._8fc8629368db("lambda_kl_eff", _956c71aa394b(_adebc65e1a18(self, "kl_base", 0.30))),
                "train_lambda_contrast": _dfb10b6c3e32._8fc8629368db("lambda_cos_eff", _956c71aa394b(_adebc65e1a18(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _dcd759769e3e in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _dcd759769e3e in _dfb10b6c3e32:
                    _06a457eeef44 = _dfb10b6c3e32[_dcd759769e3e]
                    # convert single-element tensors to python floats for logging
                    if _6c54eb2d93e5(_06a457eeef44, _6e39b26f9db2._a3e1f82651b2) and _06a457eeef44._647341d67fcc() == 1:
                        _82394c463e30[f"train_{_dcd759769e3e}"] = _956c71aa394b(_06a457eeef44._e13d37e5c6e0()._69017429bedd()._81d1e7f4f2c1())
                    else:
                        _82394c463e30[f"train_{_dcd759769e3e}"] = _06a457eeef44

            # log exactly like you did
            self._0487f396d4a5(
                _82394c463e30,
                _a787c83eb64c=_a787c83eb64c,
                _9ed07ea05351=_e43b45db6833,
                _5c02fc870ace=_b44310a17910,
                _571cb2059a1e=_e43b45db6833,
                _877405a9e199=_b44310a17910,
                _60c4033bf6a1=_b44310a17910,
            )

            # free references as you did
            del _47ef5efda800, _646aff80fd11, _1308de7b36c4, _247ddc45385e, _73eca50a9f93, _eea572d4c094, _c10b306f53a5, _f7ffa0110bfa, _79493f319ac3, _0e9724a4f17b

            return _38684eb9a026

        except _62f472c1e751 as _7101eea27e7a:
            raise _3894f6d90969(f"Error in training_step: {_7101eea27e7a}") from _7101eea27e7a

    def _77c1420b84a8(self):
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            _6e39b26f9db2._f2f2c0372574._3e814810cf30()
        _692b375dade2._167f981dee4b()
        return _260e801f926b()._b5722eed2b3c()

    def _d73459ebc7c5(self, _010ff4b2ac96, _df02db7ae65f):
        _47ef5efda800      = _010ff4b2ac96["input_ids"]._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)
        _646aff80fd11         = _010ff4b2ac96["labels"]._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)
        _9fa008fcd1cb     = _010ff4b2ac96._8fc8629368db("lang_codes", _655b08c5fe91)
        _ff65d12bb9af     = _010ff4b2ac96._8fc8629368db("sample_ids", _655b08c5fe91)
        _fc1f585723b3      = _010ff4b2ac96._8fc8629368db("chunk_ids", _655b08c5fe91)
        _54f591164e1b = _010ff4b2ac96._8fc8629368db("word_positions", _655b08c5fe91)
        _228d40fc640c    = _010ff4b2ac96._8fc8629368db("prompt_lens", _655b08c5fe91)
        _cd40e021969c = _010ff4b2ac96._8fc8629368db("num_chunks", _655b08c5fe91)

        _a787c83eb64c = _47ef5efda800._8ea694649487(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _1308de7b36c4, _247ddc45385e, _eea572d4c094 = self(_47ef5efda800)

        # causal LM shift for next-token classification (same as training)
        _f7ffa0110bfa = _1308de7b36c4[:, :-1, :]._e253429b1be6()
        _c10b306f53a5 = _646aff80fd11[:, 1:]._e253429b1be6()
        _0e9724a4f17b = _f7ffa0110bfa._5a048acf0558(-1, _f7ffa0110bfa._8ea694649487(-1))
        _79493f319ac3 = _c10b306f53a5._5a048acf0558(-1)

        if _df02db7ae65f == 0:
            try:
                _148e1ad1b78f(
                    f"VAL TEST BATCH {_df02db7ae65f} Input IDs: {_47ef5efda800._0c5cd36c74dd()[0]}, "
                    f"Predictions: {_6e39b26f9db2._2a0bafcc2b78(_f7ffa0110bfa, _473323112478=-1)._0c5cd36c74dd()[0]}, "
                    f"Labels: {_c10b306f53a5._0c5cd36c74dd()[0]}"
                )
            except _62f472c1e751:
                # printing should never crash validation
                pass

        # classification loss
        _73eca50a9f93 = self._545c9449977d['criterion'](_0e9724a4f17b, _79493f319ac3)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _247ddc45385e = _6e39b26f9db2._d52dec04a996(_247ddc45385e, _475b7a19a09f=0.0, _e7fa92a8b29d=0.0, _c635d3222f33=0.0)
        _eea572d4c094 = _6e39b26f9db2._d52dec04a996(_eea572d4c094, _475b7a19a09f=0.0, _e7fa92a8b29d=0.0, _c635d3222f33=0.0)
        _73eca50a9f93 = _6e39b26f9db2._d52dec04a996(_73eca50a9f93, _475b7a19a09f=0.0, _e7fa92a8b29d=0.0, _c635d3222f33=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _dfb10b6c3e32 = self._6eb0509dbb9d(_73eca50a9f93, _247ddc45385e, _eea572d4c094)
        _c92951d7ea35 = _dfb10b6c3e32["aux_term"]
        _38684eb9a026 = _73eca50a9f93 + _c92951d7ea35

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _0487f396d4a5 = {
            "val_kl_loss": _956c71aa394b(_dfb10b6c3e32._8fc8629368db("kl_loss", _247ddc45385e)._e13d37e5c6e0()._69017429bedd()._81d1e7f4f2c1()) if _6c54eb2d93e5(_dfb10b6c3e32._8fc8629368db("kl_loss", _247ddc45385e), _6e39b26f9db2._a3e1f82651b2) else _956c71aa394b(_dfb10b6c3e32._8fc8629368db("kl_loss", _247ddc45385e)),
            "val_contrastive_loss": _956c71aa394b(_dfb10b6c3e32._8fc8629368db("contrastive_loss", _eea572d4c094)._e13d37e5c6e0()._69017429bedd()._81d1e7f4f2c1()) if _6c54eb2d93e5(_dfb10b6c3e32._8fc8629368db("contrastive_loss", _eea572d4c094), _6e39b26f9db2._a3e1f82651b2) else _956c71aa394b(_dfb10b6c3e32._8fc8629368db("contrastive_loss", _eea572d4c094)),
            "val_classification_loss": _956c71aa394b(_73eca50a9f93._e13d37e5c6e0()._69017429bedd()._81d1e7f4f2c1()),
            "val_loss": _956c71aa394b(_38684eb9a026._e13d37e5c6e0()._69017429bedd()._81d1e7f4f2c1()),
        }

        # include effective lambdas and others if provided by aux
        _0487f396d4a5["val_lambda_kl"] = _956c71aa394b(_dfb10b6c3e32._8fc8629368db("lambda_kl", _dfb10b6c3e32._8fc8629368db("lambda_kl_eff", _956c71aa394b(_adebc65e1a18(self, "kl_base", 0.30)))))
        _0487f396d4a5["val_lambda_contrast"] = _956c71aa394b(_dfb10b6c3e32._8fc8629368db("lambda_cos", _dfb10b6c3e32._8fc8629368db("lambda_cos_eff", _956c71aa394b(_adebc65e1a18(self, "cos_base", 0.25)))))
        _0487f396d4a5["val_w_mean"] = _956c71aa394b(_dfb10b6c3e32._8fc8629368db("w_mean", 0.0))
        _0487f396d4a5["val_aux_scale"] = _956c71aa394b(_dfb10b6c3e32._8fc8629368db("aux_scale", 0.0))
        _0487f396d4a5["val_shift_r"] = _956c71aa394b(_dfb10b6c3e32._8fc8629368db("shift_r", 0.0))
        _0487f396d4a5["val_teacher_conf_mean"] = _956c71aa394b(_dfb10b6c3e32._8fc8629368db("teacher_conf_mean", 0.0))

        self._0487f396d4a5(
            _0487f396d4a5,
            _a787c83eb64c=_a787c83eb64c,
            _9ed07ea05351=_e43b45db6833,
            _5c02fc870ace=_b44310a17910,
            _571cb2059a1e=_e43b45db6833,
            _877405a9e199=_b44310a17910,
            _60c4033bf6a1=_b44310a17910,
        )

        # build preds and labels per example (preserve your previous behavior)
        _5336e8a661c1 = []
        _efa1f57b5e80 = []
        for _9f1f0400de82 in _ca2a711e29a6(_a787c83eb64c):
            _f81c9d4754b9 = _1308de7b36c4[_9f1f0400de82]
            _a61a1ab1a7b1 = _646aff80fd11[_9f1f0400de82]
            _f318e6422c64 = _6e39b26f9db2._2a0bafcc2b78(_f81c9d4754b9, _473323112478=-1)
            _e0020162dfa5 = _a61a1ab1a7b1
            _5336e8a661c1._683f9fc99221(_f318e6422c64)
            _efa1f57b5e80._683f9fc99221(_e0020162dfa5)

        _9d77ebf27b7a = {
            "lang_codes": _9fa008fcd1cb,
            "preds": _5336e8a661c1,
            "labels": _efa1f57b5e80,
            "sample_ids": _ff65d12bb9af,
            "chunk_ids": _fc1f585723b3,
            "word_positions": _54f591164e1b,
            "val_loss": _38684eb9a026,
            "prompt_lens": _228d40fc640c,
            "num_chunks": _cd40e021969c,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._86fa72d9ca61._683f9fc99221(_9d77ebf27b7a)

        # explicit frees (same as you had)
        del _47ef5efda800, _646aff80fd11, _1308de7b36c4, _0e9724a4f17b, _79493f319ac3, _f7ffa0110bfa, _c10b306f53a5
        del _247ddc45385e, _eea572d4c094, _73eca50a9f93, _5336e8a661c1, _efa1f57b5e80

        return _9d77ebf27b7a


    def _c242a7913cf5(self, _b50a08674cf1, _16ded48f34d6, _9631de5fbe65=_655b08c5fe91):
        _9aabb0873e02 = os._9762836e5761()
        _31d4817e1f7b = f"trial_{_9631de5fbe65}" if _9631de5fbe65 is not _655b08c5fe91 else "default"
        _148e1ad1b78f(f"[DEBUG rank={_6e39b26f9db2._e902498b1682._a7605e18882f() if _6e39b26f9db2._e902498b1682._b9124b4a6065() else 0}] metrics_dict confusion_matrix sum={_1d376cad07ad(_1d376cad07ad(_80d9b659ea2c) for _80d9b659ea2c in _b50a08674cf1['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _b9d4ce90b758 = os._6f8bd533315b._ce2c8c45f1e5(_9aabb0873e02, "metrics", self._7458dd3c6550,  _31d4817e1f7b)
        os._8cb4a34db71e(_b9d4ce90b758, _393a8657d767=_b44310a17910)
        _e41ab5302d2b = os._6f8bd533315b._ce2c8c45f1e5(_b9d4ce90b758, _16ded48f34d6)
        _aa1d45489cc3 = _baffdc174071._807254312348(_b50a08674cf1)
        _aa1d45489cc3._54c54426c37c(_e41ab5302d2b, _59fc448556b7=_e43b45db6833)
        _148e1ad1b78f(f"[metrics] Saved {_e41ab5302d2b}")

    def _6b5483ee631f(self):
        # pick correct device for this rank
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            if _6e39b26f9db2._e902498b1682._b9124b4a6065():
                _c3b97bd9d6b7 = _6e39b26f9db2._e902498b1682._a7605e18882f()
            else:
                _c3b97bd9d6b7 = 0
            _6e39b26f9db2._f2f2c0372574._ca110fee8dcd(_c3b97bd9d6b7)
            self._de96aab61a3b = _6e39b26f9db2._fcfd22e4e02c(f"cuda:{_c3b97bd9d6b7}")
        else:
            self._de96aab61a3b = _6e39b26f9db2._fcfd22e4e02c("cpu")

        self._2e1c4dd3c74f()

    def _ee7bab90fbc9(self):
        _1308de7b36c4 = _adebc65e1a18(self, "_validation_outputs", _655b08c5fe91)
        if not _1308de7b36c4:
            return

        _acd41b71465d, _d1136a10bf7a, _10676b6d71b3, _551856388d3e = \
            self._bb871be86a04(_1308de7b36c4)

        _0bb31ad6e396, _60ccd489ab5b = [], []
        for _91ad5d84a36c in _b0144b82b576(_10676b6d71b3._9d47806043c6()):
            _0e9bb1d8e516 = _acd41b71465d[_91ad5d84a36c]._0c5cd36c74dd()
            _68722444f039 = _d1136a10bf7a[_91ad5d84a36c]._0c5cd36c74dd()
            _eb7e987cd9f5 = _10676b6d71b3[_91ad5d84a36c]
            _2d8c206111be = _551856388d3e[_91ad5d84a36c]
            if _eb7e987cd9f5._647341d67fcc() > 0 and _2d8c206111be._647341d67fcc() > 0:
                _0bb31ad6e396._683f9fc99221(_eb7e987cd9f5)
                _60ccd489ab5b._683f9fc99221(_2d8c206111be)

        if not _0bb31ad6e396:
            _148e1ad1b78f("[VAL END] Nothing to score.")
            self._86fa72d9ca61._7cc0135feb59()
            return

        _63eef50c5aa5 = _6e39b26f9db2._64a6ae940149(_0bb31ad6e396)._252728105cf7(_fcfd22e4e02c=self._665ffedda66b['micro_accuracy']._fcfd22e4e02c, _be3112fdac93=_b44310a17910)
        _646aff80fd11 = _6e39b26f9db2._64a6ae940149(_60ccd489ab5b)._252728105cf7(_fcfd22e4e02c=self._665ffedda66b['micro_accuracy']._fcfd22e4e02c, _be3112fdac93=_b44310a17910)

        self._665ffedda66b['micro_accuracy']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_accuracy']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_precision']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_recall']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_f1']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_accuracy']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_precision']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_recall']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_f1']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['confmat']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)

        _b5847502a1e2  = self._665ffedda66b['micro_accuracy']._5e5b999bd23c()._81d1e7f4f2c1()
        _35c88843cb5d  = self._665ffedda66b['macro_accuracy']._5e5b999bd23c()._81d1e7f4f2c1()
        _3ddd85241a1c = self._665ffedda66b['macro_precision']._5e5b999bd23c()._81d1e7f4f2c1()
        _d7243b03872b    = self._665ffedda66b['macro_recall']._5e5b999bd23c()._81d1e7f4f2c1()
        _9db7748663de        = self._665ffedda66b['macro_f1']._5e5b999bd23c()._81d1e7f4f2c1()

        self._0d4a76ff74bd("val_accuracy", _35c88843cb5d, _60c4033bf6a1=_b44310a17910)

        try:
            _ecc2eeddc720 = self._bbee321f6888
            _b50a08674cf1 = {
                "epoch": [_ecc2eeddc720],
                "class_names": [self._b34ef133a4a3],
                "micro_accuracy": [_b5847502a1e2],
                "macro_accuracy": [_35c88843cb5d],
                "macro_precision": [_3ddd85241a1c],
                "macro_recall": [_d7243b03872b],
                "macro_f1": [_9db7748663de],
                "classwise_accuracy": [self._665ffedda66b['classwise_accuracy']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "classwise_precision": [self._665ffedda66b['classwise_precision']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "classwise_recall": [self._665ffedda66b['classwise_recall']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "classwise_f1": [self._665ffedda66b['classwise_f1']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "confusion_matrix": [self._665ffedda66b['confmat']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
            }
            self._491858d94f54(_b50a08674cf1, f"val_epoch_{_ecc2eeddc720}.csv", _9631de5fbe65=self._9631de5fbe65)
        except _62f472c1e751 as _7101eea27e7a:
            _148e1ad1b78f(f"[VAL END] save metrics FAILED: {_7101eea27e7a}")

        # cleanup
        self._665ffedda66b['micro_accuracy']._11ae0928d8af(); self._665ffedda66b['macro_accuracy']._11ae0928d8af()
        self._665ffedda66b['macro_precision']._11ae0928d8af(); self._665ffedda66b['macro_recall']._11ae0928d8af(); self._665ffedda66b['macro_f1']._11ae0928d8af()
        self._665ffedda66b['classwise_accuracy']._11ae0928d8af(); self._665ffedda66b['classwise_precision']._11ae0928d8af()
        self._665ffedda66b['classwise_recall']._11ae0928d8af(); self._665ffedda66b['classwise_f1']._11ae0928d8af()
        self._665ffedda66b['confmat']._11ae0928d8af(); self._86fa72d9ca61._7cc0135feb59()
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            _6e39b26f9db2._f2f2c0372574._3e814810cf30()
        _148e1ad1b78f("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_6e39b26f9db2._a358536ad6df()
    def _5435f384fec1(self, _47ef5efda800: _6e39b26f9db2._a3e1f82651b2, **_7eb2a2744739):
        _7eb2a2744739._bc26d086aead("pad_token_id", _655b08c5fe91)
        _7eb2a2744739._bc26d086aead("attention_mask", _655b08c5fe91)
        return self._6b5c02afcdb8._9ec9bdf97ed0(
            _47ef5efda800=_47ef5efda800,
            _def6529d1a53=(_47ef5efda800 != self._efb3b07b4eef._c4c30b80c075),
            _c4c30b80c075=self._efb3b07b4eef._c4c30b80c075,
            _951f6a9e7564=self._efb3b07b4eef._951f6a9e7564,
            **_7eb2a2744739
        )

    def _fd9e12275fa8(self, _010ff4b2ac96, _df02db7ae65f):
        _47ef5efda800 = _010ff4b2ac96["input_ids"]._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)
        _646aff80fd11    = _010ff4b2ac96["labels"]._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)
        _9fa008fcd1cb     = _010ff4b2ac96._8fc8629368db("lang_codes", _655b08c5fe91)
        _ff65d12bb9af     = _010ff4b2ac96._8fc8629368db("sample_ids", _655b08c5fe91)
        _fc1f585723b3      = _010ff4b2ac96._8fc8629368db("chunk_ids", _655b08c5fe91)
        _54f591164e1b = _010ff4b2ac96._8fc8629368db("word_positions", _655b08c5fe91)
        _228d40fc640c    = _010ff4b2ac96._8fc8629368db("prompt_lens", _655b08c5fe91)
        _cd40e021969c = _010ff4b2ac96._8fc8629368db("num_chunks", _655b08c5fe91)

        _a787c83eb64c = _47ef5efda800._8ea694649487(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _d2204a517087 = self._9ec9bdf97ed0(
            _47ef5efda800,
            _83f3b901f969=48,
            _6fa88109bbba=_e43b45db6833,
            _e86f458d96f4=_655b08c5fe91,     # or just add this
            _ab6bb87d274f=_655b08c5fe91,
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _5336e8a661c1 = []
        _efa1f57b5e80 = []
        for _9f1f0400de82 in _ca2a711e29a6(_a787c83eb64c):
            _1c783217a89a = _d2204a517087[_9f1f0400de82]                    # (seq_len,)
            _3718a7c45719 = _646aff80fd11[_9f1f0400de82]
            _5336e8a661c1._683f9fc99221(_1c783217a89a)
            _efa1f57b5e80._683f9fc99221(_3718a7c45719)

        _9d77ebf27b7a = {
            "lang_codes": _9fa008fcd1cb,
            "preds": _5336e8a661c1,
            "labels": _efa1f57b5e80,
            "sample_ids": _ff65d12bb9af,
            "chunk_ids": _fc1f585723b3,
            "word_positions": _54f591164e1b,
            "prompt_lens": _228d40fc640c,
            "num_chunks": _cd40e021969c,
        }

        self._7897c7f3d9c8._683f9fc99221(_9d77ebf27b7a)

        # Exact same cleanup as before
        del _47ef5efda800, _646aff80fd11, _d2204a517087, _5336e8a661c1, _efa1f57b5e80

        return _9d77ebf27b7a

    def _57f92ed04a7d(self):
        # pick correct device for this rank
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            if _6e39b26f9db2._e902498b1682._b9124b4a6065():
                _c3b97bd9d6b7 = _6e39b26f9db2._e902498b1682._a7605e18882f()
            else:
                _c3b97bd9d6b7 = 0
            _6e39b26f9db2._f2f2c0372574._ca110fee8dcd(_c3b97bd9d6b7)
            self._de96aab61a3b = _6e39b26f9db2._fcfd22e4e02c(f"cuda:{_c3b97bd9d6b7}")
        else:
            self._de96aab61a3b = _6e39b26f9db2._fcfd22e4e02c("cpu")

        self._2e1c4dd3c74f()
        
    def _4e1c0d6426e8(self):
        _1308de7b36c4 = _adebc65e1a18(self, "_test_outputs", _655b08c5fe91)
        _148e1ad1b78f(f"[DEBUG rank={_6e39b26f9db2._e902498b1682._a7605e18882f()}] outputs_len={_94a0187a3088(_1308de7b36c4)}")
        if not _1308de7b36c4:
            return

        _acd41b71465d, _d1136a10bf7a, _10676b6d71b3, _551856388d3e = \
            self._bb871be86a04(_1308de7b36c4)

        _0bb31ad6e396, _60ccd489ab5b = [], []
        for _91ad5d84a36c in _b0144b82b576(_10676b6d71b3._9d47806043c6()):
            _0e9bb1d8e516 = _acd41b71465d[_91ad5d84a36c]._0c5cd36c74dd()
            _68722444f039 = _d1136a10bf7a[_91ad5d84a36c]._0c5cd36c74dd()
            _eb7e987cd9f5 = _10676b6d71b3[_91ad5d84a36c]
            _2d8c206111be = _551856388d3e[_91ad5d84a36c]

            if _eb7e987cd9f5._647341d67fcc() > 0 and _2d8c206111be._647341d67fcc() > 0:
                _0bb31ad6e396._683f9fc99221(_eb7e987cd9f5)
                _60ccd489ab5b._683f9fc99221(_2d8c206111be)

        if not _0bb31ad6e396:
            _148e1ad1b78f("[TEST END] Nothing to score.")
            self._86fa72d9ca61._7cc0135feb59()
            return

        _63eef50c5aa5 = _6e39b26f9db2._64a6ae940149(_0bb31ad6e396)._252728105cf7(_fcfd22e4e02c=self._665ffedda66b['micro_accuracy']._fcfd22e4e02c, _be3112fdac93=_b44310a17910)
        _646aff80fd11 = _6e39b26f9db2._64a6ae940149(_60ccd489ab5b)._252728105cf7(_fcfd22e4e02c=self._665ffedda66b['micro_accuracy']._fcfd22e4e02c, _be3112fdac93=_b44310a17910)

        self._665ffedda66b['micro_accuracy']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_accuracy']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_precision']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_recall']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['macro_f1']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_accuracy']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_precision']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_recall']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['classwise_f1']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)
        self._665ffedda66b['confmat']._c3c31d07fded(_63eef50c5aa5, _646aff80fd11)

        _b5847502a1e2  = self._665ffedda66b['micro_accuracy']._5e5b999bd23c()._81d1e7f4f2c1()
        _35c88843cb5d  = self._665ffedda66b['macro_accuracy']._5e5b999bd23c()._81d1e7f4f2c1()
        _3ddd85241a1c = self._665ffedda66b['macro_precision']._5e5b999bd23c()._81d1e7f4f2c1()
        _d7243b03872b    = self._665ffedda66b['macro_recall']._5e5b999bd23c()._81d1e7f4f2c1()
        _9db7748663de        = self._665ffedda66b['macro_f1']._5e5b999bd23c()._81d1e7f4f2c1()

        self._0d4a76ff74bd("test_accuracy", _35c88843cb5d, _60c4033bf6a1=_b44310a17910)

        try:
            _ecc2eeddc720 = self._bbee321f6888
            _b50a08674cf1 = {
                "epoch": [_ecc2eeddc720],
                "class_names": [self._b34ef133a4a3],
                "micro_accuracy": [_b5847502a1e2],
                "macro_accuracy": [_35c88843cb5d],
                "macro_precision": [_3ddd85241a1c],
                "macro_recall": [_d7243b03872b],
                "macro_f1": [_9db7748663de],
                "classwise_accuracy": [self._665ffedda66b['classwise_accuracy']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "classwise_precision": [self._665ffedda66b['classwise_precision']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "classwise_recall": [self._665ffedda66b['classwise_recall']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "classwise_f1": [self._665ffedda66b['classwise_f1']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
                "confusion_matrix": [self._665ffedda66b['confmat']._5e5b999bd23c()._252728105cf7(_fcfd22e4e02c="cpu")._0ee37aaa65b6()._0c5cd36c74dd()],
            }
            self._491858d94f54(_b50a08674cf1, f"test_final.csv", _9631de5fbe65=self._9631de5fbe65)
        except _62f472c1e751 as _7101eea27e7a:
            _148e1ad1b78f(f"[TEST END] save metrics FAILED: {_7101eea27e7a}")

        # cleanup
        self._665ffedda66b['micro_accuracy']._11ae0928d8af(); self._665ffedda66b['macro_accuracy']._11ae0928d8af()
        self._665ffedda66b['macro_precision']._11ae0928d8af(); self._665ffedda66b['macro_recall']._11ae0928d8af(); self._665ffedda66b['macro_f1']._11ae0928d8af()
        self._665ffedda66b['classwise_accuracy']._11ae0928d8af(); self._665ffedda66b['classwise_precision']._11ae0928d8af()
        self._665ffedda66b['classwise_recall']._11ae0928d8af(); self._665ffedda66b['classwise_f1']._11ae0928d8af()
        self._665ffedda66b['confmat']._11ae0928d8af(); self._86fa72d9ca61._7cc0135feb59()
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            _6e39b26f9db2._f2f2c0372574._3e814810cf30()
        _148e1ad1b78f("[TEST END] Finished and cleaned up.")

    def _a31a6940bc3e(self, _010ff4b2ac96, _df02db7ae65f, _6e27c7b65ee2=0):
        """Optimized prediction step with efficient memory handling."""
        _47ef5efda800, _ = _010ff4b2ac96
        _47ef5efda800 = _47ef5efda800._252728105cf7(self._de96aab61a3b, _be3112fdac93=_b44310a17910)
        _1308de7b36c4, _, _ = self(_47ef5efda800)
        _812d8ccbc0fa = _6e39b26f9db2._2a0bafcc2b78(_1308de7b36c4, _473323112478=-1)
        del _47ef5efda800, _1308de7b36c4
        if _6e39b26f9db2._f2f2c0372574._afa87b0ac178():
            _6e39b26f9db2._f2f2c0372574._3e814810cf30()
        return {"predictions": _812d8ccbc0fa._69017429bedd()}

    def _3758875955d1(self, _1308de7b36c4, _746c8edb7feb=_b44310a17910, _218e27d7844d="cpu"):
        from collections import _2a04b37f96c1, _0f2b59681963
        import _6e39b26f9db2
        _9640075cbece = self._ea33d091fa73
        def _d5d68028d5d8(_87de3915be94):
            if _6c54eb2d93e5(_87de3915be94, _6e39b26f9db2._a3e1f82651b2): return _87de3915be94._e13d37e5c6e0()._252728105cf7(_fcfd22e4e02c=_218e27d7844d, _be3112fdac93=_b44310a17910)._d24bafbb8c55(-1)._0c5cd36c74dd()
            return _f46b8b43bca0(_87de3915be94) if _6c54eb2d93e5(_87de3915be94, (_f46b8b43bca0, _28695ff1c377)) else [_87de3915be94]
        
        _f629c0776cfd = _5730a11b5683()
        _acd41b71465d, _d1136a10bf7a, _df03bff169fd = {}, {}, []
        if _746c8edb7feb:
            _148e1ad1b78f(f"[reconcile] start: num_outputs={_94a0187a3088(_1308de7b36c4)}")
        

        _148e1ad1b78f(f"[DEBUG rank={_6e39b26f9db2._e902498b1682._a7605e18882f()}] Before reconcile missing sample_ids={[_91ad5d84a36c for _91ad5d84a36c in _ca2a711e29a6(0 if _6e39b26f9db2._e902498b1682._a7605e18882f() == 0 else 637, 637 if _6e39b26f9db2._e902498b1682._a7605e18882f() == 0 else 1274) if _91ad5d84a36c not in _5730a11b5683(_91ad5d84a36c for _7d35ac0118df in _1308de7b36c4 for _91ad5d84a36c in _7d35ac0118df._8fc8629368db('sample_ids', []))]}")
        for _7d35ac0118df in _1308de7b36c4:
            _ff65d12bb9af     = _7d35ac0118df["sample_ids"]
            _fc1f585723b3      = _7d35ac0118df["chunk_ids"]
            _6686e07f56dd    = _7d35ac0118df["preds"]
            _f50cd8597604   = _7d35ac0118df["labels"]
            _54f591164e1b = _7d35ac0118df["word_positions"]
            _228d40fc640c = _7d35ac0118df["prompt_lens"]
            _559aff2fdb94 = _7d35ac0118df["num_chunks"]

            for _9f1f0400de82, _91ad5d84a36c in _672aea193df6(_ff65d12bb9af):
                _e6666c68f6f7 = _b07597fe40e6(_fc1f585723b3[_9f1f0400de82])

                if (_91ad5d84a36c, _e6666c68f6f7) in _f629c0776cfd:
                    continue
                _f629c0776cfd._bf3f6d41b795((_91ad5d84a36c, _e6666c68f6f7))

                _e60d3605a141 = _b07597fe40e6(_228d40fc640c[_9f1f0400de82])
                _5c92d3a19dc8 = _7c6b6e5bee69(_54f591164e1b[_9f1f0400de82])
                _817dfdd9332d = self._21112401c1a6
                # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
                _376ea5a47e42  = _7c6b6e5bee69(_6686e07f56dd[_9f1f0400de82])
                _2300218cba7e = _7c6b6e5bee69(_f50cd8597604[_9f1f0400de82])

                # If preds are shorter than labels, they are generation-only (test)
                if _94a0187a3088(_376ea5a47e42) < _94a0187a3088(_2300218cba7e):
                    _7fd6abc35301  = _376ea5a47e42
                    _80a379cda203 = _2300218cba7e[_e60d3605a141:]
                else:
                    _7fd6abc35301  = _376ea5a47e42[_e60d3605a141:]
                    _80a379cda203 = _2300218cba7e[_e60d3605a141:]
                if _91ad5d84a36c not in _df03bff169fd:
                    _df03bff169fd._683f9fc99221(_91ad5d84a36c)

                if 'chunks_by_sid' not in _4e3fddc9b4c5():
                    _4a5cbc15e20e = _2a04b37f96c1(_f46b8b43bca0)
                _4a5cbc15e20e[_91ad5d84a36c]._683f9fc99221((_e6666c68f6f7, _5c92d3a19dc8, _7fd6abc35301, _80a379cda203))
            
        _3811ad66dcb2 = _655b08c5fe91
        _c3b97bd9d6b7 = _6e39b26f9db2._e902498b1682._a7605e18882f() if _6e39b26f9db2._e902498b1682._b9124b4a6065() else 0
        _148e1ad1b78f(f"[DEBUG rank={_6e39b26f9db2._e902498b1682._a7605e18882f()}] Missing sample_ids={[_91ad5d84a36c for _91ad5d84a36c in _ca2a711e29a6(0 if _6e39b26f9db2._e902498b1682._a7605e18882f() == 0 else 637, 637 if _6e39b26f9db2._e902498b1682._a7605e18882f() == 0 else 1274) if _91ad5d84a36c not in _df03bff169fd]}")
        for _91ad5d84a36c in _df03bff169fd:
            _9de2b0033d28 = _4a5cbc15e20e[_91ad5d84a36c]
            _148e1ad1b78f(f"[WARN] Rank {_c3b97bd9d6b7} Missing chunks sample_id={_91ad5d84a36c}, missing {_7d35ac0118df['num_chunks'][_9f1f0400de82] - _94a0187a3088(_9de2b0033d28)} chunks") if _0b0aa9575f71(_7d35ac0118df['sample_ids'][_9f1f0400de82] == _91ad5d84a36c and _7d35ac0118df['num_chunks'][_9f1f0400de82] > _94a0187a3088(_9de2b0033d28) for _7d35ac0118df in _1308de7b36c4 for _9f1f0400de82 in _ca2a711e29a6(_94a0187a3088(_7d35ac0118df['sample_ids']))) else _655b08c5fe91
            if _3811ad66dcb2 is _655b08c5fe91 and _94a0187a3088(_9de2b0033d28) > 1:
                _3811ad66dcb2 = _91ad5d84a36c
            _9de2b0033d28._d6e245509670(_337f2131952f=lambda _87de3915be94: _87de3915be94[0])
            _6d0f16ffd786 = _2a04b37f96c1(_f46b8b43bca0)
            _5af96713a7f5 = _2a04b37f96c1(_f46b8b43bca0)
            _f26da324325e = _2a04b37f96c1(_f46b8b43bca0)
            _0472dcf37303 = _2a04b37f96c1(_f46b8b43bca0)
            for _e6666c68f6f7, _ba2ee3cfd78c, _63eef50c5aa5, _646aff80fd11 in _9de2b0033d28:
                _f2432fc026c2 = {}
                _a2a8bf955f89 = {}
                _d694df7e5d4e = _655b08c5fe91
                _458786819eed = []
                _ae3498653ae2 = []
                for _bc03632dce31, _16811f7dd707, _92a850566e46 in _f32ebbba847c(_ba2ee3cfd78c, _63eef50c5aa5, _646aff80fd11):
                    _dfd63d4552c8 = _b07597fe40e6(_bc03632dce31)
                    if _dfd63d4552c8 >= 0:
                        if _dfd63d4552c8 != _d694df7e5d4e:
                            if _d694df7e5d4e is not _655b08c5fe91:
                                _f2432fc026c2[_d694df7e5d4e] = _458786819eed[:]
                                _a2a8bf955f89[_d694df7e5d4e] = _ae3498653ae2[:]
                            _d694df7e5d4e = _dfd63d4552c8
                            _458786819eed = [_b07597fe40e6(_16811f7dd707)]
                            _ae3498653ae2 = [_b07597fe40e6(_92a850566e46)]
                        else:
                            _458786819eed._683f9fc99221(_b07597fe40e6(_16811f7dd707))
                            _ae3498653ae2._683f9fc99221(_b07597fe40e6(_92a850566e46))
                    else:
                        if _d694df7e5d4e is not _655b08c5fe91:
                            _5af96713a7f5[_d694df7e5d4e]._683f9fc99221(_b07597fe40e6(_16811f7dd707))
                            _0472dcf37303[_d694df7e5d4e]._683f9fc99221(_b07597fe40e6(_92a850566e46))
                if _d694df7e5d4e is not _655b08c5fe91:
                    _f2432fc026c2[_d694df7e5d4e] = _458786819eed[:]
                    _a2a8bf955f89[_d694df7e5d4e] = _ae3498653ae2[:]
                for _317ac4415e54, _59efc816bd1c in _f2432fc026c2._9d8323b24593():
                    _6d0f16ffd786[_317ac4415e54]._683f9fc99221(_59efc816bd1c)
                    _f26da324325e[_317ac4415e54]._683f9fc99221(_a2a8bf955f89[_317ac4415e54])
            if not _6d0f16ffd786:
                continue
            _5612c171e091 = _a4ac10edb801(_6d0f16ffd786._9d47806043c6())
            _186065078dd7 = []
            _72388dab9f60 = []
            _3220e060268a = _f494b42310c7((_9b16eb33d504[0] for _9b16eb33d504, _9f1bd37cbc75 in self._222a93604bd8._9d8323b24593() if _9f1bd37cbc75 == 0), 3200)
            for _317ac4415e54 in _b0144b82b576(_6d0f16ffd786._9d47806043c6()):
                _ec2c4fef6bdb = _6d0f16ffd786[_317ac4415e54]
                _2dc9044a3ea4 = _f26da324325e[_317ac4415e54]
                _d561057eaf8d = _94a0187a3088(_2dc9044a3ea4[0])
                _e6a1f7e3779f = []
                for _f54161cfa7bf in _ca2a711e29a6(_d561057eaf8d):
                    _e94087b679d7 = [_f3ce050f7716[_f54161cfa7bf] for _f3ce050f7716 in _ec2c4fef6bdb if _f54161cfa7bf < _94a0187a3088(_f3ce050f7716)]
                    while _94a0187a3088(_e94087b679d7) < _94a0187a3088(_2dc9044a3ea4):
                        _e94087b679d7._683f9fc99221(_3220e060268a)
                    _1639adc69596 = _0f2b59681963(_e94087b679d7)._e53f501cd958(1)[0][0]
                    _e6a1f7e3779f._683f9fc99221(_1639adc69596)
                _186065078dd7._72953108d951(_e6a1f7e3779f[:_d561057eaf8d])
                _2451911d2ec3 = []
                for _f54161cfa7bf in _ca2a711e29a6(_d561057eaf8d):
                    _e94087b679d7 = [_f3ce050f7716[_f54161cfa7bf] for _f3ce050f7716 in _2dc9044a3ea4]
                    _1639adc69596 = _0f2b59681963(_e94087b679d7)._e53f501cd958(1)[0][0]
                    _2451911d2ec3._683f9fc99221(_1639adc69596)
                _72388dab9f60._72953108d951(_2451911d2ec3)
                if _317ac4415e54 < _5612c171e091:
                    _fac3138693ec = _5af96713a7f5[_317ac4415e54]
                    if _fac3138693ec:
                        _84baff4edd3c = _0f2b59681963(_fac3138693ec)._e53f501cd958(1)[0][0]
                        _186065078dd7._683f9fc99221(_84baff4edd3c)
                    _b6d949053f4a = _0472dcf37303[_317ac4415e54]
                    if _b6d949053f4a:
                        _b1f15850b1dc = _0f2b59681963(_b6d949053f4a)._e53f501cd958(1)[0][0]
                        _72388dab9f60._683f9fc99221(_b1f15850b1dc)
                    else:
                        _72388dab9f60._683f9fc99221(self._45cb1054b80e)
                        _186065078dd7._683f9fc99221(self._45cb1054b80e)
            _3220e060268a = _f494b42310c7((_9b16eb33d504[0] for _9b16eb33d504, _9f1bd37cbc75 in self._222a93604bd8._9d8323b24593() if _9f1bd37cbc75 == 0), 3200)
            _5f5a8b9ef54f = _1d376cad07ad(1 for _9f1f0400de82, _87de3915be94 in _672aea193df6(_72388dab9f60) if _87de3915be94 != self._45cb1054b80e and (_9f1f0400de82 == 0 or _72388dab9f60[_9f1f0400de82-1] == self._45cb1054b80e))
            _c57252803c71 = _1d376cad07ad(1 for _9f1f0400de82, _87de3915be94 in _672aea193df6(_186065078dd7) if _87de3915be94 != self._45cb1054b80e and (_9f1f0400de82 == 0 or _186065078dd7[_9f1f0400de82-1] == self._45cb1054b80e))
            if _c57252803c71 < _5f5a8b9ef54f:
                for _ in _ca2a711e29a6(_c57252803c71, _5f5a8b9ef54f):
                    if _94a0187a3088(_186065078dd7) > 0 and _186065078dd7[-1] != self._45cb1054b80e:
                        _186065078dd7._683f9fc99221(self._45cb1054b80e)
                    _186065078dd7._683f9fc99221(_3220e060268a)
            elif _c57252803c71 > _5f5a8b9ef54f:
                _0926aedce279 = []
                _4ece696a9b87 = 0
                for _9f1f0400de82, _bfddf5bc912b in _672aea193df6(_186065078dd7):
                    if _bfddf5bc912b != self._45cb1054b80e and (_9f1f0400de82 == 0 or _186065078dd7[_9f1f0400de82-1] == self._45cb1054b80e):
                        _4ece696a9b87 += 1
                    if _4ece696a9b87 <= _5f5a8b9ef54f:
                        _0926aedce279._683f9fc99221(_bfddf5bc912b)
                    elif _bfddf5bc912b == self._45cb1054b80e and _4ece696a9b87 == _5f5a8b9ef54f:
                        _0926aedce279._683f9fc99221(_bfddf5bc912b)
                        break
                _186065078dd7 = _0926aedce279

            _acd41b71465d[_91ad5d84a36c] = _6e39b26f9db2._1cdc812d94a5(_186065078dd7, _fcfd22e4e02c=_218e27d7844d)
            _d1136a10bf7a[_91ad5d84a36c] = _6e39b26f9db2._1cdc812d94a5(_72388dab9f60 if _72388dab9f60 else [self._ea33d091fa73] * _94a0187a3088(_186065078dd7), _fcfd22e4e02c=_218e27d7844d)

        if _746c8edb7feb and _3811ad66dcb2:
            _148e1ad1b78f(f"[SUMMARY] reconciled samples in batch = {_94a0187a3088(_df03bff169fd)} \
                  sid={_3811ad66dcb2} total_preds={_94a0187a3088(_acd41b71465d[_3811ad66dcb2])} total_labels={_94a0187a3088(_d1136a10bf7a[_3811ad66dcb2])} \
                    raw_preds {_acd41b71465d[_3811ad66dcb2]} and raw_labels{_d1136a10bf7a[_3811ad66dcb2]}\
                        chunks {_4a5cbc15e20e[_3811ad66dcb2]}")
        
        _70a060d51d39, _089c3014cc74 = self._75e7e5ea4def(_acd41b71465d, _d1136a10bf7a, _746c8edb7feb=_746c8edb7feb, _218e27d7844d=_218e27d7844d)
        
        if _746c8edb7feb and _3811ad66dcb2:
            _148e1ad1b78f(f"After Overlay [DEBUG sid={_3811ad66dcb2}] raw_preds={_acd41b71465d[_3811ad66dcb2]} and raw_labels={_d1136a10bf7a[_3811ad66dcb2]} and preds={_70a060d51d39[_3811ad66dcb2]} and labels={_089c3014cc74[_3811ad66dcb2]}")
        
        return _acd41b71465d, _d1136a10bf7a, _70a060d51d39, _089c3014cc74

    def _5b6133bfab22(self, _acd41b71465d, _d1136a10bf7a, _746c8edb7feb=_b44310a17910, _218e27d7844d="cpu"):
        _222a93604bd8 = _adebc65e1a18(self, "seq2class", {})
        _b1d3cde37a57 = _adebc65e1a18(self, "tokenizer_separator_token", _655b08c5fe91)
        _9640075cbece = _adebc65e1a18(self, "ignore_idx", -100)
        
        def _242a29a73bd8(_cc287a7aaccb, _5c96de102990):
            _710056fcb32f = []
            _d694df7e5d4e = []
            for _9f1f0400de82, token in _672aea193df6(_cc287a7aaccb):
                if token == _5c96de102990 and _d694df7e5d4e:
                    _710056fcb32f._683f9fc99221(_d694df7e5d4e)
                    _d694df7e5d4e = []
                elif token != _5c96de102990:
                    _d694df7e5d4e._683f9fc99221(token)
            if _d694df7e5d4e:
                _710056fcb32f._683f9fc99221(_d694df7e5d4e)
            return _710056fcb32f
        
        def _e7ccd4cde5a9(_2b42520793e7, _222a93604bd8, _746c8edb7feb, _91ad5d84a36c):
            _7d35ac0118df = []
            _edd91dfb7406 = _b0144b82b576(_222a93604bd8._9d47806043c6(), _337f2131952f=_94a0187a3088, _0796be898c3f=_b44310a17910)
            for _9f1f0400de82, _c1c32c66ff5e in _672aea193df6(_2b42520793e7, 1):
                _e06240e68ef4 = _28695ff1c377(_c1c32c66ff5e)
                _7f4ac632e42f = self._3cc38e23ecb3
                for _337f2131952f in _edd91dfb7406:
                    if _94a0187a3088(_e06240e68ef4) >= _94a0187a3088(_337f2131952f) and _e06240e68ef4[:_94a0187a3088(_337f2131952f)] == _337f2131952f:
                        _7f4ac632e42f = _222a93604bd8[_337f2131952f]
                        break
                _7d35ac0118df._683f9fc99221(_7f4ac632e42f)

            return _7d35ac0118df
        
        _10676b6d71b3, _551856388d3e = {}, {}
        for _91ad5d84a36c in _acd41b71465d:
            _bfddf5bc912b = _acd41b71465d[_91ad5d84a36c]
            _ca5d1268986c = _d1136a10bf7a._8fc8629368db(_91ad5d84a36c, _655b08c5fe91)
            _63eef50c5aa5 = _bfddf5bc912b._0c5cd36c74dd() if _6c54eb2d93e5(_bfddf5bc912b, _6e39b26f9db2._a3e1f82651b2) else _f46b8b43bca0(_bfddf5bc912b)
            _646aff80fd11 = _ca5d1268986c._0c5cd36c74dd() if _6c54eb2d93e5(_ca5d1268986c, _6e39b26f9db2._a3e1f82651b2) else _f46b8b43bca0(_ca5d1268986c) if _ca5d1268986c else _655b08c5fe91
            if _646aff80fd11 is not _655b08c5fe91:
                _5f5a8b9ef54f = _f0880048cc19(_646aff80fd11, _b1d3cde37a57)
                _e28170282597 = _11970f75db0e(_5f5a8b9ef54f, _222a93604bd8, _91ad5d84a36c == 1 or _746c8edb7feb, _91ad5d84a36c)
                _3be4aa5ee633 = _f0880048cc19(_63eef50c5aa5, _b1d3cde37a57)
                _800b602aef0b = _11970f75db0e(_3be4aa5ee633, _222a93604bd8, _91ad5d84a36c == 1 or _746c8edb7feb, _91ad5d84a36c)
                if _94a0187a3088(_800b602aef0b) < _94a0187a3088(_e28170282597):
                    _800b602aef0b += [0] * (_94a0187a3088(_e28170282597) - _94a0187a3088(_800b602aef0b))
                elif _94a0187a3088(_800b602aef0b) > _94a0187a3088(_e28170282597):
                    _800b602aef0b = _800b602aef0b[:_94a0187a3088(_e28170282597)]
            else:
                _3be4aa5ee633 = _f0880048cc19(_63eef50c5aa5, _b1d3cde37a57)
                _800b602aef0b = _11970f75db0e(_3be4aa5ee633, _222a93604bd8, _91ad5d84a36c == 1 or _746c8edb7feb, _91ad5d84a36c)
                _e28170282597 = [_9640075cbece] * _94a0187a3088(_800b602aef0b)
            _10676b6d71b3[_91ad5d84a36c] = _6e39b26f9db2._1cdc812d94a5(_800b602aef0b, _fcfd22e4e02c=_218e27d7844d, _81eae2d9aed2=_6e39b26f9db2._c5a8c8ad9775)
            _551856388d3e[_91ad5d84a36c] = _6e39b26f9db2._1cdc812d94a5(_e28170282597, _fcfd22e4e02c=_218e27d7844d, _81eae2d9aed2=_6e39b26f9db2._c5a8c8ad9775)
        return _10676b6d71b3, _551856388d3e

    def _d2a3b5c11f47(self, _445776b06522):
        _6e39b26f9db2._c7b2c8b51ec0._57ee5d612c0f._99e31217f79b(self._dbf7aaa35281(), _bf8e1f5afd17=1.0)
    
    def _9d5a47136b66(self, _445776b06522):
        for _69235d344bab in self._dbf7aaa35281():
            if _69235d344bab is not _655b08c5fe91:
                _69235d344bab._1d860a43cf3a._ce3d15796970(-5, 5)

    def _0dc702367605(self):
        _5333cf621b99 = 0
        for _69235d344bab in self._dbf7aaa35281():
            if _69235d344bab._4222a05285d8 is not _655b08c5fe91:
                _c9da55632f40 = _69235d344bab._4222a05285d8._e13d37e5c6e0()._1d860a43cf3a._721d4579b437(2)
                _5333cf621b99 += _c9da55632f40._81d1e7f4f2c1() ** 2
        return _5333cf621b99 ** 0.5  # L2 norm

    def _f132e3cbb267(self):
        _6e3f1ac42514 = [_bfddf5bc912b for _bfddf5bc912b in self._dbf7aaa35281() if _bfddf5bc912b._a151831100b0]
        if not _6e3f1ac42514:
            _148e1ad1b78f("No trainable parameters. Skipping optimizer creation.")
            return _655b08c5fe91
        
        _d030c5dc1734 = _5566f92754af(lambda _bfddf5bc912b: _bfddf5bc912b._a151831100b0, self._dbf7aaa35281())

        _a47438cfe338 = {
            "adamw": _6e39b26f9db2._61b6efc26579._b125c1f14a12,
            "adamax": _6e39b26f9db2._61b6efc26579._ab5e1148fc12,
            "adam": _6e39b26f9db2._61b6efc26579._74ae4a1ff689,
        }
        _2d05d5f5713c = _a47438cfe338._8fc8629368db(self._88636f00f7f4._da3fb4666307(), _6e39b26f9db2._61b6efc26579._74ae4a1ff689)

        _445776b06522 = _2d05d5f5713c(_d030c5dc1734, _447d9ad9ed6d=self._6fa512e11a62._447d9ad9ed6d, _a280c965a7fa=0.001)

        _6d65f9efad7f = self._b5d64b644f3a._61d4824bac41
        _873f4db305f5 = math._4ff832da5f6e(0.1 * _6d65f9efad7f)

        _3ce036e14e6f = _6e39b26f9db2._61b6efc26579._af7297c79ca6._4ec29f515d7a(_445776b06522, _ebc7bf6b76fe=lambda _af5bb8daefa7: (_af5bb8daefa7 + 1) / _873f4db305f5)

        _6e5e469c5fda = _6e39b26f9db2._61b6efc26579._af7297c79ca6._6f515ef07b86(
            _445776b06522,
            _98cd1955853f=_a4ac10edb801(1, _6d65f9efad7f - _873f4db305f5),
            _aa293e561b09=2,
            _f7646157fd80=1e-6
        )
        _af7297c79ca6 = _6e39b26f9db2._61b6efc26579._af7297c79ca6._7817a121ff75(
            _445776b06522,
            _c01816a9733b=[_3ce036e14e6f, _6e5e469c5fda],
            _95192767fd1d=[_873f4db305f5]
        )
        return {"optimizer": _445776b06522, "lr_scheduler": {"scheduler": _af7297c79ca6, "interval": "epoch", "monitor": "val_loss"}}
