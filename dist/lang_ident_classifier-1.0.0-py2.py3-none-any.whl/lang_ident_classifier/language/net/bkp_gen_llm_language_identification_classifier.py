# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _611746d10f7c
import copy
from _f8adb06229a3 import _179e7e7eae74
import _7cd46c3a0476
import math
import os
from typing import _f45978f77340
import _bed613227bd8 as _f29bcd984dd2
import _8b9c703b1e30 as _0dd673d8765a
import _39fe13e31267
import _0a16923d0f31 as _811c1cb6f22e
from _ffc251efee15._4e11745a831b._ef74b1f2fe7d._31a69d8030f6 import _298a4948d513
from _efb8e50dbf35 import _f2bb3031aa93, _e17537d3908e, _47d92e225208, _410ee4872ef7, _e52ef8b0784f

from _369f0b718477._8d7db716c1a7._014b65002b18._cbe30be4a983 import _11fd32d35771
from _369f0b718477._8d7db716c1a7._f9eca077ac0e._d6126f128b8a import _0b54533ae27d
from _369f0b718477._8d7db716c1a7._f9eca077ac0e._6506e0c9320c import _3bfb586f4683
from _369f0b718477._8d7db716c1a7._f9eca077ac0e._1368cdd960b8 import _6ea72d4f4156
from _369f0b718477._8d7db716c1a7._1e2d231b245d._fbaa16a3e968 import _befaecdd70d4
# expose only the classifier from the module
_3c4e5d4790b4 = ["GenLLMLanguageIdentificationClassifier"]

_fb0b7c838cc9 = 'cuda' if _39fe13e31267._be7d69560cc1._802eb0e47e6a() else 'cpu'
_3a78806721ca = _071ed420c21c  # global frozen embedding (kept for compatibility)

class _73936d950932(_811c1cb6f22e._d63452321491):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _a47164904e75(_39fe13e31267._98038833a40b._d877d8e53cd4):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _da3d22228006(self, _b407948b9c8c: _9bd75263d55c, _5f9b427719e0: _9bd75263d55c = 64):
            _15e93e50e5b6()._2b8df0a804a1()
            self._015d88c5a483 = _39fe13e31267._98038833a40b._b0cf8e9d8c11(_b407948b9c8c, _5f9b427719e0, _3746abf00e46=_100364afef71)
            self._893ca4138970 = _39fe13e31267._98038833a40b._eb52157c373e(_c107219767a8=_85ecf7a08589)
            self._ab3b00d40ff6 = _39fe13e31267._98038833a40b._b0cf8e9d8c11(_5f9b427719e0, _b407948b9c8c, _3746abf00e46=_100364afef71)
            # start adapter near-zero so initial behavior is identity
            _39fe13e31267._98038833a40b._a55f19d2b461._1d0dc0d381ef(self._ab3b00d40ff6._dc00a99685ed)
            _39fe13e31267._98038833a40b._a55f19d2b461._9551be4adfbb(self._015d88c5a483._dc00a99685ed, _bd3dc7959b0e=math._5608ba64fad3(5))

        def _25216b7b0e4d(self, _0b486840b8f1: _39fe13e31267._7f2895d47ff6) -> _39fe13e31267._7f2895d47ff6:
            # supports x shape (B, L, D) or (B, D)
            if _0b486840b8f1._b407948b9c8c() == 2:
                _50bd5fd211a6 = self._ab3b00d40ff6(self._893ca4138970(self._015d88c5a483(_0b486840b8f1)))
                return _0b486840b8f1 + _50bd5fd211a6
            _5b30ce4115e1, _0e76ef5ea09f, _9e9fa45572e8 = _0b486840b8f1._7299198f2135
            _addc93fc9512 = _0b486840b8f1._8a9c2705f402(-1, _9e9fa45572e8)                    # (B*L, D)
            _addc93fc9512 = self._ab3b00d40ff6(self._893ca4138970(self._015d88c5a483(_addc93fc9512)))  # (B*L, D)
            _addc93fc9512 = _addc93fc9512._8a9c2705f402(_5b30ce4115e1, _0e76ef5ea09f, _9e9fa45572e8)
            return _0b486840b8f1 + _addc93fc9512
        
    class _c09edf57a3fa(_39fe13e31267._98038833a40b._d877d8e53cd4):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _da3d22228006(self, _9e639f598808, _d540ec667f75=-5, _646c9d629681=5):
            _15e93e50e5b6()._2b8df0a804a1()
            self._9e639f598808 = _9e639f598808
            self._d540ec667f75 = _d540ec667f75
            self._646c9d629681 = _646c9d629681
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _25216b7b0e4d(self, *_8c3203b3bdb1, **_ca3589fa488f):
            _8c3203b3bdb1 = _041a9f264b7e(
                _4187eb5d6a8a._aca0d72d6383(_39fe13e31267._55c05ed9327a)._6d9cce1905d1(-10, 10) if _28e51846f321(_4187eb5d6a8a, _39fe13e31267._7f2895d47ff6) and _4187eb5d6a8a._08008bc1ec8d != _39fe13e31267._55c05ed9327a else _4187eb5d6a8a
                for _4187eb5d6a8a in _8c3203b3bdb1
            )
            for _466469080718, _4187eb5d6a8a in _f39d6fde7a2a(_8c3203b3bdb1):
                if _28e51846f321(_4187eb5d6a8a, _39fe13e31267._7f2895d47ff6) and not _39fe13e31267._538df19b5251(_4187eb5d6a8a)._88a38a2cdab4():
                    _4187eb5d6a8a = _39fe13e31267._019d38325b07(_4187eb5d6a8a)
            _42cc589a3bd6 = self._9e639f598808(*_8c3203b3bdb1, **_ca3589fa488f)
            if _28e51846f321(_42cc589a3bd6, _39fe13e31267._7f2895d47ff6):
                _42cc589a3bd6 = _42cc589a3bd6._aca0d72d6383(_39fe13e31267._55c05ed9327a)
                if not _39fe13e31267._538df19b5251(_42cc589a3bd6)._88a38a2cdab4():
                    _42cc589a3bd6 = _39fe13e31267._019d38325b07(_42cc589a3bd6)
                _42cc589a3bd6._e7ad1d5e59ed(self._d540ec667f75, self._646c9d629681)
            return _42cc589a3bd6

    # --- original __init__ signature and body preserved ---
    def _da3d22228006(
        self,
        _0d26360ea4e6,
        _a0e3aada039d,
        _f6f6ff3273db,
        _73c934a56c29,
        _7b3fba952881,
        _5315a727c8e9,
        _7ae64a51d74e,
        _cc9a92f8e890,
        _65f15fcfad66,
        _34f1ffb4c44c,
        _c2fa516feae1,
        _b443c1dc04e2: _9bd75263d55c = 20,
        _efef6e19aa93 = _071ed420c21c,
        _b09748ec99c1=_071ed420c21c,
        _ec34062453d6=0.9,
        _648cce91511c:_3bbe99a3c6a3=_071ed420c21c,
    ):
        _15e93e50e5b6(_36fdd55d9b73, self)._2b8df0a804a1()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._aee9b8363d5c({
            "lr": _672e56a4ffb5(_f6f6ff3273db),
            "optimizer": _3bbe99a3c6a3(_73c934a56c29),
            "num_backbone_model_units_unfrozen": _9bd75263d55c(_7ae64a51d74e),
            "loss_type": _3bbe99a3c6a3(_cc9a92f8e890),
            "is_train": _9d5262d8ef2c(_65f15fcfad66),
            "random_seed": _9bd75263d55c(_b443c1dc04e2),
        })
        self._b443c1dc04e2 = _b443c1dc04e2
        _811c1cb6f22e._59339ad43f46(_b443c1dc04e2, _ec83db8d8eb8=_85ecf7a08589)
        _39fe13e31267._c0ff7f90b9cb(_b443c1dc04e2)
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            _39fe13e31267._be7d69560cc1._428c0de2fc2d(_b443c1dc04e2)
        _f29bcd984dd2.random._0574cb3f30b5(_b443c1dc04e2)
        self._b09748ec99c1 = _9bd75263d55c(_b09748ec99c1) if _b09748ec99c1 is not _071ed420c21c else _071ed420c21c
        self._34f1ffb4c44c = _34f1ffb4c44c
        self._648cce91511c = _648cce91511c
        # TODO: REMOVE THIS HARDCODING
        if not self._34f1ffb4c44c._63e5aa9565a2:
            self._34f1ffb4c44c._63e5aa9565a2 = 128004  # <|finetune_right_pad_id|>
        self._eef5abce5772 = _34f1ffb4c44c._4ff662320650(" ", _f2a02b3ed855=_100364afef71)[0]
        self._4f88148cb368 = (
            _39fe13e31267._7326db126d68("cuda:{}"._ed24f3fd5178(_5315a727c8e9["gpu_local_rank"]))
            if _5315a727c8e9["gpu_local_rank"] != -1
            else "cpu"
        )
        self._efef6e19aa93 = _efef6e19aa93
        self._888cb6f90905 = _2c8049819e0e(_a0e3aada039d)
        self._ec34062453d6 = _ec34062453d6
        self._a0e3aada039d =  ["unk"] + _a0e3aada039d if self._ec34062453d6 > 0 else _a0e3aada039d
        self._8fb612c0c1d4 = {}
        for _0ca6706d18d6, _178ceca7bda3 in _f39d6fde7a2a(self._a0e3aada039d):
            _4b6f599ec2fd = self._34f1ffb4c44c._4ff662320650(_178ceca7bda3, _f2a02b3ed855=_100364afef71)
            self._8fb612c0c1d4[_0ca6706d18d6] = _4b6f599ec2fd
        self._f6ba21bcd4ec = {_041a9f264b7e(_4b6f599ec2fd): _32f2abcf3233 for _32f2abcf3233, _4b6f599ec2fd in self._8fb612c0c1d4._792d04858f19()}
        self._8d2d4919cdf4 = _611746d10f7c(_ceef1f2af457)
        for _bc6ec48c2cce, _4b6f599ec2fd in self._8fb612c0c1d4._792d04858f19():
            self._8d2d4919cdf4[_2c8049819e0e(_4b6f599ec2fd)]._e7cfb8207b93((_bc6ec48c2cce, _4b6f599ec2fd))
        self._255341d86151 = 0
        _c8620e49c8fc(f"SEQ {self._8fb612c0c1d4} and {self._f6ba21bcd4ec}")
        self._e6530549b081 = _34f1ffb4c44c._63e5aa9565a2 or _34f1ffb4c44c._cdb2bf1aed4f
        self._7b3fba952881 = _7b3fba952881
        self._a1a061927333 = "multiclass"
        self._357ca379c743 = -100
        self._1b22e1bc1eb5 = _34f1ffb4c44c._4ff662320650("assistant<|end_header_id|>\n\n", _f2a02b3ed855=_100364afef71)
        self._2104dc88a0e5 = self._52d7aee29eb0()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._c791a25d69e8 = _0d26360ea4e6
        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._c791a25d69e8._d2568e6f8d44(_100364afef71)
        _4ebfaa304147 = _befaecdd70d4()  # bfloat16 or float16

        for _3bad90dda9f7, _9e639f598808 in self._e92e11916cac():
            if not _22319902d17d(_fc6542d888aa._63de67bbc3aa for _fc6542d888aa in _9e639f598808._63bb9535d73e(_9658a347e8ca=_100364afef71)):
                # FROZEN → BF16 (save memory)
                _9e639f598808._aca0d72d6383(_08008bc1ec8d=_4ebfaa304147)
            else:
                # TRAINABLE → FP32 (stable grads)
                _9e639f598808._aca0d72d6383(_08008bc1ec8d=_39fe13e31267._55c05ed9327a)
        self._c791a25d69e8._aca0d72d6383(self._4f88148cb368)
        if _07693918b530(self._c791a25d69e8, "gradient_checkpointing_enable"):
            self._c791a25d69e8._5866b968ae24()
        # determine embedding dim robustly from model config if available
        _564dcb57a84c = _89565abf9e73(_89565abf9e73(self._c791a25d69e8, "config", _071ed420c21c), "hidden_size", _071ed420c21c)
        if _564dcb57a84c is _071ed420c21c:
            # fallback to common default — change if your model uses a different hidden size
            _564dcb57a84c = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _07693918b530(self._c791a25d69e8, "lm_head") and _89565abf9e73(self._c791a25d69e8, "lm_head") is not _071ed420c21c:
            self._e7b4773dc4ed = self._c791a25d69e8._46ba8778dd25
        else:
            _4e4db4aeb45f = _89565abf9e73(self._c791a25d69e8, "get_output_embeddings", _071ed420c21c)
            self._e7b4773dc4ed = _4e4db4aeb45f() if _428128684508(_4e4db4aeb45f) else _071ed420c21c

        # mark presence and ensure module (if any) is on the same device
        self._f3453b627be2 = self._e7b4773dc4ed is not _071ed420c21c
        if self._f3453b627be2:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._e7b4773dc4ed._aca0d72d6383(self._4f88148cb368)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._d55d0a51ef48 = self._8197a37ff7d5(_b407948b9c8c=_564dcb57a84c, _5f9b427719e0=64)
        self._d55d0a51ef48._aca0d72d6383(self._4f88148cb368)
        for _fc6542d888aa in self._d55d0a51ef48._63bb9535d73e():
            _fc6542d888aa._63de67bbc3aa = _85ecf7a08589
            
        if _7ae64a51d74e > 0:
            if "llama" in self._efef6e19aa93:
                for _9344e2accb79 in self._c791a25d69e8._63bb9535d73e():
                    if not _9344e2accb79._5597efcc15e3:
                        _9344e2accb79 = _9344e2accb79._90e0e66f060b()
                    _9344e2accb79._63de67bbc3aa = _100364afef71  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _f706059012ba = self._c791a25d69e8._d2b6f9cfb4af._39e4694a4cd1  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _b18b44383546 in _f706059012ba[-_7ae64a51d74e:]:
                    for _9344e2accb79 in _b18b44383546._63bb9535d73e():
                        if _28e51846f321(_9344e2accb79, _39fe13e31267._7f2895d47ff6) and (_9344e2accb79._b3c310efd249() or _39fe13e31267._9046ae27cab6(_9344e2accb79)):
                            _9344e2accb79._63de67bbc3aa = _85ecf7a08589
                if _07693918b530(self._c791a25d69e8, "lm_head"):
                    self._c791a25d69e8._46ba8778dd25._63de67bbc3aa = _85ecf7a08589

        self._76c057a5fc63 = 1
        _c8620e49c8fc(f"DEBUG xth_batch init {self._76c057a5fc63}")
        global _3a78806721ca
        _3a78806721ca = copy._eda0c53741e0(self._c791a25d69e8)._4a05a522774a()
        self._f6f6ff3273db = _f6f6ff3273db

        self._0679dc520b1c = {}
        self._5df625c29ab6 = {}

        # Loss function initialization
        if _cc9a92f8e890._1a57428fd627() == "class_weighted_cross_entropy_loss":
            self._5df625c29ab6['criterion'] = _3bfb586f4683(_7b3fba952881=self._7b3fba952881,
                                                            _7326db126d68=self._4f88148cb368,
                                                            _53ad4046d923=self._357ca379c743,
                                                            _69d78ebb999a=self._eef5abce5772)
        elif _cc9a92f8e890._1a57428fd627() == "focal_loss":
            self._5df625c29ab6['criterion'] = _6ea72d4f4156(_a7ddfb773b1d=0.25,
                                                     _7326db126d68=self._4f88148cb368,
                                                     _53ad4046d923=self._357ca379c743,
                                                     _69d78ebb999a=self._eef5abce5772)
        elif _cc9a92f8e890._1a57428fd627() == "class_weighted_focal_loss":
            self._5df625c29ab6['criterion'] = _6ea72d4f4156(_a7ddfb773b1d=self._7b3fba952881,
                                                     _7326db126d68=self._4f88148cb368,
                                                     _53ad4046d923=self._357ca379c743,
                                                     _69d78ebb999a=self._eef5abce5772)
        elif _cc9a92f8e890._1a57428fd627() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._5df625c29ab6['criterion'] = _0b54533ae27d(_a7ddfb773b1d=self._7b3fba952881,
                                                                      _e4410b541044='type1',
                                                                      _7326db126d68=self._4f88148cb368,
                                                                      _53ad4046d923=self._357ca379c743,
                                                                      _69d78ebb999a=self._eef5abce5772)
        elif _cc9a92f8e890._1a57428fd627() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._5df625c29ab6['criterion'] = _0b54533ae27d(_a7ddfb773b1d=self._7b3fba952881,
                                                                      _e4410b541044='type2',
                                                                      _7326db126d68=self._4f88148cb368,
                                                                      _53ad4046d923=self._357ca379c743,
                                                                      _69d78ebb999a=self._eef5abce5772)
        elif _cc9a92f8e890._1a57428fd627() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._5df625c29ab6['criterion'] = _0b54533ae27d(_a7ddfb773b1d=self._7b3fba952881,
                                                                      _e4410b541044='type3',
                                                                      _7326db126d68=self._4f88148cb368,
                                                                      _53ad4046d923=self._357ca379c743,
                                                                      _69d78ebb999a=self._eef5abce5772)
        else:
            self._5df625c29ab6['criterion'] = _3bfb586f4683(_7326db126d68=self._4f88148cb368,
                                                            _53ad4046d923=self._357ca379c743,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._b0c12367b2c5 = 0.99
        self._5451c188dcab = 0.3
        self._0486177fa40f = 0.30
        self._ca190272c13b = 0.25
        self._444e61f66bf8 = 0.6
        self._652a761d6b14 = 0.995
        self._6fdf9531819f = 0.60
        self._7771690118df = 0.20
        self._7755c1f07742 = _89565abf9e73(self, "batch_counter", 0)


        self._7246bde5c7d8 = []
        self._931c144bf6dd = []

        self._10b14e26f386 = _73c934a56c29._1a57428fd627()
        self._940077e24dd1()

        self._976aaa8b605c(self._c791a25d69e8)
    
    def _1c92908ef4da(self):
        # rebuild all metrics on the correct device
        self._0679dc520b1c['micro_accuracy'] = _f2bb3031aa93(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522="micro",
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['macro_accuracy'] = _f2bb3031aa93(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522="macro",
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['macro_precision'] = _47d92e225208(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522="macro",
            _9fd936f10892=self. _a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['macro_recall'] = _410ee4872ef7(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522="macro",
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['macro_f1'] = _e52ef8b0784f(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522="macro",
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['classwise_accuracy'] = _f2bb3031aa93(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522=_071ed420c21c,
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['classwise_precision'] = _47d92e225208(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522=_071ed420c21c,
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['classwise_recall'] = _410ee4872ef7(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522=_071ed420c21c,
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['classwise_f1'] = _e52ef8b0784f(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _86789a42b522=_071ed420c21c,
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)

        self._0679dc520b1c['confmat'] = _e17537d3908e(
            _888cb6f90905=_2c8049819e0e(self._a0e3aada039d),
            _9fd936f10892=self._a1a061927333,
            _53ad4046d923=self._357ca379c743,
        )._aca0d72d6383(self._4f88148cb368)


    def _09179bd9d77d(self, _62f39e2f7f31=_071ed420c21c):
        """Calculate batch counts and set xth_batch_to_consider."""
        _367e2241970b = 0
        _4ee06f725d83 = 0
        if self._197958a0e018._1b0f077f9e69 is not _071ed420c21c:
            if _07693918b530(self._197958a0e018._1b0f077f9e69, 'train_dataset') and self._197958a0e018._1b0f077f9e69._227f23e6f15d is not _071ed420c21c:
                _367e2241970b = _2c8049819e0e(self._197958a0e018._1b0f077f9e69._227f23e6f15d)
            if _07693918b530(self._197958a0e018._1b0f077f9e69, 'val_dataset') and self._197958a0e018._1b0f077f9e69._f67b9fcb2291 is not _071ed420c21c:
                _4ee06f725d83 = _2c8049819e0e(self._197958a0e018._1b0f077f9e69._f67b9fcb2291)
            _ccff47832171 = self._197958a0e018._1b0f077f9e69._ccff47832171
            _f4ca302cd140 = (_367e2241970b + _ccff47832171 - 1) // _ccff47832171 if _367e2241970b > 0 else 1
            _0d65777581ed = (_4ee06f725d83 + _ccff47832171 - 1) // _ccff47832171 if _4ee06f725d83 > 0 else 1
            _0ecd9f04a962 = _c8530dbc4c56(_f4ca302cd140, _0d65777581ed) if _4ee06f725d83 > 0 else _f4ca302cd140
            _c10d9a9f7360 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._76c057a5fc63 = 1
            _c8620e49c8fc(f"DEBUG Batch Info: num_train_batches={_f4ca302cd140}, num_val_batches={_0d65777581ed}, xth_batch_to_consider={self._76c057a5fc63}")

    def _bc795b166137(self, _d962277dbf6a, _4e2a8bbf8e38):
        if _d962277dbf6a._1a57428fd627() == "parametric_relu":
            return _39fe13e31267._98038833a40b._60a6fe4073b1(_4e2a8bbf8e38=1)
        elif _d962277dbf6a._1a57428fd627() == "leaky_relu":
            return _39fe13e31267._98038833a40b._4f610a6cba3d(_c107219767a8=_100364afef71)
        else:
            return _39fe13e31267._98038833a40b._eb52157c373e(_c107219767a8=_100364afef71)

    def _6c7123271d1e(self, _9e639f598808, _1cba0ae72d87=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _3bad90dda9f7, _a86298b8e50e in _9e639f598808._d03ca8afe1ed():
            _4d6bcfaa4499 = f"{_1cba0ae72d87}.{_3bad90dda9f7}" if _1cba0ae72d87 else _3bad90dda9f7

            def _1d8bfedea67a(_8ba31df31607, _4187eb5d6a8a, _50bd5fd211a6):
                if _28e51846f321(_50bd5fd211a6, _39fe13e31267._7f2895d47ff6) and _50bd5fd211a6._d28d776211eb()._22319902d17d():
                    _c8620e49c8fc(f"NaN detected in {_4d6bcfaa4499} ({_8ba31df31607._5b13e5c3f7d8.__name__}) ({_50bd5fd211a6._08008bc1ec8d})")

            _a86298b8e50e._3f9f6d25e664(_8dafbe870d37)

            self._976aaa8b605c(_a86298b8e50e, _4d6bcfaa4499)

    def _f759b20c51ac(self, _9e639f598808):
        return _22319902d17d(_fc6542d888aa._63de67bbc3aa for _fc6542d888aa in _9e639f598808._63bb9535d73e())

    def _2b3def32bd78(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _b9d3fb026211 = []
        for _3bad90dda9f7, _9e639f598808 in self._e92e11916cac():
            if not self._1d08f45b9b70(_9e639f598808):
                continue
            _769aacaca454 = (
                "norm" in _3bad90dda9f7._e921527443d1() or 
                "linear4bit" in _3bad90dda9f7._e921527443d1() or 
                _22319902d17d(_893ca4138970 in _3bad90dda9f7._e921527443d1() for _893ca4138970 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _3bad90dda9f7._e921527443d1() or 
                "dropout" in _3bad90dda9f7._e921527443d1() or 
                _28e51846f321(_9e639f598808, (_298a4948d513, _39fe13e31267._98038833a40b._b0cf8e9d8c11, _39fe13e31267._98038833a40b._ce2ba0e1a0e9))
            )
            if _769aacaca454:
                if _07693918b530(_9e639f598808, "eps"):
                    _9e639f598808._17130e4ca343 = 1e-3
                _9e639f598808 = _9e639f598808._aca0d72d6383(_39fe13e31267._55c05ed9327a)
                if not _28e51846f321(_9e639f598808, _36fdd55d9b73._e06ae0507455):
                    _b9d3fb026211._e7cfb8207b93((_3bad90dda9f7, _36fdd55d9b73._e06ae0507455(_9e639f598808, _d540ec667f75=-10, _646c9d629681=10)))
        for _3bad90dda9f7, _c807f19c402e in _b9d3fb026211:
            _16d9787cce84, _eb46ba591f6a = self._ef9fa3951fc9(_3bad90dda9f7)
            if _16d9787cce84 is not _071ed420c21c:
                _6b1f8d4a0e14(_16d9787cce84, _eb46ba591f6a, _c807f19c402e)

    def _27789e223f40(self, _ddd50c7ec9c2):
        """Finds the parent module and attribute name given the full module path."""
        _3a208f99e560 = _ddd50c7ec9c2._6b74aab47746('.')
        _313422753b7b = self
        for _ec3107f1c3ea in _3a208f99e560[:-1]:
            _313422753b7b = _89565abf9e73(_313422753b7b, _ec3107f1c3ea, _071ed420c21c)
            if _313422753b7b is _071ed420c21c:
                return _071ed420c21c, _071ed420c21c
        return _313422753b7b, _3a208f99e560[-1]

    def _909409e29b76(self, _107e3fd6c232: _39fe13e31267._7f2895d47ff6, _f34c3fd91c79: _39fe13e31267._7f2895d47ff6, _561fceb74eda: _39fe13e31267._7f2895d47ff6) -> _bc2587e93f14:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _7326db126d68 = _107e3fd6c232._7326db126d68

        # 1) gating w (use cached per-example teacher_conf if available)
        _b7389b2fb883 = _89565abf9e73(self, "_last_teacher_conf", _071ed420c21c)
        if _b7389b2fb883 is _071ed420c21c:
            # no teacher info => w = 0 (no distillation)
            _8444f00b1173 = 0.0
        else:
            _641da0515c13 = (_b7389b2fb883 >= _672e56a4ffb5(_89565abf9e73(self, "teacher_conf_tau", 0.6)))._672e56a4ffb5()
            _8444f00b1173 = _672e56a4ffb5(_641da0515c13._ac121bf66001()._661038bb1938()._a5e06781c255()) if _641da0515c13._d3d639b59b43() > 0 else 0.0

        # apply gating to the batch scalars
        _49f31309179a = _f34c3fd91c79 * _672e56a4ffb5(_8444f00b1173)
        _477f6690e456 = _561fceb74eda * _672e56a4ffb5(_8444f00b1173)

        # 2) EMAs for autoscaling
        _55d35273072b = _672e56a4ffb5((_49f31309179a + _477f6690e456)._90e0e66f060b()._661038bb1938()._a5e06781c255())
        _4d134b337e3a = _672e56a4ffb5(_107e3fd6c232._90e0e66f060b()._661038bb1938()._a5e06781c255())
        if _89565abf9e73(self, "ema_task", _071ed420c21c) is _071ed420c21c:
            self._f271a7ed1168 = _4d134b337e3a
            self._9686af8588f1 = _55d35273072b + 1e-12
        else:
            _a7ddfb773b1d = _672e56a4ffb5(_89565abf9e73(self, "ema_alpha", 0.99))
            self._f271a7ed1168 = _a7ddfb773b1d * _672e56a4ffb5(self._f271a7ed1168) + (1.0 - _a7ddfb773b1d) * _4d134b337e3a
            self._9686af8588f1  = _a7ddfb773b1d * _672e56a4ffb5(self._9686af8588f1)  + (1.0 - _a7ddfb773b1d) * _55d35273072b

        _b86612ab3c94 = _672e56a4ffb5(_89565abf9e73(self, "distill_target_ratio", 0.3))
        _d3239ab0c9b6 = (_672e56a4ffb5(self._f271a7ed1168) / (_672e56a4ffb5(self._9686af8588f1) + 1e-12)) * _b86612ab3c94
        _6fc97a036d96 = _672e56a4ffb5(_d3239ab0c9b6)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _315f2219a59f = _672e56a4ffb5(_89565abf9e73(self._197958a0e018, "current_epoch", _89565abf9e73(self._197958a0e018, "global_step", 0.0)))
        _6d0cd0807ecb = _672e56a4ffb5(_5b3b2d77198b(1, _89565abf9e73(self._197958a0e018, "max_epochs", 1)))
        _a6c68bcd2fbd = _c8530dbc4c56(_5b3b2d77198b(_315f2219a59f / _6d0cd0807ecb, 0.0), 1.0)
        _98ff0cd4c065 = 0.30
        _61002047f8db = _672e56a4ffb5(_89565abf9e73(self, "kl_base", 0.30)) * _c8530dbc4c56(_a6c68bcd2fbd / _98ff0cd4c065, 1.0)
        _ca190272c13b = _672e56a4ffb5(_89565abf9e73(self, "cos_base", 0.25))
        _4bde4b9b7564 = _ca190272c13b + (0.10 - _ca190272c13b) * _a6c68bcd2fbd

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _8216e81056f4 = _672e56a4ffb5(self._e5df37e2a15d._ac121bf66001()._661038bb1938()._a5e06781c255()) if _89565abf9e73(self, "_last_teacher_conf", _071ed420c21c) is not _071ed420c21c else 0.0
        if _89565abf9e73(self, "ema_teacher_conf", _071ed420c21c) is _071ed420c21c:
            self._a01528990852 = _8216e81056f4
        else:
            _5b30ce4115e1 = _672e56a4ffb5(_89565abf9e73(self, "teacher_conf_beta", 0.995))
            self._a01528990852 = _5b30ce4115e1 * _672e56a4ffb5(self._a01528990852) + (1.0 - _5b30ce4115e1) * _8216e81056f4

        _6fdf9531819f = _672e56a4ffb5(_89565abf9e73(self, "tau_warn", 0.60))
        _7771690118df = _672e56a4ffb5(_89565abf9e73(self, "tau_detect", 0.20))
        _e7d09e084f21 = _5b3b2d77198b(1e-12, (_6fdf9531819f - _7771690118df))
        _8ebd6695b759 = (_672e56a4ffb5(self._a01528990852) - _7771690118df) / _e7d09e084f21
        _8ebd6695b759 = _5b3b2d77198b(0.0, _c8530dbc4c56(1.0, _8ebd6695b759))

        _3cb432407ced = _61002047f8db * _8ebd6695b759
        _8f1a0df61994 = _4bde4b9b7564 * _8ebd6695b759

        # 5) final aux term
        _b6fb424762df = _39fe13e31267._28329e03fb59(0.0, _7326db126d68=_7326db126d68)
        _b6fb424762df = _b6fb424762df + (_3cb432407ced * _49f31309179a + _8f1a0df61994 * _477f6690e456) * _672e56a4ffb5(_6fc97a036d96)

        # diagnostics
        _50bd5fd211a6 = {
            "aux_term": _b6fb424762df,
            "kl_batch": _f34c3fd91c79,
            "contrast_batch": _561fceb74eda,
            "kl_loss": _49f31309179a,
            "contrastive_loss": _477f6690e456,
            "w_mean": _8444f00b1173,
            "aux_scale": _672e56a4ffb5(_6fc97a036d96),
            "lambda_kl_eff": _672e56a4ffb5(_3cb432407ced),
            "lambda_cos_eff": _672e56a4ffb5(_8f1a0df61994),
            "teacher_conf_mean": _672e56a4ffb5(self._a01528990852),
            "shift_r": _672e56a4ffb5(_8ebd6695b759)
        }
        return _50bd5fd211a6

    def _25216b7b0e4d(self, _de2e11691097):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _de2e11691097 = _de2e11691097._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)
        _27774fa3be19 = (_de2e11691097 != self._34f1ffb4c44c._63e5aa9565a2)._aca0d72d6383(_08008bc1ec8d=_39fe13e31267._9d5262d8ef2c, _7326db126d68=self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)

        # model forward (request hidden states)
        _eb138dd254c4 = self._c791a25d69e8(
            _de2e11691097=_de2e11691097,
            _27774fa3be19=_27774fa3be19,
            _5b1b629bc2f0=_85ecf7a08589,
            _3c7af8934745=_85ecf7a08589,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _3b697c46af0e = _89565abf9e73(_eb138dd254c4, "last_hidden_state", _071ed420c21c)
        if _3b697c46af0e is _071ed420c21c:
            _3b697c46af0e = _eb138dd254c4._e3caba455890[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _3b697c46af0e._08008bc1ec8d != _39fe13e31267._55c05ed9327a:
            _3b697c46af0e = _3b697c46af0e._aca0d72d6383(_39fe13e31267._55c05ed9327a)
        _61bc4838d957 = self._d55d0a51ef48(_3b697c46af0e)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._f3453b627be2:
            _9ae927bfe207 = self._e7b4773dc4ed(_61bc4838d957)
        else:
            _9ae927bfe207 = _eb138dd254c4._9ae927bfe207


        _9ae927bfe207 = _9ae927bfe207._aca0d72d6383(_39fe13e31267._55c05ed9327a)._6d9cce1905d1(-20, 20)

        # default zero scalars
        _49f31309179a = _39fe13e31267._28329e03fb59(0.0, _7326db126d68=self._4f88148cb368)
        _477f6690e456 = _39fe13e31267._28329e03fb59(0.0, _7326db126d68=self._4f88148cb368)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _904fdb186478 = _89565abf9e73(self, "trainer", _071ed420c21c)
        _64fda3b01a4d = _100364afef71
        if _904fdb186478 is not _071ed420c21c:
            _64fda3b01a4d = _9d5262d8ef2c(_89565abf9e73(self._197958a0e018, "training", _100364afef71) or _89565abf9e73(self._197958a0e018, "validating", _100364afef71))

        if _64fda3b01a4d and (_89565abf9e73(self, "batch_counter", 0) % _89565abf9e73(self, "xth_batch_to_consider", 1) == 0):
            with _39fe13e31267._634e6905302d():
                _2b66ab4577b6 = _3a78806721ca(
                    _de2e11691097=_de2e11691097,
                    _27774fa3be19=_27774fa3be19,
                    _5b1b629bc2f0=_85ecf7a08589,
                    _3c7af8934745=_85ecf7a08589,
                )
                _16b1a82dc668 = _89565abf9e73(_2b66ab4577b6, "last_hidden_state", _071ed420c21c)
                if _16b1a82dc668 is _071ed420c21c:
                    _16b1a82dc668 = _2b66ab4577b6._e3caba455890[-1]

            # compute embedding-level KL + contrastive (scalar)
            _49f31309179a, _477f6690e456 = self._e5d10c84768a(_61bc4838d957, _16b1a82dc668, _7326db126d68=self._4f88148cb368)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _7ff04d733d56(_0b486840b8f1): return _0b486840b8f1._ac121bf66001(_b407948b9c8c=1) if _0b486840b8f1._b407948b9c8c() == 3 else _0b486840b8f1
            _b0f2a51668f9 = _39fe13e31267._98038833a40b._ff96aac34e83._b334002e6168(_07a7e69d3e00(_61bc4838d957), _fc6542d888aa=2, _b407948b9c8c=-1, _17130e4ca343=1e-6)
            _84ffaa52e604 = _39fe13e31267._98038833a40b._ff96aac34e83._b334002e6168(_07a7e69d3e00(_16b1a82dc668), _fc6542d888aa=2, _b407948b9c8c=-1, _17130e4ca343=1e-6)
            _fada81badd04 = _39fe13e31267._98038833a40b._ff96aac34e83._8bf3d0eb840e(_b0f2a51668f9, _84ffaa52e604, _b407948b9c8c=-1)  # [-1,1]
            _b7389b2fb883 = _fada81badd04._6d9cce1905d1(_c8530dbc4c56=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._6ea78c2b0360 = _61bc4838d957._90e0e66f060b()
            self._fb2b4e4a017c = _16b1a82dc668._90e0e66f060b()
            self._e5df37e2a15d = _b7389b2fb883._90e0e66f060b()  # shape (B,)

        # increment counter
        self._7755c1f07742 = _89565abf9e73(self, "batch_counter", 0) + 1

        return _9ae927bfe207, _49f31309179a, _477f6690e456


    def _a7990a5dd7d9(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _fb00f2ded890(_9e639f598808, _8c3203b3bdb1, _cdc762daf50c):
            if _22319902d17d(_4187eb5d6a8a._08008bc1ec8d == _39fe13e31267._2bb2fc98e81a for _4187eb5d6a8a in _8c3203b3bdb1 if _28e51846f321(_4187eb5d6a8a, _39fe13e31267._7f2895d47ff6)):
                _c8620e49c8fc(f"Layer {_9e639f598808._5b13e5c3f7d8.__name__} is using float16!")

        for _37f78558705e in self._38b15b18d1c3():
            _731d7d0001d8 = _37f78558705e._3f9f6d25e664(_cf43ed8e8627)
            self._b92bcc57b291._e7cfb8207b93(_731d7d0001d8)

    def _93daf500a920(self):
        """Remove all registered forward hooks."""
        for _731d7d0001d8 in _89565abf9e73(self, "amp_hooks", []):
            _731d7d0001d8._67b251080ef6()
        self._b92bcc57b291 = []

    def _594888917544(self, _de2e11691097, _26ae06722b1e, _69b3d8b4970c):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _eb4016d4261b = [self._34f1ffb4c44c._e602a8423a67(_3cd52d62cfb1) for _3cd52d62cfb1 in _de2e11691097]
        _d624e6dae405, _d765a629b178 = [], []

        for _0a1cc1922e5d, _0c4b88900ab8, _9bfa638d90b7 in _43f4521b7131(_eb4016d4261b, _26ae06722b1e, _69b3d8b4970c):
            for token, _a39bc2d50b6e, _839fb0592a3b in _43f4521b7131(_0a1cc1922e5d, _0c4b88900ab8, _9bfa638d90b7):
                if token == self._34f1ffb4c44c._d02c0f91575c or _839fb0592a3b == self._357ca379c743:
                    continue

                _eaeaad7b710d = (
                    token._ac22fedfa8cc("##") or
                    token._ac22fedfa8cc("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _eaeaad7b710d:
                    continue

                _d624e6dae405._e7cfb8207b93(_a39bc2d50b6e._a5e06781c255())
                _d765a629b178._e7cfb8207b93(_839fb0592a3b._a5e06781c255())

        return _39fe13e31267._28329e03fb59(_d624e6dae405), _39fe13e31267._28329e03fb59(_d765a629b178)

    def _cd95662b3431(self):
        _891ef326150f = _39fe13e31267._55c05ed9327a
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            _82771e9bbca9, _8c939f3d20cc = _39fe13e31267._be7d69560cc1._4cbb6bc6cfeb()
            if _82771e9bbca9 >= 8:
                _891ef326150f = _39fe13e31267._e218cf192156
            else:
                _891ef326150f = _39fe13e31267._2bb2fc98e81a
        return _891ef326150f

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _952c5d268fe8(
        self,
        _2903b9faa48f: _39fe13e31267._7f2895d47ff6,
        _2800c583544e: _39fe13e31267._7f2895d47ff6,
        _7326db126d68: _3bbe99a3c6a3 = "cpu",
    ) -> _f45978f77340[_39fe13e31267._7f2895d47ff6, _39fe13e31267._7f2895d47ff6]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _113e71ae41b9 = 2.0
            # NaN/Inf guard
            _2903b9faa48f = _2903b9faa48f._6d9cce1905d1(_c8530dbc4c56=-30, _5b3b2d77198b=30)
            _2800c583544e = _2800c583544e._6d9cce1905d1(_c8530dbc4c56=-30, _5b3b2d77198b=30)

            # Move once if needed
            _adefd22af485 = _39fe13e31267._7326db126d68(_7326db126d68)
            if _2903b9faa48f._7326db126d68 != _adefd22af485:
                _2903b9faa48f = _2903b9faa48f._aca0d72d6383(_7326db126d68=_adefd22af485, _16f0af4e6e6b=_85ecf7a08589, _08008bc1ec8d=self._2104dc88a0e5)
                _2800c583544e = _2800c583544e._aca0d72d6383(_7326db126d68=_adefd22af485, _16f0af4e6e6b=_85ecf7a08589, _08008bc1ec8d=self._2104dc88a0e5)

            _ccff47832171 = _2903b9faa48f._ea7c472c03c8(0)
            _564dcb57a84c = _2903b9faa48f._ea7c472c03c8(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _48a1af35f4f9 = (_ccff47832171 * _564dcb57a84c) > 32_000_000

            if not _48a1af35f4f9 or _ccff47832171 <= 8:
                # Direct computation
                _9be33638a4e6 = _39fe13e31267._98038833a40b._ff96aac34e83._b4dfb09a6534(_2903b9faa48f / _113e71ae41b9, _b407948b9c8c=-1)
                _28ee8e78e225 = _39fe13e31267._98038833a40b._ff96aac34e83._f3229950562a(_2800c583544e / _113e71ae41b9, _b407948b9c8c=-1)
                _49f31309179a = _39fe13e31267._98038833a40b._ff96aac34e83._d5acd2fec22b(_9be33638a4e6, _28ee8e78e225, _32f130905360="batchmean") * (_113e71ae41b9 * _113e71ae41b9)
                _477f6690e456 = 1 - _39fe13e31267._98038833a40b._ff96aac34e83._8bf3d0eb840e(_2903b9faa48f, _2800c583544e, _b407948b9c8c=-1)._ac121bf66001()
                return _49f31309179a, _477f6690e456

            # Chunked mode for large inputs
            _d23496102f6b = _5b3b2d77198b(1, _ccff47832171 // 8)
            _1f7b9e87298b, _22641cce5f25 = [], []

            for _466469080718 in _336ed066e4bd(0, _ccff47832171, _d23496102f6b):
                _351baa9f952e = _2903b9faa48f[_466469080718:_466469080718 + _d23496102f6b]
                _708ba3c2c008 = _2800c583544e[_466469080718:_466469080718 + _d23496102f6b]

                _9be33638a4e6 = _39fe13e31267._98038833a40b._ff96aac34e83._b4dfb09a6534(_351baa9f952e / _113e71ae41b9, _b407948b9c8c=-1)
                _28ee8e78e225 = _39fe13e31267._98038833a40b._ff96aac34e83._f3229950562a(_708ba3c2c008 / _113e71ae41b9, _b407948b9c8c=-1)

                _3a16099448ed = _39fe13e31267._98038833a40b._ff96aac34e83._d5acd2fec22b(_9be33638a4e6, _28ee8e78e225, _32f130905360="batchmean") * (_113e71ae41b9 * _113e71ae41b9)
                _841173b77459 = _39fe13e31267._98038833a40b._ff96aac34e83._8bf3d0eb840e(_351baa9f952e, _708ba3c2c008, _b407948b9c8c=-1)._ac121bf66001()
                _bd0d1df74f13 = 1 - _841173b77459

                _1f7b9e87298b._e7cfb8207b93(_3a16099448ed)
                _22641cce5f25._e7cfb8207b93(_bd0d1df74f13)

            _49f31309179a = _39fe13e31267._42dc4b387628(_1f7b9e87298b)._ac121bf66001()
            _477f6690e456 = _39fe13e31267._42dc4b387628(_22641cce5f25)._ac121bf66001()
            return _49f31309179a, _477f6690e456

        except _fb74352f99f1 as _26c80111d50c:
            raise _7587f8a9200e(f"KL/contrastive loss computation failed: {_3bbe99a3c6a3(_26c80111d50c)}")


    def _49190bb3957e(self, _8adfdcb876cb, _2bc1abc86149):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _de2e11691097 = _8adfdcb876cb["input_ids"]
            _e49f08d77dde = _8adfdcb876cb["labels"]
            _8e5677c2f638 = _8adfdcb876cb._3813eef240c1("prompt_lens", _071ed420c21c)
            _ccff47832171 = _de2e11691097._ea7c472c03c8(0)

            # move to device
            _de2e11691097 = _de2e11691097._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)
            _e49f08d77dde = _e49f08d77dde._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _cdc762daf50c, _f34c3fd91c79, _561fceb74eda = self(_de2e11691097)

            # causal LM shift for next-token classification (unchanged)
            _c3a94283a683 = _cdc762daf50c[:, :-1, :]._30c371af826a()
            _57b9ea9879bb = _e49f08d77dde[:, 1:]._30c371af826a()
            _a20e9aa177ba = _c3a94283a683._8a9c2705f402(-1, _c3a94283a683._ea7c472c03c8(-1))
            _2ed0fdb6c2d3 = _57b9ea9879bb._8a9c2705f402(-1)

            # classification/task loss
            _1ffa2a6901ae = self._5df625c29ab6['criterion'](_a20e9aa177ba, _2ed0fdb6c2d3)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _f34c3fd91c79 = _39fe13e31267._019d38325b07(_f34c3fd91c79, _c155d89691f1=0.0, _cfac64a0e130=0.0, _4f5d85e092c7=0.0)
            _561fceb74eda = _39fe13e31267._019d38325b07(_561fceb74eda, _c155d89691f1=0.0, _cfac64a0e130=0.0, _4f5d85e092c7=0.0)
            _1ffa2a6901ae = _39fe13e31267._019d38325b07(_1ffa2a6901ae, _c155d89691f1=0.0, _cfac64a0e130=0.0, _4f5d85e092c7=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _c2b53c5a4d1e = self._3d756fab8a8f(_1ffa2a6901ae, _f34c3fd91c79, _561fceb74eda)
            _b6fb424762df = _c2b53c5a4d1e["aux_term"]

            # final combined loss (single-equation)
            _d9970b2a4db2 = _1ffa2a6901ae + _b6fb424762df

            # Optional NaN print as before (keeps your original check)
            if _39fe13e31267._d28d776211eb(_1ffa2a6901ae):
                _c8620e49c8fc(f"Step {_2bc1abc86149}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _ed8aac1519e7 = {
                "epoch": _672e56a4ffb5(_89565abf9e73(self, "current_epoch", _89565abf9e73(self._197958a0e018, "current_epoch", 0))),
                "train_kl_loss": _c2b53c5a4d1e._3813eef240c1("kl_loss", _f34c3fd91c79)._90e0e66f060b() if _28e51846f321(_c2b53c5a4d1e._3813eef240c1("kl_loss", _f34c3fd91c79), _39fe13e31267._7f2895d47ff6) else _c2b53c5a4d1e._3813eef240c1("kl_loss", _f34c3fd91c79),
                "train_contrastive_loss": _c2b53c5a4d1e._3813eef240c1("contrastive_loss", _561fceb74eda)._90e0e66f060b() if _28e51846f321(_c2b53c5a4d1e._3813eef240c1("contrastive_loss", _561fceb74eda), _39fe13e31267._7f2895d47ff6) else _c2b53c5a4d1e._3813eef240c1("contrastive_loss", _561fceb74eda),
                "train_classification_loss": _1ffa2a6901ae._90e0e66f060b(),
                "train_loss": _d9970b2a4db2._90e0e66f060b(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _672e56a4ffb5(_89565abf9e73(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _c2b53c5a4d1e._3813eef240c1("lambda_kl_eff", _672e56a4ffb5(_89565abf9e73(self, "kl_base", 0.30))),
                "train_lambda_contrast": _c2b53c5a4d1e._3813eef240c1("lambda_cos_eff", _672e56a4ffb5(_89565abf9e73(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _b28c677309d4 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _b28c677309d4 in _c2b53c5a4d1e:
                    _dd8ca888a88f = _c2b53c5a4d1e[_b28c677309d4]
                    # convert single-element tensors to python floats for logging
                    if _28e51846f321(_dd8ca888a88f, _39fe13e31267._7f2895d47ff6) and _dd8ca888a88f._d3d639b59b43() == 1:
                        _ed8aac1519e7[f"train_{_b28c677309d4}"] = _672e56a4ffb5(_dd8ca888a88f._90e0e66f060b()._661038bb1938()._a5e06781c255())
                    else:
                        _ed8aac1519e7[f"train_{_b28c677309d4}"] = _dd8ca888a88f

            # log exactly like you did
            self._8db36f23395f(
                _ed8aac1519e7,
                _ccff47832171=_ccff47832171,
                _8303142e5325=_100364afef71,
                _efe69eabf253=_85ecf7a08589,
                _03559d27c9a9=_100364afef71,
                _bc0b096fff77=_85ecf7a08589,
                _6724d75b12d6=_85ecf7a08589,
            )

            # free references as you did
            del _de2e11691097, _e49f08d77dde, _cdc762daf50c, _f34c3fd91c79, _1ffa2a6901ae, _561fceb74eda, _57b9ea9879bb, _c3a94283a683, _2ed0fdb6c2d3, _a20e9aa177ba

            return _d9970b2a4db2

        except _fb74352f99f1 as _26c80111d50c:
            raise _7587f8a9200e(f"Error in training_step: {_26c80111d50c}") from _26c80111d50c

    def _e86c5b79e326(self):
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            _39fe13e31267._be7d69560cc1._4f7f749f9b0b()
        _7cd46c3a0476._b62c9da81858()
        return _15e93e50e5b6()._d56f1f649a35()

    def _92c2c15ee6eb(self, _8adfdcb876cb, _2bc1abc86149):
        _de2e11691097      = _8adfdcb876cb["input_ids"]._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)
        _e49f08d77dde         = _8adfdcb876cb["labels"]._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)
        _50c3a31272d3     = _8adfdcb876cb._3813eef240c1("lang_codes", _071ed420c21c)
        _dc2347574e0e     = _8adfdcb876cb._3813eef240c1("sample_ids", _071ed420c21c)
        _de7e5c2a9ac2      = _8adfdcb876cb._3813eef240c1("chunk_ids", _071ed420c21c)
        _75e269cd8574 = _8adfdcb876cb._3813eef240c1("word_positions", _071ed420c21c)
        _8e5677c2f638    = _8adfdcb876cb._3813eef240c1("prompt_lens", _071ed420c21c)
        _7c8855ed828c = _8adfdcb876cb._3813eef240c1("num_chunks", _071ed420c21c)

        _ccff47832171 = _de2e11691097._ea7c472c03c8(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _cdc762daf50c, _f34c3fd91c79, _561fceb74eda = self(_de2e11691097)

        # causal LM shift for next-token classification (same as training)
        _c3a94283a683 = _cdc762daf50c[:, :-1, :]._30c371af826a()
        _57b9ea9879bb = _e49f08d77dde[:, 1:]._30c371af826a()
        _a20e9aa177ba = _c3a94283a683._8a9c2705f402(-1, _c3a94283a683._ea7c472c03c8(-1))
        _2ed0fdb6c2d3 = _57b9ea9879bb._8a9c2705f402(-1)

        if _2bc1abc86149 == 0:
            try:
                _c8620e49c8fc(
                    f"VAL TEST BATCH {_2bc1abc86149} Input IDs: {_de2e11691097._d2efc1d80317()[0]}, "
                    f"Predictions: {_39fe13e31267._2193f519e934(_c3a94283a683, _b407948b9c8c=-1)._d2efc1d80317()[0]}, "
                    f"Labels: {_57b9ea9879bb._d2efc1d80317()[0]}"
                )
            except _fb74352f99f1:
                # printing should never crash validation
                pass

        # classification loss
        _1ffa2a6901ae = self._5df625c29ab6['criterion'](_a20e9aa177ba, _2ed0fdb6c2d3)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _f34c3fd91c79 = _39fe13e31267._019d38325b07(_f34c3fd91c79, _c155d89691f1=0.0, _cfac64a0e130=0.0, _4f5d85e092c7=0.0)
        _561fceb74eda = _39fe13e31267._019d38325b07(_561fceb74eda, _c155d89691f1=0.0, _cfac64a0e130=0.0, _4f5d85e092c7=0.0)
        _1ffa2a6901ae = _39fe13e31267._019d38325b07(_1ffa2a6901ae, _c155d89691f1=0.0, _cfac64a0e130=0.0, _4f5d85e092c7=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _c2b53c5a4d1e = self._3d756fab8a8f(_1ffa2a6901ae, _f34c3fd91c79, _561fceb74eda)
        _b6fb424762df = _c2b53c5a4d1e["aux_term"]
        _d9970b2a4db2 = _1ffa2a6901ae + _b6fb424762df

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _8db36f23395f = {
            "val_kl_loss": _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("kl_loss", _f34c3fd91c79)._90e0e66f060b()._661038bb1938()._a5e06781c255()) if _28e51846f321(_c2b53c5a4d1e._3813eef240c1("kl_loss", _f34c3fd91c79), _39fe13e31267._7f2895d47ff6) else _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("kl_loss", _f34c3fd91c79)),
            "val_contrastive_loss": _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("contrastive_loss", _561fceb74eda)._90e0e66f060b()._661038bb1938()._a5e06781c255()) if _28e51846f321(_c2b53c5a4d1e._3813eef240c1("contrastive_loss", _561fceb74eda), _39fe13e31267._7f2895d47ff6) else _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("contrastive_loss", _561fceb74eda)),
            "val_classification_loss": _672e56a4ffb5(_1ffa2a6901ae._90e0e66f060b()._661038bb1938()._a5e06781c255()),
            "val_loss": _672e56a4ffb5(_d9970b2a4db2._90e0e66f060b()._661038bb1938()._a5e06781c255()),
        }

        # include effective lambdas and others if provided by aux
        _8db36f23395f["val_lambda_kl"] = _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("lambda_kl", _c2b53c5a4d1e._3813eef240c1("lambda_kl_eff", _672e56a4ffb5(_89565abf9e73(self, "kl_base", 0.30)))))
        _8db36f23395f["val_lambda_contrast"] = _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("lambda_cos", _c2b53c5a4d1e._3813eef240c1("lambda_cos_eff", _672e56a4ffb5(_89565abf9e73(self, "cos_base", 0.25)))))
        _8db36f23395f["val_w_mean"] = _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("w_mean", 0.0))
        _8db36f23395f["val_aux_scale"] = _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("aux_scale", 0.0))
        _8db36f23395f["val_shift_r"] = _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("shift_r", 0.0))
        _8db36f23395f["val_teacher_conf_mean"] = _672e56a4ffb5(_c2b53c5a4d1e._3813eef240c1("teacher_conf_mean", 0.0))

        self._8db36f23395f(
            _8db36f23395f,
            _ccff47832171=_ccff47832171,
            _8303142e5325=_100364afef71,
            _efe69eabf253=_85ecf7a08589,
            _03559d27c9a9=_100364afef71,
            _bc0b096fff77=_85ecf7a08589,
            _6724d75b12d6=_85ecf7a08589,
        )

        # build preds and labels per example (preserve your previous behavior)
        _5c9435c570ae = []
        _f7953145e31f = []
        for _466469080718 in _336ed066e4bd(_ccff47832171):
            _de3c0d575f3d = _cdc762daf50c[_466469080718]
            _839fb0592a3b = _e49f08d77dde[_466469080718]
            _e6c0932c058a = _39fe13e31267._2193f519e934(_de3c0d575f3d, _b407948b9c8c=-1)
            _83db535782e1 = _839fb0592a3b
            _5c9435c570ae._e7cfb8207b93(_e6c0932c058a)
            _f7953145e31f._e7cfb8207b93(_83db535782e1)

        _42cc589a3bd6 = {
            "lang_codes": _50c3a31272d3,
            "preds": _5c9435c570ae,
            "labels": _f7953145e31f,
            "sample_ids": _dc2347574e0e,
            "chunk_ids": _de7e5c2a9ac2,
            "word_positions": _75e269cd8574,
            "val_loss": _d9970b2a4db2,
            "prompt_lens": _8e5677c2f638,
            "num_chunks": _7c8855ed828c,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._7246bde5c7d8._e7cfb8207b93(_42cc589a3bd6)

        # explicit frees (same as you had)
        del _de2e11691097, _e49f08d77dde, _cdc762daf50c, _a20e9aa177ba, _2ed0fdb6c2d3, _c3a94283a683, _57b9ea9879bb
        del _f34c3fd91c79, _561fceb74eda, _1ffa2a6901ae, _5c9435c570ae, _f7953145e31f

        return _42cc589a3bd6


    def _42064732d3cb(self, _7e30cc16b1f9, _281e09887ab5, _b09748ec99c1=_071ed420c21c):
        _36462201d910 = os._27e2deffee8e()
        _cf40632fefb8 = f"trial_{_b09748ec99c1}" if _b09748ec99c1 is not _071ed420c21c else "default"
        _c8620e49c8fc(f"[DEBUG rank={_39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb() if _39fe13e31267._ee2f0e1538e8._5d46b0583082() else 0}] metrics_dict confusion_matrix sum={_71ecf64a0f99(_71ecf64a0f99(_16ef0c62e5bf) for _16ef0c62e5bf in _7e30cc16b1f9['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _64a3fa0bcb53 = os._9f6eb609d8dd._b685b7088fba(_36462201d910, "metrics", self._648cce91511c,  _cf40632fefb8)
        os._b6839da962ac(_64a3fa0bcb53, _6ae4e3cfe16f=_85ecf7a08589)
        _44d0c336e37f = os._9f6eb609d8dd._b685b7088fba(_64a3fa0bcb53, _281e09887ab5)
        _a0e8cb459866 = _0dd673d8765a._db535739ec39(_7e30cc16b1f9)
        _a0e8cb459866._64157fd7dea8(_44d0c336e37f, _2d3abef205d6=_100364afef71)
        _c8620e49c8fc(f"[metrics] Saved {_44d0c336e37f}")

    def _b0df6d092741(self):
        # pick correct device for this rank
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            if _39fe13e31267._ee2f0e1538e8._5d46b0583082():
                _34a6615505a7 = _39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb()
            else:
                _34a6615505a7 = 0
            _39fe13e31267._be7d69560cc1._351cbb1192b5(_34a6615505a7)
            self._4f88148cb368 = _39fe13e31267._7326db126d68(f"cuda:{_34a6615505a7}")
        else:
            self._4f88148cb368 = _39fe13e31267._7326db126d68("cpu")

        self._3009e09cc063()

    def _6a41d5a6b570(self):
        _cdc762daf50c = _89565abf9e73(self, "_validation_outputs", _071ed420c21c)
        if not _cdc762daf50c:
            return

        _0861b1344346, _0ede2ba95417, _e5146c288498, _bb54a473ff44 = \
            self._38a6674d6a48(_cdc762daf50c)

        _d1b7bfc97dfa, _55ebb5c9dbd9 = [], []
        for _6c732e1fba18 in _f0299f3ce4fa(_e5146c288498._0218be444e1f()):
            _598884ad8b23 = _0861b1344346[_6c732e1fba18]._d2efc1d80317()
            _3d2a33731728 = _0ede2ba95417[_6c732e1fba18]._d2efc1d80317()
            _78a0ca4ad7da = _e5146c288498[_6c732e1fba18]
            _9e28628e500c = _bb54a473ff44[_6c732e1fba18]
            if _78a0ca4ad7da._d3d639b59b43() > 0 and _9e28628e500c._d3d639b59b43() > 0:
                _d1b7bfc97dfa._e7cfb8207b93(_78a0ca4ad7da)
                _55ebb5c9dbd9._e7cfb8207b93(_9e28628e500c)

        if not _d1b7bfc97dfa:
            _c8620e49c8fc("[VAL END] Nothing to score.")
            self._7246bde5c7d8._c8e3a80b76ea()
            return

        _b8f16471d5fd = _39fe13e31267._de4379e6018f(_d1b7bfc97dfa)._aca0d72d6383(_7326db126d68=self._0679dc520b1c['micro_accuracy']._7326db126d68, _16f0af4e6e6b=_85ecf7a08589)
        _e49f08d77dde = _39fe13e31267._de4379e6018f(_55ebb5c9dbd9)._aca0d72d6383(_7326db126d68=self._0679dc520b1c['micro_accuracy']._7326db126d68, _16f0af4e6e6b=_85ecf7a08589)

        self._0679dc520b1c['micro_accuracy']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_accuracy']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_precision']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_recall']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_f1']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_accuracy']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_precision']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_recall']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_f1']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['confmat']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)

        _a8ae8a1cbd54  = self._0679dc520b1c['micro_accuracy']._d18a9fd50018()._a5e06781c255()
        _75277829fa03  = self._0679dc520b1c['macro_accuracy']._d18a9fd50018()._a5e06781c255()
        _a42e2096e71b = self._0679dc520b1c['macro_precision']._d18a9fd50018()._a5e06781c255()
        _dedeeb695527    = self._0679dc520b1c['macro_recall']._d18a9fd50018()._a5e06781c255()
        _6a4ed2d30b63        = self._0679dc520b1c['macro_f1']._d18a9fd50018()._a5e06781c255()

        self._7834910970f1("val_accuracy", _75277829fa03, _6724d75b12d6=_85ecf7a08589)

        try:
            _abd616ac3606 = self._98d2bfac9b9d
            _7e30cc16b1f9 = {
                "epoch": [_abd616ac3606],
                "class_names": [self._a0e3aada039d],
                "micro_accuracy": [_a8ae8a1cbd54],
                "macro_accuracy": [_75277829fa03],
                "macro_precision": [_a42e2096e71b],
                "macro_recall": [_dedeeb695527],
                "macro_f1": [_6a4ed2d30b63],
                "classwise_accuracy": [self._0679dc520b1c['classwise_accuracy']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "classwise_precision": [self._0679dc520b1c['classwise_precision']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "classwise_recall": [self._0679dc520b1c['classwise_recall']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "classwise_f1": [self._0679dc520b1c['classwise_f1']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "confusion_matrix": [self._0679dc520b1c['confmat']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
            }
            self._f2925dc6ab22(_7e30cc16b1f9, f"val_epoch_{_abd616ac3606}.csv", _b09748ec99c1=self._b09748ec99c1)
        except _fb74352f99f1 as _26c80111d50c:
            _c8620e49c8fc(f"[VAL END] save metrics FAILED: {_26c80111d50c}")

        # cleanup
        self._0679dc520b1c['micro_accuracy']._70b73e8ff034(); self._0679dc520b1c['macro_accuracy']._70b73e8ff034()
        self._0679dc520b1c['macro_precision']._70b73e8ff034(); self._0679dc520b1c['macro_recall']._70b73e8ff034(); self._0679dc520b1c['macro_f1']._70b73e8ff034()
        self._0679dc520b1c['classwise_accuracy']._70b73e8ff034(); self._0679dc520b1c['classwise_precision']._70b73e8ff034()
        self._0679dc520b1c['classwise_recall']._70b73e8ff034(); self._0679dc520b1c['classwise_f1']._70b73e8ff034()
        self._0679dc520b1c['confmat']._70b73e8ff034(); self._7246bde5c7d8._c8e3a80b76ea()
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            _39fe13e31267._be7d69560cc1._4f7f749f9b0b()
        _c8620e49c8fc("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_39fe13e31267._634e6905302d()
    def _f0ea7d57ec98(self, _de2e11691097: _39fe13e31267._7f2895d47ff6, **_ca3589fa488f):
        _ca3589fa488f._64c1ab611b30("pad_token_id", _071ed420c21c)
        _ca3589fa488f._64c1ab611b30("attention_mask", _071ed420c21c)
        return self._c791a25d69e8._f95fa61637d9(
            _de2e11691097=_de2e11691097,
            _27774fa3be19=(_de2e11691097 != self._34f1ffb4c44c._63e5aa9565a2),
            _63e5aa9565a2=self._34f1ffb4c44c._63e5aa9565a2,
            _cdb2bf1aed4f=self._34f1ffb4c44c._cdb2bf1aed4f,
            **_ca3589fa488f
        )

    def _3fd90feef6b6(self, _8adfdcb876cb, _2bc1abc86149):
        _de2e11691097 = _8adfdcb876cb["input_ids"]._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)
        _e49f08d77dde    = _8adfdcb876cb["labels"]._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)
        _50c3a31272d3     = _8adfdcb876cb._3813eef240c1("lang_codes", _071ed420c21c)
        _dc2347574e0e     = _8adfdcb876cb._3813eef240c1("sample_ids", _071ed420c21c)
        _de7e5c2a9ac2      = _8adfdcb876cb._3813eef240c1("chunk_ids", _071ed420c21c)
        _75e269cd8574 = _8adfdcb876cb._3813eef240c1("word_positions", _071ed420c21c)
        _8e5677c2f638    = _8adfdcb876cb._3813eef240c1("prompt_lens", _071ed420c21c)
        _7c8855ed828c = _8adfdcb876cb._3813eef240c1("num_chunks", _071ed420c21c)

        _ccff47832171 = _de2e11691097._ea7c472c03c8(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _922ddd92c93e = self._f95fa61637d9(
            _de2e11691097,
            _5c964efa1407=48,
            _2a5c1d7b4f36=_100364afef71,
            _b76973831efc=_071ed420c21c,     # or just add this
            _69007798774f=_071ed420c21c,
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _5c9435c570ae = []
        _f7953145e31f = []
        for _466469080718 in _336ed066e4bd(_ccff47832171):
            _d1e36bc948da = _922ddd92c93e[_466469080718]                    # (seq_len,)
            _952f7effa417 = _e49f08d77dde[_466469080718]
            _5c9435c570ae._e7cfb8207b93(_d1e36bc948da)
            _f7953145e31f._e7cfb8207b93(_952f7effa417)

        _42cc589a3bd6 = {
            "lang_codes": _50c3a31272d3,
            "preds": _5c9435c570ae,
            "labels": _f7953145e31f,
            "sample_ids": _dc2347574e0e,
            "chunk_ids": _de7e5c2a9ac2,
            "word_positions": _75e269cd8574,
            "prompt_lens": _8e5677c2f638,
            "num_chunks": _7c8855ed828c,
        }

        self._931c144bf6dd._e7cfb8207b93(_42cc589a3bd6)

        # Exact same cleanup as before
        del _de2e11691097, _e49f08d77dde, _922ddd92c93e, _5c9435c570ae, _f7953145e31f

        return _42cc589a3bd6

    def _9de5911d1b17(self):
        # pick correct device for this rank
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            if _39fe13e31267._ee2f0e1538e8._5d46b0583082():
                _34a6615505a7 = _39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb()
            else:
                _34a6615505a7 = 0
            _39fe13e31267._be7d69560cc1._351cbb1192b5(_34a6615505a7)
            self._4f88148cb368 = _39fe13e31267._7326db126d68(f"cuda:{_34a6615505a7}")
        else:
            self._4f88148cb368 = _39fe13e31267._7326db126d68("cpu")

        self._3009e09cc063()
        
    def _0c68845b9837(self):
        _cdc762daf50c = _89565abf9e73(self, "_test_outputs", _071ed420c21c)
        _c8620e49c8fc(f"[DEBUG rank={_39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb()}] outputs_len={_2c8049819e0e(_cdc762daf50c)}")
        if not _cdc762daf50c:
            return

        _0861b1344346, _0ede2ba95417, _e5146c288498, _bb54a473ff44 = \
            self._38a6674d6a48(_cdc762daf50c)

        _d1b7bfc97dfa, _55ebb5c9dbd9 = [], []
        for _6c732e1fba18 in _f0299f3ce4fa(_e5146c288498._0218be444e1f()):
            _598884ad8b23 = _0861b1344346[_6c732e1fba18]._d2efc1d80317()
            _3d2a33731728 = _0ede2ba95417[_6c732e1fba18]._d2efc1d80317()
            _78a0ca4ad7da = _e5146c288498[_6c732e1fba18]
            _9e28628e500c = _bb54a473ff44[_6c732e1fba18]

            if _78a0ca4ad7da._d3d639b59b43() > 0 and _9e28628e500c._d3d639b59b43() > 0:
                _d1b7bfc97dfa._e7cfb8207b93(_78a0ca4ad7da)
                _55ebb5c9dbd9._e7cfb8207b93(_9e28628e500c)

        if not _d1b7bfc97dfa:
            _c8620e49c8fc("[TEST END] Nothing to score.")
            self._7246bde5c7d8._c8e3a80b76ea()
            return

        _b8f16471d5fd = _39fe13e31267._de4379e6018f(_d1b7bfc97dfa)._aca0d72d6383(_7326db126d68=self._0679dc520b1c['micro_accuracy']._7326db126d68, _16f0af4e6e6b=_85ecf7a08589)
        _e49f08d77dde = _39fe13e31267._de4379e6018f(_55ebb5c9dbd9)._aca0d72d6383(_7326db126d68=self._0679dc520b1c['micro_accuracy']._7326db126d68, _16f0af4e6e6b=_85ecf7a08589)

        self._0679dc520b1c['micro_accuracy']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_accuracy']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_precision']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_recall']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['macro_f1']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_accuracy']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_precision']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_recall']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['classwise_f1']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)
        self._0679dc520b1c['confmat']._89b46d700af6(_b8f16471d5fd, _e49f08d77dde)

        _a8ae8a1cbd54  = self._0679dc520b1c['micro_accuracy']._d18a9fd50018()._a5e06781c255()
        _75277829fa03  = self._0679dc520b1c['macro_accuracy']._d18a9fd50018()._a5e06781c255()
        _a42e2096e71b = self._0679dc520b1c['macro_precision']._d18a9fd50018()._a5e06781c255()
        _dedeeb695527    = self._0679dc520b1c['macro_recall']._d18a9fd50018()._a5e06781c255()
        _6a4ed2d30b63        = self._0679dc520b1c['macro_f1']._d18a9fd50018()._a5e06781c255()

        self._7834910970f1("test_accuracy", _75277829fa03, _6724d75b12d6=_85ecf7a08589)

        try:
            _abd616ac3606 = self._98d2bfac9b9d
            _7e30cc16b1f9 = {
                "epoch": [_abd616ac3606],
                "class_names": [self._a0e3aada039d],
                "micro_accuracy": [_a8ae8a1cbd54],
                "macro_accuracy": [_75277829fa03],
                "macro_precision": [_a42e2096e71b],
                "macro_recall": [_dedeeb695527],
                "macro_f1": [_6a4ed2d30b63],
                "classwise_accuracy": [self._0679dc520b1c['classwise_accuracy']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "classwise_precision": [self._0679dc520b1c['classwise_precision']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "classwise_recall": [self._0679dc520b1c['classwise_recall']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "classwise_f1": [self._0679dc520b1c['classwise_f1']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
                "confusion_matrix": [self._0679dc520b1c['confmat']._d18a9fd50018()._aca0d72d6383(_7326db126d68="cpu")._bed613227bd8()._d2efc1d80317()],
            }
            self._f2925dc6ab22(_7e30cc16b1f9, f"test_final.csv", _b09748ec99c1=self._b09748ec99c1)
        except _fb74352f99f1 as _26c80111d50c:
            _c8620e49c8fc(f"[TEST END] save metrics FAILED: {_26c80111d50c}")

        # cleanup
        self._0679dc520b1c['micro_accuracy']._70b73e8ff034(); self._0679dc520b1c['macro_accuracy']._70b73e8ff034()
        self._0679dc520b1c['macro_precision']._70b73e8ff034(); self._0679dc520b1c['macro_recall']._70b73e8ff034(); self._0679dc520b1c['macro_f1']._70b73e8ff034()
        self._0679dc520b1c['classwise_accuracy']._70b73e8ff034(); self._0679dc520b1c['classwise_precision']._70b73e8ff034()
        self._0679dc520b1c['classwise_recall']._70b73e8ff034(); self._0679dc520b1c['classwise_f1']._70b73e8ff034()
        self._0679dc520b1c['confmat']._70b73e8ff034(); self._7246bde5c7d8._c8e3a80b76ea()
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            _39fe13e31267._be7d69560cc1._4f7f749f9b0b()
        _c8620e49c8fc("[TEST END] Finished and cleaned up.")

    def _aa12fe7e5585(self, _8adfdcb876cb, _2bc1abc86149, _9f9cb78a93dd=0):
        """Optimized prediction step with efficient memory handling."""
        _de2e11691097, _ = _8adfdcb876cb
        _de2e11691097 = _de2e11691097._aca0d72d6383(self._4f88148cb368, _16f0af4e6e6b=_85ecf7a08589)
        _cdc762daf50c, _, _ = self(_de2e11691097)
        _2e199276d43a = _39fe13e31267._2193f519e934(_cdc762daf50c, _b407948b9c8c=-1)
        del _de2e11691097, _cdc762daf50c
        if _39fe13e31267._be7d69560cc1._802eb0e47e6a():
            _39fe13e31267._be7d69560cc1._4f7f749f9b0b()
        return {"predictions": _2e199276d43a._661038bb1938()}

    def _f86e3313f1b9(self, _cdc762daf50c, _1d09b4e762e2=_85ecf7a08589, _adefd22af485="cpu"):
        from collections import _611746d10f7c, _a4f36bccd7a4
        import _39fe13e31267
        _53ad4046d923 = self._357ca379c743
        def _b6977952871c(_0b486840b8f1):
            if _28e51846f321(_0b486840b8f1, _39fe13e31267._7f2895d47ff6): return _0b486840b8f1._90e0e66f060b()._aca0d72d6383(_7326db126d68=_adefd22af485, _16f0af4e6e6b=_85ecf7a08589)._ab2657a6a8a1(-1)._d2efc1d80317()
            return _ceef1f2af457(_0b486840b8f1) if _28e51846f321(_0b486840b8f1, (_ceef1f2af457, _041a9f264b7e)) else [_0b486840b8f1]
        
        _5eab97c0be74 = _c2657b9f1296()
        _0861b1344346, _0ede2ba95417, _fc1c00460cd3 = {}, {}, []
        if _1d09b4e762e2:
            _c8620e49c8fc(f"[reconcile] start: num_outputs={_2c8049819e0e(_cdc762daf50c)}")
        

        _c8620e49c8fc(f"[DEBUG rank={_39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb()}] Before reconcile missing sample_ids={[_6c732e1fba18 for _6c732e1fba18 in _336ed066e4bd(0 if _39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb() == 0 else 637, 637 if _39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb() == 0 else 1274) if _6c732e1fba18 not in _c2657b9f1296(_6c732e1fba18 for _50bd5fd211a6 in _cdc762daf50c for _6c732e1fba18 in _50bd5fd211a6._3813eef240c1('sample_ids', []))]}")
        for _50bd5fd211a6 in _cdc762daf50c:
            _dc2347574e0e     = _50bd5fd211a6["sample_ids"]
            _de7e5c2a9ac2      = _50bd5fd211a6["chunk_ids"]
            _2c14c00d7c6e    = _50bd5fd211a6["preds"]
            _086f989ae6cd   = _50bd5fd211a6["labels"]
            _75e269cd8574 = _50bd5fd211a6["word_positions"]
            _8e5677c2f638 = _50bd5fd211a6["prompt_lens"]
            _ed246d0928cb = _50bd5fd211a6["num_chunks"]

            for _466469080718, _6c732e1fba18 in _f39d6fde7a2a(_dc2347574e0e):
                _32f2abcf3233 = _9bd75263d55c(_de7e5c2a9ac2[_466469080718])

                if (_6c732e1fba18, _32f2abcf3233) in _5eab97c0be74:
                    continue
                _5eab97c0be74._293ad7acb094((_6c732e1fba18, _32f2abcf3233))

                _0ae209fa2111 = _9bd75263d55c(_8e5677c2f638[_466469080718])
                _2d49810c99fc = _a52ae23e5f56(_75e269cd8574[_466469080718])
                _34c409c0232e = self._1b22e1bc1eb5
                # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
                _8fca4dd738aa  = _a52ae23e5f56(_2c14c00d7c6e[_466469080718])
                _62e86b024950 = _a52ae23e5f56(_086f989ae6cd[_466469080718])

                # If preds are shorter than labels, they are generation-only (test)
                if _2c8049819e0e(_8fca4dd738aa) < _2c8049819e0e(_62e86b024950):
                    _9b4f2e3d5729  = _8fca4dd738aa
                    _d649d2dd94a0 = _62e86b024950[_0ae209fa2111:]
                else:
                    _9b4f2e3d5729  = _8fca4dd738aa[_0ae209fa2111:]
                    _d649d2dd94a0 = _62e86b024950[_0ae209fa2111:]
                if _6c732e1fba18 not in _fc1c00460cd3:
                    _fc1c00460cd3._e7cfb8207b93(_6c732e1fba18)

                if 'chunks_by_sid' not in _499e57847ea9():
                    _1e69a07fd291 = _611746d10f7c(_ceef1f2af457)
                _1e69a07fd291[_6c732e1fba18]._e7cfb8207b93((_32f2abcf3233, _2d49810c99fc, _9b4f2e3d5729, _d649d2dd94a0))
            
        _94a5526102e8 = _071ed420c21c
        _34a6615505a7 = _39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb() if _39fe13e31267._ee2f0e1538e8._5d46b0583082() else 0
        _c8620e49c8fc(f"[DEBUG rank={_39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb()}] Missing sample_ids={[_6c732e1fba18 for _6c732e1fba18 in _336ed066e4bd(0 if _39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb() == 0 else 637, 637 if _39fe13e31267._ee2f0e1538e8._e8a1ae9e72fb() == 0 else 1274) if _6c732e1fba18 not in _fc1c00460cd3]}")
        for _6c732e1fba18 in _fc1c00460cd3:
            _5de99d818072 = _1e69a07fd291[_6c732e1fba18]
            _c8620e49c8fc(f"[WARN] Rank {_34a6615505a7} Missing chunks sample_id={_6c732e1fba18}, missing {_50bd5fd211a6['num_chunks'][_466469080718] - _2c8049819e0e(_5de99d818072)} chunks") if _22319902d17d(_50bd5fd211a6['sample_ids'][_466469080718] == _6c732e1fba18 and _50bd5fd211a6['num_chunks'][_466469080718] > _2c8049819e0e(_5de99d818072) for _50bd5fd211a6 in _cdc762daf50c for _466469080718 in _336ed066e4bd(_2c8049819e0e(_50bd5fd211a6['sample_ids']))) else _071ed420c21c
            if _94a5526102e8 is _071ed420c21c and _2c8049819e0e(_5de99d818072) > 1:
                _94a5526102e8 = _6c732e1fba18
            _5de99d818072._25bb9ce904e5(_31605e00d486=lambda _0b486840b8f1: _0b486840b8f1[0])
            _2b86a635f82c = _611746d10f7c(_ceef1f2af457)
            _5f10ddb7e0db = _611746d10f7c(_ceef1f2af457)
            _92693e235ad1 = _611746d10f7c(_ceef1f2af457)
            _c3b5ab15c088 = _611746d10f7c(_ceef1f2af457)
            for _32f2abcf3233, _3152d26569f1, _b8f16471d5fd, _e49f08d77dde in _5de99d818072:
                _5e59818ecf9e = {}
                _5699d0784f51 = {}
                _9803e48a4149 = _071ed420c21c
                _364bbe122101 = []
                _34256ac0c334 = []
                for _918540b88c9a, _c52b2ccc5df8, _85d14e24a781 in _43f4521b7131(_3152d26569f1, _b8f16471d5fd, _e49f08d77dde):
                    _cbe3c21547a1 = _9bd75263d55c(_918540b88c9a)
                    if _cbe3c21547a1 >= 0:
                        if _cbe3c21547a1 != _9803e48a4149:
                            if _9803e48a4149 is not _071ed420c21c:
                                _5e59818ecf9e[_9803e48a4149] = _364bbe122101[:]
                                _5699d0784f51[_9803e48a4149] = _34256ac0c334[:]
                            _9803e48a4149 = _cbe3c21547a1
                            _364bbe122101 = [_9bd75263d55c(_c52b2ccc5df8)]
                            _34256ac0c334 = [_9bd75263d55c(_85d14e24a781)]
                        else:
                            _364bbe122101._e7cfb8207b93(_9bd75263d55c(_c52b2ccc5df8))
                            _34256ac0c334._e7cfb8207b93(_9bd75263d55c(_85d14e24a781))
                    else:
                        if _9803e48a4149 is not _071ed420c21c:
                            _5f10ddb7e0db[_9803e48a4149]._e7cfb8207b93(_9bd75263d55c(_c52b2ccc5df8))
                            _c3b5ab15c088[_9803e48a4149]._e7cfb8207b93(_9bd75263d55c(_85d14e24a781))
                if _9803e48a4149 is not _071ed420c21c:
                    _5e59818ecf9e[_9803e48a4149] = _364bbe122101[:]
                    _5699d0784f51[_9803e48a4149] = _34256ac0c334[:]
                for _330c51a78ad0, _9d5e01b7c11c in _5e59818ecf9e._792d04858f19():
                    _2b86a635f82c[_330c51a78ad0]._e7cfb8207b93(_9d5e01b7c11c)
                    _92693e235ad1[_330c51a78ad0]._e7cfb8207b93(_5699d0784f51[_330c51a78ad0])
            if not _2b86a635f82c:
                continue
            _66019aa41176 = _5b3b2d77198b(_2b86a635f82c._0218be444e1f())
            _a79205a09011 = []
            _143080e48da3 = []
            _15e14785b931 = _668bd6a8c79f((_b5051d7b1a91[0] for _b5051d7b1a91, _65ca4912b0a8 in self._f6ba21bcd4ec._792d04858f19() if _65ca4912b0a8 == 0), 3200)
            for _330c51a78ad0 in _f0299f3ce4fa(_2b86a635f82c._0218be444e1f()):
                _63896293d673 = _2b86a635f82c[_330c51a78ad0]
                _736db136f843 = _92693e235ad1[_330c51a78ad0]
                _54b4ffe07937 = _2c8049819e0e(_736db136f843[0])
                _d624e6dae405 = []
                for _6a3666585528 in _336ed066e4bd(_54b4ffe07937):
                    _b843151e7e71 = [_a5188f5615dd[_6a3666585528] for _a5188f5615dd in _63896293d673 if _6a3666585528 < _2c8049819e0e(_a5188f5615dd)]
                    while _2c8049819e0e(_b843151e7e71) < _2c8049819e0e(_736db136f843):
                        _b843151e7e71._e7cfb8207b93(_15e14785b931)
                    _a3a5a9153432 = _a4f36bccd7a4(_b843151e7e71)._2816b193c43d(1)[0][0]
                    _d624e6dae405._e7cfb8207b93(_a3a5a9153432)
                _a79205a09011._3e034ca32f42(_d624e6dae405[:_54b4ffe07937])
                _d765a629b178 = []
                for _6a3666585528 in _336ed066e4bd(_54b4ffe07937):
                    _b843151e7e71 = [_a5188f5615dd[_6a3666585528] for _a5188f5615dd in _736db136f843]
                    _a3a5a9153432 = _a4f36bccd7a4(_b843151e7e71)._2816b193c43d(1)[0][0]
                    _d765a629b178._e7cfb8207b93(_a3a5a9153432)
                _143080e48da3._3e034ca32f42(_d765a629b178)
                if _330c51a78ad0 < _66019aa41176:
                    _6c69c3058c18 = _5f10ddb7e0db[_330c51a78ad0]
                    if _6c69c3058c18:
                        _1c4803b895d7 = _a4f36bccd7a4(_6c69c3058c18)._2816b193c43d(1)[0][0]
                        _a79205a09011._e7cfb8207b93(_1c4803b895d7)
                    _c8af1329ab99 = _c3b5ab15c088[_330c51a78ad0]
                    if _c8af1329ab99:
                        _af889d0b2afc = _a4f36bccd7a4(_c8af1329ab99)._2816b193c43d(1)[0][0]
                        _143080e48da3._e7cfb8207b93(_af889d0b2afc)
                    else:
                        _143080e48da3._e7cfb8207b93(self._eef5abce5772)
                        _a79205a09011._e7cfb8207b93(self._eef5abce5772)
            _15e14785b931 = _668bd6a8c79f((_b5051d7b1a91[0] for _b5051d7b1a91, _65ca4912b0a8 in self._f6ba21bcd4ec._792d04858f19() if _65ca4912b0a8 == 0), 3200)
            _4875c4a14997 = _71ecf64a0f99(1 for _466469080718, _0b486840b8f1 in _f39d6fde7a2a(_143080e48da3) if _0b486840b8f1 != self._eef5abce5772 and (_466469080718 == 0 or _143080e48da3[_466469080718-1] == self._eef5abce5772))
            _01e6efcc4df3 = _71ecf64a0f99(1 for _466469080718, _0b486840b8f1 in _f39d6fde7a2a(_a79205a09011) if _0b486840b8f1 != self._eef5abce5772 and (_466469080718 == 0 or _a79205a09011[_466469080718-1] == self._eef5abce5772))
            if _01e6efcc4df3 < _4875c4a14997:
                for _ in _336ed066e4bd(_01e6efcc4df3, _4875c4a14997):
                    if _2c8049819e0e(_a79205a09011) > 0 and _a79205a09011[-1] != self._eef5abce5772:
                        _a79205a09011._e7cfb8207b93(self._eef5abce5772)
                    _a79205a09011._e7cfb8207b93(_15e14785b931)
            elif _01e6efcc4df3 > _4875c4a14997:
                _6764bdac3139 = []
                _b70105c5d6a6 = 0
                for _466469080718, _fc6542d888aa in _f39d6fde7a2a(_a79205a09011):
                    if _fc6542d888aa != self._eef5abce5772 and (_466469080718 == 0 or _a79205a09011[_466469080718-1] == self._eef5abce5772):
                        _b70105c5d6a6 += 1
                    if _b70105c5d6a6 <= _4875c4a14997:
                        _6764bdac3139._e7cfb8207b93(_fc6542d888aa)
                    elif _fc6542d888aa == self._eef5abce5772 and _b70105c5d6a6 == _4875c4a14997:
                        _6764bdac3139._e7cfb8207b93(_fc6542d888aa)
                        break
                _a79205a09011 = _6764bdac3139

            _0861b1344346[_6c732e1fba18] = _39fe13e31267._28329e03fb59(_a79205a09011, _7326db126d68=_adefd22af485)
            _0ede2ba95417[_6c732e1fba18] = _39fe13e31267._28329e03fb59(_143080e48da3 if _143080e48da3 else [self._357ca379c743] * _2c8049819e0e(_a79205a09011), _7326db126d68=_adefd22af485)

        if _1d09b4e762e2 and _94a5526102e8:
            _c8620e49c8fc(f"[SUMMARY] reconciled samples in batch = {_2c8049819e0e(_fc1c00460cd3)} \
                  sid={_94a5526102e8} total_preds={_2c8049819e0e(_0861b1344346[_94a5526102e8])} total_labels={_2c8049819e0e(_0ede2ba95417[_94a5526102e8])} \
                    raw_preds {_0861b1344346[_94a5526102e8]} and raw_labels{_0ede2ba95417[_94a5526102e8]}\
                        chunks {_1e69a07fd291[_94a5526102e8]}")
        
        _3908862e3676, _bae5bd900c23 = self._05697c424257(_0861b1344346, _0ede2ba95417, _1d09b4e762e2=_1d09b4e762e2, _adefd22af485=_adefd22af485)
        
        if _1d09b4e762e2 and _94a5526102e8:
            _c8620e49c8fc(f"After Overlay [DEBUG sid={_94a5526102e8}] raw_preds={_0861b1344346[_94a5526102e8]} and raw_labels={_0ede2ba95417[_94a5526102e8]} and preds={_3908862e3676[_94a5526102e8]} and labels={_bae5bd900c23[_94a5526102e8]}")
        
        return _0861b1344346, _0ede2ba95417, _3908862e3676, _bae5bd900c23

    def _0b241e51e532(self, _0861b1344346, _0ede2ba95417, _1d09b4e762e2=_85ecf7a08589, _adefd22af485="cpu"):
        _f6ba21bcd4ec = _89565abf9e73(self, "seq2class", {})
        _a36597cb8d06 = _89565abf9e73(self, "tokenizer_separator_token", _071ed420c21c)
        _53ad4046d923 = _89565abf9e73(self, "ignore_idx", -100)
        
        def _fd396daf3591(_eb4016d4261b, _7f16ba336439):
            _809aca8b2ce4 = []
            _9803e48a4149 = []
            for _466469080718, token in _f39d6fde7a2a(_eb4016d4261b):
                if token == _7f16ba336439 and _9803e48a4149:
                    _809aca8b2ce4._e7cfb8207b93(_9803e48a4149)
                    _9803e48a4149 = []
                elif token != _7f16ba336439:
                    _9803e48a4149._e7cfb8207b93(token)
            if _9803e48a4149:
                _809aca8b2ce4._e7cfb8207b93(_9803e48a4149)
            return _809aca8b2ce4
        
        def _6adf21a5c08d(_524494f0f0dc, _f6ba21bcd4ec, _1d09b4e762e2, _6c732e1fba18):
            _50bd5fd211a6 = []
            _446c6f2cebf4 = _f0299f3ce4fa(_f6ba21bcd4ec._0218be444e1f(), _31605e00d486=_2c8049819e0e, _df488352c261=_85ecf7a08589)
            for _466469080718, _1fe81d7e23cc in _f39d6fde7a2a(_524494f0f0dc, 1):
                _e41a9ab71ceb = _041a9f264b7e(_1fe81d7e23cc)
                _9dacc0acc122 = self._255341d86151
                for _31605e00d486 in _446c6f2cebf4:
                    if _2c8049819e0e(_e41a9ab71ceb) >= _2c8049819e0e(_31605e00d486) and _e41a9ab71ceb[:_2c8049819e0e(_31605e00d486)] == _31605e00d486:
                        _9dacc0acc122 = _f6ba21bcd4ec[_31605e00d486]
                        break
                _50bd5fd211a6._e7cfb8207b93(_9dacc0acc122)

            return _50bd5fd211a6
        
        _e5146c288498, _bb54a473ff44 = {}, {}
        for _6c732e1fba18 in _0861b1344346:
            _fc6542d888aa = _0861b1344346[_6c732e1fba18]
            _0e76ef5ea09f = _0ede2ba95417._3813eef240c1(_6c732e1fba18, _071ed420c21c)
            _b8f16471d5fd = _fc6542d888aa._d2efc1d80317() if _28e51846f321(_fc6542d888aa, _39fe13e31267._7f2895d47ff6) else _ceef1f2af457(_fc6542d888aa)
            _e49f08d77dde = _0e76ef5ea09f._d2efc1d80317() if _28e51846f321(_0e76ef5ea09f, _39fe13e31267._7f2895d47ff6) else _ceef1f2af457(_0e76ef5ea09f) if _0e76ef5ea09f else _071ed420c21c
            if _e49f08d77dde is not _071ed420c21c:
                _4875c4a14997 = _bd9f68e5e883(_e49f08d77dde, _a36597cb8d06)
                _7dd1e759efc0 = _faae21d8c0dd(_4875c4a14997, _f6ba21bcd4ec, _6c732e1fba18 == 1 or _1d09b4e762e2, _6c732e1fba18)
                _f54d760102e7 = _bd9f68e5e883(_b8f16471d5fd, _a36597cb8d06)
                _342412fe4296 = _faae21d8c0dd(_f54d760102e7, _f6ba21bcd4ec, _6c732e1fba18 == 1 or _1d09b4e762e2, _6c732e1fba18)
                if _2c8049819e0e(_342412fe4296) < _2c8049819e0e(_7dd1e759efc0):
                    _342412fe4296 += [0] * (_2c8049819e0e(_7dd1e759efc0) - _2c8049819e0e(_342412fe4296))
                elif _2c8049819e0e(_342412fe4296) > _2c8049819e0e(_7dd1e759efc0):
                    _342412fe4296 = _342412fe4296[:_2c8049819e0e(_7dd1e759efc0)]
            else:
                _f54d760102e7 = _bd9f68e5e883(_b8f16471d5fd, _a36597cb8d06)
                _342412fe4296 = _faae21d8c0dd(_f54d760102e7, _f6ba21bcd4ec, _6c732e1fba18 == 1 or _1d09b4e762e2, _6c732e1fba18)
                _7dd1e759efc0 = [_53ad4046d923] * _2c8049819e0e(_342412fe4296)
            _e5146c288498[_6c732e1fba18] = _39fe13e31267._28329e03fb59(_342412fe4296, _7326db126d68=_adefd22af485, _08008bc1ec8d=_39fe13e31267._982c765ad6bb)
            _bb54a473ff44[_6c732e1fba18] = _39fe13e31267._28329e03fb59(_7dd1e759efc0, _7326db126d68=_adefd22af485, _08008bc1ec8d=_39fe13e31267._982c765ad6bb)
        return _e5146c288498, _bb54a473ff44

    def _e0b0c0cab78c(self, _73c934a56c29):
        _39fe13e31267._98038833a40b._1e2d231b245d._5138001017ca(self._63bb9535d73e(), _9664839d1bbe=1.0)
    
    def _99776f8c60a0(self, _73c934a56c29):
        for _9344e2accb79 in self._63bb9535d73e():
            if _9344e2accb79 is not _071ed420c21c:
                _9344e2accb79._a72d03d8edfa._e7ad1d5e59ed(-5, 5)

    def _ef309edda6b1(self):
        _e57e85190cab = 0
        for _9344e2accb79 in self._63bb9535d73e():
            if _9344e2accb79._228776d10051 is not _071ed420c21c:
                _f05bfa431942 = _9344e2accb79._228776d10051._90e0e66f060b()._a72d03d8edfa._ba7676f904a5(2)
                _e57e85190cab += _f05bfa431942._a5e06781c255() ** 2
        return _e57e85190cab ** 0.5  # L2 norm

    def _9217d3640cd0(self):
        _c174b211831a = [_fc6542d888aa for _fc6542d888aa in self._63bb9535d73e() if _fc6542d888aa._63de67bbc3aa]
        if not _c174b211831a:
            _c8620e49c8fc("No trainable parameters. Skipping optimizer creation.")
            return _071ed420c21c
        
        _c4c0e1df9ca0 = _4b6a0f5778df(lambda _fc6542d888aa: _fc6542d888aa._63de67bbc3aa, self._63bb9535d73e())

        _840390cea1a9 = {
            "adamw": _39fe13e31267._a218f537e999._1c756309008f,
            "adamax": _39fe13e31267._a218f537e999._65d49194e5f5,
            "adam": _39fe13e31267._a218f537e999._078458ce2677,
        }
        _20ac805d9ffe = _840390cea1a9._3813eef240c1(self._10b14e26f386._e921527443d1(), _39fe13e31267._a218f537e999._078458ce2677)

        _73c934a56c29 = _20ac805d9ffe(_c4c0e1df9ca0, _f6f6ff3273db=self._080692641038._f6f6ff3273db, _992dd28143af=0.001)

        _f89dd93baa0d = self._197958a0e018._6d0cd0807ecb
        _fdce9b428f47 = math._d0d7b1867c9f(0.1 * _f89dd93baa0d)

        _aed0c9e763d9 = _39fe13e31267._a218f537e999._abf02cb0f9a6._e2d96efbad53(_73c934a56c29, _a3ec9abf38ef=lambda _315f2219a59f: (_315f2219a59f + 1) / _fdce9b428f47)

        _532ea1161b89 = _39fe13e31267._a218f537e999._abf02cb0f9a6._76ede335eb09(
            _73c934a56c29,
            _e324ee69f13b=_5b3b2d77198b(1, _f89dd93baa0d - _fdce9b428f47),
            _963dd7067fba=2,
            _0cf563ba0164=1e-6
        )
        _abf02cb0f9a6 = _39fe13e31267._a218f537e999._abf02cb0f9a6._b28ee21e2bd3(
            _73c934a56c29,
            _d3d090c83c21=[_aed0c9e763d9, _532ea1161b89],
            _db00a364c83d=[_fdce9b428f47]
        )
        return {"optimizer": _73c934a56c29, "lr_scheduler": {"scheduler": _abf02cb0f9a6, "interval": "epoch", "monitor": "val_loss"}}
