# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import math
import traceback
import torch
import lightning as pl
from torch import nn
from torchmetrics import Accuracy, Precision, Recall, F1Score
from torch.amp import autocast
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss

class InferenceLanguageIdentificationClassifier(nn.Module):
    def __init__(
        self,
        model,
    ):
        super(InferenceLanguageIdentificationClassifier, self).__init__()
        self.model = model
        

    def forward(self, input_ids, attention_mask):
        output = self.model(input_ids,attention_mask)
        return output
    
    def test_step(self, batch, batch_idx):
        print(f"Test step check")
        print(f"Model training mode: {self.training}")  # Should print False for testing
        print(f"Test step called for batch {batch_idx}")
        input_ids, attention_mask, labels = batch
        # Ensure inputs have correct dimensions
        if input_ids.dim() == 1:
            input_ids = input_ids.unsqueeze(0)
        if attention_mask.dim() == 1:
            attention_mask = attention_mask.unsqueeze(0)
        print(f"Batch contents: input_ids={input_ids.shape}, attention_mask={attention_mask.shape}, labels={labels.shape}")
        # input_ids, attention_mask, labels = batch
        self.eval()
        with torch.no_grad():
            try:
                for param in self.embedding.pooler.parameters():
                    param.requires_grad = False
                outputs = self(input_ids, attention_mask)
            except Exception as e:
                print(f"Error during forward pass: {e}")
                traceback.print_exc()

        print(f"Test outputs {outputs}")
        
        # Convert logits to predicted labels
        predicted_labels = torch.argmax(outputs, dim=1)

        print(f"Test step test predicted labels{predicted_labels}")
        
        # Calculate metrics
        accuracy = self._accuracy(predicted_labels, labels)
        precision = self._precision(predicted_labels, labels)
        recall = self._recall(predicted_labels, labels)
        f1 = self._f1(predicted_labels, labels)
        
        # Create a dictionary to store test metrics
        test_metrics = {
            "test_accuracy": accuracy,
            "test_precision": precision,
            "test_recall": recall,
            "test_f1": f1,
        }
        
        # Log the metrics
        self.log_dict(
            test_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        self.log.info(f"Inside test step {test_metrics}")
        
        # Return predicted labels or other relevant information if needed
        return predicted_labels

    
    def predict_step(self, batch, batch_idx, dataloader_idx: int = 0):
        input_ids, attention_mask, labels = batch
        outputs = self(input_ids, attention_mask)
        # outputs is the model prediction tensor for each class
        pred_probabilities = torch.softmax(outputs, dim=1)
        # TODO if pred_probabilities < 0.9 set index unknown
        
        # predicted class indices
        pred_indices = pred_probabilities.argmax(dim=1).cpu().numpy()

        print(f"expected idx {labels} and predictions {pred_indices}")
        
        return pred_indices

