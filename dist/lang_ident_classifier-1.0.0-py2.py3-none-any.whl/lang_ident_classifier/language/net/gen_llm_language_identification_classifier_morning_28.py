# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the authora if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, OrderedDict, defaultdict
import copy
import gc
import json
import math
import os
import sys
import numpy as np
import pandas as pd
import torch
import lightning as pl
import bitsandbytes
from torchmetrics import Accuracy, ConfusionMatrix, Precision, Recall, F1Score
from torch.amp import autocast
from cachetools import LRUCache
from lang_ident_classifier.language.accuracy.class_weighted_accuracy import ClassWeightedAccuracy
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset
from lang_ident_classifier.language.loss.class_weighted_focal_loss_with_adaptive_focus import ClassWeightedFocalLossWithAdaptiveFocus
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
from transformers import AutoModelForSeq2SeqLM
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# Global cache (NOT in model class)
FROZEN_EMBEDDING = None  
# MAX_OLD_EMBS = 1000  # Limit the cache size

# class LRUCacheDict(OrderedDict):
#     def __init__(self, max_size):
#         self.max_size = max_size
#         super().__init__()

#     def __getitem__(self, key):
#         value = super().__getitem__(key)
#         self.move_to_end(key)
#         return value

#     def __setitem__(self, key, value):
#         if key in self:
#             self.move_to_end(key)
#         elif len(self) >= self.max_size:
#             self.popitem(last=False)  # Remove LRU item
#         super().__setitem__(key, value)

# OLD_EMB_TRAIN = LRUCacheDict(max_size=MAX_OLD_EMBS)
# OLD_EMB_VAL = LRUCacheDict(max_size=MAX_OLD_EMBS)

class SafeModuleWrapper(torch.nn.Module):
    def __init__(self, module, clamp_min=-5, clamp_max=5):
        super().__init__()
        self.module = module
        # self.module = module.to(dtype=torch.float32)  # Convert module to FP32
        # for param in self.module.parameters():
        #     param.data = param.data.to(torch.float32)
        # for buffer in self.module.buffers():
        #     buffer.data = buffer.data.to(torch.float32)
        
        self.clamp_min = clamp_min
        self.clamp_max = clamp_max

    # def forward(self, *inputs, **kwargs):
    #     # Ensure all inputs are float32 if they are tensors
    #     inputs = tuple(inp.float() if isinstance(inp, torch.Tensor) else inp for inp in inputs)
        
    #     # Logging dtype info
    #     # param_dtypes = {name: param.dtype for name, param in self.module.named_parameters()}
    #     # buffer_dtypes = {name: buffer.dtype for name, buffer in self.module.named_buffers()}
    #     # print(f"[Forward Pass] {self.module.__class__.__name__} running")
    #     # print(f"  - Parameters Dtype: {param_dtypes if param_dtypes else 'No Parameters'}")
    #     # print(f"  - Buffers Dtype: {buffer_dtypes if buffer_dtypes else 'No Buffers'}")

    #     # Forward pass
    #     output = self.module(*inputs, **kwargs)
        
    #     # Convert output to FP32 and clamp if necessary
    #     if isinstance(output, torch.Tensor):
    #         output = torch.clamp(output.float(), min=self.clamp_min, max=self.clamp_max)
    #         return torch.nan_to_num(output)
    #     return output  # If it's not a tensor, return as is

    def forward(self, *inputs, **kwargs):
        # # Convert to float32 if needed
        inputs = tuple(
            inp.to(torch.float32) if isinstance(inp, torch.Tensor) and inp.dtype != torch.float32 else inp
            for inp in inputs
        )
        # Pre-check inputs
        for i, inp in enumerate(inputs):
            if isinstance(inp, torch.Tensor) and not torch.isfinite(inp).all():
                inp = torch.nan_to_num(inp)

        # Run module
        output = self.module(*inputs, **kwargs)

        # Post-check output
        if isinstance(output, torch.Tensor):
            output = output.to(torch.float32)
            if not torch.isfinite(output).all():
                output = torch.nan_to_num(output)
            output.clamp_(self.clamp_min, self.clamp_max)
            return output

        return output

    
class GenLLMLanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        pretrained_embedding_model,
        class_names,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_backbone_model_units_unfrozen,
        loss_type,
        is_train,
        tokenizer,
        prompt_length,
        random_seed: int = 20,
        pretrained_model_embedding_name = None,
        trial_number=None,
        decision_threshold=0.0
    ):
        super(GenLLMLanguageIdentificationClassifier, self).__init__()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self.save_hyperparameters({
            "lr": float(lr),
            "optimizer": str(optimizer),
            "num_backbone_model_units_unfrozen": int(num_backbone_model_units_unfrozen),
            "loss_type": str(loss_type),
            "is_train": bool(is_train),
            "random_seed": int(random_seed),
        })
        # print(f"HPARAMS {self.hparams}")
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
        np.random.seed(random_seed)
        self.trial_number = int(trial_number) if trial_number is not None else None
        self.tokenizer = tokenizer
        self.tokenizer_separator_token = tokenizer.encode(" ", add_special_tokens=False)[0]
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.pretrained_model_embedding_name = pretrained_model_embedding_name
        self.num_classes = len(class_names)
        self.class_names = ["unk"] + class_names
        self.class2seq = {}
        for idx, cname in enumerate(self.class_names):
            # tokenize without special tokens
            seq = self.tokenizer.encode(cname, add_special_tokens=False)
            self.class2seq[idx] = seq
        # inverse map
        self.seq2class = {tuple(v): k for k,v in self.class2seq.items()}
        self.len2classes = defaultdict(list)   # maps length L -> list of (class_id, seq_ids)
        for cls_id, seq in self.class2seq.items():
            self.len2classes[len(seq)].append((cls_id, seq))
        self.unk_idx = 0
        print(f"SEQ {self.class2seq} and {self.seq2class}")
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.ignore_idx = tokenizer.pad_token_id if tokenizer.pad_token_id else -100

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self.embedding = pretrained_embedding_model
        # # Convert LayerNorm inside self.embedding to FP32
        # for module in self.modules():
        #     if isinstance(module, torch.nn.LayerNorm):
        #         module.to(torch.float32)  # Convert weights & buffers to FP32
        #         module.weight.data = module.weight.data.to(torch.float32)
        #         if module.bias is not None:
        #             module.bias.data = module.bias.data.to(torch.float32)
        self.embedding.requires_grad_(False).to(self.curr_device)
        if num_backbone_model_units_unfrozen > 0:
            if "llama" in self.pretrained_model_embedding_name:
                for param in self.embedding.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = False  # Freeze all layers initially
                
                # Access the LlamaDecoderLayers directly
                decoder_layers = self.embedding.model.layers  # (LlamaModel -> layers: ModuleList)
                
                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for block in decoder_layers[-num_backbone_model_units_unfrozen:]:
                    for param in block.parameters():
                        if isinstance(param, torch.Tensor) and (param.is_floating_point() or torch.is_complex(param)):
                            param.requires_grad = True

        # Create learnable prompt embeddings (random init)
        global FROZEN_EMBEDDING 
        FROZEN_EMBEDDING = copy.deepcopy(self.embedding).eval()
        self.lr = lr

        # Loss function initialization
        if loss_type.casefold() == "class_weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=0.25, device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type1', device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type2', device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type3', device=self.curr_device, ignore_index=-100)
        else:
            self._criterion = ClassWeightedCrossEntropyLoss(device=self.curr_device, ignore_index=-100)
        
        # self._accuracy = Accuracy(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)
        # self._precision = Precision(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)
        # self._recall = Recall(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)
        # self._f1 = F1Score(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)

        self._accuracy = ClassWeightedAccuracy(
            # device=self.curr_device,
            class_weights=self.class_weights,
            # num_classes=self.num_classes,
            num_classes=self.tokenizer.vocab_size,
            # task=self.classification_task,
            ignore_index=-100,
            average="custom",
        ).to('cpu')

        self._micro_accuracy = Accuracy(
            num_classes=self.num_classes+1,
            average="micro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._macro_accuracy = Accuracy(
            num_classes=self.num_classes+1,
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._macro_precision = Precision(
            num_classes=self.num_classes+1,
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._macro_recall = Recall(
            num_classes=self.num_classes+1,
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._macro_f1 = F1Score(
            num_classes=self.num_classes+1,
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        # Classwise metrics (per-class values, tensor of shape [num_classes])
        self._classwise_accuracy = Accuracy(
            num_classes=self.num_classes+1,
            average=None,   # <-- per-class instead of macro/micro
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._classwise_precision = Precision(
            num_classes=self.num_classes+1,
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._classwise_recall = Recall(
            num_classes=self.num_classes+1,
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._classwise_f1 = F1Score(
            num_classes=self.num_classes+1,
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to("cpu")

        self._confmat = ConfusionMatrix(
            num_classes=self.num_classes+1,
            task=self.classification_task,
            normalize=None,  # can also be "true" for row-normalized
            ignore_index=self.ignore_idx,
        ).to("cpu")


        self._validation_outputs = []
        self._test_outputs = []
        
        self.optimizer_name = optimizer.casefold()
        self.fix_embedding_layers()

        self.register_nan_hooks(self.embedding)
        # self.initialize_weights(self.curr_device, num_fc_layers)
    
    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            # return torch.nn.PReLU(num_parameters=num_parameters)
            return torch.nn.PReLU(num_parameters=1)
        elif activation_function_for_layer.casefold() == "leaky_relu":
            return torch.nn.LeakyReLU(inplace=False)
        else:
            return torch.nn.ReLU(inplace=False) # in place tensor modifications disabled due to issues in gradient 
        
    def register_nan_hooks(self, module, prefix=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for name, child in module.named_children():
            full_name = f"{prefix}.{name}" if prefix else name  # Keep full layer path

            # Hook function to check for NaNs in forward pass
            def detect_nan_hook(mod, inp, out):
                if isinstance(out, torch.Tensor) and out.isnan().any():
                    print(f"NaN detected in {full_name} ({mod.__class__.__name__}) ({out.dtype})")

            child.register_forward_hook(detect_nan_hook)

            # Recursively apply to children
            self.register_nan_hooks(child, full_name)

    def initialize_weights(self, device, num_fc_layers):
        def _initialize_weights(m):
            if hasattr(m, "weight") and m.weight.dim() > 1:
                # print(f"Initializing {m}")
                m.to(device)
                torch.nn.init.xavier_uniform_(m.weight.data)
                # if m.bias is not None:  # Initialize bias as well
                #     torch.nn.init.zeros_(m.bias.data)
        
        # for layer_idx in range(num_fc_layers):
        #     layer = getattr(self, f"fc_{layer_idx+1}")
        #     layer.apply(_initialize_weights)
        fc_layers = [layer for name, layer in self._modules.items() if name.startswith("fc_")]
        # print(f"Initializing layers {fc_layers}")
        for layer in fc_layers:
            layer.apply(_initialize_weights)
    
    def has_trainable_params(self, module):
        return any(p.requires_grad for p in module.parameters())  # Includes submodules
    
    def fix_embedding_layers(self):
        """Convert unstable modules (LayerNorm, RMSNorm, Linear4bit, MLP, activations, attention, projections) 
        to float32 and wrap them safely to prevent NaNs."""

        updates = []

        for name, module in self.named_modules():
            if not self.has_trainable_params(module):
                continue  # Skip frozen layers

            # Anything prone to NaNs
            is_unstable = any(k in name.lower() for k in [
                "norm", "linear4bit", "mlp", "act", "attention", "proj","gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"
            ]) or isinstance(module, torch.nn.LayerNorm)

            if is_unstable:
                if hasattr(module, "eps"):  
                    module.eps = max(getattr(module, "eps", 1e-5), 1e-5)  # stabilize norms
                module = module.to(torch.float32)  # force fp32
                if not isinstance(module, SafeModuleWrapper):
                    updates.append((name, SafeModuleWrapper(module)))

        # Apply wrapped modules
        for name, new_module in updates:
            parent_module, attr = self.get_parent_and_attr(name)
            if parent_module is not None:
                setattr(parent_module, attr, new_module)

    def get_parent_and_attr(self, module_name):
        """Finds the parent module and attribute name given the full module path."""
        parts = module_name.split('.')
        parent = self  # Start from the main model
        for part in parts[:-1]:  # Traverse down but stop at the parent
            parent = getattr(parent, part, None)
            if parent is None:
                return None, None
        return parent, parts[-1]  # Return parent module and final attribute

    def forward(self, input_ids, labels=None):
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        attention_mask = (input_ids != self.tokenizer.eos_token_id).to(dtype=torch.bool, device=self.curr_device, non_blocking=True)

        outputs = self.embedding(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=True,
            return_dict=True
        )

        logits = outputs.logits

        # Optional: KL + contrastive loss
        kl_loss = torch.tensor(0.0, device=self.curr_device)
        contrastive_loss = torch.tensor(0.0, device=self.curr_device)
        if self.trainer.training or self.trainer.validating:
            frozen_outputs = FROZEN_EMBEDDING(input_ids).logits.detach()
            kl_loss, contrastive_loss = self.compute_kl_contrastive_loss(
                logits, frozen_outputs, device=self.curr_device
            )

        return logits, kl_loss, contrastive_loss

    def register_amp_hooks(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def hook_fn(module, inputs, outputs):
            if any(inp.dtype == torch.float16 for inp in inputs if isinstance(inp, torch.Tensor)):
                print(f"Layer {module.__class__.__name__} is using float16!")

        # Attach hooks to all layers in self.model
        for submodule in self.modules():
            hook = submodule.register_forward_hook(hook_fn)
            self.amp_hooks.append(hook)  # Store hooks to remove them later if needed

    def remove_hooks(self):
        """Remove all registered forward hooks."""
        for hook in getattr(self, "amp_hooks", []):
            hook.remove()
        self.amp_hooks = []

    def align_tokens_to_words(self, input_ids, token_preds, token_labels):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        tokens = [self.tokenizer.convert_ids_to_tokens(ids) for ids in input_ids]
        word_preds, word_labels = [], []
        
        for token_seq, pred_seq, label_seq in zip(tokens, token_preds, token_labels):
            for token, pred, label in zip(token_seq, pred_seq, label_seq):
                if token == self.tokenizer.pad_token or label == -100:
                    continue  # Skip padding & ignored labels

                # Detect subword tokens (model-specific handling)
                is_subword = (
                    token.startswith("##") or  # BERT/RoBERTa (WordPiece)
                    token.startswith("▁") or   # IndicBERT/mT5 (SentencePiece)
                    token in ["<unk>", "<pad>"]  # Generic unknown/padding tokens
                )

                if is_subword:
                    continue  # Ignore subword parts, keep only first part's label
                
                # Store the first subword’s label as word-level
                word_preds.append(pred.item())
                word_labels.append(label.item())

        return torch.tensor(word_preds), torch.tensor(word_labels)

    def compute_kl_contrastive_loss(self, new_emb_cpu, old_emb_cpu, device="cuda"):
        """Computes KL divergence and contrastive loss efficiently with minimal GPU usage."""
        
        # Ensure tensors are detached and moved to CPU for lightweight loss computation
        # new_emb_cpu = new_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)
        # old_emb_cpu = old_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)
        new_emb_cpu = new_emb_cpu.clamp(min=-30, max=30)
        old_emb_cpu = old_emb_cpu.clamp(min=-30, max=30)
        T = 2.0 # Temperature fixed in Hinto et al 2015 set at 2 or 3 most cases works
        # Compute KL divergence using more stable log-softmax
        new_emb_log = torch.nn.functional.log_softmax(new_emb_cpu/T, dim=-1)
        old_emb_prob = torch.nn.functional.softmax(old_emb_cpu/T, dim=-1)
        latent_dim = new_emb_log.shape[-1]  # Safe for [batch, dim]
        kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean")* (T * T) / latent_dim

        # Compute cosine similarity for contrastive loss No scaling on temp for constractive since cosine is scale invariant
        embedding_drift = torch.nn.functional.cosine_similarity(new_emb_cpu, old_emb_cpu, dim=-1).mean()
        contrastive_loss = 1 - embedding_drift

        # Free CPU memory after computation
        del new_emb_cpu, old_emb_cpu
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Ensure GPU stays clean

        # Move results back to GPU if necessary
        return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    
    def training_step(self, batch, batch_idx):
        """Optimized training step with reduced memory footprint and improved stability."""

        # input_ids, labels = batch
        input_ids = batch["input_ids"]
        labels = batch["labels"]
        batch_size = input_ids.size(0)

        # Ensure data is on the correct device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        labels = labels.to(self.curr_device, non_blocking=True)

        # Forward pass
        outputs, kl_loss, contrastive_loss = self(input_ids)

        # Flatten outputs and labels for loss computation
        # outputs = outputs.contiguous().view(-1, outputs.shape[-1])
        # labels = labels.contiguous().view(-1)

        shift_logits = outputs[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()
        # print(f"[Step T4] Shifted logits: {shift_logits.shape}, Shifted labels: {shift_labels.shape}")

        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)
        # Compute classification loss
        loss = self._criterion(logits_flat, labels_flat)

        # Ensure KL and contrastive loss values are finite
        # loss = torch.nan_to_num(loss, nan=0.0)
        # kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
        # contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)
        # Replace NaNs while preserving autograd graph
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)

        # Combine losses with scaling factors
        # λ_kl = max(1.0 - self.trainer.current_epoch * 0.1, 0.2)
        epoch = float(self.trainer.current_epoch)
        λ_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
        λ_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
        combined_loss = loss + λ_kl * kl_loss + λ_contrast * contrastive_loss

        # combined_loss = loss + 0.05 * kl_loss + 0.05 * contrastive_loss

        # Convert logits to predicted labels
        # with torch.no_grad():  # Prevent gradient tracking for metrics
        #     predicted_labels = torch.argmax(outputs, dim=1)
        #     accuracy = self._accuracy(predicted_labels, labels)
        #     precision = self._precision(predicted_labels, labels)
        #     recall = self._recall(predicted_labels, labels)
        #     f1 = self._f1(predicted_labels, labels)

        # Check for NaN loss and log issue
        if torch.isnan(loss):
            print(f"Step {batch_idx}: NaN loss detected!")

        # Store training metrics
        train_metrics = {
            "epoch": float(self.current_epoch),
            "train_kl_loss": kl_loss.detach(),
            "train_contrastive_loss": contrastive_loss.detach(),
            "train_classification_loss": loss.detach(),
            "train_loss": combined_loss.detach(),
            "train_λ_kl": λ_kl,
            "train_λ_contrast": λ_contrast,
            # "train_accuracy": accuracy,
            # "train_precision": precision,
            # "train_recall": recall,
            # "train_f1": f1,
        }

        # self.log("epoch", float(self.current_epoch), 
        #         on_step=False,
        #         on_epoch=True,
        #         prog_bar=False,
        #         logger=True,
        #         sync_dist=False)
        # self.log("train_λ_kl", λ_kl, 
        #         on_step=False,
        #         on_epoch=True,
        #         prog_bar=False,
        #         logger=True,
        #         sync_dist=False)
        # self.log("train_λ_contrast", λ_contrast,
        #         on_step=False,
        #         on_epoch=True,
        #         prog_bar=False,
        #         logger=True,
        #         sync_dist=False)

        # Log metrics without unnecessary sync overhead
        self.log_dict(
            train_metrics,
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,  # Sync across GPUs in distributed training
        )
        # self.log(
        #     "epoch", float(self.current_epoch),
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=True,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )
        # self.log(
        #     "train_λ_kl", λ_kl,
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=True,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )
        # self.log(
        #     "train_λ_contrast", λ_contrast,
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=True,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )


        # Explicitly delete tensors to free memory
        del input_ids, labels, outputs
        # del predicted_labels
        del kl_loss, loss, contrastive_loss
        del shift_labels, shift_logits, labels_flat, logits_flat
        # if torch.cuda.is_available():
        #     torch.cuda.empty_cache()  # Free GPU memory

        return combined_loss # returned loss to avoid warning
        # return # Nothing returned since core thinsg are logged in log_dict
    
    def on_train_epoch_end(self):
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()
        return super().on_train_epoch_end()

    def validation_step(self, batch, batch_idx):
        # if batch_idx == 0:
        #     print(f"\n[VAL STEP] Batch {batch_idx}")
        #     print("input_ids shape:", batch["input_ids"].shape)
        #     print("labels shape:", batch["labels"].shape)
        #     print("labels min/max:", batch["labels"].min().item(), batch["labels"].max().item())
        #     print("sample_ids:", batch["sample_ids"][:5])  # first 5 sample ids
        #     print("chunk_ids:", batch["chunk_ids"][:5])
        #     print("word_positions lengths:", [len(wp) for wp in batch["word_positions"][:5]])
        #     print("labels:", batch["labels"])
        input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
        labels         = batch["labels"].to(self.curr_device, non_blocking=True)
        lang_codes     = batch["lang_codes"]
        sample_ids     = batch["sample_ids"]
        chunk_ids      = batch["chunk_ids"]
        word_positions = batch["word_positions"]

        batch_size = input_ids.size(0)

        # Forward
        outputs, kl_loss, contrastive_loss = self(input_ids)

        # Shift
        shift_logits = outputs[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()

        # Loss
        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)
        loss = self._criterion(logits_flat, labels_flat)

        # NaN guards
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)

        # Combine losses
        epoch = float(self.trainer.current_epoch)
        λ_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
        λ_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
        combined_loss = loss + λ_kl * kl_loss + λ_contrast * contrastive_loss

        # Log
        self.log_dict(
            {
                "val_kl_loss": kl_loss.detach(),
                "val_contrastive_loss": contrastive_loss.detach(),
                "val_classification_loss": loss.detach(),
                "val_loss": combined_loss.detach(),
                "val_λ_kl": λ_kl,
                "val_λ_contrast": λ_contrast,
            },
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        # ---- Per-word CLASS prediction ----
        preds_list, labels_list = [], []
        sep_id = getattr(self, "tokenizer_separator_token", None)
        if sep_id is None:
            sep_id = self.tokenizer.encode(" ", add_special_tokens=False)[0]
        unk_idx = getattr(self, "unk_idx", 0)

        for i in range(batch_size):
            logit = shift_logits[i]
            label = shift_labels[i]
            mask  = (label != -100)

            if not mask.any():
                preds_list.append(torch.empty(0, dtype=torch.long))
                labels_list.append(torch.empty(0, dtype=torch.long))
                continue

            # Gold runs (don’t split inside multi-token label)
            gold_ids  = label[mask].tolist()
            gold_runs, cur = [], []
            for tid in gold_ids:
                if tid == sep_id:
                    if cur: gold_runs.append(cur); cur = []
                else:
                    cur.append(tid)
            if cur: gold_runs.append(cur)

            logp = torch.log_softmax(logit[mask], dim=-1)  # (valid_len, vocab)
            ptr = 0
            y_pred_cls, y_true_cls = [], []

            for run in gold_runs:
                L = len(run)
                if ptr + L > logp.size(0):
                    y_pred_cls.append(unk_idx)
                    y_true_cls.append(self.seq2class.get(tuple(run), unk_idx))
                    break

                seg = logp[ptr:ptr + L]  # (L, V)
                ptr += L

                # Gold class ID
                g_cls = self.seq2class.get(tuple(run), unk_idx)
                y_true_cls.append(g_cls)

                # Score all classes (non-leaky)
                best_cls, best_score = unk_idx, float("-inf")
                for cls_id, seq in self.class2seq.items():
                    Lc = len(seq)
                    if Lc == 0 or Lc > seg.size(0):
                        continue
                    row_idx   = torch.arange(Lc, device=seg.device)
                    seq_tensor = torch.tensor(seq, device=seg.device, dtype=torch.long)
                    score = seg[row_idx, seq_tensor].sum().item()
                    if score > best_score:
                        best_score, best_cls = score, cls_id

                y_pred_cls.append(best_cls)

            preds_list.append(torch.tensor(y_pred_cls, dtype=torch.long))
            labels_list.append(torch.tensor(y_true_cls, dtype=torch.long))
        # ---- END ----

        output = {
            "lang_code": lang_codes,
            "preds": preds_list,
            "labels": labels_list,
            "sample_id": sample_ids,
            "chunk_id": chunk_ids,
            "word_positions": word_positions,
            "val_loss": combined_loss,
        }
        self._validation_outputs.append(output)

        # Cleanup
        del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
        del kl_loss, contrastive_loss, loss, preds_list, labels_list

        return output



    def _save_metrics_to_csv(self, metrics_dict, filename, trial_number=None):
        """Helper to save metrics to CSV in per-trial directory."""
        # Figure out project dir (Lightning usually has self.logger.log_dir)
        project_dir = os.getcwd()
        trial_id = f"trial_{trial_number}" if trial_number is not None else "default"

        save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        os.makedirs(save_dir, exist_ok=True)

        filepath = os.path.join(save_dir, filename)
        df = pd.DataFrame(metrics_dict)
        df.to_csv(filepath, index=False)
        print(f"[metrics] Saved {filepath}")


    def on_validation_epoch_end(self):
        if not self._validation_outputs:
            print("[on_validation_epoch_end] No validation outputs to process.")
            return

        # Reconcile chunked predictions
        preds, labels = self.reconcile_chunks(self._validation_outputs)
        print(f"[on_validation_epoch_end] reconcile_chunks -> preds={preds.shape}, labels={labels.shape}")
        if preds.numel() == 0 or labels.numel() == 0:
            print("[on_validation_epoch_end] Empty preds/labels after reconcile! Skipping metrics.")
            return

        device = self._micro_accuracy.device
        preds, labels = preds.to(device), labels.to(device)

        # --- DEBUG PRINTS ---
        print(f"[on_validation_epoch_end] Sample preds[:20]: {preds[:20].tolist()}")
        print(f"[on_validation_epoch_end] Sample labels[:20]: {labels[:20].tolist()}")
        print(f"[on_validation_epoch_end] Unique preds: {torch.unique(preds).tolist()}")
        print(f"[on_validation_epoch_end] Unique labels: {torch.unique(labels).tolist()}")
        print(f"[on_validation_epoch_end] Num classes = {self.num_classes}, "
            f"ignore_idx = {self.ignore_idx}, unk_idx = {getattr(self, 'unk_idx', None)}")

        try:
            # Update all metrics
            self._micro_accuracy.update(preds, labels)
            self._macro_accuracy.update(preds, labels)
            self._macro_precision.update(preds, labels)
            self._macro_recall.update(preds, labels)
            self._macro_f1.update(preds, labels)

            self._classwise_accuracy.update(preds, labels)
            self._classwise_precision.update(preds, labels)
            self._classwise_recall.update(preds, labels)
            self._classwise_f1.update(preds, labels)

            self._confmat.update(preds, labels)

            # Compute results
            final_micro_accuracy  = self._micro_accuracy.compute().item()
            final_macro_accuracy  = self._macro_accuracy.compute().item()
            final_macro_precision = self._macro_precision.compute().item()
            final_macro_recall    = self._macro_recall.compute().item()
            final_macro_f1        = self._macro_f1.compute().item()

            final_classwise_accuracy  = self._classwise_accuracy.compute().cpu().numpy()
            final_classwise_precision = self._classwise_precision.compute().cpu().numpy()
            final_classwise_recall    = self._classwise_recall.compute().cpu().numpy()
            final_classwise_f1        = self._classwise_f1.compute().cpu().numpy()

            final_confmat = self._confmat.compute().cpu().numpy()

        except Exception as e:
            print(f"[on_validation_epoch_end] Exception: {e}")
            return

        # Log macro metrics to Lightning
        self.log("val_accuracy", final_macro_accuracy, sync_dist=True)

        # Save full metrics to CSV
        trial = getattr(self, "trial", None)  # if Optuna trial is attached
        epoch_idx = self.current_epoch
        metrics_dict = {
            "epoch": [epoch_idx],
            "class_names": [self.class_names],
            "micro_accuracy": [final_micro_accuracy],
            "macro_accuracy": [final_macro_accuracy],
            "macro_precision": [final_macro_precision],
            "macro_recall": [final_macro_recall],
            "macro_f1": [final_macro_f1],
            "classwise_accuracy": [final_classwise_accuracy.tolist()],
            "classwise_precision": [final_classwise_precision.tolist()],
            "classwise_recall": [final_classwise_recall.tolist()],
            "classwise_f1": [final_classwise_f1.tolist()],
            "confusion_matrix": [final_confmat.tolist()],
        }
        print(f"[on_validation_epoch_end] Saving metrics for epoch {epoch_idx}")
        self._save_metrics_to_csv(metrics_dict, f"val_epoch_{epoch_idx}.csv", trial_number=self.trial_number)

        # Reset all
        self._micro_accuracy.reset()
        self._macro_accuracy.reset()
        self._macro_precision.reset()
        self._macro_recall.reset()
        self._macro_f1.reset()

        self._classwise_accuracy.reset()
        self._classwise_precision.reset()
        self._classwise_recall.reset()
        self._classwise_f1.reset()
        self._confmat.reset()
        self._validation_outputs.clear()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        print("[on_validation_epoch_end] Finished and cleaned up.")


    def test_step(self, batch, batch_idx):
        """Memory-efficient test step with chunk-level prediction output for later reconciliation."""
        with torch.no_grad():
            input_ids = batch["input_ids"].to(self.curr_device, non_blocking=True)
            labels = batch["labels"].to(self.curr_device, non_blocking=True)
            lang_codes_list = batch["lang_codes"]
            sample_ids = batch["sample_ids"]
            chunk_ids = batch["chunk_ids"]
            word_positions = batch["word_positions"]
            batch_size = input_ids.size(0)

            outputs, _, _ = self(input_ids)

            shift_logits = outputs[:, :-1, :].contiguous()
            shift_labels = labels[:, 1:].contiguous()

            preds_list = []
            labels_list = []

            # --- NEW: convert to per-word CLASS IDs using gold run lengths ---
            sep_id = getattr(self, "tokenizer_separator_token", None)
            if sep_id is None:
                sep_id = self.tokenizer.encode(" ", add_special_tokens=False)[0]
            unk_idx = 0  # "unk" is self.class_names[0]

            for i in range(batch_size):
                logit = shift_logits[i]       # (seq_len, vocab)
                label = shift_labels[i]       # (seq_len,)
                mask = label != -100

                gold_ids = label[mask].tolist()                         # (valid_len,)
                pred_ids = torch.argmax(logit[mask], dim=-1).tolist()   # (valid_len,)

                # build gold runs: contiguous non-space tokens (preserve multi-token labels)
                gold_runs, cur = [], []
                for tid in gold_ids:
                    if tid == sep_id:
                        if cur:
                            gold_runs.append(cur); cur = []
                    else:
                        cur.append(tid)
                if cur:
                    gold_runs.append(cur)

                # align predictions to gold by run length
                y_pred_cls, y_true_cls = [], []
                p_idx = 0
                for run in gold_runs:
                    L = len(run)
                    run_pred = []
                    while p_idx < len(pred_ids) and len(run_pred) < L:
                        if pred_ids[p_idx] != sep_id:
                            run_pred.append(pred_ids[p_idx])
                        p_idx += 1

                    g_cls = self.seq2class.get(tuple(run), unk_idx)
                    if len(run_pred) < L:
                        p_cls = unk_idx
                    else:
                        p_cls = self.seq2class.get(tuple(run_pred), unk_idx)

                    y_true_cls.append(g_cls)
                    y_pred_cls.append(p_cls)

                preds_list.append(torch.tensor(y_pred_cls, dtype=torch.long).cpu())
                labels_list.append(torch.tensor(y_true_cls, dtype=torch.long).cpu())
            # --- END NEW ---

            # output = {
            #     "preds": preds_list,
            #     "labels": labels_list,
            #     "sample_ids": sample_ids,
            #     "chunk_ids": chunk_ids,
            #     "word_positions": word_positions,
            # }
            output = {
                "lang_codes": lang_codes_list,
                "preds": preds_list,
                "labels": labels_list,
                "sample_ids": sample_ids,
                "chunk_ids": chunk_ids,
                "word_positions": word_positions,
            }

            self._test_outputs.append(output)

            del input_ids, labels, outputs, shift_logits, shift_labels

            return output

    def on_test_epoch_end(self):
        # Gather outputs across all test steps
        outputs = getattr(self, "_test_outputs", None)
        if outputs is None or len(outputs) == 0:
            return

        # Reconcile chunked predictions to sample-level (already CLASS IDs)
        preds, labels = self.reconcile_chunks(outputs)
        device = self._micro_accuracy.device
        preds, labels = preds.to(device), labels.to(device)

        # Compute final test metrics
        try:
            # Update all metrics
            self._micro_accuracy.update(preds, labels)
            self._macro_accuracy.update(preds, labels)
            self._macro_precision.update(preds, labels)
            self._macro_recall.update(preds, labels)
            self._macro_f1.update(preds, labels)

            self._classwise_accuracy.update(preds, labels)
            self._classwise_precision.update(preds, labels)
            self._classwise_recall.update(preds, labels)
            self._classwise_f1.update(preds, labels)

            self._confmat.update(preds, labels)

            # Compute
            final_micro_accuracy  = self._micro_accuracy.compute().item()
            final_macro_accuracy  = self._macro_accuracy.compute().item()
            final_macro_precision = self._macro_precision.compute().item()
            final_macro_recall    = self._macro_recall.compute().item()
            final_macro_f1        = self._macro_f1.compute().item()

            final_classwise_accuracy  = self._classwise_accuracy.compute().cpu().numpy()
            final_classwise_precision = self._classwise_precision.compute().cpu().numpy()
            final_classwise_recall    = self._classwise_recall.compute().cpu().numpy()
            final_classwise_f1        = self._classwise_f1.compute().cpu().numpy()

            final_confmat = self._confmat.compute().cpu().numpy()
        except Exception as e:
            print(f"[on_test_epoch_end] Exception: {e}")
            return

        # Log test metrics (headline)
        self.log(
            "test_accuracy",  # keeping your original key; this is MACRO acc to match val
            final_macro_accuracy,
            on_step=False,
            on_epoch=True,
            prog_bar=True,
            logger=True,
            sync_dist=True,
        )

        # Optionally save full metrics to CSV (parity with val)
        epoch_idx = getattr(self, "current_epoch", 0)
        metrics_dict = {
            "epoch": [epoch_idx],
            "class_names": [self.class_names],
            "micro_accuracy": [final_micro_accuracy],
            "macro_accuracy": [final_macro_accuracy],
            "macro_precision": [final_macro_precision],
            "macro_recall": [final_macro_recall],
            "macro_f1": [final_macro_f1],
            "classwise_accuracy": [final_classwise_accuracy.tolist()],
            "classwise_precision": [final_classwise_precision.tolist()],
            "classwise_recall": [final_classwise_recall.tolist()],
            "classwise_f1": [final_classwise_f1.tolist()],
            "confusion_matrix": [final_confmat.tolist()],
        }
        # if you want: self._save_metrics_to_csv(metrics_dict, f"test_epoch_{epoch_idx}.csv", trial_number=self.trial_number)

        # Reset metric
        self._micro_accuracy.reset()
        self._macro_accuracy.reset()
        self._macro_precision.reset()
        self._macro_recall.reset()
        self._macro_f1.reset()

        self._classwise_accuracy.reset()
        self._classwise_precision.reset()
        self._classwise_recall.reset()
        self._classwise_f1.reset()
        self._confmat.reset()

        # Clear stored outputs to avoid leakage across epochs
        self._test_outputs.clear()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()

    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        """Optimized prediction step with efficient memory handling."""

        input_ids, _ = batch  # Labels are not needed

        # Move tensors to device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)

        # Forward pass (without computing KL or contrastive loss)
        outputs, _, _ = self(input_ids)
        predicted_labels = torch.argmax(outputs, dim=-1)

        # Explicitly delete tensors to free memory
        del input_ids, outputs
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free GPU memory

        return {"predictions": predicted_labels.cpu()}

    def reconcile_chunks(self, outputs):
        print(f"\n[reconcile_chunks] Called with {len(outputs)} outputs")

        chunks_by_sample = defaultdict(list)

        for out in outputs:
            lang_codes     = out["lang_code"]      # list[str] (batched)
            sample_ids     = out["sample_id"]      # list[int] or 1D tensor
            chunk_ids      = out["chunk_id"]       # list[int] or 1D tensor
            chunk_preds    = out["preds"]          # list[tensor] of class IDs (per-word)
            chunk_labels   = out["labels"]         # list[tensor] of class IDs (per-word)
            word_positions = out["word_positions"] # list[list[int]] (per-chunk local positions)

            # unify python types for batch-level containers
            if isinstance(sample_ids, torch.Tensor):
                sample_ids = sample_ids.cpu().tolist()
            if isinstance(chunk_ids, torch.Tensor):
                chunk_ids = chunk_ids.cpu().tolist()

            # iterate per-chunk item
            for i in range(len(sample_ids)):
                sid       = sample_ids[i]
                cid       = chunk_ids[i]
                lang_code = lang_codes[i]                 # keep as human-readable string
                preds_i   = chunk_preds[i]                # 1D tensor (len == num words we emitted)
                labels_i  = chunk_labels[i]               # 1D tensor
                positions = word_positions[i]             # list[int] (per-word positions within sentence)

                # normalize types
                if isinstance(sid, torch.Tensor):
                    sid = int(sid.item())
                else:
                    sid = int(sid)
                if isinstance(cid, torch.Tensor):
                    cid = int(cid.item())
                else:
                    cid = int(cid)

                if isinstance(positions, torch.Tensor):
                    positions = positions.cpu().tolist()

                # make sure preds/labels are 1D CPU lists for safe indexing
                if isinstance(preds_i, torch.Tensor):
                    preds_i = preds_i.cpu()
                if isinstance(labels_i, torch.Tensor):
                    labels_i = labels_i.cpu()

                # harden against length mismatches (take common overlap)
                L = min(len(positions), len(preds_i), len(labels_i))
                if L == 0:
                    continue
                if len(positions) != L:
                    positions = positions[:L]
                preds_i  = preds_i[:L]
                labels_i = labels_i[:L]

                # composite key avoids collisions across batches
                key = (sid, cid, lang_code)  # lang_code stays a string
                chunks_by_sample[key].append((positions, preds_i, labels_i))

        final_preds = []
        final_labels = []

        for key, chunks in chunks_by_sample.items():
            pos_to_preds  = defaultdict(list)
            pos_to_labels = defaultdict(list)

            for positions, preds, labels in chunks:
                # positions is list[int], preds/labels are 1D tensors (same length)
                for j, pos in enumerate(positions):
                    pred  = int(preds[j].item())
                    label = int(labels[j].item())
                    pos_to_preds[pos].append(pred)
                    pos_to_labels[pos].append(label)

            if not pos_to_preds:
                continue

            for pos in sorted(pos_to_preds.keys()):
                pred_final  = Counter(pos_to_preds[pos]).most_common(1)[0][0]
                label_final = Counter(pos_to_labels[pos]).most_common(1)[0][0]
                final_preds.append(pred_final)
                final_labels.append(label_final)

        # return CPU tensors of class IDs
        return torch.tensor(final_preds, device="cpu"), torch.tensor(final_labels, device="cpu")

    def on_before_optimizer_step(self, optimizer):
        torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
    
    def on_after_optimizer_step(self, optimizer):
        for param in self.parameters():
            if param is not None:
                param.data.clamp_(-5, 5)

    def _compute_grad_norm(self):
        total_norm = 0
        for param in self.parameters():
            if param.grad is not None:
                param_norm = param.grad.detach().data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5  # L2 norm

    def configure_optimizers(self):
        """Configures optimizer and learning rate scheduler."""
        trainable_params = [p for p in self.parameters() if p.requires_grad]
        if not trainable_params:
            print("No trainable parameters. Skipping optimizer creation.")
            return None  # or [] depending on version
        
        # Filter trainable parameters
        model_parameters = filter(lambda p: p.requires_grad, self.parameters())

        # Select optimizer
        optimizers = {
            "adamw": torch.optim.AdamW,
            "adamax": torch.optim.Adamax,
            "adam": torch.optim.Adam,
        }
        optimizer_class = optimizers.get(self.optimizer_name.lower(), torch.optim.Adam)  # Default to Adam

        optimizer = optimizer_class(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Uncomment if using bitsandbytes optimizers
        # if self.optimizer_name == "adamw":
        #     optimizer = bitsandbytes.optim.AdamW(model_parameters, lr=self.hparams.lr, weight_decay=0.001)
        # elif self.optimizer_name == "adam":
        #     optimizer = bitsandbytes.optim.Adam(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Learning rate scheduler
        # lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        #     optimizer, mode="min", factor=0.1, patience=3, cooldown=3, min_lr=1e-8, verbose=True
        # )
        # lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=2, eta_min=1e-6)
    

        # Warmup: 10% of total epochs, rounded up
        total_epochs = self.trainer.max_epochs
        warmup_epochs = math.ceil(0.1 * total_epochs)

        # Warmup LR schedule: linear increase
        warmup_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda epoch: (epoch + 1) / warmup_epochs)

        # CosineAnnealingWarmRestarts after warmup
        cosine_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer,
            T_0=max(1, total_epochs - warmup_epochs),
            T_mult=2,
            eta_min=1e-6
        )

        # Combine both in a SequentialLR
        lr_scheduler = torch.optim.lr_scheduler.SequentialLR(
            optimizer,
            schedulers=[warmup_scheduler, cosine_scheduler],
            milestones=[warmup_epochs]
        )
        # Debugging/logging (if needed)
        # print(f"Using optimizer: {self.optimizer_name}")
        # print(f"Initial learning rate: {self.hparams.lr}")
        # print(f"Weight decay: 0.001")
        
        return {"optimizer": optimizer, "lr_scheduler": {"scheduler": lr_scheduler, "interval": "epoch", "monitor": "val_loss"}}

