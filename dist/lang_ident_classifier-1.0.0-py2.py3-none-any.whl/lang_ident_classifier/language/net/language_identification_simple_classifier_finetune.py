# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import math
import torch
import lightning as pl
from torch import nn
from torchmetrics import Accuracy, Precision, Recall, F1Score
from torch.amp import autocast
from language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'


class LanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        num_classes,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_embedding_layers_unfrozen,
        loss_type,
        num_fc_layers,
        activation_function_for_layer,
        add_dropout_after_embedding,
        pretrained_model
    ):
        super().__init__()
        self.save_hyperparameters(ignore=["pretrained_embedding_model"])
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.num_classes = num_classes
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.num_fc_layers = num_fc_layers
        self.activation_function_for_layer = activation_function_for_layer
        # Load the pretrained embedding and the FC layers of the original model
        # Load the pretrained model
        self.pretrained_model = pretrained_model
        
        # Freeze all parameters except the ones you want to modify
        for param in self.pretrained_model.parameters():
            param.requires_grad = False

        # Unfreeze the parameters of the last fully connected layer
        last_fc_layer_name = f"fc_{self.pretrained_model.num_fc_layers}"
        last_fc_layer = getattr(self.pretrained_model, last_fc_layer_name)
        for param in last_fc_layer.parameters():
            param.requires_grad = True
        
        # Replace the last fully connected layer with a new layer
        self.pretrained_model.new_fc_layer = nn.Linear(last_fc_layer.in_features, num_classes)
        if num_embedding_layers_unfrozen > 0:
            for param in self.pretrained_model.embedding.pooler.parameters():
                param.requires_grad = True
            if num_embedding_layers_unfrozen > 1:
                for param in self.pretrained_model.embedding.encoder.layer[-(num_embedding_layers_unfrozen-1)].parameters():
                    param.requires_grad = True
        if loss_type.casefold() == "weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, device=self.curr_device)
        elif loss_type.casefold() == "weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, device=self.curr_device)
        else:
            self._criterion = nn.CrossEntropyLoss()
        self._accuracy = Accuracy(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._precision = Precision(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._recall = Recall(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self._f1 = F1Score(
            num_classes=self.num_classes,
            average="weighted",
            task=self.classification_task,
        ).to(self.curr_device)
        self.optimizer_name = optimizer.casefold()
        self.initialize_weights(self.curr_device, num_fc_layers)
    
    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            return nn.PReLU(num_parameters=num_parameters)
        else:
            return nn.ReLU()

    def initialize_weights(self, device, num_fc_layers):
        def _initialize_weights(m):
            if hasattr(m, "weight") and m.weight.dim() > 1:
                m.to(device)
                nn.init.xavier_uniform_(m.weight.data)
        
        for layer_idx in range(num_fc_layers):
            layer = getattr(self, f"fc_{layer_idx+1}")
            layer.apply(_initialize_weights)
    
    # @autocast(CAST_TO_DEVICE)
    def forward(self, input_ids, attention_mask):
        input_ids = input_ids.to(self.curr_device)
        attention_mask = attention_mask.to(self.curr_device)
        # Forward pass through the modified model
        output = self.pretrained_model(input_ids, attention_mask)
        return output

    def training_step(self, batch, batch_idx):
        input_ids, attention_mask, labels = batch
        outputs = self(input_ids, attention_mask)
        loss = self._criterion(outputs, labels)
        epoch = float(self.current_epoch)
        accuracy = self._accuracy(outputs, labels)
        precision = self._precision(outputs, labels)
        recall = self._recall(outputs, labels)
        f1 = self._f1(outputs, labels)
        train_metrics = {
            "train_loss": loss,
            "train_accuracy": accuracy,
            "train_precision": precision,
            "train_recall": recall,
            "train_f1": f1,
        }
        self.log(
            name="epoch",
            value=epoch,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            rank_zero_only=True,
        )
        self.log_dict(
            train_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )
        return loss

    def validation_step(self, batch, batch_idx):
        input_ids, attention_mask, labels = batch
        outputs = self(input_ids, attention_mask)
        loss = self._criterion(outputs, labels)
        accuracy = self._accuracy(outputs, labels)
        precision = self._precision(outputs, labels)
        recall = self._recall(outputs, labels)
        f1 = self._f1(outputs, labels)
        val_metrics = {
            "val_loss": loss,
            "val_accuracy": accuracy,
            "val_precision": precision,
            "val_recall": recall,
            "val_f1": f1,
        }
        self.log_dict(
            val_metrics,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )
        return loss
    
    def predict_step(self, batch, batch_idx, dataloader_idx: int = 0):
        input_ids, attention_mask, labels = batch
        outputs = self(input_ids, attention_mask)
        # outputs is the model prediction tensor for each class
        pred_probabilities = torch.softmax(outputs, dim=1)
        # TODO if pred_probabilities < 0.9 set index unknown
        
        # predicted class indices
        pred_indices = pred_probabilities.argmax(dim=1).cpu().numpy()

        print(f"expected idx {labels} and predictions {pred_indices}")
        
        return pred_indices

    def configure_optimizers(self):
        model_parameters = filter(lambda p: p.requires_grad, self.trainer.model.parameters())
        if self.optimizer_name == "adamw":
            optimizer = torch.optim.AdamW(
                model_parameters, lr=self.hparams.lr, weight_decay=0.001
            )
        elif self.optimizer_name == "adamax":
            optimizer = torch.optim.Adamax(
                model_parameters, lr=self.hparams.lr, weight_decay=0.001
            )
        else:
            optimizer = torch.optim.Adam(
                model_parameters, lr=self.hparams.lr, weight_decay=0.001
            )
        lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=0.1,
            patience=3,
            verbose=True,
            cooldown=3,
            min_lr=1e-8,
        )
        return {"optimizer": optimizer, "lr_scheduler": lr_scheduler, "monitor": "val_loss"}
