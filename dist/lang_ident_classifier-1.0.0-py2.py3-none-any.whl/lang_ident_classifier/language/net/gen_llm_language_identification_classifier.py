# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _7514a9971a4d, _7196ff7f918b
import copy
from _a1643785ef71 import _e0f48a2ac153
import _683fab15ebb5
import math
import os
from typing import _11327c5904db
import _f5cb434446a3 as _d7e1ceab09f4
import _7b69e3cda07b as _604b5332752e
import _810510729dc7
import _c8ee24895f91 as _0599f1234867
from _d0e8b41b8ace import _52cea70ca409, _b653c6da3144
from _d0e8b41b8ace._6e736d8b2f2a._298492958b29._09893fa46c9c import _9ea349d7289e
from _4f8118073c3b import _140de5620c6d, _6deb90536b06, _dfe993580770, _7268b05e8eea, _2e9f716b2d2f

from _6e4655fd6e5b._6347b370cd70._ce47da51d866._c659cc52c903 import _0650c9477c6b
from _6e4655fd6e5b._6347b370cd70._6ce753e45d51._620d3df68b88 import _913234b912f7
from _6e4655fd6e5b._6347b370cd70._6ce753e45d51._30ba54495c26 import _1c5a42d8afd7
from _6e4655fd6e5b._6347b370cd70._6ce753e45d51._dc2791172872 import _90dbc108a546
from _6e4655fd6e5b._6347b370cd70._eb98e9e3ba20._368d9b4db787 import _ef7d32e322bc
# expose only the classifier from the module
_d4bcefc54d93 = ["GenLLMLanguageIdentificationClassifier"]

_2de6a7719f05 = 'cuda' if _810510729dc7._6958a31f26b5._b643c947233a() else 'cpu'
_1d7ad2a8ec40 = _d2d1d82801e9  # global frozen embedding (kept for compatibility)


class _cd3f8cc84c0d(_52cea70ca409):
    def _792832f6cac9(self, _6cc4b98bc281, _75d0002635f2=_d2d1d82801e9, _6ddb741f1015=_d2d1d82801e9):
        self._7c4ac2e60ba4 = _ea33824555bd(_6cc4b98bc281)
        self._34a046d76298 = _75d0002635f2
        self._fe91a75afffb = _6ddb741f1015

    def _fa770cb423e8(self, _38f15cb91a9b, _74423ea260f1):
        _c55a27f40f23 = _810510729dc7._54e749ccb5f3(_74423ea260f1, _3a3dfa495bcf("-inf"))

        for _51de5c284468 in self._7c4ac2e60ba4:
            _c55a27f40f23[:, _51de5c284468] = 0.0

        if self._34a046d76298 is not _d2d1d82801e9:
            _c55a27f40f23[:, self._34a046d76298] = 0.0

        if self._fe91a75afffb is not _d2d1d82801e9:
            _c55a27f40f23[:, self._fe91a75afffb] = 0.0

        return _74423ea260f1 + _c55a27f40f23
    
class _0f0b568e04ef(_0599f1234867._14de6df9a8d0):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """
    _dacce44b1421 = {}

    class _af8ecaec4761(_810510729dc7._766e16553e7b._e847f111821b):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _792832f6cac9(self, _a32bfbf6fc08: _f9e0f962dc7b, _c4da9590fd45: _f9e0f962dc7b = 64):
            _cf1ae2e411b3()._69c964463752()
            self._f43086fd4bcf = _810510729dc7._766e16553e7b._72f60a24e80a(_a32bfbf6fc08, _c4da9590fd45, _a068fc53cb03=_eba335b1d5cd)
            self._1e2750d6f833 = _810510729dc7._766e16553e7b._3731990cc3d6(_b22622e07646=_cdc6b872c644)
            self._28a0b2d2113a = _810510729dc7._766e16553e7b._72f60a24e80a(_c4da9590fd45, _a32bfbf6fc08, _a068fc53cb03=_eba335b1d5cd)
            # start adapter near-zero so initial behavior is identity
            _810510729dc7._766e16553e7b._495a8af7752a._f0f6cde2be18(self._28a0b2d2113a._d2463c632100)
            _810510729dc7._766e16553e7b._495a8af7752a._c58165f6cd98(self._f43086fd4bcf._d2463c632100, _721ba7f63631=math._cd09fedd3894(5))

        def _7a71564db828(self, _39748a02495d: _810510729dc7._0c00e83b221f) -> _810510729dc7._0c00e83b221f:
            # supports x shape (B, L, D) or (B, D)
            if _39748a02495d._a32bfbf6fc08() == 2:
                _f6774db8cefe = self._28a0b2d2113a(self._1e2750d6f833(self._f43086fd4bcf(_39748a02495d)))
                return _39748a02495d + _f6774db8cefe
            _789f879352ce, _29b4a47efcf7, _b3432d2c9350 = _39748a02495d._457dc7fa890f
            _4986a5f51519 = _39748a02495d._fefef823d698(-1, _b3432d2c9350)                    # (B*L, D)
            _4986a5f51519 = self._28a0b2d2113a(self._1e2750d6f833(self._f43086fd4bcf(_4986a5f51519)))  # (B*L, D)
            _4986a5f51519 = _4986a5f51519._fefef823d698(_789f879352ce, _29b4a47efcf7, _b3432d2c9350)
            return _39748a02495d + _4986a5f51519


    class _8c8942f31095(_810510729dc7._766e16553e7b._e847f111821b):
        def _792832f6cac9(self, _a32bfbf6fc08: _f9e0f962dc7b, _f11a4ec2ac21: _810510729dc7._766e16553e7b._e847f111821b, _c4da9590fd45: _f9e0f962dc7b = 64):
            _cf1ae2e411b3()._69c964463752()
            self._f43086fd4bcf = _810510729dc7._766e16553e7b._72f60a24e80a(_a32bfbf6fc08, _c4da9590fd45, _a068fc53cb03=_eba335b1d5cd)
            self._1e2750d6f833 = _810510729dc7._766e16553e7b._3731990cc3d6(_b22622e07646=_cdc6b872c644)
            self._28a0b2d2113a = _810510729dc7._766e16553e7b._72f60a24e80a(_c4da9590fd45, _a32bfbf6fc08, _a068fc53cb03=_eba335b1d5cd)
            self._f11a4ec2ac21 = _f11a4ec2ac21

            _810510729dc7._766e16553e7b._495a8af7752a._f0f6cde2be18(self._28a0b2d2113a._d2463c632100)
            _810510729dc7._766e16553e7b._495a8af7752a._c58165f6cd98(self._f43086fd4bcf._d2463c632100, _721ba7f63631=math._cd09fedd3894(5))

        def _96358088be42(self, _768020c6015f):
            if _768020c6015f._a32bfbf6fc08() == 3:
                _789f879352ce, _29b4a47efcf7, _b3432d2c9350 = _768020c6015f._457dc7fa890f
                _4986a5f51519 = _768020c6015f._fefef823d698(-1, _b3432d2c9350)
                _4986a5f51519 = _4986a5f51519 + self._28a0b2d2113a(self._1e2750d6f833(self._f43086fd4bcf(_4986a5f51519)))
                return _4986a5f51519._fefef823d698(_789f879352ce, _29b4a47efcf7, _b3432d2c9350)
            return _768020c6015f + self._28a0b2d2113a(self._1e2750d6f833(self._f43086fd4bcf(_768020c6015f)))

        def _7a71564db828(self, _768020c6015f):
            _768020c6015f = self._bc9bd75df3de(_768020c6015f)
            return self._f11a4ec2ac21(_768020c6015f)

    class _84fa9a1a4f4c(_810510729dc7._766e16553e7b._e847f111821b):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _792832f6cac9(self, _edf360a0beab, _1e6e67f434d7=-5, _28563d4f7b67=5):
            _cf1ae2e411b3()._69c964463752()
            self._edf360a0beab = _edf360a0beab
            self._1e6e67f434d7 = _1e6e67f434d7
            self._28563d4f7b67 = _28563d4f7b67
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _7a71564db828(self, *_e57d46803dc7, **_c1797c9c9bdb):
            _e57d46803dc7 = _e7d3cf2a96cb(
                _07e2e2133628._8727f06591ca(_810510729dc7._307c952523d9)._3d75c9481759(-10, 10) if _4955fe52b6b2(_07e2e2133628, _810510729dc7._0c00e83b221f) and _07e2e2133628._cf75de35227b != _810510729dc7._307c952523d9 else _07e2e2133628
                for _07e2e2133628 in _e57d46803dc7
            )
            for _3f74c2e21537, _07e2e2133628 in _d31438f8397b(_e57d46803dc7):
                if _4955fe52b6b2(_07e2e2133628, _810510729dc7._0c00e83b221f) and not _810510729dc7._12acb6995ac0(_07e2e2133628)._ee7761cf7122():
                    _07e2e2133628 = _810510729dc7._6fc811fed75c(_07e2e2133628)
            _34db4e1421b0 = self._edf360a0beab(*_e57d46803dc7, **_c1797c9c9bdb)
            if _4955fe52b6b2(_34db4e1421b0, _810510729dc7._0c00e83b221f):
                _34db4e1421b0 = _34db4e1421b0._8727f06591ca(_810510729dc7._307c952523d9)
                if not _810510729dc7._12acb6995ac0(_34db4e1421b0)._ee7761cf7122():
                    _34db4e1421b0 = _810510729dc7._6fc811fed75c(_34db4e1421b0)
                _34db4e1421b0._7bf3e013eed7(self._1e6e67f434d7, self._28563d4f7b67)
            return _34db4e1421b0

    # --- original __init__ signature and body preserved ---
    def _792832f6cac9(
        self,
        _300c83422d8b,
        _3f1a0d12d9be,
        _a5abaf5c2f70,
        _ffa96398d5b4,
        _74c492a9ee99,
        _66e0539268ef,
        _fbb7baf6157a,
        _8661d25c30d1,
        _17040a0e57d5,
        _afb0d7b22d1c,
        _da344e9999f4,
        _1c309eb524af: _f9e0f962dc7b = 20,
        _310cd31bfc57 = _d2d1d82801e9,
        _dd89e135e16f=_d2d1d82801e9,
        _3367218bfd4e=0.9,
        _6a96cd1cc8bf:_4da47aecaf3f=_d2d1d82801e9,
    ):
        _cf1ae2e411b3(_db7ca19179f2, self)._69c964463752()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._ebf69b746362({
            "lr": _3a3dfa495bcf(_a5abaf5c2f70),
            "optimizer": _4da47aecaf3f(_ffa96398d5b4),
            "num_backbone_model_units_unfrozen": _f9e0f962dc7b(_fbb7baf6157a),
            "loss_type": _4da47aecaf3f(_8661d25c30d1),
            "is_train": _73fb58b05a86(_17040a0e57d5),
            "random_seed": _f9e0f962dc7b(_1c309eb524af),
        })
        self._1c309eb524af = _1c309eb524af
        _0599f1234867._8ee205fc19f9(_1c309eb524af, _3ed44114c4a8=_cdc6b872c644)
        _810510729dc7._2df65476cc07(_1c309eb524af)
        if _810510729dc7._6958a31f26b5._b643c947233a():
            _810510729dc7._6958a31f26b5._f6775e82532b(_1c309eb524af)
        _d7e1ceab09f4.random._3483fbc6de82(_1c309eb524af)
        self._9b86c66b3d5e = 0.2
        self._dd89e135e16f = _f9e0f962dc7b(_dd89e135e16f) if _dd89e135e16f is not _d2d1d82801e9 else _d2d1d82801e9
        _afb0d7b22d1c._96b1e44d3623 = "left"
        self._afb0d7b22d1c = _afb0d7b22d1c
        self._6a96cd1cc8bf = _6a96cd1cc8bf
        self._f43386a2da5a = 0.2 # for preventing model shift dominance
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
        #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
        #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
        #     print(f"Added padding token  <PAD> with (id: {tid})")
        if not self._afb0d7b22d1c._cc43173d9090:
            self._afb0d7b22d1c._e20be991b06a(["_P"], _b8635bec2915=_eba335b1d5cd)
            _51de5c284468 = self._afb0d7b22d1c._096837dfbcd5("_P")
            self._afb0d7b22d1c._cc43173d9090 = _51de5c284468
            _43887641ae66(f"Added padding token  _P with (id: {_51de5c284468})")
        
        # self.tokenizer_separator_token = tokenizer.encode(" ", add_special_tokens=False)[0]
        self._430eab910420 = _afb0d7b22d1c._8fd0ecd2787d("||", _748d9b784e25=_eba335b1d5cd)[0]
        self._b753732b8644 = (
            _810510729dc7._c59b9fb2a946("cuda:{}"._5d31c88f05a8(_66e0539268ef["gpu_local_rank"]))
            if _66e0539268ef["gpu_local_rank"] != -1
            else "cpu"
        )
        self._310cd31bfc57 = _310cd31bfc57
        self._3367218bfd4e = _3367218bfd4e
        self._3f1a0d12d9be =  ["unk"] + _3f1a0d12d9be if self._3367218bfd4e > 0 else _3f1a0d12d9be
        self._c6fc1c0c5a13 = _78d8252c7db0(self._3f1a0d12d9be)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._c1c7aae01ece = {}
        # FOR NEW TOKEN COMMENT THIS
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        
        # FOR NEW TOKEN UNCOMMENT THIS
        # Add only if class name splits into >1 token
        # for cname in self.class_names:
        #     if len(self.tokenizer.encode(cname, add_special_tokens=False)) > 1:
        #         token = f"{cname}"
        #         if token not in self.tokenizer.get_vocab():
        #             self.tokenizer.add_tokens([token], special_tokens=False)
        #             tid = self.tokenizer.convert_tokens_to_ids(token)
        #             print(f"Added class '{cname}' Token: {token} (id: {tid})")

        # Map every class to single token ID
        for _822ef9d506c3 in self._3f1a0d12d9be:
            if _822ef9d506c3 not in _db7ca19179f2._dacce44b1421:
                _c9fd0d2b592b = _afb0d7b22d1c._8fd0ecd2787d(_822ef9d506c3, _748d9b784e25=_eba335b1d5cd)
                if _78d8252c7db0(_c9fd0d2b592b) > 1:
                    _db7ca19179f2._dacce44b1421[_822ef9d506c3] = f"{_78d8252c7db0(_db7ca19179f2._dacce44b1421)}"
                else:
                    _db7ca19179f2._dacce44b1421[_822ef9d506c3] = _822ef9d506c3
        
        self._c1c7aae01ece = {
            _8b597246f51e: [self._afb0d7b22d1c._096837dfbcd5(_db7ca19179f2._dacce44b1421._03294381a598(_822ef9d506c3))]
            for _8b597246f51e, _822ef9d506c3 in _d31438f8397b(self._3f1a0d12d9be)
        }

        self._e05534f9d609 = _b653c6da3144([
            _630c5a9e29d7(
                _6cc4b98bc281=[
                    _51de5c284468
                    for _b2b629f1ee10 in self._c1c7aae01ece._343738e95723()
                    for _51de5c284468 in _b2b629f1ee10
                ],
                _75d0002635f2=self._430eab910420,
                _6ddb741f1015=self._afb0d7b22d1c._6ddb741f1015
            )
        ])
        # self.class2seq = {
        #     idx: [self.tokenizer.convert_tokens_to_ids(f"{cname}")]
        #     for idx, cname in enumerate(self.class_names)
        # }

        self._4002611d1d70 = {_e7d3cf2a96cb(_b2b629f1ee10): _549e173a8d70 for _549e173a8d70, _b2b629f1ee10 in self._c1c7aae01ece._69b5704cbec0()}
        self._cf23eed5a5ec = _7196ff7f918b(_1fc29e6309f3)
        for _4f4966a4cb9f, _b2b629f1ee10 in self._c1c7aae01ece._69b5704cbec0():
            self._cf23eed5a5ec[_78d8252c7db0(_b2b629f1ee10)]._115de3784ad2((_4f4966a4cb9f, _b2b629f1ee10))
        self._89e62616d0d9 = 0
        _43887641ae66(f"SEQ {self._c1c7aae01ece} and {self._4002611d1d70}")
        self._187ca5e64953 = _afb0d7b22d1c._cc43173d9090 or _afb0d7b22d1c._6ddb741f1015
        self._74c492a9ee99 = _74c492a9ee99
        self._865de147aa7e = "multiclass"
        self._93dfc006bc6f = -100
        self._09acf986c05e = _afb0d7b22d1c._8fd0ecd2787d("assistant<|end_header_id|>\n\n", _748d9b784e25=_eba335b1d5cd)
        self._0cc18602a30e = self._a40783c488b2()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._28eca43959eb = _300c83422d8b
        # Resize vocab based token embeddings
        self._28eca43959eb._4b1e68a24f36(_78d8252c7db0(self._afb0d7b22d1c))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._28eca43959eb._c9a6f3922d36(_eba335b1d5cd)
        _60cf6686ef1c = _ef7d32e322bc()  # bfloat16 or float16

        for _dcf96c6967b9, _edf360a0beab in self._ab7cda74766c():
            if not _8149f3e8e616(_5d4bc2e289fb._9fb81e49d86d for _5d4bc2e289fb in _edf360a0beab._e2a4bdb3bd86(_89a68cf19c0d=_eba335b1d5cd)):
                # FROZEN → BF16 (save memory)
                _edf360a0beab._8727f06591ca(_cf75de35227b=_60cf6686ef1c)
            else:
                # TRAINABLE → FP32 (stable grads)
                _edf360a0beab._8727f06591ca(_cf75de35227b=_810510729dc7._307c952523d9)
        self._28eca43959eb._8727f06591ca(self._b753732b8644)
        if _2566bdb718db(self._28eca43959eb, "gradient_checkpointing_enable"):
            self._28eca43959eb._72432ce4a6a5()
        # determine embedding dim robustly from model config if available
        _3d4556d1fd3b = _f5597c2b351b(_f5597c2b351b(self._28eca43959eb, "config", _d2d1d82801e9), "hidden_size", _d2d1d82801e9)
        if _3d4556d1fd3b is _d2d1d82801e9:
            # fallback to common default — change if your model uses a different hidden size
            _3d4556d1fd3b = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        # if hasattr(self.embedding, "lm_head") and getattr(self.embedding, "lm_head") is not None:
        #     self._lm_head = self.embedding.lm_head
        # else:
        #     get_out = getattr(self.embedding, "get_output_embeddings", None)
        #     self._lm_head = get_out() if callable(get_out) else None

        # # mark presence and ensure module (if any) is on the same device
        # self._has_lm_head = self._lm_head is not None
        # if self._has_lm_head:
        #     # move lm_head params/buffers to the model device (safe no-op if already there)
        #     self._lm_head.to(self.curr_device)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        # self.adapter = self._Adapter(dim=embedding_dim, bottleneck=64)
        # self.adapter.to(self.curr_device)
        # for p in self.adapter.parameters():
        #     p.requires_grad = True
        _f11a4ec2ac21 = (
            self._28eca43959eb._f11a4ec2ac21
            if _2566bdb718db(self._28eca43959eb, "lm_head")
            else self._28eca43959eb._c46117abfdf6()
        )

        self._28eca43959eb._f11a4ec2ac21 = self._b873dd7435b3(
            _a32bfbf6fc08=_3d4556d1fd3b,
            _f11a4ec2ac21=_f11a4ec2ac21,
            _c4da9590fd45=64,
        )._8727f06591ca(self._b753732b8644)

        # self.adapter = self.embedding.lm_head

        if _fbb7baf6157a > 0:
            # if "llama" in self.pretrained_model_embedding_name:
            if self._310cd31bfc57:
                for _1c17061ced9f in self._28eca43959eb._e2a4bdb3bd86():
                    if not _1c17061ced9f._1fc70e190075:
                        _1c17061ced9f = _1c17061ced9f._46eb1dcccfd6()
                    _1c17061ced9f._9fb81e49d86d = _eba335b1d5cd  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _69f8437fab6d = self._28eca43959eb._32ac706e6f03._16fb19e7f600  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _e85115ffb35d in _69f8437fab6d[-_fbb7baf6157a:]:
                    for _1c17061ced9f in _e85115ffb35d._e2a4bdb3bd86():
                        if _4955fe52b6b2(_1c17061ced9f, _810510729dc7._0c00e83b221f) and (_1c17061ced9f._c03e08fa1874() or _810510729dc7._88a3a4480ab2(_1c17061ced9f)):
                            _1c17061ced9f._9fb81e49d86d = _cdc6b872c644
                for _1c17061ced9f in self._28eca43959eb._f11a4ec2ac21._e2a4bdb3bd86():
                    _1c17061ced9f._9fb81e49d86d = _cdc6b872c644

        self._daf5a6f8033a = 1
        _43887641ae66(f"DEBUG xth_batch init {self._daf5a6f8033a}")
        global _1d7ad2a8ec40
        _1d7ad2a8ec40 = copy._20e362583f93(self._28eca43959eb)._9f44873d778d()
        self._a5abaf5c2f70 = _a5abaf5c2f70

        self._1ed1a645da62 = {}
        self._52ec756e7e90 = {}

        # Loss function initialization
        if _8661d25c30d1._247a3d315ecf() == "class_weighted_cross_entropy_loss":
            self._52ec756e7e90['criterion'] = _1c5a42d8afd7(_74c492a9ee99=self._74c492a9ee99,
                                                            _c59b9fb2a946=self._b753732b8644,
                                                            _79f22ef75301=self._93dfc006bc6f,
                                                            _caa4a506c17e=self._430eab910420)
        elif _8661d25c30d1._247a3d315ecf() == "focal_loss":
            self._52ec756e7e90['criterion'] = _90dbc108a546(_67ff67482fff=0.25,
                                                     _c59b9fb2a946=self._b753732b8644,
                                                     _79f22ef75301=self._93dfc006bc6f,
                                                     _caa4a506c17e=self._430eab910420)
        elif _8661d25c30d1._247a3d315ecf() == "class_weighted_focal_loss":
            self._52ec756e7e90['criterion'] = _90dbc108a546(_67ff67482fff=self._74c492a9ee99,
                                                     _c59b9fb2a946=self._b753732b8644,
                                                     _79f22ef75301=self._93dfc006bc6f,
                                                     _caa4a506c17e=self._430eab910420)
        elif _8661d25c30d1._247a3d315ecf() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._52ec756e7e90['criterion'] = _913234b912f7(_67ff67482fff=self._74c492a9ee99,
                                                                      _12a81cba41de='type1',
                                                                      _c59b9fb2a946=self._b753732b8644,
                                                                      _79f22ef75301=self._93dfc006bc6f,
                                                                      _caa4a506c17e=self._430eab910420)
        elif _8661d25c30d1._247a3d315ecf() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._52ec756e7e90['criterion'] = _913234b912f7(_67ff67482fff=self._74c492a9ee99,
                                                                      _12a81cba41de='type2',
                                                                      _c59b9fb2a946=self._b753732b8644,
                                                                      _79f22ef75301=self._93dfc006bc6f,
                                                                      _caa4a506c17e=self._430eab910420)
        elif _8661d25c30d1._247a3d315ecf() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._52ec756e7e90['criterion'] = _913234b912f7(_67ff67482fff=self._74c492a9ee99,
                                                                      _12a81cba41de='type3',
                                                                      _c59b9fb2a946=self._b753732b8644,
                                                                      _79f22ef75301=self._93dfc006bc6f,
                                                                      _caa4a506c17e=self._430eab910420)
        else:
            self._52ec756e7e90['criterion'] = _1c5a42d8afd7(_c59b9fb2a946=self._b753732b8644,
                                                            _79f22ef75301=self._93dfc006bc6f,)
        
        self._e2be2f1a15bf = 0.99
        self._d6b0bd88c174 = 0.3
        self._fa9183b5440d = 0.30
        self._1a7469232524 = 0.25
        self._6cc2fc263d99 = 0.6
        self._3b21eb77f36d = 0.995
        self._0325dce44609 = 0.60
        self._b4c49dfa6858 = 0.20
        self._d5b6b2633dd9 = _f5597c2b351b(self, "batch_counter", 0)


        self._b410091ad04f = []
        self._f5ef19aca27b = []

        self._3ef1f5731fc5 = _ffa96398d5b4._247a3d315ecf()
        self._90c094de0e33()

        self._5616f3d04266(self._28eca43959eb)
    
    def _faac95fe45e5(self):
        # rebuild all metrics on the correct device
        self._1ed1a645da62['micro_accuracy'] = _140de5620c6d(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4="micro",
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['macro_accuracy'] = _140de5620c6d(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4="macro",
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['macro_precision'] = _dfe993580770(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4="macro",
            _51f95191e99e=self. _865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['macro_recall'] = _7268b05e8eea(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4="macro",
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['macro_f1'] = _2e9f716b2d2f(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4="macro",
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['classwise_accuracy'] = _140de5620c6d(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4=_d2d1d82801e9,
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['classwise_precision'] = _dfe993580770(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4=_d2d1d82801e9,
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['classwise_recall'] = _7268b05e8eea(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4=_d2d1d82801e9,
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['classwise_f1'] = _2e9f716b2d2f(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _36f6e9e5b5f4=_d2d1d82801e9,
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)

        self._1ed1a645da62['confmat'] = _6deb90536b06(
            _c6fc1c0c5a13=_78d8252c7db0(self._3f1a0d12d9be),
            _51f95191e99e=self._865de147aa7e,
            _79f22ef75301=self._93dfc006bc6f,
        )._8727f06591ca(self._b753732b8644)


    def _9453aed78427(self, _62486b694d54=_d2d1d82801e9):
        """Calculate batch counts and set xth_batch_to_consider."""
        _7cf344152e74 = 0
        _2b81351da492 = 0
        if self._2a1c30a06ca5._d77945d600fb is not _d2d1d82801e9:
            if _2566bdb718db(self._2a1c30a06ca5._d77945d600fb, 'train_dataset') and self._2a1c30a06ca5._d77945d600fb._7ec24e6bcf65 is not _d2d1d82801e9:
                _7cf344152e74 = _78d8252c7db0(self._2a1c30a06ca5._d77945d600fb._7ec24e6bcf65)
            if _2566bdb718db(self._2a1c30a06ca5._d77945d600fb, 'val_dataset') and self._2a1c30a06ca5._d77945d600fb._ce4a5f2cf0e5 is not _d2d1d82801e9:
                _2b81351da492 = _78d8252c7db0(self._2a1c30a06ca5._d77945d600fb._ce4a5f2cf0e5)
            _faf9985e169d = self._2a1c30a06ca5._d77945d600fb._faf9985e169d
            _9cdd8fc6661b = (_7cf344152e74 + _faf9985e169d - 1) // _faf9985e169d if _7cf344152e74 > 0 else 1
            _a0b0d04a2418 = (_2b81351da492 + _faf9985e169d - 1) // _faf9985e169d if _2b81351da492 > 0 else 1
            _accb1d5a761b = _6a4624efa0c2(_9cdd8fc6661b, _a0b0d04a2418) if _2b81351da492 > 0 else _9cdd8fc6661b
            _4829760bea75 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._daf5a6f8033a = 1
            _43887641ae66(f"DEBUG Batch Info: num_train_batches={_9cdd8fc6661b}, num_val_batches={_a0b0d04a2418}, xth_batch_to_consider={self._daf5a6f8033a}")

    def _56981b4dd361(self, _e3bb9294038f, _8253c2503f3e):
        if _e3bb9294038f._247a3d315ecf() == "parametric_relu":
            return _810510729dc7._766e16553e7b._f94e16cf5967(_8253c2503f3e=1)
        elif _e3bb9294038f._247a3d315ecf() == "leaky_relu":
            return _810510729dc7._766e16553e7b._262bad3a5907(_b22622e07646=_eba335b1d5cd)
        else:
            return _810510729dc7._766e16553e7b._3731990cc3d6(_b22622e07646=_eba335b1d5cd)
    
    def _bb33f28633a6(self, _edf360a0beab, _d503829207f0=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _dcf96c6967b9, _9e5c31ddf559 in _edf360a0beab._7d97dd45a073():
            _f123d7449a0a = f"{_d503829207f0}.{_dcf96c6967b9}" if _d503829207f0 else _dcf96c6967b9

            def _8b065083a77e(_43c33e1bb1d9, _07e2e2133628, _f6774db8cefe):
                if _4955fe52b6b2(_f6774db8cefe, _810510729dc7._0c00e83b221f) and _f6774db8cefe._9905ba7ac075()._8149f3e8e616():
                    _43887641ae66(f"NaN detected in {_f123d7449a0a} ({_43c33e1bb1d9._f89fec1cd9dc.__name__}) ({_f6774db8cefe._cf75de35227b})")

            _9e5c31ddf559._f9143baefe38(_c45b63dfe4e5)

            self._5616f3d04266(_9e5c31ddf559, _f123d7449a0a)

    def _1a850a0b97cd(self, _edf360a0beab):
        return _8149f3e8e616(_5d4bc2e289fb._9fb81e49d86d for _5d4bc2e289fb in _edf360a0beab._e2a4bdb3bd86())

    def _bc05c8132cc4(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _c53dafbfd8e8 = []
        for _dcf96c6967b9, _edf360a0beab in self._ab7cda74766c():
            if not self._305a27336a63(_edf360a0beab):
                continue
            _c5137a1abca5 = (
                "norm" in _dcf96c6967b9._3277753cb1b1() or 
                "linear4bit" in _dcf96c6967b9._3277753cb1b1() or 
                _8149f3e8e616(_1e2750d6f833 in _dcf96c6967b9._3277753cb1b1() for _1e2750d6f833 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _dcf96c6967b9._3277753cb1b1() or 
                "dropout" in _dcf96c6967b9._3277753cb1b1() or 
                _4955fe52b6b2(_edf360a0beab, (_9ea349d7289e, _810510729dc7._766e16553e7b._72f60a24e80a, _810510729dc7._766e16553e7b._1bc11901d746))
            )
            if _c5137a1abca5:
                if _2566bdb718db(_edf360a0beab, "eps"):
                    _edf360a0beab._d7bcb967d2ce = 1e-3
                _edf360a0beab = _edf360a0beab._8727f06591ca(_810510729dc7._307c952523d9)
                if not _4955fe52b6b2(_edf360a0beab, _db7ca19179f2._802229f76e14):
                    _c53dafbfd8e8._115de3784ad2((_dcf96c6967b9, _db7ca19179f2._802229f76e14(_edf360a0beab, _1e6e67f434d7=-10, _28563d4f7b67=10)))
        for _dcf96c6967b9, _4acf756c056c in _c53dafbfd8e8:
            _00958a043f86, _067e50a4f447 = self._b5ed4f1ce188(_dcf96c6967b9)
            if _00958a043f86 is not _d2d1d82801e9:
                _f811fd8ba88b(_00958a043f86, _067e50a4f447, _4acf756c056c)

    def _681da4299af8(self, _aecb0521a5f3):
        """Finds the parent module and attribute name given the full module path."""
        _0e8dbb0408f8 = _aecb0521a5f3._000f9a65e783('.')
        _5087be7be6c8 = self
        for _c0b47aae2874 in _0e8dbb0408f8[:-1]:
            _5087be7be6c8 = _f5597c2b351b(_5087be7be6c8, _c0b47aae2874, _d2d1d82801e9)
            if _5087be7be6c8 is _d2d1d82801e9:
                return _d2d1d82801e9, _d2d1d82801e9
        return _5087be7be6c8, _0e8dbb0408f8[-1]

    def _4e5d1ac340a8(self, _dc6767182e8b: _810510729dc7._0c00e83b221f, _cfffcba5d51d: _810510729dc7._0c00e83b221f, _afcb5f24a400: _810510729dc7._0c00e83b221f) -> _2b8bce6331b6:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _c59b9fb2a946 = _dc6767182e8b._c59b9fb2a946

        # 1) gating w (use cached per-example teacher_conf if available)
        _e3c91338fbb7 = _f5597c2b351b(self, "_last_teacher_conf", _d2d1d82801e9)
        if _e3c91338fbb7 is _d2d1d82801e9:
            # no teacher info => w = 0 (no distillation)
            _277ea80fcd97 = 0.0
        else:
            _3207c9a5f603 = (_e3c91338fbb7 >= _3a3dfa495bcf(_f5597c2b351b(self, "teacher_conf_tau", 0.6)))._3a3dfa495bcf()
            _277ea80fcd97 = _3a3dfa495bcf(_3207c9a5f603._5ef8fd0784dc()._8b7b4c762d6c()._647e261773cf()) if _3207c9a5f603._92c2a00bc9ec() > 0 else 0.0

        # apply gating to the batch scalars
        _f555642589c1 = _cfffcba5d51d * _3a3dfa495bcf(_277ea80fcd97)
        _bde2bd767d1a = _afcb5f24a400 * _3a3dfa495bcf(_277ea80fcd97)

        # 2) EMAs for autoscaling
        _192d81b317d9 = _3a3dfa495bcf((_f555642589c1 + _bde2bd767d1a)._46eb1dcccfd6()._8b7b4c762d6c()._647e261773cf())
        _ca2dd7a9298a = _3a3dfa495bcf(_dc6767182e8b._46eb1dcccfd6()._8b7b4c762d6c()._647e261773cf())
        if _f5597c2b351b(self, "ema_task", _d2d1d82801e9) is _d2d1d82801e9:
            self._96e27ebf2710 = _ca2dd7a9298a
            self._926e60729d47 = _192d81b317d9 + 1e-12
        else:
            _67ff67482fff = _3a3dfa495bcf(_f5597c2b351b(self, "ema_alpha", 0.99))
            self._96e27ebf2710 = _67ff67482fff * _3a3dfa495bcf(self._96e27ebf2710) + (1.0 - _67ff67482fff) * _ca2dd7a9298a
            self._926e60729d47  = _67ff67482fff * _3a3dfa495bcf(self._926e60729d47)  + (1.0 - _67ff67482fff) * _192d81b317d9

        _03ea6665c76e = _3a3dfa495bcf(_f5597c2b351b(self, "distill_target_ratio", 0.3))
        _107bb92e453f = (_3a3dfa495bcf(self._96e27ebf2710) / (_3a3dfa495bcf(self._926e60729d47) + 1e-12)) * _03ea6665c76e
        _0a6c96a26262 = _3a3dfa495bcf(_107bb92e453f)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _4f0acfe7538a = _3a3dfa495bcf(_f5597c2b351b(self._2a1c30a06ca5, "current_epoch", _f5597c2b351b(self._2a1c30a06ca5, "global_step", 0.0)))
        _aed9fa56376e = _3a3dfa495bcf(_87b3f1d1c16d(1, _f5597c2b351b(self._2a1c30a06ca5, "max_epochs", 1)))
        _c051637fafe9 = _6a4624efa0c2(_87b3f1d1c16d(_4f0acfe7538a / _aed9fa56376e, 0.0), 1.0)
        _a6290642835d = 0.30
        _c4ac45bf8bec = _3a3dfa495bcf(_f5597c2b351b(self, "kl_base", 0.30)) * _6a4624efa0c2(_c051637fafe9 / _a6290642835d, 1.0)
        _1a7469232524 = _3a3dfa495bcf(_f5597c2b351b(self, "cos_base", 0.25))
        _9986273b28d4 = _1a7469232524 + (0.10 - _1a7469232524) * _c051637fafe9

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _7a4285ad388a = _3a3dfa495bcf(self._a650ac01954b._5ef8fd0784dc()._8b7b4c762d6c()._647e261773cf()) if _f5597c2b351b(self, "_last_teacher_conf", _d2d1d82801e9) is not _d2d1d82801e9 else 0.0
        if _f5597c2b351b(self, "ema_teacher_conf", _d2d1d82801e9) is _d2d1d82801e9:
            self._41ee9385417f = _7a4285ad388a
        else:
            _789f879352ce = _3a3dfa495bcf(_f5597c2b351b(self, "teacher_conf_beta", 0.995))
            self._41ee9385417f = _789f879352ce * _3a3dfa495bcf(self._41ee9385417f) + (1.0 - _789f879352ce) * _7a4285ad388a

        _0325dce44609 = _3a3dfa495bcf(_f5597c2b351b(self, "tau_warn", 0.60))
        _b4c49dfa6858 = _3a3dfa495bcf(_f5597c2b351b(self, "tau_detect", 0.20))
        _a44cde48b617 = _87b3f1d1c16d(1e-12, (_0325dce44609 - _b4c49dfa6858))
        _025c7824c71d = (_3a3dfa495bcf(self._41ee9385417f) - _b4c49dfa6858) / _a44cde48b617
        _025c7824c71d = _87b3f1d1c16d(0.0, _6a4624efa0c2(1.0, _025c7824c71d))

        _6d430019a531 = _c4ac45bf8bec * _025c7824c71d
        _ef5b59db9df0 = _9986273b28d4 * _025c7824c71d

        # 5) final aux term
        _d851a165620d = _810510729dc7._bc4e457e4d34(0.0, _c59b9fb2a946=_c59b9fb2a946)
        _d851a165620d = _d851a165620d + (_6d430019a531 * _f555642589c1 + _ef5b59db9df0 * _bde2bd767d1a) * _3a3dfa495bcf(_0a6c96a26262)

        # diagnostics
        _f6774db8cefe = {
            "aux_term": _d851a165620d,
            "kl_batch": _cfffcba5d51d,
            "contrast_batch": _afcb5f24a400,
            "kl_loss": _f555642589c1,
            "contrastive_loss": _bde2bd767d1a,
            "w_mean": _277ea80fcd97,
            "aux_scale": _3a3dfa495bcf(_0a6c96a26262),
            "lambda_kl_eff": _3a3dfa495bcf(_6d430019a531),
            "lambda_cos_eff": _3a3dfa495bcf(_ef5b59db9df0),
            "teacher_conf_mean": _3a3dfa495bcf(self._41ee9385417f),
            "shift_r": _3a3dfa495bcf(_025c7824c71d)
        }
        return _f6774db8cefe

    def _7a71564db828(self, _38f15cb91a9b):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _38f15cb91a9b = _38f15cb91a9b._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)
        _d0804e6969bf = (_38f15cb91a9b != self._afb0d7b22d1c._cc43173d9090)._8727f06591ca(_cf75de35227b=_810510729dc7._73fb58b05a86, _c59b9fb2a946=self._b753732b8644, _58feefeef430=_cdc6b872c644)

        # model forward (request hidden states)
        _75ff7a944996 = self._28eca43959eb(
            _38f15cb91a9b=_38f15cb91a9b,
            _d0804e6969bf=_d0804e6969bf,
            _c87526d4886a=_cdc6b872c644,
            _79fd030084da=_cdc6b872c644,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _768020c6015f = _f5597c2b351b(_75ff7a944996, "last_hidden_state", _d2d1d82801e9)
        if _768020c6015f is _d2d1d82801e9:
            _768020c6015f = _75ff7a944996._b298d333ee67[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _768020c6015f._cf75de35227b != _810510729dc7._307c952523d9:
            _768020c6015f = _768020c6015f._8727f06591ca(_810510729dc7._307c952523d9)
        # student_hidden = self.adapter(hidden)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        # if self._has_lm_head:
        #     logits = self._lm_head(student_hidden)
        # else:
        #     logits = outs.logits

        _46827310d81a = self._28eca43959eb._f11a4ec2ac21  # _LMHeadAdapter

        _bfa7d0216325 = _46827310d81a._bc9bd75df3de(_768020c6015f)      # (B, L, 2048)
        # logits = adapter.lm_head(student_hidden)    # (B, L, 128256)
        _c64a7a08630a = _46827310d81a(_768020c6015f)


        _c64a7a08630a = _c64a7a08630a._8727f06591ca(_810510729dc7._307c952523d9)._3d75c9481759(-20, 20)

        # default zero scalars
        _f555642589c1 = _810510729dc7._bc4e457e4d34(0.0, _c59b9fb2a946=self._b753732b8644)
        _bde2bd767d1a = _810510729dc7._bc4e457e4d34(0.0, _c59b9fb2a946=self._b753732b8644)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _365cf6d1f08c = _f5597c2b351b(self, "trainer", _d2d1d82801e9)
        _d80799f3cf79 = _eba335b1d5cd
        if _365cf6d1f08c is not _d2d1d82801e9:
            _d80799f3cf79 = _73fb58b05a86(_f5597c2b351b(self._2a1c30a06ca5, "training", _eba335b1d5cd) or _f5597c2b351b(self._2a1c30a06ca5, "validating", _eba335b1d5cd))

        if _d80799f3cf79 and (_f5597c2b351b(self, "batch_counter", 0) % _f5597c2b351b(self, "xth_batch_to_consider", 1) == 0):
            with _810510729dc7._e71d6b3adcce():
                _a5f210fd6816 = _1d7ad2a8ec40(
                    _38f15cb91a9b=_38f15cb91a9b,
                    _d0804e6969bf=_d0804e6969bf,
                    _c87526d4886a=_cdc6b872c644,
                    _79fd030084da=_cdc6b872c644,
                )
                _a825676d8ed3 = _f5597c2b351b(_a5f210fd6816, "last_hidden_state", _d2d1d82801e9)
                if _a825676d8ed3 is _d2d1d82801e9:
                    _a825676d8ed3 = _a5f210fd6816._b298d333ee67[-1]

            # compute embedding-level KL + contrastive (scalar)
            _f555642589c1, _bde2bd767d1a = self._4af3bd7b764f(_bfa7d0216325, _a825676d8ed3, _c59b9fb2a946=self._b753732b8644)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _e38ada1708c1(_39748a02495d): return _39748a02495d._5ef8fd0784dc(_a32bfbf6fc08=1) if _39748a02495d._a32bfbf6fc08() == 3 else _39748a02495d
            _649f76df201e = _810510729dc7._766e16553e7b._b45f3b6f86ea._18b0faec01aa(_c511a1bd8219(_bfa7d0216325), _5d4bc2e289fb=2, _a32bfbf6fc08=-1, _d7bcb967d2ce=1e-6)
            _cf7637a212d8 = _810510729dc7._766e16553e7b._b45f3b6f86ea._18b0faec01aa(_c511a1bd8219(_a825676d8ed3), _5d4bc2e289fb=2, _a32bfbf6fc08=-1, _d7bcb967d2ce=1e-6)
            _036eab2fcd1a = _810510729dc7._766e16553e7b._b45f3b6f86ea._417d18ae63a5(_649f76df201e, _cf7637a212d8, _a32bfbf6fc08=-1)  # [-1,1]
            _e3c91338fbb7 = _036eab2fcd1a._3d75c9481759(_6a4624efa0c2=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._7425ea7cde42 = _bfa7d0216325._46eb1dcccfd6()
            self._a6a60575756e = _a825676d8ed3._46eb1dcccfd6()
            self._a650ac01954b = _e3c91338fbb7._46eb1dcccfd6()  # shape (B,)

        # increment counter
        self._d5b6b2633dd9 = _f5597c2b351b(self, "batch_counter", 0) + 1

        return _c64a7a08630a, _f555642589c1, _bde2bd767d1a


    def _c25edaa7cf87(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _3c9511ee664a(_edf360a0beab, _e57d46803dc7, _c33165cec31a):
            if _8149f3e8e616(_07e2e2133628._cf75de35227b == _810510729dc7._c0dc0c70fa09 for _07e2e2133628 in _e57d46803dc7 if _4955fe52b6b2(_07e2e2133628, _810510729dc7._0c00e83b221f)):
                _43887641ae66(f"Layer {_edf360a0beab._f89fec1cd9dc.__name__} is using float16!")

        for _bed26574ac83 in self._b219f5261bc6():
            _750062d81aa5 = _bed26574ac83._f9143baefe38(_21e832c4b305)
            self._ac80ba491ab9._115de3784ad2(_750062d81aa5)

    def _bc4cc432a750(self):
        """Remove all registered forward hooks."""
        for _750062d81aa5 in _f5597c2b351b(self, "amp_hooks", []):
            _750062d81aa5._4cd9c1f71dc8()
        self._ac80ba491ab9 = []

    def _9ff6f97436e6(self, _38f15cb91a9b, _a9cc33e04e92, _226bab016a10):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _c16ae25130fa = [self._afb0d7b22d1c._feba5ff5a488(_b1517f9d00e4) for _b1517f9d00e4 in _38f15cb91a9b]
        _8e396cb764fb, _1566e52fea7d = [], []

        for _744788da3f64, _0e916b2e8a8c, _efd98dad202a in _a4862bfbff1e(_c16ae25130fa, _a9cc33e04e92, _226bab016a10):
            for token, _58859ec04292, _6177a03a93dc in _a4862bfbff1e(_744788da3f64, _0e916b2e8a8c, _efd98dad202a):
                if token == self._afb0d7b22d1c._b5a37e57f388 or _6177a03a93dc == self._93dfc006bc6f:
                    continue

                _4561f9a1f88a = (
                    token._d8799a8c3508("##") or
                    token._d8799a8c3508("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _4561f9a1f88a:
                    continue

                _8e396cb764fb._115de3784ad2(_58859ec04292._647e261773cf())
                _1566e52fea7d._115de3784ad2(_6177a03a93dc._647e261773cf())

        return _810510729dc7._bc4e457e4d34(_8e396cb764fb), _810510729dc7._bc4e457e4d34(_1566e52fea7d)

    def _960c5ac8b013(self):
        _8e417d787571 = _810510729dc7._307c952523d9
        if _810510729dc7._6958a31f26b5._b643c947233a():
            _0846818eeba8, _3d81699a7899 = _810510729dc7._6958a31f26b5._7aabb906d3bf()
            if _0846818eeba8 >= 8:
                _8e417d787571 = _810510729dc7._371d69d1e3e1
            else:
                _8e417d787571 = _810510729dc7._c0dc0c70fa09
        return _8e417d787571

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _15b6e987ef51(
        self,
        _755af5a1d925: _810510729dc7._0c00e83b221f,
        _703344bfbe57: _810510729dc7._0c00e83b221f,
        _c59b9fb2a946: _4da47aecaf3f = "cpu",
    ) -> _11327c5904db[_810510729dc7._0c00e83b221f, _810510729dc7._0c00e83b221f]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _14b7a7cdd441 = 2.0
            # NaN/Inf guard
            _755af5a1d925 = _755af5a1d925._3d75c9481759(_6a4624efa0c2=-30, _87b3f1d1c16d=30)
            _703344bfbe57 = _703344bfbe57._3d75c9481759(_6a4624efa0c2=-30, _87b3f1d1c16d=30)

            # Move once if needed
            _cbcfe092824b = _810510729dc7._c59b9fb2a946(_c59b9fb2a946)
            if _755af5a1d925._c59b9fb2a946 != _cbcfe092824b:
                _755af5a1d925 = _755af5a1d925._8727f06591ca(_c59b9fb2a946=_cbcfe092824b, _58feefeef430=_cdc6b872c644, _cf75de35227b=self._0cc18602a30e)
                _703344bfbe57 = _703344bfbe57._8727f06591ca(_c59b9fb2a946=_cbcfe092824b, _58feefeef430=_cdc6b872c644, _cf75de35227b=self._0cc18602a30e)

            _faf9985e169d = _755af5a1d925._d0a907f2a6ce(0)
            _3d4556d1fd3b = _755af5a1d925._d0a907f2a6ce(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _6ad464c51fa5 = (_faf9985e169d * _3d4556d1fd3b) > 32_000_000

            if not _6ad464c51fa5 or _faf9985e169d <= 8:
                # Direct computation
                _c372bf276ebd = _810510729dc7._766e16553e7b._b45f3b6f86ea._742d9f967af8(_755af5a1d925 / _14b7a7cdd441, _a32bfbf6fc08=-1)
                _9b128c4e0407 = _810510729dc7._766e16553e7b._b45f3b6f86ea._8a6b857ce37c(_703344bfbe57 / _14b7a7cdd441, _a32bfbf6fc08=-1)
                _f555642589c1 = _810510729dc7._766e16553e7b._b45f3b6f86ea._07d9fd7c109c(_c372bf276ebd, _9b128c4e0407, _79eae9792158="batchmean") * (_14b7a7cdd441 * _14b7a7cdd441)
                _bde2bd767d1a = 1 - _810510729dc7._766e16553e7b._b45f3b6f86ea._417d18ae63a5(_755af5a1d925, _703344bfbe57, _a32bfbf6fc08=-1)._5ef8fd0784dc()
                return _f555642589c1, _bde2bd767d1a

            # Chunked mode for large inputs
            _6ca72a4604ef = _87b3f1d1c16d(1, _faf9985e169d // 8)
            _4c043fdfa65c, _30c2f7608768 = [], []

            for _3f74c2e21537 in _019c57382d1b(0, _faf9985e169d, _6ca72a4604ef):
                _2101c5703eec = _755af5a1d925[_3f74c2e21537:_3f74c2e21537 + _6ca72a4604ef]
                _ec0ed3d67250 = _703344bfbe57[_3f74c2e21537:_3f74c2e21537 + _6ca72a4604ef]

                _c372bf276ebd = _810510729dc7._766e16553e7b._b45f3b6f86ea._742d9f967af8(_2101c5703eec / _14b7a7cdd441, _a32bfbf6fc08=-1)
                _9b128c4e0407 = _810510729dc7._766e16553e7b._b45f3b6f86ea._8a6b857ce37c(_ec0ed3d67250 / _14b7a7cdd441, _a32bfbf6fc08=-1)

                _c0e64dcba204 = _810510729dc7._766e16553e7b._b45f3b6f86ea._07d9fd7c109c(_c372bf276ebd, _9b128c4e0407, _79eae9792158="batchmean") * (_14b7a7cdd441 * _14b7a7cdd441)
                _35f9f19fa7ca = _810510729dc7._766e16553e7b._b45f3b6f86ea._417d18ae63a5(_2101c5703eec, _ec0ed3d67250, _a32bfbf6fc08=-1)._5ef8fd0784dc()
                _dcfcadd47b1a = 1 - _35f9f19fa7ca

                _4c043fdfa65c._115de3784ad2(_c0e64dcba204)
                _30c2f7608768._115de3784ad2(_dcfcadd47b1a)

            _f555642589c1 = _810510729dc7._5a3042dfa5d8(_4c043fdfa65c)._5ef8fd0784dc()
            _bde2bd767d1a = _810510729dc7._5a3042dfa5d8(_30c2f7608768)._5ef8fd0784dc()
            return _f555642589c1, _bde2bd767d1a

        except _9552e1cc4a1d as _0b91e2d78e79:
            raise _8708f1af4959(f"KL/contrastive loss computation failed: {_4da47aecaf3f(_0b91e2d78e79)}")

    def _a5f690344503(self, _ed54a9decad9):
        _6cc4b98bc281 = [
            _51de5c284468
            for _8b597246f51e, _b2b629f1ee10 in self._c1c7aae01ece._69b5704cbec0()
            if self._3f1a0d12d9be[_8b597246f51e] in _ed54a9decad9
            for _51de5c284468 in _b2b629f1ee10
        ]

        self._e05534f9d609 = _b653c6da3144([
            _630c5a9e29d7(
                _6cc4b98bc281=_6cc4b98bc281,
                _75d0002635f2=self._430eab910420,
                _6ddb741f1015=self._afb0d7b22d1c._6ddb741f1015
            )
        ])

    def _753357589c32(self, _bd7e224abe87):
        _ed54a9decad9 = _ea33824555bd()

        if _4955fe52b6b2(_bd7e224abe87, _2b8bce6331b6):
            _8bdead8ab40d = _bd7e224abe87._343738e95723()
        elif _4955fe52b6b2(_bd7e224abe87, (_1fc29e6309f3, _e7d3cf2a96cb)):
            _8bdead8ab40d = _bd7e224abe87
        else:
            _8bdead8ab40d = [_bd7e224abe87]

        for _54880a5666d5 in _8bdead8ab40d:
            _ed54a9decad9._ef32e0e1aa00(_54880a5666d5._ce47da51d866._7562a1fc6a6f)

        return _ed54a9decad9

    def _c6b28d370550(self):
        _ed54a9decad9 = self._e2f38cf854e2(
            self._2a1c30a06ca5._654fba120465
        )
        self._935a1fa88723(_ed54a9decad9)

        _43887641ae66(f"Training Allowed languages {_ed54a9decad9}")

        self._e05534f9d609 = _b653c6da3144([
            _630c5a9e29d7(
                _6cc4b98bc281=[
                    _51de5c284468
                    for _8b597246f51e, _b2b629f1ee10 in self._c1c7aae01ece._69b5704cbec0()
                    if self._3f1a0d12d9be[_8b597246f51e] in _ed54a9decad9
                    for _51de5c284468 in _b2b629f1ee10
                ],
                _75d0002635f2=self._430eab910420,
                _6ddb741f1015=self._afb0d7b22d1c._6ddb741f1015
            )
        ])
        
    def _fa7bc729b443(self, _54c2e2542e63, _75c663ad49e5):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _38f15cb91a9b = _54c2e2542e63["input_ids"]
            _ac7db27b05e9 = _54c2e2542e63["labels"]
            _7b43ac47941b = _54c2e2542e63._03294381a598("prompt_lens", _d2d1d82801e9)
            _faf9985e169d = _38f15cb91a9b._d0a907f2a6ce(0)

            # move to device
            _38f15cb91a9b = _38f15cb91a9b._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)
            _ac7db27b05e9 = _ac7db27b05e9._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)

            # ---- scheduled sampling (minimal) ----
            _5d4bc2e289fb = 0.0 if self._b1c1e279490f < 2 else self._9b86c66b3d5e  # e.g. 0.2
            if _5d4bc2e289fb > 0.0 and (_75c663ad49e5 % 2 == 0):
                with _810510729dc7._e71d6b3adcce():
                    # 1. run a no-grad forward to get predictions
                    _28ea81294615, _, _ = self(_38f15cb91a9b)
                    _e604b1b083c7 = _28ea81294615._efd6a0f98ef9(_a32bfbf6fc08=-1)
                    _e604b1b083c7 = _810510729dc7._4a06a3d0d119(
                        [_38f15cb91a9b[:, :1], _e604b1b083c7[:, :-1]],
                        _a32bfbf6fc08=1
                    )

                # 2. decide where to replace (Bernoulli mask)
                _0457cbfb4451 = _810510729dc7._6ce05053789c(_38f15cb91a9b._3a3dfa495bcf()) < _5d4bc2e289fb

                # 3. NEVER replace masked-out labels (-100) or input side
                _f7ad97611091 = (_ac7db27b05e9 != -100)
                _0457cbfb4451 &= _f7ad97611091

                # 4. replace teacher tokens with model predictions
                _38f15cb91a9b = _810510729dc7._0de27070d3a2(_0457cbfb4451, _e604b1b083c7, _38f15cb91a9b)
            # -------------------------------------

            # ---- label dropout (generic, safe) ----
            _79fc6115b21a = 0.0 if self._b1c1e279490f < 2 else 0.2  # start small
            if _79fc6115b21a > 0 and (_75c663ad49e5 % 2 == 0):
                _ff1ee6703573 = (
                    (_810510729dc7._6ce05053789c(_38f15cb91a9b._3a3dfa495bcf()) < _79fc6115b21a)
                    & (_ac7db27b05e9 != -100)
                )
                _38f15cb91a9b = _810510729dc7._0de27070d3a2(
                    _ff1ee6703573,
                    self._430eab910420,
                    _38f15cb91a9b
                )
            # -------------------------------------
            
            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _c33165cec31a, _cfffcba5d51d, _afcb5f24a400 = self(_38f15cb91a9b)

            # causal LM shift for next-token classification (unchanged)
            _8915447af55f = _c33165cec31a[:, :-1, :]._580b1476f3fd()
            _c398fe85713b = _ac7db27b05e9[:, 1:]._580b1476f3fd()
            _7ccc99a2396c = _8915447af55f._fefef823d698(-1, _8915447af55f._d0a907f2a6ce(-1))
            _da6827ce8c0c = _c398fe85713b._fefef823d698(-1)

            # classification/task loss
            _8a7e335477d0 = self._52ec756e7e90['criterion'](_7ccc99a2396c, _da6827ce8c0c)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _cfffcba5d51d = _810510729dc7._6fc811fed75c(_cfffcba5d51d, _02819b15b862=0.0, _d25dd7c4a1ca=0.0, _b5ebfdc11b05=0.0)
            _afcb5f24a400 = _810510729dc7._6fc811fed75c(_afcb5f24a400, _02819b15b862=0.0, _d25dd7c4a1ca=0.0, _b5ebfdc11b05=0.0)
            _8a7e335477d0 = _810510729dc7._6fc811fed75c(_8a7e335477d0, _02819b15b862=0.0, _d25dd7c4a1ca=0.0, _b5ebfdc11b05=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _11b590c36109 = self._324bb78b95f7(_8a7e335477d0, _cfffcba5d51d, _afcb5f24a400)
            _d851a165620d = _11b590c36109["aux_term"]

            if _8a7e335477d0._46eb1dcccfd6() < self._f43386a2da5a:
                _d851a165620d = _810510729dc7._9cef8de1c9c6(_8a7e335477d0)

            # final combined loss (single-equation)
            _a706da9ceebb = _8a7e335477d0 + _d851a165620d

            # Optional NaN print as before (keeps your original check)
            if _810510729dc7._9905ba7ac075(_8a7e335477d0):
                _43887641ae66(f"Step {_75c663ad49e5}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _53fbee8b60d6 = {
                "epoch": _3a3dfa495bcf(_f5597c2b351b(self, "current_epoch", _f5597c2b351b(self._2a1c30a06ca5, "current_epoch", 0))),
                "train_kl_loss": _11b590c36109._03294381a598("kl_loss", _cfffcba5d51d)._46eb1dcccfd6() if _4955fe52b6b2(_11b590c36109._03294381a598("kl_loss", _cfffcba5d51d), _810510729dc7._0c00e83b221f) else _11b590c36109._03294381a598("kl_loss", _cfffcba5d51d),
                "train_contrastive_loss": _11b590c36109._03294381a598("contrastive_loss", _afcb5f24a400)._46eb1dcccfd6() if _4955fe52b6b2(_11b590c36109._03294381a598("contrastive_loss", _afcb5f24a400), _810510729dc7._0c00e83b221f) else _11b590c36109._03294381a598("contrastive_loss", _afcb5f24a400),
                "train_classification_loss": _8a7e335477d0._46eb1dcccfd6(),
                "train_loss": _a706da9ceebb._46eb1dcccfd6(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _3a3dfa495bcf(_f5597c2b351b(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _11b590c36109._03294381a598("lambda_kl_eff", _3a3dfa495bcf(_f5597c2b351b(self, "kl_base", 0.30))),
                "train_lambda_contrast": _11b590c36109._03294381a598("lambda_cos_eff", _3a3dfa495bcf(_f5597c2b351b(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _5fbeef4263c4 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _5fbeef4263c4 in _11b590c36109:
                    _0dfac976f168 = _11b590c36109[_5fbeef4263c4]
                    # convert single-element tensors to python floats for logging
                    if _4955fe52b6b2(_0dfac976f168, _810510729dc7._0c00e83b221f) and _0dfac976f168._92c2a00bc9ec() == 1:
                        _53fbee8b60d6[f"train_{_5fbeef4263c4}"] = _3a3dfa495bcf(_0dfac976f168._46eb1dcccfd6()._8b7b4c762d6c()._647e261773cf())
                    else:
                        _53fbee8b60d6[f"train_{_5fbeef4263c4}"] = _0dfac976f168

            # log exactly like you did
            self._95eec910620b(
                _53fbee8b60d6,
                _faf9985e169d=_faf9985e169d,
                _312914356a78=_eba335b1d5cd,
                _ee6a3d5edf7c=_cdc6b872c644,
                _2c2807eec455=_eba335b1d5cd,
                _839c74d07edd=_cdc6b872c644,
                _5a78f1d7d695=_cdc6b872c644,
            )

            # free references as you did
            del _38f15cb91a9b, _ac7db27b05e9, _c33165cec31a, _cfffcba5d51d, _8a7e335477d0, _afcb5f24a400, _c398fe85713b, _8915447af55f, _da6827ce8c0c, _7ccc99a2396c

            return _a706da9ceebb

        except _9552e1cc4a1d as _0b91e2d78e79:
            raise _8708f1af4959(f"Error in training_step: {_0b91e2d78e79}") from _0b91e2d78e79

    def _a2c8ff13ff00(self):
        if _810510729dc7._6958a31f26b5._b643c947233a():
            _810510729dc7._6958a31f26b5._2074bc6a8877()
        _683fab15ebb5._b8dfe2982616()
        return _cf1ae2e411b3()._cc470109dbc7()

    # def validation_step(self, batch, batch_idx):
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification (same as training)
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     if batch_idx == 0:
    #         try:
    #             print(
    #                 f"VAL TEST BATCH {batch_idx} Input IDs: {input_ids.tolist()[0]}, "
    #                 f"Predictions: {torch.argmax(shift_logits, dim=-1).tolist()[0]}, "
    #                 f"Labels: {shift_labels.tolist()[0]}"
    #             )
    #         except Exception:
    #             # printing should never crash validation
    #             pass

    #     # classification loss
    #     classification_loss = self.loss_funcs['criterion'](logits_flat, labels_flat)

    #     # numeric guards (preserve your original torch.where behavior but simpler)
    #     kl_batch = torch.nan_to_num(kl_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     contrast_batch = torch.nan_to_num(contrast_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     classification_loss = torch.nan_to_num(classification_loss, nan=0.0, posinf=0.0, neginf=0.0)

    #     # ---------------------
    #     # Compute auxiliary term using the same helper as training
    #     # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
    #     aux = self.compute_auxiliary_distill_term(classification_loss, kl_batch, contrast_batch)
    #     aux_term = aux["aux_term"]
    #     if classification_loss.detach() < self.task_loss_floor:
    #         aux_term = torch.zeros_like(classification_loss)

    #     combined_loss = classification_loss + aux_term

    #     # Logging: preserve your keys but prefer the aux diagnostics where available
    #     log_dict = {
    #         "val_kl_loss": float(aux.get("kl_loss", kl_batch).detach().cpu().item()) if isinstance(aux.get("kl_loss", kl_batch), torch.Tensor) else float(aux.get("kl_loss", kl_batch)),
    #         "val_contrastive_loss": float(aux.get("contrastive_loss", contrast_batch).detach().cpu().item()) if isinstance(aux.get("contrastive_loss", contrast_batch), torch.Tensor) else float(aux.get("contrastive_loss", contrast_batch)),
    #         "val_classification_loss": float(classification_loss.detach().cpu().item()),
    #         "val_loss": float(combined_loss.detach().cpu().item()),
    #     }

    #     # include effective lambdas and others if provided by aux
    #     log_dict["val_lambda_kl"] = float(aux.get("lambda_kl", aux.get("lambda_kl_eff", float(getattr(self, "kl_base", 0.30)))))
    #     log_dict["val_lambda_contrast"] = float(aux.get("lambda_cos", aux.get("lambda_cos_eff", float(getattr(self, "cos_base", 0.25)))))
    #     log_dict["val_w_mean"] = float(aux.get("w_mean", 0.0))
    #     log_dict["val_aux_scale"] = float(aux.get("aux_scale", 0.0))
    #     log_dict["val_shift_r"] = float(aux.get("shift_r", 0.0))
    #     log_dict["val_teacher_conf_mean"] = float(aux.get("teacher_conf_mean", 0.0))

    #     self.log_dict(
    #         log_dict,
    #         batch_size=batch_size,
    #         on_step=False,
    #         on_epoch=True,
    #         prog_bar=False,
    #         logger=True,
    #         sync_dist=True,
    #     )

    #     # build preds and labels per example (preserve your previous behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "val_loss": combined_loss,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # store for epoch-end aggregation (your code uses self._validation_outputs)
    #     self._validation_outputs.append(output)

    #     # explicit frees (same as you had)
    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, classification_loss, preds_list, labels_list

    #     return output

    def _2fda4bd8035b(self, _54c2e2542e63, _75c663ad49e5):
        _38f15cb91a9b = _54c2e2542e63["input_ids"]._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)
        _ac7db27b05e9 = _54c2e2542e63["labels"]._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)

        _7562a1fc6a6f = _54c2e2542e63._03294381a598("lang_codes", _d2d1d82801e9)
        _17afad208602 = _54c2e2542e63._03294381a598("sample_ids", _d2d1d82801e9)
        _a2b1c13e5711 = _54c2e2542e63._03294381a598("chunk_ids", _d2d1d82801e9)
        _a61419f97bf6 = _54c2e2542e63._03294381a598("word_positions", _d2d1d82801e9)
        _7b43ac47941b = _54c2e2542e63._03294381a598("prompt_lens", _d2d1d82801e9)
        _b583ac21adea = _54c2e2542e63._03294381a598("num_chunks", _d2d1d82801e9)

        _faf9985e169d = _38f15cb91a9b._d0a907f2a6ce(0)

        _4fb262f6a61d = (_ac7db27b05e9 != -100)._942d992a5d33(_a32bfbf6fc08=1)
        _455f3bdc5973 = _4fb262f6a61d._87b3f1d1c16d()._647e261773cf()

        with _810510729dc7._e71d6b3adcce():
            _2f3dcfac4870 = self._9c567992fccb(
                _38f15cb91a9b=_38f15cb91a9b,
                _daa404f0ae76=_455f3bdc5973,
                _05adde2c7d3b=_455f3bdc5973,
                _9670df5c6586=_eba335b1d5cd,
                _41cab2fb4630=1,
                _65e77d16fd2d=1.0,
                _48ff4ebf4b94=1.0,
                # repetition_penalty=1.0,
                # length_penalty=1.0,
                # early_stopping=True,
                _c7527fe5e4b7=_cdc6b872c644,
                _e05534f9d609=self._e05534f9d609,
                _8ea4cfad08bc=_cdc6b872c644,
                _3424504f5ede=_cdc6b872c644,
                _c87526d4886a=_eba335b1d5cd,
            )


        _34e6618c5fdf = _810510729dc7._5a3042dfa5d8(_2f3dcfac4870._74423ea260f1, _a32bfbf6fc08=1)   # (B, T_gen, V)

        _9b0a39580087 = _38f15cb91a9b._d0a907f2a6ce(1)
        _6867df0390de, _e771432dbbcf, _8de4da5af960 = _34e6618c5fdf._457dc7fa890f
        _95973621e50a = _ac7db27b05e9._d0a907f2a6ce(1)

        _f62684d3445f = _2f3dcfac4870._af09ff6ac2a5
        _60c8ac80d124 = _f62684d3445f

        # ---- build pred_tokens WITHOUT argmax on junk ----
        _e604b1b083c7 = _810510729dc7._892a9c812b2a(
            (_6867df0390de, _95973621e50a),
            -100,
            _c59b9fb2a946=_34e6618c5fdf._c59b9fb2a946,
            _cf75de35227b=_810510729dc7._fac41cb50e59,
        )

        # pred_tokens[:, prompt_len : prompt_len + T_gen] = torch.argmax(gen_logits, dim=-1)
        _e604b1b083c7[:, _9b0a39580087 : _9b0a39580087 + _e771432dbbcf] = _60c8ac80d124[:, _9b0a39580087 : _9b0a39580087 + _e771432dbbcf]

        # DEBUG — AS-IS, full length
        if _75c663ad49e5 == 0:
            _43887641ae66(
                "VAL DEBUG\n"
                f"INPUT IDS      : {_38f15cb91a9b[0]._bdf517f1c435()}\n"
                f"GEN IDS (ONLY) : {_60c8ac80d124[0]._bdf517f1c435()}\n"
                f"PRED TOKENS    : {_e604b1b083c7[0]._bdf517f1c435()}\n"
                f"LABELS (FULL)  : {_ac7db27b05e9[0]._bdf517f1c435()}"
            )


        _6f8e4f4c3a6e = _9b0a39580087
        _029243aa9c99 = _9b0a39580087 + _34e6618c5fdf._d0a907f2a6ce(1)

        # logits_flat = gen_logits.reshape(-1, gen_logits.size(-1))
        # labels_flat = labels[:, gen_start:gen_end].reshape(-1)

        _3bd263873bf9 = _ac7db27b05e9[:, _6f8e4f4c3a6e:_029243aa9c99]
        _91ad70fa7ae8 = _3bd263873bf9 != -100

        _7ccc99a2396c = _34e6618c5fdf[_91ad70fa7ae8]
        _da6827ce8c0c = _3bd263873bf9[_91ad70fa7ae8]

        if _75c663ad49e5 == 0:
            _43887641ae66(
                "VAL DEBUG\n"
                f"LOGITS FLAT : {_7ccc99a2396c._457dc7fa890f}\n"
                f"LABELS FLAT : {_da6827ce8c0c._457dc7fa890f}\n"
            )
        

        _8a7e335477d0 = self._52ec756e7e90["criterion"](_7ccc99a2396c, _da6827ce8c0c)
        _8a7e335477d0 = _810510729dc7._6fc811fed75c(_8a7e335477d0, _02819b15b862=0.0)

        _cfffcba5d51d = _810510729dc7._bc4e457e4d34(0.0, _c59b9fb2a946=_38f15cb91a9b._c59b9fb2a946)
        _afcb5f24a400 = _810510729dc7._bc4e457e4d34(0.0, _c59b9fb2a946=_38f15cb91a9b._c59b9fb2a946)

        # if gen_out.hidden_states is not None:
        #     hs = gen_out.hidden_states
        #     last_step = hs[-1]
        #     last_layer = last_step[-1] if isinstance(last_step, (tuple, list)) else last_step
        #     student_hidden = last_layer[:, -T_gen:, :]

        #     with torch.no_grad():
        #         frozen_outs = FROZEN_EMBEDDING(
        #             input_ids=generated_ids,
        #             attention_mask=(generated_ids != self.tokenizer.pad_token_id),
        #             output_hidden_states=True,
        #             return_dict=True,
        #         )
        #         frozen_hidden = frozen_outs.hidden_states[-1][:, -T_gen:, :]

        #     kl_batch, contrast_batch = self.compute_kl_contrastive_loss(
        #         student_hidden,
        #         frozen_hidden,
        #         device=self.curr_device,
        #     )

        _cfffcba5d51d = _810510729dc7._6fc811fed75c(_cfffcba5d51d, _02819b15b862=0.0)
        _afcb5f24a400 = _810510729dc7._6fc811fed75c(_afcb5f24a400, _02819b15b862=0.0)

        _11b590c36109 = self._324bb78b95f7(
            _8a7e335477d0,
            _cfffcba5d51d,
            _afcb5f24a400,
        )

        _d851a165620d = _11b590c36109["aux_term"]
        if _8a7e335477d0._46eb1dcccfd6() < self._f43386a2da5a:
            _d851a165620d = _810510729dc7._9cef8de1c9c6(_8a7e335477d0)

        _a706da9ceebb = _8a7e335477d0 + _d851a165620d

        self._95eec910620b(
            {
                "val_loss": _a706da9ceebb._46eb1dcccfd6(),
                "val_classification_loss": _8a7e335477d0._46eb1dcccfd6(),
                "val_kl_loss": _11b590c36109._03294381a598("kl_loss", _cfffcba5d51d),
                "val_contrastive_loss": _11b590c36109._03294381a598("contrastive_loss", _afcb5f24a400),
                "val_lambda_kl": _11b590c36109._03294381a598("lambda_kl_eff", 0.0),
                "val_lambda_contrast": _11b590c36109._03294381a598("lambda_cos_eff", 0.0),
                "val_teacher_conf_mean": _11b590c36109._03294381a598("teacher_conf_mean", 0.0),
            },
            _faf9985e169d=_faf9985e169d,
            _312914356a78=_eba335b1d5cd,
            _ee6a3d5edf7c=_cdc6b872c644,
            _5a78f1d7d695=_cdc6b872c644,
        )

        _556920d67bf3 = [_60c8ac80d124[_3f74c2e21537] for _3f74c2e21537 in _019c57382d1b(_faf9985e169d)]
        _8395acbb96de = [_ac7db27b05e9[_3f74c2e21537] for _3f74c2e21537 in _019c57382d1b(_faf9985e169d)]

        _34db4e1421b0 = {
            "lang_codes": _7562a1fc6a6f,
            "preds": _556920d67bf3,
            "labels": _8395acbb96de,
            "sample_ids": _17afad208602,
            "chunk_ids": _a2b1c13e5711,
            "word_positions": _a61419f97bf6,
            "prompt_lens": _7b43ac47941b,
            "num_chunks": _b583ac21adea,
            "val_loss": _a706da9ceebb,
        }

        self._b410091ad04f._115de3784ad2(_34db4e1421b0)

        del _38f15cb91a9b, _ac7db27b05e9, _2f3dcfac4870, _34e6618c5fdf
        del _7ccc99a2396c, _da6827ce8c0c, _60c8ac80d124
        del _cfffcba5d51d, _afcb5f24a400, _8a7e335477d0
        del _556920d67bf3, _8395acbb96de

        return _34db4e1421b0

    def _e12d0611f910(self, _ff3da39336e7, _2f09235201a1, _dd89e135e16f=_d2d1d82801e9):
        _c1009f7c0e8b = os._e0b93a2dc864()
        _a37b1d2bb6c0 = f"trial_{_dd89e135e16f}" if _dd89e135e16f is not _d2d1d82801e9 else "default"
        _43887641ae66(f"[DEBUG rank={_810510729dc7._d5532b6eeaf5._844b628af9de() if _810510729dc7._d5532b6eeaf5._1d6b16dbc453() else 0}] metrics_dict confusion_matrix sum={_942d992a5d33(_942d992a5d33(_cc0a4c3ab604) for _cc0a4c3ab604 in _ff3da39336e7['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _a97e2ec71f7f = os._586148d6d4fd._7c5f46dda0cb(_c1009f7c0e8b, "metrics", self._6a96cd1cc8bf,  _a37b1d2bb6c0)
        os._3ef3b454c974(_a97e2ec71f7f, _6940a1df0fee=_cdc6b872c644)
        _d29892fefff8 = os._586148d6d4fd._7c5f46dda0cb(_a97e2ec71f7f, _2f09235201a1)
        _6c25b493d488 = _604b5332752e._c7344c162605(_ff3da39336e7)
        _6c25b493d488._aa55f75d7e70(_d29892fefff8, _6f474ba5359d=_eba335b1d5cd)
        _43887641ae66(f"[metrics] Saved {_d29892fefff8}")

    def _aa41876e4d4b(self):
        # pick correct device for this rank
        if _810510729dc7._6958a31f26b5._b643c947233a():
            if _810510729dc7._d5532b6eeaf5._1d6b16dbc453():
                _738bfc7e8bb7 = _810510729dc7._d5532b6eeaf5._844b628af9de()
            else:
                _738bfc7e8bb7 = 0
            _810510729dc7._6958a31f26b5._58df84d0a5f3(_738bfc7e8bb7)
            self._b753732b8644 = _810510729dc7._c59b9fb2a946(f"cuda:{_738bfc7e8bb7}")
        else:
            self._b753732b8644 = _810510729dc7._c59b9fb2a946("cpu")
        
        _ed54a9decad9 = self._e2f38cf854e2(
            self._2a1c30a06ca5._4416073f4231
        )
        self._935a1fa88723(_ed54a9decad9)

        _43887641ae66(f"Validation Allowed languages {_ed54a9decad9}")

        self._e05534f9d609 = _b653c6da3144([
            _630c5a9e29d7(
                _6cc4b98bc281=[
                    _51de5c284468
                    for _8b597246f51e, _b2b629f1ee10 in self._c1c7aae01ece._69b5704cbec0()
                    if self._3f1a0d12d9be[_8b597246f51e] in _ed54a9decad9
                    for _51de5c284468 in _b2b629f1ee10
                ],
                _75d0002635f2=self._430eab910420,
                _6ddb741f1015=self._afb0d7b22d1c._6ddb741f1015
            )
        ])

        self._0bf7ae7c100e()

    def _7af052029875(self):
        _c33165cec31a = _f5597c2b351b(self, "_validation_outputs", _d2d1d82801e9)
        if not _c33165cec31a:
            return

        _220990b4b253, _1ccdbf6aa9b5, _2da6a7906ee7, _a5b5b678d934 = \
            self._b205287f5374(_c33165cec31a)

        _867e4d631da3, _21585db41c9f = [], []
        for _f3d079561d0d in _4de56f1ba083(_2da6a7906ee7._4d858fb90522()):
            _e0d88b8a8f92 = _220990b4b253[_f3d079561d0d]._bdf517f1c435()
            _a5860431bcf3 = _1ccdbf6aa9b5[_f3d079561d0d]._bdf517f1c435()
            _597b232c1a47 = _2da6a7906ee7[_f3d079561d0d]
            _1c6d30ec8f17 = _a5b5b678d934[_f3d079561d0d]
            if _597b232c1a47._92c2a00bc9ec() > 0 and _1c6d30ec8f17._92c2a00bc9ec() > 0:
                _867e4d631da3._115de3784ad2(_597b232c1a47)
                _21585db41c9f._115de3784ad2(_1c6d30ec8f17)

        if not _867e4d631da3:
            _43887641ae66("[VAL END] Nothing to score.")
            self._b410091ad04f._f0913b3358b4()
            return

        _78d74f2eb745 = _810510729dc7._4a06a3d0d119(_867e4d631da3)._8727f06591ca(_c59b9fb2a946=self._1ed1a645da62['micro_accuracy']._c59b9fb2a946, _58feefeef430=_cdc6b872c644)
        _ac7db27b05e9 = _810510729dc7._4a06a3d0d119(_21585db41c9f)._8727f06591ca(_c59b9fb2a946=self._1ed1a645da62['micro_accuracy']._c59b9fb2a946, _58feefeef430=_cdc6b872c644)

        self._1ed1a645da62['micro_accuracy']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_accuracy']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_precision']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_recall']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_f1']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_accuracy']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_precision']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_recall']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_f1']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['confmat']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)

        _c3c6a1fb8ee6  = self._1ed1a645da62['micro_accuracy']._d5c68cfa4e6b()._647e261773cf()
        _5da2ed5d7330  = self._1ed1a645da62['macro_accuracy']._d5c68cfa4e6b()._647e261773cf()
        _5ccc28f7a9cc = self._1ed1a645da62['macro_precision']._d5c68cfa4e6b()._647e261773cf()
        _87eef620780e    = self._1ed1a645da62['macro_recall']._d5c68cfa4e6b()._647e261773cf()
        _8e71bb00eaeb        = self._1ed1a645da62['macro_f1']._d5c68cfa4e6b()._647e261773cf()

        self._323b3d57ea50("val_accuracy", _5da2ed5d7330, _5a78f1d7d695=_cdc6b872c644)

        try:
            _b2c4a080df85 = self._b1c1e279490f
            _ff3da39336e7 = {
                "epoch": [_b2c4a080df85],
                "class_names": [self._3f1a0d12d9be],
                "micro_accuracy": [_c3c6a1fb8ee6],
                "macro_accuracy": [_5da2ed5d7330],
                "macro_precision": [_5ccc28f7a9cc],
                "macro_recall": [_87eef620780e],
                "macro_f1": [_8e71bb00eaeb],
                "classwise_accuracy": [self._1ed1a645da62['classwise_accuracy']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "classwise_precision": [self._1ed1a645da62['classwise_precision']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "classwise_recall": [self._1ed1a645da62['classwise_recall']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "classwise_f1": [self._1ed1a645da62['classwise_f1']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "confusion_matrix": [self._1ed1a645da62['confmat']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
            }
            self._fbfbd3f4c0ad(_ff3da39336e7, f"val_epoch_{_b2c4a080df85}.csv", _dd89e135e16f=self._dd89e135e16f)
        except _9552e1cc4a1d as _0b91e2d78e79:
            _43887641ae66(f"[VAL END] save metrics FAILED: {_0b91e2d78e79}")

        # cleanup
        self._1ed1a645da62['micro_accuracy']._624be09e2960(); self._1ed1a645da62['macro_accuracy']._624be09e2960()
        self._1ed1a645da62['macro_precision']._624be09e2960(); self._1ed1a645da62['macro_recall']._624be09e2960(); self._1ed1a645da62['macro_f1']._624be09e2960()
        self._1ed1a645da62['classwise_accuracy']._624be09e2960(); self._1ed1a645da62['classwise_precision']._624be09e2960()
        self._1ed1a645da62['classwise_recall']._624be09e2960(); self._1ed1a645da62['classwise_f1']._624be09e2960()
        self._1ed1a645da62['confmat']._624be09e2960(); self._b410091ad04f._f0913b3358b4()
        if _810510729dc7._6958a31f26b5._b643c947233a():
            _810510729dc7._6958a31f26b5._2074bc6a8877()
        _43887641ae66("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_810510729dc7._e71d6b3adcce()
    def _0d0c82114a42(self, _38f15cb91a9b: _810510729dc7._0c00e83b221f, **_c1797c9c9bdb):
        _c1797c9c9bdb._604711a1335e("pad_token_id", _d2d1d82801e9)
        _c1797c9c9bdb._604711a1335e("attention_mask", _d2d1d82801e9)
        return self._28eca43959eb._9c567992fccb(
            _38f15cb91a9b=_38f15cb91a9b,
            _d0804e6969bf=(_38f15cb91a9b != self._afb0d7b22d1c._cc43173d9090),
            _cc43173d9090=self._afb0d7b22d1c._cc43173d9090,
            _6ddb741f1015=self._afb0d7b22d1c._6ddb741f1015,
            **_c1797c9c9bdb
        )

    def _6cfd674d2363(self, _54c2e2542e63, _75c663ad49e5):
        _38f15cb91a9b = _54c2e2542e63["input_ids"]._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)
        _ac7db27b05e9    = _54c2e2542e63["labels"]._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)
        _7562a1fc6a6f     = _54c2e2542e63._03294381a598("lang_codes", _d2d1d82801e9)
        _17afad208602     = _54c2e2542e63._03294381a598("sample_ids", _d2d1d82801e9)
        _a2b1c13e5711      = _54c2e2542e63._03294381a598("chunk_ids", _d2d1d82801e9)
        _a61419f97bf6 = _54c2e2542e63._03294381a598("word_positions", _d2d1d82801e9)
        _7b43ac47941b    = _54c2e2542e63._03294381a598("prompt_lens", _d2d1d82801e9)
        _b583ac21adea = _54c2e2542e63._03294381a598("num_chunks", _d2d1d82801e9)

        _faf9985e169d = _38f15cb91a9b._d0a907f2a6ce(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _3a83ed3dea3e = [_78d8252c7db0(_8d1a7b990196) for _8d1a7b990196 in _a61419f97bf6]
        _62616de393e7 = _87b3f1d1c16d(_3a83ed3dea3e)
        _60c8ac80d124 = self._9c567992fccb(
            _38f15cb91a9b,
            # max_new_tokens=64,
            # do_sample=False,
            # temperature=None,     # for deterministic answers
            # top_p=None,           # for deterministic answers
            # repetition_penalty=1.2,
            # fully deterministic decoding
            _daa404f0ae76=_62616de393e7,        # hard cap on number of generated tokens
            _05adde2c7d3b=_62616de393e7,        # forces fixed-length output (prevents early EOS)
            _9670df5c6586=_eba335b1d5cd,          # disables sampling ; greedy decoding
            _41cab2fb4630=1,              # no beam search ; single deterministic path
            _65e77d16fd2d=1.0,          # 1.2 with do_sample True; neutral temperature (no probability scaling)
            _48ff4ebf4b94=1.0,                # disables nucleus filtering
            # repetition_penalty=1.0,   # no penalty for repeated tokens
            # length_penalty=1.0,       # no bias toward shorter/longer sequences
            # early_stopping=True,     # do not stop on EOS before min_new_tokens
            _c7527fe5e4b7=_cdc6b872c644,           # reuse KV cache for consistent + faster decoding
            _e05534f9d609=self._e05534f9d609,
        )

        if _75c663ad49e5 == 0:
            try:
                _43887641ae66(
                    f"TEST TEST BATCH {_75c663ad49e5} Input IDs: {_38f15cb91a9b._bdf517f1c435()[0]}, "
                    f"Generated IDs: {_60c8ac80d124._bdf517f1c435()[0]}, "
                    f"Labels: {_ac7db27b05e9._bdf517f1c435()[0]}"
                )
            except _9552e1cc4a1d:
                # printing should never crash testing
                pass


        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _556920d67bf3 = []
        _8395acbb96de = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _3f74c2e21537 in _019c57382d1b(_faf9985e169d):
            _556920d67bf3._115de3784ad2(_60c8ac80d124[_3f74c2e21537]._46eb1dcccfd6()._8b7b4c762d6c())
            _8395acbb96de._115de3784ad2(_ac7db27b05e9[_3f74c2e21537]._46eb1dcccfd6()._8b7b4c762d6c())


        _34db4e1421b0 = {
            "lang_codes": _7562a1fc6a6f,
            "preds": _556920d67bf3,
            "labels": _8395acbb96de,
            "sample_ids": _17afad208602,
            "chunk_ids": _a2b1c13e5711,
            "word_positions": _a61419f97bf6,
            "prompt_lens": _7b43ac47941b,
            "num_chunks": _b583ac21adea,
        }

        self._f5ef19aca27b._115de3784ad2(_34db4e1421b0)

        # Exact same cleanup as before
        del _38f15cb91a9b, _ac7db27b05e9, _60c8ac80d124, _556920d67bf3, _8395acbb96de

        return _34db4e1421b0

    def _f5d1bd8fb792(self):
        # pick correct device for this rank
        if _810510729dc7._6958a31f26b5._b643c947233a():
            if _810510729dc7._d5532b6eeaf5._1d6b16dbc453():
                _738bfc7e8bb7 = _810510729dc7._d5532b6eeaf5._844b628af9de()
            else:
                _738bfc7e8bb7 = 0
            _810510729dc7._6958a31f26b5._58df84d0a5f3(_738bfc7e8bb7)
            self._b753732b8644 = _810510729dc7._c59b9fb2a946(f"cuda:{_738bfc7e8bb7}")
        else:
            self._b753732b8644 = _810510729dc7._c59b9fb2a946("cpu")

        _ed54a9decad9 = self._e2f38cf854e2(
            self._2a1c30a06ca5._af17547ef68a
        )
        self._935a1fa88723(_ed54a9decad9)

        _43887641ae66(f"Test Allowed languages {_ed54a9decad9}")

        self._e05534f9d609 = _b653c6da3144([
            _630c5a9e29d7(
                _6cc4b98bc281=[
                    _51de5c284468
                    for _8b597246f51e, _b2b629f1ee10 in self._c1c7aae01ece._69b5704cbec0()
                    if self._3f1a0d12d9be[_8b597246f51e] in _ed54a9decad9
                    for _51de5c284468 in _b2b629f1ee10
                ],
                _75d0002635f2=self._430eab910420,
                _6ddb741f1015=self._afb0d7b22d1c._6ddb741f1015
            )
        ])

        self._0bf7ae7c100e()
        
    def _4c985296ed11(self):
        _c33165cec31a = _f5597c2b351b(self, "_test_outputs", _d2d1d82801e9)
        _43887641ae66(f"[DEBUG rank={_810510729dc7._d5532b6eeaf5._844b628af9de()}] outputs_len={_78d8252c7db0(_c33165cec31a)}")
        if not _c33165cec31a:
            return

        _220990b4b253, _1ccdbf6aa9b5, _2da6a7906ee7, _a5b5b678d934 = \
            self._b205287f5374(_c33165cec31a, _096b40e399d6=_cdc6b872c644)

        _867e4d631da3, _21585db41c9f = [], []
        for _f3d079561d0d in _4de56f1ba083(_2da6a7906ee7._4d858fb90522()):
            _e0d88b8a8f92 = _220990b4b253[_f3d079561d0d]._bdf517f1c435()
            _a5860431bcf3 = _1ccdbf6aa9b5[_f3d079561d0d]._bdf517f1c435()
            _597b232c1a47 = _2da6a7906ee7[_f3d079561d0d]
            _1c6d30ec8f17 = _a5b5b678d934[_f3d079561d0d]

            if _597b232c1a47._92c2a00bc9ec() > 0 and _1c6d30ec8f17._92c2a00bc9ec() > 0:
                _867e4d631da3._115de3784ad2(_597b232c1a47)
                _21585db41c9f._115de3784ad2(_1c6d30ec8f17)

        if not _867e4d631da3:
            _43887641ae66("[TEST END] Nothing to score.")
            self._b410091ad04f._f0913b3358b4()
            return

        _78d74f2eb745 = _810510729dc7._4a06a3d0d119(_867e4d631da3)._8727f06591ca(_c59b9fb2a946=self._1ed1a645da62['micro_accuracy']._c59b9fb2a946, _58feefeef430=_cdc6b872c644)
        _ac7db27b05e9 = _810510729dc7._4a06a3d0d119(_21585db41c9f)._8727f06591ca(_c59b9fb2a946=self._1ed1a645da62['micro_accuracy']._c59b9fb2a946, _58feefeef430=_cdc6b872c644)

        self._1ed1a645da62['micro_accuracy']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_accuracy']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_precision']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_recall']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['macro_f1']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_accuracy']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_precision']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_recall']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['classwise_f1']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)
        self._1ed1a645da62['confmat']._ef32e0e1aa00(_78d74f2eb745, _ac7db27b05e9)

        _c3c6a1fb8ee6  = self._1ed1a645da62['micro_accuracy']._d5c68cfa4e6b()._647e261773cf()
        _5da2ed5d7330  = self._1ed1a645da62['macro_accuracy']._d5c68cfa4e6b()._647e261773cf()
        _5ccc28f7a9cc = self._1ed1a645da62['macro_precision']._d5c68cfa4e6b()._647e261773cf()
        _87eef620780e    = self._1ed1a645da62['macro_recall']._d5c68cfa4e6b()._647e261773cf()
        _8e71bb00eaeb        = self._1ed1a645da62['macro_f1']._d5c68cfa4e6b()._647e261773cf()

        self._323b3d57ea50("test_accuracy", _5da2ed5d7330, _5a78f1d7d695=_cdc6b872c644)

        try:
            _b2c4a080df85 = self._b1c1e279490f
            _ff3da39336e7 = {
                "epoch": [_b2c4a080df85],
                "class_names": [self._3f1a0d12d9be],
                "micro_accuracy": [_c3c6a1fb8ee6],
                "macro_accuracy": [_5da2ed5d7330],
                "macro_precision": [_5ccc28f7a9cc],
                "macro_recall": [_87eef620780e],
                "macro_f1": [_8e71bb00eaeb],
                "classwise_accuracy": [self._1ed1a645da62['classwise_accuracy']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "classwise_precision": [self._1ed1a645da62['classwise_precision']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "classwise_recall": [self._1ed1a645da62['classwise_recall']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "classwise_f1": [self._1ed1a645da62['classwise_f1']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
                "confusion_matrix": [self._1ed1a645da62['confmat']._d5c68cfa4e6b()._8727f06591ca(_c59b9fb2a946="cpu")._f5cb434446a3()._bdf517f1c435()],
            }
            self._fbfbd3f4c0ad(_ff3da39336e7, f"test_final.csv", _dd89e135e16f=self._dd89e135e16f)
        except _9552e1cc4a1d as _0b91e2d78e79:
            _43887641ae66(f"[TEST END] save metrics FAILED: {_0b91e2d78e79}")

        # cleanup
        self._1ed1a645da62['micro_accuracy']._624be09e2960(); self._1ed1a645da62['macro_accuracy']._624be09e2960()
        self._1ed1a645da62['macro_precision']._624be09e2960(); self._1ed1a645da62['macro_recall']._624be09e2960(); self._1ed1a645da62['macro_f1']._624be09e2960()
        self._1ed1a645da62['classwise_accuracy']._624be09e2960(); self._1ed1a645da62['classwise_precision']._624be09e2960()
        self._1ed1a645da62['classwise_recall']._624be09e2960(); self._1ed1a645da62['classwise_f1']._624be09e2960()
        self._1ed1a645da62['confmat']._624be09e2960(); self._b410091ad04f._f0913b3358b4()
        if _810510729dc7._6958a31f26b5._b643c947233a():
            _810510729dc7._6958a31f26b5._2074bc6a8877()
        _43887641ae66("[TEST END] Finished and cleaned up.")

    def _8cf27c49d405(self, _54c2e2542e63, _75c663ad49e5, _82aedfa5c863=0):
        """Optimized prediction step with efficient memory handling."""
        _38f15cb91a9b, _ = _54c2e2542e63
        _38f15cb91a9b = _38f15cb91a9b._8727f06591ca(self._b753732b8644, _58feefeef430=_cdc6b872c644)
        _c33165cec31a, _, _ = self(_38f15cb91a9b)
        _d6396b47713b = _810510729dc7._efd6a0f98ef9(_c33165cec31a, _a32bfbf6fc08=-1)
        del _38f15cb91a9b, _c33165cec31a
        if _810510729dc7._6958a31f26b5._b643c947233a():
            _810510729dc7._6958a31f26b5._2074bc6a8877()
        return {"predictions": _d6396b47713b._8b7b4c762d6c()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _1e79c20e39ab(self, _c16ae25130fa, _9a2bb1803831):
        # if sep token not present then just tuple the tokens and return
        if _9a2bb1803831 is _d2d1d82801e9:
            return [(_11afb3da88a2,) for _11afb3da88a2 in _c16ae25130fa]

        _7f5dd038a98f = []
        _b877fc384eb0 = []

        for _11afb3da88a2 in _c16ae25130fa:
            if _11afb3da88a2 == _9a2bb1803831:
                if _b877fc384eb0:
                    _7f5dd038a98f._115de3784ad2(_e7d3cf2a96cb(_b877fc384eb0))
                    _b877fc384eb0 = []
            else:
                if _9a2bb1803831 == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _11afb3da88a2 in _b877fc384eb0:
                        continue
                    else:
                        _b877fc384eb0._115de3784ad2(_11afb3da88a2)
                    
                else:
                    _b877fc384eb0._115de3784ad2(_11afb3da88a2)

        if _b877fc384eb0:
            _7f5dd038a98f._115de3784ad2(_e7d3cf2a96cb(_b877fc384eb0))

        return _7f5dd038a98f

    def _c62a39e8ebf1(self, _343738e95723, _16cdc53129b1="exact_match", _b68cef09928c=_d2d1d82801e9):
        if not _343738e95723:
            return _b68cef09928c

        if _16cdc53129b1 == "exact_match":
            return _343738e95723[0] if _ee7761cf7122(_b85ad739de47 == _343738e95723[0] for _b85ad739de47 in _343738e95723) else _b68cef09928c

        if _16cdc53129b1 == "most_common":
            return _7514a9971a4d(_343738e95723)._ad6cc1606772(1)[0][0]

        if _16cdc53129b1 == "first":
            return _343738e95723[0]

        raise _aec41171a572(f"Unknown vote mode: {_16cdc53129b1}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _0bfb6589c32a(self, _23b00f0fd250):
        _7c4ac2e60ba4 = _ea33824555bd(_11afb3da88a2 for _b2b629f1ee10 in self._c1c7aae01ece._343738e95723() for _11afb3da88a2 in _b2b629f1ee10)
        return _e7d3cf2a96cb(_11afb3da88a2 for _11afb3da88a2 in _23b00f0fd250 if _11afb3da88a2 in _7c4ac2e60ba4)


    def _82de207beacf(self, _c33165cec31a, _b8df537b6310=_cdc6b872c644, _cbcfe092824b="cpu", _096b40e399d6=_eba335b1d5cd):
        from collections import _7196ff7f918b
        import _810510729dc7

        _79f22ef75301 = self._93dfc006bc6f
        _9a2bb1803831 = self._430eab910420
        _07836851ff79 = self._89e62616d0d9

        def _626e9a0b5df4(_39748a02495d):
            if _4955fe52b6b2(_39748a02495d, _810510729dc7._0c00e83b221f):
                return _39748a02495d._46eb1dcccfd6()._8727f06591ca(_c59b9fb2a946=_cbcfe092824b)._b9240d416437(-1)._bdf517f1c435()
            return _1fc29e6309f3(_39748a02495d) if _4955fe52b6b2(_39748a02495d, (_1fc29e6309f3, _e7d3cf2a96cb)) else [_39748a02495d]

        _143b601aa4d2 = _ea33824555bd()
        _84faa997a354 = _7196ff7f918b(_1fc29e6309f3)
        _413b872a94d4 = _7196ff7f918b(_f9e0f962dc7b)
        _b4f4bfaf32f3 = []

        if _b8df537b6310:
            _43887641ae66(f"[reconcile] start: num_outputs={_78d8252c7db0(_c33165cec31a)}")

        for _f6774db8cefe in _c33165cec31a:
            _17afad208602 = _f6774db8cefe["sample_ids"]
            _a2b1c13e5711 = _f6774db8cefe["chunk_ids"]
            _11058ff2590f = _f6774db8cefe["preds"]
            _f516ca73ad1b = _f6774db8cefe["labels"]
            _a61419f97bf6 = _f6774db8cefe["word_positions"]
            _7b43ac47941b = _f6774db8cefe["prompt_lens"]
            _9c90e720711b = _f6774db8cefe["num_chunks"]

            for _3f74c2e21537, _f3d079561d0d in _d31438f8397b(_17afad208602):
                _549e173a8d70 = _f9e0f962dc7b(_a2b1c13e5711[_3f74c2e21537])
                if (_f3d079561d0d, _549e173a8d70) in _143b601aa4d2:
                    continue
                _143b601aa4d2._cf6a117aa8e9((_f3d079561d0d, _549e173a8d70))

                _413b872a94d4[_f3d079561d0d] = _f9e0f962dc7b(_9c90e720711b[_3f74c2e21537])
                _54d505204764 = _f9e0f962dc7b(_7b43ac47941b[_3f74c2e21537])
                _1be84adfda0a = _8a4a5fd23e44(_a61419f97bf6[_3f74c2e21537])
                
                # Right pad 
                # preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_raw = to_list(chunk_labels[i])[prompt_len_i:]

                # left pad
                # preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                # labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _d09a90aac7f2  = _8a4a5fd23e44(_11058ff2590f[_3f74c2e21537])
                _76e5dbdd6e80 = _8a4a5fd23e44(_f516ca73ad1b[_3f74c2e21537])

                _67fc8c485801  = [_5d4bc2e289fb for _5d4bc2e289fb, _29b4a47efcf7 in _a4862bfbff1e(_d09a90aac7f2, _76e5dbdd6e80) if _29b4a47efcf7 != _79f22ef75301]
                _5eab6645391a = [_29b4a47efcf7 for _29b4a47efcf7 in _76e5dbdd6e80 if _29b4a47efcf7 != _79f22ef75301]
                #PROMPT LEN
                # if not left_pad:
                #     preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                #     labels_raw = to_list(chunk_labels[i])[prompt_len_i:]
                # else:
                #     preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                #     labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _eaf6a00189d9 = [_5d4bc2e289fb for _5d4bc2e289fb in _67fc8c485801 if _5d4bc2e289fb != _79f22ef75301]
                _f37fe68a6767 = [_29b4a47efcf7 for _29b4a47efcf7 in _5eab6645391a if _29b4a47efcf7 != _79f22ef75301]

                if _f3d079561d0d not in _b4f4bfaf32f3:
                    _b4f4bfaf32f3._115de3784ad2(_f3d079561d0d)

                _84faa997a354[_f3d079561d0d]._115de3784ad2((_549e173a8d70, _1be84adfda0a, _eaf6a00189d9, _f37fe68a6767))

        _abea96202389 = _d2d1d82801e9
        _220990b4b253 = {}
        _1ccdbf6aa9b5 = {}

        for _f3d079561d0d in _b4f4bfaf32f3:
            _214c48f4edb8 = _84faa997a354[_f3d079561d0d]
            if _78d8252c7db0(_214c48f4edb8) != _413b872a94d4[_f3d079561d0d]:
                if _b8df537b6310:
                    _43887641ae66(f"Skipping sample {_f3d079561d0d}: expected {_413b872a94d4[_f3d079561d0d]} chunks, got {_78d8252c7db0(_214c48f4edb8)}")
                continue

            _214c48f4edb8._90ba65390651(_5e8e319fbbca=lambda _39748a02495d: _39748a02495d[0])

            if _abea96202389 is _d2d1d82801e9 and _78d8252c7db0(_214c48f4edb8) > 1:
                _abea96202389 = _f3d079561d0d

            # Split into words
            _ebab3d881fe7 = []
            for _549e173a8d70, _9f192e2e4b17, _eed8fa215f84, _40a86e2596b3 in _214c48f4edb8:
                _77642e9a04e4 = self._fb4855bea24d(_9f192e2e4b17, -1)
                _0c08e3a2ab9f = self._fb4855bea24d(_eed8fa215f84, _9a2bb1803831)
                _c0666f4c4613 = self._fb4855bea24d(_40a86e2596b3, _9a2bb1803831)
                _011f88014fa8 = _78d8252c7db0(_77642e9a04e4)
                if _78d8252c7db0(_0c08e3a2ab9f) < _011f88014fa8:
                    _0c08e3a2ab9f += [(_07836851ff79,)] * (_011f88014fa8 - _78d8252c7db0(_0c08e3a2ab9f))
                if _78d8252c7db0(_c0666f4c4613) < _011f88014fa8:
                    _c0666f4c4613 += [(_79f22ef75301,)] * (_011f88014fa8 - _78d8252c7db0(_c0666f4c4613))
                _ebab3d881fe7._115de3784ad2((_77642e9a04e4, _0c08e3a2ab9f, _c0666f4c4613))

            # Vote per word position
            _5824a18d3cc8 = _7196ff7f918b(_1fc29e6309f3)
            _96ebe6fef445 = _7196ff7f918b(_1fc29e6309f3)
            for _77642e9a04e4, _0c08e3a2ab9f, _c0666f4c4613 in _ebab3d881fe7:
                for _8d1a7b990196, _adc7c605efec, _36f170569071 in _a4862bfbff1e(_77642e9a04e4, _0c08e3a2ab9f, _c0666f4c4613):
                    _9f192e2e4b17 = _8d1a7b990196[0]
                    # pred_votes[pos].append(wpred)
                    _b8ebc421de16 = self._b4d24fd393b3(_adc7c605efec)
                    if _b8ebc421de16:
                        _5824a18d3cc8[_9f192e2e4b17]._115de3784ad2(_b8ebc421de16)
                    else:
                        _5824a18d3cc8[_9f192e2e4b17]._115de3784ad2((_07836851ff79,))

                    _96ebe6fef445[_9f192e2e4b17]._115de3784ad2(_36f170569071)

            _c359ef45765f = _4de56f1ba083(_5824a18d3cc8._4d858fb90522())

            _467a591f786a = [self._ca9a536190a9(_5824a18d3cc8[_5d4bc2e289fb], _16cdc53129b1="most_common", _b68cef09928c=(_07836851ff79,)) for _5d4bc2e289fb in _c359ef45765f]
            _1dcda4828b69 = []
            for _5d4bc2e289fb in _c359ef45765f:
                _f2012eb0d2f0 = _96ebe6fef445[_5d4bc2e289fb]
                _d8adbb858e88 = self._ca9a536190a9(_f2012eb0d2f0, _16cdc53129b1="most_common", _b68cef09928c=_d2d1d82801e9)
                if _d8adbb858e88 is _d2d1d82801e9:
                    for _ab067f2fa946 in _f2012eb0d2f0:
                        if _79f22ef75301 not in _ab067f2fa946:
                            _d8adbb858e88 = _ab067f2fa946
                            break
                    if _d8adbb858e88 is _d2d1d82801e9:
                        _d8adbb858e88 = _f2012eb0d2f0[0]
                _1dcda4828b69._115de3784ad2(_d8adbb858e88)

            # Reconstruct
            _368283a98265 = []
            _efd8b1171e37 = []
            for _3f74c2e21537 in _019c57382d1b(_78d8252c7db0(_c359ef45765f)):
                _368283a98265._807147a65c2e(_467a591f786a[_3f74c2e21537])
                _efd8b1171e37._807147a65c2e(_1dcda4828b69[_3f74c2e21537])
                if _3f74c2e21537 < _78d8252c7db0(_c359ef45765f) - 1:
                    _368283a98265._115de3784ad2(_9a2bb1803831)
                    _efd8b1171e37._115de3784ad2(_9a2bb1803831)

            # print(f"check labels final {(sum(1 for x in recon_labels if x == sep_token))}")

            _220990b4b253[_f3d079561d0d] = _810510729dc7._bc4e457e4d34(_368283a98265, _c59b9fb2a946=_cbcfe092824b)
            _1ccdbf6aa9b5[_f3d079561d0d] = _810510729dc7._bc4e457e4d34(_efd8b1171e37, _c59b9fb2a946=_cbcfe092824b)

        if _b8df537b6310 and _abea96202389 is not _d2d1d82801e9:
            _43887641ae66(f"[SUMMARY] reconciled samples in batch = {_78d8252c7db0(_b4f4bfaf32f3)} "
                f"sid={_abea96202389} total_preds={_78d8252c7db0(_220990b4b253[_abea96202389])} "
                f"total_labels={_78d8252c7db0(_1ccdbf6aa9b5[_abea96202389])} "
                f"raw_preds {_220990b4b253[_abea96202389]} and raw_labels {_1ccdbf6aa9b5[_abea96202389]} "
                f"chunks {_84faa997a354[_abea96202389]}")

        _a9f6e50ab8ad = _942d992a5d33(_78d8252c7db0(_29b4a47efcf7) for _29b4a47efcf7 in _1ccdbf6aa9b5._343738e95723())
        _43887641ae66(f"Total reconciled labels: {_a9f6e50ab8ad}")

        _2d4b617e92ed, _5050e3653181 = self._eb2187184583(
            _220990b4b253, _1ccdbf6aa9b5, _b8df537b6310=_b8df537b6310, _cbcfe092824b=_cbcfe092824b
        )
        _3e21f8a829f5 = _942d992a5d33(_78d8252c7db0(_29b4a47efcf7) for _29b4a47efcf7 in _5050e3653181._343738e95723())
        _43887641ae66(f"Total reconciled labels classes: {_3e21f8a829f5}")

        _bad1f9c9b24d = _810510729dc7._d5532b6eeaf5._844b628af9de() if _810510729dc7._d5532b6eeaf5._1d6b16dbc453() else -1
        _43887641ae66(f"Rank {_bad1f9c9b24d} samples are {_b4f4bfaf32f3}")

        return _220990b4b253, _1ccdbf6aa9b5, _2d4b617e92ed, _5050e3653181

    def _0b014ea8b434(self, _220990b4b253, _1ccdbf6aa9b5, _b8df537b6310=_cdc6b872c644, _cbcfe092824b="cpu"):
        _4002611d1d70 = _f5597c2b351b(self, "seq2class", {})
        _9a2bb1803831 = _f5597c2b351b(self, "tokenizer_separator_token", _d2d1d82801e9)
        _79f22ef75301 = _f5597c2b351b(self, "ignore_idx", -100)
        
        def _649e290eef22(_c16ae25130fa, _34a046d76298):
            _7f5dd038a98f = []
            _188fa9f1eec8 = []
            for _3f74c2e21537, token in _d31438f8397b(_c16ae25130fa):
                if token == _34a046d76298 and _188fa9f1eec8:
                    _7f5dd038a98f._115de3784ad2(_188fa9f1eec8)
                    _188fa9f1eec8 = []
                elif token != _34a046d76298:
                    _188fa9f1eec8._115de3784ad2(token)
            if _188fa9f1eec8:
                _7f5dd038a98f._115de3784ad2(_188fa9f1eec8)
            return _7f5dd038a98f
        
        def _2e5a7b207bba(_83f29aacdff5, _4002611d1d70, _b8df537b6310, _f3d079561d0d):
            _f6774db8cefe = []
            _bec3740e6a3c = _4de56f1ba083(_4002611d1d70._4d858fb90522(), _5e8e319fbbca=_78d8252c7db0, _58e1e935d5b7=_cdc6b872c644)
            for _3f74c2e21537, _f34082cc5a5a in _d31438f8397b(_83f29aacdff5, 1):
                _9438a5d56e38 = _e7d3cf2a96cb(_f34082cc5a5a)
                _1e9e876f33ca = self._89e62616d0d9
                for _5e8e319fbbca in _bec3740e6a3c:
                    if _78d8252c7db0(_9438a5d56e38) >= _78d8252c7db0(_5e8e319fbbca) and _9438a5d56e38[:_78d8252c7db0(_5e8e319fbbca)] == _5e8e319fbbca:
                        _1e9e876f33ca = _4002611d1d70[_5e8e319fbbca]
                        break
                _f6774db8cefe._115de3784ad2(_1e9e876f33ca)

            return _f6774db8cefe
        
        _2da6a7906ee7, _a5b5b678d934 = {}, {}
        for _f3d079561d0d in _220990b4b253:
            _5d4bc2e289fb = _220990b4b253[_f3d079561d0d]
            _29b4a47efcf7 = _1ccdbf6aa9b5._03294381a598(_f3d079561d0d, _d2d1d82801e9)
            _78d74f2eb745 = _5d4bc2e289fb._bdf517f1c435() if _4955fe52b6b2(_5d4bc2e289fb, _810510729dc7._0c00e83b221f) else _1fc29e6309f3(_5d4bc2e289fb)
            _ac7db27b05e9 = _29b4a47efcf7._bdf517f1c435() if _4955fe52b6b2(_29b4a47efcf7, _810510729dc7._0c00e83b221f) else _1fc29e6309f3(_29b4a47efcf7) if _29b4a47efcf7 else _d2d1d82801e9
            if _ac7db27b05e9 is not _d2d1d82801e9:
                _efbf5082965c = _87812454d4ea(_ac7db27b05e9, _9a2bb1803831)
                _089da4f68b00 = _c8981e476cc0(_efbf5082965c, _4002611d1d70, _f3d079561d0d == 1 or _b8df537b6310, _f3d079561d0d)
                _e36c5ffd07ca = _87812454d4ea(_78d74f2eb745, _9a2bb1803831)
                _164f848055fd = _c8981e476cc0(_e36c5ffd07ca, _4002611d1d70, _f3d079561d0d == 1 or _b8df537b6310, _f3d079561d0d)
                if _78d8252c7db0(_164f848055fd) < _78d8252c7db0(_089da4f68b00):
                    _164f848055fd += [0] * (_78d8252c7db0(_089da4f68b00) - _78d8252c7db0(_164f848055fd))
                elif _78d8252c7db0(_164f848055fd) > _78d8252c7db0(_089da4f68b00):
                    _164f848055fd = _164f848055fd[:_78d8252c7db0(_089da4f68b00)]
            else:
                _e36c5ffd07ca = _87812454d4ea(_78d74f2eb745, _9a2bb1803831)
                _164f848055fd = _c8981e476cc0(_e36c5ffd07ca, _4002611d1d70, _f3d079561d0d == 1 or _b8df537b6310, _f3d079561d0d)
                _089da4f68b00 = [_79f22ef75301] * _78d8252c7db0(_164f848055fd)
            _2da6a7906ee7[_f3d079561d0d] = _810510729dc7._bc4e457e4d34(_164f848055fd, _c59b9fb2a946=_cbcfe092824b, _cf75de35227b=_810510729dc7._fac41cb50e59)
            _a5b5b678d934[_f3d079561d0d] = _810510729dc7._bc4e457e4d34(_089da4f68b00, _c59b9fb2a946=_cbcfe092824b, _cf75de35227b=_810510729dc7._fac41cb50e59)
        return _2da6a7906ee7, _a5b5b678d934

    def _f3204dd34ae9(self, _ffa96398d5b4):
        _810510729dc7._766e16553e7b._eb98e9e3ba20._d987f5e29df9(self._e2a4bdb3bd86(), _18fdad1521e3=1.0)
    
    def _4777217af34a(self, _ffa96398d5b4):
        for _1c17061ced9f in self._e2a4bdb3bd86():
            if _1c17061ced9f is not _d2d1d82801e9:
                _1c17061ced9f._51a3093dd192._7bf3e013eed7(-5, 5)

    def _af2284d3f130(self):
        _246acafaf608 = 0
        for _1c17061ced9f in self._e2a4bdb3bd86():
            if _1c17061ced9f._911fe7d6ffaa is not _d2d1d82801e9:
                _39bcae38066e = _1c17061ced9f._911fe7d6ffaa._46eb1dcccfd6()._51a3093dd192._b8ebc421de16(2)
                _246acafaf608 += _39bcae38066e._647e261773cf() ** 2
        return _246acafaf608 ** 0.5  # L2 norm

    def _f503830768ec(self):
        _f72f900eb0ec = [_5d4bc2e289fb for _5d4bc2e289fb in self._e2a4bdb3bd86() if _5d4bc2e289fb._9fb81e49d86d]
        if not _f72f900eb0ec:
            _43887641ae66("No trainable parameters. Skipping optimizer creation.")
            return _d2d1d82801e9
        
        _6caba6d5c1e7 = _1fa4eaf3f97e(lambda _5d4bc2e289fb: _5d4bc2e289fb._9fb81e49d86d, self._e2a4bdb3bd86())

        _e22d5555b18b = {
            "adamw": _810510729dc7._1dc96303c4db._d27805c45947,
            "adamax": _810510729dc7._1dc96303c4db._642be06d2e17,
            "adam": _810510729dc7._1dc96303c4db._c0162e41703f,
        }
        _b4112f9fca24 = _e22d5555b18b._03294381a598(self._3ef1f5731fc5._3277753cb1b1(), _810510729dc7._1dc96303c4db._c0162e41703f)

        _ffa96398d5b4 = _b4112f9fca24(_6caba6d5c1e7, _a5abaf5c2f70=self._190d25f7ca73._a5abaf5c2f70, _0c2ecc749699=0.001)

        _dca2b90be7ff = self._2a1c30a06ca5._aed9fa56376e
        _b19d98e3c2b6 = math._5292dc2d2e2c(0.1 * _dca2b90be7ff)

        _b2c013d7fd1b = _810510729dc7._1dc96303c4db._835febbcc56a._51b2e619e979(_ffa96398d5b4, _03a3ccc3fe7d=lambda _4f0acfe7538a: (_4f0acfe7538a + 1) / _b19d98e3c2b6)

        _7172f5b1f9f0 = _810510729dc7._1dc96303c4db._835febbcc56a._bad83861b1db(
            _ffa96398d5b4,
            _96873e7afd45=_87b3f1d1c16d(1, _dca2b90be7ff - _b19d98e3c2b6),
            _b818d0e89e02=2,
            _a6d14164799a=1e-6
        )
        _835febbcc56a = _810510729dc7._1dc96303c4db._835febbcc56a._17c1ef95da84(
            _ffa96398d5b4,
            _51a6372c42c6=[_b2c013d7fd1b, _7172f5b1f9f0],
            _c3369a731aab=[_b19d98e3c2b6]
        )
        return {"optimizer": _ffa96398d5b4, "lr_scheduler": {"scheduler": _835febbcc56a, "interval": "epoch", "monitor": "val_loss"}}
