# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the authora if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, OrderedDict, defaultdict
import copy
from decimal import Decimal
import gc
import json
import math
import os
import sys
import traceback
import numpy as np
import pandas as pd
import torch
import lightning as pl
from transformers.models.llama.modeling_llama import LlamaRMSNorm
import bitsandbytes
from torchmetrics import Accuracy, ConfusionMatrix, Precision, Recall, F1Score
from torch.amp import autocast
from cachetools import LRUCache
from lang_ident_classifier.language.accuracy.class_weighted_accuracy import ClassWeightedAccuracy
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset
from lang_ident_classifier.language.loss.class_weighted_focal_loss_with_adaptive_focus import ClassWeightedFocalLossWithAdaptiveFocus
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
from transformers import AutoModelForSeq2SeqLM
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# Global cache (NOT in model class)
FROZEN_EMBEDDING = None  

# class SafeModuleWrapper(torch.nn.Module):
#     def __init__(self, module, clamp_min=-5, clamp_max=5):
#         super().__init__()
#         self.module = module
#         # self.module = module.to(dtype=torch.float32)  # Convert module to FP32
#         # for param in self.module.parameters():
#         #     param.data = param.data.to(torch.float32)
#         # for buffer in self.module.buffers():
#         #     buffer.data = buffer.data.to(torch.float32)
        
#         self.clamp_min = clamp_min
#         self.clamp_max = clamp_max

#     # def forward(self, *inputs, **kwargs):
#     #     # Ensure all inputs are float32 if they are tensors
#     #     inputs = tuple(inp.float() if isinstance(inp, torch.Tensor) else inp for inp in inputs)
        
#     #     # Logging dtype info
#     #     # param_dtypes = {name: param.dtype for name, param in self.module.named_parameters()}
#     #     # buffer_dtypes = {name: buffer.dtype for name, buffer in self.module.named_buffers()}
#     #     # print(f"[Forward Pass] {self.module.__class__.__name__} running")
#     #     # print(f"  - Parameters Dtype: {param_dtypes if param_dtypes else 'No Parameters'}")
#     #     # print(f"  - Buffers Dtype: {buffer_dtypes if buffer_dtypes else 'No Buffers'}")

#     #     # Forward pass
#     #     output = self.module(*inputs, **kwargs)
        
#     #     # Convert output to FP32 and clamp if necessary
#     #     if isinstance(output, torch.Tensor):
#     #         output = torch.clamp(output.float(), min=self.clamp_min, max=self.clamp_max)
#     #         return torch.nan_to_num(output)
#     #     return output  # If it's not a tensor, return as is

#     def forward(self, *inputs, **kwargs):
#         # # Convert to float32 if needed
#         inputs = tuple(
#             inp.to(torch.float32) if isinstance(inp, torch.Tensor) and inp.dtype != torch.float32 else inp
#             for inp in inputs
#         )
#         # Pre-check inputs
#         for i, inp in enumerate(inputs):
#             if isinstance(inp, torch.Tensor) and not torch.isfinite(inp).all():
#                 inp = torch.nan_to_num(inp)

#         # Run module
#         output = self.module(*inputs, **kwargs)

#         # Post-check output
#         if isinstance(output, torch.Tensor):
#             output = output.to(torch.float32)
#             if not torch.isfinite(output).all():
#                 output = torch.nan_to_num(output)
#             output.clamp_(self.clamp_min, self.clamp_max)
#             return output

#         return output

class SafeModuleWrapper(torch.nn.Module):
    def __init__(self, module, clamp_min=-5, clamp_max=5):
        super().__init__()
        self.module = module
        self.clamp_min = clamp_min
        self.clamp_max = clamp_max
        torch._dynamo.config.suppress_errors = True
        if not isinstance(module, LlamaRMSNorm):
            self.module = torch.compile(self.module, mode="default", backend="cudagraphs")

    # def forward(self, *inputs, **kwargs):
    #     inputs = tuple(
    #         inp.to(torch.float32) if isinstance(inp, torch.Tensor) and inp.dtype != torch.float32 else inp
    #         for inp in inputs
    #     )
    #     for i, inp in enumerate(inputs):
    #         if isinstance(inp, torch.Tensor) and not torch.isfinite(inp).all():
    #             inp = torch.nan_to_num(inp)
    #     output = self.module(*inputs, **kwargs)
    #     if isinstance(output, torch.Tensor):
    #         output = output.to(torch.float32)
    #         if not torch.isfinite(output).all():
    #             output = torch.nan_to_num(output)
    #         output.clamp_(self.clamp_min, self.clamp_max)
    #     return output

    def forward(self, *inputs, **kwargs):
        inputs = tuple(
            inp.to(torch.float32).clamp(-10, 10) if isinstance(inp, torch.Tensor) and inp.dtype != torch.float32 else inp
            for inp in inputs
        )
        for i, inp in enumerate(inputs):
            if isinstance(inp, torch.Tensor) and not torch.isfinite(inp).all():
                inp = torch.nan_to_num(inp)
        output = self.module(*inputs, **kwargs)
        if isinstance(output, torch.Tensor):
            output = output.to(torch.float32)
            if not torch.isfinite(output).all():
                output = torch.nan_to_num(output)
            output.clamp_(self.clamp_min, self.clamp_max)
        return output
    
class GenLLMLanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        pretrained_embedding_model,
        class_names,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_backbone_model_units_unfrozen,
        loss_type,
        is_train,
        tokenizer,
        prompt_length,
        random_seed: int = 20,
        pretrained_model_embedding_name = None,
        trial_number=None,
        decision_threshold=0.9
    ):
        super(GenLLMLanguageIdentificationClassifier, self).__init__()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self.save_hyperparameters({
            "lr": float(lr),
            "optimizer": str(optimizer),
            "num_backbone_model_units_unfrozen": int(num_backbone_model_units_unfrozen),
            "loss_type": str(loss_type),
            "is_train": bool(is_train),
            "random_seed": int(random_seed),
        })
        # print(f"HPARAMS {self.hparams}")
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
        np.random.seed(random_seed)
        self.trial_number = int(trial_number) if trial_number is not None else None
        self.tokenizer = tokenizer
        #TODO: REMOVE THIS HARDCODING
        if not self.tokenizer.pad_token_id:
            self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|> 
        self.tokenizer_separator_token = tokenizer.encode(" ", add_special_tokens=False)[0]
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.pretrained_model_embedding_name = pretrained_model_embedding_name
        self.num_classes = len(class_names)
        self.decision_threshold = decision_threshold
        self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        self.class2seq = {}
        for idx, cname in enumerate(self.class_names):
            # tokenize without special tokens
            seq = self.tokenizer.encode(cname, add_special_tokens=False)
            self.class2seq[idx] = seq
        # inverse map
        self.seq2class = {tuple(seq): cid for cid, seq in self.class2seq.items()}
        self.len2classes = defaultdict(list)   # maps length L -> list of (class_id, seq_ids)
        for cls_id, seq in self.class2seq.items():
            self.len2classes[len(seq)].append((cls_id, seq))
        self.unk_idx = 0
        print(f"SEQ {self.class2seq} and {self.seq2class}")
        self.pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.ignore_idx = -100
        self.pred_filter_tokens = tokenizer.encode("assistant<|end_header_id|>\n\n", add_special_tokens=False)
        self.compute_device_dtype_for_half_precision = self.get_compute_device_dtype_for_half_precision()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self.embedding = pretrained_embedding_model
        self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        if num_backbone_model_units_unfrozen > 0:
            if "llama" in self.pretrained_model_embedding_name:
                for param in self.embedding.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = False  # Freeze all layers initially
                
                # Access the LlamaDecoderLayers directly
                decoder_layers = self.embedding.model.layers  # (LlamaModel -> layers: ModuleList)
                
                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for block in decoder_layers[-num_backbone_model_units_unfrozen:]:
                    for param in block.parameters():
                        if isinstance(param, torch.Tensor) and (param.is_floating_point() or torch.is_complex(param)):
                            param.requires_grad = True

        self.batch_counter = 0
        # self.xth_batch_to_consider = 100
        self.xth_batch_to_consider = 1
        print(f"DEBUG xth_batch init {self.xth_batch_to_consider}")
        # Create learnable prompt embeddings (random init)
        global FROZEN_EMBEDDING 
        FROZEN_EMBEDDING = copy.deepcopy(self.embedding).eval()
        self.lr = lr

        self.prompt_loss = ClassWeightedCrossEntropyLoss(device=self.curr_device, ignore_index=self.ignore_idx)

        # Loss function initialization
        if loss_type.casefold() == "class_weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, 
                                                            device=self.curr_device, 
                                                            ignore_index=self.ignore_idx,
                                                            separator_token=self.tokenizer_separator_token)
        elif loss_type.casefold() == "focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=0.25, 
                                                     device=self.curr_device, 
                                                     ignore_index=self.ignore_idx,
                                                     separator_token=self.tokenizer_separator_token)
        elif loss_type.casefold() == "class_weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, 
                                                     device=self.curr_device, 
                                                     ignore_index=self.ignore_idx,
                                                     separator_token=self.tokenizer_separator_token)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, 
                                                                      gamma_type='type1', 
                                                                      device=self.curr_device,
                                                                      ignore_index=self.ignore_idx,
                                                                      separator_token=self.tokenizer_separator_token)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, 
                                                                      gamma_type='type2', 
                                                                      device=self.curr_device, 
                                                                      ignore_index=self.ignore_idx,
                                                                      separator_token=self.tokenizer_separator_token)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, 
                                                                      gamma_type='type3', 
                                                                      device=self.curr_device, 
                                                                      ignore_index=self.ignore_idx,
                                                                      separator_token=self.tokenizer_separator_token)
        else:
            self._criterion = ClassWeightedCrossEntropyLoss(device=self.curr_device, 
                                                            ignore_index=self.ignore_idx,)
        
        self._accuracy = ClassWeightedAccuracy(
            # device=self.curr_device,
            class_weights=self.class_weights,
            # num_classes=self.num_classes,
            num_classes=self.tokenizer.vocab_size,
            # task=self.classification_task,
            ignore_index=self.ignore_idx,
            average="custom",
        ).to(self.curr_device, non_blocking=True)

        self._micro_accuracy = Accuracy(
            num_classes=len(self.class_names),
            average="micro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._macro_accuracy = Accuracy(
            num_classes=len(self.class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._macro_precision = Precision(
            num_classes=len(self.class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._macro_recall = Recall(
            num_classes=len(self.class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._macro_f1 = F1Score(
            num_classes=len(self.class_names),
            average="macro",
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        # Classwise metrics (per-class values, tensor of shape [num_classes])
        self._classwise_accuracy = Accuracy(
            num_classes=len(self.class_names),
            average=None,   # per-class instead of macro/micro
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._classwise_precision = Precision(
            num_classes=len(self.class_names),
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._classwise_recall = Recall(
            num_classes=len(self.class_names),
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._classwise_f1 = F1Score(
            num_classes=len(self.class_names),
            average=None,
            task=self.classification_task,
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)

        self._confmat = ConfusionMatrix(
            num_classes=len(self.class_names),
            task=self.classification_task,
            normalize=None,  # can also be "true" for row-normalized
            ignore_index=self.ignore_idx,
        ).to(self.curr_device, non_blocking=True)


        self._validation_outputs = []
        self._test_outputs = []
        
        self.optimizer_name = optimizer.casefold()
        self.fix_embedding_layers()

        self.register_nan_hooks(self.embedding)
    
    def setup(self, stage=None):
        """Calculate batch counts and set xth_batch_to_consider."""
        train_dataset_size = 0
        val_dataset_size = 0
        if self.trainer.datamodule is not None:
            if hasattr(self.trainer.datamodule, 'train_dataset') and self.trainer.datamodule.train_dataset is not None:
                train_dataset_size = len(self.trainer.datamodule.train_dataset)  # e.g., 107715
            if hasattr(self.trainer.datamodule, 'val_dataset') and self.trainer.datamodule.val_dataset is not None:
                val_dataset_size = len(self.trainer.datamodule.val_dataset)      # e.g., 20000
            batch_size = self.trainer.datamodule.batch_size                  # e.g., 4
            num_train_batches = (train_dataset_size + batch_size - 1) // batch_size if train_dataset_size > 0 else 1  # e.g., 26929
            num_val_batches = (val_dataset_size + batch_size - 1) // batch_size if val_dataset_size > 0 else 1      # e.g., 5000
            num_batches = min(num_train_batches, num_val_batches) if val_dataset_size > 0 else num_train_batches    # e.g., 5000
            xth_fraction = 0.1  # For 10% of batches
            self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))  # e.g., 500
            print(f"DEBUG Batch Info: num_train_batches={num_train_batches}, num_val_batches={num_val_batches}, xth_batch_to_consider={self.xth_batch_to_consider}")
    
    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            # return torch.nn.PReLU(num_parameters=num_parameters)
            return torch.nn.PReLU(num_parameters=1)
        elif activation_function_for_layer.casefold() == "leaky_relu":
            return torch.nn.LeakyReLU(inplace=False)
        else:
            return torch.nn.ReLU(inplace=False) # in place tensor modifications disabled due to issues in gradient 
        
    def register_nan_hooks(self, module, prefix=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for name, child in module.named_children():
            full_name = f"{prefix}.{name}" if prefix else name  # Keep full layer path

            # Hook function to check for NaNs in forward pass
            def detect_nan_hook(mod, inp, out):
                if isinstance(out, torch.Tensor) and out.isnan().any():
                    print(f"NaN detected in {full_name} ({mod.__class__.__name__}) ({out.dtype})")

            child.register_forward_hook(detect_nan_hook)

            # Recursively apply to children
            self.register_nan_hooks(child, full_name)

    
    def has_trainable_params(self, module):
        return any(p.requires_grad for p in module.parameters())  # Includes submodules
    
    # def fix_embedding_layers(self):
    #     """Convert unstable modules (LayerNorm, RMSNorm, Linear4bit, MLP, activations, attention, projections) 
    #     to float32 and wrap them safely to prevent NaNs."""

    #     updates = []

    #     for name, module in self.named_modules():
    #         if not self.has_trainable_params(module):
    #             continue  # Skip frozen layers

    #         # Anything prone to NaNs
    #         is_unstable = any(k in name.lower() for k in [
    #             "norm", "linear4bit", "mlp", "act", "attention", "proj","gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"
    #         ]) or isinstance(module, torch.nn.LayerNorm)

    #         if is_unstable:
    #             if hasattr(module, "eps"):  
    #                 module.eps = max(getattr(module, "eps", 1e-3), 1e-3)  # Increase eps for RMSNorm stability
    #             module = module.to(torch.float32)  # force fp32
    #             if not isinstance(module, SafeModuleWrapper):
    #                 updates.append((name, SafeModuleWrapper(module)))

    #     # Apply wrapped modules
    #     for name, new_module in updates:
    #         parent_module, attr = self.get_parent_and_attr(name)
    #         if parent_module is not None:
    #             setattr(parent_module, attr, new_module)

    def fix_embedding_layers(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        updates = []
        for name, module in self.named_modules():
            if not self.has_trainable_params(module):
                continue  # Skip frozen layers
            # Identify RMSNorm, Linear4bit, SiLU, attention, and dropout
            is_unstable = (
                "norm" in name.lower() or 
                "linear4bit" in name.lower() or 
                any(act in name.lower() for act in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in name.lower() or 
                "dropout" in name.lower() or 
                isinstance(module, (LlamaRMSNorm, torch.nn.Linear, torch.nn.SiLU))
            )
            if is_unstable:
                if hasattr(module, "eps"):
                    module.eps = 1e-3  # Increase eps for RMSNorm
                module = module.to(torch.float32)  # Force FP32
                if not isinstance(module, SafeModuleWrapper):
                    updates.append((name, SafeModuleWrapper(module, clamp_min=-10, clamp_max=10)))
        for name, new_module in updates:
            parent_module, attr = self.get_parent_and_attr(name)
            if parent_module is not None:
                setattr(parent_module, attr, new_module)
                
    def get_parent_and_attr(self, module_name):
        """Finds the parent module and attribute name given the full module path."""
        parts = module_name.split('.')
        parent = self  # Start from the main model
        for part in parts[:-1]:  # Traverse down but stop at the parent
            parent = getattr(parent, part, None)
            if parent is None:
                return None, None
        return parent, parts[-1]  # Return parent module and final attribute

    def forward(self, input_ids):
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        attention_mask = (input_ids != self.tokenizer.pad_token_id).to(dtype=torch.bool, device=self.curr_device, non_blocking=True)
        # attention_mask = ((input_ids != self.tokenizer.eos_token_id) & (input_ids != 220)).to(dtype=torch.bool, device=self.curr_device, non_blocking=True)
        outputs = self.embedding(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=True,
            return_dict=True,
        )
        # Clamping extreme NaN
        logits = outputs.logits.to(torch.float32).clamp(-20, 20)
        # logits = outputs.logits

        
        # Optional: KL + contrastive loss
        kl_loss = torch.tensor(0.0, device=self.curr_device)
        contrastive_loss = torch.tensor(0.0, device=self.curr_device)
        if (self.trainer.training or self.trainer.validating) and self.batch_counter % self.xth_batch_to_consider == 0:
            frozen_outputs = FROZEN_EMBEDDING(input_ids).logits.detach()
            kl_loss, contrastive_loss = self.compute_kl_contrastive_loss(
                logits, frozen_outputs, device=self.curr_device
            )
        self.batch_counter += 1

        return logits, kl_loss, contrastive_loss

    def register_amp_hooks(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def hook_fn(module, inputs, outputs):
            if any(inp.dtype == torch.float16 for inp in inputs if isinstance(inp, torch.Tensor)):
                print(f"Layer {module.__class__.__name__} is using float16!")

        # Attach hooks to all layers in self.model
        for submodule in self.modules():
            hook = submodule.register_forward_hook(hook_fn)
            self.amp_hooks.append(hook)  # Store hooks to remove them later if needed

    def remove_hooks(self):
        """Remove all registered forward hooks."""
        for hook in getattr(self, "amp_hooks", []):
            hook.remove()
        self.amp_hooks = []

    def align_tokens_to_words(self, input_ids, token_preds, token_labels):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        tokens = [self.tokenizer.convert_ids_to_tokens(ids) for ids in input_ids]
        word_preds, word_labels = [], []
        
        for token_seq, pred_seq, label_seq in zip(tokens, token_preds, token_labels):
            for token, pred, label in zip(token_seq, pred_seq, label_seq):
                if token == self.tokenizer.pad_token or label == self.ignore_idx:
                    continue  # Skip padding & ignored labels

                # Detect subword tokens (model-specific handling)
                is_subword = (
                    token.startswith("##") or  # BERT/RoBERTa (WordPiece)
                    token.startswith("▁") or   # IndicBERT/mT5 (SentencePiece)
                    token in ["<unk>", "<pad>"]  # Generic unknown/padding tokens
                )

                if is_subword:
                    continue  # Ignore subword parts, keep only first part's label
                
                # Store the first subword’s label as word-level
                word_preds.append(pred.item())
                word_labels.append(label.item())

        return torch.tensor(word_preds), torch.tensor(word_labels)

    # def compute_kl_contrastive_loss(self, new_emb_cpu, old_emb_cpu, device="cuda"):
    #     """Computes KL divergence and contrastive loss efficiently with minimal GPU usage."""
        
    #     # Ensure tensors are detached and moved to CPU for lightweight loss computation
    #     new_emb_cpu = new_emb_cpu.clamp(min=-30, max=30)
    #     old_emb_cpu = old_emb_cpu.clamp(min=-30, max=30)
    #     T = 2.0 # Temperature fixed in Hinto et al 2015 set at 2 or 3 most cases works
    #     # Compute KL divergence using more stable log-softmax
    #     new_emb_log = torch.nn.functional.log_softmax(new_emb_cpu/T, dim=-1)
    #     old_emb_prob = torch.nn.functional.softmax(old_emb_cpu/T, dim=-1)
    #     latent_dim = new_emb_log.shape[-1]  # Safe for [batch, dim]
    #     kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean")* (T * T) / latent_dim

    #     # Compute cosine similarity for contrastive loss No scaling on temp for constractive since cosine is scale invariant
    #     embedding_drift = torch.nn.functional.cosine_similarity(new_emb_cpu, old_emb_cpu, dim=-1).mean()
    #     contrastive_loss = 1 - embedding_drift

    #     # Free CPU memory after computation
    #     del new_emb_cpu, old_emb_cpu
    #     if torch.cuda.is_available():
    #         torch.cuda.empty_cache()  # Ensure GPU stays clean

    #     # Move results back to GPU if necessary
    #     return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)

    def get_compute_device_dtype_for_half_precision(self):
        supported_dtype = torch.float32
        if torch.cuda.is_available():
            major, minor = torch.cuda.get_device_capability()
            # Ampere (8.0+) supports bfloat16
            if major >= 8:
                supported_dtype = torch.bfloat16
            else:
                supported_dtype = torch.float16
        return supported_dtype

    def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
        batch_size = new_emb.size(0)
        chunk_size = max(1, batch_size // 8)
        kl_losses = []
        contrastive_losses = []
        T = 2.0
        for i in range(0, batch_size, chunk_size):
            new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
            old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
            new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
            old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
            kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
            embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
            contrastive_loss = 1 - embedding_drift
            kl_losses.append(kl_loss)
            contrastive_losses.append(contrastive_loss)
            del new_chunk, old_chunk, new_emb_log, old_emb_prob
        kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
        contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
        return kl_loss, contrastive_loss

    # def training_step(self, batch, batch_idx):
    #     """Optimized training step with reduced memory footprint and improved stability."""

    #     # input_ids, labels = batch
    #     input_ids = batch["input_ids"]
    #     labels = batch["labels"]
    #     batch_size = input_ids.size(0)

    #     # Ensure data is on the correct device
    #     input_ids = input_ids.to(self.curr_device, non_blocking=True)
    #     labels = labels.to(self.curr_device, non_blocking=True)

    #     # Forward pass
    #     outputs, kl_loss, contrastive_loss = self(input_ids)

    #     # Shift prediction/ ground truth to align with Generative LLM functionality
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()

    #     # Flatten outputs and labels for loss computation
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)
    #     # Compute classification loss
    #     loss = self._criterion(logits_flat, labels_flat)

    #     # Ensure KL and contrastive loss values are finite
    #     # Replace NaNs while preserving autograd graph
    #     kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
    #     contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
    #     loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)

    #     # Combine losses with scaling factors
    #     epoch = float(self.trainer.current_epoch)
    #     lambda_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
    #     lambda_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
    #     # Apply Decimal to enforce exact precision
    #     lambda_kl = float(f"{lambda_kl:.2f}")  # Ensures 0.20
    #     lambda_contrast = float(f"{lambda_contrast:.2f}")  # Ensures 0.50
    #     combined_loss = loss + lambda_kl * kl_loss + lambda_contrast * contrastive_loss

    #     # Check for NaN loss and log issue
    #     if torch.isnan(loss):
    #         print(f"Step {batch_idx}: NaN loss detected!")

    #     # Store training metrics
    #     train_metrics = {
    #         "epoch": float(self.current_epoch),
    #         "train_kl_loss": kl_loss.detach(),
    #         "train_contrastive_loss": contrastive_loss.detach(),
    #         "train_classification_loss": loss.detach(),
    #         "train_loss": combined_loss.detach(),
    #         "train_lambda_kl": lambda_kl,
    #         "train_lambda_contrast": lambda_contrast,
    #     }

    #     # Log metrics without unnecessary sync overhead
    #     self.log_dict(
    #         train_metrics,
    #         batch_size=batch_size,
    #         on_step=False,
    #         on_epoch=True,
    #         prog_bar=False,
    #         logger=True,
    #         sync_dist=True,  # Sync across GPUs in distributed training
    #     )

    #     # Explicitly delete tensors to free memory
    #     del input_ids, labels, outputs
    #     # del predicted_labels
    #     del kl_loss, loss, contrastive_loss
    #     del shift_labels, shift_logits, labels_flat, logits_flat

    #     return combined_loss

    def training_step(self, batch, batch_idx):
        """Optimized training step with reduced memory footprint and improved stability."""
        input_ids = batch["input_ids"]
        labels = batch["labels"]
        prompt_lens = batch["prompt_lens"]
        batch_size = input_ids.size(0)
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        labels = labels.to(self.curr_device, non_blocking=True)
        outputs, kl_loss, contrastive_loss = self(input_ids)

        # Mask using prompt_lens, overwrite labels only
        # labels = labels.clone()  # Ensure no in-place modification
        # for i, pl in enumerate(prompt_lens):
        #     if pl < labels.size(1):
        #         labels[i, :pl] = -100  # Mask prompt tokens for loss
        
        # Shift and flatten prompt
        shift_logits = outputs[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()
        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)
        # reducing logits_flat to make faster computation
        classification_loss = self._criterion(logits_flat, labels_flat)
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        classification_loss = torch.where(torch.isnan(classification_loss), torch.zeros_like(classification_loss), classification_loss)
        epoch = float(self.trainer.current_epoch)
        # lambda_kl = round(min(0.2 + epoch * 0.4, 1.0), 2)  # Cap at 1.0, 2 decimal precision
        # lambda_contrast = round(max(0.5 - epoch * 0.05, 0.1), 2)  # Floor at 0.1, 2 decimal precision
        # lambda_classification = round(max(3.0 - epoch * 0.1, 1.5), 2)  # Start at 3.0, floor at 1.5, 2 decimal precision
        lambda_kl = 0.1
        lambda_contrast = 0.1
        lambda_classification = 0.8
        combined_loss = (
            (lambda_classification * classification_loss) +
            (lambda_kl * kl_loss) +
            (lambda_contrast * contrastive_loss)
        )
        if torch.isnan(classification_loss):
            print(f"Step {batch_idx}: NaN loss detected!")
        train_metrics = {
            "epoch": epoch,
            "train_kl_loss": kl_loss.detach(),
            "train_contrastive_loss": contrastive_loss.detach(),
            "train_classification_loss": classification_loss.detach(),
            "train_loss": combined_loss.detach(),
            "train_lambda_classification": lambda_classification,
            "train_lambda_kl": lambda_kl,
            "train_lambda_contrast": lambda_contrast,
        }
        self.log_dict(
            train_metrics,
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )
        del input_ids, labels, outputs, kl_loss, classification_loss, contrastive_loss, shift_labels, shift_logits, labels_flat, logits_flat
        return combined_loss
    
    def on_train_epoch_end(self):
        # Clear up gpu memory after epoch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()
        return super().on_train_epoch_end()

    def validation_step(self, batch, batch_idx):
        input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
        labels         = batch["labels"].to(self.curr_device, non_blocking=True)
        lang_codes     = batch["lang_codes"]
        sample_ids     = batch["sample_ids"]
        chunk_ids      = batch["chunk_ids"]
        word_positions = batch["word_positions"]
        prompt_lens = batch["prompt_lens"]
        batch_num_chunks = batch["num_chunks"]

        batch_size = input_ids.size(0)

        # Forward
        outputs, kl_loss, contrastive_loss = self(input_ids)

        # Mask using prompt_lens, overwrite labels only
        # labels = labels.clone()  # Ensure no in-place modification
        # for i, pl in enumerate(prompt_lens):
        #     if pl < labels.size(1):
        #         labels[i, :pl] = -100  # Mask prompt tokens for loss

        # Shift
        shift_logits = outputs[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()
        # shift_logits = outputs.contiguous()
        # shift_labels = labels.contiguous()

        # Loss
        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)
        if batch_idx == 0:
            print(f"VAL TEST BATCH {batch_idx} Input IDs: {input_ids.tolist()[0]}, Predictions: {torch.argmax(shift_logits, dim=-1).tolist()[0]}, Labels: {shift_labels.tolist()[0]}")
        classification_loss = self._criterion(logits_flat, labels_flat)

        # NaN guards
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        classification_loss = torch.where(torch.isnan(classification_loss), torch.zeros_like(classification_loss), classification_loss)

        # Combine losses
        epoch = float(self.trainer.current_epoch)
        # lambda_kl = round(min(0.2 + epoch * 0.4, 1.0), 2)  # Cap at 1.0, 2 decimal precision
        # lambda_contrast = round(max(0.5 - epoch * 0.05, 0.1), 2)  # Floor at 0.1, 2 decimal precision
        # lambda_classification = round(max(3.0 - epoch * 0.1, 1.5), 2)  # Start at 3.0, floor at 1.5, 2 decimal precision
        lambda_kl = 0.1
        lambda_contrast = 0.1
        lambda_classification = 0.8

        combined_loss = (
            (lambda_classification * classification_loss) +
            (lambda_kl * kl_loss) +
            (lambda_contrast * contrastive_loss)
        )

        # Log
        self.log_dict(
            {
                "val_kl_loss": kl_loss.detach(),
                "val_contrastive_loss": contrastive_loss.detach(),
                "val_classification_loss": classification_loss.detach(),
                "val_loss": combined_loss.detach(),
                "val_lambda_classification": lambda_classification,
                "val_lambda_kl": lambda_kl,
                "val_lambda_contrast": lambda_contrast,
            },
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        preds_list = []
        labels_list = []

        for i in range(batch_size):
            logit = outputs[i]       # (seq_len, vocab)
            label = labels[i]       # (seq_len,)

            valid_pred = torch.argmax(logit, dim=-1)  # (valid_len,)
            valid_label = label                       # (valid_len,)

            preds_list.append(valid_pred)
            labels_list.append(valid_label)

        output = {
            "lang_codes": lang_codes,
            "preds": preds_list,
            "labels": labels_list,
            "sample_ids": sample_ids,
            "chunk_ids": chunk_ids,
            "word_positions": word_positions,
            "val_loss": combined_loss,
            "prompt_lens": prompt_lens,
            "num_chunks": batch_num_chunks,
        }
        self._validation_outputs.append(output)

        # Cleanup
        del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
        del kl_loss, contrastive_loss, classification_loss, preds_list, labels_list

        return output


    def _save_metrics_to_csv(self, metrics_dict, filename, trial_number=None):
        """Helper to save metrics to CSV in per-trial directory."""
        # Figure out project dir (Lightning usually has self.logger.log_dir)
        project_dir = os.getcwd()
        trial_id = f"trial_{trial_number}" if trial_number is not None else "default"
        print(f"[DEBUG rank={torch.distributed.get_rank() if torch.distributed.is_initialized() else 0}] metrics_dict confusion_matrix sum={sum(sum(row) for row in metrics_dict['confusion_matrix'][0])}")
        save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        os.makedirs(save_dir, exist_ok=True)

        filepath = os.path.join(save_dir, filename)
        df = pd.DataFrame(metrics_dict)
        df.to_csv(filepath, index=False)
        print(f"[metrics] Saved {filepath}")

    def on_validation_epoch_end(self):
        outputs = getattr(self, "_validation_outputs", None)
        if not outputs:
            return
        
        preds_by_sid, labels_by_sid, preds_classes_by_sid, labels_classes_by_sid = \
            self.reconcile_chunks(outputs)

        all_preds, all_labels = [], []
        for sid in sorted(preds_classes_by_sid.keys()):
            p_raw = preds_by_sid[sid].tolist()        # already a list
            l_raw = labels_by_sid[sid].tolist()       # already a list
            p_seq = preds_classes_by_sid[sid]         # tensor
            l_seq = labels_classes_by_sid[sid]        # tensor

            if p_seq.numel() > 0 and l_seq.numel() > 0:
                all_preds.append(p_seq)
                all_labels.append(l_seq)

        if not all_preds:
            print("[VAL END] Nothing to score.")
            self._validation_outputs.clear()
            return

        preds = torch.cat(all_preds).to(device=self._micro_accuracy.device, non_blocking=True)
        labels = torch.cat(all_labels).to(device=self._micro_accuracy.device, non_blocking=True)

        self._micro_accuracy.update(preds, labels)
        self._macro_accuracy.update(preds, labels)
        self._macro_precision.update(preds, labels)
        self._macro_recall.update(preds, labels)
        self._macro_f1.update(preds, labels)
        self._classwise_accuracy.update(preds, labels)
        self._classwise_precision.update(preds, labels)
        self._classwise_recall.update(preds, labels)
        self._classwise_f1.update(preds, labels)
        self._confmat.update(preds, labels)

        final_micro_accuracy  = self._micro_accuracy.compute().item()
        final_macro_accuracy  = self._macro_accuracy.compute().item()
        final_macro_precision = self._macro_precision.compute().item()
        final_macro_recall    = self._macro_recall.compute().item()
        final_macro_f1        = self._macro_f1.compute().item()

        self.log("val_accuracy", final_macro_accuracy, sync_dist=True)

        try:
            epoch_idx = self.current_epoch
            metrics_dict = {
                "epoch": [epoch_idx],
                "class_names": [self.class_names],
                "micro_accuracy": [final_micro_accuracy],
                "macro_accuracy": [final_macro_accuracy],
                "macro_precision": [final_macro_precision],
                "macro_recall": [final_macro_recall],
                "macro_f1": [final_macro_f1],
                "classwise_accuracy": [self._classwise_accuracy.compute().to(device="cpu").numpy().tolist()],
                "classwise_precision": [self._classwise_precision.compute().to(device="cpu").numpy().tolist()],
                "classwise_recall": [self._classwise_recall.compute().to(device="cpu").numpy().tolist()],
                "classwise_f1": [self._classwise_f1.compute().to(device="cpu").numpy().tolist()],
                "confusion_matrix": [self._confmat.compute().to(device="cpu").numpy().tolist()],
            }
            self._save_metrics_to_csv(metrics_dict, f"val_epoch_{epoch_idx}.csv", trial_number=self.trial_number)
        except Exception as e:
            print(f"[VAL END] save metrics FAILED: {e}")

        # cleanup
        self._micro_accuracy.reset(); self._macro_accuracy.reset()
        self._macro_precision.reset(); self._macro_recall.reset(); self._macro_f1.reset()
        self._classwise_accuracy.reset(); self._classwise_precision.reset()
        self._classwise_recall.reset(); self._classwise_f1.reset()
        self._confmat.reset(); self._validation_outputs.clear()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        print("[VAL END] Finished and cleaned up.")


    # def test_step(self, batch, batch_idx):
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch["lang_codes"]
    #     sample_ids     = batch["sample_ids"]
    #     chunk_ids      = batch["chunk_ids"]
    #     word_positions = batch["word_positions"]
    #     prompt_lens = batch["prompt_lens"]
    #     batch_num_chunks = batch["num_chunks"]

    #     batch_size = input_ids.size(0)

    #     # Forward
    #     outputs, _, _ = self(input_ids)

    #     # Mask using prompt_lens, overwrite labels only
    #     # labels = labels.clone()  # Ensure no in-place modification
    #     # for i, pl in enumerate(prompt_lens):
    #     #     if pl < labels.size(1):
    #     #         labels[i, :pl] = -100  # Mask prompt tokens for loss

    #     # Shift
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()

    #     # Flatten Logits and Truth
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     preds_list = []
    #     labels_list = []

    #     for i in range(batch_size):
    #         logit = outputs[i]       # (seq_len, vocab)
    #         label = labels[i]       # (seq_len,)

    #         valid_pred = torch.argmax(logit, dim=-1)  # (valid_len,)
    #         valid_label = label                      # (valid_len,)

    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }
    #     self._test_outputs.append(output)

    #     # Cleanup
    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del preds_list, labels_list

    #     return output

    def test_step(self, batch, batch_idx):
        # Set left padding for test generation
        self.tokenizer.padding_side = 'left'
        
        input_ids = batch["input_ids"].to(self.curr_device, non_blocking=True)
        labels = batch["labels"].to(self.curr_device, non_blocking=True)
        lang_codes = batch["lang_codes"]
        sample_ids = batch["sample_ids"]
        chunk_ids = batch["chunk_ids"]
        word_positions = batch["word_positions"]
        prompt_lens = batch["prompt_lens"]
        batch_num_chunks = batch["num_chunks"]
        batch_size = input_ids.size(0)
        max_seq_len = input_ids.size(1)
        
        # Batch generation
        generated_ids = self.embedding.generate(
            input_ids=input_ids,
            max_new_tokens=max_seq_len,
            do_sample=False,
            temperature=0.0,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
            return_dict_in_generate=True
        ).sequences
        
        # Reset to right padding
        self.tokenizer.padding_side = 'right'
        
        # Simulate logits for argmax
        outputs = torch.nn.functional.one_hot(generated_ids, num_classes=self.embedding.config.vocab_size).float()
        
        # Shift
        shift_logits = outputs[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()
        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)
        
        preds_list = []
        labels_list = []
        for i in range(batch_size):
            logit = outputs[i]
            label = labels[i]
            valid_pred = torch.argmax(logit, dim=-1)
            valid_label = label
            preds_list.append(valid_pred)
            labels_list.append(valid_label)
        
        output = {
            "lang_codes": lang_codes,
            "preds": preds_list,
            "labels": labels_list,
            "sample_ids": sample_ids,
            "chunk_ids": chunk_ids,
            "word_positions": word_positions,
            "prompt_lens": prompt_lens,
            "num_chunks": batch_num_chunks,
        }
        self._test_outputs.append(output)
        
        # Cleanup
        del input_ids, labels, generated_ids, outputs, logits_flat, labels_flat, shift_logits, shift_labels
        del preds_list, labels_list
        return output


    def on_test_epoch_end(self):
        outputs = getattr(self, "_test_outputs", None)
        print(f"[DEBUG rank={torch.distributed.get_rank()}] outputs_len={len(outputs)}")
        if not outputs:
            return

        preds_by_sid, labels_by_sid, preds_classes_by_sid, labels_classes_by_sid = \
            self.reconcile_chunks(outputs)

        all_preds, all_labels = [], []
        for sid in sorted(preds_classes_by_sid.keys()):
            p_raw = preds_by_sid[sid].tolist()        # already a list
            l_raw = labels_by_sid[sid].tolist()       # already a list
            p_seq = preds_classes_by_sid[sid]         # tensor
            l_seq = labels_classes_by_sid[sid]       # tensor

            if p_seq.numel() > 0 and l_seq.numel() > 0:
                all_preds.append(p_seq)
                all_labels.append(l_seq)

        if not all_preds:
            print("[TEST END] Nothing to score.")
            self._validation_outputs.clear()
            return

        preds = torch.cat(all_preds).to(device=self._micro_accuracy.device, non_blocking=True)
        labels = torch.cat(all_labels).to(device=self._micro_accuracy.device, non_blocking=True)

        self._micro_accuracy.update(preds, labels)
        self._macro_accuracy.update(preds, labels)
        self._macro_precision.update(preds, labels)
        self._macro_recall.update(preds, labels)
        self._macro_f1.update(preds, labels)
        self._classwise_accuracy.update(preds, labels)
        self._classwise_precision.update(preds, labels)
        self._classwise_recall.update(preds, labels)
        self._classwise_f1.update(preds, labels)
        self._confmat.update(preds, labels)

        final_micro_accuracy  = self._micro_accuracy.compute().item()
        final_macro_accuracy  = self._macro_accuracy.compute().item()
        final_macro_precision = self._macro_precision.compute().item()
        final_macro_recall    = self._macro_recall.compute().item()
        final_macro_f1        = self._macro_f1.compute().item()

        self.log("test_accuracy", final_macro_accuracy, sync_dist=True)

        try:
            epoch_idx = self.current_epoch
            metrics_dict = {
                "epoch": [epoch_idx],
                "class_names": [self.class_names],
                "micro_accuracy": [final_micro_accuracy],
                "macro_accuracy": [final_macro_accuracy],
                "macro_precision": [final_macro_precision],
                "macro_recall": [final_macro_recall],
                "macro_f1": [final_macro_f1],
                "classwise_accuracy": [self._classwise_accuracy.compute().to(device="cpu").numpy().tolist()],
                "classwise_precision": [self._classwise_precision.compute().to(device="cpu").numpy().tolist()],
                "classwise_recall": [self._classwise_recall.compute().to(device="cpu").numpy().tolist()],
                "classwise_f1": [self._classwise_f1.compute().to(device="cpu").numpy().tolist()],
                "confusion_matrix": [self._confmat.compute().to(device="cpu").numpy().tolist()],
            }
            self._save_metrics_to_csv(metrics_dict, f"test_final.csv", trial_number=self.trial_number)
        except Exception as e:
            print(f"[TEST END] save metrics FAILED: {e}")

        # cleanup
        self._micro_accuracy.reset(); self._macro_accuracy.reset()
        self._macro_precision.reset(); self._macro_recall.reset(); self._macro_f1.reset()
        self._classwise_accuracy.reset(); self._classwise_precision.reset()
        self._classwise_recall.reset(); self._classwise_f1.reset()
        self._confmat.reset(); self._validation_outputs.clear()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        print("[TEST END] Finished and cleaned up.")


    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        """Optimized prediction step with efficient memory handling."""

        input_ids, _ = batch  # Labels are not needed

        # Move tensors to device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)

        # Forward pass (without computing KL or contrastive loss)
        outputs, _, _ = self(input_ids)
        predicted_labels = torch.argmax(outputs, dim=-1)

        # Explicitly delete tensors to free memory
        del input_ids, outputs
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free GPU memory

        return {"predictions": predicted_labels.cpu()}


    def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
        from collections import defaultdict, Counter
        import torch
        ignore_index = self.ignore_idx  # self.ignore_idx
        def to_list(x):
            if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
            return list(x) if isinstance(x, (list, tuple)) else [x]
        
        seen_chunks = set()
        preds_by_sid, labels_by_sid, final_sids = {}, {}, []
        if verbose:
            print(f"[reconcile] start: num_outputs={len(outputs)}")
        

        print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
        # --- iterate over all sample_ids across all ranks ---
        for out in outputs:
            sample_ids     = out["sample_ids"]
            chunk_ids      = out["chunk_ids"]
            chunk_preds    = out["preds"]
            chunk_labels   = out["labels"]
            word_positions = out["word_positions"]
            prompt_lens = out["prompt_lens"]
            num_chunks = out["num_chunks"]

            for i, sid in enumerate(sample_ids):
                cid = int(chunk_ids[i])

                if (sid, cid) in seen_chunks:
                    continue  # already processed this chunk from another rank
                seen_chunks.add((sid, cid))

                prompt_len_i = int(prompt_lens[i])
                positions_i = to_list(word_positions[i])
                sep_tokens = self.pred_filter_tokens
                preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
                labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
                # accumulate into sample-level storage
                if sid not in final_sids:
                    final_sids.append(sid)

                if 'chunks_by_sid' not in locals():
                    chunks_by_sid = defaultdict(list)
                chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
        sample_debug_id = None
        rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
        # --- reconcile per sample ---
        print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
        for sid in final_sids:
            chunks = chunks_by_sid[sid]
            print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
            if sample_debug_id is None and len(chunks) > 1:
                sample_debug_id = sid
            chunks.sort(key=lambda x: x[0])  # sort by chunk_id
            word_to_token_preds = defaultdict(list)
            word_to_sep_preds = defaultdict(list)
            word_to_token_labels = defaultdict(list)
            word_to_sep_labels = defaultdict(list)
            for cid, positions, preds, labels in chunks:
                chunk_word_preds = {}
                chunk_word_labels = {}
                current_word = None
                current_preds = []
                current_labels = []
                for posi, pre, lab in zip(positions, preds, labels):
                    ipos = int(posi)
                    if ipos >= 0:
                        if ipos != current_word:
                            if current_word is not None:
                                chunk_word_preds[current_word] = current_preds[:]
                                chunk_word_labels[current_word] = current_labels[:]
                            current_word = ipos
                            current_preds = [int(pre)]
                            current_labels = [int(lab)]
                        else:
                            current_preds.append(int(pre))
                            current_labels.append(int(lab))
                    else:  # -1, separator
                        if current_word is not None:
                            word_to_sep_preds[current_word].append(int(pre))
                            word_to_sep_labels[current_word].append(int(lab))
                if current_word is not None:
                    chunk_word_preds[current_word] = current_preds[:]
                    chunk_word_labels[current_word] = current_labels[:]
                for w, toks in chunk_word_preds.items():
                    word_to_token_preds[w].append(toks)
                    word_to_token_labels[w].append(chunk_word_labels[w])
            # reconcile
            if not word_to_token_preds:
                continue
            max_w = max(word_to_token_preds.keys())
            preds_final = []
            labels_final = []
            # With:
            unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
            for w in sorted(word_to_token_preds.keys()):
                token_lists_p = word_to_token_preds[w]
                token_lists_l = word_to_token_labels[w]
                sub_len = len(token_lists_l[0])  # Use labels as source of truth
                word_preds = []
                for sub_i in range(sub_len):
                    col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
                    while len(col) < len(token_lists_l):
                        col.append(unk_id)
                    voted = Counter(col).most_common(1)[0][0]
                    word_preds.append(voted)
                preds_final.extend(word_preds[:sub_len])
                word_labels = []
                for sub_i in range(sub_len):
                    col = [tl[sub_i] for tl in token_lists_l]
                    voted = Counter(col).most_common(1)[0][0]
                    word_labels.append(voted)
                labels_final.extend(word_labels)
                if w < max_w:
                    sep_col_p = word_to_sep_preds[w]
                    if sep_col_p:
                        sep_p = Counter(sep_col_p).most_common(1)[0][0]
                        preds_final.append(sep_p)
                    sep_col_l = word_to_sep_labels[w]
                    if sep_col_l:
                        sep_l = Counter(sep_col_l).most_common(1)[0][0]
                        labels_final.append(sep_l)
                    else:
                        labels_final.append(self.tokenizer_separator_token)
                        preds_final.append(self.tokenizer_separator_token)
            
            # With:
            unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)  # From seq2class where value is [3200] for class 0
            label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
            pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
            if pred_words < label_words:
                for _ in range(pred_words, label_words):
                    if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
                        preds_final.append(self.tokenizer_separator_token)
                    preds_final.append(unk_id)
            elif pred_words > label_words:
                new_preds = []
                word_count = 0
                for i, p in enumerate(preds_final):
                    if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
                        word_count += 1
                    if word_count <= label_words:
                        new_preds.append(p)
                    elif p == self.tokenizer_separator_token and word_count == label_words:
                        new_preds.append(p)
                        break
                preds_final = new_preds

            preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
            labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)


        # DEBUG
        if verbose and sample_debug_id:
            print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
                  sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
                    raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
                        chunks {chunks_by_sid[sample_debug_id]}")
        
        preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
        if verbose and sample_debug_id:
            print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
        return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def overlay_classes(self, preds_by_sid, labels_by_sid, verbose=True, target_device="cpu"):
        seq2class = getattr(self, "seq2class", {})
        sep_token = getattr(self, "tokenizer_separator_token", None)
        ignore_index = getattr(self, "ignore_idx", -100)
        
        def split_by_separator(tokens, sep):
            words = []
            current_word = []
            for i, token in enumerate(tokens):
                if token == sep and current_word:
                    words.append(current_word)
                    current_word = []
                elif token != sep:
                    current_word.append(token)
            if current_word:  # Ensure last word is included
                words.append(current_word)
            return words
        
        def overlay_words(word_list, seq2class, verbose, sid):
            out = []
            sorted_keys = sorted(seq2class.keys(), key=len, reverse=True)
            for i, word in enumerate(word_list, 1):
                word_tuple = tuple(word)
                class_id = self.unk_idx  # Default to 0 for unmatched
                for key in sorted_keys:
                    if len(word_tuple) >= len(key) and word_tuple[:len(key)] == key:
                        class_id = seq2class[key]
                        break
                out.append(class_id)

            return out
        
        preds_classes_by_sid, labels_classes_by_sid = {}, {}
        for sid in preds_by_sid:
            p = preds_by_sid[sid]
            l = labels_by_sid.get(sid, None)
            preds = p.tolist() if isinstance(p, torch.Tensor) else list(p)
            labels = l.tolist() if isinstance(l, torch.Tensor) else list(l) if l else None
            # print(f"[DEBUG sid={sid} input] preds_len={len(preds)}, labels_len={len(labels) if labels else 'None'}, labels={labels if labels else 'None'}")
            if labels is not None:
                label_words = split_by_separator(labels, sep_token)
                labels_classes = overlay_words(label_words, seq2class, sid == 1 or verbose, sid)
                preds_words = split_by_separator(preds, sep_token)
                preds_classes = overlay_words(preds_words, seq2class, sid == 1 or verbose, sid)
                if len(preds_classes) < len(labels_classes):
                    preds_classes += [0] * (len(labels_classes) - len(preds_classes))
                elif len(preds_classes) > len(labels_classes):
                    preds_classes = preds_classes[:len(labels_classes)]
            else:
                preds_words = split_by_separator(preds, sep_token)
                preds_classes = overlay_words(preds_words, seq2class, sid == 1 or verbose, sid)
                labels_classes = [ignore_index] * len(preds_classes)
            # print(f"[DEBUG sid={sid} final] preds_classes={preds_classes}, labels_classes={labels_classes}")
            preds_classes_by_sid[sid] = torch.tensor(preds_classes, device=target_device, dtype=torch.long)
            labels_classes_by_sid[sid] = torch.tensor(labels_classes, device=target_device, dtype=torch.long)
        return preds_classes_by_sid, labels_classes_by_sid

    def on_before_optimizer_step(self, optimizer):
        torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)
    
    def on_after_optimizer_step(self, optimizer):
        for param in self.parameters():
            if param is not None:
                param.data.clamp_(-5, 5)

    def _compute_grad_norm(self):
        total_norm = 0
        for param in self.parameters():
            if param.grad is not None:
                param_norm = param.grad.detach().data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5  # L2 norm

    def configure_optimizers(self):
        """Configures optimizer and learning rate scheduler."""
        trainable_params = [p for p in self.parameters() if p.requires_grad]
        if not trainable_params:
            print("No trainable parameters. Skipping optimizer creation.")
            return None  # or [] depending on version
        
        # Filter trainable parameters
        model_parameters = filter(lambda p: p.requires_grad, self.parameters())

        # Select optimizer
        optimizers = {
            "adamw": torch.optim.AdamW,
            "adamax": torch.optim.Adamax,
            "adam": torch.optim.Adam,
        }
        optimizer_class = optimizers.get(self.optimizer_name.lower(), torch.optim.Adam)  # Default to Adam

        optimizer = optimizer_class(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Uncomment if using bitsandbytes optimizers
        # if self.optimizer_name == "adamw":
        #     optimizer = bitsandbytes.optim.AdamW(model_parameters, lr=self.hparams.lr, weight_decay=0.001)
        # elif self.optimizer_name == "adam":
        #     optimizer = bitsandbytes.optim.Adam(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Learning rate scheduler
        # lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        #     optimizer, mode="min", factor=0.1, patience=3, cooldown=3, min_lr=1e-8, verbose=True
        # )
        # lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=2, eta_min=1e-6)
    

        # Warmup: 10% of total epochs, rounded up
        total_epochs = self.trainer.max_epochs
        warmup_epochs = math.ceil(0.1 * total_epochs)

        # Warmup LR schedule: linear increase
        warmup_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda epoch: (epoch + 1) / warmup_epochs)

        # CosineAnnealingWarmRestarts after warmup
        cosine_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer,
            T_0=max(1, total_epochs - warmup_epochs),
            T_mult=2,
            eta_min=1e-6
        )

        # Combine both in a SequentialLR
        lr_scheduler = torch.optim.lr_scheduler.SequentialLR(
            optimizer,
            schedulers=[warmup_scheduler, cosine_scheduler],
            milestones=[warmup_epochs]
        )
        # Debugging/logging (if needed)
        # print(f"Using optimizer: {self.optimizer_name}")
        # print(f"Initial learning rate: {self.hparams.lr}")
        # print(f"Weight decay: 0.001")
        
        return {"optimizer": optimizer, "lr_scheduler": {"scheduler": lr_scheduler, "interval": "epoch", "monitor": "val_loss"}}
