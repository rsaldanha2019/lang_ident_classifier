# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from _30b498e81767 import _3859e5934dd4, _9ae885a9674a
import _1b99df885095
from _154519f94cb7 import _ab961ceea953
import _c61fe3213320
import _ee703a0a843e
import _040871b10acb
from _fd98a02132cc import _0a0c408b1ef1
import _e08acbc94865 as _8a2fbcbadbdb
import _fef5b7bc4b93 as _546eee7dd996
import _18ce74297369
import _a1c77d997c54 as _29dfdfd0cb22
from _948137823220 import _012b65daf548, _10f60b654077
from _948137823220._ffe3a1e9b255._e4367de9ff89._2ccb98b6d36d import _fbe7d79e151e
from _32007c2ae325 import _f0d2c563dc80, _8f5338a5b846, _ae9807e97d20, _842b0a2e1063, _e82f19d9cd22

from _cbca80f57a5f._37f317b3fb1c._63a08c4051c2._855c738baabf import _ba2118d89092
from _cbca80f57a5f._37f317b3fb1c._ed33f230908d._3663a9c912e5 import _f43b3104550b
from _cbca80f57a5f._37f317b3fb1c._ed33f230908d._e80038d2d4fc import _2b3f1e31a3d2
from _cbca80f57a5f._37f317b3fb1c._ed33f230908d._5aa1fd49fd58 import _8d585e453faf
from _cbca80f57a5f._37f317b3fb1c._d6a7e73f98f2._174febec9bd1 import _334ab870c677
# expose only the classifier from the module
_be4221a26900 = ["GenLLMLanguageIdentificationClassifier"]

_88e4ee4bf5d2 = 'cuda' if _18ce74297369._fb7f3cc5b839._b2aa76a80269() else 'cpu'
_b5534f141417 = _4fa295680821  # global frozen embedding (kept for compatibility)


class _3ac0fd394b3b(_012b65daf548):
    def _826098fd844f(self, _7c961a8914ff, _ceec7d2f2056=_4fa295680821, _c8bed4259035=_4fa295680821):
        self._960c1d2af216 = _e470473f1113(_7c961a8914ff)
        self._c890b963cebe = _ceec7d2f2056
        self._7bf115dcc8ff = _c8bed4259035

    def _041202d07d5e(self, _5f5f9e7fa83a, _d8ca76572029):
        _f01936aa9685 = _18ce74297369._92f468d9a7d7(_d8ca76572029, _5c9600642633("-inf"))

        for _d85068d30d0c in self._960c1d2af216:
            _f01936aa9685[:, _d85068d30d0c] = 0.0

        if self._c890b963cebe is not _4fa295680821:
            _f01936aa9685[:, self._c890b963cebe] = 0.0

        if self._7bf115dcc8ff is not _4fa295680821:
            _f01936aa9685[:, self._7bf115dcc8ff] = 0.0

        return _d8ca76572029 + _f01936aa9685
    
class _10cdb5e7f294(_29dfdfd0cb22._52f1d1e2c147):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """
    _a74d07f604ca = {}

    class _ea6e17011bb2(_18ce74297369._951d1ac253a3._af39a4f77f7e):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _826098fd844f(self, _e36ec35acba5: _4c835be6dcaa, _b8b934d4372f: _4c835be6dcaa = 64):
            _87d343b43d4b()._3a4668621ca0()
            self._f47539e2633f = _18ce74297369._951d1ac253a3._d3960b066a91(_e36ec35acba5, _b8b934d4372f, _d909228fe8c7=_ef4c66fa8dbf)
            self._e2c772a4ce97 = _18ce74297369._951d1ac253a3._0b1b5bd5f1b3(_0d111da1f2da=_fcad1e1d9bc5)
            self._d30810b095ba = _18ce74297369._951d1ac253a3._d3960b066a91(_b8b934d4372f, _e36ec35acba5, _d909228fe8c7=_ef4c66fa8dbf)
            # start adapter near-zero so initial behavior is identity
            _18ce74297369._951d1ac253a3._cb79e4703670._bc5445aa02b4(self._d30810b095ba._0c4ec9b11074)
            _18ce74297369._951d1ac253a3._cb79e4703670._38c76c604b51(self._f47539e2633f._0c4ec9b11074, _3d0a4c4749c1=_ee703a0a843e._9da75297c142(5))

        def _5669aca034c1(self, _5fab92a624e3: _18ce74297369._3a0eddc10aea) -> _18ce74297369._3a0eddc10aea:
            # supports x shape (B, L, D) or (B, D)
            if _5fab92a624e3._e36ec35acba5() == 2:
                _9b17cbf4b7aa = self._d30810b095ba(self._e2c772a4ce97(self._f47539e2633f(_5fab92a624e3)))
                return _5fab92a624e3 + _9b17cbf4b7aa
            _3f7303870282, _6d5a6deaeb22, _60f006f41355 = _5fab92a624e3._d780d4cd5a74
            _653e59c34354 = _5fab92a624e3._9e5921e8f0cc(-1, _60f006f41355)                    # (B*L, D)
            _653e59c34354 = self._d30810b095ba(self._e2c772a4ce97(self._f47539e2633f(_653e59c34354)))  # (B*L, D)
            _653e59c34354 = _653e59c34354._9e5921e8f0cc(_3f7303870282, _6d5a6deaeb22, _60f006f41355)
            return _5fab92a624e3 + _653e59c34354


    class _e2d6fe76796c(_18ce74297369._951d1ac253a3._af39a4f77f7e):
        def _826098fd844f(self, _e36ec35acba5: _4c835be6dcaa, _09fc3c535a4e: _18ce74297369._951d1ac253a3._af39a4f77f7e, _b8b934d4372f: _4c835be6dcaa = 64):
            _87d343b43d4b()._3a4668621ca0()
            self._f47539e2633f = _18ce74297369._951d1ac253a3._d3960b066a91(_e36ec35acba5, _b8b934d4372f, _d909228fe8c7=_ef4c66fa8dbf)
            self._e2c772a4ce97 = _18ce74297369._951d1ac253a3._0b1b5bd5f1b3(_0d111da1f2da=_fcad1e1d9bc5)
            self._d30810b095ba = _18ce74297369._951d1ac253a3._d3960b066a91(_b8b934d4372f, _e36ec35acba5, _d909228fe8c7=_ef4c66fa8dbf)
            self._09fc3c535a4e = _09fc3c535a4e

            _18ce74297369._951d1ac253a3._cb79e4703670._bc5445aa02b4(self._d30810b095ba._0c4ec9b11074)
            _18ce74297369._951d1ac253a3._cb79e4703670._38c76c604b51(self._f47539e2633f._0c4ec9b11074, _3d0a4c4749c1=_ee703a0a843e._9da75297c142(5))

        def _25f02a653c46(self, _959a8ed09a3c):
            if _959a8ed09a3c._e36ec35acba5() == 3:
                _3f7303870282, _6d5a6deaeb22, _60f006f41355 = _959a8ed09a3c._d780d4cd5a74
                _653e59c34354 = _959a8ed09a3c._9e5921e8f0cc(-1, _60f006f41355)
                _653e59c34354 = _653e59c34354 + self._d30810b095ba(self._e2c772a4ce97(self._f47539e2633f(_653e59c34354)))
                return _653e59c34354._9e5921e8f0cc(_3f7303870282, _6d5a6deaeb22, _60f006f41355)
            return _959a8ed09a3c + self._d30810b095ba(self._e2c772a4ce97(self._f47539e2633f(_959a8ed09a3c)))

        def _5669aca034c1(self, _959a8ed09a3c):
            _959a8ed09a3c = self._9c3c18ec716f(_959a8ed09a3c)
            return self._09fc3c535a4e(_959a8ed09a3c)

    class _da932aee84e5(_18ce74297369._951d1ac253a3._af39a4f77f7e):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _826098fd844f(self, _4a9b6bfbedb1, _756eca44cd5e=-5, _f36efcdfee85=5):
            _87d343b43d4b()._3a4668621ca0()
            self._4a9b6bfbedb1 = _4a9b6bfbedb1
            self._756eca44cd5e = _756eca44cd5e
            self._f36efcdfee85 = _f36efcdfee85
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _5669aca034c1(self, *_46a30b35cf16, **_98d338c49373):
            _46a30b35cf16 = _bdc17ddb981e(
                _56368cdba0d7._dbbde872cae8(_18ce74297369._2d05bf1dcd13)._f717bbdf09b9(-10, 10) if _039628450a64(_56368cdba0d7, _18ce74297369._3a0eddc10aea) and _56368cdba0d7._4b779a0fad4b != _18ce74297369._2d05bf1dcd13 else _56368cdba0d7
                for _56368cdba0d7 in _46a30b35cf16
            )
            for _24512c575754, _56368cdba0d7 in _808d5ec65a8a(_46a30b35cf16):
                if _039628450a64(_56368cdba0d7, _18ce74297369._3a0eddc10aea) and not _18ce74297369._e9b9b327a23b(_56368cdba0d7)._439b13f19019():
                    _56368cdba0d7 = _18ce74297369._80f694e68359(_56368cdba0d7)
            _4d3c203d86c5 = self._4a9b6bfbedb1(*_46a30b35cf16, **_98d338c49373)
            if _039628450a64(_4d3c203d86c5, _18ce74297369._3a0eddc10aea):
                _4d3c203d86c5 = _4d3c203d86c5._dbbde872cae8(_18ce74297369._2d05bf1dcd13)
                if not _18ce74297369._e9b9b327a23b(_4d3c203d86c5)._439b13f19019():
                    _4d3c203d86c5 = _18ce74297369._80f694e68359(_4d3c203d86c5)
                _4d3c203d86c5._1094e3b31c96(self._756eca44cd5e, self._f36efcdfee85)
            return _4d3c203d86c5

    # --- original __init__ signature and body preserved ---
    def _826098fd844f(
        self,
        _89d39c2901b2,
        _a85116ed3c1c,
        _deaa03a51113,
        _038c791a92e4,
        _d069dcf6326a,
        _5c87bd833d4b,
        _9dc134d09e4e,
        _653f63e1decd,
        _619f5961ba4c,
        _59ed64029177,
        _8294d95126a6,
        _fc383406454b: _4c835be6dcaa = 20,
        _e157d6b3d12a = _4fa295680821,
        _fa913b5acd26=_4fa295680821,
        _90f56146f35f=0.9,
        _d20ee0cb57db:_c242ed4cb1cd=_4fa295680821,
    ):
        _87d343b43d4b(_74d4c4ccedbe, self)._3a4668621ca0()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._6997e6978478({
            "lr": _5c9600642633(_deaa03a51113),
            "optimizer": _c242ed4cb1cd(_038c791a92e4),
            "num_backbone_model_units_unfrozen": _4c835be6dcaa(_9dc134d09e4e),
            "loss_type": _c242ed4cb1cd(_653f63e1decd),
            "is_train": _2a960f1c4de5(_619f5961ba4c),
            "random_seed": _4c835be6dcaa(_fc383406454b),
        })
        self._fc383406454b = _fc383406454b
        _29dfdfd0cb22._fc7f9847ee22(_fc383406454b, _137c05b9c078=_fcad1e1d9bc5)
        _18ce74297369._652a94d64dad(_fc383406454b)
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            _18ce74297369._fb7f3cc5b839._f10deab93203(_fc383406454b)
        _8a2fbcbadbdb._804a12aaacd2._16d4de64ff0a(_fc383406454b)
        self._0360bad0fd69 = 0.2
        self._fa913b5acd26 = _4c835be6dcaa(_fa913b5acd26) if _fa913b5acd26 is not _4fa295680821 else _4fa295680821
        _59ed64029177._adf151c2452b = "left"
        self._59ed64029177 = _59ed64029177
        self._d20ee0cb57db = _d20ee0cb57db
        self._d2770e52ae18 = 0.2 # for preventing model shift dominance
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
        #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
        #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
        #     print(f"Added padding token  <PAD> with (id: {tid})")
        if not self._59ed64029177._5b4ae9b6d2cd:
            self._59ed64029177._aa30a93913a2(["_P"], _883f3a705b78=_ef4c66fa8dbf)
            _d85068d30d0c = self._59ed64029177._047b19ee964f("_P")
            self._59ed64029177._5b4ae9b6d2cd = _d85068d30d0c
            _8e00933065b7(f"Added padding token  _P with (id: {_d85068d30d0c})")
        
        # self.tokenizer_separator_token = tokenizer.encode(" ", add_special_tokens=False)[0]
        self._1409bcf2953c = _59ed64029177._1d4aee789707("||", _0ca4692381ff=_ef4c66fa8dbf)[0]
        self._4b7a48d6b477 = (
            _18ce74297369._8078911a0ffb("cuda:{}"._f8d834c03d89(_5c87bd833d4b["gpu_local_rank"]))
            if _5c87bd833d4b["gpu_local_rank"] != -1
            else "cpu"
        )
        self._e157d6b3d12a = _e157d6b3d12a
        self._90f56146f35f = _90f56146f35f
        self._a85116ed3c1c =  ["unk"] + _a85116ed3c1c if self._90f56146f35f > 0 else _a85116ed3c1c
        self._8c516e0bc3c1 = _c36d9bb81aeb(self._a85116ed3c1c)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._15ba210377ae = {}
        # FOR NEW TOKEN COMMENT THIS
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        
        # FOR NEW TOKEN UNCOMMENT THIS
        # Add only if class name splits into >1 token
        # for cname in self.class_names:
        #     if len(self.tokenizer.encode(cname, add_special_tokens=False)) > 1:
        #         token = f"{cname}"
        #         if token not in self.tokenizer.get_vocab():
        #             self.tokenizer.add_tokens([token], special_tokens=False)
        #             tid = self.tokenizer.convert_tokens_to_ids(token)
        #             print(f"Added class '{cname}' Token: {token} (id: {tid})")

        # Map every class to single token ID
        for _472156885599 in self._a85116ed3c1c:
            if _472156885599 not in _74d4c4ccedbe._a74d07f604ca:
                _613c9e53d5a4 = _59ed64029177._1d4aee789707(_472156885599, _0ca4692381ff=_ef4c66fa8dbf)
                if _c36d9bb81aeb(_613c9e53d5a4) > 1:
                    _74d4c4ccedbe._a74d07f604ca[_472156885599] = f"{_c36d9bb81aeb(_74d4c4ccedbe._a74d07f604ca)}"
                else:
                    _74d4c4ccedbe._a74d07f604ca[_472156885599] = _472156885599
        
        self._15ba210377ae = {
            _04499eb884ac: [self._59ed64029177._047b19ee964f(_74d4c4ccedbe._a74d07f604ca._66dede16100f(_472156885599))]
            for _04499eb884ac, _472156885599 in _808d5ec65a8a(self._a85116ed3c1c)
        }

        self._4d7a84cd828f = _10f60b654077([
            _19c16b8ce88d(
                _7c961a8914ff=[
                    _d85068d30d0c
                    for _df5278c13fb3 in self._15ba210377ae._c49f63c8df0c()
                    for _d85068d30d0c in _df5278c13fb3
                ],
                _ceec7d2f2056=self._1409bcf2953c,
                _c8bed4259035=self._59ed64029177._c8bed4259035
            )
        ])
        # self.class2seq = {
        #     idx: [self.tokenizer.convert_tokens_to_ids(f"{cname}")]
        #     for idx, cname in enumerate(self.class_names)
        # }

        self._7cb2ec1d5d14 = {_bdc17ddb981e(_df5278c13fb3): _02a63893203b for _02a63893203b, _df5278c13fb3 in self._15ba210377ae._e5acc0bc36b4()}
        self._738b13014eb0 = _9ae885a9674a(_e603872a5b35)
        for _a724d5c97dd2, _df5278c13fb3 in self._15ba210377ae._e5acc0bc36b4():
            self._738b13014eb0[_c36d9bb81aeb(_df5278c13fb3)]._1a511bab9629((_a724d5c97dd2, _df5278c13fb3))
        self._40e7de653ea5 = 0
        _8e00933065b7(f"SEQ {self._15ba210377ae} and {self._7cb2ec1d5d14}")
        self._06d588efc5ff = _59ed64029177._5b4ae9b6d2cd or _59ed64029177._c8bed4259035
        self._d069dcf6326a = _d069dcf6326a
        self._eeca24a73212 = "multiclass"
        self._4ec41e2281f8 = -100
        self._5587e664dba0 = _59ed64029177._1d4aee789707("assistant<|end_header_id|>\n\n", _0ca4692381ff=_ef4c66fa8dbf)
        self._4a3a5a589750 = self._90366750faca()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._f9a2802f383b = _89d39c2901b2
        # Resize vocab based token embeddings
        self._f9a2802f383b._b5622d378afe(_c36d9bb81aeb(self._59ed64029177))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._f9a2802f383b._9f08a6ac85a7(_ef4c66fa8dbf)
        _016fc9e6fec7 = _334ab870c677()  # bfloat16 or float16

        for _ac6c124ce9ba, _4a9b6bfbedb1 in self._5ecf264e8134():
            if not _c170677907c0(_56b257b60858._5c0dbc0caa93 for _56b257b60858 in _4a9b6bfbedb1._9facccfab45c(_cb957179004b=_ef4c66fa8dbf)):
                # FROZEN → BF16 (save memory)
                _4a9b6bfbedb1._dbbde872cae8(_4b779a0fad4b=_016fc9e6fec7)
            else:
                # TRAINABLE → FP32 (stable grads)
                _4a9b6bfbedb1._dbbde872cae8(_4b779a0fad4b=_18ce74297369._2d05bf1dcd13)
        self._f9a2802f383b._dbbde872cae8(self._4b7a48d6b477)
        if _d6b2cd8d46d0(self._f9a2802f383b, "gradient_checkpointing_enable"):
            self._f9a2802f383b._662ec409484d()
        # determine embedding dim robustly from model config if available
        _81fa0aa666de = _05d91581264c(_05d91581264c(self._f9a2802f383b, "config", _4fa295680821), "hidden_size", _4fa295680821)
        if _81fa0aa666de is _4fa295680821:
            # fallback to common default — change if your model uses a different hidden size
            _81fa0aa666de = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        # if hasattr(self.embedding, "lm_head") and getattr(self.embedding, "lm_head") is not None:
        #     self._lm_head = self.embedding.lm_head
        # else:
        #     get_out = getattr(self.embedding, "get_output_embeddings", None)
        #     self._lm_head = get_out() if callable(get_out) else None

        # # mark presence and ensure module (if any) is on the same device
        # self._has_lm_head = self._lm_head is not None
        # if self._has_lm_head:
        #     # move lm_head params/buffers to the model device (safe no-op if already there)
        #     self._lm_head.to(self.curr_device)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        # self.adapter = self._Adapter(dim=embedding_dim, bottleneck=64)
        # self.adapter.to(self.curr_device)
        # for p in self.adapter.parameters():
        #     p.requires_grad = True
        _09fc3c535a4e = (
            self._f9a2802f383b._09fc3c535a4e
            if _d6b2cd8d46d0(self._f9a2802f383b, "lm_head")
            else self._f9a2802f383b._85e35b1a2bfd()
        )

        self._f9a2802f383b._09fc3c535a4e = self._bddb5efb163c(
            _e36ec35acba5=_81fa0aa666de,
            _09fc3c535a4e=_09fc3c535a4e,
            _b8b934d4372f=64,
        )._dbbde872cae8(self._4b7a48d6b477)

        # self.adapter = self.embedding.lm_head

        if _9dc134d09e4e > 0:
            # if "llama" in self.pretrained_model_embedding_name:
            if self._e157d6b3d12a:
                for _c6e471b78b1a in self._f9a2802f383b._9facccfab45c():
                    if not _c6e471b78b1a._4fff259b7d8e:
                        _c6e471b78b1a = _c6e471b78b1a._e96e40d5974a()
                    _c6e471b78b1a._5c0dbc0caa93 = _ef4c66fa8dbf  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _34014104c93c = self._f9a2802f383b._e8b1e23d61de._85e1b42e9621  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _4142a8aa98fd in _34014104c93c[-_9dc134d09e4e:]:
                    for _c6e471b78b1a in _4142a8aa98fd._9facccfab45c():
                        if _039628450a64(_c6e471b78b1a, _18ce74297369._3a0eddc10aea) and (_c6e471b78b1a._322c3d29295e() or _18ce74297369._9bdfefd9fd4b(_c6e471b78b1a)):
                            _c6e471b78b1a._5c0dbc0caa93 = _fcad1e1d9bc5
                for _c6e471b78b1a in self._f9a2802f383b._09fc3c535a4e._9facccfab45c():
                    _c6e471b78b1a._5c0dbc0caa93 = _fcad1e1d9bc5

        self._0b96ed3c70f9 = 1
        _8e00933065b7(f"DEBUG xth_batch init {self._0b96ed3c70f9}")
        global _b5534f141417
        _b5534f141417 = _1b99df885095._ccf612c26ace(self._f9a2802f383b)._4c422b72072a()
        self._deaa03a51113 = _deaa03a51113

        self._892ce5e2edf7 = {}
        self._0388e0664aaa = {}

        # Loss function initialization
        if _653f63e1decd._219286780e29() == "class_weighted_cross_entropy_loss":
            self._0388e0664aaa['criterion'] = _2b3f1e31a3d2(_d069dcf6326a=self._d069dcf6326a,
                                                            _8078911a0ffb=self._4b7a48d6b477,
                                                            _e8c793919898=self._4ec41e2281f8,
                                                            _33b12eb0e96e=self._1409bcf2953c)
        elif _653f63e1decd._219286780e29() == "focal_loss":
            self._0388e0664aaa['criterion'] = _8d585e453faf(_46b5ed127751=0.25,
                                                     _8078911a0ffb=self._4b7a48d6b477,
                                                     _e8c793919898=self._4ec41e2281f8,
                                                     _33b12eb0e96e=self._1409bcf2953c)
        elif _653f63e1decd._219286780e29() == "class_weighted_focal_loss":
            self._0388e0664aaa['criterion'] = _8d585e453faf(_46b5ed127751=self._d069dcf6326a,
                                                     _8078911a0ffb=self._4b7a48d6b477,
                                                     _e8c793919898=self._4ec41e2281f8,
                                                     _33b12eb0e96e=self._1409bcf2953c)
        elif _653f63e1decd._219286780e29() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._0388e0664aaa['criterion'] = _f43b3104550b(_46b5ed127751=self._d069dcf6326a,
                                                                      _60ff2c5da1da='type1',
                                                                      _8078911a0ffb=self._4b7a48d6b477,
                                                                      _e8c793919898=self._4ec41e2281f8,
                                                                      _33b12eb0e96e=self._1409bcf2953c)
        elif _653f63e1decd._219286780e29() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._0388e0664aaa['criterion'] = _f43b3104550b(_46b5ed127751=self._d069dcf6326a,
                                                                      _60ff2c5da1da='type2',
                                                                      _8078911a0ffb=self._4b7a48d6b477,
                                                                      _e8c793919898=self._4ec41e2281f8,
                                                                      _33b12eb0e96e=self._1409bcf2953c)
        elif _653f63e1decd._219286780e29() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._0388e0664aaa['criterion'] = _f43b3104550b(_46b5ed127751=self._d069dcf6326a,
                                                                      _60ff2c5da1da='type3',
                                                                      _8078911a0ffb=self._4b7a48d6b477,
                                                                      _e8c793919898=self._4ec41e2281f8,
                                                                      _33b12eb0e96e=self._1409bcf2953c)
        else:
            self._0388e0664aaa['criterion'] = _2b3f1e31a3d2(_8078911a0ffb=self._4b7a48d6b477,
                                                            _e8c793919898=self._4ec41e2281f8,)
        
        self._60b31219c429 = 0.99
        self._30335eaeec02 = 0.3
        self._86be457f25a8 = 0.30
        self._b97f66e2e142 = 0.25
        self._f11c0857623d = 0.6
        self._28a542e3cead = 0.995
        self._12fca749fb12 = 0.60
        self._49aac0d67d2f = 0.20
        self._8ced193d28be = _05d91581264c(self, "batch_counter", 0)


        self._60dc9c3486a9 = []
        self._dae422a0ec75 = []

        self._3ce2560f60d8 = _038c791a92e4._219286780e29()
        self._5b972020d0e6()

        self._ffbc4a0505d1(self._f9a2802f383b)
    
    def _bccd735ebb7d(self):
        # rebuild all metrics on the correct device
        self._892ce5e2edf7['micro_accuracy'] = _f0d2c563dc80(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5="micro",
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['macro_accuracy'] = _f0d2c563dc80(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5="macro",
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['macro_precision'] = _ae9807e97d20(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5="macro",
            _05e9dcafd78e=self. _eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['macro_recall'] = _842b0a2e1063(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5="macro",
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['macro_f1'] = _e82f19d9cd22(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5="macro",
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['classwise_accuracy'] = _f0d2c563dc80(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5=_4fa295680821,
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['classwise_precision'] = _ae9807e97d20(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5=_4fa295680821,
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['classwise_recall'] = _842b0a2e1063(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5=_4fa295680821,
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['classwise_f1'] = _e82f19d9cd22(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _20fcae8df6e5=_4fa295680821,
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)

        self._892ce5e2edf7['confmat'] = _8f5338a5b846(
            _8c516e0bc3c1=_c36d9bb81aeb(self._a85116ed3c1c),
            _05e9dcafd78e=self._eeca24a73212,
            _e8c793919898=self._4ec41e2281f8,
        )._dbbde872cae8(self._4b7a48d6b477)


    def _453da190ec82(self, _43e5cc93bf8a=_4fa295680821):
        """Calculate batch counts and set xth_batch_to_consider."""
        _efca684d948d = 0
        _43252302a214 = 0
        if self._7a56d685d9d1._f154dcc47de1 is not _4fa295680821:
            if _d6b2cd8d46d0(self._7a56d685d9d1._f154dcc47de1, 'train_dataset') and self._7a56d685d9d1._f154dcc47de1._39634be4107e is not _4fa295680821:
                _efca684d948d = _c36d9bb81aeb(self._7a56d685d9d1._f154dcc47de1._39634be4107e)
            if _d6b2cd8d46d0(self._7a56d685d9d1._f154dcc47de1, 'val_dataset') and self._7a56d685d9d1._f154dcc47de1._820b442de6fd is not _4fa295680821:
                _43252302a214 = _c36d9bb81aeb(self._7a56d685d9d1._f154dcc47de1._820b442de6fd)
            _4a64e91f1095 = self._7a56d685d9d1._f154dcc47de1._4a64e91f1095
            _08d868e37495 = (_efca684d948d + _4a64e91f1095 - 1) // _4a64e91f1095 if _efca684d948d > 0 else 1
            _7e89e99cd173 = (_43252302a214 + _4a64e91f1095 - 1) // _4a64e91f1095 if _43252302a214 > 0 else 1
            _199578af9d8d = _a7135a2fa768(_08d868e37495, _7e89e99cd173) if _43252302a214 > 0 else _08d868e37495
            _4b2f7d26ac27 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._0b96ed3c70f9 = 1
            _8e00933065b7(f"DEBUG Batch Info: num_train_batches={_08d868e37495}, num_val_batches={_7e89e99cd173}, xth_batch_to_consider={self._0b96ed3c70f9}")

    def _6d1165ba9a9b(self, _bed688d4f778, _6ea60b96069f):
        if _bed688d4f778._219286780e29() == "parametric_relu":
            return _18ce74297369._951d1ac253a3._deb1f813178a(_6ea60b96069f=1)
        elif _bed688d4f778._219286780e29() == "leaky_relu":
            return _18ce74297369._951d1ac253a3._0fe9b54698df(_0d111da1f2da=_ef4c66fa8dbf)
        else:
            return _18ce74297369._951d1ac253a3._0b1b5bd5f1b3(_0d111da1f2da=_ef4c66fa8dbf)
    
    def _f3acbfc33ea6(self, _4a9b6bfbedb1, _ab6f05cd9923=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _ac6c124ce9ba, _a12540590b0e in _4a9b6bfbedb1._c10df4517dbd():
            _7f6229c46973 = f"{_ab6f05cd9923}.{_ac6c124ce9ba}" if _ab6f05cd9923 else _ac6c124ce9ba

            def _c2c9cb321680(_77457b5b8abf, _56368cdba0d7, _9b17cbf4b7aa):
                if _039628450a64(_9b17cbf4b7aa, _18ce74297369._3a0eddc10aea) and _9b17cbf4b7aa._6a8b00e77538()._c170677907c0():
                    _8e00933065b7(f"NaN detected in {_7f6229c46973} ({_77457b5b8abf._0b78d28ab774.__name__}) ({_9b17cbf4b7aa._4b779a0fad4b})")

            _a12540590b0e._696e95ce6f37(_d304fad7f9eb)

            self._ffbc4a0505d1(_a12540590b0e, _7f6229c46973)

    def _6430e3a76be3(self, _4a9b6bfbedb1):
        return _c170677907c0(_56b257b60858._5c0dbc0caa93 for _56b257b60858 in _4a9b6bfbedb1._9facccfab45c())

    def _9e49822e6a86(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _076c8f266d8c = []
        for _ac6c124ce9ba, _4a9b6bfbedb1 in self._5ecf264e8134():
            if not self._2dc68dbb424a(_4a9b6bfbedb1):
                continue
            _7ed262dacbfd = (
                "norm" in _ac6c124ce9ba._c82772026d30() or 
                "linear4bit" in _ac6c124ce9ba._c82772026d30() or 
                _c170677907c0(_e2c772a4ce97 in _ac6c124ce9ba._c82772026d30() for _e2c772a4ce97 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _ac6c124ce9ba._c82772026d30() or 
                "dropout" in _ac6c124ce9ba._c82772026d30() or 
                _039628450a64(_4a9b6bfbedb1, (_fbe7d79e151e, _18ce74297369._951d1ac253a3._d3960b066a91, _18ce74297369._951d1ac253a3._2aea2b9f5592))
            )
            if _7ed262dacbfd:
                if _d6b2cd8d46d0(_4a9b6bfbedb1, "eps"):
                    _4a9b6bfbedb1._91b27b316e75 = 1e-3
                _4a9b6bfbedb1 = _4a9b6bfbedb1._dbbde872cae8(_18ce74297369._2d05bf1dcd13)
                if not _039628450a64(_4a9b6bfbedb1, _74d4c4ccedbe._453fc373763c):
                    _076c8f266d8c._1a511bab9629((_ac6c124ce9ba, _74d4c4ccedbe._453fc373763c(_4a9b6bfbedb1, _756eca44cd5e=-10, _f36efcdfee85=10)))
        for _ac6c124ce9ba, _ef9f310be441 in _076c8f266d8c:
            _330a07a90c1c, _0349f4e7c43f = self._5eafed64eac4(_ac6c124ce9ba)
            if _330a07a90c1c is not _4fa295680821:
                _099376da442f(_330a07a90c1c, _0349f4e7c43f, _ef9f310be441)

    def _c00cd56a68cc(self, _f5c681c3d722):
        """Finds the parent module and attribute name given the full module path."""
        _e1bc8d6121b5 = _f5c681c3d722._fb7577894b84('.')
        _31d46f532fe0 = self
        for _de66058010b2 in _e1bc8d6121b5[:-1]:
            _31d46f532fe0 = _05d91581264c(_31d46f532fe0, _de66058010b2, _4fa295680821)
            if _31d46f532fe0 is _4fa295680821:
                return _4fa295680821, _4fa295680821
        return _31d46f532fe0, _e1bc8d6121b5[-1]

    def _fceab797f936(self, _697b67cde581: _18ce74297369._3a0eddc10aea, _9300cc5e9d5f: _18ce74297369._3a0eddc10aea, _6c93be26d5f2: _18ce74297369._3a0eddc10aea) -> _5af0dd8c3e0d:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _8078911a0ffb = _697b67cde581._8078911a0ffb

        # 1) gating w (use cached per-example teacher_conf if available)
        _d88c3774b778 = _05d91581264c(self, "_last_teacher_conf", _4fa295680821)
        if _d88c3774b778 is _4fa295680821:
            # no teacher info => w = 0 (no distillation)
            _e1b313ee314b = 0.0
        else:
            _9cc5fd272e0f = (_d88c3774b778 >= _5c9600642633(_05d91581264c(self, "teacher_conf_tau", 0.6)))._5c9600642633()
            _e1b313ee314b = _5c9600642633(_9cc5fd272e0f._2e148f12e862()._e7c40d05734a()._01e989591fe1()) if _9cc5fd272e0f._50502a2a274d() > 0 else 0.0

        # apply gating to the batch scalars
        _628bad22b9fd = _9300cc5e9d5f * _5c9600642633(_e1b313ee314b)
        _cc8ae867b943 = _6c93be26d5f2 * _5c9600642633(_e1b313ee314b)

        # 2) EMAs for autoscaling
        _4a62e0ea1f82 = _5c9600642633((_628bad22b9fd + _cc8ae867b943)._e96e40d5974a()._e7c40d05734a()._01e989591fe1())
        _b5f904ff3820 = _5c9600642633(_697b67cde581._e96e40d5974a()._e7c40d05734a()._01e989591fe1())
        if _05d91581264c(self, "ema_task", _4fa295680821) is _4fa295680821:
            self._0171e48d6e4e = _b5f904ff3820
            self._92c8c445f7e8 = _4a62e0ea1f82 + 1e-12
        else:
            _46b5ed127751 = _5c9600642633(_05d91581264c(self, "ema_alpha", 0.99))
            self._0171e48d6e4e = _46b5ed127751 * _5c9600642633(self._0171e48d6e4e) + (1.0 - _46b5ed127751) * _b5f904ff3820
            self._92c8c445f7e8  = _46b5ed127751 * _5c9600642633(self._92c8c445f7e8)  + (1.0 - _46b5ed127751) * _4a62e0ea1f82

        _9d855ac77d43 = _5c9600642633(_05d91581264c(self, "distill_target_ratio", 0.3))
        _0e71e1d7a2a1 = (_5c9600642633(self._0171e48d6e4e) / (_5c9600642633(self._92c8c445f7e8) + 1e-12)) * _9d855ac77d43
        _adfcaf619733 = _5c9600642633(_0e71e1d7a2a1)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _672e6a7f7951 = _5c9600642633(_05d91581264c(self._7a56d685d9d1, "current_epoch", _05d91581264c(self._7a56d685d9d1, "global_step", 0.0)))
        _db3506872463 = _5c9600642633(_c1d544a1f915(1, _05d91581264c(self._7a56d685d9d1, "max_epochs", 1)))
        _3bb0d9cacf63 = _a7135a2fa768(_c1d544a1f915(_672e6a7f7951 / _db3506872463, 0.0), 1.0)
        _7c12bf6fa095 = 0.30
        _be5ec0c6269b = _5c9600642633(_05d91581264c(self, "kl_base", 0.30)) * _a7135a2fa768(_3bb0d9cacf63 / _7c12bf6fa095, 1.0)
        _b97f66e2e142 = _5c9600642633(_05d91581264c(self, "cos_base", 0.25))
        _f87cf1da7cb3 = _b97f66e2e142 + (0.10 - _b97f66e2e142) * _3bb0d9cacf63

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _61d110539ec6 = _5c9600642633(self._f71497aa9f34._2e148f12e862()._e7c40d05734a()._01e989591fe1()) if _05d91581264c(self, "_last_teacher_conf", _4fa295680821) is not _4fa295680821 else 0.0
        if _05d91581264c(self, "ema_teacher_conf", _4fa295680821) is _4fa295680821:
            self._99ee1c766c5b = _61d110539ec6
        else:
            _3f7303870282 = _5c9600642633(_05d91581264c(self, "teacher_conf_beta", 0.995))
            self._99ee1c766c5b = _3f7303870282 * _5c9600642633(self._99ee1c766c5b) + (1.0 - _3f7303870282) * _61d110539ec6

        _12fca749fb12 = _5c9600642633(_05d91581264c(self, "tau_warn", 0.60))
        _49aac0d67d2f = _5c9600642633(_05d91581264c(self, "tau_detect", 0.20))
        _88f47f358d38 = _c1d544a1f915(1e-12, (_12fca749fb12 - _49aac0d67d2f))
        _bdd8bc057c17 = (_5c9600642633(self._99ee1c766c5b) - _49aac0d67d2f) / _88f47f358d38
        _bdd8bc057c17 = _c1d544a1f915(0.0, _a7135a2fa768(1.0, _bdd8bc057c17))

        _d987e864af93 = _be5ec0c6269b * _bdd8bc057c17
        _3ed43ce85f45 = _f87cf1da7cb3 * _bdd8bc057c17

        # 5) final aux term
        _18766a49da2a = _18ce74297369._8a1b70327af7(0.0, _8078911a0ffb=_8078911a0ffb)
        _18766a49da2a = _18766a49da2a + (_d987e864af93 * _628bad22b9fd + _3ed43ce85f45 * _cc8ae867b943) * _5c9600642633(_adfcaf619733)

        # diagnostics
        _9b17cbf4b7aa = {
            "aux_term": _18766a49da2a,
            "kl_batch": _9300cc5e9d5f,
            "contrast_batch": _6c93be26d5f2,
            "kl_loss": _628bad22b9fd,
            "contrastive_loss": _cc8ae867b943,
            "w_mean": _e1b313ee314b,
            "aux_scale": _5c9600642633(_adfcaf619733),
            "lambda_kl_eff": _5c9600642633(_d987e864af93),
            "lambda_cos_eff": _5c9600642633(_3ed43ce85f45),
            "teacher_conf_mean": _5c9600642633(self._99ee1c766c5b),
            "shift_r": _5c9600642633(_bdd8bc057c17)
        }
        return _9b17cbf4b7aa

    def _5669aca034c1(self, _5f5f9e7fa83a):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _5f5f9e7fa83a = _5f5f9e7fa83a._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)
        _d4e1af287d09 = (_5f5f9e7fa83a != self._59ed64029177._5b4ae9b6d2cd)._dbbde872cae8(_4b779a0fad4b=_18ce74297369._2a960f1c4de5, _8078911a0ffb=self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)

        # model forward (request hidden states)
        _ce3ea49fb0d7 = self._f9a2802f383b(
            _5f5f9e7fa83a=_5f5f9e7fa83a,
            _d4e1af287d09=_d4e1af287d09,
            _59a9c1e4ade2=_fcad1e1d9bc5,
            _484f3b24355c=_fcad1e1d9bc5,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _959a8ed09a3c = _05d91581264c(_ce3ea49fb0d7, "last_hidden_state", _4fa295680821)
        if _959a8ed09a3c is _4fa295680821:
            _959a8ed09a3c = _ce3ea49fb0d7._bd52c91974e2[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _959a8ed09a3c._4b779a0fad4b != _18ce74297369._2d05bf1dcd13:
            _959a8ed09a3c = _959a8ed09a3c._dbbde872cae8(_18ce74297369._2d05bf1dcd13)
        # student_hidden = self.adapter(hidden)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        # if self._has_lm_head:
        #     logits = self._lm_head(student_hidden)
        # else:
        #     logits = outs.logits

        _d3f850756873 = self._f9a2802f383b._09fc3c535a4e  # _LMHeadAdapter

        _0b446666bfb6 = _d3f850756873._9c3c18ec716f(_959a8ed09a3c)      # (B, L, 2048)
        # logits = adapter.lm_head(student_hidden)    # (B, L, 128256)
        _e078e12b3140 = _d3f850756873(_959a8ed09a3c)


        _e078e12b3140 = _e078e12b3140._dbbde872cae8(_18ce74297369._2d05bf1dcd13)._f717bbdf09b9(-20, 20)

        # default zero scalars
        _628bad22b9fd = _18ce74297369._8a1b70327af7(0.0, _8078911a0ffb=self._4b7a48d6b477)
        _cc8ae867b943 = _18ce74297369._8a1b70327af7(0.0, _8078911a0ffb=self._4b7a48d6b477)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _670a9a4f4ad8 = _05d91581264c(self, "trainer", _4fa295680821)
        _55ff68fecd77 = _ef4c66fa8dbf
        if _670a9a4f4ad8 is not _4fa295680821:
            _55ff68fecd77 = _2a960f1c4de5(_05d91581264c(self._7a56d685d9d1, "training", _ef4c66fa8dbf) or _05d91581264c(self._7a56d685d9d1, "validating", _ef4c66fa8dbf))

        if _55ff68fecd77 and (_05d91581264c(self, "batch_counter", 0) % _05d91581264c(self, "xth_batch_to_consider", 1) == 0):
            with _18ce74297369._94dfa498555a():
                _5cef683adaa2 = _b5534f141417(
                    _5f5f9e7fa83a=_5f5f9e7fa83a,
                    _d4e1af287d09=_d4e1af287d09,
                    _59a9c1e4ade2=_fcad1e1d9bc5,
                    _484f3b24355c=_fcad1e1d9bc5,
                )
                _0a007d98222e = _05d91581264c(_5cef683adaa2, "last_hidden_state", _4fa295680821)
                if _0a007d98222e is _4fa295680821:
                    _0a007d98222e = _5cef683adaa2._bd52c91974e2[-1]

            # compute embedding-level KL + contrastive (scalar)
            _628bad22b9fd, _cc8ae867b943 = self._21417a70e48b(_0b446666bfb6, _0a007d98222e, _8078911a0ffb=self._4b7a48d6b477)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _7edb1b812ccb(_5fab92a624e3): return _5fab92a624e3._2e148f12e862(_e36ec35acba5=1) if _5fab92a624e3._e36ec35acba5() == 3 else _5fab92a624e3
            _2e12e8cc88fe = _18ce74297369._951d1ac253a3._155097bde577._0c846c4eb91a(_c72db87d61f8(_0b446666bfb6), _56b257b60858=2, _e36ec35acba5=-1, _91b27b316e75=1e-6)
            _ddd033ea1b3b = _18ce74297369._951d1ac253a3._155097bde577._0c846c4eb91a(_c72db87d61f8(_0a007d98222e), _56b257b60858=2, _e36ec35acba5=-1, _91b27b316e75=1e-6)
            _cf6365063fbc = _18ce74297369._951d1ac253a3._155097bde577._c93976362cd2(_2e12e8cc88fe, _ddd033ea1b3b, _e36ec35acba5=-1)  # [-1,1]
            _d88c3774b778 = _cf6365063fbc._f717bbdf09b9(_a7135a2fa768=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._b0866ee00bba = _0b446666bfb6._e96e40d5974a()
            self._46b28149f5cd = _0a007d98222e._e96e40d5974a()
            self._f71497aa9f34 = _d88c3774b778._e96e40d5974a()  # shape (B,)

        # increment counter
        self._8ced193d28be = _05d91581264c(self, "batch_counter", 0) + 1

        return _e078e12b3140, _628bad22b9fd, _cc8ae867b943


    def _fecf437a395d(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _e10f51353ecc(_4a9b6bfbedb1, _46a30b35cf16, _be0ab2d47c75):
            if _c170677907c0(_56368cdba0d7._4b779a0fad4b == _18ce74297369._2bbc1d8e3b76 for _56368cdba0d7 in _46a30b35cf16 if _039628450a64(_56368cdba0d7, _18ce74297369._3a0eddc10aea)):
                _8e00933065b7(f"Layer {_4a9b6bfbedb1._0b78d28ab774.__name__} is using float16!")

        for _12314084be9c in self._817eb5babace():
            _2a3ea2745860 = _12314084be9c._696e95ce6f37(_57330ccffe2c)
            self._cd8e10ad5e02._1a511bab9629(_2a3ea2745860)

    def _c88bee85ff73(self):
        """Remove all registered forward hooks."""
        for _2a3ea2745860 in _05d91581264c(self, "amp_hooks", []):
            _2a3ea2745860._68224aeaf835()
        self._cd8e10ad5e02 = []

    def _02ac4992984a(self, _5f5f9e7fa83a, _b2f3042f8695, _7dc0a54976b2):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _bfe43eb29bad = [self._59ed64029177._820af77a0592(_75d97452acc7) for _75d97452acc7 in _5f5f9e7fa83a]
        _b61369b7125a, _34d8b9e273f9 = [], []

        for _0ac0836804cb, _22af67168cd6, _6eacb2852ab1 in _d41302f192a1(_bfe43eb29bad, _b2f3042f8695, _7dc0a54976b2):
            for _a6d5160b4ab7, _9aa8dc5b3051, _e0f191bf53fc in _d41302f192a1(_0ac0836804cb, _22af67168cd6, _6eacb2852ab1):
                if _a6d5160b4ab7 == self._59ed64029177._f7f0ff2f065d or _e0f191bf53fc == self._4ec41e2281f8:
                    continue

                _0b80494f827c = (
                    _a6d5160b4ab7._9d0baf2e0b3a("##") or
                    _a6d5160b4ab7._9d0baf2e0b3a("▁") or
                    _a6d5160b4ab7 in ["<unk>", "<pad>"]
                )

                if _0b80494f827c:
                    continue

                _b61369b7125a._1a511bab9629(_9aa8dc5b3051._01e989591fe1())
                _34d8b9e273f9._1a511bab9629(_e0f191bf53fc._01e989591fe1())

        return _18ce74297369._8a1b70327af7(_b61369b7125a), _18ce74297369._8a1b70327af7(_34d8b9e273f9)

    def _4fd4408bffa1(self):
        _4543e0c5dbd5 = _18ce74297369._2d05bf1dcd13
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            _03d5ee8e03ec, _b2907516bf8f = _18ce74297369._fb7f3cc5b839._a13f226ab029()
            if _03d5ee8e03ec >= 8:
                _4543e0c5dbd5 = _18ce74297369._47399ee42e97
            else:
                _4543e0c5dbd5 = _18ce74297369._2bbc1d8e3b76
        return _4543e0c5dbd5

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _73325d993c79(
        self,
        _9870905edfe4: _18ce74297369._3a0eddc10aea,
        _4d4e66049f96: _18ce74297369._3a0eddc10aea,
        _8078911a0ffb: _c242ed4cb1cd = "cpu",
    ) -> _0a0c408b1ef1[_18ce74297369._3a0eddc10aea, _18ce74297369._3a0eddc10aea]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _67f18431e86d = 2.0
            # NaN/Inf guard
            _9870905edfe4 = _9870905edfe4._f717bbdf09b9(_a7135a2fa768=-30, _c1d544a1f915=30)
            _4d4e66049f96 = _4d4e66049f96._f717bbdf09b9(_a7135a2fa768=-30, _c1d544a1f915=30)

            # Move once if needed
            _cb3f62f27b8e = _18ce74297369._8078911a0ffb(_8078911a0ffb)
            if _9870905edfe4._8078911a0ffb != _cb3f62f27b8e:
                _9870905edfe4 = _9870905edfe4._dbbde872cae8(_8078911a0ffb=_cb3f62f27b8e, _8e854892cdda=_fcad1e1d9bc5, _4b779a0fad4b=self._4a3a5a589750)
                _4d4e66049f96 = _4d4e66049f96._dbbde872cae8(_8078911a0ffb=_cb3f62f27b8e, _8e854892cdda=_fcad1e1d9bc5, _4b779a0fad4b=self._4a3a5a589750)

            _4a64e91f1095 = _9870905edfe4._260ad1b4dd18(0)
            _81fa0aa666de = _9870905edfe4._260ad1b4dd18(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _828e786f9ba2 = (_4a64e91f1095 * _81fa0aa666de) > 32_000_000

            if not _828e786f9ba2 or _4a64e91f1095 <= 8:
                # Direct computation
                _a374c8853ef0 = _18ce74297369._951d1ac253a3._155097bde577._71d03618f3e0(_9870905edfe4 / _67f18431e86d, _e36ec35acba5=-1)
                _f8865e55e59f = _18ce74297369._951d1ac253a3._155097bde577._b9638d9cf228(_4d4e66049f96 / _67f18431e86d, _e36ec35acba5=-1)
                _628bad22b9fd = _18ce74297369._951d1ac253a3._155097bde577._78027dcc42fc(_a374c8853ef0, _f8865e55e59f, _be47a8c1f074="batchmean") * (_67f18431e86d * _67f18431e86d)
                _cc8ae867b943 = 1 - _18ce74297369._951d1ac253a3._155097bde577._c93976362cd2(_9870905edfe4, _4d4e66049f96, _e36ec35acba5=-1)._2e148f12e862()
                return _628bad22b9fd, _cc8ae867b943

            # Chunked mode for large inputs
            _4ed6a9c92aa2 = _c1d544a1f915(1, _4a64e91f1095 // 8)
            _6f2b319a2652, _be462d3d6648 = [], []

            for _24512c575754 in _b36d53bf66ba(0, _4a64e91f1095, _4ed6a9c92aa2):
                _39ccc7371821 = _9870905edfe4[_24512c575754:_24512c575754 + _4ed6a9c92aa2]
                _40ca48b26238 = _4d4e66049f96[_24512c575754:_24512c575754 + _4ed6a9c92aa2]

                _a374c8853ef0 = _18ce74297369._951d1ac253a3._155097bde577._71d03618f3e0(_39ccc7371821 / _67f18431e86d, _e36ec35acba5=-1)
                _f8865e55e59f = _18ce74297369._951d1ac253a3._155097bde577._b9638d9cf228(_40ca48b26238 / _67f18431e86d, _e36ec35acba5=-1)

                _6421e38927c3 = _18ce74297369._951d1ac253a3._155097bde577._78027dcc42fc(_a374c8853ef0, _f8865e55e59f, _be47a8c1f074="batchmean") * (_67f18431e86d * _67f18431e86d)
                _52158ad8e241 = _18ce74297369._951d1ac253a3._155097bde577._c93976362cd2(_39ccc7371821, _40ca48b26238, _e36ec35acba5=-1)._2e148f12e862()
                _590ed7a14101 = 1 - _52158ad8e241

                _6f2b319a2652._1a511bab9629(_6421e38927c3)
                _be462d3d6648._1a511bab9629(_590ed7a14101)

            _628bad22b9fd = _18ce74297369._8fe433ddcdf6(_6f2b319a2652)._2e148f12e862()
            _cc8ae867b943 = _18ce74297369._8fe433ddcdf6(_be462d3d6648)._2e148f12e862()
            return _628bad22b9fd, _cc8ae867b943

        except _136f84ce92aa as _5af893fd5670:
            raise _b7b5ea930b05(f"KL/contrastive loss computation failed: {_c242ed4cb1cd(_5af893fd5670)}")

    def _a3116144fd65(self, _9fbdc5edac8f):
        _7c961a8914ff = [
            _d85068d30d0c
            for _04499eb884ac, _df5278c13fb3 in self._15ba210377ae._e5acc0bc36b4()
            if self._a85116ed3c1c[_04499eb884ac] in _9fbdc5edac8f
            for _d85068d30d0c in _df5278c13fb3
        ]

        self._4d7a84cd828f = _10f60b654077([
            _19c16b8ce88d(
                _7c961a8914ff=_7c961a8914ff,
                _ceec7d2f2056=self._1409bcf2953c,
                _c8bed4259035=self._59ed64029177._c8bed4259035
            )
        ])

    def _9c4c66bc2679(self, _5611525d0013):
        _9fbdc5edac8f = _e470473f1113()

        if _039628450a64(_5611525d0013, _5af0dd8c3e0d):
            _0e1f66ea428f = _5611525d0013._c49f63c8df0c()
        elif _039628450a64(_5611525d0013, (_e603872a5b35, _bdc17ddb981e)):
            _0e1f66ea428f = _5611525d0013
        else:
            _0e1f66ea428f = [_5611525d0013]

        for _67a11cfef7a2 in _0e1f66ea428f:
            _9fbdc5edac8f._be7f42ac5d6c(_67a11cfef7a2._63a08c4051c2._18e80a1c320b)

        return _9fbdc5edac8f

    def _a529f758acc1(self):
        _9fbdc5edac8f = self._74e47fab3ab6(
            self._7a56d685d9d1._d584bdd73939
        )
        self._c8000816d18d(_9fbdc5edac8f)

        _8e00933065b7(f"Training Allowed languages {_9fbdc5edac8f}")

        self._4d7a84cd828f = _10f60b654077([
            _19c16b8ce88d(
                _7c961a8914ff=[
                    _d85068d30d0c
                    for _04499eb884ac, _df5278c13fb3 in self._15ba210377ae._e5acc0bc36b4()
                    if self._a85116ed3c1c[_04499eb884ac] in _9fbdc5edac8f
                    for _d85068d30d0c in _df5278c13fb3
                ],
                _ceec7d2f2056=self._1409bcf2953c,
                _c8bed4259035=self._59ed64029177._c8bed4259035
            )
        ])
        
    def _20589d895810(self, _e305b72b6961, _a176924bfca5):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _5f5f9e7fa83a = _e305b72b6961["input_ids"]
            _5a28e3eba168 = _e305b72b6961["labels"]
            _9ec082ca61e3 = _e305b72b6961._66dede16100f("prompt_lens", _4fa295680821)
            _4a64e91f1095 = _5f5f9e7fa83a._260ad1b4dd18(0)

            # move to device
            _5f5f9e7fa83a = _5f5f9e7fa83a._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)
            _5a28e3eba168 = _5a28e3eba168._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)

            # ---- scheduled sampling (minimal) ----
            _56b257b60858 = 0.0 if self._50d606f6a153 < 2 else self._0360bad0fd69  # e.g. 0.2
            if _56b257b60858 > 0.0 and (_a176924bfca5 % 2 == 0):
                with _18ce74297369._94dfa498555a():
                    # 1. run a no-grad forward to get predictions
                    _02b8863f916c, _, _ = self(_5f5f9e7fa83a)
                    _09d5e61f241b = _02b8863f916c._43ec846708f0(_e36ec35acba5=-1)
                    _09d5e61f241b = _18ce74297369._9fff19ed52bf(
                        [_5f5f9e7fa83a[:, :1], _09d5e61f241b[:, :-1]],
                        _e36ec35acba5=1
                    )

                # 2. decide where to replace (Bernoulli mask)
                _1048d6372d47 = _18ce74297369._cc9520ed0ff4(_5f5f9e7fa83a._5c9600642633()) < _56b257b60858

                # 3. NEVER replace masked-out labels (-100) or input side
                _c49524332a22 = (_5a28e3eba168 != -100)
                _1048d6372d47 &= _c49524332a22

                # 4. replace teacher tokens with model predictions
                _5f5f9e7fa83a = _18ce74297369._a839336d8d71(_1048d6372d47, _09d5e61f241b, _5f5f9e7fa83a)
            # -------------------------------------

            # ---- label dropout (generic, safe) ----
            _d4419c68445e = 0.0 if self._50d606f6a153 < 2 else 0.2  # start small
            if _d4419c68445e > 0 and (_a176924bfca5 % 2 == 0):
                _b20fcb5955b4 = (
                    (_18ce74297369._cc9520ed0ff4(_5f5f9e7fa83a._5c9600642633()) < _d4419c68445e)
                    & (_5a28e3eba168 != -100)
                )
                _5f5f9e7fa83a = _18ce74297369._a839336d8d71(
                    _b20fcb5955b4,
                    self._1409bcf2953c,
                    _5f5f9e7fa83a
                )
            # -------------------------------------
            
            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _be0ab2d47c75, _9300cc5e9d5f, _6c93be26d5f2 = self(_5f5f9e7fa83a)

            # causal LM shift for next-token classification (unchanged)
            _5f3aa80e5e94 = _be0ab2d47c75[:, :-1, :]._41a23cd94aab()
            _cca0ceebedee = _5a28e3eba168[:, 1:]._41a23cd94aab()
            _654cf81adba8 = _5f3aa80e5e94._9e5921e8f0cc(-1, _5f3aa80e5e94._260ad1b4dd18(-1))
            _9bfcf64d96c6 = _cca0ceebedee._9e5921e8f0cc(-1)

            # classification/task loss
            _3acfac28719c = self._0388e0664aaa['criterion'](_654cf81adba8, _9bfcf64d96c6)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _9300cc5e9d5f = _18ce74297369._80f694e68359(_9300cc5e9d5f, _8979df90e434=0.0, _e6ce545cb1b3=0.0, _574b03c971ed=0.0)
            _6c93be26d5f2 = _18ce74297369._80f694e68359(_6c93be26d5f2, _8979df90e434=0.0, _e6ce545cb1b3=0.0, _574b03c971ed=0.0)
            _3acfac28719c = _18ce74297369._80f694e68359(_3acfac28719c, _8979df90e434=0.0, _e6ce545cb1b3=0.0, _574b03c971ed=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _269cae5e5154 = self._93760ac4b666(_3acfac28719c, _9300cc5e9d5f, _6c93be26d5f2)
            _18766a49da2a = _269cae5e5154["aux_term"]

            if _3acfac28719c._e96e40d5974a() < self._d2770e52ae18:
                _18766a49da2a = _18ce74297369._2e9fc394a289(_3acfac28719c)

            # final combined loss (single-equation)
            _3a9466f678dd = _3acfac28719c + _18766a49da2a

            # Optional NaN print as before (keeps your original check)
            if _18ce74297369._6a8b00e77538(_3acfac28719c):
                _8e00933065b7(f"Step {_a176924bfca5}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _ab7f2182440b = {
                "epoch": _5c9600642633(_05d91581264c(self, "current_epoch", _05d91581264c(self._7a56d685d9d1, "current_epoch", 0))),
                "train_kl_loss": _269cae5e5154._66dede16100f("kl_loss", _9300cc5e9d5f)._e96e40d5974a() if _039628450a64(_269cae5e5154._66dede16100f("kl_loss", _9300cc5e9d5f), _18ce74297369._3a0eddc10aea) else _269cae5e5154._66dede16100f("kl_loss", _9300cc5e9d5f),
                "train_contrastive_loss": _269cae5e5154._66dede16100f("contrastive_loss", _6c93be26d5f2)._e96e40d5974a() if _039628450a64(_269cae5e5154._66dede16100f("contrastive_loss", _6c93be26d5f2), _18ce74297369._3a0eddc10aea) else _269cae5e5154._66dede16100f("contrastive_loss", _6c93be26d5f2),
                "train_classification_loss": _3acfac28719c._e96e40d5974a(),
                "train_loss": _3a9466f678dd._e96e40d5974a(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _5c9600642633(_05d91581264c(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _269cae5e5154._66dede16100f("lambda_kl_eff", _5c9600642633(_05d91581264c(self, "kl_base", 0.30))),
                "train_lambda_contrast": _269cae5e5154._66dede16100f("lambda_cos_eff", _5c9600642633(_05d91581264c(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _f57384af8a63 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _f57384af8a63 in _269cae5e5154:
                    _e6c71232041c = _269cae5e5154[_f57384af8a63]
                    # convert single-element tensors to python floats for logging
                    if _039628450a64(_e6c71232041c, _18ce74297369._3a0eddc10aea) and _e6c71232041c._50502a2a274d() == 1:
                        _ab7f2182440b[f"train_{_f57384af8a63}"] = _5c9600642633(_e6c71232041c._e96e40d5974a()._e7c40d05734a()._01e989591fe1())
                    else:
                        _ab7f2182440b[f"train_{_f57384af8a63}"] = _e6c71232041c

            # log exactly like you did
            self._3c582aa3606c(
                _ab7f2182440b,
                _4a64e91f1095=_4a64e91f1095,
                _49b132f0543e=_ef4c66fa8dbf,
                _22df3d0dd82d=_fcad1e1d9bc5,
                _28c538178f92=_ef4c66fa8dbf,
                _68993ee119d6=_fcad1e1d9bc5,
                _58ef7bb2578a=_fcad1e1d9bc5,
            )

            # free references as you did
            del _5f5f9e7fa83a, _5a28e3eba168, _be0ab2d47c75, _9300cc5e9d5f, _3acfac28719c, _6c93be26d5f2, _cca0ceebedee, _5f3aa80e5e94, _9bfcf64d96c6, _654cf81adba8

            return _3a9466f678dd

        except _136f84ce92aa as _5af893fd5670:
            raise _b7b5ea930b05(f"Error in training_step: {_5af893fd5670}") from _5af893fd5670

    def _53869a5b7c16(self):
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            _18ce74297369._fb7f3cc5b839._b01178574ffc()
        _c61fe3213320._96dba8b2853c()
        return _87d343b43d4b()._987f8c6117f5()

    # def validation_step(self, batch, batch_idx):
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification (same as training)
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     if batch_idx == 0:
    #         try:
    #             print(
    #                 f"VAL TEST BATCH {batch_idx} Input IDs: {input_ids.tolist()[0]}, "
    #                 f"Predictions: {torch.argmax(shift_logits, dim=-1).tolist()[0]}, "
    #                 f"Labels: {shift_labels.tolist()[0]}"
    #             )
    #         except Exception:
    #             # printing should never crash validation
    #             pass

    #     # classification loss
    #     classification_loss = self.loss_funcs['criterion'](logits_flat, labels_flat)

    #     # numeric guards (preserve your original torch.where behavior but simpler)
    #     kl_batch = torch.nan_to_num(kl_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     contrast_batch = torch.nan_to_num(contrast_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     classification_loss = torch.nan_to_num(classification_loss, nan=0.0, posinf=0.0, neginf=0.0)

    #     # ---------------------
    #     # Compute auxiliary term using the same helper as training
    #     # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
    #     aux = self.compute_auxiliary_distill_term(classification_loss, kl_batch, contrast_batch)
    #     aux_term = aux["aux_term"]
    #     if classification_loss.detach() < self.task_loss_floor:
    #         aux_term = torch.zeros_like(classification_loss)

    #     combined_loss = classification_loss + aux_term

    #     # Logging: preserve your keys but prefer the aux diagnostics where available
    #     log_dict = {
    #         "val_kl_loss": float(aux.get("kl_loss", kl_batch).detach().cpu().item()) if isinstance(aux.get("kl_loss", kl_batch), torch.Tensor) else float(aux.get("kl_loss", kl_batch)),
    #         "val_contrastive_loss": float(aux.get("contrastive_loss", contrast_batch).detach().cpu().item()) if isinstance(aux.get("contrastive_loss", contrast_batch), torch.Tensor) else float(aux.get("contrastive_loss", contrast_batch)),
    #         "val_classification_loss": float(classification_loss.detach().cpu().item()),
    #         "val_loss": float(combined_loss.detach().cpu().item()),
    #     }

    #     # include effective lambdas and others if provided by aux
    #     log_dict["val_lambda_kl"] = float(aux.get("lambda_kl", aux.get("lambda_kl_eff", float(getattr(self, "kl_base", 0.30)))))
    #     log_dict["val_lambda_contrast"] = float(aux.get("lambda_cos", aux.get("lambda_cos_eff", float(getattr(self, "cos_base", 0.25)))))
    #     log_dict["val_w_mean"] = float(aux.get("w_mean", 0.0))
    #     log_dict["val_aux_scale"] = float(aux.get("aux_scale", 0.0))
    #     log_dict["val_shift_r"] = float(aux.get("shift_r", 0.0))
    #     log_dict["val_teacher_conf_mean"] = float(aux.get("teacher_conf_mean", 0.0))

    #     self.log_dict(
    #         log_dict,
    #         batch_size=batch_size,
    #         on_step=False,
    #         on_epoch=True,
    #         prog_bar=False,
    #         logger=True,
    #         sync_dist=True,
    #     )

    #     # build preds and labels per example (preserve your previous behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "val_loss": combined_loss,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # store for epoch-end aggregation (your code uses self._validation_outputs)
    #     self._validation_outputs.append(output)

    #     # explicit frees (same as you had)
    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, classification_loss, preds_list, labels_list

    #     return output

    def _b63ded327921(self, _e305b72b6961, _a176924bfca5):
        _5f5f9e7fa83a = _e305b72b6961["input_ids"]._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)
        _5a28e3eba168 = _e305b72b6961["labels"]._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)

        _18e80a1c320b = _e305b72b6961._66dede16100f("lang_codes", _4fa295680821)
        _cc41b8f1f5b3 = _e305b72b6961._66dede16100f("sample_ids", _4fa295680821)
        _c71db774469f = _e305b72b6961._66dede16100f("chunk_ids", _4fa295680821)
        _2565f3526dd2 = _e305b72b6961._66dede16100f("word_positions", _4fa295680821)
        _9ec082ca61e3 = _e305b72b6961._66dede16100f("prompt_lens", _4fa295680821)
        _9d5ef233c7ea = _e305b72b6961._66dede16100f("num_chunks", _4fa295680821)

        _4a64e91f1095 = _5f5f9e7fa83a._260ad1b4dd18(0)

        _8cb36c55aae5 = (_5a28e3eba168 != -100)._5de4ff660788(_e36ec35acba5=1)
        _30130c21b7e9 = _8cb36c55aae5._c1d544a1f915()._01e989591fe1()

        with _18ce74297369._94dfa498555a():
            _b7b06ad0b344 = self._153b1d198dec(
                _5f5f9e7fa83a=_5f5f9e7fa83a,
                _cc217da3be56=_30130c21b7e9,
                _fedf15443566=_30130c21b7e9,
                _472f84085822=_ef4c66fa8dbf,
                _80a67c144604=1,
                _4cdddc7c6de9=1.0,
                _304c946bac7d=1.0,
                # repetition_penalty=1.0,
                # length_penalty=1.0,
                # early_stopping=True,
                _616369f492dd=_fcad1e1d9bc5,
                _4d7a84cd828f=self._4d7a84cd828f,
                _15380ec8b975=_fcad1e1d9bc5,
                _d84e35f3e187=_fcad1e1d9bc5,
                _59a9c1e4ade2=_ef4c66fa8dbf,
            )


        _78fadb4f7ad9 = _18ce74297369._8fe433ddcdf6(_b7b06ad0b344._d8ca76572029, _e36ec35acba5=1)   # (B, T_gen, V)

        _d9684f30faac = _5f5f9e7fa83a._260ad1b4dd18(1)
        _d5e63c832815, _4d96788b783d, _dbc513042917 = _78fadb4f7ad9._d780d4cd5a74
        _a7de9f541ffe = _5a28e3eba168._260ad1b4dd18(1)

        _0476c4cafd58 = _b7b06ad0b344._f879c86ae037
        _0444fcdb3d34 = _0476c4cafd58

        # ---- build pred_tokens WITHOUT argmax on junk ----
        _09d5e61f241b = _18ce74297369._21b566ad6bd1(
            (_d5e63c832815, _a7de9f541ffe),
            -100,
            _8078911a0ffb=_78fadb4f7ad9._8078911a0ffb,
            _4b779a0fad4b=_18ce74297369._5be207d527a1,
        )

        # pred_tokens[:, prompt_len : prompt_len + T_gen] = torch.argmax(gen_logits, dim=-1)
        _09d5e61f241b[:, _d9684f30faac : _d9684f30faac + _4d96788b783d] = _0444fcdb3d34[:, _d9684f30faac : _d9684f30faac + _4d96788b783d]

        # DEBUG — AS-IS, full length
        if _a176924bfca5 == 0:
            _8e00933065b7(
                "VAL DEBUG\n"
                f"INPUT IDS      : {_5f5f9e7fa83a[0]._b52daafee6d7()}\n"
                f"GEN IDS (ONLY) : {_0444fcdb3d34[0]._b52daafee6d7()}\n"
                f"PRED TOKENS    : {_09d5e61f241b[0]._b52daafee6d7()}\n"
                f"LABELS (FULL)  : {_5a28e3eba168[0]._b52daafee6d7()}"
            )


        _7cebc30ec9ea = _d9684f30faac
        _f7b608c65442 = _d9684f30faac + _78fadb4f7ad9._260ad1b4dd18(1)

        # logits_flat = gen_logits.reshape(-1, gen_logits.size(-1))
        # labels_flat = labels[:, gen_start:gen_end].reshape(-1)

        _92f42c90e805 = _5a28e3eba168[:, _7cebc30ec9ea:_f7b608c65442]
        _1a24d330aeed = _92f42c90e805 != -100

        _654cf81adba8 = _78fadb4f7ad9[_1a24d330aeed]
        _9bfcf64d96c6 = _92f42c90e805[_1a24d330aeed]

        if _a176924bfca5 == 0:
            _8e00933065b7(
                "VAL DEBUG\n"
                f"LOGITS FLAT : {_654cf81adba8._d780d4cd5a74}\n"
                f"LABELS FLAT : {_9bfcf64d96c6._d780d4cd5a74}\n"
            )
        

        _3acfac28719c = self._0388e0664aaa["criterion"](_654cf81adba8, _9bfcf64d96c6)
        _3acfac28719c = _18ce74297369._80f694e68359(_3acfac28719c, _8979df90e434=0.0)

        _9300cc5e9d5f = _18ce74297369._8a1b70327af7(0.0, _8078911a0ffb=_5f5f9e7fa83a._8078911a0ffb)
        _6c93be26d5f2 = _18ce74297369._8a1b70327af7(0.0, _8078911a0ffb=_5f5f9e7fa83a._8078911a0ffb)

        # if gen_out.hidden_states is not None:
        #     hs = gen_out.hidden_states
        #     last_step = hs[-1]
        #     last_layer = last_step[-1] if isinstance(last_step, (tuple, list)) else last_step
        #     student_hidden = last_layer[:, -T_gen:, :]

        #     with torch.no_grad():
        #         frozen_outs = FROZEN_EMBEDDING(
        #             input_ids=generated_ids,
        #             attention_mask=(generated_ids != self.tokenizer.pad_token_id),
        #             output_hidden_states=True,
        #             return_dict=True,
        #         )
        #         frozen_hidden = frozen_outs.hidden_states[-1][:, -T_gen:, :]

        #     kl_batch, contrast_batch = self.compute_kl_contrastive_loss(
        #         student_hidden,
        #         frozen_hidden,
        #         device=self.curr_device,
        #     )

        _9300cc5e9d5f = _18ce74297369._80f694e68359(_9300cc5e9d5f, _8979df90e434=0.0)
        _6c93be26d5f2 = _18ce74297369._80f694e68359(_6c93be26d5f2, _8979df90e434=0.0)

        _269cae5e5154 = self._93760ac4b666(
            _3acfac28719c,
            _9300cc5e9d5f,
            _6c93be26d5f2,
        )

        _18766a49da2a = _269cae5e5154["aux_term"]
        if _3acfac28719c._e96e40d5974a() < self._d2770e52ae18:
            _18766a49da2a = _18ce74297369._2e9fc394a289(_3acfac28719c)

        _3a9466f678dd = _3acfac28719c + _18766a49da2a

        self._3c582aa3606c(
            {
                "val_loss": _3a9466f678dd._e96e40d5974a(),
                "val_classification_loss": _3acfac28719c._e96e40d5974a(),
                "val_kl_loss": _269cae5e5154._66dede16100f("kl_loss", _9300cc5e9d5f),
                "val_contrastive_loss": _269cae5e5154._66dede16100f("contrastive_loss", _6c93be26d5f2),
                "val_lambda_kl": _269cae5e5154._66dede16100f("lambda_kl_eff", 0.0),
                "val_lambda_contrast": _269cae5e5154._66dede16100f("lambda_cos_eff", 0.0),
                "val_teacher_conf_mean": _269cae5e5154._66dede16100f("teacher_conf_mean", 0.0),
            },
            _4a64e91f1095=_4a64e91f1095,
            _49b132f0543e=_ef4c66fa8dbf,
            _22df3d0dd82d=_fcad1e1d9bc5,
            _58ef7bb2578a=_fcad1e1d9bc5,
        )

        _4b305a0130f8 = [_0444fcdb3d34[_24512c575754] for _24512c575754 in _b36d53bf66ba(_4a64e91f1095)]
        _9725f9a36973 = [_5a28e3eba168[_24512c575754] for _24512c575754 in _b36d53bf66ba(_4a64e91f1095)]

        _4d3c203d86c5 = {
            "lang_codes": _18e80a1c320b,
            "preds": _4b305a0130f8,
            "labels": _9725f9a36973,
            "sample_ids": _cc41b8f1f5b3,
            "chunk_ids": _c71db774469f,
            "word_positions": _2565f3526dd2,
            "prompt_lens": _9ec082ca61e3,
            "num_chunks": _9d5ef233c7ea,
            "val_loss": _3a9466f678dd,
        }

        self._60dc9c3486a9._1a511bab9629(_4d3c203d86c5)

        del _5f5f9e7fa83a, _5a28e3eba168, _b7b06ad0b344, _78fadb4f7ad9
        del _654cf81adba8, _9bfcf64d96c6, _0444fcdb3d34
        del _9300cc5e9d5f, _6c93be26d5f2, _3acfac28719c
        del _4b305a0130f8, _9725f9a36973

        return _4d3c203d86c5

    def _b7d991abe3db(self, _f90c6413fd30, _06d35d176d71, _fa913b5acd26=_4fa295680821):
        _02606896e2a3 = _040871b10acb._43eb4ba168e7()
        _b1605dcbf77f = f"trial_{_fa913b5acd26}" if _fa913b5acd26 is not _4fa295680821 else "default"
        _8e00933065b7(f"[DEBUG rank={_18ce74297369._8e1f7539b9af._550eca9fdec8() if _18ce74297369._8e1f7539b9af._7438204551eb() else 0}] metrics_dict confusion_matrix sum={_5de4ff660788(_5de4ff660788(_a0d50efb1403) for _a0d50efb1403 in _f90c6413fd30['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _3b4fd700862d = _040871b10acb._8026002bcb4a._5ba2dfd8da85(_02606896e2a3, "metrics", self._d20ee0cb57db,  _b1605dcbf77f)
        _040871b10acb._8e9e37f65d27(_3b4fd700862d, _e6c4a9b00e63=_fcad1e1d9bc5)
        _ada216ee2169 = _040871b10acb._8026002bcb4a._5ba2dfd8da85(_3b4fd700862d, _06d35d176d71)
        _5f252fea3764 = _546eee7dd996._6c1ccea98497(_f90c6413fd30)
        _5f252fea3764._39f59a8fda82(_ada216ee2169, _9461d2506172=_ef4c66fa8dbf)
        _8e00933065b7(f"[metrics] Saved {_ada216ee2169}")

    def _e8b7d880a5ff(self):
        # pick correct device for this rank
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            if _18ce74297369._8e1f7539b9af._7438204551eb():
                _a4a060ee2039 = _18ce74297369._8e1f7539b9af._550eca9fdec8()
            else:
                _a4a060ee2039 = 0
            _18ce74297369._fb7f3cc5b839._fd0653efd207(_a4a060ee2039)
            self._4b7a48d6b477 = _18ce74297369._8078911a0ffb(f"cuda:{_a4a060ee2039}")
        else:
            self._4b7a48d6b477 = _18ce74297369._8078911a0ffb("cpu")
        
        _9fbdc5edac8f = self._74e47fab3ab6(
            self._7a56d685d9d1._a65ea5672532
        )
        self._c8000816d18d(_9fbdc5edac8f)

        _8e00933065b7(f"Validation Allowed languages {_9fbdc5edac8f}")

        self._4d7a84cd828f = _10f60b654077([
            _19c16b8ce88d(
                _7c961a8914ff=[
                    _d85068d30d0c
                    for _04499eb884ac, _df5278c13fb3 in self._15ba210377ae._e5acc0bc36b4()
                    if self._a85116ed3c1c[_04499eb884ac] in _9fbdc5edac8f
                    for _d85068d30d0c in _df5278c13fb3
                ],
                _ceec7d2f2056=self._1409bcf2953c,
                _c8bed4259035=self._59ed64029177._c8bed4259035
            )
        ])

        self._ecba315819ea()

    def _3d5412871fc8(self):
        _be0ab2d47c75 = _05d91581264c(self, "_validation_outputs", _4fa295680821)
        if not _be0ab2d47c75:
            return

        _babe5f5cd429, _30ebe2facd48, _2865abd9876b, _5ca75941690c = \
            self._e12e5ed3a039(_be0ab2d47c75)

        _a4e2d2cecd2f, _73d0b4d627e1 = [], []
        for _5b6239875a1a in _f8e07f5e0f31(_2865abd9876b._a632b92eb634()):
            _d13981820b35 = _babe5f5cd429[_5b6239875a1a]._b52daafee6d7()
            _db40adc41fde = _30ebe2facd48[_5b6239875a1a]._b52daafee6d7()
            _d55515fc4d29 = _2865abd9876b[_5b6239875a1a]
            _11ebe4363747 = _5ca75941690c[_5b6239875a1a]
            if _d55515fc4d29._50502a2a274d() > 0 and _11ebe4363747._50502a2a274d() > 0:
                _a4e2d2cecd2f._1a511bab9629(_d55515fc4d29)
                _73d0b4d627e1._1a511bab9629(_11ebe4363747)

        if not _a4e2d2cecd2f:
            _8e00933065b7("[VAL END] Nothing to score.")
            self._60dc9c3486a9._12a96df0ce6e()
            return

        _493d907ac790 = _18ce74297369._9fff19ed52bf(_a4e2d2cecd2f)._dbbde872cae8(_8078911a0ffb=self._892ce5e2edf7['micro_accuracy']._8078911a0ffb, _8e854892cdda=_fcad1e1d9bc5)
        _5a28e3eba168 = _18ce74297369._9fff19ed52bf(_73d0b4d627e1)._dbbde872cae8(_8078911a0ffb=self._892ce5e2edf7['micro_accuracy']._8078911a0ffb, _8e854892cdda=_fcad1e1d9bc5)

        self._892ce5e2edf7['micro_accuracy']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_accuracy']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_precision']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_recall']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_f1']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_accuracy']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_precision']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_recall']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_f1']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['confmat']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)

        _7a576515e9cf  = self._892ce5e2edf7['micro_accuracy']._e843ecb1f5ba()._01e989591fe1()
        _c7c1c6da1c46  = self._892ce5e2edf7['macro_accuracy']._e843ecb1f5ba()._01e989591fe1()
        _aeef0df4c8e3 = self._892ce5e2edf7['macro_precision']._e843ecb1f5ba()._01e989591fe1()
        _8bcd17f371e5    = self._892ce5e2edf7['macro_recall']._e843ecb1f5ba()._01e989591fe1()
        _7f4f21ba441f        = self._892ce5e2edf7['macro_f1']._e843ecb1f5ba()._01e989591fe1()

        self._6fb4f2199d25("val_accuracy", _c7c1c6da1c46, _58ef7bb2578a=_fcad1e1d9bc5)

        try:
            _2ee4e802cee5 = self._50d606f6a153
            _f90c6413fd30 = {
                "epoch": [_2ee4e802cee5],
                "class_names": [self._a85116ed3c1c],
                "micro_accuracy": [_7a576515e9cf],
                "macro_accuracy": [_c7c1c6da1c46],
                "macro_precision": [_aeef0df4c8e3],
                "macro_recall": [_8bcd17f371e5],
                "macro_f1": [_7f4f21ba441f],
                "classwise_accuracy": [self._892ce5e2edf7['classwise_accuracy']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "classwise_precision": [self._892ce5e2edf7['classwise_precision']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "classwise_recall": [self._892ce5e2edf7['classwise_recall']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "classwise_f1": [self._892ce5e2edf7['classwise_f1']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "confusion_matrix": [self._892ce5e2edf7['confmat']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
            }
            self._bff12dfb76aa(_f90c6413fd30, f"val_epoch_{_2ee4e802cee5}.csv", _fa913b5acd26=self._fa913b5acd26)
        except _136f84ce92aa as _5af893fd5670:
            _8e00933065b7(f"[VAL END] save metrics FAILED: {_5af893fd5670}")

        # cleanup
        self._892ce5e2edf7['micro_accuracy']._6689e6300e85(); self._892ce5e2edf7['macro_accuracy']._6689e6300e85()
        self._892ce5e2edf7['macro_precision']._6689e6300e85(); self._892ce5e2edf7['macro_recall']._6689e6300e85(); self._892ce5e2edf7['macro_f1']._6689e6300e85()
        self._892ce5e2edf7['classwise_accuracy']._6689e6300e85(); self._892ce5e2edf7['classwise_precision']._6689e6300e85()
        self._892ce5e2edf7['classwise_recall']._6689e6300e85(); self._892ce5e2edf7['classwise_f1']._6689e6300e85()
        self._892ce5e2edf7['confmat']._6689e6300e85(); self._60dc9c3486a9._12a96df0ce6e()
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            _18ce74297369._fb7f3cc5b839._b01178574ffc()
        _8e00933065b7("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_18ce74297369._94dfa498555a()
    def _70c8bf7fae74(self, _5f5f9e7fa83a: _18ce74297369._3a0eddc10aea, **_98d338c49373):
        _98d338c49373._7a35006e8579("pad_token_id", _4fa295680821)
        _98d338c49373._7a35006e8579("attention_mask", _4fa295680821)
        return self._f9a2802f383b._153b1d198dec(
            _5f5f9e7fa83a=_5f5f9e7fa83a,
            _d4e1af287d09=(_5f5f9e7fa83a != self._59ed64029177._5b4ae9b6d2cd),
            _5b4ae9b6d2cd=self._59ed64029177._5b4ae9b6d2cd,
            _c8bed4259035=self._59ed64029177._c8bed4259035,
            **_98d338c49373
        )

    def _63cf000d7dc1(self, _e305b72b6961, _a176924bfca5):
        _5f5f9e7fa83a = _e305b72b6961["input_ids"]._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)
        _5a28e3eba168    = _e305b72b6961["labels"]._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)
        _18e80a1c320b     = _e305b72b6961._66dede16100f("lang_codes", _4fa295680821)
        _cc41b8f1f5b3     = _e305b72b6961._66dede16100f("sample_ids", _4fa295680821)
        _c71db774469f      = _e305b72b6961._66dede16100f("chunk_ids", _4fa295680821)
        _2565f3526dd2 = _e305b72b6961._66dede16100f("word_positions", _4fa295680821)
        _9ec082ca61e3    = _e305b72b6961._66dede16100f("prompt_lens", _4fa295680821)
        _9d5ef233c7ea = _e305b72b6961._66dede16100f("num_chunks", _4fa295680821)

        _4a64e91f1095 = _5f5f9e7fa83a._260ad1b4dd18(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _bcb8eb0ca624 = [_c36d9bb81aeb(_178478a02746) for _178478a02746 in _2565f3526dd2]
        _3afd2638e3c6 = _c1d544a1f915(_bcb8eb0ca624)
        _0444fcdb3d34 = self._153b1d198dec(
            _5f5f9e7fa83a,
            # max_new_tokens=64,
            # do_sample=False,
            # temperature=None,     # for deterministic answers
            # top_p=None,           # for deterministic answers
            # repetition_penalty=1.2,
            # fully deterministic decoding
            _cc217da3be56=_3afd2638e3c6,        # hard cap on number of generated tokens
            _fedf15443566=_3afd2638e3c6,        # forces fixed-length output (prevents early EOS)
            _472f84085822=_ef4c66fa8dbf,          # disables sampling ; greedy decoding
            _80a67c144604=1,              # no beam search ; single deterministic path
            _4cdddc7c6de9=1.0,          # 1.2 with do_sample True; neutral temperature (no probability scaling)
            _304c946bac7d=1.0,                # disables nucleus filtering
            # repetition_penalty=1.0,   # no penalty for repeated tokens
            # length_penalty=1.0,       # no bias toward shorter/longer sequences
            # early_stopping=True,     # do not stop on EOS before min_new_tokens
            _616369f492dd=_fcad1e1d9bc5,           # reuse KV cache for consistent + faster decoding
            _4d7a84cd828f=self._4d7a84cd828f,
        )

        if _a176924bfca5 == 0:
            try:
                _8e00933065b7(
                    f"TEST TEST BATCH {_a176924bfca5} Input IDs: {_5f5f9e7fa83a._b52daafee6d7()[0]}, "
                    f"Generated IDs: {_0444fcdb3d34._b52daafee6d7()[0]}, "
                    f"Labels: {_5a28e3eba168._b52daafee6d7()[0]}"
                )
            except _136f84ce92aa:
                # printing should never crash testing
                pass


        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _4b305a0130f8 = []
        _9725f9a36973 = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _24512c575754 in _b36d53bf66ba(_4a64e91f1095):
            _4b305a0130f8._1a511bab9629(_0444fcdb3d34[_24512c575754]._e96e40d5974a()._e7c40d05734a())
            _9725f9a36973._1a511bab9629(_5a28e3eba168[_24512c575754]._e96e40d5974a()._e7c40d05734a())


        _4d3c203d86c5 = {
            "lang_codes": _18e80a1c320b,
            "preds": _4b305a0130f8,
            "labels": _9725f9a36973,
            "sample_ids": _cc41b8f1f5b3,
            "chunk_ids": _c71db774469f,
            "word_positions": _2565f3526dd2,
            "prompt_lens": _9ec082ca61e3,
            "num_chunks": _9d5ef233c7ea,
        }

        self._dae422a0ec75._1a511bab9629(_4d3c203d86c5)

        # Exact same cleanup as before
        del _5f5f9e7fa83a, _5a28e3eba168, _0444fcdb3d34, _4b305a0130f8, _9725f9a36973

        return _4d3c203d86c5

    def _52646ad74005(self):
        # pick correct device for this rank
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            if _18ce74297369._8e1f7539b9af._7438204551eb():
                _a4a060ee2039 = _18ce74297369._8e1f7539b9af._550eca9fdec8()
            else:
                _a4a060ee2039 = 0
            _18ce74297369._fb7f3cc5b839._fd0653efd207(_a4a060ee2039)
            self._4b7a48d6b477 = _18ce74297369._8078911a0ffb(f"cuda:{_a4a060ee2039}")
        else:
            self._4b7a48d6b477 = _18ce74297369._8078911a0ffb("cpu")

        _9fbdc5edac8f = self._74e47fab3ab6(
            self._7a56d685d9d1._a4b2f9f27421
        )
        self._c8000816d18d(_9fbdc5edac8f)

        _8e00933065b7(f"Test Allowed languages {_9fbdc5edac8f}")

        self._4d7a84cd828f = _10f60b654077([
            _19c16b8ce88d(
                _7c961a8914ff=[
                    _d85068d30d0c
                    for _04499eb884ac, _df5278c13fb3 in self._15ba210377ae._e5acc0bc36b4()
                    if self._a85116ed3c1c[_04499eb884ac] in _9fbdc5edac8f
                    for _d85068d30d0c in _df5278c13fb3
                ],
                _ceec7d2f2056=self._1409bcf2953c,
                _c8bed4259035=self._59ed64029177._c8bed4259035
            )
        ])

        self._ecba315819ea()
        
    def _c6485a25829e(self):
        _be0ab2d47c75 = _05d91581264c(self, "_test_outputs", _4fa295680821)
        _8e00933065b7(f"[DEBUG rank={_18ce74297369._8e1f7539b9af._550eca9fdec8()}] outputs_len={_c36d9bb81aeb(_be0ab2d47c75)}")
        if not _be0ab2d47c75:
            return

        _babe5f5cd429, _30ebe2facd48, _2865abd9876b, _5ca75941690c = \
            self._e12e5ed3a039(_be0ab2d47c75, _6cfc459cae65=_fcad1e1d9bc5)

        _a4e2d2cecd2f, _73d0b4d627e1 = [], []
        for _5b6239875a1a in _f8e07f5e0f31(_2865abd9876b._a632b92eb634()):
            _d13981820b35 = _babe5f5cd429[_5b6239875a1a]._b52daafee6d7()
            _db40adc41fde = _30ebe2facd48[_5b6239875a1a]._b52daafee6d7()
            _d55515fc4d29 = _2865abd9876b[_5b6239875a1a]
            _11ebe4363747 = _5ca75941690c[_5b6239875a1a]

            if _d55515fc4d29._50502a2a274d() > 0 and _11ebe4363747._50502a2a274d() > 0:
                _a4e2d2cecd2f._1a511bab9629(_d55515fc4d29)
                _73d0b4d627e1._1a511bab9629(_11ebe4363747)

        if not _a4e2d2cecd2f:
            _8e00933065b7("[TEST END] Nothing to score.")
            self._60dc9c3486a9._12a96df0ce6e()
            return

        _493d907ac790 = _18ce74297369._9fff19ed52bf(_a4e2d2cecd2f)._dbbde872cae8(_8078911a0ffb=self._892ce5e2edf7['micro_accuracy']._8078911a0ffb, _8e854892cdda=_fcad1e1d9bc5)
        _5a28e3eba168 = _18ce74297369._9fff19ed52bf(_73d0b4d627e1)._dbbde872cae8(_8078911a0ffb=self._892ce5e2edf7['micro_accuracy']._8078911a0ffb, _8e854892cdda=_fcad1e1d9bc5)

        self._892ce5e2edf7['micro_accuracy']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_accuracy']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_precision']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_recall']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['macro_f1']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_accuracy']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_precision']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_recall']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['classwise_f1']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)
        self._892ce5e2edf7['confmat']._be7f42ac5d6c(_493d907ac790, _5a28e3eba168)

        _7a576515e9cf  = self._892ce5e2edf7['micro_accuracy']._e843ecb1f5ba()._01e989591fe1()
        _c7c1c6da1c46  = self._892ce5e2edf7['macro_accuracy']._e843ecb1f5ba()._01e989591fe1()
        _aeef0df4c8e3 = self._892ce5e2edf7['macro_precision']._e843ecb1f5ba()._01e989591fe1()
        _8bcd17f371e5    = self._892ce5e2edf7['macro_recall']._e843ecb1f5ba()._01e989591fe1()
        _7f4f21ba441f        = self._892ce5e2edf7['macro_f1']._e843ecb1f5ba()._01e989591fe1()

        self._6fb4f2199d25("test_accuracy", _c7c1c6da1c46, _58ef7bb2578a=_fcad1e1d9bc5)

        try:
            _2ee4e802cee5 = self._50d606f6a153
            _f90c6413fd30 = {
                "epoch": [_2ee4e802cee5],
                "class_names": [self._a85116ed3c1c],
                "micro_accuracy": [_7a576515e9cf],
                "macro_accuracy": [_c7c1c6da1c46],
                "macro_precision": [_aeef0df4c8e3],
                "macro_recall": [_8bcd17f371e5],
                "macro_f1": [_7f4f21ba441f],
                "classwise_accuracy": [self._892ce5e2edf7['classwise_accuracy']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "classwise_precision": [self._892ce5e2edf7['classwise_precision']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "classwise_recall": [self._892ce5e2edf7['classwise_recall']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "classwise_f1": [self._892ce5e2edf7['classwise_f1']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
                "confusion_matrix": [self._892ce5e2edf7['confmat']._e843ecb1f5ba()._dbbde872cae8(_8078911a0ffb="cpu")._e08acbc94865()._b52daafee6d7()],
            }
            self._bff12dfb76aa(_f90c6413fd30, f"test_final.csv", _fa913b5acd26=self._fa913b5acd26)
        except _136f84ce92aa as _5af893fd5670:
            _8e00933065b7(f"[TEST END] save metrics FAILED: {_5af893fd5670}")

        # cleanup
        self._892ce5e2edf7['micro_accuracy']._6689e6300e85(); self._892ce5e2edf7['macro_accuracy']._6689e6300e85()
        self._892ce5e2edf7['macro_precision']._6689e6300e85(); self._892ce5e2edf7['macro_recall']._6689e6300e85(); self._892ce5e2edf7['macro_f1']._6689e6300e85()
        self._892ce5e2edf7['classwise_accuracy']._6689e6300e85(); self._892ce5e2edf7['classwise_precision']._6689e6300e85()
        self._892ce5e2edf7['classwise_recall']._6689e6300e85(); self._892ce5e2edf7['classwise_f1']._6689e6300e85()
        self._892ce5e2edf7['confmat']._6689e6300e85(); self._60dc9c3486a9._12a96df0ce6e()
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            _18ce74297369._fb7f3cc5b839._b01178574ffc()
        _8e00933065b7("[TEST END] Finished and cleaned up.")

    def _661a61dfac5b(self, _e305b72b6961, _a176924bfca5, _158aa4360e36=0):
        """Optimized prediction step with efficient memory handling."""
        _5f5f9e7fa83a, _ = _e305b72b6961
        _5f5f9e7fa83a = _5f5f9e7fa83a._dbbde872cae8(self._4b7a48d6b477, _8e854892cdda=_fcad1e1d9bc5)
        _be0ab2d47c75, _, _ = self(_5f5f9e7fa83a)
        _1d6d9ca4b9cc = _18ce74297369._43ec846708f0(_be0ab2d47c75, _e36ec35acba5=-1)
        del _5f5f9e7fa83a, _be0ab2d47c75
        if _18ce74297369._fb7f3cc5b839._b2aa76a80269():
            _18ce74297369._fb7f3cc5b839._b01178574ffc()
        return {"predictions": _1d6d9ca4b9cc._e7c40d05734a()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _96137f29c1e8(self, _bfe43eb29bad, _dc209acef261):
        # if sep token not present then just tuple the tokens and return
        if _dc209acef261 is _4fa295680821:
            return [(_a4f0f1ad595e,) for _a4f0f1ad595e in _bfe43eb29bad]

        _9b25a55db3b4 = []
        _c47bdc5d3eb9 = []

        for _a4f0f1ad595e in _bfe43eb29bad:
            if _a4f0f1ad595e == _dc209acef261:
                if _c47bdc5d3eb9:
                    _9b25a55db3b4._1a511bab9629(_bdc17ddb981e(_c47bdc5d3eb9))
                    _c47bdc5d3eb9 = []
            else:
                if _dc209acef261 == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _a4f0f1ad595e in _c47bdc5d3eb9:
                        continue
                    else:
                        _c47bdc5d3eb9._1a511bab9629(_a4f0f1ad595e)
                    
                else:
                    _c47bdc5d3eb9._1a511bab9629(_a4f0f1ad595e)

        if _c47bdc5d3eb9:
            _9b25a55db3b4._1a511bab9629(_bdc17ddb981e(_c47bdc5d3eb9))

        return _9b25a55db3b4

    def _d5dc2c8bd407(self, _c49f63c8df0c, _1ef6665697ce="exact_match", _4c196e600d32=_4fa295680821):
        if not _c49f63c8df0c:
            return _4c196e600d32

        if _1ef6665697ce == "exact_match":
            return _c49f63c8df0c[0] if _439b13f19019(_7fa49bc953ba == _c49f63c8df0c[0] for _7fa49bc953ba in _c49f63c8df0c) else _4c196e600d32

        if _1ef6665697ce == "most_common":
            return _3859e5934dd4(_c49f63c8df0c)._a250416ee3c9(1)[0][0]

        if _1ef6665697ce == "first":
            return _c49f63c8df0c[0]

        raise _ae486ea6f7f0(f"Unknown vote mode: {_1ef6665697ce}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _2b1aa8271046(self, _798e56744b67):
        _960c1d2af216 = _e470473f1113(_a4f0f1ad595e for _df5278c13fb3 in self._15ba210377ae._c49f63c8df0c() for _a4f0f1ad595e in _df5278c13fb3)
        return _bdc17ddb981e(_a4f0f1ad595e for _a4f0f1ad595e in _798e56744b67 if _a4f0f1ad595e in _960c1d2af216)


    def _47b258920979(self, _be0ab2d47c75, _108091059d7e=_fcad1e1d9bc5, _cb3f62f27b8e="cpu", _6cfc459cae65=_ef4c66fa8dbf):
        from _30b498e81767 import _9ae885a9674a
        import _18ce74297369

        _e8c793919898 = self._4ec41e2281f8
        _dc209acef261 = self._1409bcf2953c
        _9b27680a8385 = self._40e7de653ea5

        def _8b524102b317(_5fab92a624e3):
            if _039628450a64(_5fab92a624e3, _18ce74297369._3a0eddc10aea):
                return _5fab92a624e3._e96e40d5974a()._dbbde872cae8(_8078911a0ffb=_cb3f62f27b8e)._9faa5bbcdafc(-1)._b52daafee6d7()
            return _e603872a5b35(_5fab92a624e3) if _039628450a64(_5fab92a624e3, (_e603872a5b35, _bdc17ddb981e)) else [_5fab92a624e3]

        _daa814b8907f = _e470473f1113()
        _4def73a02288 = _9ae885a9674a(_e603872a5b35)
        _fe12eaa770fb = _9ae885a9674a(_4c835be6dcaa)
        _c4c7ad42a458 = []

        if _108091059d7e:
            _8e00933065b7(f"[reconcile] start: num_outputs={_c36d9bb81aeb(_be0ab2d47c75)}")

        for _9b17cbf4b7aa in _be0ab2d47c75:
            _cc41b8f1f5b3 = _9b17cbf4b7aa["sample_ids"]
            _c71db774469f = _9b17cbf4b7aa["chunk_ids"]
            _461e55c5b1e1 = _9b17cbf4b7aa["preds"]
            _acf547b0fc13 = _9b17cbf4b7aa["labels"]
            _2565f3526dd2 = _9b17cbf4b7aa["word_positions"]
            _9ec082ca61e3 = _9b17cbf4b7aa["prompt_lens"]
            _a59bfec41d03 = _9b17cbf4b7aa["num_chunks"]

            for _24512c575754, _5b6239875a1a in _808d5ec65a8a(_cc41b8f1f5b3):
                _02a63893203b = _4c835be6dcaa(_c71db774469f[_24512c575754])
                if (_5b6239875a1a, _02a63893203b) in _daa814b8907f:
                    continue
                _daa814b8907f._7f36987b4c3c((_5b6239875a1a, _02a63893203b))

                _fe12eaa770fb[_5b6239875a1a] = _4c835be6dcaa(_a59bfec41d03[_24512c575754])
                _c6479fa526b0 = _4c835be6dcaa(_9ec082ca61e3[_24512c575754])
                _e04db1e17a9e = _44b274c14f37(_2565f3526dd2[_24512c575754])
                
                # Right pad 
                # preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_raw = to_list(chunk_labels[i])[prompt_len_i:]

                # left pad
                # preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                # labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _2dc5cb65e5d4  = _44b274c14f37(_461e55c5b1e1[_24512c575754])
                _de4f07dd07b8 = _44b274c14f37(_acf547b0fc13[_24512c575754])

                _d9f30a20e207  = [_56b257b60858 for _56b257b60858, _6d5a6deaeb22 in _d41302f192a1(_2dc5cb65e5d4, _de4f07dd07b8) if _6d5a6deaeb22 != _e8c793919898]
                _6f1fc9b1e6d7 = [_6d5a6deaeb22 for _6d5a6deaeb22 in _de4f07dd07b8 if _6d5a6deaeb22 != _e8c793919898]
                #PROMPT LEN
                # if not left_pad:
                #     preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                #     labels_raw = to_list(chunk_labels[i])[prompt_len_i:]
                # else:
                #     preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                #     labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _5c6ee01075f4 = [_56b257b60858 for _56b257b60858 in _d9f30a20e207 if _56b257b60858 != _e8c793919898]
                _d6719f220df6 = [_6d5a6deaeb22 for _6d5a6deaeb22 in _6f1fc9b1e6d7 if _6d5a6deaeb22 != _e8c793919898]

                if _5b6239875a1a not in _c4c7ad42a458:
                    _c4c7ad42a458._1a511bab9629(_5b6239875a1a)

                _4def73a02288[_5b6239875a1a]._1a511bab9629((_02a63893203b, _e04db1e17a9e, _5c6ee01075f4, _d6719f220df6))

        _55149ea6da77 = _4fa295680821
        _babe5f5cd429 = {}
        _30ebe2facd48 = {}

        for _5b6239875a1a in _c4c7ad42a458:
            _8a34c99963c6 = _4def73a02288[_5b6239875a1a]
            if _c36d9bb81aeb(_8a34c99963c6) != _fe12eaa770fb[_5b6239875a1a]:
                if _108091059d7e:
                    _8e00933065b7(f"Skipping sample {_5b6239875a1a}: expected {_fe12eaa770fb[_5b6239875a1a]} chunks, got {_c36d9bb81aeb(_8a34c99963c6)}")
                continue

            _8a34c99963c6._7e61bb914efd(_b23c67f79286=lambda _5fab92a624e3: _5fab92a624e3[0])

            if _55149ea6da77 is _4fa295680821 and _c36d9bb81aeb(_8a34c99963c6) > 1:
                _55149ea6da77 = _5b6239875a1a

            # Split into words
            _771525af973e = []
            for _02a63893203b, _310790c98cee, _a470014f8e64, _b3f4bd8b5652 in _8a34c99963c6:
                _5965b55ae010 = self._497b37e240b2(_310790c98cee, -1)
                _2e00f852d020 = self._497b37e240b2(_a470014f8e64, _dc209acef261)
                _b60a3891175e = self._497b37e240b2(_b3f4bd8b5652, _dc209acef261)
                _33f2f3ebfd4d = _c36d9bb81aeb(_5965b55ae010)
                if _c36d9bb81aeb(_2e00f852d020) < _33f2f3ebfd4d:
                    _2e00f852d020 += [(_9b27680a8385,)] * (_33f2f3ebfd4d - _c36d9bb81aeb(_2e00f852d020))
                if _c36d9bb81aeb(_b60a3891175e) < _33f2f3ebfd4d:
                    _b60a3891175e += [(_e8c793919898,)] * (_33f2f3ebfd4d - _c36d9bb81aeb(_b60a3891175e))
                _771525af973e._1a511bab9629((_5965b55ae010, _2e00f852d020, _b60a3891175e))

            # Vote per word position
            _69713153d837 = _9ae885a9674a(_e603872a5b35)
            _31a137ba3ac3 = _9ae885a9674a(_e603872a5b35)
            for _5965b55ae010, _2e00f852d020, _b60a3891175e in _771525af973e:
                for _178478a02746, _88ff517b4265, _ab7cc58041b6 in _d41302f192a1(_5965b55ae010, _2e00f852d020, _b60a3891175e):
                    _310790c98cee = _178478a02746[0]
                    # pred_votes[pos].append(wpred)
                    _0a05eeb5fc5b = self._5a6ece41f573(_88ff517b4265)
                    if _0a05eeb5fc5b:
                        _69713153d837[_310790c98cee]._1a511bab9629(_0a05eeb5fc5b)
                    else:
                        _69713153d837[_310790c98cee]._1a511bab9629((_9b27680a8385,))

                    _31a137ba3ac3[_310790c98cee]._1a511bab9629(_ab7cc58041b6)

            _ed124a0bbe08 = _f8e07f5e0f31(_69713153d837._a632b92eb634())

            _cb4776b3de42 = [self._fb80a55cff57(_69713153d837[_56b257b60858], _1ef6665697ce="most_common", _4c196e600d32=(_9b27680a8385,)) for _56b257b60858 in _ed124a0bbe08]
            _98392abd7c23 = []
            for _56b257b60858 in _ed124a0bbe08:
                _756451129c4c = _31a137ba3ac3[_56b257b60858]
                _bf75dca96c14 = self._fb80a55cff57(_756451129c4c, _1ef6665697ce="most_common", _4c196e600d32=_4fa295680821)
                if _bf75dca96c14 is _4fa295680821:
                    for _f7c24aec84b5 in _756451129c4c:
                        if _e8c793919898 not in _f7c24aec84b5:
                            _bf75dca96c14 = _f7c24aec84b5
                            break
                    if _bf75dca96c14 is _4fa295680821:
                        _bf75dca96c14 = _756451129c4c[0]
                _98392abd7c23._1a511bab9629(_bf75dca96c14)

            # Reconstruct
            _76220212b2f0 = []
            _79aac04f96fc = []
            for _24512c575754 in _b36d53bf66ba(_c36d9bb81aeb(_ed124a0bbe08)):
                _76220212b2f0._861629f39c35(_cb4776b3de42[_24512c575754])
                _79aac04f96fc._861629f39c35(_98392abd7c23[_24512c575754])
                if _24512c575754 < _c36d9bb81aeb(_ed124a0bbe08) - 1:
                    _76220212b2f0._1a511bab9629(_dc209acef261)
                    _79aac04f96fc._1a511bab9629(_dc209acef261)

            # print(f"check labels final {(sum(1 for x in recon_labels if x == sep_token))}")

            _babe5f5cd429[_5b6239875a1a] = _18ce74297369._8a1b70327af7(_76220212b2f0, _8078911a0ffb=_cb3f62f27b8e)
            _30ebe2facd48[_5b6239875a1a] = _18ce74297369._8a1b70327af7(_79aac04f96fc, _8078911a0ffb=_cb3f62f27b8e)

        if _108091059d7e and _55149ea6da77 is not _4fa295680821:
            _8e00933065b7(f"[SUMMARY] reconciled samples in batch = {_c36d9bb81aeb(_c4c7ad42a458)} "
                f"sid={_55149ea6da77} total_preds={_c36d9bb81aeb(_babe5f5cd429[_55149ea6da77])} "
                f"total_labels={_c36d9bb81aeb(_30ebe2facd48[_55149ea6da77])} "
                f"raw_preds {_babe5f5cd429[_55149ea6da77]} and raw_labels {_30ebe2facd48[_55149ea6da77]} "
                f"chunks {_4def73a02288[_55149ea6da77]}")

        _da5302a0e5f1 = _5de4ff660788(_c36d9bb81aeb(_6d5a6deaeb22) for _6d5a6deaeb22 in _30ebe2facd48._c49f63c8df0c())
        _8e00933065b7(f"Total reconciled labels: {_da5302a0e5f1}")

        _227c3530eda8, _bb9ce12c44dd = self._18965c95c540(
            _babe5f5cd429, _30ebe2facd48, _108091059d7e=_108091059d7e, _cb3f62f27b8e=_cb3f62f27b8e
        )
        _01967574b671 = _5de4ff660788(_c36d9bb81aeb(_6d5a6deaeb22) for _6d5a6deaeb22 in _bb9ce12c44dd._c49f63c8df0c())
        _8e00933065b7(f"Total reconciled labels classes: {_01967574b671}")

        _c06ccc6f21e1 = _18ce74297369._8e1f7539b9af._550eca9fdec8() if _18ce74297369._8e1f7539b9af._7438204551eb() else -1
        _8e00933065b7(f"Rank {_c06ccc6f21e1} samples are {_c4c7ad42a458}")

        return _babe5f5cd429, _30ebe2facd48, _227c3530eda8, _bb9ce12c44dd

    def _5e699b9cd1a3(self, _babe5f5cd429, _30ebe2facd48, _108091059d7e=_fcad1e1d9bc5, _cb3f62f27b8e="cpu"):
        _7cb2ec1d5d14 = _05d91581264c(self, "seq2class", {})
        _dc209acef261 = _05d91581264c(self, "tokenizer_separator_token", _4fa295680821)
        _e8c793919898 = _05d91581264c(self, "ignore_idx", -100)
        
        def _9dda388f34db(_bfe43eb29bad, _c890b963cebe):
            _9b25a55db3b4 = []
            _cff67e2b1099 = []
            for _24512c575754, _a6d5160b4ab7 in _808d5ec65a8a(_bfe43eb29bad):
                if _a6d5160b4ab7 == _c890b963cebe and _cff67e2b1099:
                    _9b25a55db3b4._1a511bab9629(_cff67e2b1099)
                    _cff67e2b1099 = []
                elif _a6d5160b4ab7 != _c890b963cebe:
                    _cff67e2b1099._1a511bab9629(_a6d5160b4ab7)
            if _cff67e2b1099:
                _9b25a55db3b4._1a511bab9629(_cff67e2b1099)
            return _9b25a55db3b4
        
        def _07a6fc15ba8b(_de4da89cf1e0, _7cb2ec1d5d14, _108091059d7e, _5b6239875a1a):
            _9b17cbf4b7aa = []
            _02fe133db578 = _f8e07f5e0f31(_7cb2ec1d5d14._a632b92eb634(), _b23c67f79286=_c36d9bb81aeb, _81a95b0331c6=_fcad1e1d9bc5)
            for _24512c575754, _74b37875c12e in _808d5ec65a8a(_de4da89cf1e0, 1):
                _9fdcd268741c = _bdc17ddb981e(_74b37875c12e)
                _b578bf25dcac = self._40e7de653ea5
                for _b23c67f79286 in _02fe133db578:
                    if _c36d9bb81aeb(_9fdcd268741c) >= _c36d9bb81aeb(_b23c67f79286) and _9fdcd268741c[:_c36d9bb81aeb(_b23c67f79286)] == _b23c67f79286:
                        _b578bf25dcac = _7cb2ec1d5d14[_b23c67f79286]
                        break
                _9b17cbf4b7aa._1a511bab9629(_b578bf25dcac)

            return _9b17cbf4b7aa
        
        _2865abd9876b, _5ca75941690c = {}, {}
        for _5b6239875a1a in _babe5f5cd429:
            _56b257b60858 = _babe5f5cd429[_5b6239875a1a]
            _6d5a6deaeb22 = _30ebe2facd48._66dede16100f(_5b6239875a1a, _4fa295680821)
            _493d907ac790 = _56b257b60858._b52daafee6d7() if _039628450a64(_56b257b60858, _18ce74297369._3a0eddc10aea) else _e603872a5b35(_56b257b60858)
            _5a28e3eba168 = _6d5a6deaeb22._b52daafee6d7() if _039628450a64(_6d5a6deaeb22, _18ce74297369._3a0eddc10aea) else _e603872a5b35(_6d5a6deaeb22) if _6d5a6deaeb22 else _4fa295680821
            if _5a28e3eba168 is not _4fa295680821:
                _11dd6bfa7930 = _83a4cf7f7426(_5a28e3eba168, _dc209acef261)
                _4f2d8f873f60 = _b65edb5f9561(_11dd6bfa7930, _7cb2ec1d5d14, _5b6239875a1a == 1 or _108091059d7e, _5b6239875a1a)
                _0191b5aff008 = _83a4cf7f7426(_493d907ac790, _dc209acef261)
                _d55bb74a4256 = _b65edb5f9561(_0191b5aff008, _7cb2ec1d5d14, _5b6239875a1a == 1 or _108091059d7e, _5b6239875a1a)
                if _c36d9bb81aeb(_d55bb74a4256) < _c36d9bb81aeb(_4f2d8f873f60):
                    _d55bb74a4256 += [0] * (_c36d9bb81aeb(_4f2d8f873f60) - _c36d9bb81aeb(_d55bb74a4256))
                elif _c36d9bb81aeb(_d55bb74a4256) > _c36d9bb81aeb(_4f2d8f873f60):
                    _d55bb74a4256 = _d55bb74a4256[:_c36d9bb81aeb(_4f2d8f873f60)]
            else:
                _0191b5aff008 = _83a4cf7f7426(_493d907ac790, _dc209acef261)
                _d55bb74a4256 = _b65edb5f9561(_0191b5aff008, _7cb2ec1d5d14, _5b6239875a1a == 1 or _108091059d7e, _5b6239875a1a)
                _4f2d8f873f60 = [_e8c793919898] * _c36d9bb81aeb(_d55bb74a4256)
            _2865abd9876b[_5b6239875a1a] = _18ce74297369._8a1b70327af7(_d55bb74a4256, _8078911a0ffb=_cb3f62f27b8e, _4b779a0fad4b=_18ce74297369._5be207d527a1)
            _5ca75941690c[_5b6239875a1a] = _18ce74297369._8a1b70327af7(_4f2d8f873f60, _8078911a0ffb=_cb3f62f27b8e, _4b779a0fad4b=_18ce74297369._5be207d527a1)
        return _2865abd9876b, _5ca75941690c

    def _ba14498e58d2(self, _038c791a92e4):
        _18ce74297369._951d1ac253a3._d6a7e73f98f2._e58df3b36a82(self._9facccfab45c(), _ef20c5afc9b8=1.0)
    
    def _bdd9c04130e4(self, _038c791a92e4):
        for _c6e471b78b1a in self._9facccfab45c():
            if _c6e471b78b1a is not _4fa295680821:
                _c6e471b78b1a._5da44010b1da._1094e3b31c96(-5, 5)

    def _a1a4afbf62ee(self):
        _4f17d12c9369 = 0
        for _c6e471b78b1a in self._9facccfab45c():
            if _c6e471b78b1a._225d383a0c60 is not _4fa295680821:
                _ef8aa8a5b44a = _c6e471b78b1a._225d383a0c60._e96e40d5974a()._5da44010b1da._0a05eeb5fc5b(2)
                _4f17d12c9369 += _ef8aa8a5b44a._01e989591fe1() ** 2
        return _4f17d12c9369 ** 0.5  # L2 norm

    def _95583bd6a9ee(self):
        _973e3e47f834 = [_56b257b60858 for _56b257b60858 in self._9facccfab45c() if _56b257b60858._5c0dbc0caa93]
        if not _973e3e47f834:
            _8e00933065b7("No trainable parameters. Skipping optimizer creation.")
            return _4fa295680821
        
        _2edad716634a = _4f5ae51eaa76(lambda _56b257b60858: _56b257b60858._5c0dbc0caa93, self._9facccfab45c())

        _f3ad9eafacf3 = {
            "adamw": _18ce74297369._0bfde30192e6._997a10d36ae6,
            "adamax": _18ce74297369._0bfde30192e6._9c2c98bf1fc5,
            "adam": _18ce74297369._0bfde30192e6._c296b518408f,
        }
        _aef7fb659fa3 = _f3ad9eafacf3._66dede16100f(self._3ce2560f60d8._c82772026d30(), _18ce74297369._0bfde30192e6._c296b518408f)

        _038c791a92e4 = _aef7fb659fa3(_2edad716634a, _deaa03a51113=self._130fa1b0e61c._deaa03a51113, _fe7f593b34c1=0.001)

        _e6ebdfd4e3a3 = self._7a56d685d9d1._db3506872463
        _9d86ff501306 = _ee703a0a843e._d2678e35624d(0.1 * _e6ebdfd4e3a3)

        _bfeb1badeefd = _18ce74297369._0bfde30192e6._ecf638865047._4e3653963459(_038c791a92e4, _14958a71d857=lambda _672e6a7f7951: (_672e6a7f7951 + 1) / _9d86ff501306)

        _4439076ddb35 = _18ce74297369._0bfde30192e6._ecf638865047._bbe55b1963dc(
            _038c791a92e4,
            _ce67004bcd2a=_c1d544a1f915(1, _e6ebdfd4e3a3 - _9d86ff501306),
            _44aee6ed54b8=2,
            _81673703defa=1e-6
        )
        _ecf638865047 = _18ce74297369._0bfde30192e6._ecf638865047._21f822f319f0(
            _038c791a92e4,
            _dc843dfa1390=[_bfeb1badeefd, _4439076ddb35],
            _e3cf1e0d538f=[_9d86ff501306]
        )
        return {"optimizer": _038c791a92e4, "lr_scheduler": {"scheduler": _ecf638865047, "interval": "epoch", "monitor": "val_loss"}}
