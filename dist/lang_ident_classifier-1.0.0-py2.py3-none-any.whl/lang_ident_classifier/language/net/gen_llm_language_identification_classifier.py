# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _579753e9320d, _01a85d4b5834
import copy
from _7127a9e5bdbc import _96113affd2ee
import _b129d38d9c91
import math
import os
from typing import _41c533176210
import _d721fb76c325 as _2d0e022b005b
import _4415dfc760d6 as _38334ca44edf
import _22f79c2ae8bd
import _c86dffa1d79f as _98774985bad0
from _1e820a7419d5 import _ff5b08f5f2df, _ddc8d5de8b65
from _1e820a7419d5._9dad728d1b45._149882869e16._533ff7665b63 import _b630527c429f
from _1afe797e30f6 import _99886a82cec9, _edc5cbacc129, _e6cb4142eece, _5b05c89c3843, _ae7e83ac6721

from _206753bfebfd._a8cb2d0bf0ad._b0b760f92cc9._2989b6e5c9b1 import _634b714c75b7
from _206753bfebfd._a8cb2d0bf0ad._a06dbc245a08._a203f69ea7ab import _ab10cc27ce41
from _206753bfebfd._a8cb2d0bf0ad._a06dbc245a08._6a83b9800570 import _e7e6e4efe329
from _206753bfebfd._a8cb2d0bf0ad._a06dbc245a08._e7e6ed7f4db6 import _a4e1cd1fe2ee
from _206753bfebfd._a8cb2d0bf0ad._adf3aef31199._7bc665e3399c import _f7aa304bfc00
# expose only the classifier from the module
_01df358c3a48 = ["GenLLMLanguageIdentificationClassifier"]

_ddb71ff82420 = 'cuda' if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd() else 'cpu'
_d56b1900c94a = _9f5ce76e7050  # global frozen embedding (kept for compatibility)


class _f244204c93bb(_ff5b08f5f2df):
    def _57cc85b51d08(self, _0cdff9ffaba2, _bcdfa6d24f0e=_9f5ce76e7050, _aa3213c4d689=_9f5ce76e7050):
        self._8ac972e79cb9 = _45a52a008360(_0cdff9ffaba2)
        self._782817a8da55 = _bcdfa6d24f0e
        self._92d70c2f289e = _aa3213c4d689

    def _26401ac6f7af(self, _930928b40865, _33f7bc79c1ec):
        _16ee08b11c92 = _22f79c2ae8bd._e0aff82d825d(_33f7bc79c1ec, _370cd5a374fa("-inf"))

        for _2895904574cf in self._8ac972e79cb9:
            _16ee08b11c92[:, _2895904574cf] = 0.0

        if self._782817a8da55 is not _9f5ce76e7050:
            _16ee08b11c92[:, self._782817a8da55] = 0.0

        if self._92d70c2f289e is not _9f5ce76e7050:
            _16ee08b11c92[:, self._92d70c2f289e] = 0.0

        return _33f7bc79c1ec + _16ee08b11c92
    
class _52f8d05d77af(_98774985bad0._d83b093bc2f5):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """
    _3b7bf02c427d = {}

    class _de4cdaa738f0(_22f79c2ae8bd._a23190b10449._cf4b7dc47dfd):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _57cc85b51d08(self, _2d0a9d4e7fb4: _63db5a091a06, _f7265dfbc2a9: _63db5a091a06 = 64):
            _a408a677567a()._53b05bba408c()
            self._e0768cb58984 = _22f79c2ae8bd._a23190b10449._1414756a5493(_2d0a9d4e7fb4, _f7265dfbc2a9, _e7dcb6126c8e=_7e747897cf37)
            self._6cf448ba8f95 = _22f79c2ae8bd._a23190b10449._c892fcd276f2(_9bf9365efc6b=_6f286ccafa31)
            self._5794bbc0cc4d = _22f79c2ae8bd._a23190b10449._1414756a5493(_f7265dfbc2a9, _2d0a9d4e7fb4, _e7dcb6126c8e=_7e747897cf37)
            # start adapter near-zero so initial behavior is identity
            _22f79c2ae8bd._a23190b10449._2b7a7e7e6805._ae1556c5348b(self._5794bbc0cc4d._770e4ce42a98)
            _22f79c2ae8bd._a23190b10449._2b7a7e7e6805._45341475d800(self._e0768cb58984._770e4ce42a98, _fe3c80544f32=math._19ec0bfe5a27(5))

        def _2e6ed31cab5f(self, _f9877cd87da8: _22f79c2ae8bd._48448c804dbc) -> _22f79c2ae8bd._48448c804dbc:
            # supports x shape (B, L, D) or (B, D)
            if _f9877cd87da8._2d0a9d4e7fb4() == 2:
                _9141c4c81351 = self._5794bbc0cc4d(self._6cf448ba8f95(self._e0768cb58984(_f9877cd87da8)))
                return _f9877cd87da8 + _9141c4c81351
            _ad9d36d99224, _43b4fa0979f6, _4b08ebf47639 = _f9877cd87da8._e13bed6de027
            _ad4862ff7d0e = _f9877cd87da8._bc533c8e4114(-1, _4b08ebf47639)                    # (B*L, D)
            _ad4862ff7d0e = self._5794bbc0cc4d(self._6cf448ba8f95(self._e0768cb58984(_ad4862ff7d0e)))  # (B*L, D)
            _ad4862ff7d0e = _ad4862ff7d0e._bc533c8e4114(_ad9d36d99224, _43b4fa0979f6, _4b08ebf47639)
            return _f9877cd87da8 + _ad4862ff7d0e


    class _3e6ce56c5646(_22f79c2ae8bd._a23190b10449._cf4b7dc47dfd):
        def _57cc85b51d08(self, _2d0a9d4e7fb4: _63db5a091a06, _e29283df87cb: _22f79c2ae8bd._a23190b10449._cf4b7dc47dfd, _f7265dfbc2a9: _63db5a091a06 = 64):
            _a408a677567a()._53b05bba408c()
            self._e0768cb58984 = _22f79c2ae8bd._a23190b10449._1414756a5493(_2d0a9d4e7fb4, _f7265dfbc2a9, _e7dcb6126c8e=_7e747897cf37)
            self._6cf448ba8f95 = _22f79c2ae8bd._a23190b10449._c892fcd276f2(_9bf9365efc6b=_6f286ccafa31)
            self._5794bbc0cc4d = _22f79c2ae8bd._a23190b10449._1414756a5493(_f7265dfbc2a9, _2d0a9d4e7fb4, _e7dcb6126c8e=_7e747897cf37)
            self._e29283df87cb = _e29283df87cb

            _22f79c2ae8bd._a23190b10449._2b7a7e7e6805._ae1556c5348b(self._5794bbc0cc4d._770e4ce42a98)
            _22f79c2ae8bd._a23190b10449._2b7a7e7e6805._45341475d800(self._e0768cb58984._770e4ce42a98, _fe3c80544f32=math._19ec0bfe5a27(5))

        def _7c2541f7d2fd(self, _a200a38fa5c4):
            if _a200a38fa5c4._2d0a9d4e7fb4() == 3:
                _ad9d36d99224, _43b4fa0979f6, _4b08ebf47639 = _a200a38fa5c4._e13bed6de027
                _ad4862ff7d0e = _a200a38fa5c4._bc533c8e4114(-1, _4b08ebf47639)
                _ad4862ff7d0e = _ad4862ff7d0e + self._5794bbc0cc4d(self._6cf448ba8f95(self._e0768cb58984(_ad4862ff7d0e)))
                return _ad4862ff7d0e._bc533c8e4114(_ad9d36d99224, _43b4fa0979f6, _4b08ebf47639)
            return _a200a38fa5c4 + self._5794bbc0cc4d(self._6cf448ba8f95(self._e0768cb58984(_a200a38fa5c4)))

        def _2e6ed31cab5f(self, _a200a38fa5c4):
            _a200a38fa5c4 = self._54a385bf2525(_a200a38fa5c4)
            return self._e29283df87cb(_a200a38fa5c4)

    class _56a10121e31b(_22f79c2ae8bd._a23190b10449._cf4b7dc47dfd):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _57cc85b51d08(self, _38c09d6967fd, _5ed360b19021=-5, _c68ee5f1f15c=5):
            _a408a677567a()._53b05bba408c()
            self._38c09d6967fd = _38c09d6967fd
            self._5ed360b19021 = _5ed360b19021
            self._c68ee5f1f15c = _c68ee5f1f15c
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _2e6ed31cab5f(self, *_8de4952e32d2, **_47bacf7e9ce4):
            _8de4952e32d2 = _02c849d7c172(
                _0add36920341._21ce1385ea5b(_22f79c2ae8bd._d5ab54d656e5)._1b6c9f6e696f(-10, 10) if _351eebf587ec(_0add36920341, _22f79c2ae8bd._48448c804dbc) and _0add36920341._a313c9f76a9f != _22f79c2ae8bd._d5ab54d656e5 else _0add36920341
                for _0add36920341 in _8de4952e32d2
            )
            for _4884ccc7d273, _0add36920341 in _40fd1d7ef032(_8de4952e32d2):
                if _351eebf587ec(_0add36920341, _22f79c2ae8bd._48448c804dbc) and not _22f79c2ae8bd._79b9e107c6eb(_0add36920341)._6425a7887113():
                    _0add36920341 = _22f79c2ae8bd._5aa5d89a859f(_0add36920341)
            _f5db263bc330 = self._38c09d6967fd(*_8de4952e32d2, **_47bacf7e9ce4)
            if _351eebf587ec(_f5db263bc330, _22f79c2ae8bd._48448c804dbc):
                _f5db263bc330 = _f5db263bc330._21ce1385ea5b(_22f79c2ae8bd._d5ab54d656e5)
                if not _22f79c2ae8bd._79b9e107c6eb(_f5db263bc330)._6425a7887113():
                    _f5db263bc330 = _22f79c2ae8bd._5aa5d89a859f(_f5db263bc330)
                _f5db263bc330._600bf48bbbcd(self._5ed360b19021, self._c68ee5f1f15c)
            return _f5db263bc330

    # --- original __init__ signature and body preserved ---
    def _57cc85b51d08(
        self,
        _50117d945c3a,
        _857f2d1e364a,
        _c4ff59e997a0,
        _18c52502a05c,
        _52ff027a34e6,
        _2f141487c4a0,
        _99a2c39003db,
        _cc0a785f369e,
        _50950dcfa09c,
        _f568b9c9d391,
        _937c35874f15,
        _3fa913508536: _63db5a091a06 = 20,
        _e993bec3b8f8 = _9f5ce76e7050,
        _683b614b87ee=_9f5ce76e7050,
        _8ed394fdf56b=0.9,
        _143e2a211dfc:_3dfdef28f84c=_9f5ce76e7050,
    ):
        _a408a677567a(_41f95b47759a, self)._53b05bba408c()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._5f2d3b547e07({
            "lr": _370cd5a374fa(_c4ff59e997a0),
            "optimizer": _3dfdef28f84c(_18c52502a05c),
            "num_backbone_model_units_unfrozen": _63db5a091a06(_99a2c39003db),
            "loss_type": _3dfdef28f84c(_cc0a785f369e),
            "is_train": _b2f3b0033b3a(_50950dcfa09c),
            "random_seed": _63db5a091a06(_3fa913508536),
        })
        self._3fa913508536 = _3fa913508536
        _98774985bad0._9e9a2ccc3c0d(_3fa913508536, _ae7cd1e24484=_6f286ccafa31)
        _22f79c2ae8bd._977e11e18838(_3fa913508536)
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            _22f79c2ae8bd._94cc49ef777c._837bb1b04b1e(_3fa913508536)
        _2d0e022b005b.random._7bc2f188cad5(_3fa913508536)
        self._ed56cea9b110 = 0.2
        self._683b614b87ee = _63db5a091a06(_683b614b87ee) if _683b614b87ee is not _9f5ce76e7050 else _9f5ce76e7050
        _f568b9c9d391._3993832e08e5 = "left"
        self._f568b9c9d391 = _f568b9c9d391
        self._143e2a211dfc = _143e2a211dfc
        self._a00c01f29837 = 0.2 # for preventing model shift dominance
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
        #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
        #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
        #     print(f"Added padding token  <PAD> with (id: {tid})")
        if not self._f568b9c9d391._f68f68c20b0d:
            self._f568b9c9d391._8a4e36a57400(["_P"], _ce9ba54979d7=_7e747897cf37)
            _2895904574cf = self._f568b9c9d391._2794d6118c40("_P")
            self._f568b9c9d391._f68f68c20b0d = _2895904574cf
            _5ca5f56b5416(f"Added padding token  _P with (id: {_2895904574cf})")
        
        # self.tokenizer_separator_token = tokenizer.encode(" ", add_special_tokens=False)[0]
        self._5d0d28dc4a97 = _f568b9c9d391._4932bc9f97c8("||", _eef081ad8179=_7e747897cf37)[0]
        self._6c69f304a217 = (
            _22f79c2ae8bd._c861017b4e3e("cuda:{}"._272429a7612d(_2f141487c4a0["gpu_local_rank"]))
            if _2f141487c4a0["gpu_local_rank"] != -1
            else "cpu"
        )
        self._e993bec3b8f8 = _e993bec3b8f8
        self._8ed394fdf56b = _8ed394fdf56b
        self._857f2d1e364a =  ["unk"] + _857f2d1e364a if self._8ed394fdf56b > 0 else _857f2d1e364a
        self._023e1bc29369 = _7a68e1d47bdf(self._857f2d1e364a)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._03e93277f31e = {}
        # FOR NEW TOKEN COMMENT THIS
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        
        # FOR NEW TOKEN UNCOMMENT THIS
        # Add only if class name splits into >1 token
        # for cname in self.class_names:
        #     if len(self.tokenizer.encode(cname, add_special_tokens=False)) > 1:
        #         token = f"{cname}"
        #         if token not in self.tokenizer.get_vocab():
        #             self.tokenizer.add_tokens([token], special_tokens=False)
        #             tid = self.tokenizer.convert_tokens_to_ids(token)
        #             print(f"Added class '{cname}' Token: {token} (id: {tid})")

        # Map every class to single token ID
        for _a09587e608eb in self._857f2d1e364a:
            if _a09587e608eb not in _41f95b47759a._3b7bf02c427d:
                _bb6bdf68974e = _f568b9c9d391._4932bc9f97c8(_a09587e608eb, _eef081ad8179=_7e747897cf37)
                if _7a68e1d47bdf(_bb6bdf68974e) > 1:
                    _41f95b47759a._3b7bf02c427d[_a09587e608eb] = f"{_7a68e1d47bdf(_41f95b47759a._3b7bf02c427d)}"
                else:
                    _41f95b47759a._3b7bf02c427d[_a09587e608eb] = _a09587e608eb
        
        self._03e93277f31e = {
            _512295011f7a: [self._f568b9c9d391._2794d6118c40(_41f95b47759a._3b7bf02c427d._0e89f6560e35(_a09587e608eb))]
            for _512295011f7a, _a09587e608eb in _40fd1d7ef032(self._857f2d1e364a)
        }

        self._7b54a171bee4 = _ddc8d5de8b65([
            _1a8362a9eb48(
                _0cdff9ffaba2=[
                    _2895904574cf
                    for _dc0b22a18fc2 in self._03e93277f31e._3fdeeb8e034d()
                    for _2895904574cf in _dc0b22a18fc2
                ],
                _bcdfa6d24f0e=self._5d0d28dc4a97,
                _aa3213c4d689=self._f568b9c9d391._aa3213c4d689
            )
        ])
        # self.class2seq = {
        #     idx: [self.tokenizer.convert_tokens_to_ids(f"{cname}")]
        #     for idx, cname in enumerate(self.class_names)
        # }

        self._1eaba7ec11a7 = {_02c849d7c172(_dc0b22a18fc2): _554fb287bd1c for _554fb287bd1c, _dc0b22a18fc2 in self._03e93277f31e._be860f998e29()}
        self._4e92b02ab9b6 = _01a85d4b5834(_cff5b835c41c)
        for _3d1e4cf21abd, _dc0b22a18fc2 in self._03e93277f31e._be860f998e29():
            self._4e92b02ab9b6[_7a68e1d47bdf(_dc0b22a18fc2)]._6a651bb11d5d((_3d1e4cf21abd, _dc0b22a18fc2))
        self._be98294757af = 0
        _5ca5f56b5416(f"SEQ {self._03e93277f31e} and {self._1eaba7ec11a7}")
        self._3ca83fc7433b = _f568b9c9d391._f68f68c20b0d or _f568b9c9d391._aa3213c4d689
        self._52ff027a34e6 = _52ff027a34e6
        self._b31e99678961 = "multiclass"
        self._cf7b6bf5d6fa = -100
        self._886b6f0cef65 = _f568b9c9d391._4932bc9f97c8("assistant<|end_header_id|>\n\n", _eef081ad8179=_7e747897cf37)
        self._57560ddf1131 = self._2de70c87eb80()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._c73fd81ab4d1 = _50117d945c3a
        # Resize vocab based token embeddings
        self._c73fd81ab4d1._7cc94578a930(_7a68e1d47bdf(self._f568b9c9d391))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._c73fd81ab4d1._3a0da4277958(_7e747897cf37)
        _8d0ef2910f15 = _f7aa304bfc00()  # bfloat16 or float16

        for _4dced9d9b32d, _38c09d6967fd in self._23d2c410b459():
            if not _d33af229fa47(_f717e32729bd._441565d94a06 for _f717e32729bd in _38c09d6967fd._6fbe416077a6(_dc6423480a7a=_7e747897cf37)):
                # FROZEN → BF16 (save memory)
                _38c09d6967fd._21ce1385ea5b(_a313c9f76a9f=_8d0ef2910f15)
            else:
                # TRAINABLE → FP32 (stable grads)
                _38c09d6967fd._21ce1385ea5b(_a313c9f76a9f=_22f79c2ae8bd._d5ab54d656e5)
        self._c73fd81ab4d1._21ce1385ea5b(self._6c69f304a217)
        if _8bf9cf4571b5(self._c73fd81ab4d1, "gradient_checkpointing_enable"):
            self._c73fd81ab4d1._be303feacc44()
        # determine embedding dim robustly from model config if available
        _8e11e28cdc3b = _6e8b1ff0d420(_6e8b1ff0d420(self._c73fd81ab4d1, "config", _9f5ce76e7050), "hidden_size", _9f5ce76e7050)
        if _8e11e28cdc3b is _9f5ce76e7050:
            # fallback to common default — change if your model uses a different hidden size
            _8e11e28cdc3b = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        # if hasattr(self.embedding, "lm_head") and getattr(self.embedding, "lm_head") is not None:
        #     self._lm_head = self.embedding.lm_head
        # else:
        #     get_out = getattr(self.embedding, "get_output_embeddings", None)
        #     self._lm_head = get_out() if callable(get_out) else None

        # # mark presence and ensure module (if any) is on the same device
        # self._has_lm_head = self._lm_head is not None
        # if self._has_lm_head:
        #     # move lm_head params/buffers to the model device (safe no-op if already there)
        #     self._lm_head.to(self.curr_device)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        # self.adapter = self._Adapter(dim=embedding_dim, bottleneck=64)
        # self.adapter.to(self.curr_device)
        # for p in self.adapter.parameters():
        #     p.requires_grad = True
        _e29283df87cb = (
            self._c73fd81ab4d1._e29283df87cb
            if _8bf9cf4571b5(self._c73fd81ab4d1, "lm_head")
            else self._c73fd81ab4d1._93ed85a114ef()
        )

        self._c73fd81ab4d1._e29283df87cb = self._57c0268e2c10(
            _2d0a9d4e7fb4=_8e11e28cdc3b,
            _e29283df87cb=_e29283df87cb,
            _f7265dfbc2a9=64,
        )._21ce1385ea5b(self._6c69f304a217)

        # self.adapter = self.embedding.lm_head

        if _99a2c39003db > 0:
            # if "llama" in self.pretrained_model_embedding_name:
            if self._e993bec3b8f8:
                for _6b5e693ad798 in self._c73fd81ab4d1._6fbe416077a6():
                    if not _6b5e693ad798._6b5ee08009ce:
                        _6b5e693ad798 = _6b5e693ad798._cbccf314a5e9()
                    _6b5e693ad798._441565d94a06 = _7e747897cf37  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _cbb775ea3d3d = self._c73fd81ab4d1._0146dc17217e._8ece82bb19d5  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _9de6cc05e163 in _cbb775ea3d3d[-_99a2c39003db:]:
                    for _6b5e693ad798 in _9de6cc05e163._6fbe416077a6():
                        if _351eebf587ec(_6b5e693ad798, _22f79c2ae8bd._48448c804dbc) and (_6b5e693ad798._3736c995933b() or _22f79c2ae8bd._bae92f260784(_6b5e693ad798)):
                            _6b5e693ad798._441565d94a06 = _6f286ccafa31
                for _6b5e693ad798 in self._c73fd81ab4d1._e29283df87cb._6fbe416077a6():
                    _6b5e693ad798._441565d94a06 = _6f286ccafa31

        self._4e891941bc21 = 1
        _5ca5f56b5416(f"DEBUG xth_batch init {self._4e891941bc21}")
        global _d56b1900c94a
        _d56b1900c94a = copy._3808b296f0e8(self._c73fd81ab4d1)._1758be6da5b6()
        self._c4ff59e997a0 = _c4ff59e997a0

        self._d5cb2c5e916b = {}
        self._14e5297c70b2 = {}

        # Loss function initialization
        if _cc0a785f369e._fde76133560d() == "class_weighted_cross_entropy_loss":
            self._14e5297c70b2['criterion'] = _e7e6e4efe329(_52ff027a34e6=self._52ff027a34e6,
                                                            _c861017b4e3e=self._6c69f304a217,
                                                            _f17591b04463=self._cf7b6bf5d6fa,
                                                            _117145892664=self._5d0d28dc4a97)
        elif _cc0a785f369e._fde76133560d() == "focal_loss":
            self._14e5297c70b2['criterion'] = _a4e1cd1fe2ee(_254ddeb66956=0.25,
                                                     _c861017b4e3e=self._6c69f304a217,
                                                     _f17591b04463=self._cf7b6bf5d6fa,
                                                     _117145892664=self._5d0d28dc4a97)
        elif _cc0a785f369e._fde76133560d() == "class_weighted_focal_loss":
            self._14e5297c70b2['criterion'] = _a4e1cd1fe2ee(_254ddeb66956=self._52ff027a34e6,
                                                     _c861017b4e3e=self._6c69f304a217,
                                                     _f17591b04463=self._cf7b6bf5d6fa,
                                                     _117145892664=self._5d0d28dc4a97)
        elif _cc0a785f369e._fde76133560d() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._14e5297c70b2['criterion'] = _ab10cc27ce41(_254ddeb66956=self._52ff027a34e6,
                                                                      _d5bf4fcb785b='type1',
                                                                      _c861017b4e3e=self._6c69f304a217,
                                                                      _f17591b04463=self._cf7b6bf5d6fa,
                                                                      _117145892664=self._5d0d28dc4a97)
        elif _cc0a785f369e._fde76133560d() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._14e5297c70b2['criterion'] = _ab10cc27ce41(_254ddeb66956=self._52ff027a34e6,
                                                                      _d5bf4fcb785b='type2',
                                                                      _c861017b4e3e=self._6c69f304a217,
                                                                      _f17591b04463=self._cf7b6bf5d6fa,
                                                                      _117145892664=self._5d0d28dc4a97)
        elif _cc0a785f369e._fde76133560d() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._14e5297c70b2['criterion'] = _ab10cc27ce41(_254ddeb66956=self._52ff027a34e6,
                                                                      _d5bf4fcb785b='type3',
                                                                      _c861017b4e3e=self._6c69f304a217,
                                                                      _f17591b04463=self._cf7b6bf5d6fa,
                                                                      _117145892664=self._5d0d28dc4a97)
        else:
            self._14e5297c70b2['criterion'] = _e7e6e4efe329(_c861017b4e3e=self._6c69f304a217,
                                                            _f17591b04463=self._cf7b6bf5d6fa,)
        
        self._607d55aa8fbb = 0.99
        self._091d4f8474ec = 0.3
        self._e742b31b585f = 0.30
        self._c6d93b699bd0 = 0.25
        self._21af35ad2624 = 0.6
        self._13722893d7b7 = 0.995
        self._0047f23056f7 = 0.60
        self._d7b697410d34 = 0.20
        self._de945553a273 = _6e8b1ff0d420(self, "batch_counter", 0)


        self._013e67b273e9 = []
        self._8989a4933087 = []

        self._5c355e9832a6 = _18c52502a05c._fde76133560d()
        self._7de5654e51c0()

        self._369e7fc82010(self._c73fd81ab4d1)
    
    def _7c2da3198a70(self):
        # rebuild all metrics on the correct device
        self._d5cb2c5e916b['micro_accuracy'] = _99886a82cec9(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e="micro",
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['macro_accuracy'] = _99886a82cec9(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e="macro",
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['macro_precision'] = _e6cb4142eece(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e="macro",
            _4ae23ad16129=self. _b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['macro_recall'] = _5b05c89c3843(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e="macro",
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['macro_f1'] = _ae7e83ac6721(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e="macro",
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['classwise_accuracy'] = _99886a82cec9(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e=_9f5ce76e7050,
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['classwise_precision'] = _e6cb4142eece(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e=_9f5ce76e7050,
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['classwise_recall'] = _5b05c89c3843(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e=_9f5ce76e7050,
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['classwise_f1'] = _ae7e83ac6721(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _2b3165b3236e=_9f5ce76e7050,
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)

        self._d5cb2c5e916b['confmat'] = _edc5cbacc129(
            _023e1bc29369=_7a68e1d47bdf(self._857f2d1e364a),
            _4ae23ad16129=self._b31e99678961,
            _f17591b04463=self._cf7b6bf5d6fa,
        )._21ce1385ea5b(self._6c69f304a217)


    def _d5d270be1d9f(self, _3dad88f4c5b7=_9f5ce76e7050):
        """Calculate batch counts and set xth_batch_to_consider."""
        _fa564a369d68 = 0
        _dc0f54decb99 = 0
        if self._756745c57740._c3c052f40eaf is not _9f5ce76e7050:
            if _8bf9cf4571b5(self._756745c57740._c3c052f40eaf, 'train_dataset') and self._756745c57740._c3c052f40eaf._430be5bb392b is not _9f5ce76e7050:
                _fa564a369d68 = _7a68e1d47bdf(self._756745c57740._c3c052f40eaf._430be5bb392b)
            if _8bf9cf4571b5(self._756745c57740._c3c052f40eaf, 'val_dataset') and self._756745c57740._c3c052f40eaf._4bda7c0dd8f1 is not _9f5ce76e7050:
                _dc0f54decb99 = _7a68e1d47bdf(self._756745c57740._c3c052f40eaf._4bda7c0dd8f1)
            _0bc12da90b52 = self._756745c57740._c3c052f40eaf._0bc12da90b52
            _797ba6f5fd24 = (_fa564a369d68 + _0bc12da90b52 - 1) // _0bc12da90b52 if _fa564a369d68 > 0 else 1
            _13cb41257cea = (_dc0f54decb99 + _0bc12da90b52 - 1) // _0bc12da90b52 if _dc0f54decb99 > 0 else 1
            _658a534c7171 = _825072112bd7(_797ba6f5fd24, _13cb41257cea) if _dc0f54decb99 > 0 else _797ba6f5fd24
            _f9d1b0c2f43e = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._4e891941bc21 = 1
            _5ca5f56b5416(f"DEBUG Batch Info: num_train_batches={_797ba6f5fd24}, num_val_batches={_13cb41257cea}, xth_batch_to_consider={self._4e891941bc21}")

    def _d7f73b52051d(self, _dfffee74359f, _407a22ae2d69):
        if _dfffee74359f._fde76133560d() == "parametric_relu":
            return _22f79c2ae8bd._a23190b10449._3fcff477ba4d(_407a22ae2d69=1)
        elif _dfffee74359f._fde76133560d() == "leaky_relu":
            return _22f79c2ae8bd._a23190b10449._808a5971bc61(_9bf9365efc6b=_7e747897cf37)
        else:
            return _22f79c2ae8bd._a23190b10449._c892fcd276f2(_9bf9365efc6b=_7e747897cf37)
    
    def _adbce3700dca(self, _38c09d6967fd, _16ffdb4fb221=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _4dced9d9b32d, _00c83525348b in _38c09d6967fd._bdbd82928e54():
            _8c89824b3d66 = f"{_16ffdb4fb221}.{_4dced9d9b32d}" if _16ffdb4fb221 else _4dced9d9b32d

            def _bfac959ca6f5(_fa06616579da, _0add36920341, _9141c4c81351):
                if _351eebf587ec(_9141c4c81351, _22f79c2ae8bd._48448c804dbc) and _9141c4c81351._f32a19846089()._d33af229fa47():
                    _5ca5f56b5416(f"NaN detected in {_8c89824b3d66} ({_fa06616579da._8c3f488b2519.__name__}) ({_9141c4c81351._a313c9f76a9f})")

            _00c83525348b._8dfa9df4e5c9(_9bb92e7a9161)

            self._369e7fc82010(_00c83525348b, _8c89824b3d66)

    def _d828a98e320f(self, _38c09d6967fd):
        return _d33af229fa47(_f717e32729bd._441565d94a06 for _f717e32729bd in _38c09d6967fd._6fbe416077a6())

    def _e9ba79ebd5a4(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _454eb44ef36b = []
        for _4dced9d9b32d, _38c09d6967fd in self._23d2c410b459():
            if not self._368e160a725d(_38c09d6967fd):
                continue
            _5ee0b680e346 = (
                "norm" in _4dced9d9b32d._942a52703d25() or 
                "linear4bit" in _4dced9d9b32d._942a52703d25() or 
                _d33af229fa47(_6cf448ba8f95 in _4dced9d9b32d._942a52703d25() for _6cf448ba8f95 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _4dced9d9b32d._942a52703d25() or 
                "dropout" in _4dced9d9b32d._942a52703d25() or 
                _351eebf587ec(_38c09d6967fd, (_b630527c429f, _22f79c2ae8bd._a23190b10449._1414756a5493, _22f79c2ae8bd._a23190b10449._21da6272fc99))
            )
            if _5ee0b680e346:
                if _8bf9cf4571b5(_38c09d6967fd, "eps"):
                    _38c09d6967fd._e5a894246203 = 1e-3
                _38c09d6967fd = _38c09d6967fd._21ce1385ea5b(_22f79c2ae8bd._d5ab54d656e5)
                if not _351eebf587ec(_38c09d6967fd, _41f95b47759a._3c46aee3a049):
                    _454eb44ef36b._6a651bb11d5d((_4dced9d9b32d, _41f95b47759a._3c46aee3a049(_38c09d6967fd, _5ed360b19021=-10, _c68ee5f1f15c=10)))
        for _4dced9d9b32d, _14e154a65019 in _454eb44ef36b:
            _fbe0f33abdb3, _f84279a5a8d8 = self._9c5aeda69b2b(_4dced9d9b32d)
            if _fbe0f33abdb3 is not _9f5ce76e7050:
                _1be971643950(_fbe0f33abdb3, _f84279a5a8d8, _14e154a65019)

    def _d0e148aea864(self, _5f10df3fa2cc):
        """Finds the parent module and attribute name given the full module path."""
        _7ac07a9a52e3 = _5f10df3fa2cc._0d2478aea853('.')
        _5e5d87f31f86 = self
        for _3ec1770b910d in _7ac07a9a52e3[:-1]:
            _5e5d87f31f86 = _6e8b1ff0d420(_5e5d87f31f86, _3ec1770b910d, _9f5ce76e7050)
            if _5e5d87f31f86 is _9f5ce76e7050:
                return _9f5ce76e7050, _9f5ce76e7050
        return _5e5d87f31f86, _7ac07a9a52e3[-1]

    def _9be2be245bfe(self, _542eb2954b5f: _22f79c2ae8bd._48448c804dbc, _7cd8d92e74e9: _22f79c2ae8bd._48448c804dbc, _f55bb6aae2bb: _22f79c2ae8bd._48448c804dbc) -> _6fd79383c899:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _c861017b4e3e = _542eb2954b5f._c861017b4e3e

        # 1) gating w (use cached per-example teacher_conf if available)
        _54a258ca82ae = _6e8b1ff0d420(self, "_last_teacher_conf", _9f5ce76e7050)
        if _54a258ca82ae is _9f5ce76e7050:
            # no teacher info => w = 0 (no distillation)
            _f92dbd65920b = 0.0
        else:
            _4c93e1825b41 = (_54a258ca82ae >= _370cd5a374fa(_6e8b1ff0d420(self, "teacher_conf_tau", 0.6)))._370cd5a374fa()
            _f92dbd65920b = _370cd5a374fa(_4c93e1825b41._4d25e6213fbc()._8f4d763a2421()._6290a4defde8()) if _4c93e1825b41._0ab33cd7aa15() > 0 else 0.0

        # apply gating to the batch scalars
        _c438ea9fb2f2 = _7cd8d92e74e9 * _370cd5a374fa(_f92dbd65920b)
        _84f32413fcc9 = _f55bb6aae2bb * _370cd5a374fa(_f92dbd65920b)

        # 2) EMAs for autoscaling
        _21d5de49cf01 = _370cd5a374fa((_c438ea9fb2f2 + _84f32413fcc9)._cbccf314a5e9()._8f4d763a2421()._6290a4defde8())
        _b729fb654613 = _370cd5a374fa(_542eb2954b5f._cbccf314a5e9()._8f4d763a2421()._6290a4defde8())
        if _6e8b1ff0d420(self, "ema_task", _9f5ce76e7050) is _9f5ce76e7050:
            self._d5d0a71bd02a = _b729fb654613
            self._2c5cd9646776 = _21d5de49cf01 + 1e-12
        else:
            _254ddeb66956 = _370cd5a374fa(_6e8b1ff0d420(self, "ema_alpha", 0.99))
            self._d5d0a71bd02a = _254ddeb66956 * _370cd5a374fa(self._d5d0a71bd02a) + (1.0 - _254ddeb66956) * _b729fb654613
            self._2c5cd9646776  = _254ddeb66956 * _370cd5a374fa(self._2c5cd9646776)  + (1.0 - _254ddeb66956) * _21d5de49cf01

        _8ea256308f5f = _370cd5a374fa(_6e8b1ff0d420(self, "distill_target_ratio", 0.3))
        _7e8c49a4b498 = (_370cd5a374fa(self._d5d0a71bd02a) / (_370cd5a374fa(self._2c5cd9646776) + 1e-12)) * _8ea256308f5f
        _bd3e5f51221f = _370cd5a374fa(_7e8c49a4b498)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _9baeb9c07b49 = _370cd5a374fa(_6e8b1ff0d420(self._756745c57740, "current_epoch", _6e8b1ff0d420(self._756745c57740, "global_step", 0.0)))
        _07d535723280 = _370cd5a374fa(_30b8beb3c8a8(1, _6e8b1ff0d420(self._756745c57740, "max_epochs", 1)))
        _65ba09be9791 = _825072112bd7(_30b8beb3c8a8(_9baeb9c07b49 / _07d535723280, 0.0), 1.0)
        _17c99cd42315 = 0.30
        _d676ffa656eb = _370cd5a374fa(_6e8b1ff0d420(self, "kl_base", 0.30)) * _825072112bd7(_65ba09be9791 / _17c99cd42315, 1.0)
        _c6d93b699bd0 = _370cd5a374fa(_6e8b1ff0d420(self, "cos_base", 0.25))
        _cfa509b55f7d = _c6d93b699bd0 + (0.10 - _c6d93b699bd0) * _65ba09be9791

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _4d266a7666ac = _370cd5a374fa(self._7b3345673dd7._4d25e6213fbc()._8f4d763a2421()._6290a4defde8()) if _6e8b1ff0d420(self, "_last_teacher_conf", _9f5ce76e7050) is not _9f5ce76e7050 else 0.0
        if _6e8b1ff0d420(self, "ema_teacher_conf", _9f5ce76e7050) is _9f5ce76e7050:
            self._d531acdc4a64 = _4d266a7666ac
        else:
            _ad9d36d99224 = _370cd5a374fa(_6e8b1ff0d420(self, "teacher_conf_beta", 0.995))
            self._d531acdc4a64 = _ad9d36d99224 * _370cd5a374fa(self._d531acdc4a64) + (1.0 - _ad9d36d99224) * _4d266a7666ac

        _0047f23056f7 = _370cd5a374fa(_6e8b1ff0d420(self, "tau_warn", 0.60))
        _d7b697410d34 = _370cd5a374fa(_6e8b1ff0d420(self, "tau_detect", 0.20))
        _9a24bdd2ade1 = _30b8beb3c8a8(1e-12, (_0047f23056f7 - _d7b697410d34))
        _ecbe12259bdd = (_370cd5a374fa(self._d531acdc4a64) - _d7b697410d34) / _9a24bdd2ade1
        _ecbe12259bdd = _30b8beb3c8a8(0.0, _825072112bd7(1.0, _ecbe12259bdd))

        _fbf9a498559b = _d676ffa656eb * _ecbe12259bdd
        _fa7b53b003bd = _cfa509b55f7d * _ecbe12259bdd

        # 5) final aux term
        _ffe7ed6354cf = _22f79c2ae8bd._be3ce29a45ce(0.0, _c861017b4e3e=_c861017b4e3e)
        _ffe7ed6354cf = _ffe7ed6354cf + (_fbf9a498559b * _c438ea9fb2f2 + _fa7b53b003bd * _84f32413fcc9) * _370cd5a374fa(_bd3e5f51221f)

        # diagnostics
        _9141c4c81351 = {
            "aux_term": _ffe7ed6354cf,
            "kl_batch": _7cd8d92e74e9,
            "contrast_batch": _f55bb6aae2bb,
            "kl_loss": _c438ea9fb2f2,
            "contrastive_loss": _84f32413fcc9,
            "w_mean": _f92dbd65920b,
            "aux_scale": _370cd5a374fa(_bd3e5f51221f),
            "lambda_kl_eff": _370cd5a374fa(_fbf9a498559b),
            "lambda_cos_eff": _370cd5a374fa(_fa7b53b003bd),
            "teacher_conf_mean": _370cd5a374fa(self._d531acdc4a64),
            "shift_r": _370cd5a374fa(_ecbe12259bdd)
        }
        return _9141c4c81351

    def _2e6ed31cab5f(self, _930928b40865):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _930928b40865 = _930928b40865._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)
        _e4763179cec7 = (_930928b40865 != self._f568b9c9d391._f68f68c20b0d)._21ce1385ea5b(_a313c9f76a9f=_22f79c2ae8bd._b2f3b0033b3a, _c861017b4e3e=self._6c69f304a217, _01344d24547f=_6f286ccafa31)

        # model forward (request hidden states)
        _f82c18fc9761 = self._c73fd81ab4d1(
            _930928b40865=_930928b40865,
            _e4763179cec7=_e4763179cec7,
            _21e9b52db49a=_6f286ccafa31,
            _4438bd5716cf=_6f286ccafa31,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _a200a38fa5c4 = _6e8b1ff0d420(_f82c18fc9761, "last_hidden_state", _9f5ce76e7050)
        if _a200a38fa5c4 is _9f5ce76e7050:
            _a200a38fa5c4 = _f82c18fc9761._cdf5faedbacf[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _a200a38fa5c4._a313c9f76a9f != _22f79c2ae8bd._d5ab54d656e5:
            _a200a38fa5c4 = _a200a38fa5c4._21ce1385ea5b(_22f79c2ae8bd._d5ab54d656e5)
        # student_hidden = self.adapter(hidden)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        # if self._has_lm_head:
        #     logits = self._lm_head(student_hidden)
        # else:
        #     logits = outs.logits

        _d92158887f4c = self._c73fd81ab4d1._e29283df87cb  # _LMHeadAdapter

        _4924d1e1e60c = _d92158887f4c._54a385bf2525(_a200a38fa5c4)      # (B, L, 2048)
        # logits = adapter.lm_head(student_hidden)    # (B, L, 128256)
        _04ac564afe5f = _d92158887f4c(_a200a38fa5c4)


        _04ac564afe5f = _04ac564afe5f._21ce1385ea5b(_22f79c2ae8bd._d5ab54d656e5)._1b6c9f6e696f(-20, 20)

        # default zero scalars
        _c438ea9fb2f2 = _22f79c2ae8bd._be3ce29a45ce(0.0, _c861017b4e3e=self._6c69f304a217)
        _84f32413fcc9 = _22f79c2ae8bd._be3ce29a45ce(0.0, _c861017b4e3e=self._6c69f304a217)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _7441d420976b = _6e8b1ff0d420(self, "trainer", _9f5ce76e7050)
        _be7ef4127305 = _7e747897cf37
        if _7441d420976b is not _9f5ce76e7050:
            _be7ef4127305 = _b2f3b0033b3a(_6e8b1ff0d420(self._756745c57740, "training", _7e747897cf37) or _6e8b1ff0d420(self._756745c57740, "validating", _7e747897cf37))

        if _be7ef4127305 and (_6e8b1ff0d420(self, "batch_counter", 0) % _6e8b1ff0d420(self, "xth_batch_to_consider", 1) == 0):
            with _22f79c2ae8bd._404caabea430():
                _8078dfdbd689 = _d56b1900c94a(
                    _930928b40865=_930928b40865,
                    _e4763179cec7=_e4763179cec7,
                    _21e9b52db49a=_6f286ccafa31,
                    _4438bd5716cf=_6f286ccafa31,
                )
                _71c7b743f2dd = _6e8b1ff0d420(_8078dfdbd689, "last_hidden_state", _9f5ce76e7050)
                if _71c7b743f2dd is _9f5ce76e7050:
                    _71c7b743f2dd = _8078dfdbd689._cdf5faedbacf[-1]

            # compute embedding-level KL + contrastive (scalar)
            _c438ea9fb2f2, _84f32413fcc9 = self._3e9abc9557ca(_4924d1e1e60c, _71c7b743f2dd, _c861017b4e3e=self._6c69f304a217)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _28b9a720c4db(_f9877cd87da8): return _f9877cd87da8._4d25e6213fbc(_2d0a9d4e7fb4=1) if _f9877cd87da8._2d0a9d4e7fb4() == 3 else _f9877cd87da8
            _14f655f4f225 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._dd3d7142da58(_9b5e9d04a5ec(_4924d1e1e60c), _f717e32729bd=2, _2d0a9d4e7fb4=-1, _e5a894246203=1e-6)
            _171d949f78f5 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._dd3d7142da58(_9b5e9d04a5ec(_71c7b743f2dd), _f717e32729bd=2, _2d0a9d4e7fb4=-1, _e5a894246203=1e-6)
            _1dfc0d386f64 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._fa25f2652812(_14f655f4f225, _171d949f78f5, _2d0a9d4e7fb4=-1)  # [-1,1]
            _54a258ca82ae = _1dfc0d386f64._1b6c9f6e696f(_825072112bd7=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._687b604cb640 = _4924d1e1e60c._cbccf314a5e9()
            self._884ae8abc7cb = _71c7b743f2dd._cbccf314a5e9()
            self._7b3345673dd7 = _54a258ca82ae._cbccf314a5e9()  # shape (B,)

        # increment counter
        self._de945553a273 = _6e8b1ff0d420(self, "batch_counter", 0) + 1

        return _04ac564afe5f, _c438ea9fb2f2, _84f32413fcc9


    def _e29ce0c668cc(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _b4e233739b49(_38c09d6967fd, _8de4952e32d2, _c6c24b55b34d):
            if _d33af229fa47(_0add36920341._a313c9f76a9f == _22f79c2ae8bd._f8aa82495e16 for _0add36920341 in _8de4952e32d2 if _351eebf587ec(_0add36920341, _22f79c2ae8bd._48448c804dbc)):
                _5ca5f56b5416(f"Layer {_38c09d6967fd._8c3f488b2519.__name__} is using float16!")

        for _96ca09e24a37 in self._6a3a3573299a():
            _802bc5dadb17 = _96ca09e24a37._8dfa9df4e5c9(_34b53686cc28)
            self._4e9e3b1ea102._6a651bb11d5d(_802bc5dadb17)

    def _0ebfc3f2d6be(self):
        """Remove all registered forward hooks."""
        for _802bc5dadb17 in _6e8b1ff0d420(self, "amp_hooks", []):
            _802bc5dadb17._dd8e5d8e3866()
        self._4e9e3b1ea102 = []

    def _6853cbb36f10(self, _930928b40865, _c1a87632ce62, _91deecb34182):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _5f2d91c7e822 = [self._f568b9c9d391._1c41bd6d347c(_867a232a77d8) for _867a232a77d8 in _930928b40865]
        _6e3986ec5c17, _60a8a697f4dd = [], []

        for _c6a49ce303fc, _3a82291df8d7, _c33d28074781 in _c4642c625e11(_5f2d91c7e822, _c1a87632ce62, _91deecb34182):
            for token, _1f87c7a218aa, _34d9d77728ac in _c4642c625e11(_c6a49ce303fc, _3a82291df8d7, _c33d28074781):
                if token == self._f568b9c9d391._63c9c5a66f19 or _34d9d77728ac == self._cf7b6bf5d6fa:
                    continue

                _98fb4ae18b05 = (
                    token._8a6da67b1cdc("##") or
                    token._8a6da67b1cdc("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _98fb4ae18b05:
                    continue

                _6e3986ec5c17._6a651bb11d5d(_1f87c7a218aa._6290a4defde8())
                _60a8a697f4dd._6a651bb11d5d(_34d9d77728ac._6290a4defde8())

        return _22f79c2ae8bd._be3ce29a45ce(_6e3986ec5c17), _22f79c2ae8bd._be3ce29a45ce(_60a8a697f4dd)

    def _16ef19767fb1(self):
        _82fb1d3e9c3b = _22f79c2ae8bd._d5ab54d656e5
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            _bbfa36533934, _dda409611c91 = _22f79c2ae8bd._94cc49ef777c._d1cb8dd44e28()
            if _bbfa36533934 >= 8:
                _82fb1d3e9c3b = _22f79c2ae8bd._0b31a8e74458
            else:
                _82fb1d3e9c3b = _22f79c2ae8bd._f8aa82495e16
        return _82fb1d3e9c3b

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _7916a6e720d0(
        self,
        _429bbd248111: _22f79c2ae8bd._48448c804dbc,
        _61f50f9f3276: _22f79c2ae8bd._48448c804dbc,
        _c861017b4e3e: _3dfdef28f84c = "cpu",
    ) -> _41c533176210[_22f79c2ae8bd._48448c804dbc, _22f79c2ae8bd._48448c804dbc]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _4e14f5da1032 = 2.0
            # NaN/Inf guard
            _429bbd248111 = _429bbd248111._1b6c9f6e696f(_825072112bd7=-30, _30b8beb3c8a8=30)
            _61f50f9f3276 = _61f50f9f3276._1b6c9f6e696f(_825072112bd7=-30, _30b8beb3c8a8=30)

            # Move once if needed
            _5bc83a70900d = _22f79c2ae8bd._c861017b4e3e(_c861017b4e3e)
            if _429bbd248111._c861017b4e3e != _5bc83a70900d:
                _429bbd248111 = _429bbd248111._21ce1385ea5b(_c861017b4e3e=_5bc83a70900d, _01344d24547f=_6f286ccafa31, _a313c9f76a9f=self._57560ddf1131)
                _61f50f9f3276 = _61f50f9f3276._21ce1385ea5b(_c861017b4e3e=_5bc83a70900d, _01344d24547f=_6f286ccafa31, _a313c9f76a9f=self._57560ddf1131)

            _0bc12da90b52 = _429bbd248111._6091b6d691ef(0)
            _8e11e28cdc3b = _429bbd248111._6091b6d691ef(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _474b57375e17 = (_0bc12da90b52 * _8e11e28cdc3b) > 32_000_000

            if not _474b57375e17 or _0bc12da90b52 <= 8:
                # Direct computation
                _a499a45b37d7 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._e27dce29a73a(_429bbd248111 / _4e14f5da1032, _2d0a9d4e7fb4=-1)
                _43b18cfe3ca3 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._f5ab2186ad48(_61f50f9f3276 / _4e14f5da1032, _2d0a9d4e7fb4=-1)
                _c438ea9fb2f2 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._08fa59d6f1dc(_a499a45b37d7, _43b18cfe3ca3, _160d21168152="batchmean") * (_4e14f5da1032 * _4e14f5da1032)
                _84f32413fcc9 = 1 - _22f79c2ae8bd._a23190b10449._d731e56c95c9._fa25f2652812(_429bbd248111, _61f50f9f3276, _2d0a9d4e7fb4=-1)._4d25e6213fbc()
                return _c438ea9fb2f2, _84f32413fcc9

            # Chunked mode for large inputs
            _7c41d1352a2b = _30b8beb3c8a8(1, _0bc12da90b52 // 8)
            _7f6b7dfdc437, _5ddc1ee23a3c = [], []

            for _4884ccc7d273 in _6df69cdb4343(0, _0bc12da90b52, _7c41d1352a2b):
                _4da75e84ee1a = _429bbd248111[_4884ccc7d273:_4884ccc7d273 + _7c41d1352a2b]
                _7e10486fa41a = _61f50f9f3276[_4884ccc7d273:_4884ccc7d273 + _7c41d1352a2b]

                _a499a45b37d7 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._e27dce29a73a(_4da75e84ee1a / _4e14f5da1032, _2d0a9d4e7fb4=-1)
                _43b18cfe3ca3 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._f5ab2186ad48(_7e10486fa41a / _4e14f5da1032, _2d0a9d4e7fb4=-1)

                _08edbe3d3e70 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._08fa59d6f1dc(_a499a45b37d7, _43b18cfe3ca3, _160d21168152="batchmean") * (_4e14f5da1032 * _4e14f5da1032)
                _9ca75f9ae303 = _22f79c2ae8bd._a23190b10449._d731e56c95c9._fa25f2652812(_4da75e84ee1a, _7e10486fa41a, _2d0a9d4e7fb4=-1)._4d25e6213fbc()
                _7a48558a91aa = 1 - _9ca75f9ae303

                _7f6b7dfdc437._6a651bb11d5d(_08edbe3d3e70)
                _5ddc1ee23a3c._6a651bb11d5d(_7a48558a91aa)

            _c438ea9fb2f2 = _22f79c2ae8bd._08b301a6f71a(_7f6b7dfdc437)._4d25e6213fbc()
            _84f32413fcc9 = _22f79c2ae8bd._08b301a6f71a(_5ddc1ee23a3c)._4d25e6213fbc()
            return _c438ea9fb2f2, _84f32413fcc9

        except _8e0c0c5a5e1e as _327f048f215e:
            raise _88bc3856ce4c(f"KL/contrastive loss computation failed: {_3dfdef28f84c(_327f048f215e)}")

    def _3da5cca48d20(self, _b72ce6c50710):
        _0cdff9ffaba2 = [
            _2895904574cf
            for _512295011f7a, _dc0b22a18fc2 in self._03e93277f31e._be860f998e29()
            if self._857f2d1e364a[_512295011f7a] in _b72ce6c50710
            for _2895904574cf in _dc0b22a18fc2
        ]

        self._7b54a171bee4 = _ddc8d5de8b65([
            _1a8362a9eb48(
                _0cdff9ffaba2=_0cdff9ffaba2,
                _bcdfa6d24f0e=self._5d0d28dc4a97,
                _aa3213c4d689=self._f568b9c9d391._aa3213c4d689
            )
        ])

    def _f40a1d517079(self, _e9d04b9f74e8):
        _b72ce6c50710 = _45a52a008360()

        if _351eebf587ec(_e9d04b9f74e8, _6fd79383c899):
            _4cdd35901507 = _e9d04b9f74e8._3fdeeb8e034d()
        elif _351eebf587ec(_e9d04b9f74e8, (_cff5b835c41c, _02c849d7c172)):
            _4cdd35901507 = _e9d04b9f74e8
        else:
            _4cdd35901507 = [_e9d04b9f74e8]

        for _eed6dfdf897d in _4cdd35901507:
            _b72ce6c50710._ea5e9a04381d(_eed6dfdf897d._b0b760f92cc9._b2c6b1fd171b)

        return _b72ce6c50710

    def _d48005bf88b1(self):
        _b72ce6c50710 = self._0db6172f2669(
            self._756745c57740._6ee5b115584b
        )
        self._70f79429a3d5(_b72ce6c50710)

        _5ca5f56b5416(f"Training Allowed languages {_b72ce6c50710}")

        self._7b54a171bee4 = _ddc8d5de8b65([
            _1a8362a9eb48(
                _0cdff9ffaba2=[
                    _2895904574cf
                    for _512295011f7a, _dc0b22a18fc2 in self._03e93277f31e._be860f998e29()
                    if self._857f2d1e364a[_512295011f7a] in _b72ce6c50710
                    for _2895904574cf in _dc0b22a18fc2
                ],
                _bcdfa6d24f0e=self._5d0d28dc4a97,
                _aa3213c4d689=self._f568b9c9d391._aa3213c4d689
            )
        ])
        
    def _76d8437ce2f7(self, _f082a224c505, _14cf50b8c0fe):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _930928b40865 = _f082a224c505["input_ids"]
            _4f5636f78a59 = _f082a224c505["labels"]
            _52cfbec22abc = _f082a224c505._0e89f6560e35("prompt_lens", _9f5ce76e7050)
            _0bc12da90b52 = _930928b40865._6091b6d691ef(0)

            # move to device
            _930928b40865 = _930928b40865._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)
            _4f5636f78a59 = _4f5636f78a59._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)

            # ---- scheduled sampling (minimal) ----
            _f717e32729bd = 0.0 if self._7a207884007e < 2 else self._ed56cea9b110  # e.g. 0.2
            if _f717e32729bd > 0.0 and (_14cf50b8c0fe % 2 == 0):
                with _22f79c2ae8bd._404caabea430():
                    # 1. run a no-grad forward to get predictions
                    _fded5584fa5e, _, _ = self(_930928b40865)
                    _7b5d890b6a6b = _fded5584fa5e._3e107ce19912(_2d0a9d4e7fb4=-1)
                    _7b5d890b6a6b = _22f79c2ae8bd._24f43c38c38f(
                        [_930928b40865[:, :1], _7b5d890b6a6b[:, :-1]],
                        _2d0a9d4e7fb4=1
                    )

                # 2. decide where to replace (Bernoulli mask)
                _94c2f896f961 = _22f79c2ae8bd._aeb4aac9dbd7(_930928b40865._370cd5a374fa()) < _f717e32729bd

                # 3. NEVER replace masked-out labels (-100) or input side
                _a1901422d75b = (_4f5636f78a59 != -100)
                _94c2f896f961 &= _a1901422d75b

                # 4. replace teacher tokens with model predictions
                _930928b40865 = _22f79c2ae8bd._8a4ad231accf(_94c2f896f961, _7b5d890b6a6b, _930928b40865)
            # -------------------------------------

            # ---- label dropout (generic, safe) ----
            _5bb638b5012c = 0.0 if self._7a207884007e < 2 else 0.2  # start small
            if _5bb638b5012c > 0 and (_14cf50b8c0fe % 2 == 0):
                _00e3b10f65c3 = (
                    (_22f79c2ae8bd._aeb4aac9dbd7(_930928b40865._370cd5a374fa()) < _5bb638b5012c)
                    & (_4f5636f78a59 != -100)
                )
                _930928b40865 = _22f79c2ae8bd._8a4ad231accf(
                    _00e3b10f65c3,
                    self._5d0d28dc4a97,
                    _930928b40865
                )
            # -------------------------------------
            
            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _c6c24b55b34d, _7cd8d92e74e9, _f55bb6aae2bb = self(_930928b40865)

            # causal LM shift for next-token classification (unchanged)
            _0cd0714acff0 = _c6c24b55b34d[:, :-1, :]._7ce0fe0745b4()
            _9c4b14350645 = _4f5636f78a59[:, 1:]._7ce0fe0745b4()
            _002f92bfb033 = _0cd0714acff0._bc533c8e4114(-1, _0cd0714acff0._6091b6d691ef(-1))
            _b7fed6b2d24e = _9c4b14350645._bc533c8e4114(-1)

            # classification/task loss
            _9390dfbd90dc = self._14e5297c70b2['criterion'](_002f92bfb033, _b7fed6b2d24e)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _7cd8d92e74e9 = _22f79c2ae8bd._5aa5d89a859f(_7cd8d92e74e9, _7a2d16156543=0.0, _9930a90d6b8f=0.0, _a7b542ba7c2a=0.0)
            _f55bb6aae2bb = _22f79c2ae8bd._5aa5d89a859f(_f55bb6aae2bb, _7a2d16156543=0.0, _9930a90d6b8f=0.0, _a7b542ba7c2a=0.0)
            _9390dfbd90dc = _22f79c2ae8bd._5aa5d89a859f(_9390dfbd90dc, _7a2d16156543=0.0, _9930a90d6b8f=0.0, _a7b542ba7c2a=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _b16e815655e2 = self._443e6fd426d3(_9390dfbd90dc, _7cd8d92e74e9, _f55bb6aae2bb)
            _ffe7ed6354cf = _b16e815655e2["aux_term"]

            if _9390dfbd90dc._cbccf314a5e9() < self._a00c01f29837:
                _ffe7ed6354cf = _22f79c2ae8bd._ec99eb4dd03c(_9390dfbd90dc)

            # final combined loss (single-equation)
            _abe0db82b26e = _9390dfbd90dc + _ffe7ed6354cf

            # Optional NaN print as before (keeps your original check)
            if _22f79c2ae8bd._f32a19846089(_9390dfbd90dc):
                _5ca5f56b5416(f"Step {_14cf50b8c0fe}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _c6eaaafabc27 = {
                "epoch": _370cd5a374fa(_6e8b1ff0d420(self, "current_epoch", _6e8b1ff0d420(self._756745c57740, "current_epoch", 0))),
                "train_kl_loss": _b16e815655e2._0e89f6560e35("kl_loss", _7cd8d92e74e9)._cbccf314a5e9() if _351eebf587ec(_b16e815655e2._0e89f6560e35("kl_loss", _7cd8d92e74e9), _22f79c2ae8bd._48448c804dbc) else _b16e815655e2._0e89f6560e35("kl_loss", _7cd8d92e74e9),
                "train_contrastive_loss": _b16e815655e2._0e89f6560e35("contrastive_loss", _f55bb6aae2bb)._cbccf314a5e9() if _351eebf587ec(_b16e815655e2._0e89f6560e35("contrastive_loss", _f55bb6aae2bb), _22f79c2ae8bd._48448c804dbc) else _b16e815655e2._0e89f6560e35("contrastive_loss", _f55bb6aae2bb),
                "train_classification_loss": _9390dfbd90dc._cbccf314a5e9(),
                "train_loss": _abe0db82b26e._cbccf314a5e9(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _370cd5a374fa(_6e8b1ff0d420(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _b16e815655e2._0e89f6560e35("lambda_kl_eff", _370cd5a374fa(_6e8b1ff0d420(self, "kl_base", 0.30))),
                "train_lambda_contrast": _b16e815655e2._0e89f6560e35("lambda_cos_eff", _370cd5a374fa(_6e8b1ff0d420(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _6fbc3526376b in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _6fbc3526376b in _b16e815655e2:
                    _1fbb2f617af2 = _b16e815655e2[_6fbc3526376b]
                    # convert single-element tensors to python floats for logging
                    if _351eebf587ec(_1fbb2f617af2, _22f79c2ae8bd._48448c804dbc) and _1fbb2f617af2._0ab33cd7aa15() == 1:
                        _c6eaaafabc27[f"train_{_6fbc3526376b}"] = _370cd5a374fa(_1fbb2f617af2._cbccf314a5e9()._8f4d763a2421()._6290a4defde8())
                    else:
                        _c6eaaafabc27[f"train_{_6fbc3526376b}"] = _1fbb2f617af2

            # log exactly like you did
            self._f028a0e50b02(
                _c6eaaafabc27,
                _0bc12da90b52=_0bc12da90b52,
                _30c8abf8ed05=_7e747897cf37,
                _5ba836934ed9=_6f286ccafa31,
                _d19843afd347=_7e747897cf37,
                _4030a64437a9=_6f286ccafa31,
                _0fa87f535dc4=_6f286ccafa31,
            )

            # free references as you did
            del _930928b40865, _4f5636f78a59, _c6c24b55b34d, _7cd8d92e74e9, _9390dfbd90dc, _f55bb6aae2bb, _9c4b14350645, _0cd0714acff0, _b7fed6b2d24e, _002f92bfb033

            return _abe0db82b26e

        except _8e0c0c5a5e1e as _327f048f215e:
            raise _88bc3856ce4c(f"Error in training_step: {_327f048f215e}") from _327f048f215e

    def _0c953987a7ca(self):
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            _22f79c2ae8bd._94cc49ef777c._8b9243fa071b()
        _b129d38d9c91._cd5997a41f47()
        return _a408a677567a()._9c68fa42fff6()

    # def validation_step(self, batch, batch_idx):
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification (same as training)
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     if batch_idx == 0:
    #         try:
    #             print(
    #                 f"VAL TEST BATCH {batch_idx} Input IDs: {input_ids.tolist()[0]}, "
    #                 f"Predictions: {torch.argmax(shift_logits, dim=-1).tolist()[0]}, "
    #                 f"Labels: {shift_labels.tolist()[0]}"
    #             )
    #         except Exception:
    #             # printing should never crash validation
    #             pass

    #     # classification loss
    #     classification_loss = self.loss_funcs['criterion'](logits_flat, labels_flat)

    #     # numeric guards (preserve your original torch.where behavior but simpler)
    #     kl_batch = torch.nan_to_num(kl_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     contrast_batch = torch.nan_to_num(contrast_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     classification_loss = torch.nan_to_num(classification_loss, nan=0.0, posinf=0.0, neginf=0.0)

    #     # ---------------------
    #     # Compute auxiliary term using the same helper as training
    #     # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
    #     aux = self.compute_auxiliary_distill_term(classification_loss, kl_batch, contrast_batch)
    #     aux_term = aux["aux_term"]
    #     if classification_loss.detach() < self.task_loss_floor:
    #         aux_term = torch.zeros_like(classification_loss)

    #     combined_loss = classification_loss + aux_term

    #     # Logging: preserve your keys but prefer the aux diagnostics where available
    #     log_dict = {
    #         "val_kl_loss": float(aux.get("kl_loss", kl_batch).detach().cpu().item()) if isinstance(aux.get("kl_loss", kl_batch), torch.Tensor) else float(aux.get("kl_loss", kl_batch)),
    #         "val_contrastive_loss": float(aux.get("contrastive_loss", contrast_batch).detach().cpu().item()) if isinstance(aux.get("contrastive_loss", contrast_batch), torch.Tensor) else float(aux.get("contrastive_loss", contrast_batch)),
    #         "val_classification_loss": float(classification_loss.detach().cpu().item()),
    #         "val_loss": float(combined_loss.detach().cpu().item()),
    #     }

    #     # include effective lambdas and others if provided by aux
    #     log_dict["val_lambda_kl"] = float(aux.get("lambda_kl", aux.get("lambda_kl_eff", float(getattr(self, "kl_base", 0.30)))))
    #     log_dict["val_lambda_contrast"] = float(aux.get("lambda_cos", aux.get("lambda_cos_eff", float(getattr(self, "cos_base", 0.25)))))
    #     log_dict["val_w_mean"] = float(aux.get("w_mean", 0.0))
    #     log_dict["val_aux_scale"] = float(aux.get("aux_scale", 0.0))
    #     log_dict["val_shift_r"] = float(aux.get("shift_r", 0.0))
    #     log_dict["val_teacher_conf_mean"] = float(aux.get("teacher_conf_mean", 0.0))

    #     self.log_dict(
    #         log_dict,
    #         batch_size=batch_size,
    #         on_step=False,
    #         on_epoch=True,
    #         prog_bar=False,
    #         logger=True,
    #         sync_dist=True,
    #     )

    #     # build preds and labels per example (preserve your previous behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "val_loss": combined_loss,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # store for epoch-end aggregation (your code uses self._validation_outputs)
    #     self._validation_outputs.append(output)

    #     # explicit frees (same as you had)
    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, classification_loss, preds_list, labels_list

    #     return output

    def _14acaa2927ee(self, _f082a224c505, _14cf50b8c0fe):
        _930928b40865 = _f082a224c505["input_ids"]._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)
        _4f5636f78a59 = _f082a224c505["labels"]._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)

        _b2c6b1fd171b = _f082a224c505._0e89f6560e35("lang_codes", _9f5ce76e7050)
        _6e80e7018e7a = _f082a224c505._0e89f6560e35("sample_ids", _9f5ce76e7050)
        _67d0853fccc5 = _f082a224c505._0e89f6560e35("chunk_ids", _9f5ce76e7050)
        _62fb33b5c607 = _f082a224c505._0e89f6560e35("word_positions", _9f5ce76e7050)
        _52cfbec22abc = _f082a224c505._0e89f6560e35("prompt_lens", _9f5ce76e7050)
        _a21a8efb9dbe = _f082a224c505._0e89f6560e35("num_chunks", _9f5ce76e7050)

        _0bc12da90b52 = _930928b40865._6091b6d691ef(0)

        _0f9c9303321f = (_4f5636f78a59 != -100)._0c85c207328f(_2d0a9d4e7fb4=1)
        _5a5e46b169b2 = _0f9c9303321f._30b8beb3c8a8()._6290a4defde8()

        with _22f79c2ae8bd._404caabea430():
            _93374498bc92 = self._e9394d156a06(
                _930928b40865=_930928b40865,
                _0e26c761011a=_5a5e46b169b2,
                _f6086eaaeb4d=_5a5e46b169b2,
                _8b7730aafe87=_7e747897cf37,
                _aad38f6cf900=1,
                _8953ed92f6a8=1.0,
                _7d997b6a5bb6=1.0,
                # repetition_penalty=1.0,
                # length_penalty=1.0,
                # early_stopping=True,
                _7de04cf8fd7a=_6f286ccafa31,
                _7b54a171bee4=self._7b54a171bee4,
                _613e9d0d72c6=_6f286ccafa31,
                _c32f9566417c=_6f286ccafa31,
                _21e9b52db49a=_7e747897cf37,
            )


        _811f464b6cb8 = _22f79c2ae8bd._08b301a6f71a(_93374498bc92._33f7bc79c1ec, _2d0a9d4e7fb4=1)   # (B, T_gen, V)

        _0c91ad84b571 = _930928b40865._6091b6d691ef(1)
        _c0c8957f2c05, _6168cef2d055, _f478aa05da02 = _811f464b6cb8._e13bed6de027
        _a5ab09cb3130 = _4f5636f78a59._6091b6d691ef(1)

        _06d719a93dbf = _93374498bc92._e6f588a17629
        _5f49497aa467 = _06d719a93dbf

        # ---- build pred_tokens WITHOUT argmax on junk ----
        _7b5d890b6a6b = _22f79c2ae8bd._6f2279855a8a(
            (_c0c8957f2c05, _a5ab09cb3130),
            -100,
            _c861017b4e3e=_811f464b6cb8._c861017b4e3e,
            _a313c9f76a9f=_22f79c2ae8bd._c50b6dfa918b,
        )

        # pred_tokens[:, prompt_len : prompt_len + T_gen] = torch.argmax(gen_logits, dim=-1)
        _7b5d890b6a6b[:, _0c91ad84b571 : _0c91ad84b571 + _6168cef2d055] = _5f49497aa467[:, _0c91ad84b571 : _0c91ad84b571 + _6168cef2d055]

        # DEBUG — AS-IS, full length
        if _14cf50b8c0fe == 0:
            _5ca5f56b5416(
                "VAL DEBUG\n"
                f"INPUT IDS      : {_930928b40865[0]._739ee94bbd80()}\n"
                f"GEN IDS (ONLY) : {_5f49497aa467[0]._739ee94bbd80()}\n"
                f"PRED TOKENS    : {_7b5d890b6a6b[0]._739ee94bbd80()}\n"
                f"LABELS (FULL)  : {_4f5636f78a59[0]._739ee94bbd80()}"
            )


        _e36325ec8193 = _0c91ad84b571
        _5075b52a1afa = _0c91ad84b571 + _811f464b6cb8._6091b6d691ef(1)

        # logits_flat = gen_logits.reshape(-1, gen_logits.size(-1))
        # labels_flat = labels[:, gen_start:gen_end].reshape(-1)

        _cf186385e251 = _4f5636f78a59[:, _e36325ec8193:_5075b52a1afa]
        _7bfb9cd2579d = _cf186385e251 != -100

        _002f92bfb033 = _811f464b6cb8[_7bfb9cd2579d]
        _b7fed6b2d24e = _cf186385e251[_7bfb9cd2579d]

        if _14cf50b8c0fe == 0:
            _5ca5f56b5416(
                "VAL DEBUG\n"
                f"LOGITS FLAT : {_002f92bfb033._e13bed6de027}\n"
                f"LABELS FLAT : {_b7fed6b2d24e._e13bed6de027}\n"
            )
        

        _9390dfbd90dc = self._14e5297c70b2["criterion"](_002f92bfb033, _b7fed6b2d24e)
        _9390dfbd90dc = _22f79c2ae8bd._5aa5d89a859f(_9390dfbd90dc, _7a2d16156543=0.0)

        _7cd8d92e74e9 = _22f79c2ae8bd._be3ce29a45ce(0.0, _c861017b4e3e=_930928b40865._c861017b4e3e)
        _f55bb6aae2bb = _22f79c2ae8bd._be3ce29a45ce(0.0, _c861017b4e3e=_930928b40865._c861017b4e3e)

        # if gen_out.hidden_states is not None:
        #     hs = gen_out.hidden_states
        #     last_step = hs[-1]
        #     last_layer = last_step[-1] if isinstance(last_step, (tuple, list)) else last_step
        #     student_hidden = last_layer[:, -T_gen:, :]

        #     with torch.no_grad():
        #         frozen_outs = FROZEN_EMBEDDING(
        #             input_ids=generated_ids,
        #             attention_mask=(generated_ids != self.tokenizer.pad_token_id),
        #             output_hidden_states=True,
        #             return_dict=True,
        #         )
        #         frozen_hidden = frozen_outs.hidden_states[-1][:, -T_gen:, :]

        #     kl_batch, contrast_batch = self.compute_kl_contrastive_loss(
        #         student_hidden,
        #         frozen_hidden,
        #         device=self.curr_device,
        #     )

        _7cd8d92e74e9 = _22f79c2ae8bd._5aa5d89a859f(_7cd8d92e74e9, _7a2d16156543=0.0)
        _f55bb6aae2bb = _22f79c2ae8bd._5aa5d89a859f(_f55bb6aae2bb, _7a2d16156543=0.0)

        _b16e815655e2 = self._443e6fd426d3(
            _9390dfbd90dc,
            _7cd8d92e74e9,
            _f55bb6aae2bb,
        )

        _ffe7ed6354cf = _b16e815655e2["aux_term"]
        if _9390dfbd90dc._cbccf314a5e9() < self._a00c01f29837:
            _ffe7ed6354cf = _22f79c2ae8bd._ec99eb4dd03c(_9390dfbd90dc)

        _abe0db82b26e = _9390dfbd90dc + _ffe7ed6354cf

        self._f028a0e50b02(
            {
                "val_loss": _abe0db82b26e._cbccf314a5e9(),
                "val_classification_loss": _9390dfbd90dc._cbccf314a5e9(),
                "val_kl_loss": _b16e815655e2._0e89f6560e35("kl_loss", _7cd8d92e74e9),
                "val_contrastive_loss": _b16e815655e2._0e89f6560e35("contrastive_loss", _f55bb6aae2bb),
                "val_lambda_kl": _b16e815655e2._0e89f6560e35("lambda_kl_eff", 0.0),
                "val_lambda_contrast": _b16e815655e2._0e89f6560e35("lambda_cos_eff", 0.0),
                "val_teacher_conf_mean": _b16e815655e2._0e89f6560e35("teacher_conf_mean", 0.0),
            },
            _0bc12da90b52=_0bc12da90b52,
            _30c8abf8ed05=_7e747897cf37,
            _5ba836934ed9=_6f286ccafa31,
            _0fa87f535dc4=_6f286ccafa31,
        )

        _b2e276ee6863 = [_5f49497aa467[_4884ccc7d273] for _4884ccc7d273 in _6df69cdb4343(_0bc12da90b52)]
        _6811bacccfd1 = [_4f5636f78a59[_4884ccc7d273] for _4884ccc7d273 in _6df69cdb4343(_0bc12da90b52)]

        _f5db263bc330 = {
            "lang_codes": _b2c6b1fd171b,
            "preds": _b2e276ee6863,
            "labels": _6811bacccfd1,
            "sample_ids": _6e80e7018e7a,
            "chunk_ids": _67d0853fccc5,
            "word_positions": _62fb33b5c607,
            "prompt_lens": _52cfbec22abc,
            "num_chunks": _a21a8efb9dbe,
            "val_loss": _abe0db82b26e,
        }

        self._013e67b273e9._6a651bb11d5d(_f5db263bc330)

        del _930928b40865, _4f5636f78a59, _93374498bc92, _811f464b6cb8
        del _002f92bfb033, _b7fed6b2d24e, _5f49497aa467
        del _7cd8d92e74e9, _f55bb6aae2bb, _9390dfbd90dc
        del _b2e276ee6863, _6811bacccfd1

        return _f5db263bc330

    def _1292ef782ed9(self, _690cc7cbfafe, _8db15a495ea6, _683b614b87ee=_9f5ce76e7050):
        _8ac6795af69b = os._0cec50a247e2()
        _29ded4b4714c = f"trial_{_683b614b87ee}" if _683b614b87ee is not _9f5ce76e7050 else "default"
        _5ca5f56b5416(f"[DEBUG rank={_22f79c2ae8bd._9c0c099ef24d._7b7d3a5f481a() if _22f79c2ae8bd._9c0c099ef24d._4e130686a8cc() else 0}] metrics_dict confusion_matrix sum={_0c85c207328f(_0c85c207328f(_d83ec298b192) for _d83ec298b192 in _690cc7cbfafe['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _f0c8f25ea316 = os._15cc4b9860a2._f9fd96824c77(_8ac6795af69b, "metrics", self._143e2a211dfc,  _29ded4b4714c)
        os._1d32ffc25393(_f0c8f25ea316, _fea9c7ba6931=_6f286ccafa31)
        _afdf270705a9 = os._15cc4b9860a2._f9fd96824c77(_f0c8f25ea316, _8db15a495ea6)
        _c3558b51bc5d = _38334ca44edf._63d3d0ccc1d4(_690cc7cbfafe)
        _c3558b51bc5d._aa413fb11e88(_afdf270705a9, _54114a6a61cd=_7e747897cf37)
        _5ca5f56b5416(f"[metrics] Saved {_afdf270705a9}")

    def _6128dfe92d32(self):
        # pick correct device for this rank
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            if _22f79c2ae8bd._9c0c099ef24d._4e130686a8cc():
                _a25a6137f443 = _22f79c2ae8bd._9c0c099ef24d._7b7d3a5f481a()
            else:
                _a25a6137f443 = 0
            _22f79c2ae8bd._94cc49ef777c._b61693688876(_a25a6137f443)
            self._6c69f304a217 = _22f79c2ae8bd._c861017b4e3e(f"cuda:{_a25a6137f443}")
        else:
            self._6c69f304a217 = _22f79c2ae8bd._c861017b4e3e("cpu")
        
        _b72ce6c50710 = self._0db6172f2669(
            self._756745c57740._c63ee920fd0b
        )
        self._70f79429a3d5(_b72ce6c50710)

        _5ca5f56b5416(f"Validation Allowed languages {_b72ce6c50710}")

        self._7b54a171bee4 = _ddc8d5de8b65([
            _1a8362a9eb48(
                _0cdff9ffaba2=[
                    _2895904574cf
                    for _512295011f7a, _dc0b22a18fc2 in self._03e93277f31e._be860f998e29()
                    if self._857f2d1e364a[_512295011f7a] in _b72ce6c50710
                    for _2895904574cf in _dc0b22a18fc2
                ],
                _bcdfa6d24f0e=self._5d0d28dc4a97,
                _aa3213c4d689=self._f568b9c9d391._aa3213c4d689
            )
        ])

        self._bbeff50b7bde()

    def _197da711219c(self):
        _c6c24b55b34d = _6e8b1ff0d420(self, "_validation_outputs", _9f5ce76e7050)
        if not _c6c24b55b34d:
            return

        _87201fb05534, _4654441b8e80, _399919f19e80, _1ac6672f6ebb = \
            self._5a7bd1f360fe(_c6c24b55b34d)

        _0d544f70ab22, _197d4da1e321 = [], []
        for _3798f25b3880 in _5d88e5b6f2ff(_399919f19e80._c1c9dca3e93c()):
            _721096dac162 = _87201fb05534[_3798f25b3880]._739ee94bbd80()
            _116136cbff76 = _4654441b8e80[_3798f25b3880]._739ee94bbd80()
            _4ad8b5ca6d4a = _399919f19e80[_3798f25b3880]
            _c06d4ba5d0fa = _1ac6672f6ebb[_3798f25b3880]
            if _4ad8b5ca6d4a._0ab33cd7aa15() > 0 and _c06d4ba5d0fa._0ab33cd7aa15() > 0:
                _0d544f70ab22._6a651bb11d5d(_4ad8b5ca6d4a)
                _197d4da1e321._6a651bb11d5d(_c06d4ba5d0fa)

        if not _0d544f70ab22:
            _5ca5f56b5416("[VAL END] Nothing to score.")
            self._013e67b273e9._486df41fd10d()
            return

        _8f674c594c46 = _22f79c2ae8bd._24f43c38c38f(_0d544f70ab22)._21ce1385ea5b(_c861017b4e3e=self._d5cb2c5e916b['micro_accuracy']._c861017b4e3e, _01344d24547f=_6f286ccafa31)
        _4f5636f78a59 = _22f79c2ae8bd._24f43c38c38f(_197d4da1e321)._21ce1385ea5b(_c861017b4e3e=self._d5cb2c5e916b['micro_accuracy']._c861017b4e3e, _01344d24547f=_6f286ccafa31)

        self._d5cb2c5e916b['micro_accuracy']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_accuracy']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_precision']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_recall']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_f1']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_accuracy']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_precision']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_recall']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_f1']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['confmat']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)

        _426fb5acf28e  = self._d5cb2c5e916b['micro_accuracy']._7606a7b030c1()._6290a4defde8()
        _1de1d09dc728  = self._d5cb2c5e916b['macro_accuracy']._7606a7b030c1()._6290a4defde8()
        _df87a25ba6ab = self._d5cb2c5e916b['macro_precision']._7606a7b030c1()._6290a4defde8()
        _e99a1ac17399    = self._d5cb2c5e916b['macro_recall']._7606a7b030c1()._6290a4defde8()
        _a20864b95be6        = self._d5cb2c5e916b['macro_f1']._7606a7b030c1()._6290a4defde8()

        self._60ece2deb88d("val_accuracy", _1de1d09dc728, _0fa87f535dc4=_6f286ccafa31)

        try:
            _44dfc2604e5e = self._7a207884007e
            _690cc7cbfafe = {
                "epoch": [_44dfc2604e5e],
                "class_names": [self._857f2d1e364a],
                "micro_accuracy": [_426fb5acf28e],
                "macro_accuracy": [_1de1d09dc728],
                "macro_precision": [_df87a25ba6ab],
                "macro_recall": [_e99a1ac17399],
                "macro_f1": [_a20864b95be6],
                "classwise_accuracy": [self._d5cb2c5e916b['classwise_accuracy']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "classwise_precision": [self._d5cb2c5e916b['classwise_precision']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "classwise_recall": [self._d5cb2c5e916b['classwise_recall']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "classwise_f1": [self._d5cb2c5e916b['classwise_f1']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "confusion_matrix": [self._d5cb2c5e916b['confmat']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
            }
            self._e9c3831084c6(_690cc7cbfafe, f"val_epoch_{_44dfc2604e5e}.csv", _683b614b87ee=self._683b614b87ee)
        except _8e0c0c5a5e1e as _327f048f215e:
            _5ca5f56b5416(f"[VAL END] save metrics FAILED: {_327f048f215e}")

        # cleanup
        self._d5cb2c5e916b['micro_accuracy']._43166507c90a(); self._d5cb2c5e916b['macro_accuracy']._43166507c90a()
        self._d5cb2c5e916b['macro_precision']._43166507c90a(); self._d5cb2c5e916b['macro_recall']._43166507c90a(); self._d5cb2c5e916b['macro_f1']._43166507c90a()
        self._d5cb2c5e916b['classwise_accuracy']._43166507c90a(); self._d5cb2c5e916b['classwise_precision']._43166507c90a()
        self._d5cb2c5e916b['classwise_recall']._43166507c90a(); self._d5cb2c5e916b['classwise_f1']._43166507c90a()
        self._d5cb2c5e916b['confmat']._43166507c90a(); self._013e67b273e9._486df41fd10d()
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            _22f79c2ae8bd._94cc49ef777c._8b9243fa071b()
        _5ca5f56b5416("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_22f79c2ae8bd._404caabea430()
    def _23411d245d60(self, _930928b40865: _22f79c2ae8bd._48448c804dbc, **_47bacf7e9ce4):
        _47bacf7e9ce4._87ea4229b750("pad_token_id", _9f5ce76e7050)
        _47bacf7e9ce4._87ea4229b750("attention_mask", _9f5ce76e7050)
        return self._c73fd81ab4d1._e9394d156a06(
            _930928b40865=_930928b40865,
            _e4763179cec7=(_930928b40865 != self._f568b9c9d391._f68f68c20b0d),
            _f68f68c20b0d=self._f568b9c9d391._f68f68c20b0d,
            _aa3213c4d689=self._f568b9c9d391._aa3213c4d689,
            **_47bacf7e9ce4
        )

    def _5503e33324eb(self, _f082a224c505, _14cf50b8c0fe):
        _930928b40865 = _f082a224c505["input_ids"]._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)
        _4f5636f78a59    = _f082a224c505["labels"]._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)
        _b2c6b1fd171b     = _f082a224c505._0e89f6560e35("lang_codes", _9f5ce76e7050)
        _6e80e7018e7a     = _f082a224c505._0e89f6560e35("sample_ids", _9f5ce76e7050)
        _67d0853fccc5      = _f082a224c505._0e89f6560e35("chunk_ids", _9f5ce76e7050)
        _62fb33b5c607 = _f082a224c505._0e89f6560e35("word_positions", _9f5ce76e7050)
        _52cfbec22abc    = _f082a224c505._0e89f6560e35("prompt_lens", _9f5ce76e7050)
        _a21a8efb9dbe = _f082a224c505._0e89f6560e35("num_chunks", _9f5ce76e7050)

        _0bc12da90b52 = _930928b40865._6091b6d691ef(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _0ef9312b56f1 = [_7a68e1d47bdf(_e242ce2ae08e) for _e242ce2ae08e in _62fb33b5c607]
        _9448d9e237ab = _30b8beb3c8a8(_0ef9312b56f1)
        _5f49497aa467 = self._e9394d156a06(
            _930928b40865,
            # max_new_tokens=64,
            # do_sample=False,
            # temperature=None,     # for deterministic answers
            # top_p=None,           # for deterministic answers
            # repetition_penalty=1.2,
            # fully deterministic decoding
            _0e26c761011a=_9448d9e237ab,        # hard cap on number of generated tokens
            _f6086eaaeb4d=_9448d9e237ab,        # forces fixed-length output (prevents early EOS)
            _8b7730aafe87=_7e747897cf37,          # disables sampling ; greedy decoding
            _aad38f6cf900=1,              # no beam search ; single deterministic path
            _8953ed92f6a8=1.0,          # 1.2 with do_sample True; neutral temperature (no probability scaling)
            _7d997b6a5bb6=1.0,                # disables nucleus filtering
            # repetition_penalty=1.0,   # no penalty for repeated tokens
            # length_penalty=1.0,       # no bias toward shorter/longer sequences
            # early_stopping=True,     # do not stop on EOS before min_new_tokens
            _7de04cf8fd7a=_6f286ccafa31,           # reuse KV cache for consistent + faster decoding
            _7b54a171bee4=self._7b54a171bee4,
        )

        if _14cf50b8c0fe == 0:
            try:
                _5ca5f56b5416(
                    f"TEST TEST BATCH {_14cf50b8c0fe} Input IDs: {_930928b40865._739ee94bbd80()[0]}, "
                    f"Generated IDs: {_5f49497aa467._739ee94bbd80()[0]}, "
                    f"Labels: {_4f5636f78a59._739ee94bbd80()[0]}"
                )
            except _8e0c0c5a5e1e:
                # printing should never crash testing
                pass


        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _b2e276ee6863 = []
        _6811bacccfd1 = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _4884ccc7d273 in _6df69cdb4343(_0bc12da90b52):
            _b2e276ee6863._6a651bb11d5d(_5f49497aa467[_4884ccc7d273]._cbccf314a5e9()._8f4d763a2421())
            _6811bacccfd1._6a651bb11d5d(_4f5636f78a59[_4884ccc7d273]._cbccf314a5e9()._8f4d763a2421())


        _f5db263bc330 = {
            "lang_codes": _b2c6b1fd171b,
            "preds": _b2e276ee6863,
            "labels": _6811bacccfd1,
            "sample_ids": _6e80e7018e7a,
            "chunk_ids": _67d0853fccc5,
            "word_positions": _62fb33b5c607,
            "prompt_lens": _52cfbec22abc,
            "num_chunks": _a21a8efb9dbe,
        }

        self._8989a4933087._6a651bb11d5d(_f5db263bc330)

        # Exact same cleanup as before
        del _930928b40865, _4f5636f78a59, _5f49497aa467, _b2e276ee6863, _6811bacccfd1

        return _f5db263bc330

    def _bac7a159e6fd(self):
        # pick correct device for this rank
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            if _22f79c2ae8bd._9c0c099ef24d._4e130686a8cc():
                _a25a6137f443 = _22f79c2ae8bd._9c0c099ef24d._7b7d3a5f481a()
            else:
                _a25a6137f443 = 0
            _22f79c2ae8bd._94cc49ef777c._b61693688876(_a25a6137f443)
            self._6c69f304a217 = _22f79c2ae8bd._c861017b4e3e(f"cuda:{_a25a6137f443}")
        else:
            self._6c69f304a217 = _22f79c2ae8bd._c861017b4e3e("cpu")

        _b72ce6c50710 = self._0db6172f2669(
            self._756745c57740._af1e0aaec7c0
        )
        self._70f79429a3d5(_b72ce6c50710)

        _5ca5f56b5416(f"Test Allowed languages {_b72ce6c50710}")

        self._7b54a171bee4 = _ddc8d5de8b65([
            _1a8362a9eb48(
                _0cdff9ffaba2=[
                    _2895904574cf
                    for _512295011f7a, _dc0b22a18fc2 in self._03e93277f31e._be860f998e29()
                    if self._857f2d1e364a[_512295011f7a] in _b72ce6c50710
                    for _2895904574cf in _dc0b22a18fc2
                ],
                _bcdfa6d24f0e=self._5d0d28dc4a97,
                _aa3213c4d689=self._f568b9c9d391._aa3213c4d689
            )
        ])

        self._bbeff50b7bde()
        
    def _35e68d93c9f8(self):
        _c6c24b55b34d = _6e8b1ff0d420(self, "_test_outputs", _9f5ce76e7050)
        _5ca5f56b5416(f"[DEBUG rank={_22f79c2ae8bd._9c0c099ef24d._7b7d3a5f481a()}] outputs_len={_7a68e1d47bdf(_c6c24b55b34d)}")
        if not _c6c24b55b34d:
            return

        _87201fb05534, _4654441b8e80, _399919f19e80, _1ac6672f6ebb = \
            self._5a7bd1f360fe(_c6c24b55b34d, _3f4c8a707e6e=_6f286ccafa31)

        _0d544f70ab22, _197d4da1e321 = [], []
        for _3798f25b3880 in _5d88e5b6f2ff(_399919f19e80._c1c9dca3e93c()):
            _721096dac162 = _87201fb05534[_3798f25b3880]._739ee94bbd80()
            _116136cbff76 = _4654441b8e80[_3798f25b3880]._739ee94bbd80()
            _4ad8b5ca6d4a = _399919f19e80[_3798f25b3880]
            _c06d4ba5d0fa = _1ac6672f6ebb[_3798f25b3880]

            if _4ad8b5ca6d4a._0ab33cd7aa15() > 0 and _c06d4ba5d0fa._0ab33cd7aa15() > 0:
                _0d544f70ab22._6a651bb11d5d(_4ad8b5ca6d4a)
                _197d4da1e321._6a651bb11d5d(_c06d4ba5d0fa)

        if not _0d544f70ab22:
            _5ca5f56b5416("[TEST END] Nothing to score.")
            self._013e67b273e9._486df41fd10d()
            return

        _8f674c594c46 = _22f79c2ae8bd._24f43c38c38f(_0d544f70ab22)._21ce1385ea5b(_c861017b4e3e=self._d5cb2c5e916b['micro_accuracy']._c861017b4e3e, _01344d24547f=_6f286ccafa31)
        _4f5636f78a59 = _22f79c2ae8bd._24f43c38c38f(_197d4da1e321)._21ce1385ea5b(_c861017b4e3e=self._d5cb2c5e916b['micro_accuracy']._c861017b4e3e, _01344d24547f=_6f286ccafa31)

        self._d5cb2c5e916b['micro_accuracy']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_accuracy']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_precision']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_recall']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['macro_f1']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_accuracy']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_precision']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_recall']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['classwise_f1']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)
        self._d5cb2c5e916b['confmat']._ea5e9a04381d(_8f674c594c46, _4f5636f78a59)

        _426fb5acf28e  = self._d5cb2c5e916b['micro_accuracy']._7606a7b030c1()._6290a4defde8()
        _1de1d09dc728  = self._d5cb2c5e916b['macro_accuracy']._7606a7b030c1()._6290a4defde8()
        _df87a25ba6ab = self._d5cb2c5e916b['macro_precision']._7606a7b030c1()._6290a4defde8()
        _e99a1ac17399    = self._d5cb2c5e916b['macro_recall']._7606a7b030c1()._6290a4defde8()
        _a20864b95be6        = self._d5cb2c5e916b['macro_f1']._7606a7b030c1()._6290a4defde8()

        self._60ece2deb88d("test_accuracy", _1de1d09dc728, _0fa87f535dc4=_6f286ccafa31)

        try:
            _44dfc2604e5e = self._7a207884007e
            _690cc7cbfafe = {
                "epoch": [_44dfc2604e5e],
                "class_names": [self._857f2d1e364a],
                "micro_accuracy": [_426fb5acf28e],
                "macro_accuracy": [_1de1d09dc728],
                "macro_precision": [_df87a25ba6ab],
                "macro_recall": [_e99a1ac17399],
                "macro_f1": [_a20864b95be6],
                "classwise_accuracy": [self._d5cb2c5e916b['classwise_accuracy']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "classwise_precision": [self._d5cb2c5e916b['classwise_precision']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "classwise_recall": [self._d5cb2c5e916b['classwise_recall']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "classwise_f1": [self._d5cb2c5e916b['classwise_f1']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
                "confusion_matrix": [self._d5cb2c5e916b['confmat']._7606a7b030c1()._21ce1385ea5b(_c861017b4e3e="cpu")._d721fb76c325()._739ee94bbd80()],
            }
            self._e9c3831084c6(_690cc7cbfafe, f"test_final.csv", _683b614b87ee=self._683b614b87ee)
        except _8e0c0c5a5e1e as _327f048f215e:
            _5ca5f56b5416(f"[TEST END] save metrics FAILED: {_327f048f215e}")

        # cleanup
        self._d5cb2c5e916b['micro_accuracy']._43166507c90a(); self._d5cb2c5e916b['macro_accuracy']._43166507c90a()
        self._d5cb2c5e916b['macro_precision']._43166507c90a(); self._d5cb2c5e916b['macro_recall']._43166507c90a(); self._d5cb2c5e916b['macro_f1']._43166507c90a()
        self._d5cb2c5e916b['classwise_accuracy']._43166507c90a(); self._d5cb2c5e916b['classwise_precision']._43166507c90a()
        self._d5cb2c5e916b['classwise_recall']._43166507c90a(); self._d5cb2c5e916b['classwise_f1']._43166507c90a()
        self._d5cb2c5e916b['confmat']._43166507c90a(); self._013e67b273e9._486df41fd10d()
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            _22f79c2ae8bd._94cc49ef777c._8b9243fa071b()
        _5ca5f56b5416("[TEST END] Finished and cleaned up.")

    def _c94737360b67(self, _f082a224c505, _14cf50b8c0fe, _e4c6e97c763b=0):
        """Optimized prediction step with efficient memory handling."""
        _930928b40865, _ = _f082a224c505
        _930928b40865 = _930928b40865._21ce1385ea5b(self._6c69f304a217, _01344d24547f=_6f286ccafa31)
        _c6c24b55b34d, _, _ = self(_930928b40865)
        _1a71c744af66 = _22f79c2ae8bd._3e107ce19912(_c6c24b55b34d, _2d0a9d4e7fb4=-1)
        del _930928b40865, _c6c24b55b34d
        if _22f79c2ae8bd._94cc49ef777c._6b98782c94fd():
            _22f79c2ae8bd._94cc49ef777c._8b9243fa071b()
        return {"predictions": _1a71c744af66._8f4d763a2421()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _b4a11fd415b5(self, _5f2d91c7e822, _39e62b9a69ba):
        # if sep token not present then just tuple the tokens and return
        if _39e62b9a69ba is _9f5ce76e7050:
            return [(_74c9229a9d6d,) for _74c9229a9d6d in _5f2d91c7e822]

        _e8dd85d58569 = []
        _c9b302cd76bb = []

        for _74c9229a9d6d in _5f2d91c7e822:
            if _74c9229a9d6d == _39e62b9a69ba:
                if _c9b302cd76bb:
                    _e8dd85d58569._6a651bb11d5d(_02c849d7c172(_c9b302cd76bb))
                    _c9b302cd76bb = []
            else:
                if _39e62b9a69ba == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _74c9229a9d6d in _c9b302cd76bb:
                        continue
                    else:
                        _c9b302cd76bb._6a651bb11d5d(_74c9229a9d6d)
                    
                else:
                    _c9b302cd76bb._6a651bb11d5d(_74c9229a9d6d)

        if _c9b302cd76bb:
            _e8dd85d58569._6a651bb11d5d(_02c849d7c172(_c9b302cd76bb))

        return _e8dd85d58569

    def _d0a88f899820(self, _3fdeeb8e034d, _1f52823b1019="exact_match", _004ab2a67f10=_9f5ce76e7050):
        if not _3fdeeb8e034d:
            return _004ab2a67f10

        if _1f52823b1019 == "exact_match":
            return _3fdeeb8e034d[0] if _6425a7887113(_967b85336ed5 == _3fdeeb8e034d[0] for _967b85336ed5 in _3fdeeb8e034d) else _004ab2a67f10

        if _1f52823b1019 == "most_common":
            return _579753e9320d(_3fdeeb8e034d)._e7a6cbbbd9b4(1)[0][0]

        if _1f52823b1019 == "first":
            return _3fdeeb8e034d[0]

        raise _9f930188fa4f(f"Unknown vote mode: {_1f52823b1019}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _9d3e4daa1f47(self, _61c9939a88fa):
        _8ac972e79cb9 = _45a52a008360(_74c9229a9d6d for _dc0b22a18fc2 in self._03e93277f31e._3fdeeb8e034d() for _74c9229a9d6d in _dc0b22a18fc2)
        return _02c849d7c172(_74c9229a9d6d for _74c9229a9d6d in _61c9939a88fa if _74c9229a9d6d in _8ac972e79cb9)


    def _2730b43ce813(self, _c6c24b55b34d, _5e71d7560c70=_6f286ccafa31, _5bc83a70900d="cpu", _3f4c8a707e6e=_7e747897cf37):
        from collections import _01a85d4b5834
        import _22f79c2ae8bd

        _f17591b04463 = self._cf7b6bf5d6fa
        _39e62b9a69ba = self._5d0d28dc4a97
        _76da43a9ac97 = self._be98294757af

        def _387e747ce2e4(_f9877cd87da8):
            if _351eebf587ec(_f9877cd87da8, _22f79c2ae8bd._48448c804dbc):
                return _f9877cd87da8._cbccf314a5e9()._21ce1385ea5b(_c861017b4e3e=_5bc83a70900d)._ed5525cee105(-1)._739ee94bbd80()
            return _cff5b835c41c(_f9877cd87da8) if _351eebf587ec(_f9877cd87da8, (_cff5b835c41c, _02c849d7c172)) else [_f9877cd87da8]

        _1b177885b465 = _45a52a008360()
        _fd09cb742d68 = _01a85d4b5834(_cff5b835c41c)
        _22dd8bbcbc29 = _01a85d4b5834(_63db5a091a06)
        _91317d09febb = []

        if _5e71d7560c70:
            _5ca5f56b5416(f"[reconcile] start: num_outputs={_7a68e1d47bdf(_c6c24b55b34d)}")

        for _9141c4c81351 in _c6c24b55b34d:
            _6e80e7018e7a = _9141c4c81351["sample_ids"]
            _67d0853fccc5 = _9141c4c81351["chunk_ids"]
            _ae55ed57c583 = _9141c4c81351["preds"]
            _f6e6159996a2 = _9141c4c81351["labels"]
            _62fb33b5c607 = _9141c4c81351["word_positions"]
            _52cfbec22abc = _9141c4c81351["prompt_lens"]
            _dbc89782e4de = _9141c4c81351["num_chunks"]

            for _4884ccc7d273, _3798f25b3880 in _40fd1d7ef032(_6e80e7018e7a):
                _554fb287bd1c = _63db5a091a06(_67d0853fccc5[_4884ccc7d273])
                if (_3798f25b3880, _554fb287bd1c) in _1b177885b465:
                    continue
                _1b177885b465._83cbeaa3a043((_3798f25b3880, _554fb287bd1c))

                _22dd8bbcbc29[_3798f25b3880] = _63db5a091a06(_dbc89782e4de[_4884ccc7d273])
                _62cd1cb649ae = _63db5a091a06(_52cfbec22abc[_4884ccc7d273])
                _5d8681c8a444 = _7a716d48eddf(_62fb33b5c607[_4884ccc7d273])
                
                # Right pad 
                # preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_raw = to_list(chunk_labels[i])[prompt_len_i:]

                # left pad
                # preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                # labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _15b991250ea1  = _7a716d48eddf(_ae55ed57c583[_4884ccc7d273])
                _4ab095612920 = _7a716d48eddf(_f6e6159996a2[_4884ccc7d273])

                _efcf3fcfb16a  = [_f717e32729bd for _f717e32729bd, _43b4fa0979f6 in _c4642c625e11(_15b991250ea1, _4ab095612920) if _43b4fa0979f6 != _f17591b04463]
                _57988bada600 = [_43b4fa0979f6 for _43b4fa0979f6 in _4ab095612920 if _43b4fa0979f6 != _f17591b04463]
                #PROMPT LEN
                # if not left_pad:
                #     preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                #     labels_raw = to_list(chunk_labels[i])[prompt_len_i:]
                # else:
                #     preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                #     labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _3f7432c3e530 = [_f717e32729bd for _f717e32729bd in _efcf3fcfb16a if _f717e32729bd != _f17591b04463]
                _341de67d062b = [_43b4fa0979f6 for _43b4fa0979f6 in _57988bada600 if _43b4fa0979f6 != _f17591b04463]

                if _3798f25b3880 not in _91317d09febb:
                    _91317d09febb._6a651bb11d5d(_3798f25b3880)

                _fd09cb742d68[_3798f25b3880]._6a651bb11d5d((_554fb287bd1c, _5d8681c8a444, _3f7432c3e530, _341de67d062b))

        _60b235c1ed72 = _9f5ce76e7050
        _87201fb05534 = {}
        _4654441b8e80 = {}

        for _3798f25b3880 in _91317d09febb:
            _0d5167987fdc = _fd09cb742d68[_3798f25b3880]
            if _7a68e1d47bdf(_0d5167987fdc) != _22dd8bbcbc29[_3798f25b3880]:
                if _5e71d7560c70:
                    _5ca5f56b5416(f"Skipping sample {_3798f25b3880}: expected {_22dd8bbcbc29[_3798f25b3880]} chunks, got {_7a68e1d47bdf(_0d5167987fdc)}")
                continue

            _0d5167987fdc._13e81ae10ce8(_cfb6a35e5a9a=lambda _f9877cd87da8: _f9877cd87da8[0])

            if _60b235c1ed72 is _9f5ce76e7050 and _7a68e1d47bdf(_0d5167987fdc) > 1:
                _60b235c1ed72 = _3798f25b3880

            # Split into words
            _ff4c7f5a3b36 = []
            for _554fb287bd1c, _052ffae76cd1, _38295949ecf9, _b4ecd16ce93c in _0d5167987fdc:
                _0d2d51ce5094 = self._eac784e38206(_052ffae76cd1, -1)
                _640f209351ee = self._eac784e38206(_38295949ecf9, _39e62b9a69ba)
                _6fe7d4e8fd73 = self._eac784e38206(_b4ecd16ce93c, _39e62b9a69ba)
                _41fa9a56c700 = _7a68e1d47bdf(_0d2d51ce5094)
                if _7a68e1d47bdf(_640f209351ee) < _41fa9a56c700:
                    _640f209351ee += [(_76da43a9ac97,)] * (_41fa9a56c700 - _7a68e1d47bdf(_640f209351ee))
                if _7a68e1d47bdf(_6fe7d4e8fd73) < _41fa9a56c700:
                    _6fe7d4e8fd73 += [(_f17591b04463,)] * (_41fa9a56c700 - _7a68e1d47bdf(_6fe7d4e8fd73))
                _ff4c7f5a3b36._6a651bb11d5d((_0d2d51ce5094, _640f209351ee, _6fe7d4e8fd73))

            # Vote per word position
            _cec472c1fb9d = _01a85d4b5834(_cff5b835c41c)
            _7efb687f66b9 = _01a85d4b5834(_cff5b835c41c)
            for _0d2d51ce5094, _640f209351ee, _6fe7d4e8fd73 in _ff4c7f5a3b36:
                for _e242ce2ae08e, _5d8811b95ef4, _033d12887cd6 in _c4642c625e11(_0d2d51ce5094, _640f209351ee, _6fe7d4e8fd73):
                    _052ffae76cd1 = _e242ce2ae08e[0]
                    # pred_votes[pos].append(wpred)
                    _31beab0f1196 = self._3a04755afdec(_5d8811b95ef4)
                    if _31beab0f1196:
                        _cec472c1fb9d[_052ffae76cd1]._6a651bb11d5d(_31beab0f1196)
                    else:
                        _cec472c1fb9d[_052ffae76cd1]._6a651bb11d5d((_76da43a9ac97,))

                    _7efb687f66b9[_052ffae76cd1]._6a651bb11d5d(_033d12887cd6)

            _a78b2f41faaa = _5d88e5b6f2ff(_cec472c1fb9d._c1c9dca3e93c())

            _f03ef7307b6d = [self._f4d1db7af5f0(_cec472c1fb9d[_f717e32729bd], _1f52823b1019="most_common", _004ab2a67f10=(_76da43a9ac97,)) for _f717e32729bd in _a78b2f41faaa]
            _bdec20a0bd2f = []
            for _f717e32729bd in _a78b2f41faaa:
                _fd1f26e6b6ab = _7efb687f66b9[_f717e32729bd]
                _a4a300b6955c = self._f4d1db7af5f0(_fd1f26e6b6ab, _1f52823b1019="most_common", _004ab2a67f10=_9f5ce76e7050)
                if _a4a300b6955c is _9f5ce76e7050:
                    for _b94385376a6b in _fd1f26e6b6ab:
                        if _f17591b04463 not in _b94385376a6b:
                            _a4a300b6955c = _b94385376a6b
                            break
                    if _a4a300b6955c is _9f5ce76e7050:
                        _a4a300b6955c = _fd1f26e6b6ab[0]
                _bdec20a0bd2f._6a651bb11d5d(_a4a300b6955c)

            # Reconstruct
            _ff983a9f4fca = []
            _b389760d662a = []
            for _4884ccc7d273 in _6df69cdb4343(_7a68e1d47bdf(_a78b2f41faaa)):
                _ff983a9f4fca._8e6fd433d1a9(_f03ef7307b6d[_4884ccc7d273])
                _b389760d662a._8e6fd433d1a9(_bdec20a0bd2f[_4884ccc7d273])
                if _4884ccc7d273 < _7a68e1d47bdf(_a78b2f41faaa) - 1:
                    _ff983a9f4fca._6a651bb11d5d(_39e62b9a69ba)
                    _b389760d662a._6a651bb11d5d(_39e62b9a69ba)

            # print(f"check labels final {(sum(1 for x in recon_labels if x == sep_token))}")

            _87201fb05534[_3798f25b3880] = _22f79c2ae8bd._be3ce29a45ce(_ff983a9f4fca, _c861017b4e3e=_5bc83a70900d)
            _4654441b8e80[_3798f25b3880] = _22f79c2ae8bd._be3ce29a45ce(_b389760d662a, _c861017b4e3e=_5bc83a70900d)

        if _5e71d7560c70 and _60b235c1ed72 is not _9f5ce76e7050:
            _5ca5f56b5416(f"[SUMMARY] reconciled samples in batch = {_7a68e1d47bdf(_91317d09febb)} "
                f"sid={_60b235c1ed72} total_preds={_7a68e1d47bdf(_87201fb05534[_60b235c1ed72])} "
                f"total_labels={_7a68e1d47bdf(_4654441b8e80[_60b235c1ed72])} "
                f"raw_preds {_87201fb05534[_60b235c1ed72]} and raw_labels {_4654441b8e80[_60b235c1ed72]} "
                f"chunks {_fd09cb742d68[_60b235c1ed72]}")

        _87e96eb5d864 = _0c85c207328f(_7a68e1d47bdf(_43b4fa0979f6) for _43b4fa0979f6 in _4654441b8e80._3fdeeb8e034d())
        _5ca5f56b5416(f"Total reconciled labels: {_87e96eb5d864}")

        _a30958a86485, _0397cf8ee0c7 = self._92d2bdb50770(
            _87201fb05534, _4654441b8e80, _5e71d7560c70=_5e71d7560c70, _5bc83a70900d=_5bc83a70900d
        )
        _bf3cdc3ef91e = _0c85c207328f(_7a68e1d47bdf(_43b4fa0979f6) for _43b4fa0979f6 in _0397cf8ee0c7._3fdeeb8e034d())
        _5ca5f56b5416(f"Total reconciled labels classes: {_bf3cdc3ef91e}")

        _8bddb983705d = _22f79c2ae8bd._9c0c099ef24d._7b7d3a5f481a() if _22f79c2ae8bd._9c0c099ef24d._4e130686a8cc() else -1
        _5ca5f56b5416(f"Rank {_8bddb983705d} samples are {_91317d09febb}")

        return _87201fb05534, _4654441b8e80, _a30958a86485, _0397cf8ee0c7

    def _148ac02c64e7(self, _87201fb05534, _4654441b8e80, _5e71d7560c70=_6f286ccafa31, _5bc83a70900d="cpu"):
        _1eaba7ec11a7 = _6e8b1ff0d420(self, "seq2class", {})
        _39e62b9a69ba = _6e8b1ff0d420(self, "tokenizer_separator_token", _9f5ce76e7050)
        _f17591b04463 = _6e8b1ff0d420(self, "ignore_idx", -100)
        
        def _b1f88fba5005(_5f2d91c7e822, _782817a8da55):
            _e8dd85d58569 = []
            _93834381ea86 = []
            for _4884ccc7d273, token in _40fd1d7ef032(_5f2d91c7e822):
                if token == _782817a8da55 and _93834381ea86:
                    _e8dd85d58569._6a651bb11d5d(_93834381ea86)
                    _93834381ea86 = []
                elif token != _782817a8da55:
                    _93834381ea86._6a651bb11d5d(token)
            if _93834381ea86:
                _e8dd85d58569._6a651bb11d5d(_93834381ea86)
            return _e8dd85d58569
        
        def _3df66294a295(_19cccf888ddb, _1eaba7ec11a7, _5e71d7560c70, _3798f25b3880):
            _9141c4c81351 = []
            _60eae98a0f55 = _5d88e5b6f2ff(_1eaba7ec11a7._c1c9dca3e93c(), _cfb6a35e5a9a=_7a68e1d47bdf, _b21340afef78=_6f286ccafa31)
            for _4884ccc7d273, _02019c75f2e5 in _40fd1d7ef032(_19cccf888ddb, 1):
                _395cdf16eff0 = _02c849d7c172(_02019c75f2e5)
                _efa1bbf74143 = self._be98294757af
                for _cfb6a35e5a9a in _60eae98a0f55:
                    if _7a68e1d47bdf(_395cdf16eff0) >= _7a68e1d47bdf(_cfb6a35e5a9a) and _395cdf16eff0[:_7a68e1d47bdf(_cfb6a35e5a9a)] == _cfb6a35e5a9a:
                        _efa1bbf74143 = _1eaba7ec11a7[_cfb6a35e5a9a]
                        break
                _9141c4c81351._6a651bb11d5d(_efa1bbf74143)

            return _9141c4c81351
        
        _399919f19e80, _1ac6672f6ebb = {}, {}
        for _3798f25b3880 in _87201fb05534:
            _f717e32729bd = _87201fb05534[_3798f25b3880]
            _43b4fa0979f6 = _4654441b8e80._0e89f6560e35(_3798f25b3880, _9f5ce76e7050)
            _8f674c594c46 = _f717e32729bd._739ee94bbd80() if _351eebf587ec(_f717e32729bd, _22f79c2ae8bd._48448c804dbc) else _cff5b835c41c(_f717e32729bd)
            _4f5636f78a59 = _43b4fa0979f6._739ee94bbd80() if _351eebf587ec(_43b4fa0979f6, _22f79c2ae8bd._48448c804dbc) else _cff5b835c41c(_43b4fa0979f6) if _43b4fa0979f6 else _9f5ce76e7050
            if _4f5636f78a59 is not _9f5ce76e7050:
                _361d357c23a0 = _dd993c5e721b(_4f5636f78a59, _39e62b9a69ba)
                _35748126fe33 = _6a0c5178d602(_361d357c23a0, _1eaba7ec11a7, _3798f25b3880 == 1 or _5e71d7560c70, _3798f25b3880)
                _f9c56a9eb8b8 = _dd993c5e721b(_8f674c594c46, _39e62b9a69ba)
                _f4f014c2ddb0 = _6a0c5178d602(_f9c56a9eb8b8, _1eaba7ec11a7, _3798f25b3880 == 1 or _5e71d7560c70, _3798f25b3880)
                if _7a68e1d47bdf(_f4f014c2ddb0) < _7a68e1d47bdf(_35748126fe33):
                    _f4f014c2ddb0 += [0] * (_7a68e1d47bdf(_35748126fe33) - _7a68e1d47bdf(_f4f014c2ddb0))
                elif _7a68e1d47bdf(_f4f014c2ddb0) > _7a68e1d47bdf(_35748126fe33):
                    _f4f014c2ddb0 = _f4f014c2ddb0[:_7a68e1d47bdf(_35748126fe33)]
            else:
                _f9c56a9eb8b8 = _dd993c5e721b(_8f674c594c46, _39e62b9a69ba)
                _f4f014c2ddb0 = _6a0c5178d602(_f9c56a9eb8b8, _1eaba7ec11a7, _3798f25b3880 == 1 or _5e71d7560c70, _3798f25b3880)
                _35748126fe33 = [_f17591b04463] * _7a68e1d47bdf(_f4f014c2ddb0)
            _399919f19e80[_3798f25b3880] = _22f79c2ae8bd._be3ce29a45ce(_f4f014c2ddb0, _c861017b4e3e=_5bc83a70900d, _a313c9f76a9f=_22f79c2ae8bd._c50b6dfa918b)
            _1ac6672f6ebb[_3798f25b3880] = _22f79c2ae8bd._be3ce29a45ce(_35748126fe33, _c861017b4e3e=_5bc83a70900d, _a313c9f76a9f=_22f79c2ae8bd._c50b6dfa918b)
        return _399919f19e80, _1ac6672f6ebb

    def _19ae763832c7(self, _18c52502a05c):
        _22f79c2ae8bd._a23190b10449._adf3aef31199._59da251159f7(self._6fbe416077a6(), _b8d7ca81c001=1.0)
    
    def _8ae360c2709c(self, _18c52502a05c):
        for _6b5e693ad798 in self._6fbe416077a6():
            if _6b5e693ad798 is not _9f5ce76e7050:
                _6b5e693ad798._62c845071373._600bf48bbbcd(-5, 5)

    def _a7e0f15848ed(self):
        _d3a25cd4d519 = 0
        for _6b5e693ad798 in self._6fbe416077a6():
            if _6b5e693ad798._1a044514b871 is not _9f5ce76e7050:
                _4458a7361078 = _6b5e693ad798._1a044514b871._cbccf314a5e9()._62c845071373._31beab0f1196(2)
                _d3a25cd4d519 += _4458a7361078._6290a4defde8() ** 2
        return _d3a25cd4d519 ** 0.5  # L2 norm

    def _942ffd1ba76b(self):
        _74ffcbe7a605 = [_f717e32729bd for _f717e32729bd in self._6fbe416077a6() if _f717e32729bd._441565d94a06]
        if not _74ffcbe7a605:
            _5ca5f56b5416("No trainable parameters. Skipping optimizer creation.")
            return _9f5ce76e7050
        
        _75c15805a1ba = _73f5fb081173(lambda _f717e32729bd: _f717e32729bd._441565d94a06, self._6fbe416077a6())

        _3d77ecc155aa = {
            "adamw": _22f79c2ae8bd._2ff6ea74461b._9f4db1d4b8a1,
            "adamax": _22f79c2ae8bd._2ff6ea74461b._79ea62d60a8a,
            "adam": _22f79c2ae8bd._2ff6ea74461b._71d019cd386d,
        }
        _e7df9bcb2076 = _3d77ecc155aa._0e89f6560e35(self._5c355e9832a6._942a52703d25(), _22f79c2ae8bd._2ff6ea74461b._71d019cd386d)

        _18c52502a05c = _e7df9bcb2076(_75c15805a1ba, _c4ff59e997a0=self._b0b80fb24f55._c4ff59e997a0, _fb5b586f6019=0.001)

        _7dc2b0ad93eb = self._756745c57740._07d535723280
        _79ae0073f0f5 = math._c6985909740b(0.1 * _7dc2b0ad93eb)

        _89077747e32e = _22f79c2ae8bd._2ff6ea74461b._6455c8521ea0._c6f0218b48a6(_18c52502a05c, _6bb55c841f53=lambda _9baeb9c07b49: (_9baeb9c07b49 + 1) / _79ae0073f0f5)

        _1770f2e53149 = _22f79c2ae8bd._2ff6ea74461b._6455c8521ea0._bcb89cc641b9(
            _18c52502a05c,
            _696267f7f727=_30b8beb3c8a8(1, _7dc2b0ad93eb - _79ae0073f0f5),
            _ed3f0cdff42f=2,
            _3c8939152085=1e-6
        )
        _6455c8521ea0 = _22f79c2ae8bd._2ff6ea74461b._6455c8521ea0._ff151d6edb49(
            _18c52502a05c,
            _a18f9528d8b4=[_89077747e32e, _1770f2e53149],
            _efeb3be081c2=[_79ae0073f0f5]
        )
        return {"optimizer": _18c52502a05c, "lr_scheduler": {"scheduler": _6455c8521ea0, "interval": "epoch", "monitor": "val_loss"}}
