# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _68c01c4a81e4, _43ee62b029df
import copy
from _4568f0b2d24f import _aa6d81fe839b
import _7242f866a5da
import math
import os
from typing import _fc78cb4366ff
import _307444462956 as _34bc2137b59f
import _f2fb0bfbfcf7 as _4fbc6a996c53
import _f192b1da4894
import _9ad21a0addb0 as _049bae320338
from _7888fd1cd60a import _749f3a325f8b, _ebe08ee033ce
from _7888fd1cd60a._1b6d3536b8dc._85258e383ab2._d6df944e0aec import _aa41809b6bc2
from _cab6338ded55 import _7dd18447387f, _9464c3bec807, _bca3abdc14b8, _28d4d249d7b8, _ab5937ff1b69

from _4e97385f6ca7._08519df12fd4._d9f45bf4165e._742dac803c55 import _6ef27838377f
from _4e97385f6ca7._08519df12fd4._2f81a2d6b4d8._11ff1459f8d7 import _3476aa6dcabe
from _4e97385f6ca7._08519df12fd4._2f81a2d6b4d8._2a41f4ed61af import _2798e9d0d841
from _4e97385f6ca7._08519df12fd4._2f81a2d6b4d8._f05357946e0a import _a78ecc794e86
from _4e97385f6ca7._08519df12fd4._9ca62ab14fba._dfe04302c7aa import _af27591a940e
# expose only the classifier from the module
_8b79bb14f345 = ["GenLLMLanguageIdentificationClassifier"]

_1957f5335d25 = 'cuda' if _f192b1da4894._d27e405b60bd._fb8fc813cdd6() else 'cpu'
_58a69a24ae75 = _2849d2c6b003  # global frozen embedding (kept for compatibility)


class _07791f1044c6(_749f3a325f8b):
    def _ab69a88579f2(self, _b5d5da521385, _ab4bb9141267=_2849d2c6b003, _8fdd098a1d45=_2849d2c6b003):
        self._5561967feb49 = _aaa028a68050(_b5d5da521385)
        self._f7c4b93663fb = _ab4bb9141267
        self._6fdc64977ff9 = _8fdd098a1d45

    def _e4c8dddbbc0a(self, _49e91bb33f65, _33503205669e):
        _ac584c609eaa = _f192b1da4894._f82bf148edf7(_33503205669e, _0d9fe2e75519("-inf"))

        for _b3d857e333ea in self._5561967feb49:
            _ac584c609eaa[:, _b3d857e333ea] = 0.0

        if self._f7c4b93663fb is not _2849d2c6b003:
            _ac584c609eaa[:, self._f7c4b93663fb] = 0.0

        if self._6fdc64977ff9 is not _2849d2c6b003:
            _ac584c609eaa[:, self._6fdc64977ff9] = 0.0

        return _33503205669e + _ac584c609eaa
    
class _0096f5e2e33f(_049bae320338._d78345909204):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """
    _ff7791ce9e99 = {}

    class _2127c9e258f4(_f192b1da4894._bcd2eab0d27e._538ce2640056):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _ab69a88579f2(self, _57a0a06ccf7b: _32747a27810c, _5b8a389ab9e7: _32747a27810c = 64):
            _a468d6aa49eb()._2ca052ae894a()
            self._394be8f949fc = _f192b1da4894._bcd2eab0d27e._145d74d51e02(_57a0a06ccf7b, _5b8a389ab9e7, _48d4b3343ccf=_1251a544230f)
            self._42b7f16801f9 = _f192b1da4894._bcd2eab0d27e._017c1d70d32b(_c5c74386b35d=_7a49cf610f5c)
            self._30ccee458142 = _f192b1da4894._bcd2eab0d27e._145d74d51e02(_5b8a389ab9e7, _57a0a06ccf7b, _48d4b3343ccf=_1251a544230f)
            # start adapter near-zero so initial behavior is identity
            _f192b1da4894._bcd2eab0d27e._9cf904f9f8eb._32d5c89bc266(self._30ccee458142._7dcf5627c027)
            _f192b1da4894._bcd2eab0d27e._9cf904f9f8eb._0d5900de8500(self._394be8f949fc._7dcf5627c027, _017e4d464101=math._34aa5af96098(5))

        def _8aba62045ed5(self, _d01139785437: _f192b1da4894._28a2eb79e8c9) -> _f192b1da4894._28a2eb79e8c9:
            # supports x shape (B, L, D) or (B, D)
            if _d01139785437._57a0a06ccf7b() == 2:
                _9ef6e826a002 = self._30ccee458142(self._42b7f16801f9(self._394be8f949fc(_d01139785437)))
                return _d01139785437 + _9ef6e826a002
            _eecd6553f595, _04d63b9577f0, _760ad07da335 = _d01139785437._deff0a3fcc0b
            _721f0bfc4246 = _d01139785437._48e2fe3e0256(-1, _760ad07da335)                    # (B*L, D)
            _721f0bfc4246 = self._30ccee458142(self._42b7f16801f9(self._394be8f949fc(_721f0bfc4246)))  # (B*L, D)
            _721f0bfc4246 = _721f0bfc4246._48e2fe3e0256(_eecd6553f595, _04d63b9577f0, _760ad07da335)
            return _d01139785437 + _721f0bfc4246


    class _71bdfe4a5689(_f192b1da4894._bcd2eab0d27e._538ce2640056):
        def _ab69a88579f2(self, _57a0a06ccf7b: _32747a27810c, _e4a2c79ede72: _f192b1da4894._bcd2eab0d27e._538ce2640056, _5b8a389ab9e7: _32747a27810c = 64):
            _a468d6aa49eb()._2ca052ae894a()
            self._394be8f949fc = _f192b1da4894._bcd2eab0d27e._145d74d51e02(_57a0a06ccf7b, _5b8a389ab9e7, _48d4b3343ccf=_1251a544230f)
            self._42b7f16801f9 = _f192b1da4894._bcd2eab0d27e._017c1d70d32b(_c5c74386b35d=_7a49cf610f5c)
            self._30ccee458142 = _f192b1da4894._bcd2eab0d27e._145d74d51e02(_5b8a389ab9e7, _57a0a06ccf7b, _48d4b3343ccf=_1251a544230f)
            self._e4a2c79ede72 = _e4a2c79ede72

            _f192b1da4894._bcd2eab0d27e._9cf904f9f8eb._32d5c89bc266(self._30ccee458142._7dcf5627c027)
            _f192b1da4894._bcd2eab0d27e._9cf904f9f8eb._0d5900de8500(self._394be8f949fc._7dcf5627c027, _017e4d464101=math._34aa5af96098(5))

        def _f0786fc23ca9(self, _2eab38b2c194):
            if _2eab38b2c194._57a0a06ccf7b() == 3:
                _eecd6553f595, _04d63b9577f0, _760ad07da335 = _2eab38b2c194._deff0a3fcc0b
                _721f0bfc4246 = _2eab38b2c194._48e2fe3e0256(-1, _760ad07da335)
                _721f0bfc4246 = _721f0bfc4246 + self._30ccee458142(self._42b7f16801f9(self._394be8f949fc(_721f0bfc4246)))
                return _721f0bfc4246._48e2fe3e0256(_eecd6553f595, _04d63b9577f0, _760ad07da335)
            return _2eab38b2c194 + self._30ccee458142(self._42b7f16801f9(self._394be8f949fc(_2eab38b2c194)))

        def _8aba62045ed5(self, _2eab38b2c194):
            _2eab38b2c194 = self._c4212d9ce171(_2eab38b2c194)
            return self._e4a2c79ede72(_2eab38b2c194)

    class _7b9dc1e51d60(_f192b1da4894._bcd2eab0d27e._538ce2640056):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _ab69a88579f2(self, _a6cfdb24a2d4, _4dd44d262cb8=-5, _24fd02eb63f7=5):
            _a468d6aa49eb()._2ca052ae894a()
            self._a6cfdb24a2d4 = _a6cfdb24a2d4
            self._4dd44d262cb8 = _4dd44d262cb8
            self._24fd02eb63f7 = _24fd02eb63f7
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _8aba62045ed5(self, *_28bfdea125e4, **_426ca89c65f6):
            _28bfdea125e4 = _751e7ef22ac6(
                _0252a94cd817._1ac1b791041c(_f192b1da4894._e31a298d4c7a)._5d72f50b3a5c(-10, 10) if _d2f2e1f42ed3(_0252a94cd817, _f192b1da4894._28a2eb79e8c9) and _0252a94cd817._681866af905b != _f192b1da4894._e31a298d4c7a else _0252a94cd817
                for _0252a94cd817 in _28bfdea125e4
            )
            for _783cc5d822d3, _0252a94cd817 in _84eb25ce8b8d(_28bfdea125e4):
                if _d2f2e1f42ed3(_0252a94cd817, _f192b1da4894._28a2eb79e8c9) and not _f192b1da4894._115a5c30e50a(_0252a94cd817)._897cd1c6424e():
                    _0252a94cd817 = _f192b1da4894._538e1c5b2bfd(_0252a94cd817)
            _2099bbd3a160 = self._a6cfdb24a2d4(*_28bfdea125e4, **_426ca89c65f6)
            if _d2f2e1f42ed3(_2099bbd3a160, _f192b1da4894._28a2eb79e8c9):
                _2099bbd3a160 = _2099bbd3a160._1ac1b791041c(_f192b1da4894._e31a298d4c7a)
                if not _f192b1da4894._115a5c30e50a(_2099bbd3a160)._897cd1c6424e():
                    _2099bbd3a160 = _f192b1da4894._538e1c5b2bfd(_2099bbd3a160)
                _2099bbd3a160._ba775e98f547(self._4dd44d262cb8, self._24fd02eb63f7)
            return _2099bbd3a160

    # --- original __init__ signature and body preserved ---
    def _ab69a88579f2(
        self,
        _a5f34af268a5,
        _8037fe6ff521,
        _d5c53fd31634,
        _669c9012ef4c,
        _db2fe3acc10c,
        _050e9adfb4a2,
        _1acbf5673b2c,
        _51d8721c5d01,
        _49f3c6d8688b,
        _f0d6ca335455,
        _7f467abcb5b3,
        _5151d3eb3373: _32747a27810c = 20,
        _e6e3054379c0 = _2849d2c6b003,
        _fcf741edc50b=_2849d2c6b003,
        _4b34b6650054=0.9,
        _c8d2a670c082:_572f70e39e74=_2849d2c6b003,
    ):
        _a468d6aa49eb(_60fc544baef3, self)._2ca052ae894a()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._97bda6acf1a7({
            "lr": _0d9fe2e75519(_d5c53fd31634),
            "optimizer": _572f70e39e74(_669c9012ef4c),
            "num_backbone_model_units_unfrozen": _32747a27810c(_1acbf5673b2c),
            "loss_type": _572f70e39e74(_51d8721c5d01),
            "is_train": _5f643a74fe19(_49f3c6d8688b),
            "random_seed": _32747a27810c(_5151d3eb3373),
        })
        self._5151d3eb3373 = _5151d3eb3373
        _049bae320338._88cb9c741f6f(_5151d3eb3373, _f75acc0ba301=_7a49cf610f5c)
        _f192b1da4894._f0c145cb57ae(_5151d3eb3373)
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            _f192b1da4894._d27e405b60bd._9c2e3c9c560e(_5151d3eb3373)
        _34bc2137b59f.random._3bed5d2b7e86(_5151d3eb3373)
        self._a2a7a06d27e5 = 0.2
        self._fcf741edc50b = _32747a27810c(_fcf741edc50b) if _fcf741edc50b is not _2849d2c6b003 else _2849d2c6b003
        _f0d6ca335455._7853e1ecc913 = "left"
        self._f0d6ca335455 = _f0d6ca335455
        self._c8d2a670c082 = _c8d2a670c082
        self._c753f00f0754 = 0.2 # for preventing model shift dominance
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
        #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
        #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
        #     print(f"Added padding token  <PAD> with (id: {tid})")
        if not self._f0d6ca335455._2f7ff56c8604:
            self._f0d6ca335455._e7da60171f34(["_P"], _b9b92b9cb5a9=_1251a544230f)
            _b3d857e333ea = self._f0d6ca335455._36c2f1b7e01d("_P")
            self._f0d6ca335455._2f7ff56c8604 = _b3d857e333ea
            _baa3444fd29b(f"Added padding token  _P with (id: {_b3d857e333ea})")
        
        # self.tokenizer_separator_token = tokenizer.encode(" ", add_special_tokens=False)[0]
        self._2c14781b65bc = _f0d6ca335455._195f6a444f0f("||", _0183928f2991=_1251a544230f)[0]
        self._35e8c2f15256 = (
            _f192b1da4894._27d26c411d25("cuda:{}"._ae87bff269eb(_050e9adfb4a2["gpu_local_rank"]))
            if _050e9adfb4a2["gpu_local_rank"] != -1
            else "cpu"
        )
        self._e6e3054379c0 = _e6e3054379c0
        self._4b34b6650054 = _4b34b6650054
        self._8037fe6ff521 =  ["unk"] + _8037fe6ff521 if self._4b34b6650054 > 0 else _8037fe6ff521
        self._c20b3b7f7de9 = _aafa26e6820f(self._8037fe6ff521)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._8c0218d0fb5d = {}
        # FOR NEW TOKEN COMMENT THIS
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        
        # FOR NEW TOKEN UNCOMMENT THIS
        # Add only if class name splits into >1 token
        # for cname in self.class_names:
        #     if len(self.tokenizer.encode(cname, add_special_tokens=False)) > 1:
        #         token = f"{cname}"
        #         if token not in self.tokenizer.get_vocab():
        #             self.tokenizer.add_tokens([token], special_tokens=False)
        #             tid = self.tokenizer.convert_tokens_to_ids(token)
        #             print(f"Added class '{cname}' Token: {token} (id: {tid})")

        # Map every class to single token ID
        for _61ed1ff3e4bc in self._8037fe6ff521:
            if _61ed1ff3e4bc not in _60fc544baef3._ff7791ce9e99:
                _428a2f2312fa = _f0d6ca335455._195f6a444f0f(_61ed1ff3e4bc, _0183928f2991=_1251a544230f)
                if _aafa26e6820f(_428a2f2312fa) > 1:
                    _60fc544baef3._ff7791ce9e99[_61ed1ff3e4bc] = f"{_aafa26e6820f(_60fc544baef3._ff7791ce9e99)}"
                else:
                    _60fc544baef3._ff7791ce9e99[_61ed1ff3e4bc] = _61ed1ff3e4bc
        
        self._8c0218d0fb5d = {
            _9482cd521cf3: [self._f0d6ca335455._36c2f1b7e01d(_60fc544baef3._ff7791ce9e99._45b5853ca19a(_61ed1ff3e4bc))]
            for _9482cd521cf3, _61ed1ff3e4bc in _84eb25ce8b8d(self._8037fe6ff521)
        }

        self._14fee23c372f = _ebe08ee033ce([
            _5c321af20d2c(
                _b5d5da521385=[
                    _b3d857e333ea
                    for _333ba7af4cbb in self._8c0218d0fb5d._f77b12ff6cce()
                    for _b3d857e333ea in _333ba7af4cbb
                ],
                _ab4bb9141267=self._2c14781b65bc,
                _8fdd098a1d45=self._f0d6ca335455._8fdd098a1d45
            )
        ])
        # self.class2seq = {
        #     idx: [self.tokenizer.convert_tokens_to_ids(f"{cname}")]
        #     for idx, cname in enumerate(self.class_names)
        # }

        self._15e1e5b1e797 = {_751e7ef22ac6(_333ba7af4cbb): _fa4e7493198c for _fa4e7493198c, _333ba7af4cbb in self._8c0218d0fb5d._c500e970711d()}
        self._a552f607b7cc = _43ee62b029df(_74b108c551fb)
        for _d0381cc70a2f, _333ba7af4cbb in self._8c0218d0fb5d._c500e970711d():
            self._a552f607b7cc[_aafa26e6820f(_333ba7af4cbb)]._a855f6a39116((_d0381cc70a2f, _333ba7af4cbb))
        self._86a84fb647c1 = 0
        _baa3444fd29b(f"SEQ {self._8c0218d0fb5d} and {self._15e1e5b1e797}")
        self._a6a7134aac69 = _f0d6ca335455._2f7ff56c8604 or _f0d6ca335455._8fdd098a1d45
        self._db2fe3acc10c = _db2fe3acc10c
        self._e6d7fd155ff6 = "multiclass"
        self._1cd77dc4c442 = -100
        self._3cab24f92274 = _f0d6ca335455._195f6a444f0f("assistant<|end_header_id|>\n\n", _0183928f2991=_1251a544230f)
        self._da92679cc551 = self._0de5e5ebc14b()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._03f3cf0aa07f = _a5f34af268a5
        # Resize vocab based token embeddings
        self._03f3cf0aa07f._7d65b65c1d27(_aafa26e6820f(self._f0d6ca335455))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._03f3cf0aa07f._e8f1b97f3b1d(_1251a544230f)
        _5b5359916c30 = _af27591a940e()  # bfloat16 or float16

        for _f4200e5e297a, _a6cfdb24a2d4 in self._c854351d5b88():
            if not _408cf93be998(_3767dd22a0cc._884a6deba20a for _3767dd22a0cc in _a6cfdb24a2d4._c441aec0ba5e(_4e74ea269231=_1251a544230f)):
                # FROZEN → BF16 (save memory)
                _a6cfdb24a2d4._1ac1b791041c(_681866af905b=_5b5359916c30)
            else:
                # TRAINABLE → FP32 (stable grads)
                _a6cfdb24a2d4._1ac1b791041c(_681866af905b=_f192b1da4894._e31a298d4c7a)
        self._03f3cf0aa07f._1ac1b791041c(self._35e8c2f15256)
        if _a0d1a63a0858(self._03f3cf0aa07f, "gradient_checkpointing_enable"):
            self._03f3cf0aa07f._69e136ba06e9()
        # determine embedding dim robustly from model config if available
        _95a00c85958b = _f26edc77e0cf(_f26edc77e0cf(self._03f3cf0aa07f, "config", _2849d2c6b003), "hidden_size", _2849d2c6b003)
        if _95a00c85958b is _2849d2c6b003:
            # fallback to common default — change if your model uses a different hidden size
            _95a00c85958b = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        # if hasattr(self.embedding, "lm_head") and getattr(self.embedding, "lm_head") is not None:
        #     self._lm_head = self.embedding.lm_head
        # else:
        #     get_out = getattr(self.embedding, "get_output_embeddings", None)
        #     self._lm_head = get_out() if callable(get_out) else None

        # # mark presence and ensure module (if any) is on the same device
        # self._has_lm_head = self._lm_head is not None
        # if self._has_lm_head:
        #     # move lm_head params/buffers to the model device (safe no-op if already there)
        #     self._lm_head.to(self.curr_device)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        # self.adapter = self._Adapter(dim=embedding_dim, bottleneck=64)
        # self.adapter.to(self.curr_device)
        # for p in self.adapter.parameters():
        #     p.requires_grad = True
        _e4a2c79ede72 = (
            self._03f3cf0aa07f._e4a2c79ede72
            if _a0d1a63a0858(self._03f3cf0aa07f, "lm_head")
            else self._03f3cf0aa07f._2c7c9526363c()
        )

        self._03f3cf0aa07f._e4a2c79ede72 = self._18962bd12710(
            _57a0a06ccf7b=_95a00c85958b,
            _e4a2c79ede72=_e4a2c79ede72,
            _5b8a389ab9e7=64,
        )._1ac1b791041c(self._35e8c2f15256)

        # self.adapter = self.embedding.lm_head

        if _1acbf5673b2c > 0:
            # if "llama" in self.pretrained_model_embedding_name:
            if self._e6e3054379c0:
                for _0a54ca626609 in self._03f3cf0aa07f._c441aec0ba5e():
                    if not _0a54ca626609._184fb944cd09:
                        _0a54ca626609 = _0a54ca626609._2fa5eaf451f7()
                    _0a54ca626609._884a6deba20a = _1251a544230f  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _ed744f19c590 = self._03f3cf0aa07f._532c81d035eb._e9e7611c22f6  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _17e34249fa0d in _ed744f19c590[-_1acbf5673b2c:]:
                    for _0a54ca626609 in _17e34249fa0d._c441aec0ba5e():
                        if _d2f2e1f42ed3(_0a54ca626609, _f192b1da4894._28a2eb79e8c9) and (_0a54ca626609._4a5cb284ba11() or _f192b1da4894._1eff70a93670(_0a54ca626609)):
                            _0a54ca626609._884a6deba20a = _7a49cf610f5c
                for _0a54ca626609 in self._03f3cf0aa07f._e4a2c79ede72._c441aec0ba5e():
                    _0a54ca626609._884a6deba20a = _7a49cf610f5c

        self._257e93a7bfa7 = 1
        _baa3444fd29b(f"DEBUG xth_batch init {self._257e93a7bfa7}")
        global _58a69a24ae75
        _58a69a24ae75 = copy._7a63c0be0f79(self._03f3cf0aa07f)._cd0d115e6cd2()
        self._d5c53fd31634 = _d5c53fd31634

        self._fac11b50153c = {}
        self._c4b8d5bd96a7 = {}

        # Loss function initialization
        if _51d8721c5d01._8b9432d3c0de() == "class_weighted_cross_entropy_loss":
            self._c4b8d5bd96a7['criterion'] = _2798e9d0d841(_db2fe3acc10c=self._db2fe3acc10c,
                                                            _27d26c411d25=self._35e8c2f15256,
                                                            _2622a4cef7d7=self._1cd77dc4c442,
                                                            _2dd7fb2b8a45=self._2c14781b65bc)
        elif _51d8721c5d01._8b9432d3c0de() == "focal_loss":
            self._c4b8d5bd96a7['criterion'] = _a78ecc794e86(_7c79fb2f361e=0.25,
                                                     _27d26c411d25=self._35e8c2f15256,
                                                     _2622a4cef7d7=self._1cd77dc4c442,
                                                     _2dd7fb2b8a45=self._2c14781b65bc)
        elif _51d8721c5d01._8b9432d3c0de() == "class_weighted_focal_loss":
            self._c4b8d5bd96a7['criterion'] = _a78ecc794e86(_7c79fb2f361e=self._db2fe3acc10c,
                                                     _27d26c411d25=self._35e8c2f15256,
                                                     _2622a4cef7d7=self._1cd77dc4c442,
                                                     _2dd7fb2b8a45=self._2c14781b65bc)
        elif _51d8721c5d01._8b9432d3c0de() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._c4b8d5bd96a7['criterion'] = _3476aa6dcabe(_7c79fb2f361e=self._db2fe3acc10c,
                                                                      _4c13f3d6b6a3='type1',
                                                                      _27d26c411d25=self._35e8c2f15256,
                                                                      _2622a4cef7d7=self._1cd77dc4c442,
                                                                      _2dd7fb2b8a45=self._2c14781b65bc)
        elif _51d8721c5d01._8b9432d3c0de() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._c4b8d5bd96a7['criterion'] = _3476aa6dcabe(_7c79fb2f361e=self._db2fe3acc10c,
                                                                      _4c13f3d6b6a3='type2',
                                                                      _27d26c411d25=self._35e8c2f15256,
                                                                      _2622a4cef7d7=self._1cd77dc4c442,
                                                                      _2dd7fb2b8a45=self._2c14781b65bc)
        elif _51d8721c5d01._8b9432d3c0de() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._c4b8d5bd96a7['criterion'] = _3476aa6dcabe(_7c79fb2f361e=self._db2fe3acc10c,
                                                                      _4c13f3d6b6a3='type3',
                                                                      _27d26c411d25=self._35e8c2f15256,
                                                                      _2622a4cef7d7=self._1cd77dc4c442,
                                                                      _2dd7fb2b8a45=self._2c14781b65bc)
        else:
            self._c4b8d5bd96a7['criterion'] = _2798e9d0d841(_27d26c411d25=self._35e8c2f15256,
                                                            _2622a4cef7d7=self._1cd77dc4c442,)
        
        self._e45051f30fef = 0.99
        self._b4ca361ee42a = 0.3
        self._01250245524e = 0.30
        self._30f7965bbb88 = 0.25
        self._6107891e95fc = 0.6
        self._5054ff95b4f7 = 0.995
        self._68bc592f16e0 = 0.60
        self._3203bba56b56 = 0.20
        self._43bb5c40d44f = _f26edc77e0cf(self, "batch_counter", 0)


        self._1fbf49824ea6 = []
        self._83c0440f9287 = []

        self._8879b3260674 = _669c9012ef4c._8b9432d3c0de()
        self._5379ee550908()

        self._837be5e47a1f(self._03f3cf0aa07f)
    
    def _57192b85320f(self):
        # rebuild all metrics on the correct device
        self._fac11b50153c['micro_accuracy'] = _7dd18447387f(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a="micro",
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['macro_accuracy'] = _7dd18447387f(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a="macro",
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['macro_precision'] = _bca3abdc14b8(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a="macro",
            _dae84794a8eb=self. _e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['macro_recall'] = _28d4d249d7b8(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a="macro",
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['macro_f1'] = _ab5937ff1b69(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a="macro",
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['classwise_accuracy'] = _7dd18447387f(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a=_2849d2c6b003,
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['classwise_precision'] = _bca3abdc14b8(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a=_2849d2c6b003,
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['classwise_recall'] = _28d4d249d7b8(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a=_2849d2c6b003,
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['classwise_f1'] = _ab5937ff1b69(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _9c957b79176a=_2849d2c6b003,
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)

        self._fac11b50153c['confmat'] = _9464c3bec807(
            _c20b3b7f7de9=_aafa26e6820f(self._8037fe6ff521),
            _dae84794a8eb=self._e6d7fd155ff6,
            _2622a4cef7d7=self._1cd77dc4c442,
        )._1ac1b791041c(self._35e8c2f15256)


    def _a628818e7fa3(self, _9a455bcf71f5=_2849d2c6b003):
        """Calculate batch counts and set xth_batch_to_consider."""
        _e313ed128bba = 0
        _1b8a41bc18c3 = 0
        if self._68ca5bcaa851._3bc2c092ac41 is not _2849d2c6b003:
            if _a0d1a63a0858(self._68ca5bcaa851._3bc2c092ac41, 'train_dataset') and self._68ca5bcaa851._3bc2c092ac41._f879b44dcf61 is not _2849d2c6b003:
                _e313ed128bba = _aafa26e6820f(self._68ca5bcaa851._3bc2c092ac41._f879b44dcf61)
            if _a0d1a63a0858(self._68ca5bcaa851._3bc2c092ac41, 'val_dataset') and self._68ca5bcaa851._3bc2c092ac41._54d7f5160059 is not _2849d2c6b003:
                _1b8a41bc18c3 = _aafa26e6820f(self._68ca5bcaa851._3bc2c092ac41._54d7f5160059)
            _26bbce9b4483 = self._68ca5bcaa851._3bc2c092ac41._26bbce9b4483
            _b9c039cc3ded = (_e313ed128bba + _26bbce9b4483 - 1) // _26bbce9b4483 if _e313ed128bba > 0 else 1
            _997ad09bcc0f = (_1b8a41bc18c3 + _26bbce9b4483 - 1) // _26bbce9b4483 if _1b8a41bc18c3 > 0 else 1
            _b7a937a92f77 = _5d94f77ea2da(_b9c039cc3ded, _997ad09bcc0f) if _1b8a41bc18c3 > 0 else _b9c039cc3ded
            _947721fda201 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._257e93a7bfa7 = 1
            _baa3444fd29b(f"DEBUG Batch Info: num_train_batches={_b9c039cc3ded}, num_val_batches={_997ad09bcc0f}, xth_batch_to_consider={self._257e93a7bfa7}")

    def _164d26ecb55c(self, _e5fedb01cc8f, _13cc2e0780ca):
        if _e5fedb01cc8f._8b9432d3c0de() == "parametric_relu":
            return _f192b1da4894._bcd2eab0d27e._e8983a5f0d4d(_13cc2e0780ca=1)
        elif _e5fedb01cc8f._8b9432d3c0de() == "leaky_relu":
            return _f192b1da4894._bcd2eab0d27e._0d49ffb29c7d(_c5c74386b35d=_1251a544230f)
        else:
            return _f192b1da4894._bcd2eab0d27e._017c1d70d32b(_c5c74386b35d=_1251a544230f)
    
    def _fa23b243896a(self, _a6cfdb24a2d4, _4b14238bceda=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _f4200e5e297a, _8c08353a8cc2 in _a6cfdb24a2d4._dc79d6bab2ed():
            _6e8597829967 = f"{_4b14238bceda}.{_f4200e5e297a}" if _4b14238bceda else _f4200e5e297a

            def _eb15e434635a(_0ac2883b98f6, _0252a94cd817, _9ef6e826a002):
                if _d2f2e1f42ed3(_9ef6e826a002, _f192b1da4894._28a2eb79e8c9) and _9ef6e826a002._a36f80c34275()._408cf93be998():
                    _baa3444fd29b(f"NaN detected in {_6e8597829967} ({_0ac2883b98f6._5d92935e00af.__name__}) ({_9ef6e826a002._681866af905b})")

            _8c08353a8cc2._343c2ba42d28(_80e206b2e89d)

            self._837be5e47a1f(_8c08353a8cc2, _6e8597829967)

    def _e9fd1061c289(self, _a6cfdb24a2d4):
        return _408cf93be998(_3767dd22a0cc._884a6deba20a for _3767dd22a0cc in _a6cfdb24a2d4._c441aec0ba5e())

    def _b43438723121(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _d46f64b25b17 = []
        for _f4200e5e297a, _a6cfdb24a2d4 in self._c854351d5b88():
            if not self._53286dbc2065(_a6cfdb24a2d4):
                continue
            _83563e418f31 = (
                "norm" in _f4200e5e297a._e60fde87a223() or 
                "linear4bit" in _f4200e5e297a._e60fde87a223() or 
                _408cf93be998(_42b7f16801f9 in _f4200e5e297a._e60fde87a223() for _42b7f16801f9 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _f4200e5e297a._e60fde87a223() or 
                "dropout" in _f4200e5e297a._e60fde87a223() or 
                _d2f2e1f42ed3(_a6cfdb24a2d4, (_aa41809b6bc2, _f192b1da4894._bcd2eab0d27e._145d74d51e02, _f192b1da4894._bcd2eab0d27e._c45883e287a8))
            )
            if _83563e418f31:
                if _a0d1a63a0858(_a6cfdb24a2d4, "eps"):
                    _a6cfdb24a2d4._e38311643cd3 = 1e-3
                _a6cfdb24a2d4 = _a6cfdb24a2d4._1ac1b791041c(_f192b1da4894._e31a298d4c7a)
                if not _d2f2e1f42ed3(_a6cfdb24a2d4, _60fc544baef3._d5830224dc92):
                    _d46f64b25b17._a855f6a39116((_f4200e5e297a, _60fc544baef3._d5830224dc92(_a6cfdb24a2d4, _4dd44d262cb8=-10, _24fd02eb63f7=10)))
        for _f4200e5e297a, _14e241b447f6 in _d46f64b25b17:
            _a33193c23fc7, _d75dbe2bc91d = self._df6e863bde7e(_f4200e5e297a)
            if _a33193c23fc7 is not _2849d2c6b003:
                _7e87925fb681(_a33193c23fc7, _d75dbe2bc91d, _14e241b447f6)

    def _0a753c841573(self, _b2577073596d):
        """Finds the parent module and attribute name given the full module path."""
        _8da7de949b43 = _b2577073596d._57d7f7c4b531('.')
        _72d2cf59d61d = self
        for _d029ff323765 in _8da7de949b43[:-1]:
            _72d2cf59d61d = _f26edc77e0cf(_72d2cf59d61d, _d029ff323765, _2849d2c6b003)
            if _72d2cf59d61d is _2849d2c6b003:
                return _2849d2c6b003, _2849d2c6b003
        return _72d2cf59d61d, _8da7de949b43[-1]

    def _abf233e25a1a(self, _8da75d95bbba: _f192b1da4894._28a2eb79e8c9, _45a352d9df13: _f192b1da4894._28a2eb79e8c9, _750c0c3a799c: _f192b1da4894._28a2eb79e8c9) -> _3637386c4e0b:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _27d26c411d25 = _8da75d95bbba._27d26c411d25

        # 1) gating w (use cached per-example teacher_conf if available)
        _be93993dde67 = _f26edc77e0cf(self, "_last_teacher_conf", _2849d2c6b003)
        if _be93993dde67 is _2849d2c6b003:
            # no teacher info => w = 0 (no distillation)
            _6597325db3d5 = 0.0
        else:
            _4b3c0d4a6b83 = (_be93993dde67 >= _0d9fe2e75519(_f26edc77e0cf(self, "teacher_conf_tau", 0.6)))._0d9fe2e75519()
            _6597325db3d5 = _0d9fe2e75519(_4b3c0d4a6b83._192b83930095()._cfe50cc93782()._1a1833108ae6()) if _4b3c0d4a6b83._506bb61c80de() > 0 else 0.0

        # apply gating to the batch scalars
        _e655fa77b2eb = _45a352d9df13 * _0d9fe2e75519(_6597325db3d5)
        _f4bae4dd64a1 = _750c0c3a799c * _0d9fe2e75519(_6597325db3d5)

        # 2) EMAs for autoscaling
        _1adad766ec73 = _0d9fe2e75519((_e655fa77b2eb + _f4bae4dd64a1)._2fa5eaf451f7()._cfe50cc93782()._1a1833108ae6())
        _389d2333a020 = _0d9fe2e75519(_8da75d95bbba._2fa5eaf451f7()._cfe50cc93782()._1a1833108ae6())
        if _f26edc77e0cf(self, "ema_task", _2849d2c6b003) is _2849d2c6b003:
            self._8193c2d55928 = _389d2333a020
            self._b01bf74ca14c = _1adad766ec73 + 1e-12
        else:
            _7c79fb2f361e = _0d9fe2e75519(_f26edc77e0cf(self, "ema_alpha", 0.99))
            self._8193c2d55928 = _7c79fb2f361e * _0d9fe2e75519(self._8193c2d55928) + (1.0 - _7c79fb2f361e) * _389d2333a020
            self._b01bf74ca14c  = _7c79fb2f361e * _0d9fe2e75519(self._b01bf74ca14c)  + (1.0 - _7c79fb2f361e) * _1adad766ec73

        _9cac23594f83 = _0d9fe2e75519(_f26edc77e0cf(self, "distill_target_ratio", 0.3))
        _a09ea5858b7a = (_0d9fe2e75519(self._8193c2d55928) / (_0d9fe2e75519(self._b01bf74ca14c) + 1e-12)) * _9cac23594f83
        _8d1865d1ade9 = _0d9fe2e75519(_a09ea5858b7a)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _b0fbbda205f0 = _0d9fe2e75519(_f26edc77e0cf(self._68ca5bcaa851, "current_epoch", _f26edc77e0cf(self._68ca5bcaa851, "global_step", 0.0)))
        _7f280f2d0650 = _0d9fe2e75519(_7a525eaf1d67(1, _f26edc77e0cf(self._68ca5bcaa851, "max_epochs", 1)))
        _2018892bf3c6 = _5d94f77ea2da(_7a525eaf1d67(_b0fbbda205f0 / _7f280f2d0650, 0.0), 1.0)
        _4dd83368dd5a = 0.30
        _064fdf7590eb = _0d9fe2e75519(_f26edc77e0cf(self, "kl_base", 0.30)) * _5d94f77ea2da(_2018892bf3c6 / _4dd83368dd5a, 1.0)
        _30f7965bbb88 = _0d9fe2e75519(_f26edc77e0cf(self, "cos_base", 0.25))
        _4ab84ccb672b = _30f7965bbb88 + (0.10 - _30f7965bbb88) * _2018892bf3c6

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _fbdf97aa8687 = _0d9fe2e75519(self._9bb6a24d1225._192b83930095()._cfe50cc93782()._1a1833108ae6()) if _f26edc77e0cf(self, "_last_teacher_conf", _2849d2c6b003) is not _2849d2c6b003 else 0.0
        if _f26edc77e0cf(self, "ema_teacher_conf", _2849d2c6b003) is _2849d2c6b003:
            self._57cc303c7581 = _fbdf97aa8687
        else:
            _eecd6553f595 = _0d9fe2e75519(_f26edc77e0cf(self, "teacher_conf_beta", 0.995))
            self._57cc303c7581 = _eecd6553f595 * _0d9fe2e75519(self._57cc303c7581) + (1.0 - _eecd6553f595) * _fbdf97aa8687

        _68bc592f16e0 = _0d9fe2e75519(_f26edc77e0cf(self, "tau_warn", 0.60))
        _3203bba56b56 = _0d9fe2e75519(_f26edc77e0cf(self, "tau_detect", 0.20))
        _12038c4d3ef6 = _7a525eaf1d67(1e-12, (_68bc592f16e0 - _3203bba56b56))
        _67ce9a5bb1dd = (_0d9fe2e75519(self._57cc303c7581) - _3203bba56b56) / _12038c4d3ef6
        _67ce9a5bb1dd = _7a525eaf1d67(0.0, _5d94f77ea2da(1.0, _67ce9a5bb1dd))

        _e049ee54c3c4 = _064fdf7590eb * _67ce9a5bb1dd
        _98006519b181 = _4ab84ccb672b * _67ce9a5bb1dd

        # 5) final aux term
        _9026762ff185 = _f192b1da4894._e42b41fd67e2(0.0, _27d26c411d25=_27d26c411d25)
        _9026762ff185 = _9026762ff185 + (_e049ee54c3c4 * _e655fa77b2eb + _98006519b181 * _f4bae4dd64a1) * _0d9fe2e75519(_8d1865d1ade9)

        # diagnostics
        _9ef6e826a002 = {
            "aux_term": _9026762ff185,
            "kl_batch": _45a352d9df13,
            "contrast_batch": _750c0c3a799c,
            "kl_loss": _e655fa77b2eb,
            "contrastive_loss": _f4bae4dd64a1,
            "w_mean": _6597325db3d5,
            "aux_scale": _0d9fe2e75519(_8d1865d1ade9),
            "lambda_kl_eff": _0d9fe2e75519(_e049ee54c3c4),
            "lambda_cos_eff": _0d9fe2e75519(_98006519b181),
            "teacher_conf_mean": _0d9fe2e75519(self._57cc303c7581),
            "shift_r": _0d9fe2e75519(_67ce9a5bb1dd)
        }
        return _9ef6e826a002

    def _8aba62045ed5(self, _49e91bb33f65):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _49e91bb33f65 = _49e91bb33f65._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)
        _90e83fcc4fa1 = (_49e91bb33f65 != self._f0d6ca335455._2f7ff56c8604)._1ac1b791041c(_681866af905b=_f192b1da4894._5f643a74fe19, _27d26c411d25=self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)

        # model forward (request hidden states)
        _d7e461d5f3e4 = self._03f3cf0aa07f(
            _49e91bb33f65=_49e91bb33f65,
            _90e83fcc4fa1=_90e83fcc4fa1,
            _c172ba780aae=_7a49cf610f5c,
            _9b82591284f7=_7a49cf610f5c,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _2eab38b2c194 = _f26edc77e0cf(_d7e461d5f3e4, "last_hidden_state", _2849d2c6b003)
        if _2eab38b2c194 is _2849d2c6b003:
            _2eab38b2c194 = _d7e461d5f3e4._f1e16e70ccdd[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _2eab38b2c194._681866af905b != _f192b1da4894._e31a298d4c7a:
            _2eab38b2c194 = _2eab38b2c194._1ac1b791041c(_f192b1da4894._e31a298d4c7a)
        # student_hidden = self.adapter(hidden)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        # if self._has_lm_head:
        #     logits = self._lm_head(student_hidden)
        # else:
        #     logits = outs.logits

        _8fab3886a8d3 = self._03f3cf0aa07f._e4a2c79ede72  # _LMHeadAdapter

        _35740414bc16 = _8fab3886a8d3._c4212d9ce171(_2eab38b2c194)      # (B, L, 2048)
        # logits = adapter.lm_head(student_hidden)    # (B, L, 128256)
        _5e75dabc9ebd = _8fab3886a8d3(_2eab38b2c194)


        _5e75dabc9ebd = _5e75dabc9ebd._1ac1b791041c(_f192b1da4894._e31a298d4c7a)._5d72f50b3a5c(-20, 20)

        # default zero scalars
        _e655fa77b2eb = _f192b1da4894._e42b41fd67e2(0.0, _27d26c411d25=self._35e8c2f15256)
        _f4bae4dd64a1 = _f192b1da4894._e42b41fd67e2(0.0, _27d26c411d25=self._35e8c2f15256)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _3349477ab40f = _f26edc77e0cf(self, "trainer", _2849d2c6b003)
        _69bb3a06d95f = _1251a544230f
        if _3349477ab40f is not _2849d2c6b003:
            _69bb3a06d95f = _5f643a74fe19(_f26edc77e0cf(self._68ca5bcaa851, "training", _1251a544230f) or _f26edc77e0cf(self._68ca5bcaa851, "validating", _1251a544230f))

        if _69bb3a06d95f and (_f26edc77e0cf(self, "batch_counter", 0) % _f26edc77e0cf(self, "xth_batch_to_consider", 1) == 0):
            with _f192b1da4894._2c0212bc0dec():
                _6d07e77b2acd = _58a69a24ae75(
                    _49e91bb33f65=_49e91bb33f65,
                    _90e83fcc4fa1=_90e83fcc4fa1,
                    _c172ba780aae=_7a49cf610f5c,
                    _9b82591284f7=_7a49cf610f5c,
                )
                _9fbee578535e = _f26edc77e0cf(_6d07e77b2acd, "last_hidden_state", _2849d2c6b003)
                if _9fbee578535e is _2849d2c6b003:
                    _9fbee578535e = _6d07e77b2acd._f1e16e70ccdd[-1]

            # compute embedding-level KL + contrastive (scalar)
            _e655fa77b2eb, _f4bae4dd64a1 = self._2ae066070270(_35740414bc16, _9fbee578535e, _27d26c411d25=self._35e8c2f15256)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _dd29ff291066(_d01139785437): return _d01139785437._192b83930095(_57a0a06ccf7b=1) if _d01139785437._57a0a06ccf7b() == 3 else _d01139785437
            _5d4aca4842ee = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._a67b308b142d(_f144b818df89(_35740414bc16), _3767dd22a0cc=2, _57a0a06ccf7b=-1, _e38311643cd3=1e-6)
            _56d7df776d95 = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._a67b308b142d(_f144b818df89(_9fbee578535e), _3767dd22a0cc=2, _57a0a06ccf7b=-1, _e38311643cd3=1e-6)
            _60f5f1737473 = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._3dbc8ec167c2(_5d4aca4842ee, _56d7df776d95, _57a0a06ccf7b=-1)  # [-1,1]
            _be93993dde67 = _60f5f1737473._5d72f50b3a5c(_5d94f77ea2da=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._bb4ba9f9fae7 = _35740414bc16._2fa5eaf451f7()
            self._46970cb26b90 = _9fbee578535e._2fa5eaf451f7()
            self._9bb6a24d1225 = _be93993dde67._2fa5eaf451f7()  # shape (B,)

        # increment counter
        self._43bb5c40d44f = _f26edc77e0cf(self, "batch_counter", 0) + 1

        return _5e75dabc9ebd, _e655fa77b2eb, _f4bae4dd64a1


    def _2bc4068756bc(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _d27091ad282d(_a6cfdb24a2d4, _28bfdea125e4, _f916e4403a15):
            if _408cf93be998(_0252a94cd817._681866af905b == _f192b1da4894._451fe56cacd4 for _0252a94cd817 in _28bfdea125e4 if _d2f2e1f42ed3(_0252a94cd817, _f192b1da4894._28a2eb79e8c9)):
                _baa3444fd29b(f"Layer {_a6cfdb24a2d4._5d92935e00af.__name__} is using float16!")

        for _d042f45fb4b8 in self._ec382763074a():
            _670146700531 = _d042f45fb4b8._343c2ba42d28(_6cb90cde3fc0)
            self._21547e147c60._a855f6a39116(_670146700531)

    def _7ded7cad53fa(self):
        """Remove all registered forward hooks."""
        for _670146700531 in _f26edc77e0cf(self, "amp_hooks", []):
            _670146700531._d7e28c8de091()
        self._21547e147c60 = []

    def _3c7e763b56a0(self, _49e91bb33f65, _fcb7a4f660a8, _30775b659ca0):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _d8b864111bbb = [self._f0d6ca335455._450f12e5d7c8(_0fff22654336) for _0fff22654336 in _49e91bb33f65]
        _8cd405c17f8f, _75d910f87670 = [], []

        for _c78de9e8cfda, _dc44dcc8d3a3, _251c6667c136 in _a45c41415322(_d8b864111bbb, _fcb7a4f660a8, _30775b659ca0):
            for token, _cd8ade984d04, _ed11531ed503 in _a45c41415322(_c78de9e8cfda, _dc44dcc8d3a3, _251c6667c136):
                if token == self._f0d6ca335455._760281a579f7 or _ed11531ed503 == self._1cd77dc4c442:
                    continue

                _00e6d2c7fd44 = (
                    token._039c1b5c06d5("##") or
                    token._039c1b5c06d5("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _00e6d2c7fd44:
                    continue

                _8cd405c17f8f._a855f6a39116(_cd8ade984d04._1a1833108ae6())
                _75d910f87670._a855f6a39116(_ed11531ed503._1a1833108ae6())

        return _f192b1da4894._e42b41fd67e2(_8cd405c17f8f), _f192b1da4894._e42b41fd67e2(_75d910f87670)

    def _a31e07584855(self):
        _ca58c764d1b5 = _f192b1da4894._e31a298d4c7a
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            _0a96c7a2d91d, _692ec58d8ef4 = _f192b1da4894._d27e405b60bd._d1f3f80d490b()
            if _0a96c7a2d91d >= 8:
                _ca58c764d1b5 = _f192b1da4894._970c7d926555
            else:
                _ca58c764d1b5 = _f192b1da4894._451fe56cacd4
        return _ca58c764d1b5

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _0317acfe73b4(
        self,
        _cf281ab41c2f: _f192b1da4894._28a2eb79e8c9,
        _7c7f6fc4d20f: _f192b1da4894._28a2eb79e8c9,
        _27d26c411d25: _572f70e39e74 = "cpu",
    ) -> _fc78cb4366ff[_f192b1da4894._28a2eb79e8c9, _f192b1da4894._28a2eb79e8c9]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _5b23280406ad = 2.0
            # NaN/Inf guard
            _cf281ab41c2f = _cf281ab41c2f._5d72f50b3a5c(_5d94f77ea2da=-30, _7a525eaf1d67=30)
            _7c7f6fc4d20f = _7c7f6fc4d20f._5d72f50b3a5c(_5d94f77ea2da=-30, _7a525eaf1d67=30)

            # Move once if needed
            _8632d1d66964 = _f192b1da4894._27d26c411d25(_27d26c411d25)
            if _cf281ab41c2f._27d26c411d25 != _8632d1d66964:
                _cf281ab41c2f = _cf281ab41c2f._1ac1b791041c(_27d26c411d25=_8632d1d66964, _c2d1c600e23f=_7a49cf610f5c, _681866af905b=self._da92679cc551)
                _7c7f6fc4d20f = _7c7f6fc4d20f._1ac1b791041c(_27d26c411d25=_8632d1d66964, _c2d1c600e23f=_7a49cf610f5c, _681866af905b=self._da92679cc551)

            _26bbce9b4483 = _cf281ab41c2f._c08307447f06(0)
            _95a00c85958b = _cf281ab41c2f._c08307447f06(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _99bf8f233406 = (_26bbce9b4483 * _95a00c85958b) > 32_000_000

            if not _99bf8f233406 or _26bbce9b4483 <= 8:
                # Direct computation
                _795b164eeb46 = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._80614667e25b(_cf281ab41c2f / _5b23280406ad, _57a0a06ccf7b=-1)
                _37a6d78a45c6 = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._27a9392c8d6e(_7c7f6fc4d20f / _5b23280406ad, _57a0a06ccf7b=-1)
                _e655fa77b2eb = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._a0ef6e598f86(_795b164eeb46, _37a6d78a45c6, _42042d813db0="batchmean") * (_5b23280406ad * _5b23280406ad)
                _f4bae4dd64a1 = 1 - _f192b1da4894._bcd2eab0d27e._8f4f9df93582._3dbc8ec167c2(_cf281ab41c2f, _7c7f6fc4d20f, _57a0a06ccf7b=-1)._192b83930095()
                return _e655fa77b2eb, _f4bae4dd64a1

            # Chunked mode for large inputs
            _0c99c5e06719 = _7a525eaf1d67(1, _26bbce9b4483 // 8)
            _45f51ac359ee, _efa7183469be = [], []

            for _783cc5d822d3 in _4ac00cac97f1(0, _26bbce9b4483, _0c99c5e06719):
                _333e0590edd8 = _cf281ab41c2f[_783cc5d822d3:_783cc5d822d3 + _0c99c5e06719]
                _d4fa3a11c279 = _7c7f6fc4d20f[_783cc5d822d3:_783cc5d822d3 + _0c99c5e06719]

                _795b164eeb46 = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._80614667e25b(_333e0590edd8 / _5b23280406ad, _57a0a06ccf7b=-1)
                _37a6d78a45c6 = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._27a9392c8d6e(_d4fa3a11c279 / _5b23280406ad, _57a0a06ccf7b=-1)

                _6a63dc51458c = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._a0ef6e598f86(_795b164eeb46, _37a6d78a45c6, _42042d813db0="batchmean") * (_5b23280406ad * _5b23280406ad)
                _bc881f716404 = _f192b1da4894._bcd2eab0d27e._8f4f9df93582._3dbc8ec167c2(_333e0590edd8, _d4fa3a11c279, _57a0a06ccf7b=-1)._192b83930095()
                _06c5dee71cc1 = 1 - _bc881f716404

                _45f51ac359ee._a855f6a39116(_6a63dc51458c)
                _efa7183469be._a855f6a39116(_06c5dee71cc1)

            _e655fa77b2eb = _f192b1da4894._e3889b3e2531(_45f51ac359ee)._192b83930095()
            _f4bae4dd64a1 = _f192b1da4894._e3889b3e2531(_efa7183469be)._192b83930095()
            return _e655fa77b2eb, _f4bae4dd64a1

        except _966e571e033c as _7879e81d11f4:
            raise _c0bf35ffeabc(f"KL/contrastive loss computation failed: {_572f70e39e74(_7879e81d11f4)}")

    def _b34128367d63(self, _bc38bf77ede1):
        _b5d5da521385 = [
            _b3d857e333ea
            for _9482cd521cf3, _333ba7af4cbb in self._8c0218d0fb5d._c500e970711d()
            if self._8037fe6ff521[_9482cd521cf3] in _bc38bf77ede1
            for _b3d857e333ea in _333ba7af4cbb
        ]

        self._14fee23c372f = _ebe08ee033ce([
            _5c321af20d2c(
                _b5d5da521385=_b5d5da521385,
                _ab4bb9141267=self._2c14781b65bc,
                _8fdd098a1d45=self._f0d6ca335455._8fdd098a1d45
            )
        ])

    def _76c904c1ce48(self, _3bfca11a9be3):
        _bc38bf77ede1 = _aaa028a68050()

        if _d2f2e1f42ed3(_3bfca11a9be3, _3637386c4e0b):
            _7c36b0fe2099 = _3bfca11a9be3._f77b12ff6cce()
        elif _d2f2e1f42ed3(_3bfca11a9be3, (_74b108c551fb, _751e7ef22ac6)):
            _7c36b0fe2099 = _3bfca11a9be3
        else:
            _7c36b0fe2099 = [_3bfca11a9be3]

        for _1cf4a93987b2 in _7c36b0fe2099:
            _bc38bf77ede1._8aab134f1a7a(_1cf4a93987b2._d9f45bf4165e._b74db8b6be21)

        return _bc38bf77ede1

    def _f9d1a7c1adc6(self):
        _bc38bf77ede1 = self._7bb4d9c64e2b(
            self._68ca5bcaa851._7742685266d1
        )
        self._5d48ab96d482(_bc38bf77ede1)

        _baa3444fd29b(f"Training Allowed languages {_bc38bf77ede1}")

        self._14fee23c372f = _ebe08ee033ce([
            _5c321af20d2c(
                _b5d5da521385=[
                    _b3d857e333ea
                    for _9482cd521cf3, _333ba7af4cbb in self._8c0218d0fb5d._c500e970711d()
                    if self._8037fe6ff521[_9482cd521cf3] in _bc38bf77ede1
                    for _b3d857e333ea in _333ba7af4cbb
                ],
                _ab4bb9141267=self._2c14781b65bc,
                _8fdd098a1d45=self._f0d6ca335455._8fdd098a1d45
            )
        ])
        
    def _fdcf0b7de57b(self, _72ecde945c7f, _60bf30a5c97c):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _49e91bb33f65 = _72ecde945c7f["input_ids"]
            _78c6003b9ac5 = _72ecde945c7f["labels"]
            _58aaf7a9955f = _72ecde945c7f._45b5853ca19a("prompt_lens", _2849d2c6b003)
            _26bbce9b4483 = _49e91bb33f65._c08307447f06(0)

            # move to device
            _49e91bb33f65 = _49e91bb33f65._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)
            _78c6003b9ac5 = _78c6003b9ac5._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)

            # ---- scheduled sampling (minimal) ----
            _3767dd22a0cc = 0.0 if self._a99058ad274d < 2 else self._a2a7a06d27e5  # e.g. 0.2
            if _3767dd22a0cc > 0.0 and (_60bf30a5c97c % 2 == 0):
                with _f192b1da4894._2c0212bc0dec():
                    # 1. run a no-grad forward to get predictions
                    _ae56a2b83106, _, _ = self(_49e91bb33f65)
                    _fa62440cce2f = _ae56a2b83106._11a649942ca0(_57a0a06ccf7b=-1)
                    _fa62440cce2f = _f192b1da4894._acd1d9c24e92(
                        [_49e91bb33f65[:, :1], _fa62440cce2f[:, :-1]],
                        _57a0a06ccf7b=1
                    )

                # 2. decide where to replace (Bernoulli mask)
                _2729316a5668 = _f192b1da4894._7d47073e03cc(_49e91bb33f65._0d9fe2e75519()) < _3767dd22a0cc

                # 3. NEVER replace masked-out labels (-100) or input side
                _b6d54acaa2ff = (_78c6003b9ac5 != -100)
                _2729316a5668 &= _b6d54acaa2ff

                # 4. replace teacher tokens with model predictions
                _49e91bb33f65 = _f192b1da4894._1ddc460b99b5(_2729316a5668, _fa62440cce2f, _49e91bb33f65)
            # -------------------------------------

            # ---- label dropout (generic, safe) ----
            _93d088428815 = 0.0 if self._a99058ad274d < 2 else 0.2  # start small
            if _93d088428815 > 0 and (_60bf30a5c97c % 2 == 0):
                _c6f423180a26 = (
                    (_f192b1da4894._7d47073e03cc(_49e91bb33f65._0d9fe2e75519()) < _93d088428815)
                    & (_78c6003b9ac5 != -100)
                )
                _49e91bb33f65 = _f192b1da4894._1ddc460b99b5(
                    _c6f423180a26,
                    self._2c14781b65bc,
                    _49e91bb33f65
                )
            # -------------------------------------
            
            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _f916e4403a15, _45a352d9df13, _750c0c3a799c = self(_49e91bb33f65)

            # causal LM shift for next-token classification (unchanged)
            _b6207dd58d19 = _f916e4403a15[:, :-1, :]._a7f02bb34d8f()
            _0f7b80d68808 = _78c6003b9ac5[:, 1:]._a7f02bb34d8f()
            _59c126b06927 = _b6207dd58d19._48e2fe3e0256(-1, _b6207dd58d19._c08307447f06(-1))
            _a9b0d89be029 = _0f7b80d68808._48e2fe3e0256(-1)

            # classification/task loss
            _8e296694a55f = self._c4b8d5bd96a7['criterion'](_59c126b06927, _a9b0d89be029)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _45a352d9df13 = _f192b1da4894._538e1c5b2bfd(_45a352d9df13, _c9ed3245609d=0.0, _d4fd1c1ec578=0.0, _363ae3453442=0.0)
            _750c0c3a799c = _f192b1da4894._538e1c5b2bfd(_750c0c3a799c, _c9ed3245609d=0.0, _d4fd1c1ec578=0.0, _363ae3453442=0.0)
            _8e296694a55f = _f192b1da4894._538e1c5b2bfd(_8e296694a55f, _c9ed3245609d=0.0, _d4fd1c1ec578=0.0, _363ae3453442=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _919f5917e27c = self._7672c28393df(_8e296694a55f, _45a352d9df13, _750c0c3a799c)
            _9026762ff185 = _919f5917e27c["aux_term"]

            if _8e296694a55f._2fa5eaf451f7() < self._c753f00f0754:
                _9026762ff185 = _f192b1da4894._f3f10a08b60b(_8e296694a55f)

            # final combined loss (single-equation)
            _eee56467df09 = _8e296694a55f + _9026762ff185

            # Optional NaN print as before (keeps your original check)
            if _f192b1da4894._a36f80c34275(_8e296694a55f):
                _baa3444fd29b(f"Step {_60bf30a5c97c}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _a8f72ddae8c3 = {
                "epoch": _0d9fe2e75519(_f26edc77e0cf(self, "current_epoch", _f26edc77e0cf(self._68ca5bcaa851, "current_epoch", 0))),
                "train_kl_loss": _919f5917e27c._45b5853ca19a("kl_loss", _45a352d9df13)._2fa5eaf451f7() if _d2f2e1f42ed3(_919f5917e27c._45b5853ca19a("kl_loss", _45a352d9df13), _f192b1da4894._28a2eb79e8c9) else _919f5917e27c._45b5853ca19a("kl_loss", _45a352d9df13),
                "train_contrastive_loss": _919f5917e27c._45b5853ca19a("contrastive_loss", _750c0c3a799c)._2fa5eaf451f7() if _d2f2e1f42ed3(_919f5917e27c._45b5853ca19a("contrastive_loss", _750c0c3a799c), _f192b1da4894._28a2eb79e8c9) else _919f5917e27c._45b5853ca19a("contrastive_loss", _750c0c3a799c),
                "train_classification_loss": _8e296694a55f._2fa5eaf451f7(),
                "train_loss": _eee56467df09._2fa5eaf451f7(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _0d9fe2e75519(_f26edc77e0cf(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _919f5917e27c._45b5853ca19a("lambda_kl_eff", _0d9fe2e75519(_f26edc77e0cf(self, "kl_base", 0.30))),
                "train_lambda_contrast": _919f5917e27c._45b5853ca19a("lambda_cos_eff", _0d9fe2e75519(_f26edc77e0cf(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _816ad374535b in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _816ad374535b in _919f5917e27c:
                    _8562e14bf69a = _919f5917e27c[_816ad374535b]
                    # convert single-element tensors to python floats for logging
                    if _d2f2e1f42ed3(_8562e14bf69a, _f192b1da4894._28a2eb79e8c9) and _8562e14bf69a._506bb61c80de() == 1:
                        _a8f72ddae8c3[f"train_{_816ad374535b}"] = _0d9fe2e75519(_8562e14bf69a._2fa5eaf451f7()._cfe50cc93782()._1a1833108ae6())
                    else:
                        _a8f72ddae8c3[f"train_{_816ad374535b}"] = _8562e14bf69a

            # log exactly like you did
            self._d2e04b3c0383(
                _a8f72ddae8c3,
                _26bbce9b4483=_26bbce9b4483,
                _ccfe055b4dba=_1251a544230f,
                _7540f8d56dfe=_7a49cf610f5c,
                _2004cc591933=_1251a544230f,
                _0cb2f8f184e4=_7a49cf610f5c,
                _d71cc6a40219=_7a49cf610f5c,
            )

            # free references as you did
            del _49e91bb33f65, _78c6003b9ac5, _f916e4403a15, _45a352d9df13, _8e296694a55f, _750c0c3a799c, _0f7b80d68808, _b6207dd58d19, _a9b0d89be029, _59c126b06927

            return _eee56467df09

        except _966e571e033c as _7879e81d11f4:
            raise _c0bf35ffeabc(f"Error in training_step: {_7879e81d11f4}") from _7879e81d11f4

    def _c1a59f6917a7(self):
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            _f192b1da4894._d27e405b60bd._917b3f966510()
        _7242f866a5da._fee85649d5fb()
        return _a468d6aa49eb()._7bed62f7a8e3()

    # def validation_step(self, batch, batch_idx):
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification (same as training)
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     if batch_idx == 0:
    #         try:
    #             print(
    #                 f"VAL TEST BATCH {batch_idx} Input IDs: {input_ids.tolist()[0]}, "
    #                 f"Predictions: {torch.argmax(shift_logits, dim=-1).tolist()[0]}, "
    #                 f"Labels: {shift_labels.tolist()[0]}"
    #             )
    #         except Exception:
    #             # printing should never crash validation
    #             pass

    #     # classification loss
    #     classification_loss = self.loss_funcs['criterion'](logits_flat, labels_flat)

    #     # numeric guards (preserve your original torch.where behavior but simpler)
    #     kl_batch = torch.nan_to_num(kl_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     contrast_batch = torch.nan_to_num(contrast_batch, nan=0.0, posinf=0.0, neginf=0.0)
    #     classification_loss = torch.nan_to_num(classification_loss, nan=0.0, posinf=0.0, neginf=0.0)

    #     # ---------------------
    #     # Compute auxiliary term using the same helper as training
    #     # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
    #     aux = self.compute_auxiliary_distill_term(classification_loss, kl_batch, contrast_batch)
    #     aux_term = aux["aux_term"]
    #     if classification_loss.detach() < self.task_loss_floor:
    #         aux_term = torch.zeros_like(classification_loss)

    #     combined_loss = classification_loss + aux_term

    #     # Logging: preserve your keys but prefer the aux diagnostics where available
    #     log_dict = {
    #         "val_kl_loss": float(aux.get("kl_loss", kl_batch).detach().cpu().item()) if isinstance(aux.get("kl_loss", kl_batch), torch.Tensor) else float(aux.get("kl_loss", kl_batch)),
    #         "val_contrastive_loss": float(aux.get("contrastive_loss", contrast_batch).detach().cpu().item()) if isinstance(aux.get("contrastive_loss", contrast_batch), torch.Tensor) else float(aux.get("contrastive_loss", contrast_batch)),
    #         "val_classification_loss": float(classification_loss.detach().cpu().item()),
    #         "val_loss": float(combined_loss.detach().cpu().item()),
    #     }

    #     # include effective lambdas and others if provided by aux
    #     log_dict["val_lambda_kl"] = float(aux.get("lambda_kl", aux.get("lambda_kl_eff", float(getattr(self, "kl_base", 0.30)))))
    #     log_dict["val_lambda_contrast"] = float(aux.get("lambda_cos", aux.get("lambda_cos_eff", float(getattr(self, "cos_base", 0.25)))))
    #     log_dict["val_w_mean"] = float(aux.get("w_mean", 0.0))
    #     log_dict["val_aux_scale"] = float(aux.get("aux_scale", 0.0))
    #     log_dict["val_shift_r"] = float(aux.get("shift_r", 0.0))
    #     log_dict["val_teacher_conf_mean"] = float(aux.get("teacher_conf_mean", 0.0))

    #     self.log_dict(
    #         log_dict,
    #         batch_size=batch_size,
    #         on_step=False,
    #         on_epoch=True,
    #         prog_bar=False,
    #         logger=True,
    #         sync_dist=True,
    #     )

    #     # build preds and labels per example (preserve your previous behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "val_loss": combined_loss,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # store for epoch-end aggregation (your code uses self._validation_outputs)
    #     self._validation_outputs.append(output)

    #     # explicit frees (same as you had)
    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, classification_loss, preds_list, labels_list

    #     return output

    def _c1941db54009(self, _72ecde945c7f, _60bf30a5c97c):
        _49e91bb33f65 = _72ecde945c7f["input_ids"]._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)
        _78c6003b9ac5 = _72ecde945c7f["labels"]._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)

        _b74db8b6be21 = _72ecde945c7f._45b5853ca19a("lang_codes", _2849d2c6b003)
        _95e40c69c71d = _72ecde945c7f._45b5853ca19a("sample_ids", _2849d2c6b003)
        _bc88a5340eca = _72ecde945c7f._45b5853ca19a("chunk_ids", _2849d2c6b003)
        _1afd69c8f5a1 = _72ecde945c7f._45b5853ca19a("word_positions", _2849d2c6b003)
        _58aaf7a9955f = _72ecde945c7f._45b5853ca19a("prompt_lens", _2849d2c6b003)
        _ca3a84418554 = _72ecde945c7f._45b5853ca19a("num_chunks", _2849d2c6b003)

        _26bbce9b4483 = _49e91bb33f65._c08307447f06(0)

        _b32a03f552b3 = (_78c6003b9ac5 != -100)._fbdf75780cb3(_57a0a06ccf7b=1)
        _b59d788be102 = _b32a03f552b3._7a525eaf1d67()._1a1833108ae6()

        with _f192b1da4894._2c0212bc0dec():
            _1f0cd2755d4a = self._61c7fdf657ec(
                _49e91bb33f65=_49e91bb33f65,
                _ddfee3924505=_b59d788be102,
                _376829ade2c7=_b59d788be102,
                _6f6bdd492746=_1251a544230f,
                _4f523d3e65d1=1,
                _97e35b688774=1.0,
                _8f2083e724cf=1.0,
                # repetition_penalty=1.0,
                # length_penalty=1.0,
                # early_stopping=True,
                _8e335fc0df94=_7a49cf610f5c,
                _14fee23c372f=self._14fee23c372f,
                _49da06518cfb=_7a49cf610f5c,
                _c1d4d9d0f209=_7a49cf610f5c,
                _c172ba780aae=_1251a544230f,
            )


        _d8277746c002 = _f192b1da4894._e3889b3e2531(_1f0cd2755d4a._33503205669e, _57a0a06ccf7b=1)   # (B, T_gen, V)

        _0810c2628b86 = _49e91bb33f65._c08307447f06(1)
        _845e907a7e2e, _445b31231429, _306fcb0a00ad = _d8277746c002._deff0a3fcc0b
        _36460859f0a4 = _78c6003b9ac5._c08307447f06(1)

        _289f8e70527f = _1f0cd2755d4a._ff0075467f28
        _4b5c9d850586 = _289f8e70527f

        # ---- build pred_tokens WITHOUT argmax on junk ----
        _fa62440cce2f = _f192b1da4894._8dd3763765a6(
            (_845e907a7e2e, _36460859f0a4),
            -100,
            _27d26c411d25=_d8277746c002._27d26c411d25,
            _681866af905b=_f192b1da4894._9e755b8abe1c,
        )

        # pred_tokens[:, prompt_len : prompt_len + T_gen] = torch.argmax(gen_logits, dim=-1)
        _fa62440cce2f[:, _0810c2628b86 : _0810c2628b86 + _445b31231429] = _4b5c9d850586[:, _0810c2628b86 : _0810c2628b86 + _445b31231429]

        # DEBUG — AS-IS, full length
        if _60bf30a5c97c == 0:
            _baa3444fd29b(
                "VAL DEBUG\n"
                f"INPUT IDS      : {_49e91bb33f65[0]._30ffec0503ac()}\n"
                f"GEN IDS (ONLY) : {_4b5c9d850586[0]._30ffec0503ac()}\n"
                f"PRED TOKENS    : {_fa62440cce2f[0]._30ffec0503ac()}\n"
                f"LABELS (FULL)  : {_78c6003b9ac5[0]._30ffec0503ac()}"
            )


        _026ac67144de = _0810c2628b86
        _f4b9af4586c2 = _0810c2628b86 + _d8277746c002._c08307447f06(1)

        # logits_flat = gen_logits.reshape(-1, gen_logits.size(-1))
        # labels_flat = labels[:, gen_start:gen_end].reshape(-1)

        _8b6d93db25ad = _78c6003b9ac5[:, _026ac67144de:_f4b9af4586c2]
        _2dfed66b80f3 = _8b6d93db25ad != -100

        _59c126b06927 = _d8277746c002[_2dfed66b80f3]
        _a9b0d89be029 = _8b6d93db25ad[_2dfed66b80f3]

        if _60bf30a5c97c == 0:
            _baa3444fd29b(
                "VAL DEBUG\n"
                f"LOGITS FLAT : {_59c126b06927._deff0a3fcc0b}\n"
                f"LABELS FLAT : {_a9b0d89be029._deff0a3fcc0b}\n"
            )
        

        _8e296694a55f = self._c4b8d5bd96a7["criterion"](_59c126b06927, _a9b0d89be029)
        _8e296694a55f = _f192b1da4894._538e1c5b2bfd(_8e296694a55f, _c9ed3245609d=0.0)

        _45a352d9df13 = _f192b1da4894._e42b41fd67e2(0.0, _27d26c411d25=_49e91bb33f65._27d26c411d25)
        _750c0c3a799c = _f192b1da4894._e42b41fd67e2(0.0, _27d26c411d25=_49e91bb33f65._27d26c411d25)

        # if gen_out.hidden_states is not None:
        #     hs = gen_out.hidden_states
        #     last_step = hs[-1]
        #     last_layer = last_step[-1] if isinstance(last_step, (tuple, list)) else last_step
        #     student_hidden = last_layer[:, -T_gen:, :]

        #     with torch.no_grad():
        #         frozen_outs = FROZEN_EMBEDDING(
        #             input_ids=generated_ids,
        #             attention_mask=(generated_ids != self.tokenizer.pad_token_id),
        #             output_hidden_states=True,
        #             return_dict=True,
        #         )
        #         frozen_hidden = frozen_outs.hidden_states[-1][:, -T_gen:, :]

        #     kl_batch, contrast_batch = self.compute_kl_contrastive_loss(
        #         student_hidden,
        #         frozen_hidden,
        #         device=self.curr_device,
        #     )

        _45a352d9df13 = _f192b1da4894._538e1c5b2bfd(_45a352d9df13, _c9ed3245609d=0.0)
        _750c0c3a799c = _f192b1da4894._538e1c5b2bfd(_750c0c3a799c, _c9ed3245609d=0.0)

        _919f5917e27c = self._7672c28393df(
            _8e296694a55f,
            _45a352d9df13,
            _750c0c3a799c,
        )

        _9026762ff185 = _919f5917e27c["aux_term"]
        if _8e296694a55f._2fa5eaf451f7() < self._c753f00f0754:
            _9026762ff185 = _f192b1da4894._f3f10a08b60b(_8e296694a55f)

        _eee56467df09 = _8e296694a55f + _9026762ff185

        self._d2e04b3c0383(
            {
                "val_loss": _eee56467df09._2fa5eaf451f7(),
                "val_classification_loss": _8e296694a55f._2fa5eaf451f7(),
                "val_kl_loss": _919f5917e27c._45b5853ca19a("kl_loss", _45a352d9df13),
                "val_contrastive_loss": _919f5917e27c._45b5853ca19a("contrastive_loss", _750c0c3a799c),
                "val_lambda_kl": _919f5917e27c._45b5853ca19a("lambda_kl_eff", 0.0),
                "val_lambda_contrast": _919f5917e27c._45b5853ca19a("lambda_cos_eff", 0.0),
                "val_teacher_conf_mean": _919f5917e27c._45b5853ca19a("teacher_conf_mean", 0.0),
            },
            _26bbce9b4483=_26bbce9b4483,
            _ccfe055b4dba=_1251a544230f,
            _7540f8d56dfe=_7a49cf610f5c,
            _d71cc6a40219=_7a49cf610f5c,
        )

        _803bde79066d = [_4b5c9d850586[_783cc5d822d3] for _783cc5d822d3 in _4ac00cac97f1(_26bbce9b4483)]
        _f94b84374a1b = [_78c6003b9ac5[_783cc5d822d3] for _783cc5d822d3 in _4ac00cac97f1(_26bbce9b4483)]

        _2099bbd3a160 = {
            "lang_codes": _b74db8b6be21,
            "preds": _803bde79066d,
            "labels": _f94b84374a1b,
            "sample_ids": _95e40c69c71d,
            "chunk_ids": _bc88a5340eca,
            "word_positions": _1afd69c8f5a1,
            "prompt_lens": _58aaf7a9955f,
            "num_chunks": _ca3a84418554,
            "val_loss": _eee56467df09,
        }

        self._1fbf49824ea6._a855f6a39116(_2099bbd3a160)

        del _49e91bb33f65, _78c6003b9ac5, _1f0cd2755d4a, _d8277746c002
        del _59c126b06927, _a9b0d89be029, _4b5c9d850586
        del _45a352d9df13, _750c0c3a799c, _8e296694a55f
        del _803bde79066d, _f94b84374a1b

        return _2099bbd3a160

    def _571bc8fa6bd7(self, _06f3cd88ab4d, _27ed01b57bc8, _fcf741edc50b=_2849d2c6b003):
        _b2d4aa50d3ec = os._0e65a3a8d072()
        _4a91b4ca1714 = f"trial_{_fcf741edc50b}" if _fcf741edc50b is not _2849d2c6b003 else "default"
        _baa3444fd29b(f"[DEBUG rank={_f192b1da4894._e76352c1dcd0._722965ad70b1() if _f192b1da4894._e76352c1dcd0._e301a0954eb7() else 0}] metrics_dict confusion_matrix sum={_fbdf75780cb3(_fbdf75780cb3(_5e3bb3a7ded5) for _5e3bb3a7ded5 in _06f3cd88ab4d['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _78cb68f15551 = os._f869c57df1c7._f6a103d2658f(_b2d4aa50d3ec, "metrics", self._c8d2a670c082,  _4a91b4ca1714)
        os._a04fc6ecc585(_78cb68f15551, _a8914167c3c0=_7a49cf610f5c)
        _7b4f5321202e = os._f869c57df1c7._f6a103d2658f(_78cb68f15551, _27ed01b57bc8)
        _b6b778141c5f = _4fbc6a996c53._ec2b5da1761e(_06f3cd88ab4d)
        _b6b778141c5f._bf3eacbcf069(_7b4f5321202e, _ebd1410617c9=_1251a544230f)
        _baa3444fd29b(f"[metrics] Saved {_7b4f5321202e}")

    def _a9e417c81199(self):
        # pick correct device for this rank
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            if _f192b1da4894._e76352c1dcd0._e301a0954eb7():
                _47fd07ee5a04 = _f192b1da4894._e76352c1dcd0._722965ad70b1()
            else:
                _47fd07ee5a04 = 0
            _f192b1da4894._d27e405b60bd._747a4dfa3845(_47fd07ee5a04)
            self._35e8c2f15256 = _f192b1da4894._27d26c411d25(f"cuda:{_47fd07ee5a04}")
        else:
            self._35e8c2f15256 = _f192b1da4894._27d26c411d25("cpu")
        
        _bc38bf77ede1 = self._7bb4d9c64e2b(
            self._68ca5bcaa851._e66fdeadc983
        )
        self._5d48ab96d482(_bc38bf77ede1)

        _baa3444fd29b(f"Validation Allowed languages {_bc38bf77ede1}")

        self._14fee23c372f = _ebe08ee033ce([
            _5c321af20d2c(
                _b5d5da521385=[
                    _b3d857e333ea
                    for _9482cd521cf3, _333ba7af4cbb in self._8c0218d0fb5d._c500e970711d()
                    if self._8037fe6ff521[_9482cd521cf3] in _bc38bf77ede1
                    for _b3d857e333ea in _333ba7af4cbb
                ],
                _ab4bb9141267=self._2c14781b65bc,
                _8fdd098a1d45=self._f0d6ca335455._8fdd098a1d45
            )
        ])

        self._98d9982d82f1()

    def _3617f75946d9(self):
        _f916e4403a15 = _f26edc77e0cf(self, "_validation_outputs", _2849d2c6b003)
        if not _f916e4403a15:
            return

        _7eb166df1626, _bf1fe4e0ba52, _2277710c4e35, _591804417b28 = \
            self._6a37de9d2ec5(_f916e4403a15)

        _b6ee9a24bb0c, _cb199fde7791 = [], []
        for _2227ad2c5cfb in _99a6d306fe05(_2277710c4e35._bc3e5bf346bc()):
            _47c396876f03 = _7eb166df1626[_2227ad2c5cfb]._30ffec0503ac()
            _cb9cd644f86a = _bf1fe4e0ba52[_2227ad2c5cfb]._30ffec0503ac()
            _5ccf5f319814 = _2277710c4e35[_2227ad2c5cfb]
            _f8582ff1889b = _591804417b28[_2227ad2c5cfb]
            if _5ccf5f319814._506bb61c80de() > 0 and _f8582ff1889b._506bb61c80de() > 0:
                _b6ee9a24bb0c._a855f6a39116(_5ccf5f319814)
                _cb199fde7791._a855f6a39116(_f8582ff1889b)

        if not _b6ee9a24bb0c:
            _baa3444fd29b("[VAL END] Nothing to score.")
            self._1fbf49824ea6._9bf01dcb59c9()
            return

        _8f2d120a1161 = _f192b1da4894._acd1d9c24e92(_b6ee9a24bb0c)._1ac1b791041c(_27d26c411d25=self._fac11b50153c['micro_accuracy']._27d26c411d25, _c2d1c600e23f=_7a49cf610f5c)
        _78c6003b9ac5 = _f192b1da4894._acd1d9c24e92(_cb199fde7791)._1ac1b791041c(_27d26c411d25=self._fac11b50153c['micro_accuracy']._27d26c411d25, _c2d1c600e23f=_7a49cf610f5c)

        self._fac11b50153c['micro_accuracy']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_accuracy']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_precision']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_recall']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_f1']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_accuracy']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_precision']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_recall']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_f1']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['confmat']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)

        _a790f258d5e0  = self._fac11b50153c['micro_accuracy']._8723e1a3c9dd()._1a1833108ae6()
        _4a67ce3781a0  = self._fac11b50153c['macro_accuracy']._8723e1a3c9dd()._1a1833108ae6()
        _d3ec40fb8b3b = self._fac11b50153c['macro_precision']._8723e1a3c9dd()._1a1833108ae6()
        _a79bd7cc7591    = self._fac11b50153c['macro_recall']._8723e1a3c9dd()._1a1833108ae6()
        _d94c4d84f598        = self._fac11b50153c['macro_f1']._8723e1a3c9dd()._1a1833108ae6()

        self._12df0e2f950d("val_accuracy", _4a67ce3781a0, _d71cc6a40219=_7a49cf610f5c)

        try:
            _1f53e12ab58f = self._a99058ad274d
            _06f3cd88ab4d = {
                "epoch": [_1f53e12ab58f],
                "class_names": [self._8037fe6ff521],
                "micro_accuracy": [_a790f258d5e0],
                "macro_accuracy": [_4a67ce3781a0],
                "macro_precision": [_d3ec40fb8b3b],
                "macro_recall": [_a79bd7cc7591],
                "macro_f1": [_d94c4d84f598],
                "classwise_accuracy": [self._fac11b50153c['classwise_accuracy']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "classwise_precision": [self._fac11b50153c['classwise_precision']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "classwise_recall": [self._fac11b50153c['classwise_recall']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "classwise_f1": [self._fac11b50153c['classwise_f1']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "confusion_matrix": [self._fac11b50153c['confmat']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
            }
            self._6f210556b74d(_06f3cd88ab4d, f"val_epoch_{_1f53e12ab58f}.csv", _fcf741edc50b=self._fcf741edc50b)
        except _966e571e033c as _7879e81d11f4:
            _baa3444fd29b(f"[VAL END] save metrics FAILED: {_7879e81d11f4}")

        # cleanup
        self._fac11b50153c['micro_accuracy']._f61f9e078e8b(); self._fac11b50153c['macro_accuracy']._f61f9e078e8b()
        self._fac11b50153c['macro_precision']._f61f9e078e8b(); self._fac11b50153c['macro_recall']._f61f9e078e8b(); self._fac11b50153c['macro_f1']._f61f9e078e8b()
        self._fac11b50153c['classwise_accuracy']._f61f9e078e8b(); self._fac11b50153c['classwise_precision']._f61f9e078e8b()
        self._fac11b50153c['classwise_recall']._f61f9e078e8b(); self._fac11b50153c['classwise_f1']._f61f9e078e8b()
        self._fac11b50153c['confmat']._f61f9e078e8b(); self._1fbf49824ea6._9bf01dcb59c9()
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            _f192b1da4894._d27e405b60bd._917b3f966510()
        _baa3444fd29b("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_f192b1da4894._2c0212bc0dec()
    def _a86a688aef2e(self, _49e91bb33f65: _f192b1da4894._28a2eb79e8c9, **_426ca89c65f6):
        _426ca89c65f6._a947ee73b46d("pad_token_id", _2849d2c6b003)
        _426ca89c65f6._a947ee73b46d("attention_mask", _2849d2c6b003)
        return self._03f3cf0aa07f._61c7fdf657ec(
            _49e91bb33f65=_49e91bb33f65,
            _90e83fcc4fa1=(_49e91bb33f65 != self._f0d6ca335455._2f7ff56c8604),
            _2f7ff56c8604=self._f0d6ca335455._2f7ff56c8604,
            _8fdd098a1d45=self._f0d6ca335455._8fdd098a1d45,
            **_426ca89c65f6
        )

    def _e4aa55822c50(self, _72ecde945c7f, _60bf30a5c97c):
        _49e91bb33f65 = _72ecde945c7f["input_ids"]._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)
        _78c6003b9ac5    = _72ecde945c7f["labels"]._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)
        _b74db8b6be21     = _72ecde945c7f._45b5853ca19a("lang_codes", _2849d2c6b003)
        _95e40c69c71d     = _72ecde945c7f._45b5853ca19a("sample_ids", _2849d2c6b003)
        _bc88a5340eca      = _72ecde945c7f._45b5853ca19a("chunk_ids", _2849d2c6b003)
        _1afd69c8f5a1 = _72ecde945c7f._45b5853ca19a("word_positions", _2849d2c6b003)
        _58aaf7a9955f    = _72ecde945c7f._45b5853ca19a("prompt_lens", _2849d2c6b003)
        _ca3a84418554 = _72ecde945c7f._45b5853ca19a("num_chunks", _2849d2c6b003)

        _26bbce9b4483 = _49e91bb33f65._c08307447f06(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _003e5d8086f9 = [_aafa26e6820f(_f74c817017d3) for _f74c817017d3 in _1afd69c8f5a1]
        _d65f6a71fcbc = _7a525eaf1d67(_003e5d8086f9)
        _4b5c9d850586 = self._61c7fdf657ec(
            _49e91bb33f65,
            # max_new_tokens=64,
            # do_sample=False,
            # temperature=None,     # for deterministic answers
            # top_p=None,           # for deterministic answers
            # repetition_penalty=1.2,
            # fully deterministic decoding
            _ddfee3924505=_d65f6a71fcbc,        # hard cap on number of generated tokens
            _376829ade2c7=_d65f6a71fcbc,        # forces fixed-length output (prevents early EOS)
            _6f6bdd492746=_1251a544230f,          # disables sampling ; greedy decoding
            _4f523d3e65d1=1,              # no beam search ; single deterministic path
            _97e35b688774=1.0,          # 1.2 with do_sample True; neutral temperature (no probability scaling)
            _8f2083e724cf=1.0,                # disables nucleus filtering
            # repetition_penalty=1.0,   # no penalty for repeated tokens
            # length_penalty=1.0,       # no bias toward shorter/longer sequences
            # early_stopping=True,     # do not stop on EOS before min_new_tokens
            _8e335fc0df94=_7a49cf610f5c,           # reuse KV cache for consistent + faster decoding
            _14fee23c372f=self._14fee23c372f,
        )

        if _60bf30a5c97c == 0:
            try:
                _baa3444fd29b(
                    f"TEST TEST BATCH {_60bf30a5c97c} Input IDs: {_49e91bb33f65._30ffec0503ac()[0]}, "
                    f"Generated IDs: {_4b5c9d850586._30ffec0503ac()[0]}, "
                    f"Labels: {_78c6003b9ac5._30ffec0503ac()[0]}"
                )
            except _966e571e033c:
                # printing should never crash testing
                pass


        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _803bde79066d = []
        _f94b84374a1b = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _783cc5d822d3 in _4ac00cac97f1(_26bbce9b4483):
            _803bde79066d._a855f6a39116(_4b5c9d850586[_783cc5d822d3]._2fa5eaf451f7()._cfe50cc93782())
            _f94b84374a1b._a855f6a39116(_78c6003b9ac5[_783cc5d822d3]._2fa5eaf451f7()._cfe50cc93782())


        _2099bbd3a160 = {
            "lang_codes": _b74db8b6be21,
            "preds": _803bde79066d,
            "labels": _f94b84374a1b,
            "sample_ids": _95e40c69c71d,
            "chunk_ids": _bc88a5340eca,
            "word_positions": _1afd69c8f5a1,
            "prompt_lens": _58aaf7a9955f,
            "num_chunks": _ca3a84418554,
        }

        self._83c0440f9287._a855f6a39116(_2099bbd3a160)

        # Exact same cleanup as before
        del _49e91bb33f65, _78c6003b9ac5, _4b5c9d850586, _803bde79066d, _f94b84374a1b

        return _2099bbd3a160

    def _392a0f307c60(self):
        # pick correct device for this rank
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            if _f192b1da4894._e76352c1dcd0._e301a0954eb7():
                _47fd07ee5a04 = _f192b1da4894._e76352c1dcd0._722965ad70b1()
            else:
                _47fd07ee5a04 = 0
            _f192b1da4894._d27e405b60bd._747a4dfa3845(_47fd07ee5a04)
            self._35e8c2f15256 = _f192b1da4894._27d26c411d25(f"cuda:{_47fd07ee5a04}")
        else:
            self._35e8c2f15256 = _f192b1da4894._27d26c411d25("cpu")

        _bc38bf77ede1 = self._7bb4d9c64e2b(
            self._68ca5bcaa851._226086b171fa
        )
        self._5d48ab96d482(_bc38bf77ede1)

        _baa3444fd29b(f"Test Allowed languages {_bc38bf77ede1}")

        self._14fee23c372f = _ebe08ee033ce([
            _5c321af20d2c(
                _b5d5da521385=[
                    _b3d857e333ea
                    for _9482cd521cf3, _333ba7af4cbb in self._8c0218d0fb5d._c500e970711d()
                    if self._8037fe6ff521[_9482cd521cf3] in _bc38bf77ede1
                    for _b3d857e333ea in _333ba7af4cbb
                ],
                _ab4bb9141267=self._2c14781b65bc,
                _8fdd098a1d45=self._f0d6ca335455._8fdd098a1d45
            )
        ])

        self._98d9982d82f1()
        
    def _bd6e4a5c6666(self):
        _f916e4403a15 = _f26edc77e0cf(self, "_test_outputs", _2849d2c6b003)
        _baa3444fd29b(f"[DEBUG rank={_f192b1da4894._e76352c1dcd0._722965ad70b1()}] outputs_len={_aafa26e6820f(_f916e4403a15)}")
        if not _f916e4403a15:
            return

        _7eb166df1626, _bf1fe4e0ba52, _2277710c4e35, _591804417b28 = \
            self._6a37de9d2ec5(_f916e4403a15, _a1b954bca277=_7a49cf610f5c)

        _b6ee9a24bb0c, _cb199fde7791 = [], []
        for _2227ad2c5cfb in _99a6d306fe05(_2277710c4e35._bc3e5bf346bc()):
            _47c396876f03 = _7eb166df1626[_2227ad2c5cfb]._30ffec0503ac()
            _cb9cd644f86a = _bf1fe4e0ba52[_2227ad2c5cfb]._30ffec0503ac()
            _5ccf5f319814 = _2277710c4e35[_2227ad2c5cfb]
            _f8582ff1889b = _591804417b28[_2227ad2c5cfb]

            if _5ccf5f319814._506bb61c80de() > 0 and _f8582ff1889b._506bb61c80de() > 0:
                _b6ee9a24bb0c._a855f6a39116(_5ccf5f319814)
                _cb199fde7791._a855f6a39116(_f8582ff1889b)

        if not _b6ee9a24bb0c:
            _baa3444fd29b("[TEST END] Nothing to score.")
            self._1fbf49824ea6._9bf01dcb59c9()
            return

        _8f2d120a1161 = _f192b1da4894._acd1d9c24e92(_b6ee9a24bb0c)._1ac1b791041c(_27d26c411d25=self._fac11b50153c['micro_accuracy']._27d26c411d25, _c2d1c600e23f=_7a49cf610f5c)
        _78c6003b9ac5 = _f192b1da4894._acd1d9c24e92(_cb199fde7791)._1ac1b791041c(_27d26c411d25=self._fac11b50153c['micro_accuracy']._27d26c411d25, _c2d1c600e23f=_7a49cf610f5c)

        self._fac11b50153c['micro_accuracy']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_accuracy']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_precision']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_recall']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['macro_f1']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_accuracy']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_precision']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_recall']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['classwise_f1']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)
        self._fac11b50153c['confmat']._8aab134f1a7a(_8f2d120a1161, _78c6003b9ac5)

        _a790f258d5e0  = self._fac11b50153c['micro_accuracy']._8723e1a3c9dd()._1a1833108ae6()
        _4a67ce3781a0  = self._fac11b50153c['macro_accuracy']._8723e1a3c9dd()._1a1833108ae6()
        _d3ec40fb8b3b = self._fac11b50153c['macro_precision']._8723e1a3c9dd()._1a1833108ae6()
        _a79bd7cc7591    = self._fac11b50153c['macro_recall']._8723e1a3c9dd()._1a1833108ae6()
        _d94c4d84f598        = self._fac11b50153c['macro_f1']._8723e1a3c9dd()._1a1833108ae6()

        self._12df0e2f950d("test_accuracy", _4a67ce3781a0, _d71cc6a40219=_7a49cf610f5c)

        try:
            _1f53e12ab58f = self._a99058ad274d
            _06f3cd88ab4d = {
                "epoch": [_1f53e12ab58f],
                "class_names": [self._8037fe6ff521],
                "micro_accuracy": [_a790f258d5e0],
                "macro_accuracy": [_4a67ce3781a0],
                "macro_precision": [_d3ec40fb8b3b],
                "macro_recall": [_a79bd7cc7591],
                "macro_f1": [_d94c4d84f598],
                "classwise_accuracy": [self._fac11b50153c['classwise_accuracy']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "classwise_precision": [self._fac11b50153c['classwise_precision']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "classwise_recall": [self._fac11b50153c['classwise_recall']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "classwise_f1": [self._fac11b50153c['classwise_f1']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
                "confusion_matrix": [self._fac11b50153c['confmat']._8723e1a3c9dd()._1ac1b791041c(_27d26c411d25="cpu")._307444462956()._30ffec0503ac()],
            }
            self._6f210556b74d(_06f3cd88ab4d, f"test_final.csv", _fcf741edc50b=self._fcf741edc50b)
        except _966e571e033c as _7879e81d11f4:
            _baa3444fd29b(f"[TEST END] save metrics FAILED: {_7879e81d11f4}")

        # cleanup
        self._fac11b50153c['micro_accuracy']._f61f9e078e8b(); self._fac11b50153c['macro_accuracy']._f61f9e078e8b()
        self._fac11b50153c['macro_precision']._f61f9e078e8b(); self._fac11b50153c['macro_recall']._f61f9e078e8b(); self._fac11b50153c['macro_f1']._f61f9e078e8b()
        self._fac11b50153c['classwise_accuracy']._f61f9e078e8b(); self._fac11b50153c['classwise_precision']._f61f9e078e8b()
        self._fac11b50153c['classwise_recall']._f61f9e078e8b(); self._fac11b50153c['classwise_f1']._f61f9e078e8b()
        self._fac11b50153c['confmat']._f61f9e078e8b(); self._1fbf49824ea6._9bf01dcb59c9()
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            _f192b1da4894._d27e405b60bd._917b3f966510()
        _baa3444fd29b("[TEST END] Finished and cleaned up.")

    def _ab394a2fa796(self, _72ecde945c7f, _60bf30a5c97c, _f29e9c8c3063=0):
        """Optimized prediction step with efficient memory handling."""
        _49e91bb33f65, _ = _72ecde945c7f
        _49e91bb33f65 = _49e91bb33f65._1ac1b791041c(self._35e8c2f15256, _c2d1c600e23f=_7a49cf610f5c)
        _f916e4403a15, _, _ = self(_49e91bb33f65)
        _b4ae19a87cd5 = _f192b1da4894._11a649942ca0(_f916e4403a15, _57a0a06ccf7b=-1)
        del _49e91bb33f65, _f916e4403a15
        if _f192b1da4894._d27e405b60bd._fb8fc813cdd6():
            _f192b1da4894._d27e405b60bd._917b3f966510()
        return {"predictions": _b4ae19a87cd5._cfe50cc93782()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _afd81eaa4d17(self, _d8b864111bbb, _a503da778629):
        # if sep token not present then just tuple the tokens and return
        if _a503da778629 is _2849d2c6b003:
            return [(_bc47cf53dc0d,) for _bc47cf53dc0d in _d8b864111bbb]

        _9f899eaa2a29 = []
        _f4350cf14eaf = []

        for _bc47cf53dc0d in _d8b864111bbb:
            if _bc47cf53dc0d == _a503da778629:
                if _f4350cf14eaf:
                    _9f899eaa2a29._a855f6a39116(_751e7ef22ac6(_f4350cf14eaf))
                    _f4350cf14eaf = []
            else:
                if _a503da778629 == -1:
                    # if sep token is -1 we use word pos first occurence so instead of (1,1,...) we get (1,)
                    if _bc47cf53dc0d in _f4350cf14eaf:
                        continue
                    else:
                        _f4350cf14eaf._a855f6a39116(_bc47cf53dc0d)
                    
                else:
                    _f4350cf14eaf._a855f6a39116(_bc47cf53dc0d)

        if _f4350cf14eaf:
            _9f899eaa2a29._a855f6a39116(_751e7ef22ac6(_f4350cf14eaf))

        return _9f899eaa2a29

    def _347ee037851e(self, _f77b12ff6cce, _4ddb86ab696c="exact_match", _7a652c5c4c95=_2849d2c6b003):
        if not _f77b12ff6cce:
            return _7a652c5c4c95

        if _4ddb86ab696c == "exact_match":
            return _f77b12ff6cce[0] if _897cd1c6424e(_0043bafb21cb == _f77b12ff6cce[0] for _0043bafb21cb in _f77b12ff6cce) else _7a652c5c4c95

        if _4ddb86ab696c == "most_common":
            return _68c01c4a81e4(_f77b12ff6cce)._367e29c4987e(1)[0][0]

        if _4ddb86ab696c == "first":
            return _f77b12ff6cce[0]

        raise _86990ccf889c(f"Unknown vote mode: {_4ddb86ab696c}")


    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
    #     expected_chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]
    #         num_chunks     = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             expected_chunks_by_sid[sid] = int(num_chunks[i])
    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if len(chunks) !=  expected_chunks_by_sid[sid]:
    #             print(f"Skipping sample {sid} and chunks {expected_chunks_by_sid[sid]} has chunks {len(chunks)}")
    #             continue
    #         chunks.sort(key=lambda x: x[0])

    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid

    #         for idx, (chunk_id, positions, preds, labels) in enumerate(chunks):
    #             word_positions = self.split_by_sep(positions, sep_token=-1)
    #             word_preds  = self.split_by_sep(preds,  self.tokenizer_separator_token)
    #             word_labels = self.split_by_sep(labels, self.tokenizer_separator_token)

    #             if len(word_preds) < len(word_positions):
    #                 word_preds += [(self.unk_idx,)] * (len(word_positions) - len(word_preds))
                
    #             if len(word_labels) < len(word_positions):
    #                 word_labels += [(self.ignore_idx,)] * (len(word_positions) - len(word_labels))
                
    #             word_preds = word_preds[:len(word_positions)]
    #             word_labels = word_labels[:len(word_positions)]
                    
    #             chunks[idx] = (chunk_id, word_positions, word_preds, word_labels)

    #         final_pos, final_preds, final_labels = [], [], []
    #         for i in range(len(chunks) - 1):
    #             _, p0, pr0, l0 = chunks[i]
    #             _, p1, pr1, l1 = chunks[i + 1]

    #             common = set(p0) & set(p1)

    #             # take non-overlapping from first chunk
    #             assert len(p0) == len(pr0) == len(l0), (len(p0), len(pr0), len(l0))
    #             for j, pos in enumerate(p0):
    #                 if pos not in common:
    #                     final_pos.append(pos)
    #                     final_preds.append(pr0[j])
    #                     final_labels.append(l0[j])

    #             # vote overlapping
    #             for pos in common:
    #                 j0 = p0.index(pos)
    #                 j1 = p1.index(pos)

    #                 final_pos.append(pos)
    #                 final_preds.append(
    #                     self.vote([pr0[j0], pr1[j1]], mode="exact_match", fallback=(self.unk_idx,))
    #                 )
    #                 final_labels.append(
    #                     self.vote([l0[j0], l1[j1]], mode="exact_match", fallback=(self.ignore_idx,))
    #                 )


    #         # append tail of last chunk
    #         _, p, pr, l = chunks[-1]
    #         used = set(final_pos)
    #         for j, pos in enumerate(p):
    #             if pos not in used:
    #                 final_pos.append(pos)
    #                 final_preds.append(pr[j])
    #                 final_labels.append(l[j])

    #         final_pos = [x if isinstance(x, int) else x[0] for x in final_pos]
    #         final_preds = [y for i, x in enumerate(final_preds) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_preds) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]
    #         final_labels = [y for i, x in enumerate(final_labels) for y in ((x if isinstance(x, int) else x[0],) if i == len(final_labels) - 1 else (x if isinstance(x, int) else x[0], self.tokenizer_separator_token))]            
            
    #         print(f"check labels final {(sum(1 for x in final_labels if x == self.tokenizer_separator_token))}")

    #         preds_by_sid[sid] = torch.tensor(final_preds, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(final_labels, device=target_device)

    #     if verbose and sample_debug_id is not None:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #             sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else -1
    #     print(f"Rank {local_rank} samples are {final_sids}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _44952982d812(self, _0a00e10b78e6):
        _5561967feb49 = _aaa028a68050(_bc47cf53dc0d for _333ba7af4cbb in self._8c0218d0fb5d._f77b12ff6cce() for _bc47cf53dc0d in _333ba7af4cbb)
        return _751e7ef22ac6(_bc47cf53dc0d for _bc47cf53dc0d in _0a00e10b78e6 if _bc47cf53dc0d in _5561967feb49)


    def _5a344f9ab0db(self, _f916e4403a15, _0eee6307e794=_7a49cf610f5c, _8632d1d66964="cpu", _a1b954bca277=_1251a544230f):
        from collections import _43ee62b029df
        import _f192b1da4894

        _2622a4cef7d7 = self._1cd77dc4c442
        _a503da778629 = self._2c14781b65bc
        _d4de087d264c = self._86a84fb647c1

        def _03a4bfea7aaf(_d01139785437):
            if _d2f2e1f42ed3(_d01139785437, _f192b1da4894._28a2eb79e8c9):
                return _d01139785437._2fa5eaf451f7()._1ac1b791041c(_27d26c411d25=_8632d1d66964)._0793c514518c(-1)._30ffec0503ac()
            return _74b108c551fb(_d01139785437) if _d2f2e1f42ed3(_d01139785437, (_74b108c551fb, _751e7ef22ac6)) else [_d01139785437]

        _7456fd549455 = _aaa028a68050()
        _eee76bfd352f = _43ee62b029df(_74b108c551fb)
        _7c47f385a781 = _43ee62b029df(_32747a27810c)
        _949f47aeec83 = []

        if _0eee6307e794:
            _baa3444fd29b(f"[reconcile] start: num_outputs={_aafa26e6820f(_f916e4403a15)}")

        for _9ef6e826a002 in _f916e4403a15:
            _95e40c69c71d = _9ef6e826a002["sample_ids"]
            _bc88a5340eca = _9ef6e826a002["chunk_ids"]
            _5873e14f21d1 = _9ef6e826a002["preds"]
            _a82c58000405 = _9ef6e826a002["labels"]
            _1afd69c8f5a1 = _9ef6e826a002["word_positions"]
            _58aaf7a9955f = _9ef6e826a002["prompt_lens"]
            _b60087cc11da = _9ef6e826a002["num_chunks"]

            for _783cc5d822d3, _2227ad2c5cfb in _84eb25ce8b8d(_95e40c69c71d):
                _fa4e7493198c = _32747a27810c(_bc88a5340eca[_783cc5d822d3])
                if (_2227ad2c5cfb, _fa4e7493198c) in _7456fd549455:
                    continue
                _7456fd549455._1fee26abca71((_2227ad2c5cfb, _fa4e7493198c))

                _7c47f385a781[_2227ad2c5cfb] = _32747a27810c(_b60087cc11da[_783cc5d822d3])
                _d82a853ab2de = _32747a27810c(_58aaf7a9955f[_783cc5d822d3])
                _bf33dff9b97b = _01916294dfc1(_1afd69c8f5a1[_783cc5d822d3])
                
                # Right pad 
                # preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                # labels_raw = to_list(chunk_labels[i])[prompt_len_i:]

                # left pad
                # preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                # labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _c8449f6ca5d3  = _01916294dfc1(_5873e14f21d1[_783cc5d822d3])
                _9c3747576c64 = _01916294dfc1(_a82c58000405[_783cc5d822d3])

                _82e4e7203b4e  = [_3767dd22a0cc for _3767dd22a0cc, _04d63b9577f0 in _a45c41415322(_c8449f6ca5d3, _9c3747576c64) if _04d63b9577f0 != _2622a4cef7d7]
                _bef6ce16a639 = [_04d63b9577f0 for _04d63b9577f0 in _9c3747576c64 if _04d63b9577f0 != _2622a4cef7d7]
                #PROMPT LEN
                # if not left_pad:
                #     preds_raw = to_list(chunk_preds[i])[prompt_len_i:]
                #     labels_raw = to_list(chunk_labels[i])[prompt_len_i:]
                # else:
                #     preds_raw  = to_list(chunk_preds[i])[- (len(chunk_preds[i]) - prompt_len_i):]
                #     labels_raw = to_list(chunk_labels[i])[- (len(chunk_labels[i]) - prompt_len_i):]

                _f1d2ed4faaa9 = [_3767dd22a0cc for _3767dd22a0cc in _82e4e7203b4e if _3767dd22a0cc != _2622a4cef7d7]
                _5d581ab4f98e = [_04d63b9577f0 for _04d63b9577f0 in _bef6ce16a639 if _04d63b9577f0 != _2622a4cef7d7]

                if _2227ad2c5cfb not in _949f47aeec83:
                    _949f47aeec83._a855f6a39116(_2227ad2c5cfb)

                _eee76bfd352f[_2227ad2c5cfb]._a855f6a39116((_fa4e7493198c, _bf33dff9b97b, _f1d2ed4faaa9, _5d581ab4f98e))

        _8cb4cc60eeea = _2849d2c6b003
        _7eb166df1626 = {}
        _bf1fe4e0ba52 = {}

        for _2227ad2c5cfb in _949f47aeec83:
            _4cec446ac91e = _eee76bfd352f[_2227ad2c5cfb]
            if _aafa26e6820f(_4cec446ac91e) != _7c47f385a781[_2227ad2c5cfb]:
                if _0eee6307e794:
                    _baa3444fd29b(f"Skipping sample {_2227ad2c5cfb}: expected {_7c47f385a781[_2227ad2c5cfb]} chunks, got {_aafa26e6820f(_4cec446ac91e)}")
                continue

            _4cec446ac91e._8ecc2aa982c0(_1646d52d57a5=lambda _d01139785437: _d01139785437[0])

            if _8cb4cc60eeea is _2849d2c6b003 and _aafa26e6820f(_4cec446ac91e) > 1:
                _8cb4cc60eeea = _2227ad2c5cfb

            # Split into words
            _3e33b9572b8a = []
            for _fa4e7493198c, _c84a55369544, _ef0bdf758fd8, _873951ede5b3 in _4cec446ac91e:
                _8f59f9998854 = self._0a07487e1db7(_c84a55369544, -1)
                _2d0801a71c9a = self._0a07487e1db7(_ef0bdf758fd8, _a503da778629)
                _a4dea6a82aae = self._0a07487e1db7(_873951ede5b3, _a503da778629)
                _11c56052abde = _aafa26e6820f(_8f59f9998854)
                if _aafa26e6820f(_2d0801a71c9a) < _11c56052abde:
                    _2d0801a71c9a += [(_d4de087d264c,)] * (_11c56052abde - _aafa26e6820f(_2d0801a71c9a))
                if _aafa26e6820f(_a4dea6a82aae) < _11c56052abde:
                    _a4dea6a82aae += [(_2622a4cef7d7,)] * (_11c56052abde - _aafa26e6820f(_a4dea6a82aae))
                _3e33b9572b8a._a855f6a39116((_8f59f9998854, _2d0801a71c9a, _a4dea6a82aae))

            # Vote per word position
            _f15d3c83740f = _43ee62b029df(_74b108c551fb)
            _53cd9d1014ca = _43ee62b029df(_74b108c551fb)
            for _8f59f9998854, _2d0801a71c9a, _a4dea6a82aae in _3e33b9572b8a:
                for _f74c817017d3, _0fecb1ae3264, _60dc2e70a7f5 in _a45c41415322(_8f59f9998854, _2d0801a71c9a, _a4dea6a82aae):
                    _c84a55369544 = _f74c817017d3[0]
                    # pred_votes[pos].append(wpred)
                    _e469762eb437 = self._fe27f3a319e6(_0fecb1ae3264)
                    if _e469762eb437:
                        _f15d3c83740f[_c84a55369544]._a855f6a39116(_e469762eb437)
                    else:
                        _f15d3c83740f[_c84a55369544]._a855f6a39116((_d4de087d264c,))

                    _53cd9d1014ca[_c84a55369544]._a855f6a39116(_60dc2e70a7f5)

            _f6fab2d0c362 = _99a6d306fe05(_f15d3c83740f._bc3e5bf346bc())

            _0cc3f6ae1d7c = [self._682dc1eec555(_f15d3c83740f[_3767dd22a0cc], _4ddb86ab696c="most_common", _7a652c5c4c95=(_d4de087d264c,)) for _3767dd22a0cc in _f6fab2d0c362]
            _539d149d8718 = []
            for _3767dd22a0cc in _f6fab2d0c362:
                _f285c7dfca68 = _53cd9d1014ca[_3767dd22a0cc]
                _00bc0dbeb333 = self._682dc1eec555(_f285c7dfca68, _4ddb86ab696c="most_common", _7a652c5c4c95=_2849d2c6b003)
                if _00bc0dbeb333 is _2849d2c6b003:
                    for _142926125e72 in _f285c7dfca68:
                        if _2622a4cef7d7 not in _142926125e72:
                            _00bc0dbeb333 = _142926125e72
                            break
                    if _00bc0dbeb333 is _2849d2c6b003:
                        _00bc0dbeb333 = _f285c7dfca68[0]
                _539d149d8718._a855f6a39116(_00bc0dbeb333)

            # Reconstruct
            _43d3f827059b = []
            _9624a817ad69 = []
            for _783cc5d822d3 in _4ac00cac97f1(_aafa26e6820f(_f6fab2d0c362)):
                _43d3f827059b._212205cb6b50(_0cc3f6ae1d7c[_783cc5d822d3])
                _9624a817ad69._212205cb6b50(_539d149d8718[_783cc5d822d3])
                if _783cc5d822d3 < _aafa26e6820f(_f6fab2d0c362) - 1:
                    _43d3f827059b._a855f6a39116(_a503da778629)
                    _9624a817ad69._a855f6a39116(_a503da778629)

            # print(f"check labels final {(sum(1 for x in recon_labels if x == sep_token))}")

            _7eb166df1626[_2227ad2c5cfb] = _f192b1da4894._e42b41fd67e2(_43d3f827059b, _27d26c411d25=_8632d1d66964)
            _bf1fe4e0ba52[_2227ad2c5cfb] = _f192b1da4894._e42b41fd67e2(_9624a817ad69, _27d26c411d25=_8632d1d66964)

        if _0eee6307e794 and _8cb4cc60eeea is not _2849d2c6b003:
            _baa3444fd29b(f"[SUMMARY] reconciled samples in batch = {_aafa26e6820f(_949f47aeec83)} "
                f"sid={_8cb4cc60eeea} total_preds={_aafa26e6820f(_7eb166df1626[_8cb4cc60eeea])} "
                f"total_labels={_aafa26e6820f(_bf1fe4e0ba52[_8cb4cc60eeea])} "
                f"raw_preds {_7eb166df1626[_8cb4cc60eeea]} and raw_labels {_bf1fe4e0ba52[_8cb4cc60eeea]} "
                f"chunks {_eee76bfd352f[_8cb4cc60eeea]}")

        _b87e7447dd09 = _fbdf75780cb3(_aafa26e6820f(_04d63b9577f0) for _04d63b9577f0 in _bf1fe4e0ba52._f77b12ff6cce())
        _baa3444fd29b(f"Total reconciled labels: {_b87e7447dd09}")

        _0375eeabf1fe, _bf4f1fa45a48 = self._45e0e2fac619(
            _7eb166df1626, _bf1fe4e0ba52, _0eee6307e794=_0eee6307e794, _8632d1d66964=_8632d1d66964
        )
        _977451e9d3f1 = _fbdf75780cb3(_aafa26e6820f(_04d63b9577f0) for _04d63b9577f0 in _bf4f1fa45a48._f77b12ff6cce())
        _baa3444fd29b(f"Total reconciled labels classes: {_977451e9d3f1}")

        _fbf27ece241b = _f192b1da4894._e76352c1dcd0._722965ad70b1() if _f192b1da4894._e76352c1dcd0._e301a0954eb7() else -1
        _baa3444fd29b(f"Rank {_fbf27ece241b} samples are {_949f47aeec83}")

        return _7eb166df1626, _bf1fe4e0ba52, _0375eeabf1fe, _bf4f1fa45a48

    def _7b1ff6fecade(self, _7eb166df1626, _bf1fe4e0ba52, _0eee6307e794=_7a49cf610f5c, _8632d1d66964="cpu"):
        _15e1e5b1e797 = _f26edc77e0cf(self, "seq2class", {})
        _a503da778629 = _f26edc77e0cf(self, "tokenizer_separator_token", _2849d2c6b003)
        _2622a4cef7d7 = _f26edc77e0cf(self, "ignore_idx", -100)
        
        def _59cc2f0198e9(_d8b864111bbb, _f7c4b93663fb):
            _9f899eaa2a29 = []
            _c6759390ad43 = []
            for _783cc5d822d3, token in _84eb25ce8b8d(_d8b864111bbb):
                if token == _f7c4b93663fb and _c6759390ad43:
                    _9f899eaa2a29._a855f6a39116(_c6759390ad43)
                    _c6759390ad43 = []
                elif token != _f7c4b93663fb:
                    _c6759390ad43._a855f6a39116(token)
            if _c6759390ad43:
                _9f899eaa2a29._a855f6a39116(_c6759390ad43)
            return _9f899eaa2a29
        
        def _2ab76a7d3871(_be6d44ea7aac, _15e1e5b1e797, _0eee6307e794, _2227ad2c5cfb):
            _9ef6e826a002 = []
            _818908a21d7d = _99a6d306fe05(_15e1e5b1e797._bc3e5bf346bc(), _1646d52d57a5=_aafa26e6820f, _69da490b7416=_7a49cf610f5c)
            for _783cc5d822d3, _68ae8de94f3e in _84eb25ce8b8d(_be6d44ea7aac, 1):
                _2a67ba8c1b3f = _751e7ef22ac6(_68ae8de94f3e)
                _fa3c7a1260ab = self._86a84fb647c1
                for _1646d52d57a5 in _818908a21d7d:
                    if _aafa26e6820f(_2a67ba8c1b3f) >= _aafa26e6820f(_1646d52d57a5) and _2a67ba8c1b3f[:_aafa26e6820f(_1646d52d57a5)] == _1646d52d57a5:
                        _fa3c7a1260ab = _15e1e5b1e797[_1646d52d57a5]
                        break
                _9ef6e826a002._a855f6a39116(_fa3c7a1260ab)

            return _9ef6e826a002
        
        _2277710c4e35, _591804417b28 = {}, {}
        for _2227ad2c5cfb in _7eb166df1626:
            _3767dd22a0cc = _7eb166df1626[_2227ad2c5cfb]
            _04d63b9577f0 = _bf1fe4e0ba52._45b5853ca19a(_2227ad2c5cfb, _2849d2c6b003)
            _8f2d120a1161 = _3767dd22a0cc._30ffec0503ac() if _d2f2e1f42ed3(_3767dd22a0cc, _f192b1da4894._28a2eb79e8c9) else _74b108c551fb(_3767dd22a0cc)
            _78c6003b9ac5 = _04d63b9577f0._30ffec0503ac() if _d2f2e1f42ed3(_04d63b9577f0, _f192b1da4894._28a2eb79e8c9) else _74b108c551fb(_04d63b9577f0) if _04d63b9577f0 else _2849d2c6b003
            if _78c6003b9ac5 is not _2849d2c6b003:
                _5d730987cb33 = _b950729f3737(_78c6003b9ac5, _a503da778629)
                _bc38a426e67b = _86e21f74c713(_5d730987cb33, _15e1e5b1e797, _2227ad2c5cfb == 1 or _0eee6307e794, _2227ad2c5cfb)
                _924c80fbc447 = _b950729f3737(_8f2d120a1161, _a503da778629)
                _32397d776489 = _86e21f74c713(_924c80fbc447, _15e1e5b1e797, _2227ad2c5cfb == 1 or _0eee6307e794, _2227ad2c5cfb)
                if _aafa26e6820f(_32397d776489) < _aafa26e6820f(_bc38a426e67b):
                    _32397d776489 += [0] * (_aafa26e6820f(_bc38a426e67b) - _aafa26e6820f(_32397d776489))
                elif _aafa26e6820f(_32397d776489) > _aafa26e6820f(_bc38a426e67b):
                    _32397d776489 = _32397d776489[:_aafa26e6820f(_bc38a426e67b)]
            else:
                _924c80fbc447 = _b950729f3737(_8f2d120a1161, _a503da778629)
                _32397d776489 = _86e21f74c713(_924c80fbc447, _15e1e5b1e797, _2227ad2c5cfb == 1 or _0eee6307e794, _2227ad2c5cfb)
                _bc38a426e67b = [_2622a4cef7d7] * _aafa26e6820f(_32397d776489)
            _2277710c4e35[_2227ad2c5cfb] = _f192b1da4894._e42b41fd67e2(_32397d776489, _27d26c411d25=_8632d1d66964, _681866af905b=_f192b1da4894._9e755b8abe1c)
            _591804417b28[_2227ad2c5cfb] = _f192b1da4894._e42b41fd67e2(_bc38a426e67b, _27d26c411d25=_8632d1d66964, _681866af905b=_f192b1da4894._9e755b8abe1c)
        return _2277710c4e35, _591804417b28

    def _3df571d5a84c(self, _669c9012ef4c):
        _f192b1da4894._bcd2eab0d27e._9ca62ab14fba._09b100ec3def(self._c441aec0ba5e(), _de5a599f67ca=1.0)
    
    def _f150a8384c0c(self, _669c9012ef4c):
        for _0a54ca626609 in self._c441aec0ba5e():
            if _0a54ca626609 is not _2849d2c6b003:
                _0a54ca626609._02bad0785375._ba775e98f547(-5, 5)

    def _3e1c69ab9361(self):
        _e0994830ee2b = 0
        for _0a54ca626609 in self._c441aec0ba5e():
            if _0a54ca626609._c85b113601cc is not _2849d2c6b003:
                _be67fe68d7c9 = _0a54ca626609._c85b113601cc._2fa5eaf451f7()._02bad0785375._e469762eb437(2)
                _e0994830ee2b += _be67fe68d7c9._1a1833108ae6() ** 2
        return _e0994830ee2b ** 0.5  # L2 norm

    def _65d3e59f6aa0(self):
        _434b82e08bf5 = [_3767dd22a0cc for _3767dd22a0cc in self._c441aec0ba5e() if _3767dd22a0cc._884a6deba20a]
        if not _434b82e08bf5:
            _baa3444fd29b("No trainable parameters. Skipping optimizer creation.")
            return _2849d2c6b003
        
        _85c1fe35a28d = _942106e5d43e(lambda _3767dd22a0cc: _3767dd22a0cc._884a6deba20a, self._c441aec0ba5e())

        _36c4d70bf87b = {
            "adamw": _f192b1da4894._b8e198bf2759._4e1934a38af3,
            "adamax": _f192b1da4894._b8e198bf2759._55ac37464f9b,
            "adam": _f192b1da4894._b8e198bf2759._3a7cfa318f6d,
        }
        _3a8654244b16 = _36c4d70bf87b._45b5853ca19a(self._8879b3260674._e60fde87a223(), _f192b1da4894._b8e198bf2759._3a7cfa318f6d)

        _669c9012ef4c = _3a8654244b16(_85c1fe35a28d, _d5c53fd31634=self._e5b66629a97d._d5c53fd31634, _898f6d7cf309=0.001)

        _ccdcb3e56cf4 = self._68ca5bcaa851._7f280f2d0650
        _424b598c5860 = math._c72506c196b3(0.1 * _ccdcb3e56cf4)

        _327ffecfbb9d = _f192b1da4894._b8e198bf2759._8ea469c8a453._bf1500154986(_669c9012ef4c, _97cd62aca895=lambda _b0fbbda205f0: (_b0fbbda205f0 + 1) / _424b598c5860)

        _86f3a8d67796 = _f192b1da4894._b8e198bf2759._8ea469c8a453._9b8ebd1904b2(
            _669c9012ef4c,
            _0b491d74a13d=_7a525eaf1d67(1, _ccdcb3e56cf4 - _424b598c5860),
            _b27cf608457f=2,
            _8220a587841f=1e-6
        )
        _8ea469c8a453 = _f192b1da4894._b8e198bf2759._8ea469c8a453._2cd0c0939db7(
            _669c9012ef4c,
            _3fd92b9b81e1=[_327ffecfbb9d, _86f3a8d67796],
            _e104a9965e9b=[_424b598c5860]
        )
        return {"optimizer": _669c9012ef4c, "lr_scheduler": {"scheduler": _8ea469c8a453, "interval": "epoch", "monitor": "val_loss"}}
