# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_classifier
# @Time             : 19/12/23 4:27 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the authora if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, OrderedDict, defaultdict
import copy
import gc
import math
import sys
import numpy as np
import torch
import lightning as pl
import bitsandbytes
from torchmetrics import Accuracy, Precision, Recall, F1Score
from torch.amp import autocast
from cachetools import LRUCache
from lang_ident_classifier.language.accuracy.class_weighted_accuracy import ClassWeightedAccuracy
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset
from lang_ident_classifier.language.loss.class_weighted_focal_loss_with_adaptive_focus import ClassWeightedFocalLossWithAdaptiveFocus
from lang_ident_classifier.language.loss.class_weighted_cross_entropy_loss import ClassWeightedCrossEntropyLoss
from lang_ident_classifier.language.loss.class_weighted_focal_loss import ClassWeightedFocalLoss
from transformers import AutoModelForSeq2SeqLM
CAST_TO_DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'
# Global cache (NOT in model class)
FROZEN_EMBEDDING = None  
# MAX_OLD_EMBS = 1000  # Limit the cache size

# class LRUCacheDict(OrderedDict):
#     def __init__(self, max_size):
#         self.max_size = max_size
#         super().__init__()

#     def __getitem__(self, key):
#         value = super().__getitem__(key)
#         self.move_to_end(key)
#         return value

#     def __setitem__(self, key, value):
#         if key in self:
#             self.move_to_end(key)
#         elif len(self) >= self.max_size:
#             self.popitem(last=False)  # Remove LRU item
#         super().__setitem__(key, value)

# OLD_EMB_TRAIN = LRUCacheDict(max_size=MAX_OLD_EMBS)
# OLD_EMB_VAL = LRUCacheDict(max_size=MAX_OLD_EMBS)

class SafeModuleWrapper(torch.nn.Module):
    def __init__(self, module, clamp_min=-5, clamp_max=5):
        super().__init__()
        self.module = module
        # self.module = module.to(dtype=torch.float32)  # Convert module to FP32
        # for param in self.module.parameters():
        #     param.data = param.data.to(torch.float32)
        # for buffer in self.module.buffers():
        #     buffer.data = buffer.data.to(torch.float32)
        
        self.clamp_min = clamp_min
        self.clamp_max = clamp_max

    # def forward(self, *inputs, **kwargs):
    #     # Ensure all inputs are float32 if they are tensors
    #     inputs = tuple(inp.float() if isinstance(inp, torch.Tensor) else inp for inp in inputs)
        
    #     # Logging dtype info
    #     # param_dtypes = {name: param.dtype for name, param in self.module.named_parameters()}
    #     # buffer_dtypes = {name: buffer.dtype for name, buffer in self.module.named_buffers()}
    #     # print(f"[Forward Pass] {self.module.__class__.__name__} running")
    #     # print(f"  - Parameters Dtype: {param_dtypes if param_dtypes else 'No Parameters'}")
    #     # print(f"  - Buffers Dtype: {buffer_dtypes if buffer_dtypes else 'No Buffers'}")

    #     # Forward pass
    #     output = self.module(*inputs, **kwargs)
        
    #     # Convert output to FP32 and clamp if necessary
    #     if isinstance(output, torch.Tensor):
    #         output = torch.clamp(output.float(), min=self.clamp_min, max=self.clamp_max)
    #         return torch.nan_to_num(output)
    #     return output  # If it's not a tensor, return as is

    def forward(self, *inputs, **kwargs):
        # # Convert to float32 if needed
        inputs = tuple(
            inp.to(torch.float32) if isinstance(inp, torch.Tensor) and inp.dtype != torch.float32 else inp
            for inp in inputs
        )
        # Pre-check inputs
        for i, inp in enumerate(inputs):
            if isinstance(inp, torch.Tensor) and not torch.isfinite(inp).all():
                inp = torch.nan_to_num(inp)

        # Run module
        output = self.module(*inputs, **kwargs)

        # Post-check output
        if isinstance(output, torch.Tensor):
            output = output.to(torch.float32)
            if not torch.isfinite(output).all():
                output = torch.nan_to_num(output)
            output.clamp_(self.clamp_min, self.clamp_max)
            return output

        return output

    
class GenLLMLanguageIdentificationClassifier(pl.LightningModule):
    def __init__(
        self,
        pretrained_embedding_model,
        class_names,
        lr,
        optimizer,
        class_weights,
        device_dict,
        num_backbone_model_units_unfrozen,
        loss_type,
        is_train,
        tokenizer,
        prompt_length,
        random_seed: int = 20,
        pretrained_model_embedding_name = None,
    ):
        super(GenLLMLanguageIdentificationClassifier, self).__init__()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self.save_hyperparameters({
            "lr": float(lr),
            "optimizer": str(optimizer),
            "num_backbone_model_units_unfrozen": int(num_backbone_model_units_unfrozen),
            "loss_type": str(loss_type),
            "is_train": bool(is_train),
            "random_seed": int(random_seed),
        })
        # print(f"HPARAMS {self.hparams}")
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
        np.random.seed(random_seed)
        self.tokenizer = tokenizer
        self.tokenizer_separator_token = tokenizer.encode(" ", add_special_tokens=False)[0]
        self.curr_device = (
            torch.device("cuda:{}".format(device_dict["gpu_local_rank"]))
            if device_dict["gpu_local_rank"] != -1
            else "cpu"
        )
        self.pretrained_model_embedding_name = pretrained_model_embedding_name
        self.num_classes = len(class_names)
        self.class_weights = class_weights
        self.classification_task = "multiclass"
        self.ignore_padding_token_idx = tokenizer.pad_token_id if tokenizer.pad_token_id else -100

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self.embedding = pretrained_embedding_model
        # # Convert LayerNorm inside self.embedding to FP32
        # for module in self.modules():
        #     if isinstance(module, torch.nn.LayerNorm):
        #         module.to(torch.float32)  # Convert weights & buffers to FP32
        #         module.weight.data = module.weight.data.to(torch.float32)
        #         if module.bias is not None:
        #             module.bias.data = module.bias.data.to(torch.float32)
        self.embedding.requires_grad_(False).to(self.curr_device)
        if num_backbone_model_units_unfrozen > 0:
            if "llama" in self.pretrained_model_embedding_name:
                for param in self.embedding.parameters():
                    if not param.is_leaf:
                        param = param.detach()
                    param.requires_grad = False  # Freeze all layers initially
                
                # Access the LlamaDecoderLayers directly
                decoder_layers = self.embedding.model.layers  # (LlamaModel -> layers: ModuleList)
                
                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for block in decoder_layers[-num_backbone_model_units_unfrozen:]:
                    for param in block.parameters():
                        if isinstance(param, torch.Tensor) and (param.is_floating_point() or torch.is_complex(param)):
                            param.requires_grad = True

        # self.num_fc_layers = num_fc_layers
        # self.activation_function_for_layer = activation_function_for_layer
        # self.add_dropout_after_embedding = add_dropout_after_embedding
        # if add_dropout_after_embedding:
        #     self.dropout = torch.nn.Dropout(0.1, inplace=False)
        
        # # Define FC layers
        # if num_fc_layers == 1:
        #     start_input_features = self.embedding.config.hidden_size
        #     end_output_features = self.num_classes
        #     if activation_function_for_layer:
        #         setattr(self, f"fc_with_{activation_function_for_layer}_activation_1", torch.nn.Sequential(
        #             # torch.nn.LayerNorm(start_input_features, dtype=torch.float32),
        #             torch.nn.Linear(start_input_features, end_output_features),
        #             torch.nn.LayerNorm(end_output_features),
        #             self._get_activation_function_instance(activation_function_for_layer,end_output_features)
        #         ))
        #     else:
        #         setattr(self, f"fc_1", torch.nn.Linear(start_input_features, end_output_features))
        # else:
        #     start_input_features = self.embedding.config.hidden_size
        #     end_output_features = self.num_classes
        #     for layer_idx in range(num_fc_layers):
        #         if layer_idx == 0:
        #             in_features = start_input_features
        #             out_features = in_features//2
        #         elif layer_idx+1 != num_fc_layers:
        #             in_features = start_input_features
        #             out_features = in_features//2
        #         elif layer_idx+1 == num_fc_layers:
        #             in_features = start_input_features
        #             out_features = end_output_features
        #         # setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
        #         # if activation_function_for_layer and layer_idx+1 < num_fc_layers:
        #         #     setattr(self, f"{activation_function_for_layer}_{layer_idx+1}", self._get_activation_function_instance(activation_function_for_layer, out_features))
        #         if activation_function_for_layer and layer_idx+1 < num_fc_layers:
        #             setattr(self, f"fc_with_{activation_function_for_layer}_activation_{layer_idx+1}", torch.nn.Sequential(
        #                 # torch.nn.LayerNorm(start_input_features, dtype=torch.float32),
        #                 torch.nn.Linear(start_input_features, out_features),
        #                 torch.nn.LayerNorm(out_features),
        #                 self._get_activation_function_instance(activation_function_for_layer, out_features) if activation_function_for_layer and layer_idx+1 < num_fc_layers else torch.nn.Identity()
        #             ))
        #         else:
        #             setattr(self, f"fc_{layer_idx+1}", torch.nn.Linear(start_input_features, out_features))
        #         start_input_features = out_features

        # Create learnable prompt embeddings (random init)
        global FROZEN_EMBEDDING 
        FROZEN_EMBEDDING = copy.deepcopy(self.embedding).eval()
        self.lr = lr

        # Loss function initialization
        if loss_type.casefold() == "class_weighted_cross_entropy_loss":
            self._criterion = ClassWeightedCrossEntropyLoss(class_weights=self.class_weights, device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=0.25, device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss":
            self._criterion = ClassWeightedFocalLoss(alpha=self.class_weights, device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type1', device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type2', device=self.curr_device, ignore_index=-100)
        elif loss_type.casefold() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._criterion = ClassWeightedFocalLossWithAdaptiveFocus(alpha=self.class_weights, gamma_type='type3', device=self.curr_device, ignore_index=-100)
        else:
            self._criterion = ClassWeightedCrossEntropyLoss(device=self.curr_device, ignore_index=-100)
        
        # self._accuracy = Accuracy(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)
        # self._precision = Precision(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)
        # self._recall = Recall(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)
        # self._f1 = F1Score(
        #     num_classes=self.num_classes,
        #     average="weighted",
        #     task=self.classification_task,
        #     ignore_index=-100,
        # ).to(self.curr_device)
        self._accuracy = ClassWeightedAccuracy(
            # device=self.curr_device,
            class_weights=self.class_weights,
            # num_classes=self.num_classes,
            num_classes=self.tokenizer.vocab_size,
            # task=self.classification_task,
            ignore_index=-100,
            average="custom",
        ).to('cpu')

        self._validation_outputs = []
        self._test_outputs = []
        
        self.optimizer_name = optimizer.casefold()
        self.fix_embedding_layers()

        self.register_nan_hooks(self.embedding)
        # self.initialize_weights(self.curr_device, num_fc_layers)
    
    def _get_activation_function_instance(self, activation_function_for_layer, num_parameters):
        if activation_function_for_layer.casefold() == "parametric_relu":
            # return torch.nn.PReLU(num_parameters=num_parameters)
            return torch.nn.PReLU(num_parameters=1)
        elif activation_function_for_layer.casefold() == "leaky_relu":
            return torch.nn.LeakyReLU(inplace=False)
        else:
            return torch.nn.ReLU(inplace=False) # in place tensor modifications disabled due to issues in gradient 
        
    def register_nan_hooks(self, module, prefix=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for name, child in module.named_children():
            full_name = f"{prefix}.{name}" if prefix else name  # Keep full layer path

            # Hook function to check for NaNs in forward pass
            def detect_nan_hook(mod, inp, out):
                if isinstance(out, torch.Tensor) and out.isnan().any():
                    print(f"NaN detected in {full_name} ({mod.__class__.__name__}) ({out.dtype})")

            child.register_forward_hook(detect_nan_hook)

            # Recursively apply to children
            self.register_nan_hooks(child, full_name)

    def initialize_weights(self, device, num_fc_layers):
        def _initialize_weights(m):
            if hasattr(m, "weight") and m.weight.dim() > 1:
                # print(f"Initializing {m}")
                m.to(device)
                torch.nn.init.xavier_uniform_(m.weight.data)
                # if m.bias is not None:  # Initialize bias as well
                #     torch.nn.init.zeros_(m.bias.data)
        
        # for layer_idx in range(num_fc_layers):
        #     layer = getattr(self, f"fc_{layer_idx+1}")
        #     layer.apply(_initialize_weights)
        fc_layers = [layer for name, layer in self._modules.items() if name.startswith("fc_")]
        # print(f"Initializing layers {fc_layers}")
        for layer in fc_layers:
            layer.apply(_initialize_weights)
    
    def has_trainable_params(self, module):
        return any(p.requires_grad for p in module.parameters())  # Includes submodules
    
    def fix_embedding_layers(self):
        """Convert unstable modules (LayerNorm, RMSNorm, Linear4bit, MLP, activations, attention, projections) 
        to float32 and wrap them safely to prevent NaNs."""

        updates = []

        for name, module in self.named_modules():
            if not self.has_trainable_params(module):
                continue  # Skip frozen layers

            # Anything prone to NaNs
            is_unstable = any(k in name.lower() for k in [
                "norm", "linear4bit", "mlp", "act", "attention", "proj","gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated"
            ]) or isinstance(module, torch.nn.LayerNorm)

            if is_unstable:
                if hasattr(module, "eps"):  
                    module.eps = max(getattr(module, "eps", 1e-5), 1e-5)  # stabilize norms
                module = module.to(torch.float32)  # force fp32
                if not isinstance(module, SafeModuleWrapper):
                    updates.append((name, SafeModuleWrapper(module)))

        # Apply wrapped modules
        for name, new_module in updates:
            parent_module, attr = self.get_parent_and_attr(name)
            if parent_module is not None:
                setattr(parent_module, attr, new_module)

    def get_parent_and_attr(self, module_name):
        """Finds the parent module and attribute name given the full module path."""
        parts = module_name.split('.')
        parent = self  # Start from the main model
        for part in parts[:-1]:  # Traverse down but stop at the parent
            parent = getattr(parent, part, None)
            if parent is None:
                return None, None
        return parent, parts[-1]  # Return parent module and final attribute

    def forward(self, input_ids, labels=None):
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        attention_mask = (input_ids != self.tokenizer.eos_token_id).to(dtype=torch.bool, device=self.curr_device, non_blocking=True)

        outputs = self.embedding(
            input_ids=input_ids,
            attention_mask=attention_mask,
            output_hidden_states=True,
            return_dict=True
        )

        # hidden_states = outputs.hidden_states[-1]  # (batch, seq_len, hidden_dim)
        # Mean pooling over sequence length
        # hidden_states = outputs.hidden_states[-1]
        logits = outputs.logits


        # if self.add_dropout_after_embedding:
        #     hidden_states = self.dropout(hidden_states)

        # # Apply FC layers dynamically
        # x = hidden_states
        # for layer_idx in range(1, self.num_fc_layers + 1):
        #     if hasattr(self, f"fc_with_{self.activation_function_for_layer}_activation_{layer_idx}"):
        #         fc = getattr(self, f"fc_with_{self.activation_function_for_layer}_activation_{layer_idx}")
        #     else:
        #         fc = getattr(self, f"fc_{layer_idx}")
        #     x = fc(x)

        # logits = x  # (batch, seq_len, num_classes)

        # Optional: KL + contrastive loss
        kl_loss = torch.tensor(0.0, device=self.curr_device)
        contrastive_loss = torch.tensor(0.0, device=self.curr_device)
        if self.trainer.training or self.trainer.validating:
            # with torch.no_grad():
            #     frozen_outputs = FROZEN_EMBEDDING(input_ids).logits.clone()
            frozen_outputs = FROZEN_EMBEDDING(input_ids).logits.detach()
            kl_loss, contrastive_loss = self.compute_kl_contrastive_loss(
                logits, frozen_outputs, device=self.curr_device
            )

        return logits, kl_loss, contrastive_loss

    def register_amp_hooks(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def hook_fn(module, inputs, outputs):
            if any(inp.dtype == torch.float16 for inp in inputs if isinstance(inp, torch.Tensor)):
                print(f"Layer {module.__class__.__name__} is using float16!")

        # Attach hooks to all layers in self.model
        for submodule in self.modules():
            hook = submodule.register_forward_hook(hook_fn)
            self.amp_hooks.append(hook)  # Store hooks to remove them later if needed

    def remove_hooks(self):
        """Remove all registered forward hooks."""
        for hook in getattr(self, "amp_hooks", []):
            hook.remove()
        self.amp_hooks = []

    def align_tokens_to_words(self, input_ids, token_preds, token_labels):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        tokens = [self.tokenizer.convert_ids_to_tokens(ids) for ids in input_ids]
        word_preds, word_labels = [], []
        
        for token_seq, pred_seq, label_seq in zip(tokens, token_preds, token_labels):
            for token, pred, label in zip(token_seq, pred_seq, label_seq):
                if token == self.tokenizer.pad_token or label == -100:
                    continue  # Skip padding & ignored labels

                # Detect subword tokens (model-specific handling)
                is_subword = (
                    token.startswith("##") or  # BERT/RoBERTa (WordPiece)
                    token.startswith("▁") or   # IndicBERT/mT5 (SentencePiece)
                    token in ["<unk>", "<pad>"]  # Generic unknown/padding tokens
                )

                if is_subword:
                    continue  # Ignore subword parts, keep only first part's label
                
                # Store the first subword’s label as word-level
                word_preds.append(pred.item())
                word_labels.append(label.item())

        return torch.tensor(word_preds), torch.tensor(word_labels)

    def compute_kl_contrastive_loss(self, new_emb_cpu, old_emb_cpu, device="cuda"):
        """Computes KL divergence and contrastive loss efficiently with minimal GPU usage."""
        
        # Ensure tensors are detached and moved to CPU for lightweight loss computation
        # new_emb_cpu = new_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)
        # old_emb_cpu = old_emb.detach().to("cpu", non_blocking=True, dtype=torch.float32)
        new_emb_cpu = new_emb_cpu.clamp(min=-30, max=30)
        old_emb_cpu = old_emb_cpu.clamp(min=-30, max=30)
        T = 2.0 # Temperature fixed in Hinto et al 2015 set at 2 or 3 most cases works
        # Compute KL divergence using more stable log-softmax
        new_emb_log = torch.nn.functional.log_softmax(new_emb_cpu/T, dim=-1)
        old_emb_prob = torch.nn.functional.softmax(old_emb_cpu/T, dim=-1)
        latent_dim = new_emb_log.shape[-1]  # Safe for [batch, dim]
        kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean")* (T * T) / latent_dim

        # Compute cosine similarity for contrastive loss No scaling on temp for constractive since cosine is scale invariant
        embedding_drift = torch.nn.functional.cosine_similarity(new_emb_cpu, old_emb_cpu, dim=-1).mean()
        contrastive_loss = 1 - embedding_drift

        # Free CPU memory after computation
        del new_emb_cpu, old_emb_cpu
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Ensure GPU stays clean

        # Move results back to GPU if necessary
        return kl_loss.to(device, non_blocking=True), contrastive_loss.to(device, non_blocking=True)
    
    def training_step(self, batch, batch_idx):
        """Optimized training step with reduced memory footprint and improved stability."""

        # input_ids, labels = batch
        input_ids = batch["input_ids"]
        labels = batch["labels"]
        batch_size = input_ids.size(0)

        # Ensure data is on the correct device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)
        labels = labels.to(self.curr_device, non_blocking=True)

        # Forward pass
        outputs, kl_loss, contrastive_loss = self(input_ids)

        # Flatten outputs and labels for loss computation
        # outputs = outputs.contiguous().view(-1, outputs.shape[-1])
        # labels = labels.contiguous().view(-1)

        shift_logits = outputs[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()
        # print(f"[Step T4] Shifted logits: {shift_logits.shape}, Shifted labels: {shift_labels.shape}")

        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)
        # Compute classification loss
        loss = self._criterion(logits_flat, labels_flat)

        # Ensure KL and contrastive loss values are finite
        # loss = torch.nan_to_num(loss, nan=0.0)
        # kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
        # contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)
        # Replace NaNs while preserving autograd graph
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)

        # Combine losses with scaling factors
        # λ_kl = max(1.0 - self.trainer.current_epoch * 0.1, 0.2)
        epoch = float(self.trainer.current_epoch)
        λ_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
        λ_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
        combined_loss = loss + λ_kl * kl_loss + λ_contrast * contrastive_loss

        # combined_loss = loss + 0.05 * kl_loss + 0.05 * contrastive_loss

        # Convert logits to predicted labels
        # with torch.no_grad():  # Prevent gradient tracking for metrics
        #     predicted_labels = torch.argmax(outputs, dim=1)
        #     accuracy = self._accuracy(predicted_labels, labels)
        #     precision = self._precision(predicted_labels, labels)
        #     recall = self._recall(predicted_labels, labels)
        #     f1 = self._f1(predicted_labels, labels)

        # Check for NaN loss and log issue
        if torch.isnan(loss):
            print(f"Step {batch_idx}: NaN loss detected!")

        # Store training metrics
        train_metrics = {
            "epoch": float(self.current_epoch),
            "train_kl_loss": kl_loss.detach(),
            "train_contrastive_loss": contrastive_loss.detach(),
            "train_classification_loss": loss.detach(),
            "train_loss": combined_loss.detach(),
            "train_λ_kl": λ_kl,
            "train_λ_contrast": λ_contrast,
            # "train_accuracy": accuracy,
            # "train_precision": precision,
            # "train_recall": recall,
            # "train_f1": f1,
        }

        # self.log("epoch", float(self.current_epoch), 
        #         on_step=False,
        #         on_epoch=True,
        #         prog_bar=False,
        #         logger=True,
        #         sync_dist=False)
        # self.log("train_λ_kl", λ_kl, 
        #         on_step=False,
        #         on_epoch=True,
        #         prog_bar=False,
        #         logger=True,
        #         sync_dist=False)
        # self.log("train_λ_contrast", λ_contrast,
        #         on_step=False,
        #         on_epoch=True,
        #         prog_bar=False,
        #         logger=True,
        #         sync_dist=False)

        # Log metrics without unnecessary sync overhead
        self.log_dict(
            train_metrics,
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,  # Sync across GPUs in distributed training
        )
        # self.log(
        #     "epoch", float(self.current_epoch),
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=True,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )
        # self.log(
        #     "train_λ_kl", λ_kl,
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=True,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )
        # self.log(
        #     "train_λ_contrast", λ_contrast,
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=True,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )


        # Explicitly delete tensors to free memory
        del input_ids, labels, outputs
        # del predicted_labels
        del kl_loss, loss, contrastive_loss
        del shift_labels, shift_logits, labels_flat, logits_flat
        # if torch.cuda.is_available():
        #     torch.cuda.empty_cache()  # Free GPU memory

        return combined_loss # returned loss to avoid warning
        # return # Nothing returned since core thinsg are logged in log_dict
    
    def on_train_epoch_end(self):
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()
        return super().on_train_epoch_end()

    
    # def validation_step(self, batch, batch_idx):
    #     """Optimized validation step with better memory handling and stability."""

    #     # input_ids, labels = batch
    #     input_ids = batch["input_ids"]
    #     batch_size = input_ids.size(0)
    #     labels = batch["labels"]
    #     sample_ids = batch["sample_ids"]
    #     chunk_ids = batch["chunk_ids"]
    #     word_positions = batch["word_positions"]

    #     # Move tensors to device efficiently
    #     input_ids = input_ids.to(self.curr_device, non_blocking=True)
    #     labels = labels.to(self.curr_device, non_blocking=True)

    #     # Forward pass
    #     outputs, kl_loss, contrastive_loss = self(input_ids)

    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     # print(f"[Step T4] Shifted logits: {shift_logits.shape}, Shifted labels: {shift_labels.shape}")

    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # print("outputs shape:", outputs.shape)
    #     # print("labels shape:", labels.shape)


    #     # Handle NaN/Inf values in logits
    #     if torch.isnan(outputs).any() or torch.isinf(outputs).any():
    #         print(f"Validation Step {batch_idx}: NaN detected in logits!\n{outputs}")

    #     # Compute classification loss
    #     loss = self._criterion(logits_flat, labels_flat)

    #     # Ensure KL and contrastive loss values are finite
    #     loss = torch.nan_to_num(loss, nan=0.0)
    #     kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
    #     contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)

    #     # Combine losses with scaling factors
    #     # λ_kl = max(1.0 - self.trainer.current_epoch * 0.1, 0.2)
    #     epoch = float(self.trainer.current_epoch)
    #     λ_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
    #     λ_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
    #     combined_loss = loss + λ_kl * kl_loss + λ_contrast * contrastive_loss

    #     # combined_loss = loss + 0.05 * kl_loss + 0.05 * contrastive_loss

    #     # Detect NaN loss and log issue
    #     if torch.isnan(loss):
    #         print(f"Validation Step {batch_idx}: NaN loss detected!\nInput IDs: {input_ids}\nLabels: {labels}\nOutputs: {outputs}")

    #     # Convert logits to predicted labels
    #     with torch.no_grad():  # Avoid tracking gradients for metrics
    #         # predicted_labels = torch.argmax(outputs, dim=1)
    #         # if batch_idx == 0:
    #         #     print(f"predicted labels {predicted_labels} and labels {labels}")
    #         mask = labels_flat != -100
    #         valid_preds = torch.argmax(logits_flat[mask], dim=-1)  # shape: (num_tokens,)
    #         valid_labels = labels_flat[mask]
    #         # accuracy = self._accuracy(valid_preds, valid_labels)
    #         # precision = self._precision(predicted_labels, labels)
    #         # recall = self._recall(predicted_labels, labels)
    #         # f1 = self._f1(predicted_labels, labels)

    #     # Store validation metrics
    #     val_metrics = {
    #         "val_kl_loss": kl_loss.detach(),
    #         "val_contrastive_loss": contrastive_loss.detach(),
    #         "val_classification_loss": loss.detach(),
    #         "val_loss": combined_loss.detach(),
    #         "val_λ_kl": λ_kl,
    #         "val_λ_contrast": λ_contrast,
    #         # "val_accuracy": accuracy,
    #         # "val_precision": precision,
    #         # "val_recall": recall,
    #         # "val_f1": f1,
    #     }

    #     # self.log("val_λ_kl", λ_kl, 
    #     #         on_step=False,
    #     #         on_epoch=True,
    #     #         prog_bar=False,
    #     #         logger=True,
    #     #         sync_dist=False)
    #     # self.log("val_λ_contrast", λ_contrast,
    #     #         on_step=False,
    #     #         on_epoch=True,
    #     #         prog_bar=False,
    #     #         logger=True,
    #     #         sync_dist=False)

    #     # Log metrics without unnecessary sync overhead
    #     self.log_dict(
    #         val_metrics,
    #         batch_size=batch_size,
    #         on_step=False,
    #         on_epoch=True,
    #         prog_bar=False,
    #         logger=True,
    #         sync_dist=True,  # Sync across GPUs in distributed training
    #     )

    #     # # --- Sample Inspection: Show 1 example per batch ---
    #     # if batch_idx%10 == 0:
    #     #     sample_idx = 0  # Only show one sample per batch

    #     #     input_sample = input_ids[sample_idx]          # shape: [seq_len]
    #     #     label_sample = labels[:input_sample.size(0)]
    #     #     pred_sample = predicted_labels[:input_sample.size(0)]

    #     #     # print(f"Raw Values \n {input_sample} and shape {input_sample.shape}\n \
    #     #     #     label_sample {label_sample} and shape {label_sample.shape} \n \
    #     #     #         pred sample {pred_sample} and shape {pred_sample.shape}")
    #     #     # Decode input IDs to text if tokenizer is available
    #     #     if hasattr(self, "tokenizer"):
    #     #         input_text = self.tokenizer.decode([t for t in input_sample if t != -100], skip_special_tokens=False)
    #     #     else:
    #     #         input_text = input_sample.tolist()  # raw token IDs

    #     #     # Generate from embedding model if needed
    #     #     embedding_output = None
    #     #     # if hasattr(self, "embedding"):  # e.g., for generating token embeddings
    #     #     #     with torch.no_grad():
    #     #     #         # input_sample: [seq_len] → [1, seq_len]
    #     #     #         logits = self.embedding(input_ids=input_sample.unsqueeze(0)).logits.to(dtype=torch.float32)
    #     #     #         pred_ids = torch.argmax(logits, dim=-1)
    #     #     #         decoded_prediction = self.tokenizer.batch_decode(pred_ids, skip_special_tokens=True)

    #     #     with torch.no_grad():
    #     #         # Add batch dimension: [seq_len] -> [1, seq_len]
    #     #         input_ids = input_sample.unsqueeze(0).to(self.embedding.device)

    #     #         # Generate output tokens
    #     #         generated_ids = self.embedding.generate(
    #     #             input_ids=input_ids,
    #     #             attention_mask=(input_ids != self.tokenizer.eos_token_id),  # this line fixes the warning
    #     #             max_new_tokens=512,
    #     #             do_sample=False,  # Turn off sampling (which uses cumsum)
    #     #             temperature=None,  # Explicitly unset
    #     #             top_p=None,        # Explicitly unset
    #     #             top_k=None,        # Optional, unset if needed
    #     #             eos_token_id=self.tokenizer.eos_token_id,
    #     #             pad_token_id=self.tokenizer.eos_token_id,
    #     #         )

    #     #         # Slice to keep only the newly generated part (after prompt)
    #     #         new_tokens = generated_ids[0][input_ids.shape[1]:]

    #     #         # Decode to string
    #     #         decoded_prediction = self.tokenizer.decode(new_tokens, skip_special_tokens=True)


    #     #         # -------------------------------
    #     #         # Log the full output properly
    #     #         print(
    #     #             f"--- Val Sample for batch {batch_idx} ---\n"
    #     #             f"Input IDs: {input_sample.tolist()}\n"
    #     #             f"Decoded Input Text: {input_text}\n"
    #     #             f"Decoded prediction: {decoded_prediction}\n"
    #     #             f"True Label: {label_sample}\n"
    #     #             f"Predicted Label: {pred_sample}"
    #     #         )
    #     #         del input_sample, label_sample, pred_sample, generated_ids, new_tokens, embedding_output


    #     output = {
    #             "preds": valid_preds.view(-1),    # shape: (batch_size, num_valid_tokens_per_chunk)
    #             "labels": valid_labels.view(-1),  # same shape
    #             "sample_ids": sample_ids,
    #             "chunk_ids": chunk_ids,
    #             "word_positions": word_positions,
    #             "val_loss": combined_loss
    #     }
    #     print(f"Valid Preds {output['preds'].shape}")
    #     self._validation_outputs.append(output)
    #     # Explicitly delete tensors to free memory
    #     del input_ids, labels, outputs
    #     # del predicted_labels
    #     del logits_flat, labels_flat, shift_logits, shift_labels
    #     del mask
    #     # del embedding_output, logits, pred_ids
    #     del kl_loss, contrastive_loss, loss
    #     if torch.cuda.is_available():
    #         torch.cuda.empty_cache()  # Free GPU memory
    #     return output  # optional

    def validation_step(self, batch, batch_idx):
        # if batch_idx == 0:
        #     print(f"\n[VAL STEP] Batch {batch_idx}")
        #     print("input_ids shape:", batch["input_ids"].shape)
        #     print("labels shape:", batch["labels"].shape)
        #     print("labels min/max:", batch["labels"].min().item(), batch["labels"].max().item())
        #     print("sample_ids:", batch["sample_ids"][:5])  # first 5 sample ids
        #     print("chunk_ids:", batch["chunk_ids"][:5])
        #     print("word_positions lengths:", [len(wp) for wp in batch["word_positions"][:5]])
        #     print("labels:", batch["labels"])
        input_ids = batch["input_ids"].to(self.curr_device, non_blocking=True)
        labels = batch["labels"].to(self.curr_device, non_blocking=True)
        lang_codes_list = batch["lang_codes"]
        sample_ids = batch["sample_ids"]
        chunk_ids = batch["chunk_ids"]
        word_positions = batch["word_positions"]
        batch_size = input_ids.size(0)

        outputs, kl_loss, contrastive_loss = self(input_ids)

        shift_logits = outputs[:, :-1, :].contiguous()
        shift_labels = labels[:, 1:].contiguous()

        logits_flat = shift_logits.view(-1, shift_logits.size(-1))
        labels_flat = shift_labels.view(-1)

        loss = self._criterion(logits_flat, labels_flat)
        # loss = torch.nan_to_num(loss, nan=0.0)
        # kl_loss = torch.nan_to_num(kl_loss, nan=0.0)
        # contrastive_loss = torch.nan_to_num(contrastive_loss, nan=0.0)
        # Replace NaNs while preserving autograd graph
        kl_loss = torch.where(torch.isnan(kl_loss), torch.zeros_like(kl_loss), kl_loss)
        contrastive_loss = torch.where(torch.isnan(contrastive_loss), torch.zeros_like(contrastive_loss), contrastive_loss)
        loss = torch.where(torch.isnan(loss), torch.zeros_like(loss), loss)

        epoch = float(self.trainer.current_epoch)
        λ_kl = round(min(0.2 + epoch * 0.4, 1.0), 3)
        λ_contrast = round(max(0.5 - epoch * 0.05, 0.1), 3)
        combined_loss = loss + λ_kl * kl_loss + λ_contrast * contrastive_loss

        self.log_dict(
            {
                "val_kl_loss": kl_loss.detach(),
                "val_contrastive_loss": contrastive_loss.detach(),
                "val_classification_loss": loss.detach(),
                "val_loss": combined_loss.detach(),
                "val_λ_kl": λ_kl,
                "val_λ_contrast": λ_contrast,
            },
            batch_size=batch_size,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )
        # self.log(
        #     "val_λ_kl", λ_kl,
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=False,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )
        # self.log(
        #     "val_λ_contrast", λ_contrast,
        #     on_step=False,
        #     on_epoch=True,
        #     prog_bar=False,
        #     logger=True,
        #     sync_dist=False,  # Sync across GPUs in distributed training
        # )

        preds_list = []
        labels_list = []

        for i in range(batch_size):
            logit = shift_logits[i]       # (seq_len, vocab)
            label = shift_labels[i]       # (seq_len,)
            mask = label != -100

            valid_pred = torch.argmax(logit[mask], dim=-1)  # (valid_len,)
            valid_label = label[mask]                       # (valid_len,)

            preds_list.append(valid_pred)
            labels_list.append(valid_label)

        output = {
            "lang_codes": lang_codes_list,
            "preds": preds_list,
            "labels": labels_list,
            "sample_ids": sample_ids,
            "chunk_ids": chunk_ids,
            "word_positions": word_positions,
            "val_loss": combined_loss,
        }
        # output = {
        #     "preds": preds_list,
        #     "labels": labels_list,
        #     "sample_ids": sample_ids,
        #     "chunk_ids": chunk_ids,
        #     "word_positions": word_positions,
        # }

        self._validation_outputs.append(output)

        del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
        del kl_loss, contrastive_loss, loss
        del preds_list, labels_list
        # if torch.cuda.is_available():
        #     torch.cuda.empty_cache()
        return output

    def on_validation_epoch_end(self):
        print("On Validaiton End")
        if not self._validation_outputs:
            return  # avoid failure if validation skipped

        # Reconcile chunked predictions
        preds, labels = self.reconcile_chunks(self._validation_outputs)

        # Compute final metrics
        self._accuracy.update(preds, labels)
        print(f"After Update of Accuracy")
        final_accuracy = self._accuracy.compute()
        print(f"Final Acc {final_accuracy}")

        # Log the metric
        self.log(
            "val_accuracy",
            final_accuracy,
            batch_size=1, # To silence batch size warning, batch not applicable here since end of validaiton
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        # Reset metric
        self._accuracy.reset()

        # Clear stored outputs
        self._validation_outputs.clear()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()


    # def test_step(self, batch, batch_idx):
    #     """Memory-efficient test step with chunk-level prediction output for later reconciliation."""
    #     with torch.no_grad():
    #         input_ids = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #         batch_size = input_ids.size(0)
    #         labels = batch["labels"].to(self.curr_device, non_blocking=True)

    #         sample_ids = batch["sample_ids"]
    #         chunk_ids = batch["chunk_ids"]
    #         word_positions = batch["word_positions"]

    #         outputs, _, _ = self(input_ids)

    #         shift_logits = outputs[:, :-1, :].contiguous()
    #         shift_labels = labels[:, 1:].contiguous()

    #         logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #         labels_flat = shift_labels.view(-1)

    #         mask = labels_flat != -100
    #         preds = torch.argmax(logits_flat[mask], dim=-1).cpu()
    #         valid_labels = labels_flat[mask].cpu()

    #         # accuracy = self._accuracy.update(preds, valid_labels)

    #         # self.log(
    #         #     "test_step_accuracy",  # optional: log intermediate step accuracy
    #         #     accuracy,
    #         #     on_step=True,
    #         #     on_epoch=False,
    #         #     logger=True,
    #         #     prog_bar=False,
    #         #     batch_size=batch_size  # or len(sample_ids)
    #         # )


    #         output = {
    #                 "preds": preds.view(-1),    # shape: (batch_size, num_valid_tokens_per_chunk)
    #                 "labels": valid_labels.view(-1),  # same shape
    #                 "sample_ids": sample_ids,
    #                 "chunk_ids": chunk_ids,
    #                 "word_positions": word_positions,
    #             }
    #         self._test_outputs.append(output)
    #         # Explicitly delete tensors to free memory
    #         del input_ids, labels, outputs
    #         # del embedding_output, logits, pred_ids
    #         del logits_flat, labels_flat, shift_logits, shift_labels
    #         del mask

    #         if torch.cuda.is_available():
    #             torch.cuda.empty_cache()  # Free GPU memory
    #         return output


            # # --- Sample Inspection: Show 1 example per batch ---
            # # if batch_idx == 0:
            # #     sample_idx = 0  # Only show one sample per batch

            # #     input_sample = input_ids[sample_idx]          # shape: [seq_len]
            # #     label_sample = labels[:input_sample.size(0)]
            # #     pred_sample = predicted_labels[:input_sample.size(0)]

            # #     # print(f"Raw Values \n {input_sample} and shape {input_sample.shape}\n \
            # #     #     label_sample {label_sample} and shape {label_sample.shape} \n \
            # #     #         pred sample {pred_sample} and shape {pred_sample.shape}")
            # #     # Decode input IDs to text if tokenizer is available
            # #     if hasattr(self, "tokenizer"):
            # #         input_text = self.tokenizer.decode([t for t in input_sample if t != -100], skip_special_tokens=False)
            # #     else:
            # #         input_text = input_sample.tolist()  # raw token IDs

            # #     # Generate from embedding model if needed
            # #     embedding_output = None
            # #     # if hasattr(self, "embedding"):  # e.g., for generating token embeddings
            # #     #     with torch.no_grad():
            # #     #         # input_sample: [seq_len] → [1, seq_len]
            # #     #         logits = self.embedding(input_ids=input_sample.unsqueeze(0)).logits.to(dtype=torch.float32)
            # #     #         pred_ids = torch.argmax(logits, dim=-1)
            # #     #         decoded_prediction = self.tokenizer.batch_decode(pred_ids, skip_special_tokens=True)

            # #     with torch.no_grad():
            # #         # Add batch dimension: [seq_len] -> [1, seq_len]
            # #         input_ids = input_sample.unsqueeze(0).to(self.embedding.device)

            # #         # Generate output tokens
            # #         generated_ids = self.embedding.generate(
            # #             input_ids=input_ids,
            # #             attention_mask=(input_ids != self.tokenizer.eos_token_id),  # this line fixes the warning
            # #             max_new_tokens=512,
            # #             do_sample=False,  # Turn off sampling (which uses cumsum)
            # #             temperature=None,  # Explicitly unset
            # #             top_p=None,        # Explicitly unset
            # #             top_k=None,        # Optional, unset if needed
            # #             eos_token_id=self.tokenizer.eos_token_id,
            # #             pad_token_id=self.tokenizer.eos_token_id,
            # #         )

            # #         # Slice to keep only the newly generated part (after prompt)
            # #         new_tokens = generated_ids[0][input_ids.shape[1]:]

            # #         # Decode to string
            # #         decoded_prediction = self.tokenizer.decode(new_tokens, skip_special_tokens=True)

            # #         # -------------------------------
            # #         # Log the full output properly
            # #         print(
            # #             f"--- Test Sample for batch {batch_idx} ---\n"
            # #             f"Input IDs: {input_sample.tolist()}\n"
            # #             f"Decoded Input Text: {input_text}\n"
            # #             f"Decoded prediction: {decoded_prediction}\n"
            # #             f"True Label: {label_sample}\n"
            # #             f"Predicted Label: {pred_sample}"
            # #         )

            # #         del input_sample, label_sample, pred_sample, generated_ids, new_tokens, embedding_output


            # # Explicitly delete tensors to free memory
            # del input_ids, labels, outputs
            # # del embedding_output, logits, pred_ids
            # del logits_flat, labels_flat, shift_logits, shift_labels
            # del mask

            # if torch.cuda.is_available():
            #     torch.cuda.empty_cache()  # Free GPU memory

            # return {"predictions": predicted_labels}

    def test_step(self, batch, batch_idx):
        """Memory-efficient test step with chunk-level prediction output for later reconciliation."""
        with torch.no_grad():
            input_ids = batch["input_ids"].to(self.curr_device, non_blocking=True)
            labels = batch["labels"].to(self.curr_device, non_blocking=True)
            lang_codes_list = batch["lang_codes"]
            sample_ids = batch["sample_ids"]
            chunk_ids = batch["chunk_ids"]
            word_positions = batch["word_positions"]
            batch_size = input_ids.size(0)

            outputs, _, _ = self(input_ids)

            shift_logits = outputs[:, :-1, :].contiguous()
            shift_labels = labels[:, 1:].contiguous()

            preds_list = []
            labels_list = []

            for i in range(batch_size):
                logit = shift_logits[i]       # (seq_len, vocab)
                label = shift_labels[i]       # (seq_len,)
                mask = label != -100

                valid_pred = torch.argmax(logit[mask], dim=-1).cpu()  # (valid_len,)
                valid_label = label[mask].cpu()                        # (valid_len,)

                preds_list.append(valid_pred)
                labels_list.append(valid_label)

            # output = {
            #     "preds": preds_list,
            #     "labels": labels_list,
            #     "sample_ids": sample_ids,
            #     "chunk_ids": chunk_ids,
            #     "word_positions": word_positions,
            # }
            output = {
                "lang_codes": lang_codes_list,
                "preds": preds_list,
                "labels": labels_list,
                "sample_ids": sample_ids,
                "chunk_ids": chunk_ids,
                "word_positions": word_positions,
            }

            self._test_outputs.append(output)

            del input_ids, labels, outputs, shift_logits, shift_labels
            # if torch.cuda.is_available():
            #     torch.cuda.empty_cache()

            return output

    def on_test_epoch_end(self):
        # Gather outputs across all test steps
        outputs = getattr(self, "_test_outputs", None)
        if outputs is None or len(outputs) == 0:
            return

        # Reconcile chunked predictions to sample-level
        preds, labels = self.reconcile_chunks(outputs)

        # Compute final test metrics
        self._accuracy.update(preds, labels)
        final_accuracy = self._accuracy.compute()

        # Log test metrics
        self.log(
            "test_accuracy",
            final_accuracy,
            on_step=False,
            on_epoch=True,
            prog_bar=False,
            logger=True,
            sync_dist=True,
        )

        # Reset metric
        self._accuracy.reset()

        # Clear stored outputs to avoid leakage across epochs
        self._test_outputs.clear()

        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        gc.collect()


    def predict_step(self, batch, batch_idx, dataloader_idx=0):
        """Optimized prediction step with efficient memory handling."""

        input_ids, _ = batch  # Labels are not needed

        # Move tensors to device
        input_ids = input_ids.to(self.curr_device, non_blocking=True)

        # Forward pass (without computing KL or contrastive loss)
        outputs, _, _ = self(input_ids)
        predicted_labels = torch.argmax(outputs, dim=-1)

        # Explicitly delete tensors to free memory
        del input_ids, outputs
        if torch.cuda.is_available():
            torch.cuda.empty_cache()  # Free GPU memory

        return {"predictions": predicted_labels.cpu()}


    def reconcile_chunks(self, outputs):
        print(f"\n[reconcile_chunks] Called with {len(outputs)} outputs")

        chunks_by_sample = defaultdict(list)

        for out in outputs:
            sample_ids = out["sample_ids"]
            chunk_preds = out["preds"]
            chunk_labels = out["labels"]
            word_positions = out["word_positions"]

            for i in range(len(sample_ids)):
                sid = sample_ids[i]
                preds_i = chunk_preds[i]
                labels_i = chunk_labels[i]
                positions_i = word_positions[i]

                if isinstance(positions_i, torch.Tensor):
                    positions_i = positions_i.tolist()

                chunks_by_sample[sid].append((positions_i, preds_i, labels_i))

        # Inferred separator label (skipping first position)
        separator_label = self.tokenizer_separator_token
        print(f"[reconcile_chunks] Inferred separator label ID: {separator_label}")

        final_preds = []
        final_labels = []

        for sid, chunks in chunks_by_sample.items():
            pos_to_preds = defaultdict(list)
            pos_to_labels = defaultdict(list)

            for positions, preds, labels in chunks:
                for i, pos in enumerate(positions):
                    if i >= len(preds) or i >= len(labels):
                        continue
                    label = labels[i].item()
                    pred = preds[i].item()

                    if label == separator_label:
                        continue

                    pos_to_preds[pos].append(pred)
                    pos_to_labels[pos].append(label)

            for pos in sorted(pos_to_preds.keys()):
                pred_final = Counter(pos_to_preds[pos]).most_common(1)[0][0]
                label_final = Counter(pos_to_labels[pos]).most_common(1)[0][0]
                final_preds.append(pred_final)
                final_labels.append(label_final)

        return torch.tensor(final_preds), torch.tensor(final_labels)



    
    def on_before_optimizer_step(self, optimizer):
        # Compute gradient norm before clipping
        # grad_norm_before = self._compute_grad_norm()

        # Clip gradients
        # self.clip_gradients(
        #     optimizer, gradient_clip_val=1.0, gradient_clip_algorithm="value"
        # )
        # Manual clipping
        # torch.nn.utils.clip_grad_value_(self.parameters(), clip_value=1.0)
        torch.nn.utils.clip_grad_norm_(self.parameters(), max_norm=1.0)


        # Compute gradient norm after clipping
        # grad_norm_after = self._compute_grad_norm()

        # # Log both norms
        # self.log("grad_norm/before", grad_norm_before, prog_bar=True, on_step=True)
        # self.log("grad_norm/after", grad_norm_after, prog_bar=True, on_step=True)
    
    def on_after_optimizer_step(self, optimizer):
        for param in self.parameters():
            if param is not None:
                param.data.clamp_(-5, 5)

    def _compute_grad_norm(self):
        total_norm = 0
        for param in self.parameters():
            if param.grad is not None:
                param_norm = param.grad.detach().data.norm(2)
                total_norm += param_norm.item() ** 2
        return total_norm ** 0.5  # L2 norm

    def configure_optimizers(self):
        """Configures optimizer and learning rate scheduler."""
        trainable_params = [p for p in self.parameters() if p.requires_grad]
        if not trainable_params:
            print("No trainable parameters. Skipping optimizer creation.")
            return None  # or [] depending on version
        
        # Filter trainable parameters
        model_parameters = filter(lambda p: p.requires_grad, self.parameters())

        # Select optimizer
        optimizers = {
            "adamw": torch.optim.AdamW,
            "adamax": torch.optim.Adamax,
            "adam": torch.optim.Adam,
        }
        optimizer_class = optimizers.get(self.optimizer_name.lower(), torch.optim.Adam)  # Default to Adam

        optimizer = optimizer_class(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Uncomment if using bitsandbytes optimizers
        # if self.optimizer_name == "adamw":
        #     optimizer = bitsandbytes.optim.AdamW(model_parameters, lr=self.hparams.lr, weight_decay=0.001)
        # elif self.optimizer_name == "adam":
        #     optimizer = bitsandbytes.optim.Adam(model_parameters, lr=self.hparams.lr, weight_decay=0.001)

        # Learning rate scheduler
        # lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        #     optimizer, mode="min", factor=0.1, patience=3, cooldown=3, min_lr=1e-8, verbose=True
        # )
        # lr_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=10, T_mult=2, eta_min=1e-6)
    

        # Warmup: 10% of total epochs, rounded up
        total_epochs = self.trainer.max_epochs
        warmup_epochs = math.ceil(0.1 * total_epochs)

        # Warmup LR schedule: linear increase
        warmup_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda epoch: (epoch + 1) / warmup_epochs)

        # CosineAnnealingWarmRestarts after warmup
        cosine_scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            optimizer,
            T_0=max(1, total_epochs - warmup_epochs),
            T_mult=2,
            eta_min=1e-6
        )

        # Combine both in a SequentialLR
        lr_scheduler = torch.optim.lr_scheduler.SequentialLR(
            optimizer,
            schedulers=[warmup_scheduler, cosine_scheduler],
            milestones=[warmup_epochs]
        )
        # Debugging/logging (if needed)
        # print(f"Using optimizer: {self.optimizer_name}")
        # print(f"Initial learning rate: {self.hparams.lr}")
        # print(f"Weight decay: 0.001")
        
        return {"optimizer": optimizer, "lr_scheduler": {"scheduler": lr_scheduler, "interval": "epoch", "monitor": "val_loss"}}

