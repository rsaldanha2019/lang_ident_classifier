# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _e52da7327325
import copy
from _c46cd995125f import _14637d4fa91a
import _db41f880dcfc
import math
import os
from typing import _37c64fa45a5a
import _6ec88c1bdb73 as _10abbd953a8d
import _6c8fc2d33e4c as _118b7429dbad
import _ed06ba440b13
import _44332845499e as _a78c45d4ff61
from _9a0935d2dfdc._50b9bfe0907a._d84a6c8b7494._a636f74e971a import _f3903dbd3183
from _54b741060b4d import _71cbcf7fcd20, _23fc36bf7c36, _c56cb6d87598, _787b198dfe7b, _bdd9ce8831dd

from _ab6cbf1a7240._db1d1d2b0069._3d9949796fe4._0f55586708e6 import _c670f96a48aa
from _ab6cbf1a7240._db1d1d2b0069._f4419932e323._3245415316d8 import _7f0585269176
from _ab6cbf1a7240._db1d1d2b0069._f4419932e323._dadf69381e9f import _73ea21e8d07e
from _ab6cbf1a7240._db1d1d2b0069._f4419932e323._70e26ea999fe import _b206579beb07
from _ab6cbf1a7240._db1d1d2b0069._a8087d0a93ad._a6715ff29ae5 import _a1636fcbd645
# expose only the classifier from the module
_407dba7e52b3 = ["GenLLMLanguageIdentificationClassifier"]

_e6a740262cc0 = 'cuda' if _ed06ba440b13._c1f0b98ba506._9397e3159d0e() else 'cpu'
_7b19ae012561 = _113276a30cc5  # global frozen embedding (kept for compatibility)

    
class _88d7872cd071(_a78c45d4ff61._3ee794be6286):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _8ed9ae78a0fe(_ed06ba440b13._2e69c99d9906._7ef2e8a3a2f8):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _854ce01d0863(self, _da3726ce6e59: _52b322a31dc3, _c6039e7dfab7: _52b322a31dc3 = 64):
            _9616d5313c95()._eb8171c0a331()
            self._91a6baaa7358 = _ed06ba440b13._2e69c99d9906._54ea831a3680(_da3726ce6e59, _c6039e7dfab7, _2ba1d34fa3b6=_eac3a706c388)
            self._bf28ae525234 = _ed06ba440b13._2e69c99d9906._4c6c4f736a5c(_4491131f5c0d=_69a5589bdece)
            self._5e4cf3669a93 = _ed06ba440b13._2e69c99d9906._54ea831a3680(_c6039e7dfab7, _da3726ce6e59, _2ba1d34fa3b6=_eac3a706c388)
            # start adapter near-zero so initial behavior is identity
            _ed06ba440b13._2e69c99d9906._296c4b1fafac._f8b04cbe9305(self._5e4cf3669a93._361f0e0ff24c)
            _ed06ba440b13._2e69c99d9906._296c4b1fafac._c7b3d64e70f6(self._91a6baaa7358._361f0e0ff24c, _6723e78f0f64=math._a630f0b6984b(5))

        def _52588211de9a(self, _58dba181f9d9: _ed06ba440b13._c9806991465a) -> _ed06ba440b13._c9806991465a:
            # supports x shape (B, L, D) or (B, D)
            if _58dba181f9d9._da3726ce6e59() == 2:
                _f6c7f6bbc519 = self._5e4cf3669a93(self._bf28ae525234(self._91a6baaa7358(_58dba181f9d9)))
                return _58dba181f9d9 + _f6c7f6bbc519
            _b8ae94a486ce, _20d8fa501d65, _0035b13edc0c = _58dba181f9d9._ab501d6bcd19
            _5d1f91f1122d = _58dba181f9d9._e247d5ccfa3a(-1, _0035b13edc0c)                    # (B*L, D)
            _5d1f91f1122d = self._5e4cf3669a93(self._bf28ae525234(self._91a6baaa7358(_5d1f91f1122d)))  # (B*L, D)
            _5d1f91f1122d = _5d1f91f1122d._e247d5ccfa3a(_b8ae94a486ce, _20d8fa501d65, _0035b13edc0c)
            return _58dba181f9d9 + _5d1f91f1122d
        
    class _40c9a0782962(_ed06ba440b13._2e69c99d9906._7ef2e8a3a2f8):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _854ce01d0863(self, _4348828036d2, _e6f3efc7d10f=-5, _7704b53da8c9=5):
            _9616d5313c95()._eb8171c0a331()
            self._4348828036d2 = _4348828036d2
            self._e6f3efc7d10f = _e6f3efc7d10f
            self._7704b53da8c9 = _7704b53da8c9
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _52588211de9a(self, *_83a30c5a146b, **_59d37876f87b):
            _83a30c5a146b = _290c47242672(
                _984f9b8c1b2b._96e5486de770(_ed06ba440b13._aa1218f8ad66)._c0532b71a733(-10, 10) if _92eb914fd7d5(_984f9b8c1b2b, _ed06ba440b13._c9806991465a) and _984f9b8c1b2b._70791ba74f8a != _ed06ba440b13._aa1218f8ad66 else _984f9b8c1b2b
                for _984f9b8c1b2b in _83a30c5a146b
            )
            for _72f6490b37bb, _984f9b8c1b2b in _dd0044aa256f(_83a30c5a146b):
                if _92eb914fd7d5(_984f9b8c1b2b, _ed06ba440b13._c9806991465a) and not _ed06ba440b13._0d05d68c48e4(_984f9b8c1b2b)._6bbb33084e7d():
                    _984f9b8c1b2b = _ed06ba440b13._4870838d4ec9(_984f9b8c1b2b)
            _f819ffa6368b = self._4348828036d2(*_83a30c5a146b, **_59d37876f87b)
            if _92eb914fd7d5(_f819ffa6368b, _ed06ba440b13._c9806991465a):
                _f819ffa6368b = _f819ffa6368b._96e5486de770(_ed06ba440b13._aa1218f8ad66)
                if not _ed06ba440b13._0d05d68c48e4(_f819ffa6368b)._6bbb33084e7d():
                    _f819ffa6368b = _ed06ba440b13._4870838d4ec9(_f819ffa6368b)
                _f819ffa6368b._e61bc0041a4a(self._e6f3efc7d10f, self._7704b53da8c9)
            return _f819ffa6368b

    # --- original __init__ signature and body preserved ---
    def _854ce01d0863(
        self,
        _c234d016b238,
        _a830c5295b38,
        _2584f7360855,
        _5b962ae1a34d,
        _78eb14a7fda5,
        _8962419a4d3f,
        _4a34a9c1d9b1,
        _6be50b8bee15,
        _4cb78ba38645,
        _9417a84002ca,
        _d22db1a8d3a2,
        _fe7eaba43392: _52b322a31dc3 = 20,
        _12a174b77e44 = _113276a30cc5,
        _d3a744837202=_113276a30cc5,
        _bda88cd2821d=0.9,
        _4f3e4a8bfaa0:_58be9023a0e6=_113276a30cc5,
    ):
        _9616d5313c95(_3e8cf26b3cc4, self)._eb8171c0a331()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._6681a0a15b19({
            "lr": _15f66a592264(_2584f7360855),
            "optimizer": _58be9023a0e6(_5b962ae1a34d),
            "num_backbone_model_units_unfrozen": _52b322a31dc3(_4a34a9c1d9b1),
            "loss_type": _58be9023a0e6(_6be50b8bee15),
            "is_train": _0b9775297f1b(_4cb78ba38645),
            "random_seed": _52b322a31dc3(_fe7eaba43392),
        })
        self._fe7eaba43392 = _fe7eaba43392
        _a78c45d4ff61._c38852e9fc9a(_fe7eaba43392, _ddd10dd2823e=_69a5589bdece)
        _ed06ba440b13._49661ba553a7(_fe7eaba43392)
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            _ed06ba440b13._c1f0b98ba506._ca3fb2c8f767(_fe7eaba43392)
        _10abbd953a8d.random._8dc4967d1088(_fe7eaba43392)
        self._d3a744837202 = _52b322a31dc3(_d3a744837202) if _d3a744837202 is not _113276a30cc5 else _113276a30cc5
        self._9417a84002ca = _9417a84002ca
        self._4f3e4a8bfaa0 = _4f3e4a8bfaa0
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._9417a84002ca._c4d485c982ed and "<PAD>" not in self._9417a84002ca._737b5dc99e19():
            self._9417a84002ca._69761c9d9096(["<PAD>"], _ff20124e2dd4=_eac3a706c388)
            _6a4f1f36da4b = self._9417a84002ca._692b33c427e5("<PAD>")
            _96ae604a02f1(f"Added padding token  <PAD> with (id: {_6a4f1f36da4b})")
        
        self._393e984e2ee6 = _9417a84002ca._270bc4507bdd(" ", _458e3c7e7ad6=_eac3a706c388)[0]
        self._0b97b2e50d4a = (
            _ed06ba440b13._58799d728214("cuda:{}"._bf9cb43e6cf1(_8962419a4d3f["gpu_local_rank"]))
            if _8962419a4d3f["gpu_local_rank"] != -1
            else "cpu"
        )
        self._12a174b77e44 = _12a174b77e44
        self._bda88cd2821d = _bda88cd2821d
        self._a830c5295b38 =  ["unk"] + _a830c5295b38 if self._bda88cd2821d > 0 else _a830c5295b38
        self._802a236a6852 = _1ab0a988fa37(self._a830c5295b38)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._708561098b80 = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _c59031bb7dec in self._a830c5295b38:
            if _1ab0a988fa37(self._9417a84002ca._270bc4507bdd(_c59031bb7dec, _458e3c7e7ad6=_eac3a706c388)) > 1:
                token = f"{_c59031bb7dec}"
                if token not in self._9417a84002ca._737b5dc99e19():
                    self._9417a84002ca._69761c9d9096([token], _ff20124e2dd4=_eac3a706c388)
                    _6a4f1f36da4b = self._9417a84002ca._692b33c427e5(token)
                    _96ae604a02f1(f"Added class '{_c59031bb7dec}' Token: {token} (id: {_6a4f1f36da4b})")

        # Map every class to single token ID
        self._708561098b80 = {
            _d779164be9ef: [self._9417a84002ca._692b33c427e5(f"{_c59031bb7dec}")]
            for _d779164be9ef, _c59031bb7dec in _dd0044aa256f(self._a830c5295b38)
        }

        self._930226db833f = {_290c47242672(_22c72981d34c): _1f9a4cad51e4 for _1f9a4cad51e4, _22c72981d34c in self._708561098b80._0b116fbf6f58()}
        self._0a0b5bdd0ff8 = _e52da7327325(_e4335c604f7a)
        for _500bec8c205e, _22c72981d34c in self._708561098b80._0b116fbf6f58():
            self._0a0b5bdd0ff8[_1ab0a988fa37(_22c72981d34c)]._8a8402da8be2((_500bec8c205e, _22c72981d34c))
        self._45270ecb2b32 = 0
        _96ae604a02f1(f"SEQ {self._708561098b80} and {self._930226db833f}")
        self._1b093af3da3f = _9417a84002ca._c4d485c982ed or _9417a84002ca._c0f3fb5122d6
        self._78eb14a7fda5 = _78eb14a7fda5
        self._4e814b811a1f = "multiclass"
        self._5a48325534be = -100
        self._9debdbdf315a = _9417a84002ca._270bc4507bdd("assistant<|end_header_id|>\n\n", _458e3c7e7ad6=_eac3a706c388)
        self._dd65535fe874 = self._305e28564894()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._b4eedb5ba958 = _c234d016b238
        # Resize vocab based token embeddings
        self._b4eedb5ba958._7d5aaa8b8815(_1ab0a988fa37(self._9417a84002ca))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._b4eedb5ba958._429a0a45bada(_eac3a706c388)
        _cbab4c064ef6 = _a1636fcbd645()  # bfloat16 or float16

        for _693fe6aac2d2, _4348828036d2 in self._ea6632b31e02():
            if not _0730fdf173ff(_8ef5c468c735._455d6747738a for _8ef5c468c735 in _4348828036d2._4f40fcbbe21a(_f6b985a29d2f=_eac3a706c388)):
                # FROZEN → BF16 (save memory)
                _4348828036d2._96e5486de770(_70791ba74f8a=_cbab4c064ef6)
            else:
                # TRAINABLE → FP32 (stable grads)
                _4348828036d2._96e5486de770(_70791ba74f8a=_ed06ba440b13._aa1218f8ad66)
        self._b4eedb5ba958._96e5486de770(self._0b97b2e50d4a)
        if _2d584920bd47(self._b4eedb5ba958, "gradient_checkpointing_enable"):
            self._b4eedb5ba958._703e04465687()
        # determine embedding dim robustly from model config if available
        _068b34d9a733 = _60336ab9140c(_60336ab9140c(self._b4eedb5ba958, "config", _113276a30cc5), "hidden_size", _113276a30cc5)
        if _068b34d9a733 is _113276a30cc5:
            # fallback to common default — change if your model uses a different hidden size
            _068b34d9a733 = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _2d584920bd47(self._b4eedb5ba958, "lm_head") and _60336ab9140c(self._b4eedb5ba958, "lm_head") is not _113276a30cc5:
            self._7791d5ae5e49 = self._b4eedb5ba958._c4dbc37bbfde
        else:
            _945404b9d87e = _60336ab9140c(self._b4eedb5ba958, "get_output_embeddings", _113276a30cc5)
            self._7791d5ae5e49 = _945404b9d87e() if _725cc1e1760a(_945404b9d87e) else _113276a30cc5

        # mark presence and ensure module (if any) is on the same device
        self._067c60e78fbe = self._7791d5ae5e49 is not _113276a30cc5
        if self._067c60e78fbe:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._7791d5ae5e49._96e5486de770(self._0b97b2e50d4a)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._95063ca8ff06 = self._8e07e58a08fa(_da3726ce6e59=_068b34d9a733, _c6039e7dfab7=64)
        self._95063ca8ff06._96e5486de770(self._0b97b2e50d4a)
        for _8ef5c468c735 in self._95063ca8ff06._4f40fcbbe21a():
            _8ef5c468c735._455d6747738a = _69a5589bdece
            
        if _4a34a9c1d9b1 > 0:
            if "llama" in self._12a174b77e44:
                for _05f218d63ae1 in self._b4eedb5ba958._4f40fcbbe21a():
                    if not _05f218d63ae1._7240c9eb9412:
                        _05f218d63ae1 = _05f218d63ae1._8cc9238e943a()
                    _05f218d63ae1._455d6747738a = _eac3a706c388  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _26919039e559 = self._b4eedb5ba958._05602d16aa78._86723a3b2da7  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _a4eb64f52a21 in _26919039e559[-_4a34a9c1d9b1:]:
                    for _05f218d63ae1 in _a4eb64f52a21._4f40fcbbe21a():
                        if _92eb914fd7d5(_05f218d63ae1, _ed06ba440b13._c9806991465a) and (_05f218d63ae1._6595c995dbca() or _ed06ba440b13._b03b3d0bd39a(_05f218d63ae1)):
                            _05f218d63ae1._455d6747738a = _69a5589bdece
                if _2d584920bd47(self._b4eedb5ba958, "lm_head"):
                    self._b4eedb5ba958._c4dbc37bbfde._455d6747738a = _69a5589bdece

        self._684f8083182f = 1
        _96ae604a02f1(f"DEBUG xth_batch init {self._684f8083182f}")
        global _7b19ae012561
        _7b19ae012561 = copy._369c3f01779d(self._b4eedb5ba958)._5af6e1c3498c()
        self._2584f7360855 = _2584f7360855

        self._cf8839832799 = {}
        self._ea2adbd5a589 = {}

        # Loss function initialization
        if _6be50b8bee15._5215cc9ce4be() == "class_weighted_cross_entropy_loss":
            self._ea2adbd5a589['criterion'] = _73ea21e8d07e(_78eb14a7fda5=self._78eb14a7fda5,
                                                            _58799d728214=self._0b97b2e50d4a,
                                                            _423e5c946c22=self._5a48325534be,
                                                            _11633d8d008f=self._393e984e2ee6)
        elif _6be50b8bee15._5215cc9ce4be() == "focal_loss":
            self._ea2adbd5a589['criterion'] = _b206579beb07(_c2238ae4d000=0.25,
                                                     _58799d728214=self._0b97b2e50d4a,
                                                     _423e5c946c22=self._5a48325534be,
                                                     _11633d8d008f=self._393e984e2ee6)
        elif _6be50b8bee15._5215cc9ce4be() == "class_weighted_focal_loss":
            self._ea2adbd5a589['criterion'] = _b206579beb07(_c2238ae4d000=self._78eb14a7fda5,
                                                     _58799d728214=self._0b97b2e50d4a,
                                                     _423e5c946c22=self._5a48325534be,
                                                     _11633d8d008f=self._393e984e2ee6)
        elif _6be50b8bee15._5215cc9ce4be() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._ea2adbd5a589['criterion'] = _7f0585269176(_c2238ae4d000=self._78eb14a7fda5,
                                                                      _5dff2aa94ff0='type1',
                                                                      _58799d728214=self._0b97b2e50d4a,
                                                                      _423e5c946c22=self._5a48325534be,
                                                                      _11633d8d008f=self._393e984e2ee6)
        elif _6be50b8bee15._5215cc9ce4be() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._ea2adbd5a589['criterion'] = _7f0585269176(_c2238ae4d000=self._78eb14a7fda5,
                                                                      _5dff2aa94ff0='type2',
                                                                      _58799d728214=self._0b97b2e50d4a,
                                                                      _423e5c946c22=self._5a48325534be,
                                                                      _11633d8d008f=self._393e984e2ee6)
        elif _6be50b8bee15._5215cc9ce4be() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._ea2adbd5a589['criterion'] = _7f0585269176(_c2238ae4d000=self._78eb14a7fda5,
                                                                      _5dff2aa94ff0='type3',
                                                                      _58799d728214=self._0b97b2e50d4a,
                                                                      _423e5c946c22=self._5a48325534be,
                                                                      _11633d8d008f=self._393e984e2ee6)
        else:
            self._ea2adbd5a589['criterion'] = _73ea21e8d07e(_58799d728214=self._0b97b2e50d4a,
                                                            _423e5c946c22=self._5a48325534be,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._4debb0baae9e = 0.99
        self._0f732ce6a754 = 0.3
        self._32c9928eb496 = 0.30
        self._c851b06a39c9 = 0.25
        self._8da6ca5152e4 = 0.6
        self._d8daa10a5d5f = 0.995
        self._641742513fe5 = 0.60
        self._afa82836f426 = 0.20
        self._a1176b49f469 = _60336ab9140c(self, "batch_counter", 0)


        self._7570568cbcfe = []
        self._decbb6c77f35 = []

        self._0f57250d5bf2 = _5b962ae1a34d._5215cc9ce4be()
        self._a126a038b8b9()

        self._35c84184ef92(self._b4eedb5ba958)
    
    def _d0e6cc1927e8(self):
        # rebuild all metrics on the correct device
        self._cf8839832799['micro_accuracy'] = _71cbcf7fcd20(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f="micro",
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['macro_accuracy'] = _71cbcf7fcd20(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f="macro",
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['macro_precision'] = _c56cb6d87598(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f="macro",
            _7f666f25a8b2=self. _4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['macro_recall'] = _787b198dfe7b(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f="macro",
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['macro_f1'] = _bdd9ce8831dd(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f="macro",
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['classwise_accuracy'] = _71cbcf7fcd20(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f=_113276a30cc5,
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['classwise_precision'] = _c56cb6d87598(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f=_113276a30cc5,
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['classwise_recall'] = _787b198dfe7b(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f=_113276a30cc5,
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['classwise_f1'] = _bdd9ce8831dd(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _61c4b5ca942f=_113276a30cc5,
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)

        self._cf8839832799['confmat'] = _23fc36bf7c36(
            _802a236a6852=_1ab0a988fa37(self._a830c5295b38),
            _7f666f25a8b2=self._4e814b811a1f,
            _423e5c946c22=self._5a48325534be,
        )._96e5486de770(self._0b97b2e50d4a)


    def _c377e47bbc87(self, _bc5e14e99e2c=_113276a30cc5):
        """Calculate batch counts and set xth_batch_to_consider."""
        _c21496b8bcb9 = 0
        _8d1bd91262c5 = 0
        if self._a0e688daa87b._54f5a2b76e84 is not _113276a30cc5:
            if _2d584920bd47(self._a0e688daa87b._54f5a2b76e84, 'train_dataset') and self._a0e688daa87b._54f5a2b76e84._6cd0c2ee0ebc is not _113276a30cc5:
                _c21496b8bcb9 = _1ab0a988fa37(self._a0e688daa87b._54f5a2b76e84._6cd0c2ee0ebc)
            if _2d584920bd47(self._a0e688daa87b._54f5a2b76e84, 'val_dataset') and self._a0e688daa87b._54f5a2b76e84._7094810c4862 is not _113276a30cc5:
                _8d1bd91262c5 = _1ab0a988fa37(self._a0e688daa87b._54f5a2b76e84._7094810c4862)
            _342984c3ff1c = self._a0e688daa87b._54f5a2b76e84._342984c3ff1c
            _788c04e3774b = (_c21496b8bcb9 + _342984c3ff1c - 1) // _342984c3ff1c if _c21496b8bcb9 > 0 else 1
            _b11e853ae9fb = (_8d1bd91262c5 + _342984c3ff1c - 1) // _342984c3ff1c if _8d1bd91262c5 > 0 else 1
            _4acb3587800a = _043fe35f6312(_788c04e3774b, _b11e853ae9fb) if _8d1bd91262c5 > 0 else _788c04e3774b
            _85c8a201c622 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._684f8083182f = 1
            _96ae604a02f1(f"DEBUG Batch Info: num_train_batches={_788c04e3774b}, num_val_batches={_b11e853ae9fb}, xth_batch_to_consider={self._684f8083182f}")

    def _2c1d1b8e79a5(self, _d3945cfd0aee, _b0402add7d6e):
        if _d3945cfd0aee._5215cc9ce4be() == "parametric_relu":
            return _ed06ba440b13._2e69c99d9906._5bfab9e78b96(_b0402add7d6e=1)
        elif _d3945cfd0aee._5215cc9ce4be() == "leaky_relu":
            return _ed06ba440b13._2e69c99d9906._26ae87fbc943(_4491131f5c0d=_eac3a706c388)
        else:
            return _ed06ba440b13._2e69c99d9906._4c6c4f736a5c(_4491131f5c0d=_eac3a706c388)

    def _148f0b88ea12(self, _4348828036d2, _bdeed299bd45=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _693fe6aac2d2, _935e837e48e7 in _4348828036d2._ab210f3bcb0b():
            _f2c3964cb06e = f"{_bdeed299bd45}.{_693fe6aac2d2}" if _bdeed299bd45 else _693fe6aac2d2

            def _e1e6eee3fdaa(_b740ed62164a, _984f9b8c1b2b, _f6c7f6bbc519):
                if _92eb914fd7d5(_f6c7f6bbc519, _ed06ba440b13._c9806991465a) and _f6c7f6bbc519._49cefe327006()._0730fdf173ff():
                    _96ae604a02f1(f"NaN detected in {_f2c3964cb06e} ({_b740ed62164a._023b9d8585fa.__name__}) ({_f6c7f6bbc519._70791ba74f8a})")

            _935e837e48e7._7b05fffaf315(_03b15da8dd1e)

            self._35c84184ef92(_935e837e48e7, _f2c3964cb06e)

    def _67f8cc8be333(self, _4348828036d2):
        return _0730fdf173ff(_8ef5c468c735._455d6747738a for _8ef5c468c735 in _4348828036d2._4f40fcbbe21a())

    def _ea3c584d00dd(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _244de1ebada5 = []
        for _693fe6aac2d2, _4348828036d2 in self._ea6632b31e02():
            if not self._a0fed77dcac1(_4348828036d2):
                continue
            _3ce9af9f83b9 = (
                "norm" in _693fe6aac2d2._de08adac5266() or 
                "linear4bit" in _693fe6aac2d2._de08adac5266() or 
                _0730fdf173ff(_bf28ae525234 in _693fe6aac2d2._de08adac5266() for _bf28ae525234 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _693fe6aac2d2._de08adac5266() or 
                "dropout" in _693fe6aac2d2._de08adac5266() or 
                _92eb914fd7d5(_4348828036d2, (_f3903dbd3183, _ed06ba440b13._2e69c99d9906._54ea831a3680, _ed06ba440b13._2e69c99d9906._7bd570f541ec))
            )
            if _3ce9af9f83b9:
                if _2d584920bd47(_4348828036d2, "eps"):
                    _4348828036d2._e6e16aaee5fb = 1e-3
                _4348828036d2 = _4348828036d2._96e5486de770(_ed06ba440b13._aa1218f8ad66)
                if not _92eb914fd7d5(_4348828036d2, _3e8cf26b3cc4._46315d4e40c8):
                    _244de1ebada5._8a8402da8be2((_693fe6aac2d2, _3e8cf26b3cc4._46315d4e40c8(_4348828036d2, _e6f3efc7d10f=-10, _7704b53da8c9=10)))
        for _693fe6aac2d2, _d3e0d0b75215 in _244de1ebada5:
            _1114fecec14b, _89ff98cbc11e = self._695a4952dee3(_693fe6aac2d2)
            if _1114fecec14b is not _113276a30cc5:
                _1146ecef0575(_1114fecec14b, _89ff98cbc11e, _d3e0d0b75215)

    def _464845cfef7f(self, _84e375dff252):
        """Finds the parent module and attribute name given the full module path."""
        _c10a490361bc = _84e375dff252._696e2ea0602b('.')
        _cfe31b3b15fe = self
        for _9292f9339a35 in _c10a490361bc[:-1]:
            _cfe31b3b15fe = _60336ab9140c(_cfe31b3b15fe, _9292f9339a35, _113276a30cc5)
            if _cfe31b3b15fe is _113276a30cc5:
                return _113276a30cc5, _113276a30cc5
        return _cfe31b3b15fe, _c10a490361bc[-1]

    def _e43dec9937e8(self, _708c195fb5eb: _ed06ba440b13._c9806991465a, _7843843c80d2: _ed06ba440b13._c9806991465a, _e11908c37ef4: _ed06ba440b13._c9806991465a) -> _295a9c24af67:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _58799d728214 = _708c195fb5eb._58799d728214

        # 1) gating w (use cached per-example teacher_conf if available)
        _f49d6da89178 = _60336ab9140c(self, "_last_teacher_conf", _113276a30cc5)
        if _f49d6da89178 is _113276a30cc5:
            # no teacher info => w = 0 (no distillation)
            _5551436db5f7 = 0.0
        else:
            _fedf02f77388 = (_f49d6da89178 >= _15f66a592264(_60336ab9140c(self, "teacher_conf_tau", 0.6)))._15f66a592264()
            _5551436db5f7 = _15f66a592264(_fedf02f77388._cf13e651728b()._3b32da078ba3()._6f44dc85b6ca()) if _fedf02f77388._61efe8b00a0e() > 0 else 0.0

        # apply gating to the batch scalars
        _c1779c2d7eca = _7843843c80d2 * _15f66a592264(_5551436db5f7)
        _64b5d14c9810 = _e11908c37ef4 * _15f66a592264(_5551436db5f7)

        # 2) EMAs for autoscaling
        _c6768e219b89 = _15f66a592264((_c1779c2d7eca + _64b5d14c9810)._8cc9238e943a()._3b32da078ba3()._6f44dc85b6ca())
        _7b9a7e9e548b = _15f66a592264(_708c195fb5eb._8cc9238e943a()._3b32da078ba3()._6f44dc85b6ca())
        if _60336ab9140c(self, "ema_task", _113276a30cc5) is _113276a30cc5:
            self._d4c3e943fad3 = _7b9a7e9e548b
            self._b7a4398f2ee9 = _c6768e219b89 + 1e-12
        else:
            _c2238ae4d000 = _15f66a592264(_60336ab9140c(self, "ema_alpha", 0.99))
            self._d4c3e943fad3 = _c2238ae4d000 * _15f66a592264(self._d4c3e943fad3) + (1.0 - _c2238ae4d000) * _7b9a7e9e548b
            self._b7a4398f2ee9  = _c2238ae4d000 * _15f66a592264(self._b7a4398f2ee9)  + (1.0 - _c2238ae4d000) * _c6768e219b89

        _30be4472e384 = _15f66a592264(_60336ab9140c(self, "distill_target_ratio", 0.3))
        _bd0660a6faa0 = (_15f66a592264(self._d4c3e943fad3) / (_15f66a592264(self._b7a4398f2ee9) + 1e-12)) * _30be4472e384
        _40479ed51a4d = _15f66a592264(_bd0660a6faa0)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _5075da397e1a = _15f66a592264(_60336ab9140c(self._a0e688daa87b, "current_epoch", _60336ab9140c(self._a0e688daa87b, "global_step", 0.0)))
        _7f086ae200ea = _15f66a592264(_dbb3ecd84bb1(1, _60336ab9140c(self._a0e688daa87b, "max_epochs", 1)))
        _73cf1d42739c = _043fe35f6312(_dbb3ecd84bb1(_5075da397e1a / _7f086ae200ea, 0.0), 1.0)
        _76569a1cdfe6 = 0.30
        _b875f7010c26 = _15f66a592264(_60336ab9140c(self, "kl_base", 0.30)) * _043fe35f6312(_73cf1d42739c / _76569a1cdfe6, 1.0)
        _c851b06a39c9 = _15f66a592264(_60336ab9140c(self, "cos_base", 0.25))
        _31793cabb522 = _c851b06a39c9 + (0.10 - _c851b06a39c9) * _73cf1d42739c

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _1e93e4739a6b = _15f66a592264(self._354d33de99dd._cf13e651728b()._3b32da078ba3()._6f44dc85b6ca()) if _60336ab9140c(self, "_last_teacher_conf", _113276a30cc5) is not _113276a30cc5 else 0.0
        if _60336ab9140c(self, "ema_teacher_conf", _113276a30cc5) is _113276a30cc5:
            self._211be915c346 = _1e93e4739a6b
        else:
            _b8ae94a486ce = _15f66a592264(_60336ab9140c(self, "teacher_conf_beta", 0.995))
            self._211be915c346 = _b8ae94a486ce * _15f66a592264(self._211be915c346) + (1.0 - _b8ae94a486ce) * _1e93e4739a6b

        _641742513fe5 = _15f66a592264(_60336ab9140c(self, "tau_warn", 0.60))
        _afa82836f426 = _15f66a592264(_60336ab9140c(self, "tau_detect", 0.20))
        _5bcd7621acfa = _dbb3ecd84bb1(1e-12, (_641742513fe5 - _afa82836f426))
        _464dcdab1152 = (_15f66a592264(self._211be915c346) - _afa82836f426) / _5bcd7621acfa
        _464dcdab1152 = _dbb3ecd84bb1(0.0, _043fe35f6312(1.0, _464dcdab1152))

        _32a22f6cdb5f = _b875f7010c26 * _464dcdab1152
        _02b7c591b382 = _31793cabb522 * _464dcdab1152

        # 5) final aux term
        _b280b43f8f05 = _ed06ba440b13._95f6e06ab8fd(0.0, _58799d728214=_58799d728214)
        _b280b43f8f05 = _b280b43f8f05 + (_32a22f6cdb5f * _c1779c2d7eca + _02b7c591b382 * _64b5d14c9810) * _15f66a592264(_40479ed51a4d)

        # diagnostics
        _f6c7f6bbc519 = {
            "aux_term": _b280b43f8f05,
            "kl_batch": _7843843c80d2,
            "contrast_batch": _e11908c37ef4,
            "kl_loss": _c1779c2d7eca,
            "contrastive_loss": _64b5d14c9810,
            "w_mean": _5551436db5f7,
            "aux_scale": _15f66a592264(_40479ed51a4d),
            "lambda_kl_eff": _15f66a592264(_32a22f6cdb5f),
            "lambda_cos_eff": _15f66a592264(_02b7c591b382),
            "teacher_conf_mean": _15f66a592264(self._211be915c346),
            "shift_r": _15f66a592264(_464dcdab1152)
        }
        return _f6c7f6bbc519

    def _52588211de9a(self, _e1221197618e):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _e1221197618e = _e1221197618e._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)
        _32c3728b73f2 = (_e1221197618e != self._9417a84002ca._c4d485c982ed)._96e5486de770(_70791ba74f8a=_ed06ba440b13._0b9775297f1b, _58799d728214=self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)

        # model forward (request hidden states)
        _6001ed1b0963 = self._b4eedb5ba958(
            _e1221197618e=_e1221197618e,
            _32c3728b73f2=_32c3728b73f2,
            _8c7f65ff28b8=_69a5589bdece,
            _72770994235d=_69a5589bdece,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _ce5d9a1b8757 = _60336ab9140c(_6001ed1b0963, "last_hidden_state", _113276a30cc5)
        if _ce5d9a1b8757 is _113276a30cc5:
            _ce5d9a1b8757 = _6001ed1b0963._afefc1891254[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _ce5d9a1b8757._70791ba74f8a != _ed06ba440b13._aa1218f8ad66:
            _ce5d9a1b8757 = _ce5d9a1b8757._96e5486de770(_ed06ba440b13._aa1218f8ad66)
        _0f9204166986 = self._95063ca8ff06(_ce5d9a1b8757)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._067c60e78fbe:
            _dcc2250e25df = self._7791d5ae5e49(_0f9204166986)
        else:
            _dcc2250e25df = _6001ed1b0963._dcc2250e25df


        _dcc2250e25df = _dcc2250e25df._96e5486de770(_ed06ba440b13._aa1218f8ad66)._c0532b71a733(-20, 20)

        # default zero scalars
        _c1779c2d7eca = _ed06ba440b13._95f6e06ab8fd(0.0, _58799d728214=self._0b97b2e50d4a)
        _64b5d14c9810 = _ed06ba440b13._95f6e06ab8fd(0.0, _58799d728214=self._0b97b2e50d4a)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _5f4c87ea7599 = _60336ab9140c(self, "trainer", _113276a30cc5)
        _95b1d944a316 = _eac3a706c388
        if _5f4c87ea7599 is not _113276a30cc5:
            _95b1d944a316 = _0b9775297f1b(_60336ab9140c(self._a0e688daa87b, "training", _eac3a706c388) or _60336ab9140c(self._a0e688daa87b, "validating", _eac3a706c388))

        if _95b1d944a316 and (_60336ab9140c(self, "batch_counter", 0) % _60336ab9140c(self, "xth_batch_to_consider", 1) == 0):
            with _ed06ba440b13._30e9946445a2():
                _5ceb7c50d3f7 = _7b19ae012561(
                    _e1221197618e=_e1221197618e,
                    _32c3728b73f2=_32c3728b73f2,
                    _8c7f65ff28b8=_69a5589bdece,
                    _72770994235d=_69a5589bdece,
                )
                _dd23583ed9ab = _60336ab9140c(_5ceb7c50d3f7, "last_hidden_state", _113276a30cc5)
                if _dd23583ed9ab is _113276a30cc5:
                    _dd23583ed9ab = _5ceb7c50d3f7._afefc1891254[-1]

            # compute embedding-level KL + contrastive (scalar)
            _c1779c2d7eca, _64b5d14c9810 = self._7803bfe56d1e(_0f9204166986, _dd23583ed9ab, _58799d728214=self._0b97b2e50d4a)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _84842e5c7015(_58dba181f9d9): return _58dba181f9d9._cf13e651728b(_da3726ce6e59=1) if _58dba181f9d9._da3726ce6e59() == 3 else _58dba181f9d9
            _21782a7ceb18 = _ed06ba440b13._2e69c99d9906._19457a07c007._980875c3f80d(_5135f519611f(_0f9204166986), _8ef5c468c735=2, _da3726ce6e59=-1, _e6e16aaee5fb=1e-6)
            _6c4877595792 = _ed06ba440b13._2e69c99d9906._19457a07c007._980875c3f80d(_5135f519611f(_dd23583ed9ab), _8ef5c468c735=2, _da3726ce6e59=-1, _e6e16aaee5fb=1e-6)
            _c0fc8bae9634 = _ed06ba440b13._2e69c99d9906._19457a07c007._6355cfe88f3c(_21782a7ceb18, _6c4877595792, _da3726ce6e59=-1)  # [-1,1]
            _f49d6da89178 = _c0fc8bae9634._c0532b71a733(_043fe35f6312=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._2416bd8c0adb = _0f9204166986._8cc9238e943a()
            self._519dffda7c6b = _dd23583ed9ab._8cc9238e943a()
            self._354d33de99dd = _f49d6da89178._8cc9238e943a()  # shape (B,)

        # increment counter
        self._a1176b49f469 = _60336ab9140c(self, "batch_counter", 0) + 1

        return _dcc2250e25df, _c1779c2d7eca, _64b5d14c9810


    def _2ad836dfae34(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _986ad0a8d21d(_4348828036d2, _83a30c5a146b, _145013ac8c58):
            if _0730fdf173ff(_984f9b8c1b2b._70791ba74f8a == _ed06ba440b13._d0ee10193973 for _984f9b8c1b2b in _83a30c5a146b if _92eb914fd7d5(_984f9b8c1b2b, _ed06ba440b13._c9806991465a)):
                _96ae604a02f1(f"Layer {_4348828036d2._023b9d8585fa.__name__} is using float16!")

        for _eeaec0a8a3b1 in self._e29aa2f5d258():
            _dd20e392d8e5 = _eeaec0a8a3b1._7b05fffaf315(_950a32a93408)
            self._10457be58421._8a8402da8be2(_dd20e392d8e5)

    def _4a3bd1407408(self):
        """Remove all registered forward hooks."""
        for _dd20e392d8e5 in _60336ab9140c(self, "amp_hooks", []):
            _dd20e392d8e5._d971e48feae0()
        self._10457be58421 = []

    def _0ef6c8d2a653(self, _e1221197618e, _632c43a142ce, _a7656f977a1c):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _4b4bad177e04 = [self._9417a84002ca._114b7d96f7e6(_5aa86954fe2c) for _5aa86954fe2c in _e1221197618e]
        _18d7a302ff78, _3f6e7c9f0c70 = [], []

        for _60ba7360941a, _16efe0f44062, _552b48f52277 in _b53efeffaf5f(_4b4bad177e04, _632c43a142ce, _a7656f977a1c):
            for token, _3d9dd8ebdeff, _75c60cef8ba7 in _b53efeffaf5f(_60ba7360941a, _16efe0f44062, _552b48f52277):
                if token == self._9417a84002ca._7106c25e44c6 or _75c60cef8ba7 == self._5a48325534be:
                    continue

                _3ab1643aaf52 = (
                    token._632724816d33("##") or
                    token._632724816d33("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _3ab1643aaf52:
                    continue

                _18d7a302ff78._8a8402da8be2(_3d9dd8ebdeff._6f44dc85b6ca())
                _3f6e7c9f0c70._8a8402da8be2(_75c60cef8ba7._6f44dc85b6ca())

        return _ed06ba440b13._95f6e06ab8fd(_18d7a302ff78), _ed06ba440b13._95f6e06ab8fd(_3f6e7c9f0c70)

    def _d529ffd08748(self):
        _85f4c8adceb1 = _ed06ba440b13._aa1218f8ad66
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            _fc4278b85c93, _8e2290467af9 = _ed06ba440b13._c1f0b98ba506._209e79420222()
            if _fc4278b85c93 >= 8:
                _85f4c8adceb1 = _ed06ba440b13._6ca8474cc250
            else:
                _85f4c8adceb1 = _ed06ba440b13._d0ee10193973
        return _85f4c8adceb1

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _f398c1b5d7aa(
        self,
        _0fb8c113d230: _ed06ba440b13._c9806991465a,
        _60ddabb8db1c: _ed06ba440b13._c9806991465a,
        _58799d728214: _58be9023a0e6 = "cpu",
    ) -> _37c64fa45a5a[_ed06ba440b13._c9806991465a, _ed06ba440b13._c9806991465a]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _9c5b4510e88d = 2.0
            # NaN/Inf guard
            _0fb8c113d230 = _0fb8c113d230._c0532b71a733(_043fe35f6312=-30, _dbb3ecd84bb1=30)
            _60ddabb8db1c = _60ddabb8db1c._c0532b71a733(_043fe35f6312=-30, _dbb3ecd84bb1=30)

            # Move once if needed
            _dda2d64958e1 = _ed06ba440b13._58799d728214(_58799d728214)
            if _0fb8c113d230._58799d728214 != _dda2d64958e1:
                _0fb8c113d230 = _0fb8c113d230._96e5486de770(_58799d728214=_dda2d64958e1, _a0265a7063ce=_69a5589bdece, _70791ba74f8a=self._dd65535fe874)
                _60ddabb8db1c = _60ddabb8db1c._96e5486de770(_58799d728214=_dda2d64958e1, _a0265a7063ce=_69a5589bdece, _70791ba74f8a=self._dd65535fe874)

            _342984c3ff1c = _0fb8c113d230._6de79e5b1838(0)
            _068b34d9a733 = _0fb8c113d230._6de79e5b1838(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _66001f1b46c5 = (_342984c3ff1c * _068b34d9a733) > 32_000_000

            if not _66001f1b46c5 or _342984c3ff1c <= 8:
                # Direct computation
                _79e22c0f56a8 = _ed06ba440b13._2e69c99d9906._19457a07c007._c4423c8c4721(_0fb8c113d230 / _9c5b4510e88d, _da3726ce6e59=-1)
                _25c94cee67c4 = _ed06ba440b13._2e69c99d9906._19457a07c007._91fc434e9c3d(_60ddabb8db1c / _9c5b4510e88d, _da3726ce6e59=-1)
                _c1779c2d7eca = _ed06ba440b13._2e69c99d9906._19457a07c007._3355a5ee8a1a(_79e22c0f56a8, _25c94cee67c4, _906dba115552="batchmean") * (_9c5b4510e88d * _9c5b4510e88d)
                _64b5d14c9810 = 1 - _ed06ba440b13._2e69c99d9906._19457a07c007._6355cfe88f3c(_0fb8c113d230, _60ddabb8db1c, _da3726ce6e59=-1)._cf13e651728b()
                return _c1779c2d7eca, _64b5d14c9810

            # Chunked mode for large inputs
            _b1a4dba8db95 = _dbb3ecd84bb1(1, _342984c3ff1c // 8)
            _bef732b300ef, _75e194f7bafc = [], []

            for _72f6490b37bb in _26f8deabc1ca(0, _342984c3ff1c, _b1a4dba8db95):
                _1a08e1145333 = _0fb8c113d230[_72f6490b37bb:_72f6490b37bb + _b1a4dba8db95]
                _dee30823589b = _60ddabb8db1c[_72f6490b37bb:_72f6490b37bb + _b1a4dba8db95]

                _79e22c0f56a8 = _ed06ba440b13._2e69c99d9906._19457a07c007._c4423c8c4721(_1a08e1145333 / _9c5b4510e88d, _da3726ce6e59=-1)
                _25c94cee67c4 = _ed06ba440b13._2e69c99d9906._19457a07c007._91fc434e9c3d(_dee30823589b / _9c5b4510e88d, _da3726ce6e59=-1)

                _590729b16f2a = _ed06ba440b13._2e69c99d9906._19457a07c007._3355a5ee8a1a(_79e22c0f56a8, _25c94cee67c4, _906dba115552="batchmean") * (_9c5b4510e88d * _9c5b4510e88d)
                _8f725d67d00a = _ed06ba440b13._2e69c99d9906._19457a07c007._6355cfe88f3c(_1a08e1145333, _dee30823589b, _da3726ce6e59=-1)._cf13e651728b()
                _89797295cc53 = 1 - _8f725d67d00a

                _bef732b300ef._8a8402da8be2(_590729b16f2a)
                _75e194f7bafc._8a8402da8be2(_89797295cc53)

            _c1779c2d7eca = _ed06ba440b13._b09515e5bb2c(_bef732b300ef)._cf13e651728b()
            _64b5d14c9810 = _ed06ba440b13._b09515e5bb2c(_75e194f7bafc)._cf13e651728b()
            return _c1779c2d7eca, _64b5d14c9810

        except _90a8944bba14 as _c2e05cb2ac82:
            raise _d022f8c53315(f"KL/contrastive loss computation failed: {_58be9023a0e6(_c2e05cb2ac82)}")


    def _ca9718974393(self, _3a1079ad3a41, _7b23ab12aa64):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _e1221197618e = _3a1079ad3a41["input_ids"]
            _b129ad4d8c11 = _3a1079ad3a41["labels"]
            _e3aa00adedd2 = _3a1079ad3a41._4d0fa508a7d7("prompt_lens", _113276a30cc5)
            _342984c3ff1c = _e1221197618e._6de79e5b1838(0)

            # move to device
            _e1221197618e = _e1221197618e._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)
            _b129ad4d8c11 = _b129ad4d8c11._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _145013ac8c58, _7843843c80d2, _e11908c37ef4 = self(_e1221197618e)

            # causal LM shift for next-token classification (unchanged)
            _977b4f562ac8 = _145013ac8c58[:, :-1, :]._b2097d64c542()
            _8277d7a0ca89 = _b129ad4d8c11[:, 1:]._b2097d64c542()
            _2c295c3d02e7 = _977b4f562ac8._e247d5ccfa3a(-1, _977b4f562ac8._6de79e5b1838(-1))
            _8c8b424d1b57 = _8277d7a0ca89._e247d5ccfa3a(-1)

            # classification/task loss
            _12e25bb36edf = self._ea2adbd5a589['criterion'](_2c295c3d02e7, _8c8b424d1b57)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _7843843c80d2 = _ed06ba440b13._4870838d4ec9(_7843843c80d2, _4ec6cedda414=0.0, _cb2296472d7c=0.0, _fb7059060dbd=0.0)
            _e11908c37ef4 = _ed06ba440b13._4870838d4ec9(_e11908c37ef4, _4ec6cedda414=0.0, _cb2296472d7c=0.0, _fb7059060dbd=0.0)
            _12e25bb36edf = _ed06ba440b13._4870838d4ec9(_12e25bb36edf, _4ec6cedda414=0.0, _cb2296472d7c=0.0, _fb7059060dbd=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _4c8ee9fa2ff3 = self._791382ba0db3(_12e25bb36edf, _7843843c80d2, _e11908c37ef4)
            _b280b43f8f05 = _4c8ee9fa2ff3["aux_term"]

            # final combined loss (single-equation)
            _26da2778d97e = _12e25bb36edf + _b280b43f8f05

            # Optional NaN print as before (keeps your original check)
            if _ed06ba440b13._49cefe327006(_12e25bb36edf):
                _96ae604a02f1(f"Step {_7b23ab12aa64}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _0f7905d786da = {
                "epoch": _15f66a592264(_60336ab9140c(self, "current_epoch", _60336ab9140c(self._a0e688daa87b, "current_epoch", 0))),
                "train_kl_loss": _4c8ee9fa2ff3._4d0fa508a7d7("kl_loss", _7843843c80d2)._8cc9238e943a() if _92eb914fd7d5(_4c8ee9fa2ff3._4d0fa508a7d7("kl_loss", _7843843c80d2), _ed06ba440b13._c9806991465a) else _4c8ee9fa2ff3._4d0fa508a7d7("kl_loss", _7843843c80d2),
                "train_contrastive_loss": _4c8ee9fa2ff3._4d0fa508a7d7("contrastive_loss", _e11908c37ef4)._8cc9238e943a() if _92eb914fd7d5(_4c8ee9fa2ff3._4d0fa508a7d7("contrastive_loss", _e11908c37ef4), _ed06ba440b13._c9806991465a) else _4c8ee9fa2ff3._4d0fa508a7d7("contrastive_loss", _e11908c37ef4),
                "train_classification_loss": _12e25bb36edf._8cc9238e943a(),
                "train_loss": _26da2778d97e._8cc9238e943a(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _15f66a592264(_60336ab9140c(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _4c8ee9fa2ff3._4d0fa508a7d7("lambda_kl_eff", _15f66a592264(_60336ab9140c(self, "kl_base", 0.30))),
                "train_lambda_contrast": _4c8ee9fa2ff3._4d0fa508a7d7("lambda_cos_eff", _15f66a592264(_60336ab9140c(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _318dcdbdebc6 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _318dcdbdebc6 in _4c8ee9fa2ff3:
                    _fae1e9eeca0e = _4c8ee9fa2ff3[_318dcdbdebc6]
                    # convert single-element tensors to python floats for logging
                    if _92eb914fd7d5(_fae1e9eeca0e, _ed06ba440b13._c9806991465a) and _fae1e9eeca0e._61efe8b00a0e() == 1:
                        _0f7905d786da[f"train_{_318dcdbdebc6}"] = _15f66a592264(_fae1e9eeca0e._8cc9238e943a()._3b32da078ba3()._6f44dc85b6ca())
                    else:
                        _0f7905d786da[f"train_{_318dcdbdebc6}"] = _fae1e9eeca0e

            # log exactly like you did
            self._bd7ac02d1245(
                _0f7905d786da,
                _342984c3ff1c=_342984c3ff1c,
                _c632ca346114=_eac3a706c388,
                _364a6f5c676a=_69a5589bdece,
                _cc7e9cd945b5=_eac3a706c388,
                _5cb97b0d0c7d=_69a5589bdece,
                _ac8b807742f1=_69a5589bdece,
            )

            # free references as you did
            del _e1221197618e, _b129ad4d8c11, _145013ac8c58, _7843843c80d2, _12e25bb36edf, _e11908c37ef4, _8277d7a0ca89, _977b4f562ac8, _8c8b424d1b57, _2c295c3d02e7

            return _26da2778d97e

        except _90a8944bba14 as _c2e05cb2ac82:
            raise _d022f8c53315(f"Error in training_step: {_c2e05cb2ac82}") from _c2e05cb2ac82

    def _d56609c278fa(self):
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            _ed06ba440b13._c1f0b98ba506._5a53f7d7d868()
        _db41f880dcfc._6ce21cbc5507()
        return _9616d5313c95()._66689e2c97eb()

    def _b824188eef2a(self, _3a1079ad3a41, _7b23ab12aa64):
        _e1221197618e      = _3a1079ad3a41["input_ids"]._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)
        _b129ad4d8c11         = _3a1079ad3a41["labels"]._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)
        _c897221186e5     = _3a1079ad3a41._4d0fa508a7d7("lang_codes", _113276a30cc5)
        _f1b243190c96     = _3a1079ad3a41._4d0fa508a7d7("sample_ids", _113276a30cc5)
        _d8bcd598f61b      = _3a1079ad3a41._4d0fa508a7d7("chunk_ids", _113276a30cc5)
        _34803c6e96cc = _3a1079ad3a41._4d0fa508a7d7("word_positions", _113276a30cc5)
        _e3aa00adedd2    = _3a1079ad3a41._4d0fa508a7d7("prompt_lens", _113276a30cc5)
        _926985883e0a = _3a1079ad3a41._4d0fa508a7d7("num_chunks", _113276a30cc5)

        _342984c3ff1c = _e1221197618e._6de79e5b1838(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _145013ac8c58, _7843843c80d2, _e11908c37ef4 = self(_e1221197618e)

        # causal LM shift for next-token classification (same as training)
        _977b4f562ac8 = _145013ac8c58[:, :-1, :]._b2097d64c542()
        _8277d7a0ca89 = _b129ad4d8c11[:, 1:]._b2097d64c542()
        _2c295c3d02e7 = _977b4f562ac8._e247d5ccfa3a(-1, _977b4f562ac8._6de79e5b1838(-1))
        _8c8b424d1b57 = _8277d7a0ca89._e247d5ccfa3a(-1)

        if _7b23ab12aa64 == 0:
            try:
                _96ae604a02f1(
                    f"VAL TEST BATCH {_7b23ab12aa64} Input IDs: {_e1221197618e._3125435edba7()[0]}, "
                    f"Predictions: {_ed06ba440b13._60dbacbeff71(_977b4f562ac8, _da3726ce6e59=-1)._3125435edba7()[0]}, "
                    f"Labels: {_8277d7a0ca89._3125435edba7()[0]}"
                )
            except _90a8944bba14:
                # printing should never crash validation
                pass

        # classification loss
        _12e25bb36edf = self._ea2adbd5a589['criterion'](_2c295c3d02e7, _8c8b424d1b57)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _7843843c80d2 = _ed06ba440b13._4870838d4ec9(_7843843c80d2, _4ec6cedda414=0.0, _cb2296472d7c=0.0, _fb7059060dbd=0.0)
        _e11908c37ef4 = _ed06ba440b13._4870838d4ec9(_e11908c37ef4, _4ec6cedda414=0.0, _cb2296472d7c=0.0, _fb7059060dbd=0.0)
        _12e25bb36edf = _ed06ba440b13._4870838d4ec9(_12e25bb36edf, _4ec6cedda414=0.0, _cb2296472d7c=0.0, _fb7059060dbd=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _4c8ee9fa2ff3 = self._791382ba0db3(_12e25bb36edf, _7843843c80d2, _e11908c37ef4)
        _b280b43f8f05 = _4c8ee9fa2ff3["aux_term"]
        _26da2778d97e = _12e25bb36edf + _b280b43f8f05

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _bd7ac02d1245 = {
            "val_kl_loss": _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("kl_loss", _7843843c80d2)._8cc9238e943a()._3b32da078ba3()._6f44dc85b6ca()) if _92eb914fd7d5(_4c8ee9fa2ff3._4d0fa508a7d7("kl_loss", _7843843c80d2), _ed06ba440b13._c9806991465a) else _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("kl_loss", _7843843c80d2)),
            "val_contrastive_loss": _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("contrastive_loss", _e11908c37ef4)._8cc9238e943a()._3b32da078ba3()._6f44dc85b6ca()) if _92eb914fd7d5(_4c8ee9fa2ff3._4d0fa508a7d7("contrastive_loss", _e11908c37ef4), _ed06ba440b13._c9806991465a) else _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("contrastive_loss", _e11908c37ef4)),
            "val_classification_loss": _15f66a592264(_12e25bb36edf._8cc9238e943a()._3b32da078ba3()._6f44dc85b6ca()),
            "val_loss": _15f66a592264(_26da2778d97e._8cc9238e943a()._3b32da078ba3()._6f44dc85b6ca()),
        }

        # include effective lambdas and others if provided by aux
        _bd7ac02d1245["val_lambda_kl"] = _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("lambda_kl", _4c8ee9fa2ff3._4d0fa508a7d7("lambda_kl_eff", _15f66a592264(_60336ab9140c(self, "kl_base", 0.30)))))
        _bd7ac02d1245["val_lambda_contrast"] = _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("lambda_cos", _4c8ee9fa2ff3._4d0fa508a7d7("lambda_cos_eff", _15f66a592264(_60336ab9140c(self, "cos_base", 0.25)))))
        _bd7ac02d1245["val_w_mean"] = _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("w_mean", 0.0))
        _bd7ac02d1245["val_aux_scale"] = _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("aux_scale", 0.0))
        _bd7ac02d1245["val_shift_r"] = _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("shift_r", 0.0))
        _bd7ac02d1245["val_teacher_conf_mean"] = _15f66a592264(_4c8ee9fa2ff3._4d0fa508a7d7("teacher_conf_mean", 0.0))

        self._bd7ac02d1245(
            _bd7ac02d1245,
            _342984c3ff1c=_342984c3ff1c,
            _c632ca346114=_eac3a706c388,
            _364a6f5c676a=_69a5589bdece,
            _cc7e9cd945b5=_eac3a706c388,
            _5cb97b0d0c7d=_69a5589bdece,
            _ac8b807742f1=_69a5589bdece,
        )

        # build preds and labels per example (preserve your previous behavior)
        _ad758c8a4a7e = []
        _200a9425ed87 = []
        for _72f6490b37bb in _26f8deabc1ca(_342984c3ff1c):
            _71a073113b96 = _145013ac8c58[_72f6490b37bb]
            _75c60cef8ba7 = _b129ad4d8c11[_72f6490b37bb]
            _fdf99b534a49 = _ed06ba440b13._60dbacbeff71(_71a073113b96, _da3726ce6e59=-1)
            _790c67218b80 = _75c60cef8ba7
            _ad758c8a4a7e._8a8402da8be2(_fdf99b534a49)
            _200a9425ed87._8a8402da8be2(_790c67218b80)

        _f819ffa6368b = {
            "lang_codes": _c897221186e5,
            "preds": _ad758c8a4a7e,
            "labels": _200a9425ed87,
            "sample_ids": _f1b243190c96,
            "chunk_ids": _d8bcd598f61b,
            "word_positions": _34803c6e96cc,
            "val_loss": _26da2778d97e,
            "prompt_lens": _e3aa00adedd2,
            "num_chunks": _926985883e0a,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._7570568cbcfe._8a8402da8be2(_f819ffa6368b)

        # explicit frees (same as you had)
        del _e1221197618e, _b129ad4d8c11, _145013ac8c58, _2c295c3d02e7, _8c8b424d1b57, _977b4f562ac8, _8277d7a0ca89
        del _7843843c80d2, _e11908c37ef4, _12e25bb36edf, _ad758c8a4a7e, _200a9425ed87

        return _f819ffa6368b


    def _ec2ca426ef7b(self, _47bca12267d0, _f76a5562446f, _d3a744837202=_113276a30cc5):
        _5f538a3e7a07 = os._e9617501106f()
        _b874326a2eff = f"trial_{_d3a744837202}" if _d3a744837202 is not _113276a30cc5 else "default"
        _96ae604a02f1(f"[DEBUG rank={_ed06ba440b13._f0113d6f4f67._30101343e5e2() if _ed06ba440b13._f0113d6f4f67._2cc3a045c2a3() else 0}] metrics_dict confusion_matrix sum={_0b139bc189a2(_0b139bc189a2(_aa54df52f2c1) for _aa54df52f2c1 in _47bca12267d0['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _87577b42305d = os._9520ae017d1d._c5cde9b2be77(_5f538a3e7a07, "metrics", self._4f3e4a8bfaa0,  _b874326a2eff)
        os._6695dbcd5831(_87577b42305d, _8cd651e27530=_69a5589bdece)
        _c11015acc264 = os._9520ae017d1d._c5cde9b2be77(_87577b42305d, _f76a5562446f)
        _cf81fdd225f1 = _118b7429dbad._dd954ec03c36(_47bca12267d0)
        _cf81fdd225f1._340463186d29(_c11015acc264, _13cabf232212=_eac3a706c388)
        _96ae604a02f1(f"[metrics] Saved {_c11015acc264}")

    def _1f7870e04334(self):
        # pick correct device for this rank
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            if _ed06ba440b13._f0113d6f4f67._2cc3a045c2a3():
                _dd4eb3c1e5af = _ed06ba440b13._f0113d6f4f67._30101343e5e2()
            else:
                _dd4eb3c1e5af = 0
            _ed06ba440b13._c1f0b98ba506._830ad5be8816(_dd4eb3c1e5af)
            self._0b97b2e50d4a = _ed06ba440b13._58799d728214(f"cuda:{_dd4eb3c1e5af}")
        else:
            self._0b97b2e50d4a = _ed06ba440b13._58799d728214("cpu")

        self._994191ab03f4()

    def _5e4296e71277(self):
        _145013ac8c58 = _60336ab9140c(self, "_validation_outputs", _113276a30cc5)
        if not _145013ac8c58:
            return

        _0302849ea416, _9f441e490adb, _a6aa8938cfae, _e6420911451b = \
            self._aa5db33cf700(_145013ac8c58)

        _6677deb48119, _ea245ef0018a = [], []
        for _837abd42561f in _316508a728e1(_a6aa8938cfae._fd8e75d6b704()):
            _37dd4f6abfa7 = _0302849ea416[_837abd42561f]._3125435edba7()
            _26e77a3aa401 = _9f441e490adb[_837abd42561f]._3125435edba7()
            _090f5295a587 = _a6aa8938cfae[_837abd42561f]
            _18d817886c1a = _e6420911451b[_837abd42561f]
            if _090f5295a587._61efe8b00a0e() > 0 and _18d817886c1a._61efe8b00a0e() > 0:
                _6677deb48119._8a8402da8be2(_090f5295a587)
                _ea245ef0018a._8a8402da8be2(_18d817886c1a)

        if not _6677deb48119:
            _96ae604a02f1("[VAL END] Nothing to score.")
            self._7570568cbcfe._3ebb50c5c436()
            return

        _36da04f94877 = _ed06ba440b13._7248026f7300(_6677deb48119)._96e5486de770(_58799d728214=self._cf8839832799['micro_accuracy']._58799d728214, _a0265a7063ce=_69a5589bdece)
        _b129ad4d8c11 = _ed06ba440b13._7248026f7300(_ea245ef0018a)._96e5486de770(_58799d728214=self._cf8839832799['micro_accuracy']._58799d728214, _a0265a7063ce=_69a5589bdece)

        self._cf8839832799['micro_accuracy']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_accuracy']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_precision']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_recall']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_f1']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_accuracy']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_precision']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_recall']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_f1']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['confmat']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)

        _d440c91897a9  = self._cf8839832799['micro_accuracy']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _3cbf838ce6f4  = self._cf8839832799['macro_accuracy']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _93b1f49d4252 = self._cf8839832799['macro_precision']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _c6d808d565b3    = self._cf8839832799['macro_recall']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _0559e99c54fa        = self._cf8839832799['macro_f1']._7f2d9ef7ffc0()._6f44dc85b6ca()

        self._93a4a4eb2247("val_accuracy", _3cbf838ce6f4, _ac8b807742f1=_69a5589bdece)

        try:
            _673115404b63 = self._ebe8b1500d7d
            _47bca12267d0 = {
                "epoch": [_673115404b63],
                "class_names": [self._a830c5295b38],
                "micro_accuracy": [_d440c91897a9],
                "macro_accuracy": [_3cbf838ce6f4],
                "macro_precision": [_93b1f49d4252],
                "macro_recall": [_c6d808d565b3],
                "macro_f1": [_0559e99c54fa],
                "classwise_accuracy": [self._cf8839832799['classwise_accuracy']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "classwise_precision": [self._cf8839832799['classwise_precision']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "classwise_recall": [self._cf8839832799['classwise_recall']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "classwise_f1": [self._cf8839832799['classwise_f1']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "confusion_matrix": [self._cf8839832799['confmat']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
            }
            self._3305bf894259(_47bca12267d0, f"val_epoch_{_673115404b63}.csv", _d3a744837202=self._d3a744837202)
        except _90a8944bba14 as _c2e05cb2ac82:
            _96ae604a02f1(f"[VAL END] save metrics FAILED: {_c2e05cb2ac82}")

        # cleanup
        self._cf8839832799['micro_accuracy']._e84ad5fd56ec(); self._cf8839832799['macro_accuracy']._e84ad5fd56ec()
        self._cf8839832799['macro_precision']._e84ad5fd56ec(); self._cf8839832799['macro_recall']._e84ad5fd56ec(); self._cf8839832799['macro_f1']._e84ad5fd56ec()
        self._cf8839832799['classwise_accuracy']._e84ad5fd56ec(); self._cf8839832799['classwise_precision']._e84ad5fd56ec()
        self._cf8839832799['classwise_recall']._e84ad5fd56ec(); self._cf8839832799['classwise_f1']._e84ad5fd56ec()
        self._cf8839832799['confmat']._e84ad5fd56ec(); self._7570568cbcfe._3ebb50c5c436()
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            _ed06ba440b13._c1f0b98ba506._5a53f7d7d868()
        _96ae604a02f1("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_ed06ba440b13._30e9946445a2()
    def _53583481f225(self, _e1221197618e: _ed06ba440b13._c9806991465a, **_59d37876f87b):
        _59d37876f87b._c6420489ea2b("pad_token_id", _113276a30cc5)
        _59d37876f87b._c6420489ea2b("attention_mask", _113276a30cc5)
        return self._b4eedb5ba958._08f25da098ab(
            _e1221197618e=_e1221197618e,
            _32c3728b73f2=(_e1221197618e != self._9417a84002ca._c4d485c982ed),
            _c4d485c982ed=self._9417a84002ca._c4d485c982ed,
            _c0f3fb5122d6=self._9417a84002ca._c0f3fb5122d6,
            **_59d37876f87b
        )

    def _76c390b15ba5(self, _3a1079ad3a41, _7b23ab12aa64):
        _e1221197618e = _3a1079ad3a41["input_ids"]._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)
        _b129ad4d8c11    = _3a1079ad3a41["labels"]._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)
        _c897221186e5     = _3a1079ad3a41._4d0fa508a7d7("lang_codes", _113276a30cc5)
        _f1b243190c96     = _3a1079ad3a41._4d0fa508a7d7("sample_ids", _113276a30cc5)
        _d8bcd598f61b      = _3a1079ad3a41._4d0fa508a7d7("chunk_ids", _113276a30cc5)
        _34803c6e96cc = _3a1079ad3a41._4d0fa508a7d7("word_positions", _113276a30cc5)
        _e3aa00adedd2    = _3a1079ad3a41._4d0fa508a7d7("prompt_lens", _113276a30cc5)
        _926985883e0a = _3a1079ad3a41._4d0fa508a7d7("num_chunks", _113276a30cc5)

        _342984c3ff1c = _e1221197618e._6de79e5b1838(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _b9935c1bbdad = self._08f25da098ab(
            _e1221197618e,
            _ef3e441ae4b3=32,
            _866104d87b61=_eac3a706c388,
            _ef28ed6662ff=_113276a30cc5,     # for deterministic answers
            _6eac2aa6b457=_113276a30cc5,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _ad758c8a4a7e = []
        _200a9425ed87 = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _72f6490b37bb in _26f8deabc1ca(_342984c3ff1c):
            _ad758c8a4a7e._8a8402da8be2(_b9935c1bbdad[_72f6490b37bb])   # FULL sequence
            _200a9425ed87._8a8402da8be2(_b129ad4d8c11[_72f6490b37bb])          # FULL labels


        _f819ffa6368b = {
            "lang_codes": _c897221186e5,
            "preds": _ad758c8a4a7e,
            "labels": _200a9425ed87,
            "sample_ids": _f1b243190c96,
            "chunk_ids": _d8bcd598f61b,
            "word_positions": _34803c6e96cc,
            "prompt_lens": _e3aa00adedd2,
            "num_chunks": _926985883e0a,
        }

        self._decbb6c77f35._8a8402da8be2(_f819ffa6368b)

        # Exact same cleanup as before
        del _e1221197618e, _b129ad4d8c11, _b9935c1bbdad, _ad758c8a4a7e, _200a9425ed87

        return _f819ffa6368b

    def _e94b10901348(self):
        # pick correct device for this rank
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            if _ed06ba440b13._f0113d6f4f67._2cc3a045c2a3():
                _dd4eb3c1e5af = _ed06ba440b13._f0113d6f4f67._30101343e5e2()
            else:
                _dd4eb3c1e5af = 0
            _ed06ba440b13._c1f0b98ba506._830ad5be8816(_dd4eb3c1e5af)
            self._0b97b2e50d4a = _ed06ba440b13._58799d728214(f"cuda:{_dd4eb3c1e5af}")
        else:
            self._0b97b2e50d4a = _ed06ba440b13._58799d728214("cpu")

        self._994191ab03f4()
        
    def _c9be8c7c00a5(self):
        _145013ac8c58 = _60336ab9140c(self, "_test_outputs", _113276a30cc5)
        _96ae604a02f1(f"[DEBUG rank={_ed06ba440b13._f0113d6f4f67._30101343e5e2()}] outputs_len={_1ab0a988fa37(_145013ac8c58)}")
        if not _145013ac8c58:
            return

        _0302849ea416, _9f441e490adb, _a6aa8938cfae, _e6420911451b = \
            self._aa5db33cf700(_145013ac8c58)

        _6677deb48119, _ea245ef0018a = [], []
        for _837abd42561f in _316508a728e1(_a6aa8938cfae._fd8e75d6b704()):
            _37dd4f6abfa7 = _0302849ea416[_837abd42561f]._3125435edba7()
            _26e77a3aa401 = _9f441e490adb[_837abd42561f]._3125435edba7()
            _090f5295a587 = _a6aa8938cfae[_837abd42561f]
            _18d817886c1a = _e6420911451b[_837abd42561f]

            if _090f5295a587._61efe8b00a0e() > 0 and _18d817886c1a._61efe8b00a0e() > 0:
                _6677deb48119._8a8402da8be2(_090f5295a587)
                _ea245ef0018a._8a8402da8be2(_18d817886c1a)

        if not _6677deb48119:
            _96ae604a02f1("[TEST END] Nothing to score.")
            self._7570568cbcfe._3ebb50c5c436()
            return

        _36da04f94877 = _ed06ba440b13._7248026f7300(_6677deb48119)._96e5486de770(_58799d728214=self._cf8839832799['micro_accuracy']._58799d728214, _a0265a7063ce=_69a5589bdece)
        _b129ad4d8c11 = _ed06ba440b13._7248026f7300(_ea245ef0018a)._96e5486de770(_58799d728214=self._cf8839832799['micro_accuracy']._58799d728214, _a0265a7063ce=_69a5589bdece)

        self._cf8839832799['micro_accuracy']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_accuracy']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_precision']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_recall']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['macro_f1']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_accuracy']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_precision']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_recall']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['classwise_f1']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)
        self._cf8839832799['confmat']._6ee19fdd9230(_36da04f94877, _b129ad4d8c11)

        _d440c91897a9  = self._cf8839832799['micro_accuracy']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _3cbf838ce6f4  = self._cf8839832799['macro_accuracy']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _93b1f49d4252 = self._cf8839832799['macro_precision']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _c6d808d565b3    = self._cf8839832799['macro_recall']._7f2d9ef7ffc0()._6f44dc85b6ca()
        _0559e99c54fa        = self._cf8839832799['macro_f1']._7f2d9ef7ffc0()._6f44dc85b6ca()

        self._93a4a4eb2247("test_accuracy", _3cbf838ce6f4, _ac8b807742f1=_69a5589bdece)

        try:
            _673115404b63 = self._ebe8b1500d7d
            _47bca12267d0 = {
                "epoch": [_673115404b63],
                "class_names": [self._a830c5295b38],
                "micro_accuracy": [_d440c91897a9],
                "macro_accuracy": [_3cbf838ce6f4],
                "macro_precision": [_93b1f49d4252],
                "macro_recall": [_c6d808d565b3],
                "macro_f1": [_0559e99c54fa],
                "classwise_accuracy": [self._cf8839832799['classwise_accuracy']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "classwise_precision": [self._cf8839832799['classwise_precision']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "classwise_recall": [self._cf8839832799['classwise_recall']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "classwise_f1": [self._cf8839832799['classwise_f1']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
                "confusion_matrix": [self._cf8839832799['confmat']._7f2d9ef7ffc0()._96e5486de770(_58799d728214="cpu")._6ec88c1bdb73()._3125435edba7()],
            }
            self._3305bf894259(_47bca12267d0, f"test_final.csv", _d3a744837202=self._d3a744837202)
        except _90a8944bba14 as _c2e05cb2ac82:
            _96ae604a02f1(f"[TEST END] save metrics FAILED: {_c2e05cb2ac82}")

        # cleanup
        self._cf8839832799['micro_accuracy']._e84ad5fd56ec(); self._cf8839832799['macro_accuracy']._e84ad5fd56ec()
        self._cf8839832799['macro_precision']._e84ad5fd56ec(); self._cf8839832799['macro_recall']._e84ad5fd56ec(); self._cf8839832799['macro_f1']._e84ad5fd56ec()
        self._cf8839832799['classwise_accuracy']._e84ad5fd56ec(); self._cf8839832799['classwise_precision']._e84ad5fd56ec()
        self._cf8839832799['classwise_recall']._e84ad5fd56ec(); self._cf8839832799['classwise_f1']._e84ad5fd56ec()
        self._cf8839832799['confmat']._e84ad5fd56ec(); self._7570568cbcfe._3ebb50c5c436()
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            _ed06ba440b13._c1f0b98ba506._5a53f7d7d868()
        _96ae604a02f1("[TEST END] Finished and cleaned up.")

    def _b43c4e86105f(self, _3a1079ad3a41, _7b23ab12aa64, _cb2c549de70c=0):
        """Optimized prediction step with efficient memory handling."""
        _e1221197618e, _ = _3a1079ad3a41
        _e1221197618e = _e1221197618e._96e5486de770(self._0b97b2e50d4a, _a0265a7063ce=_69a5589bdece)
        _145013ac8c58, _, _ = self(_e1221197618e)
        _10cf506b2039 = _ed06ba440b13._60dbacbeff71(_145013ac8c58, _da3726ce6e59=-1)
        del _e1221197618e, _145013ac8c58
        if _ed06ba440b13._c1f0b98ba506._9397e3159d0e():
            _ed06ba440b13._c1f0b98ba506._5a53f7d7d868()
        return {"predictions": _10cf506b2039._3b32da078ba3()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _f48dad584994(self, _145013ac8c58, _be3d5db6fbb1=_69a5589bdece, _dda2d64958e1="cpu"):
        from collections import _e52da7327325, _cd74fbeea8bc
        import _ed06ba440b13
        _423e5c946c22 = self._5a48325534be
        def _49cb19f66023(_58dba181f9d9):
            if _92eb914fd7d5(_58dba181f9d9, _ed06ba440b13._c9806991465a): return _58dba181f9d9._8cc9238e943a()._96e5486de770(_58799d728214=_dda2d64958e1, _a0265a7063ce=_69a5589bdece)._b803429347e0(-1)._3125435edba7()
            return _e4335c604f7a(_58dba181f9d9) if _92eb914fd7d5(_58dba181f9d9, (_e4335c604f7a, _290c47242672)) else [_58dba181f9d9]
        
        _55415288a7b5 = _f9307c134dcc()
        _0302849ea416, _9f441e490adb, _3587406f292e = {}, {}, []
        if _be3d5db6fbb1:
            _96ae604a02f1(f"[reconcile] start: num_outputs={_1ab0a988fa37(_145013ac8c58)}")
        
        _472de0fbc676 = _e52da7327325(_e4335c604f7a)
        
        for _f6c7f6bbc519 in _145013ac8c58:
            _f1b243190c96     = _f6c7f6bbc519["sample_ids"]
            _d8bcd598f61b      = _f6c7f6bbc519["chunk_ids"]
            _b29dca6a3349    = _f6c7f6bbc519["preds"]
            _26ccfe7ade19   = _f6c7f6bbc519["labels"]
            _34803c6e96cc = _f6c7f6bbc519["word_positions"]
            _e3aa00adedd2    = _f6c7f6bbc519["prompt_lens"]

            for _72f6490b37bb, _837abd42561f in _dd0044aa256f(_f1b243190c96):
                _1f9a4cad51e4 = _52b322a31dc3(_d8bcd598f61b[_72f6490b37bb])
                if (_837abd42561f, _1f9a4cad51e4) in _55415288a7b5:
                    continue
                _55415288a7b5._7c4578b30e10((_837abd42561f, _1f9a4cad51e4))

                _d424813720c0 = _52b322a31dc3(_e3aa00adedd2[_72f6490b37bb])
                _378167880193  = _8968c5e091ed(_34803c6e96cc[_72f6490b37bb])
                _3d37d87c4496    = _8968c5e091ed(_b29dca6a3349[_72f6490b37bb])
                _00aa86b0ec9a   = _8968c5e091ed(_26ccfe7ade19[_72f6490b37bb])

                _7e91225b4ee5  = [_8ef5c468c735 for _8ef5c468c735 in _3d37d87c4496[_d424813720c0:] if _8ef5c468c735 != _423e5c946c22]
                _b02ddc233425 = [_20d8fa501d65 for _20d8fa501d65 in _00aa86b0ec9a[_d424813720c0:] if _20d8fa501d65 != _423e5c946c22]

                if _837abd42561f not in _3587406f292e:
                    _3587406f292e._8a8402da8be2(_837abd42561f)

                _472de0fbc676[_837abd42561f]._8a8402da8be2((_1f9a4cad51e4, _378167880193, _7e91225b4ee5, _b02ddc233425))
        
        _be51ba4aa121 = _113276a30cc5
        for _837abd42561f in _3587406f292e:
            _cbf623708d2f = _472de0fbc676[_837abd42561f]
            _cbf623708d2f._9c6911fbb76e(_04220bab1ec7=lambda _58dba181f9d9: _58dba181f9d9[0])
            if _be51ba4aa121 is _113276a30cc5 and _1ab0a988fa37(_cbf623708d2f) > 1:
                _be51ba4aa121 = _837abd42561f
            
            _252b06ac4ed5 = _e52da7327325(_e4335c604f7a)
            _ef6aa938eaa7    = _e52da7327325(_e4335c604f7a)
            _7ef473158866 = _e52da7327325(_e4335c604f7a)
            _430e4f041d2f    = _e52da7327325(_e4335c604f7a)
            
            _9f782b6a1e73 = _f9307c134dcc()
            for _, _0369a84a52f7, _, _ in _cbf623708d2f:
                for _86aa22f0d298 in _0369a84a52f7:
                    if _86aa22f0d298 >= 0:
                        _9f782b6a1e73._7c4578b30e10(_86aa22f0d298)
            
            if not _9f782b6a1e73:
                continue
            
            _5dfd698f8913 = _316508a728e1(_9f782b6a1e73)
            _1b60bb3e18ec = _dbb3ecd84bb1(_5dfd698f8913)
            
            for _1f9a4cad51e4, _0369a84a52f7, _36da04f94877, _b129ad4d8c11 in _cbf623708d2f:
                _a2f42d9bf574 = _113276a30cc5
                _d6021e329d23 = []
                _5721418a7a2c = []
                for _1f38d971f2ea, _216dca8141c1, _6037d4aad36a in _b53efeffaf5f(_0369a84a52f7, _36da04f94877, _b129ad4d8c11):
                    _b33aed863fb9 = _52b322a31dc3(_1f38d971f2ea)
                    if _b33aed863fb9 >= 0:
                        if _b33aed863fb9 != _a2f42d9bf574:
                            if _a2f42d9bf574 is not _113276a30cc5:
                                _252b06ac4ed5[_a2f42d9bf574]._8a8402da8be2(_d6021e329d23[:])
                                _7ef473158866[_a2f42d9bf574]._8a8402da8be2(_5721418a7a2c[:])
                            _a2f42d9bf574 = _b33aed863fb9
                            _d6021e329d23 = [_52b322a31dc3(_216dca8141c1)]
                            _5721418a7a2c = [_52b322a31dc3(_6037d4aad36a)]
                        else:
                            _d6021e329d23._8a8402da8be2(_52b322a31dc3(_216dca8141c1))
                            _5721418a7a2c._8a8402da8be2(_52b322a31dc3(_6037d4aad36a))
                    else:
                        if _a2f42d9bf574 is not _113276a30cc5:
                            _ef6aa938eaa7[_a2f42d9bf574]._8a8402da8be2(_52b322a31dc3(_216dca8141c1))
                            _430e4f041d2f[_a2f42d9bf574]._8a8402da8be2(_52b322a31dc3(_6037d4aad36a))
                if _a2f42d9bf574 is not _113276a30cc5:
                    _252b06ac4ed5[_a2f42d9bf574]._8a8402da8be2(_d6021e329d23[:])
                    _7ef473158866[_a2f42d9bf574]._8a8402da8be2(_5721418a7a2c[:])
            
            _7a0acc48b169 = []
            _2fb943d29d5e = []
            _daf247c2c31f = _a4936d02256b(_b3770ee27f58[0] for _b3770ee27f58 in self._930226db833f if self._930226db833f[_b3770ee27f58] == 0)
            _5c14ce34c1bf = self._393e984e2ee6
            
            for _bbd6d032f1bf in _5dfd698f8913:
                _84eea7a2f627 = _252b06ac4ed5._4d0fa508a7d7(_bbd6d032f1bf, [])
                _0d700ab3bcb7 = _7ef473158866._4d0fa508a7d7(_bbd6d032f1bf, [])
                
                _f3e748ac3780 = _dbb3ecd84bb1((_1ab0a988fa37(_e1103417c9cf) for _e1103417c9cf in _84eea7a2f627 + _0d700ab3bcb7), _32b30253b1ba=0)
                
                if _f3e748ac3780 == 0:
                    continue
                
                _18d7a302ff78 = []
                for _2e653e23eb52 in _26f8deabc1ca(_f3e748ac3780):
                    _6830b5d02d28 = [_e1103417c9cf[_2e653e23eb52] for _e1103417c9cf in _84eea7a2f627 if _2e653e23eb52 < _1ab0a988fa37(_e1103417c9cf)]
                    _6830b5d02d28 = [_a8d192563e2e for _a8d192563e2e in _6830b5d02d28 if _a8d192563e2e != _423e5c946c22]
                    _c7e5a7f624f8 = _cd74fbeea8bc(_6830b5d02d28)._33d46e73393d(1)[0][0] if _6830b5d02d28 else _daf247c2c31f
                    _18d7a302ff78._8a8402da8be2(_c7e5a7f624f8)
                _7a0acc48b169._bc0cbc332646(_18d7a302ff78)
                
                _3f6e7c9f0c70 = []
                for _2e653e23eb52 in _26f8deabc1ca(_f3e748ac3780):
                    _6830b5d02d28 = [_e1103417c9cf[_2e653e23eb52] for _e1103417c9cf in _0d700ab3bcb7 if _2e653e23eb52 < _1ab0a988fa37(_e1103417c9cf)]
                    _6830b5d02d28 = [_a8d192563e2e for _a8d192563e2e in _6830b5d02d28 if _a8d192563e2e != _423e5c946c22]
                    _c7e5a7f624f8 = _cd74fbeea8bc(_6830b5d02d28)._33d46e73393d(1)[0][0] if _6830b5d02d28 else _423e5c946c22
                    _3f6e7c9f0c70._8a8402da8be2(_c7e5a7f624f8)
                _2fb943d29d5e._bc0cbc332646(_3f6e7c9f0c70)
                
                if _bbd6d032f1bf < _1b60bb3e18ec:
                    _8d3c3ccc08b2 = [_a8d192563e2e for _a8d192563e2e in _ef6aa938eaa7._4d0fa508a7d7(_bbd6d032f1bf, []) if _a8d192563e2e != _423e5c946c22]
                    _39b513c73217 = _cd74fbeea8bc(_8d3c3ccc08b2)._33d46e73393d(1)[0][0] if _8d3c3ccc08b2 else _5c14ce34c1bf
                    _7a0acc48b169._8a8402da8be2(_39b513c73217)
                    
                    _314788204ed5 = [_a8d192563e2e for _a8d192563e2e in _430e4f041d2f._4d0fa508a7d7(_bbd6d032f1bf, []) if _a8d192563e2e != _423e5c946c22]
                    _a7e276af5f3a = _cd74fbeea8bc(_314788204ed5)._33d46e73393d(1)[0][0] if _314788204ed5 else _5c14ce34c1bf
                    _2fb943d29d5e._8a8402da8be2(_a7e276af5f3a)
            
            if _1ab0a988fa37(_7a0acc48b169) > _1ab0a988fa37(_2fb943d29d5e):
                _7a0acc48b169 = _7a0acc48b169[:_1ab0a988fa37(_2fb943d29d5e)]
            elif _1ab0a988fa37(_7a0acc48b169) < _1ab0a988fa37(_2fb943d29d5e):
                _7a0acc48b169 += [_daf247c2c31f] * (_1ab0a988fa37(_2fb943d29d5e) - _1ab0a988fa37(_7a0acc48b169))
            
            _0302849ea416[_837abd42561f] = _ed06ba440b13._95f6e06ab8fd(_7a0acc48b169, _58799d728214=_dda2d64958e1)
            _9f441e490adb[_837abd42561f] = _ed06ba440b13._95f6e06ab8fd(_2fb943d29d5e, _58799d728214=_dda2d64958e1)

        if _be3d5db6fbb1 and _be51ba4aa121 is not _113276a30cc5:
            _96ae604a02f1(f"[SUMMARY] reconciled samples in batch = {_1ab0a988fa37(_3587406f292e)} \
                sid={_be51ba4aa121} total_preds={_1ab0a988fa37(_0302849ea416[_be51ba4aa121])} total_labels={_1ab0a988fa37(_9f441e490adb[_be51ba4aa121])} \
                    raw_preds {_0302849ea416[_be51ba4aa121]} and raw_labels{_9f441e490adb[_be51ba4aa121]}\
                        chunks {_472de0fbc676[_be51ba4aa121]}")

        _39947abb1767 = _0b139bc189a2(_1ab0a988fa37(_20d8fa501d65) for _20d8fa501d65 in _9f441e490adb._1cac41e9bc26())
        _96ae604a02f1(f"Total reconciled labels: {_39947abb1767}")
        _e4fd39f94bad, _351fb51ab193 = self._302ab19a10dd(_0302849ea416, _9f441e490adb, _be3d5db6fbb1=_be3d5db6fbb1, _dda2d64958e1=_dda2d64958e1)
        _a927b1d70bdc = _0b139bc189a2(_1ab0a988fa37(_20d8fa501d65) for _20d8fa501d65 in _351fb51ab193._1cac41e9bc26())
        _96ae604a02f1(f"Total reconciled labels classes: {_a927b1d70bdc}")
        return _0302849ea416, _9f441e490adb, _e4fd39f94bad, _351fb51ab193

    def _8eaec6ccb07c(self, _0302849ea416, _9f441e490adb, _be3d5db6fbb1=_69a5589bdece, _dda2d64958e1="cpu"):
        _930226db833f = _60336ab9140c(self, "seq2class", {})
        _5bef30fc99fc = _60336ab9140c(self, "tokenizer_separator_token", _113276a30cc5)
        _423e5c946c22 = _60336ab9140c(self, "ignore_idx", -100)
        
        def _e5eacc1a01c8(_4b4bad177e04, _80a22ae013a0):
            _2b6f4f282594 = []
            _a2f42d9bf574 = []
            for _72f6490b37bb, token in _dd0044aa256f(_4b4bad177e04):
                if token == _80a22ae013a0 and _a2f42d9bf574:
                    _2b6f4f282594._8a8402da8be2(_a2f42d9bf574)
                    _a2f42d9bf574 = []
                elif token != _80a22ae013a0:
                    _a2f42d9bf574._8a8402da8be2(token)
            if _a2f42d9bf574:
                _2b6f4f282594._8a8402da8be2(_a2f42d9bf574)
            return _2b6f4f282594
        
        def _b9d84dce6516(_4e2f7bdcfdf0, _930226db833f, _be3d5db6fbb1, _837abd42561f):
            _f6c7f6bbc519 = []
            _455ab2ef0b36 = _316508a728e1(_930226db833f._fd8e75d6b704(), _04220bab1ec7=_1ab0a988fa37, _98e31b562fad=_69a5589bdece)
            for _72f6490b37bb, _040fe9ac1bf9 in _dd0044aa256f(_4e2f7bdcfdf0, 1):
                _54659c504988 = _290c47242672(_040fe9ac1bf9)
                _079e6b9f346b = self._45270ecb2b32
                for _04220bab1ec7 in _455ab2ef0b36:
                    if _1ab0a988fa37(_54659c504988) >= _1ab0a988fa37(_04220bab1ec7) and _54659c504988[:_1ab0a988fa37(_04220bab1ec7)] == _04220bab1ec7:
                        _079e6b9f346b = _930226db833f[_04220bab1ec7]
                        break
                _f6c7f6bbc519._8a8402da8be2(_079e6b9f346b)

            return _f6c7f6bbc519
        
        _a6aa8938cfae, _e6420911451b = {}, {}
        for _837abd42561f in _0302849ea416:
            _8ef5c468c735 = _0302849ea416[_837abd42561f]
            _20d8fa501d65 = _9f441e490adb._4d0fa508a7d7(_837abd42561f, _113276a30cc5)
            _36da04f94877 = _8ef5c468c735._3125435edba7() if _92eb914fd7d5(_8ef5c468c735, _ed06ba440b13._c9806991465a) else _e4335c604f7a(_8ef5c468c735)
            _b129ad4d8c11 = _20d8fa501d65._3125435edba7() if _92eb914fd7d5(_20d8fa501d65, _ed06ba440b13._c9806991465a) else _e4335c604f7a(_20d8fa501d65) if _20d8fa501d65 else _113276a30cc5
            if _b129ad4d8c11 is not _113276a30cc5:
                _fda20c81206d = _c416ef7baf51(_b129ad4d8c11, _5bef30fc99fc)
                _58a73216b135 = _f9ed02b1621a(_fda20c81206d, _930226db833f, _837abd42561f == 1 or _be3d5db6fbb1, _837abd42561f)
                _7036c9e6683d = _c416ef7baf51(_36da04f94877, _5bef30fc99fc)
                _0884bff91e61 = _f9ed02b1621a(_7036c9e6683d, _930226db833f, _837abd42561f == 1 or _be3d5db6fbb1, _837abd42561f)
                if _1ab0a988fa37(_0884bff91e61) < _1ab0a988fa37(_58a73216b135):
                    _0884bff91e61 += [0] * (_1ab0a988fa37(_58a73216b135) - _1ab0a988fa37(_0884bff91e61))
                elif _1ab0a988fa37(_0884bff91e61) > _1ab0a988fa37(_58a73216b135):
                    _0884bff91e61 = _0884bff91e61[:_1ab0a988fa37(_58a73216b135)]
            else:
                _7036c9e6683d = _c416ef7baf51(_36da04f94877, _5bef30fc99fc)
                _0884bff91e61 = _f9ed02b1621a(_7036c9e6683d, _930226db833f, _837abd42561f == 1 or _be3d5db6fbb1, _837abd42561f)
                _58a73216b135 = [_423e5c946c22] * _1ab0a988fa37(_0884bff91e61)
            _a6aa8938cfae[_837abd42561f] = _ed06ba440b13._95f6e06ab8fd(_0884bff91e61, _58799d728214=_dda2d64958e1, _70791ba74f8a=_ed06ba440b13._7a2d2fed660c)
            _e6420911451b[_837abd42561f] = _ed06ba440b13._95f6e06ab8fd(_58a73216b135, _58799d728214=_dda2d64958e1, _70791ba74f8a=_ed06ba440b13._7a2d2fed660c)
        return _a6aa8938cfae, _e6420911451b

    def _eb0a6ac225ab(self, _5b962ae1a34d):
        _ed06ba440b13._2e69c99d9906._a8087d0a93ad._27858cb6e6b0(self._4f40fcbbe21a(), _8571d0c8cf31=1.0)
    
    def _73ad58de79ae(self, _5b962ae1a34d):
        for _05f218d63ae1 in self._4f40fcbbe21a():
            if _05f218d63ae1 is not _113276a30cc5:
                _05f218d63ae1._04e087708e33._e61bc0041a4a(-5, 5)

    def _19fa2794c401(self):
        _bea872f52edd = 0
        for _05f218d63ae1 in self._4f40fcbbe21a():
            if _05f218d63ae1._c8322a75b8a0 is not _113276a30cc5:
                _65c91dee2cf8 = _05f218d63ae1._c8322a75b8a0._8cc9238e943a()._04e087708e33._b36827837185(2)
                _bea872f52edd += _65c91dee2cf8._6f44dc85b6ca() ** 2
        return _bea872f52edd ** 0.5  # L2 norm

    def _7dd1464a7620(self):
        _4304eb95e792 = [_8ef5c468c735 for _8ef5c468c735 in self._4f40fcbbe21a() if _8ef5c468c735._455d6747738a]
        if not _4304eb95e792:
            _96ae604a02f1("No trainable parameters. Skipping optimizer creation.")
            return _113276a30cc5
        
        _11ca0cfa2aa3 = _bd5621f672b5(lambda _8ef5c468c735: _8ef5c468c735._455d6747738a, self._4f40fcbbe21a())

        _e0b2f33a493d = {
            "adamw": _ed06ba440b13._64c484e1f899._d9d5e34f789d,
            "adamax": _ed06ba440b13._64c484e1f899._7e091a1acf4d,
            "adam": _ed06ba440b13._64c484e1f899._9a767d65407f,
        }
        _660f2c08730f = _e0b2f33a493d._4d0fa508a7d7(self._0f57250d5bf2._de08adac5266(), _ed06ba440b13._64c484e1f899._9a767d65407f)

        _5b962ae1a34d = _660f2c08730f(_11ca0cfa2aa3, _2584f7360855=self._c71fbe36d457._2584f7360855, _81f7646e1150=0.001)

        _d1eb718fb172 = self._a0e688daa87b._7f086ae200ea
        _d8ca15113b20 = math._4754e4dc28ca(0.1 * _d1eb718fb172)

        _070b6cdbc307 = _ed06ba440b13._64c484e1f899._36fe16a7c34d._4d992edfb648(_5b962ae1a34d, _d8a07633898d=lambda _5075da397e1a: (_5075da397e1a + 1) / _d8ca15113b20)

        _b8a9943c1a93 = _ed06ba440b13._64c484e1f899._36fe16a7c34d._343126614dfd(
            _5b962ae1a34d,
            _17b578c11a0b=_dbb3ecd84bb1(1, _d1eb718fb172 - _d8ca15113b20),
            _dbb603266fd3=2,
            _94978c2ce2ba=1e-6
        )
        _36fe16a7c34d = _ed06ba440b13._64c484e1f899._36fe16a7c34d._184cefb175f1(
            _5b962ae1a34d,
            _4bfd75e89291=[_070b6cdbc307, _b8a9943c1a93],
            _db55a4624ae4=[_d8ca15113b20]
        )
        return {"optimizer": _5b962ae1a34d, "lr_scheduler": {"scheduler": _36fe16a7c34d, "interval": "epoch", "monitor": "val_loss"}}
