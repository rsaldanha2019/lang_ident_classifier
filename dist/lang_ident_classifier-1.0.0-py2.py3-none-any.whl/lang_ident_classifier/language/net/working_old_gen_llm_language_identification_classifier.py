# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _459a586f6b23
import copy
from _ad9950db9d76 import _fe2cd2554a5b
import _0285f0b8a0cb
import math
import os
from typing import _f9ed61b3c371
import _4015c538de24 as _0e60073a2781
import _bb16ef1b4092 as _44427ee2d19e
import _93798b6ebff3
import _228f153651d3 as _501a8082fb2f
from _5f09860cc27b._94615b4e3ea3._2bb650d063b8._a93ae6d734be import _1264624981d6
from _cbdc3403fc32 import _e0cba3f12b59, _6744d048e3ee, _617825ea6c69, _2c10410686af, _0bd4a6ccb477

from _3fa66988c9c4._570ec01a65d5._9b6ce900a8a7._3d84b6d7b39a import _9c8ab5b4f2ec
from _3fa66988c9c4._570ec01a65d5._8d116fac9fad._d1b8b2ffa295 import _84eec300709b
from _3fa66988c9c4._570ec01a65d5._8d116fac9fad._43c5001c6dcb import _13ffc1b6dab0
from _3fa66988c9c4._570ec01a65d5._8d116fac9fad._f3ff4c9c14b3 import _1b55ee49585e
from _3fa66988c9c4._570ec01a65d5._9ead87a429d4._417cc721c30c import _fe2740ccfeec
# expose only the classifier from the module
_47f65c6940d6 = ["GenLLMLanguageIdentificationClassifier"]

_9255e491ff77 = 'cuda' if _93798b6ebff3._11cb931ce190._8dbd723b9c79() else 'cpu'
_6fa34245014d = _e75782893652  # global frozen embedding (kept for compatibility)

    
class _64ee415468ab(_501a8082fb2f._c3d6e3dcb476):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _9a424dc3d58a(_93798b6ebff3._fddbd1ba5163._4f25cc5ead35):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _cce870a46381(self, _b3561ed5dbe7: _7534c17e0a07, _9a19373d91b1: _7534c17e0a07 = 64):
            _12ccfeab9cff()._f8932777b0b0()
            self._7d8a41ea24bf = _93798b6ebff3._fddbd1ba5163._0011c31d834e(_b3561ed5dbe7, _9a19373d91b1, _141bfffa76ce=_6ba42ed9e571)
            self._eedcfa5fcb5b = _93798b6ebff3._fddbd1ba5163._e1207a87a092(_c960b7578b0b=_bfaf21e8f1ce)
            self._a96c22a9d9c5 = _93798b6ebff3._fddbd1ba5163._0011c31d834e(_9a19373d91b1, _b3561ed5dbe7, _141bfffa76ce=_6ba42ed9e571)
            # start adapter near-zero so initial behavior is identity
            _93798b6ebff3._fddbd1ba5163._2646182f6463._db3dcb576242(self._a96c22a9d9c5._b46f56654985)
            _93798b6ebff3._fddbd1ba5163._2646182f6463._16803052328b(self._7d8a41ea24bf._b46f56654985, _ff4b4ff38d5f=math._ef19991b90c6(5))

        def _f7bf6d0a7440(self, _4db82363fae7: _93798b6ebff3._2c2f9698b9a1) -> _93798b6ebff3._2c2f9698b9a1:
            # supports x shape (B, L, D) or (B, D)
            if _4db82363fae7._b3561ed5dbe7() == 2:
                _35c9bb096dfb = self._a96c22a9d9c5(self._eedcfa5fcb5b(self._7d8a41ea24bf(_4db82363fae7)))
                return _4db82363fae7 + _35c9bb096dfb
            _6cc84df5e3a3, _16d639108ff1, _c827d7708012 = _4db82363fae7._a945c9cb0469
            _de35861f4935 = _4db82363fae7._dfb048f55998(-1, _c827d7708012)                    # (B*L, D)
            _de35861f4935 = self._a96c22a9d9c5(self._eedcfa5fcb5b(self._7d8a41ea24bf(_de35861f4935)))  # (B*L, D)
            _de35861f4935 = _de35861f4935._dfb048f55998(_6cc84df5e3a3, _16d639108ff1, _c827d7708012)
            return _4db82363fae7 + _de35861f4935
        
    class _22bf6321a866(_93798b6ebff3._fddbd1ba5163._4f25cc5ead35):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _cce870a46381(self, _4266d0425e43, _83b4a3072807=-5, _3d309610f00f=5):
            _12ccfeab9cff()._f8932777b0b0()
            self._4266d0425e43 = _4266d0425e43
            self._83b4a3072807 = _83b4a3072807
            self._3d309610f00f = _3d309610f00f
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _f7bf6d0a7440(self, *_2ca0f1b29e82, **_8a173810a8d9):
            _2ca0f1b29e82 = _2c1658a48f84(
                _cb0eeb7c7802._05b61fc5c72d(_93798b6ebff3._3fc4fdbbacee)._6279acf77fc6(-10, 10) if _cc97f3cd34f6(_cb0eeb7c7802, _93798b6ebff3._2c2f9698b9a1) and _cb0eeb7c7802._89fe9fce5a0e != _93798b6ebff3._3fc4fdbbacee else _cb0eeb7c7802
                for _cb0eeb7c7802 in _2ca0f1b29e82
            )
            for _750d1482b80f, _cb0eeb7c7802 in _340cb0cc7a0a(_2ca0f1b29e82):
                if _cc97f3cd34f6(_cb0eeb7c7802, _93798b6ebff3._2c2f9698b9a1) and not _93798b6ebff3._145790f969d4(_cb0eeb7c7802)._225d9a29db91():
                    _cb0eeb7c7802 = _93798b6ebff3._efadffc3748b(_cb0eeb7c7802)
            _7b25b1d2b198 = self._4266d0425e43(*_2ca0f1b29e82, **_8a173810a8d9)
            if _cc97f3cd34f6(_7b25b1d2b198, _93798b6ebff3._2c2f9698b9a1):
                _7b25b1d2b198 = _7b25b1d2b198._05b61fc5c72d(_93798b6ebff3._3fc4fdbbacee)
                if not _93798b6ebff3._145790f969d4(_7b25b1d2b198)._225d9a29db91():
                    _7b25b1d2b198 = _93798b6ebff3._efadffc3748b(_7b25b1d2b198)
                _7b25b1d2b198._cbac11922085(self._83b4a3072807, self._3d309610f00f)
            return _7b25b1d2b198

    # --- original __init__ signature and body preserved ---
    def _cce870a46381(
        self,
        _aecc5de1f3b2,
        _1e4a78dd72e4,
        _f768cc074088,
        _7ce6c54a06e2,
        _49e96d22d4a7,
        _c03fda4bf1b6,
        _03612b6f0006,
        _15c460176ac6,
        _ad43f68df7e8,
        _a4f5917d1c48,
        _ddfa19ff1a08,
        _d3c7d610719e: _7534c17e0a07 = 20,
        _86153c126ea1 = _e75782893652,
        _3b3472ca4f75=_e75782893652,
        _e9df71df8644=0.9,
        _48a0b1a6c95f:_50caed727acd=_e75782893652,
    ):
        _12ccfeab9cff(_6fba45d9a31b, self)._f8932777b0b0()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._08743eff271b({
            "lr": _7f38e480abd2(_f768cc074088),
            "optimizer": _50caed727acd(_7ce6c54a06e2),
            "num_backbone_model_units_unfrozen": _7534c17e0a07(_03612b6f0006),
            "loss_type": _50caed727acd(_15c460176ac6),
            "is_train": _af59e6857e2d(_ad43f68df7e8),
            "random_seed": _7534c17e0a07(_d3c7d610719e),
        })
        self._d3c7d610719e = _d3c7d610719e
        _501a8082fb2f._007b2a567ae4(_d3c7d610719e, _e47ce334f4ee=_bfaf21e8f1ce)
        _93798b6ebff3._b3153359e746(_d3c7d610719e)
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            _93798b6ebff3._11cb931ce190._429763b3ddab(_d3c7d610719e)
        _0e60073a2781.random._721a5a829db5(_d3c7d610719e)
        self._3b3472ca4f75 = _7534c17e0a07(_3b3472ca4f75) if _3b3472ca4f75 is not _e75782893652 else _e75782893652
        self._a4f5917d1c48 = _a4f5917d1c48
        self._48a0b1a6c95f = _48a0b1a6c95f
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._a4f5917d1c48._9bf964b708b9 and "<PAD>" not in self._a4f5917d1c48._ac1e68edecdb():
            self._a4f5917d1c48._b2eac1a67570(["<PAD>"], _f6c82c7147a8=_6ba42ed9e571)
            _e90850f6b882 = self._a4f5917d1c48._337836b912c2("<PAD>")
            _cfe65d617e09(f"Added padding token  <PAD> with (id: {_e90850f6b882})")
        
        self._b702943f1422 = _a4f5917d1c48._1a7019d73297(" ", _06aca1f7fc82=_6ba42ed9e571)[0]
        self._6db2aff10bdd = (
            _93798b6ebff3._1ab67dadd454("cuda:{}"._5d187dd15a55(_c03fda4bf1b6["gpu_local_rank"]))
            if _c03fda4bf1b6["gpu_local_rank"] != -1
            else "cpu"
        )
        self._86153c126ea1 = _86153c126ea1
        self._e9df71df8644 = _e9df71df8644
        self._1e4a78dd72e4 =  ["unk"] + _1e4a78dd72e4 if self._e9df71df8644 > 0 else _1e4a78dd72e4
        self._5cdedce3b094 = _6fa24e8f3359(self._1e4a78dd72e4)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._5c467e7c4dea = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _faef600669d5 in self._1e4a78dd72e4:
            if _6fa24e8f3359(self._a4f5917d1c48._1a7019d73297(_faef600669d5, _06aca1f7fc82=_6ba42ed9e571)) > 1:
                token = f"{_faef600669d5}"
                if token not in self._a4f5917d1c48._ac1e68edecdb():
                    self._a4f5917d1c48._b2eac1a67570([token], _f6c82c7147a8=_6ba42ed9e571)
                    _e90850f6b882 = self._a4f5917d1c48._337836b912c2(token)
                    _cfe65d617e09(f"Added class '{_faef600669d5}' Token: {token} (id: {_e90850f6b882})")

        # Map every class to single token ID
        self._5c467e7c4dea = {
            _78e26209d6e2: [self._a4f5917d1c48._337836b912c2(f"{_faef600669d5}")]
            for _78e26209d6e2, _faef600669d5 in _340cb0cc7a0a(self._1e4a78dd72e4)
        }

        self._d2f3ff328be7 = {_2c1658a48f84(_a15c1c134769): _388bc6818c75 for _388bc6818c75, _a15c1c134769 in self._5c467e7c4dea._fc97a56f0df8()}
        self._dfb954f5e531 = _459a586f6b23(_16add58a9554)
        for _073c2904a062, _a15c1c134769 in self._5c467e7c4dea._fc97a56f0df8():
            self._dfb954f5e531[_6fa24e8f3359(_a15c1c134769)]._7293a3436d99((_073c2904a062, _a15c1c134769))
        self._529f1a527d0b = 0
        _cfe65d617e09(f"SEQ {self._5c467e7c4dea} and {self._d2f3ff328be7}")
        self._d450ee6242f5 = _a4f5917d1c48._9bf964b708b9 or _a4f5917d1c48._e94689b3f34e
        self._49e96d22d4a7 = _49e96d22d4a7
        self._571999e2dbb6 = "multiclass"
        self._b2a09c79bbff = -100
        self._a791128d8b23 = _a4f5917d1c48._1a7019d73297("assistant<|end_header_id|>\n\n", _06aca1f7fc82=_6ba42ed9e571)
        self._9bae8a0f0464 = self._9c3ff78a6e85()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._0c30d10657bb = _aecc5de1f3b2
        # Resize vocab based token embeddings
        self._0c30d10657bb._9c1902ba6a1e(_6fa24e8f3359(self._a4f5917d1c48))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._0c30d10657bb._1317d325292c(_6ba42ed9e571)
        _d42948a89cc5 = _fe2740ccfeec()  # bfloat16 or float16

        for _0c0dacb4d7e2, _4266d0425e43 in self._70efe7fd8751():
            if not _b0bb22ad2dae(_b9910be6b60a._14b204165982 for _b9910be6b60a in _4266d0425e43._c26928b89f7c(_d2f8dddafc09=_6ba42ed9e571)):
                # FROZEN → BF16 (save memory)
                _4266d0425e43._05b61fc5c72d(_89fe9fce5a0e=_d42948a89cc5)
            else:
                # TRAINABLE → FP32 (stable grads)
                _4266d0425e43._05b61fc5c72d(_89fe9fce5a0e=_93798b6ebff3._3fc4fdbbacee)
        self._0c30d10657bb._05b61fc5c72d(self._6db2aff10bdd)
        if _bd69edefbc17(self._0c30d10657bb, "gradient_checkpointing_enable"):
            self._0c30d10657bb._85b44ab24cf7()
        # determine embedding dim robustly from model config if available
        _fe08e095a7ee = _f16671dec8cc(_f16671dec8cc(self._0c30d10657bb, "config", _e75782893652), "hidden_size", _e75782893652)
        if _fe08e095a7ee is _e75782893652:
            # fallback to common default — change if your model uses a different hidden size
            _fe08e095a7ee = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _bd69edefbc17(self._0c30d10657bb, "lm_head") and _f16671dec8cc(self._0c30d10657bb, "lm_head") is not _e75782893652:
            self._4058ff69efcb = self._0c30d10657bb._bf5c4ee2f8db
        else:
            _2fcb0bb47183 = _f16671dec8cc(self._0c30d10657bb, "get_output_embeddings", _e75782893652)
            self._4058ff69efcb = _2fcb0bb47183() if _0370cec24d1a(_2fcb0bb47183) else _e75782893652

        # mark presence and ensure module (if any) is on the same device
        self._b4c300d1eb90 = self._4058ff69efcb is not _e75782893652
        if self._b4c300d1eb90:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._4058ff69efcb._05b61fc5c72d(self._6db2aff10bdd)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._49dd50e0bfc8 = self._26e70752683c(_b3561ed5dbe7=_fe08e095a7ee, _9a19373d91b1=64)
        self._49dd50e0bfc8._05b61fc5c72d(self._6db2aff10bdd)
        for _b9910be6b60a in self._49dd50e0bfc8._c26928b89f7c():
            _b9910be6b60a._14b204165982 = _bfaf21e8f1ce
            
        if _03612b6f0006 > 0:
            if "llama" in self._86153c126ea1:
                for _f49daefe7d65 in self._0c30d10657bb._c26928b89f7c():
                    if not _f49daefe7d65._5ce54727cc03:
                        _f49daefe7d65 = _f49daefe7d65._a58aae97523e()
                    _f49daefe7d65._14b204165982 = _6ba42ed9e571  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _a4ba37809ac5 = self._0c30d10657bb._51b33da9ed75._b1efd1c5a4e3  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _7ae0f1c3a4f4 in _a4ba37809ac5[-_03612b6f0006:]:
                    for _f49daefe7d65 in _7ae0f1c3a4f4._c26928b89f7c():
                        if _cc97f3cd34f6(_f49daefe7d65, _93798b6ebff3._2c2f9698b9a1) and (_f49daefe7d65._46138ee3c987() or _93798b6ebff3._8ba1914bc714(_f49daefe7d65)):
                            _f49daefe7d65._14b204165982 = _bfaf21e8f1ce
                if _bd69edefbc17(self._0c30d10657bb, "lm_head"):
                    self._0c30d10657bb._bf5c4ee2f8db._14b204165982 = _bfaf21e8f1ce

        self._5f3eb3f29417 = 1
        _cfe65d617e09(f"DEBUG xth_batch init {self._5f3eb3f29417}")
        global _6fa34245014d
        _6fa34245014d = copy._3639bee1da15(self._0c30d10657bb)._e138d96fb61c()
        self._f768cc074088 = _f768cc074088

        self._f058c9c3ab41 = {}
        self._32197bf9f0fb = {}

        # Loss function initialization
        if _15c460176ac6._eeb341ad4aed() == "class_weighted_cross_entropy_loss":
            self._32197bf9f0fb['criterion'] = _13ffc1b6dab0(_49e96d22d4a7=self._49e96d22d4a7,
                                                            _1ab67dadd454=self._6db2aff10bdd,
                                                            _d294ea3eff64=self._b2a09c79bbff,
                                                            _e9a833f91cd4=self._b702943f1422)
        elif _15c460176ac6._eeb341ad4aed() == "focal_loss":
            self._32197bf9f0fb['criterion'] = _1b55ee49585e(_eb011faddd59=0.25,
                                                     _1ab67dadd454=self._6db2aff10bdd,
                                                     _d294ea3eff64=self._b2a09c79bbff,
                                                     _e9a833f91cd4=self._b702943f1422)
        elif _15c460176ac6._eeb341ad4aed() == "class_weighted_focal_loss":
            self._32197bf9f0fb['criterion'] = _1b55ee49585e(_eb011faddd59=self._49e96d22d4a7,
                                                     _1ab67dadd454=self._6db2aff10bdd,
                                                     _d294ea3eff64=self._b2a09c79bbff,
                                                     _e9a833f91cd4=self._b702943f1422)
        elif _15c460176ac6._eeb341ad4aed() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._32197bf9f0fb['criterion'] = _84eec300709b(_eb011faddd59=self._49e96d22d4a7,
                                                                      _2d363f2e08b5='type1',
                                                                      _1ab67dadd454=self._6db2aff10bdd,
                                                                      _d294ea3eff64=self._b2a09c79bbff,
                                                                      _e9a833f91cd4=self._b702943f1422)
        elif _15c460176ac6._eeb341ad4aed() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._32197bf9f0fb['criterion'] = _84eec300709b(_eb011faddd59=self._49e96d22d4a7,
                                                                      _2d363f2e08b5='type2',
                                                                      _1ab67dadd454=self._6db2aff10bdd,
                                                                      _d294ea3eff64=self._b2a09c79bbff,
                                                                      _e9a833f91cd4=self._b702943f1422)
        elif _15c460176ac6._eeb341ad4aed() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._32197bf9f0fb['criterion'] = _84eec300709b(_eb011faddd59=self._49e96d22d4a7,
                                                                      _2d363f2e08b5='type3',
                                                                      _1ab67dadd454=self._6db2aff10bdd,
                                                                      _d294ea3eff64=self._b2a09c79bbff,
                                                                      _e9a833f91cd4=self._b702943f1422)
        else:
            self._32197bf9f0fb['criterion'] = _13ffc1b6dab0(_1ab67dadd454=self._6db2aff10bdd,
                                                            _d294ea3eff64=self._b2a09c79bbff,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._f4cee20669c0 = 0.99
        self._2139fe668296 = 0.3
        self._288b821eb8c7 = 0.30
        self._f10d1bc8a50d = 0.25
        self._037b62a322e5 = 0.6
        self._572df6d85d9d = 0.995
        self._ea37f2830cd1 = 0.60
        self._aa7be39c7023 = 0.20
        self._961b098a28b0 = _f16671dec8cc(self, "batch_counter", 0)


        self._39c403a3c271 = []
        self._94a9e1fd9d90 = []

        self._b3d77507af16 = _7ce6c54a06e2._eeb341ad4aed()
        self._afef092a8940()

        self._c9d073ce17d6(self._0c30d10657bb)
    
    def _175d676e7919(self):
        # rebuild all metrics on the correct device
        self._f058c9c3ab41['micro_accuracy'] = _e0cba3f12b59(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e="micro",
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['macro_accuracy'] = _e0cba3f12b59(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e="macro",
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['macro_precision'] = _617825ea6c69(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e="macro",
            _92b56913efc9=self. _571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['macro_recall'] = _2c10410686af(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e="macro",
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['macro_f1'] = _0bd4a6ccb477(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e="macro",
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['classwise_accuracy'] = _e0cba3f12b59(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e=_e75782893652,
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['classwise_precision'] = _617825ea6c69(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e=_e75782893652,
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['classwise_recall'] = _2c10410686af(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e=_e75782893652,
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['classwise_f1'] = _0bd4a6ccb477(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _2779e3afa26e=_e75782893652,
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)

        self._f058c9c3ab41['confmat'] = _6744d048e3ee(
            _5cdedce3b094=_6fa24e8f3359(self._1e4a78dd72e4),
            _92b56913efc9=self._571999e2dbb6,
            _d294ea3eff64=self._b2a09c79bbff,
        )._05b61fc5c72d(self._6db2aff10bdd)


    def _b224f796c031(self, _1e09dca8c3ef=_e75782893652):
        """Calculate batch counts and set xth_batch_to_consider."""
        _d46aa75da492 = 0
        _2f2b9ac34ff3 = 0
        if self._7d9b2049da39._29a5e5b8953f is not _e75782893652:
            if _bd69edefbc17(self._7d9b2049da39._29a5e5b8953f, 'train_dataset') and self._7d9b2049da39._29a5e5b8953f._6a60022f6e8d is not _e75782893652:
                _d46aa75da492 = _6fa24e8f3359(self._7d9b2049da39._29a5e5b8953f._6a60022f6e8d)
            if _bd69edefbc17(self._7d9b2049da39._29a5e5b8953f, 'val_dataset') and self._7d9b2049da39._29a5e5b8953f._04b2dce0e367 is not _e75782893652:
                _2f2b9ac34ff3 = _6fa24e8f3359(self._7d9b2049da39._29a5e5b8953f._04b2dce0e367)
            _96e77c0a512a = self._7d9b2049da39._29a5e5b8953f._96e77c0a512a
            _13830cdd4f1c = (_d46aa75da492 + _96e77c0a512a - 1) // _96e77c0a512a if _d46aa75da492 > 0 else 1
            _00fa6aaa7fc1 = (_2f2b9ac34ff3 + _96e77c0a512a - 1) // _96e77c0a512a if _2f2b9ac34ff3 > 0 else 1
            _68103312abe3 = _388d6a5f6d6e(_13830cdd4f1c, _00fa6aaa7fc1) if _2f2b9ac34ff3 > 0 else _13830cdd4f1c
            _c9f51698017b = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._5f3eb3f29417 = 1
            _cfe65d617e09(f"DEBUG Batch Info: num_train_batches={_13830cdd4f1c}, num_val_batches={_00fa6aaa7fc1}, xth_batch_to_consider={self._5f3eb3f29417}")

    def _459bd4e3d5cb(self, _6023f5a5675b, _782bf2c3b2da):
        if _6023f5a5675b._eeb341ad4aed() == "parametric_relu":
            return _93798b6ebff3._fddbd1ba5163._e4b3519ea8a2(_782bf2c3b2da=1)
        elif _6023f5a5675b._eeb341ad4aed() == "leaky_relu":
            return _93798b6ebff3._fddbd1ba5163._e302eff974cc(_c960b7578b0b=_6ba42ed9e571)
        else:
            return _93798b6ebff3._fddbd1ba5163._e1207a87a092(_c960b7578b0b=_6ba42ed9e571)

    def _f5566275153a(self, _4266d0425e43, _fe80b9aaec70=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _0c0dacb4d7e2, _7aa50f530b03 in _4266d0425e43._06ec5563f69a():
            _7632fbc2344e = f"{_fe80b9aaec70}.{_0c0dacb4d7e2}" if _fe80b9aaec70 else _0c0dacb4d7e2

            def _ebce4b1de278(_6494161b5f23, _cb0eeb7c7802, _35c9bb096dfb):
                if _cc97f3cd34f6(_35c9bb096dfb, _93798b6ebff3._2c2f9698b9a1) and _35c9bb096dfb._f85a68715c3c()._b0bb22ad2dae():
                    _cfe65d617e09(f"NaN detected in {_7632fbc2344e} ({_6494161b5f23._f72935f4231c.__name__}) ({_35c9bb096dfb._89fe9fce5a0e})")

            _7aa50f530b03._f5917fdc74ca(_b02e89f4651f)

            self._c9d073ce17d6(_7aa50f530b03, _7632fbc2344e)

    def _d56b38bfa077(self, _4266d0425e43):
        return _b0bb22ad2dae(_b9910be6b60a._14b204165982 for _b9910be6b60a in _4266d0425e43._c26928b89f7c())

    def _c43e6d1e1096(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _e2ebb947845e = []
        for _0c0dacb4d7e2, _4266d0425e43 in self._70efe7fd8751():
            if not self._2771b471d158(_4266d0425e43):
                continue
            _ddd1822d7b56 = (
                "norm" in _0c0dacb4d7e2._07c13b998630() or 
                "linear4bit" in _0c0dacb4d7e2._07c13b998630() or 
                _b0bb22ad2dae(_eedcfa5fcb5b in _0c0dacb4d7e2._07c13b998630() for _eedcfa5fcb5b in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _0c0dacb4d7e2._07c13b998630() or 
                "dropout" in _0c0dacb4d7e2._07c13b998630() or 
                _cc97f3cd34f6(_4266d0425e43, (_1264624981d6, _93798b6ebff3._fddbd1ba5163._0011c31d834e, _93798b6ebff3._fddbd1ba5163._5757e8753b1c))
            )
            if _ddd1822d7b56:
                if _bd69edefbc17(_4266d0425e43, "eps"):
                    _4266d0425e43._485fc4541a87 = 1e-3
                _4266d0425e43 = _4266d0425e43._05b61fc5c72d(_93798b6ebff3._3fc4fdbbacee)
                if not _cc97f3cd34f6(_4266d0425e43, _6fba45d9a31b._70476fed48cb):
                    _e2ebb947845e._7293a3436d99((_0c0dacb4d7e2, _6fba45d9a31b._70476fed48cb(_4266d0425e43, _83b4a3072807=-10, _3d309610f00f=10)))
        for _0c0dacb4d7e2, _75cf41cc6761 in _e2ebb947845e:
            _f8cff9980940, _2bfd86078d24 = self._b59ae3ac20e7(_0c0dacb4d7e2)
            if _f8cff9980940 is not _e75782893652:
                _5c045d05010b(_f8cff9980940, _2bfd86078d24, _75cf41cc6761)

    def _14717cd9c19e(self, _2ca202075523):
        """Finds the parent module and attribute name given the full module path."""
        _004fb9ec34f4 = _2ca202075523._6b13882fddc9('.')
        _97984e5a15ee = self
        for _c5456d0714b5 in _004fb9ec34f4[:-1]:
            _97984e5a15ee = _f16671dec8cc(_97984e5a15ee, _c5456d0714b5, _e75782893652)
            if _97984e5a15ee is _e75782893652:
                return _e75782893652, _e75782893652
        return _97984e5a15ee, _004fb9ec34f4[-1]

    def _481a0ea73b2a(self, _0274b810d9fe: _93798b6ebff3._2c2f9698b9a1, _691a8db6b55d: _93798b6ebff3._2c2f9698b9a1, _4d0157f40f10: _93798b6ebff3._2c2f9698b9a1) -> _594ff3b0690c:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _1ab67dadd454 = _0274b810d9fe._1ab67dadd454

        # 1) gating w (use cached per-example teacher_conf if available)
        _401ec22c9220 = _f16671dec8cc(self, "_last_teacher_conf", _e75782893652)
        if _401ec22c9220 is _e75782893652:
            # no teacher info => w = 0 (no distillation)
            _aaa134f7bcb6 = 0.0
        else:
            _ec57a6f655f6 = (_401ec22c9220 >= _7f38e480abd2(_f16671dec8cc(self, "teacher_conf_tau", 0.6)))._7f38e480abd2()
            _aaa134f7bcb6 = _7f38e480abd2(_ec57a6f655f6._4e4968f045e8()._a9cb52eef1f7()._2bc0251def91()) if _ec57a6f655f6._fe5fd09cbd19() > 0 else 0.0

        # apply gating to the batch scalars
        _fb461bd742ad = _691a8db6b55d * _7f38e480abd2(_aaa134f7bcb6)
        _d9cc3255ae3d = _4d0157f40f10 * _7f38e480abd2(_aaa134f7bcb6)

        # 2) EMAs for autoscaling
        _a1b076134cdc = _7f38e480abd2((_fb461bd742ad + _d9cc3255ae3d)._a58aae97523e()._a9cb52eef1f7()._2bc0251def91())
        _4b0c6d119483 = _7f38e480abd2(_0274b810d9fe._a58aae97523e()._a9cb52eef1f7()._2bc0251def91())
        if _f16671dec8cc(self, "ema_task", _e75782893652) is _e75782893652:
            self._3c0766346b08 = _4b0c6d119483
            self._0422303b4b9c = _a1b076134cdc + 1e-12
        else:
            _eb011faddd59 = _7f38e480abd2(_f16671dec8cc(self, "ema_alpha", 0.99))
            self._3c0766346b08 = _eb011faddd59 * _7f38e480abd2(self._3c0766346b08) + (1.0 - _eb011faddd59) * _4b0c6d119483
            self._0422303b4b9c  = _eb011faddd59 * _7f38e480abd2(self._0422303b4b9c)  + (1.0 - _eb011faddd59) * _a1b076134cdc

        _18c658d43e43 = _7f38e480abd2(_f16671dec8cc(self, "distill_target_ratio", 0.3))
        _90292bb30696 = (_7f38e480abd2(self._3c0766346b08) / (_7f38e480abd2(self._0422303b4b9c) + 1e-12)) * _18c658d43e43
        _33e3b9b7dd35 = _7f38e480abd2(_90292bb30696)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _7b3c7b0cb9cc = _7f38e480abd2(_f16671dec8cc(self._7d9b2049da39, "current_epoch", _f16671dec8cc(self._7d9b2049da39, "global_step", 0.0)))
        _c13457725c8f = _7f38e480abd2(_348c1b41a78f(1, _f16671dec8cc(self._7d9b2049da39, "max_epochs", 1)))
        _3075ed5f9500 = _388d6a5f6d6e(_348c1b41a78f(_7b3c7b0cb9cc / _c13457725c8f, 0.0), 1.0)
        _2d1a46806561 = 0.30
        _8387c1ee05c8 = _7f38e480abd2(_f16671dec8cc(self, "kl_base", 0.30)) * _388d6a5f6d6e(_3075ed5f9500 / _2d1a46806561, 1.0)
        _f10d1bc8a50d = _7f38e480abd2(_f16671dec8cc(self, "cos_base", 0.25))
        _9317b5d229a5 = _f10d1bc8a50d + (0.10 - _f10d1bc8a50d) * _3075ed5f9500

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _e8068ca07619 = _7f38e480abd2(self._32e98a8e44cb._4e4968f045e8()._a9cb52eef1f7()._2bc0251def91()) if _f16671dec8cc(self, "_last_teacher_conf", _e75782893652) is not _e75782893652 else 0.0
        if _f16671dec8cc(self, "ema_teacher_conf", _e75782893652) is _e75782893652:
            self._7b860900e9f9 = _e8068ca07619
        else:
            _6cc84df5e3a3 = _7f38e480abd2(_f16671dec8cc(self, "teacher_conf_beta", 0.995))
            self._7b860900e9f9 = _6cc84df5e3a3 * _7f38e480abd2(self._7b860900e9f9) + (1.0 - _6cc84df5e3a3) * _e8068ca07619

        _ea37f2830cd1 = _7f38e480abd2(_f16671dec8cc(self, "tau_warn", 0.60))
        _aa7be39c7023 = _7f38e480abd2(_f16671dec8cc(self, "tau_detect", 0.20))
        _81296f4c6288 = _348c1b41a78f(1e-12, (_ea37f2830cd1 - _aa7be39c7023))
        _27169b4b267d = (_7f38e480abd2(self._7b860900e9f9) - _aa7be39c7023) / _81296f4c6288
        _27169b4b267d = _348c1b41a78f(0.0, _388d6a5f6d6e(1.0, _27169b4b267d))

        _ccf0019fb7bc = _8387c1ee05c8 * _27169b4b267d
        _12af1e9a518e = _9317b5d229a5 * _27169b4b267d

        # 5) final aux term
        _a18424c890b7 = _93798b6ebff3._900181899e6d(0.0, _1ab67dadd454=_1ab67dadd454)
        _a18424c890b7 = _a18424c890b7 + (_ccf0019fb7bc * _fb461bd742ad + _12af1e9a518e * _d9cc3255ae3d) * _7f38e480abd2(_33e3b9b7dd35)

        # diagnostics
        _35c9bb096dfb = {
            "aux_term": _a18424c890b7,
            "kl_batch": _691a8db6b55d,
            "contrast_batch": _4d0157f40f10,
            "kl_loss": _fb461bd742ad,
            "contrastive_loss": _d9cc3255ae3d,
            "w_mean": _aaa134f7bcb6,
            "aux_scale": _7f38e480abd2(_33e3b9b7dd35),
            "lambda_kl_eff": _7f38e480abd2(_ccf0019fb7bc),
            "lambda_cos_eff": _7f38e480abd2(_12af1e9a518e),
            "teacher_conf_mean": _7f38e480abd2(self._7b860900e9f9),
            "shift_r": _7f38e480abd2(_27169b4b267d)
        }
        return _35c9bb096dfb

    def _f7bf6d0a7440(self, _d68d4b91c7f5):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _d68d4b91c7f5 = _d68d4b91c7f5._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)
        _9b6ad247b2f4 = (_d68d4b91c7f5 != self._a4f5917d1c48._9bf964b708b9)._05b61fc5c72d(_89fe9fce5a0e=_93798b6ebff3._af59e6857e2d, _1ab67dadd454=self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)

        # model forward (request hidden states)
        _7e25b54d12bf = self._0c30d10657bb(
            _d68d4b91c7f5=_d68d4b91c7f5,
            _9b6ad247b2f4=_9b6ad247b2f4,
            _df9c6d2e2cf5=_bfaf21e8f1ce,
            _bbe0ee25b449=_bfaf21e8f1ce,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _4315d210bfa1 = _f16671dec8cc(_7e25b54d12bf, "last_hidden_state", _e75782893652)
        if _4315d210bfa1 is _e75782893652:
            _4315d210bfa1 = _7e25b54d12bf._5b70f591a07f[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _4315d210bfa1._89fe9fce5a0e != _93798b6ebff3._3fc4fdbbacee:
            _4315d210bfa1 = _4315d210bfa1._05b61fc5c72d(_93798b6ebff3._3fc4fdbbacee)
        _98e4967c45d7 = self._49dd50e0bfc8(_4315d210bfa1)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._b4c300d1eb90:
            _bf87aeff8560 = self._4058ff69efcb(_98e4967c45d7)
        else:
            _bf87aeff8560 = _7e25b54d12bf._bf87aeff8560


        _bf87aeff8560 = _bf87aeff8560._05b61fc5c72d(_93798b6ebff3._3fc4fdbbacee)._6279acf77fc6(-20, 20)

        # default zero scalars
        _fb461bd742ad = _93798b6ebff3._900181899e6d(0.0, _1ab67dadd454=self._6db2aff10bdd)
        _d9cc3255ae3d = _93798b6ebff3._900181899e6d(0.0, _1ab67dadd454=self._6db2aff10bdd)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _10a68bee2f30 = _f16671dec8cc(self, "trainer", _e75782893652)
        _9014b769df8b = _6ba42ed9e571
        if _10a68bee2f30 is not _e75782893652:
            _9014b769df8b = _af59e6857e2d(_f16671dec8cc(self._7d9b2049da39, "training", _6ba42ed9e571) or _f16671dec8cc(self._7d9b2049da39, "validating", _6ba42ed9e571))

        if _9014b769df8b and (_f16671dec8cc(self, "batch_counter", 0) % _f16671dec8cc(self, "xth_batch_to_consider", 1) == 0):
            with _93798b6ebff3._f64d8fabfc8c():
                _c0fca0b959cc = _6fa34245014d(
                    _d68d4b91c7f5=_d68d4b91c7f5,
                    _9b6ad247b2f4=_9b6ad247b2f4,
                    _df9c6d2e2cf5=_bfaf21e8f1ce,
                    _bbe0ee25b449=_bfaf21e8f1ce,
                )
                _25bcd0710dcf = _f16671dec8cc(_c0fca0b959cc, "last_hidden_state", _e75782893652)
                if _25bcd0710dcf is _e75782893652:
                    _25bcd0710dcf = _c0fca0b959cc._5b70f591a07f[-1]

            # compute embedding-level KL + contrastive (scalar)
            _fb461bd742ad, _d9cc3255ae3d = self._76111e42424c(_98e4967c45d7, _25bcd0710dcf, _1ab67dadd454=self._6db2aff10bdd)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _83d400488a52(_4db82363fae7): return _4db82363fae7._4e4968f045e8(_b3561ed5dbe7=1) if _4db82363fae7._b3561ed5dbe7() == 3 else _4db82363fae7
            _1bec7cf9b93f = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._ff79196f0000(_0cd275a10973(_98e4967c45d7), _b9910be6b60a=2, _b3561ed5dbe7=-1, _485fc4541a87=1e-6)
            _8130de7ee309 = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._ff79196f0000(_0cd275a10973(_25bcd0710dcf), _b9910be6b60a=2, _b3561ed5dbe7=-1, _485fc4541a87=1e-6)
            _f19973c47d94 = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._d9e17901ff6d(_1bec7cf9b93f, _8130de7ee309, _b3561ed5dbe7=-1)  # [-1,1]
            _401ec22c9220 = _f19973c47d94._6279acf77fc6(_388d6a5f6d6e=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._a4c2f9270038 = _98e4967c45d7._a58aae97523e()
            self._c60fd87e4a0b = _25bcd0710dcf._a58aae97523e()
            self._32e98a8e44cb = _401ec22c9220._a58aae97523e()  # shape (B,)

        # increment counter
        self._961b098a28b0 = _f16671dec8cc(self, "batch_counter", 0) + 1

        return _bf87aeff8560, _fb461bd742ad, _d9cc3255ae3d


    def _a801aee3c789(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _dbd778169420(_4266d0425e43, _2ca0f1b29e82, _c3bd6fa2d3a1):
            if _b0bb22ad2dae(_cb0eeb7c7802._89fe9fce5a0e == _93798b6ebff3._023e1e854935 for _cb0eeb7c7802 in _2ca0f1b29e82 if _cc97f3cd34f6(_cb0eeb7c7802, _93798b6ebff3._2c2f9698b9a1)):
                _cfe65d617e09(f"Layer {_4266d0425e43._f72935f4231c.__name__} is using float16!")

        for _efdf5a39bd05 in self._6574a92bc0ee():
            _5b821cfc00c1 = _efdf5a39bd05._f5917fdc74ca(_187efb26e57f)
            self._883c119da754._7293a3436d99(_5b821cfc00c1)

    def _b20bf50b5d0a(self):
        """Remove all registered forward hooks."""
        for _5b821cfc00c1 in _f16671dec8cc(self, "amp_hooks", []):
            _5b821cfc00c1._c390d75242ea()
        self._883c119da754 = []

    def _7a8f3c458382(self, _d68d4b91c7f5, _9390bd02a658, _48ec30b39292):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _136eff7d7c12 = [self._a4f5917d1c48._71c9122865ca(_8cf938de9515) for _8cf938de9515 in _d68d4b91c7f5]
        _e282d71816d6, _45e8e0a3a1d6 = [], []

        for _325f8d1ae773, _2a55b0dc55c6, _aff1dfaf9717 in _06419fbf5e2e(_136eff7d7c12, _9390bd02a658, _48ec30b39292):
            for token, _cd70b90c106d, _244ddf304566 in _06419fbf5e2e(_325f8d1ae773, _2a55b0dc55c6, _aff1dfaf9717):
                if token == self._a4f5917d1c48._13fe02254d20 or _244ddf304566 == self._b2a09c79bbff:
                    continue

                _96525a6f50a7 = (
                    token._4ece9211fd35("##") or
                    token._4ece9211fd35("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _96525a6f50a7:
                    continue

                _e282d71816d6._7293a3436d99(_cd70b90c106d._2bc0251def91())
                _45e8e0a3a1d6._7293a3436d99(_244ddf304566._2bc0251def91())

        return _93798b6ebff3._900181899e6d(_e282d71816d6), _93798b6ebff3._900181899e6d(_45e8e0a3a1d6)

    def _bf70524c9ed1(self):
        _732366352f5d = _93798b6ebff3._3fc4fdbbacee
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            _35368666659f, _694e1749ca86 = _93798b6ebff3._11cb931ce190._61073e82c34e()
            if _35368666659f >= 8:
                _732366352f5d = _93798b6ebff3._5c84a99aefe4
            else:
                _732366352f5d = _93798b6ebff3._023e1e854935
        return _732366352f5d

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _8a49b26de655(
        self,
        _cdb96ac11c9a: _93798b6ebff3._2c2f9698b9a1,
        _dcd3838612a7: _93798b6ebff3._2c2f9698b9a1,
        _1ab67dadd454: _50caed727acd = "cpu",
    ) -> _f9ed61b3c371[_93798b6ebff3._2c2f9698b9a1, _93798b6ebff3._2c2f9698b9a1]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _29c699a91c08 = 2.0
            # NaN/Inf guard
            _cdb96ac11c9a = _cdb96ac11c9a._6279acf77fc6(_388d6a5f6d6e=-30, _348c1b41a78f=30)
            _dcd3838612a7 = _dcd3838612a7._6279acf77fc6(_388d6a5f6d6e=-30, _348c1b41a78f=30)

            # Move once if needed
            _f59cbf0ae04e = _93798b6ebff3._1ab67dadd454(_1ab67dadd454)
            if _cdb96ac11c9a._1ab67dadd454 != _f59cbf0ae04e:
                _cdb96ac11c9a = _cdb96ac11c9a._05b61fc5c72d(_1ab67dadd454=_f59cbf0ae04e, _526db6377dd5=_bfaf21e8f1ce, _89fe9fce5a0e=self._9bae8a0f0464)
                _dcd3838612a7 = _dcd3838612a7._05b61fc5c72d(_1ab67dadd454=_f59cbf0ae04e, _526db6377dd5=_bfaf21e8f1ce, _89fe9fce5a0e=self._9bae8a0f0464)

            _96e77c0a512a = _cdb96ac11c9a._7e5fa7500322(0)
            _fe08e095a7ee = _cdb96ac11c9a._7e5fa7500322(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _ff8ec63fcee3 = (_96e77c0a512a * _fe08e095a7ee) > 32_000_000

            if not _ff8ec63fcee3 or _96e77c0a512a <= 8:
                # Direct computation
                _bed9b6ae68b0 = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._1804615acac1(_cdb96ac11c9a / _29c699a91c08, _b3561ed5dbe7=-1)
                _0336eb8dfc7b = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._7e3e4f160ace(_dcd3838612a7 / _29c699a91c08, _b3561ed5dbe7=-1)
                _fb461bd742ad = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._6a2d2ff5b9d7(_bed9b6ae68b0, _0336eb8dfc7b, _ce86719d6f12="batchmean") * (_29c699a91c08 * _29c699a91c08)
                _d9cc3255ae3d = 1 - _93798b6ebff3._fddbd1ba5163._44c15d484ebf._d9e17901ff6d(_cdb96ac11c9a, _dcd3838612a7, _b3561ed5dbe7=-1)._4e4968f045e8()
                return _fb461bd742ad, _d9cc3255ae3d

            # Chunked mode for large inputs
            _7e723b5e0909 = _348c1b41a78f(1, _96e77c0a512a // 8)
            _79aec9dde149, _277ee9b7b57f = [], []

            for _750d1482b80f in _0638c39f3305(0, _96e77c0a512a, _7e723b5e0909):
                _1e1596ad5009 = _cdb96ac11c9a[_750d1482b80f:_750d1482b80f + _7e723b5e0909]
                _17d4ca6708c8 = _dcd3838612a7[_750d1482b80f:_750d1482b80f + _7e723b5e0909]

                _bed9b6ae68b0 = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._1804615acac1(_1e1596ad5009 / _29c699a91c08, _b3561ed5dbe7=-1)
                _0336eb8dfc7b = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._7e3e4f160ace(_17d4ca6708c8 / _29c699a91c08, _b3561ed5dbe7=-1)

                _dc6d06d07f50 = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._6a2d2ff5b9d7(_bed9b6ae68b0, _0336eb8dfc7b, _ce86719d6f12="batchmean") * (_29c699a91c08 * _29c699a91c08)
                _b739ed42be28 = _93798b6ebff3._fddbd1ba5163._44c15d484ebf._d9e17901ff6d(_1e1596ad5009, _17d4ca6708c8, _b3561ed5dbe7=-1)._4e4968f045e8()
                _3d868cf8c47c = 1 - _b739ed42be28

                _79aec9dde149._7293a3436d99(_dc6d06d07f50)
                _277ee9b7b57f._7293a3436d99(_3d868cf8c47c)

            _fb461bd742ad = _93798b6ebff3._97ea3c68c6cd(_79aec9dde149)._4e4968f045e8()
            _d9cc3255ae3d = _93798b6ebff3._97ea3c68c6cd(_277ee9b7b57f)._4e4968f045e8()
            return _fb461bd742ad, _d9cc3255ae3d

        except _15abe8b3010d as _10713e26fb79:
            raise _5c0aaf6ef8ad(f"KL/contrastive loss computation failed: {_50caed727acd(_10713e26fb79)}")


    def _c592f7372006(self, _7df4ed909fbb, _f3aed6051df4):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _d68d4b91c7f5 = _7df4ed909fbb["input_ids"]
            _0a56d3aa120b = _7df4ed909fbb["labels"]
            _37f3371303d3 = _7df4ed909fbb._990e95f70bed("prompt_lens", _e75782893652)
            _96e77c0a512a = _d68d4b91c7f5._7e5fa7500322(0)

            # move to device
            _d68d4b91c7f5 = _d68d4b91c7f5._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)
            _0a56d3aa120b = _0a56d3aa120b._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _c3bd6fa2d3a1, _691a8db6b55d, _4d0157f40f10 = self(_d68d4b91c7f5)

            # causal LM shift for next-token classification (unchanged)
            _26e8125f5c93 = _c3bd6fa2d3a1[:, :-1, :]._6bda621559aa()
            _b43896b5eb84 = _0a56d3aa120b[:, 1:]._6bda621559aa()
            _4d65bd339691 = _26e8125f5c93._dfb048f55998(-1, _26e8125f5c93._7e5fa7500322(-1))
            _2f2e21a70319 = _b43896b5eb84._dfb048f55998(-1)

            # classification/task loss
            _cf5239c30bec = self._32197bf9f0fb['criterion'](_4d65bd339691, _2f2e21a70319)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _691a8db6b55d = _93798b6ebff3._efadffc3748b(_691a8db6b55d, _0c52e44ed2ab=0.0, _19f3d6894854=0.0, _d130ddf3f9a4=0.0)
            _4d0157f40f10 = _93798b6ebff3._efadffc3748b(_4d0157f40f10, _0c52e44ed2ab=0.0, _19f3d6894854=0.0, _d130ddf3f9a4=0.0)
            _cf5239c30bec = _93798b6ebff3._efadffc3748b(_cf5239c30bec, _0c52e44ed2ab=0.0, _19f3d6894854=0.0, _d130ddf3f9a4=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _a03ba2f3b387 = self._d5e207600892(_cf5239c30bec, _691a8db6b55d, _4d0157f40f10)
            _a18424c890b7 = _a03ba2f3b387["aux_term"]

            # final combined loss (single-equation)
            _084bd656c27b = _cf5239c30bec + _a18424c890b7

            # Optional NaN print as before (keeps your original check)
            if _93798b6ebff3._f85a68715c3c(_cf5239c30bec):
                _cfe65d617e09(f"Step {_f3aed6051df4}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _75356c6fe4bd = {
                "epoch": _7f38e480abd2(_f16671dec8cc(self, "current_epoch", _f16671dec8cc(self._7d9b2049da39, "current_epoch", 0))),
                "train_kl_loss": _a03ba2f3b387._990e95f70bed("kl_loss", _691a8db6b55d)._a58aae97523e() if _cc97f3cd34f6(_a03ba2f3b387._990e95f70bed("kl_loss", _691a8db6b55d), _93798b6ebff3._2c2f9698b9a1) else _a03ba2f3b387._990e95f70bed("kl_loss", _691a8db6b55d),
                "train_contrastive_loss": _a03ba2f3b387._990e95f70bed("contrastive_loss", _4d0157f40f10)._a58aae97523e() if _cc97f3cd34f6(_a03ba2f3b387._990e95f70bed("contrastive_loss", _4d0157f40f10), _93798b6ebff3._2c2f9698b9a1) else _a03ba2f3b387._990e95f70bed("contrastive_loss", _4d0157f40f10),
                "train_classification_loss": _cf5239c30bec._a58aae97523e(),
                "train_loss": _084bd656c27b._a58aae97523e(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _7f38e480abd2(_f16671dec8cc(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _a03ba2f3b387._990e95f70bed("lambda_kl_eff", _7f38e480abd2(_f16671dec8cc(self, "kl_base", 0.30))),
                "train_lambda_contrast": _a03ba2f3b387._990e95f70bed("lambda_cos_eff", _7f38e480abd2(_f16671dec8cc(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _b82419b2e253 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _b82419b2e253 in _a03ba2f3b387:
                    _569b99b88210 = _a03ba2f3b387[_b82419b2e253]
                    # convert single-element tensors to python floats for logging
                    if _cc97f3cd34f6(_569b99b88210, _93798b6ebff3._2c2f9698b9a1) and _569b99b88210._fe5fd09cbd19() == 1:
                        _75356c6fe4bd[f"train_{_b82419b2e253}"] = _7f38e480abd2(_569b99b88210._a58aae97523e()._a9cb52eef1f7()._2bc0251def91())
                    else:
                        _75356c6fe4bd[f"train_{_b82419b2e253}"] = _569b99b88210

            # log exactly like you did
            self._d1fe0f44301b(
                _75356c6fe4bd,
                _96e77c0a512a=_96e77c0a512a,
                _c2e81ef67f49=_6ba42ed9e571,
                _9d8f06e839aa=_bfaf21e8f1ce,
                _3a66f124ee19=_6ba42ed9e571,
                _36768b0ed684=_bfaf21e8f1ce,
                _86c471169b89=_bfaf21e8f1ce,
            )

            # free references as you did
            del _d68d4b91c7f5, _0a56d3aa120b, _c3bd6fa2d3a1, _691a8db6b55d, _cf5239c30bec, _4d0157f40f10, _b43896b5eb84, _26e8125f5c93, _2f2e21a70319, _4d65bd339691

            return _084bd656c27b

        except _15abe8b3010d as _10713e26fb79:
            raise _5c0aaf6ef8ad(f"Error in training_step: {_10713e26fb79}") from _10713e26fb79

    def _9c2808c68084(self):
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            _93798b6ebff3._11cb931ce190._403e12664643()
        _0285f0b8a0cb._7492b6e95dcc()
        return _12ccfeab9cff()._c228522ab6a4()

    def _5520b7742464(self, _7df4ed909fbb, _f3aed6051df4):
        _d68d4b91c7f5      = _7df4ed909fbb["input_ids"]._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)
        _0a56d3aa120b         = _7df4ed909fbb["labels"]._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)
        _8248b663a89c     = _7df4ed909fbb._990e95f70bed("lang_codes", _e75782893652)
        _231aa48f70a5     = _7df4ed909fbb._990e95f70bed("sample_ids", _e75782893652)
        _427c450ba75e      = _7df4ed909fbb._990e95f70bed("chunk_ids", _e75782893652)
        _a57ea82df12f = _7df4ed909fbb._990e95f70bed("word_positions", _e75782893652)
        _37f3371303d3    = _7df4ed909fbb._990e95f70bed("prompt_lens", _e75782893652)
        _56a3047229c7 = _7df4ed909fbb._990e95f70bed("num_chunks", _e75782893652)

        _96e77c0a512a = _d68d4b91c7f5._7e5fa7500322(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _c3bd6fa2d3a1, _691a8db6b55d, _4d0157f40f10 = self(_d68d4b91c7f5)

        # causal LM shift for next-token classification (same as training)
        _26e8125f5c93 = _c3bd6fa2d3a1[:, :-1, :]._6bda621559aa()
        _b43896b5eb84 = _0a56d3aa120b[:, 1:]._6bda621559aa()
        _4d65bd339691 = _26e8125f5c93._dfb048f55998(-1, _26e8125f5c93._7e5fa7500322(-1))
        _2f2e21a70319 = _b43896b5eb84._dfb048f55998(-1)

        if _f3aed6051df4 == 0:
            try:
                _cfe65d617e09(
                    f"VAL TEST BATCH {_f3aed6051df4} Input IDs: {_d68d4b91c7f5._98e7d7bfd062()[0]}, "
                    f"Predictions: {_93798b6ebff3._96118bcee280(_26e8125f5c93, _b3561ed5dbe7=-1)._98e7d7bfd062()[0]}, "
                    f"Labels: {_b43896b5eb84._98e7d7bfd062()[0]}"
                )
            except _15abe8b3010d:
                # printing should never crash validation
                pass

        # classification loss
        _cf5239c30bec = self._32197bf9f0fb['criterion'](_4d65bd339691, _2f2e21a70319)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _691a8db6b55d = _93798b6ebff3._efadffc3748b(_691a8db6b55d, _0c52e44ed2ab=0.0, _19f3d6894854=0.0, _d130ddf3f9a4=0.0)
        _4d0157f40f10 = _93798b6ebff3._efadffc3748b(_4d0157f40f10, _0c52e44ed2ab=0.0, _19f3d6894854=0.0, _d130ddf3f9a4=0.0)
        _cf5239c30bec = _93798b6ebff3._efadffc3748b(_cf5239c30bec, _0c52e44ed2ab=0.0, _19f3d6894854=0.0, _d130ddf3f9a4=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _a03ba2f3b387 = self._d5e207600892(_cf5239c30bec, _691a8db6b55d, _4d0157f40f10)
        _a18424c890b7 = _a03ba2f3b387["aux_term"]
        _084bd656c27b = _cf5239c30bec + _a18424c890b7

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _d1fe0f44301b = {
            "val_kl_loss": _7f38e480abd2(_a03ba2f3b387._990e95f70bed("kl_loss", _691a8db6b55d)._a58aae97523e()._a9cb52eef1f7()._2bc0251def91()) if _cc97f3cd34f6(_a03ba2f3b387._990e95f70bed("kl_loss", _691a8db6b55d), _93798b6ebff3._2c2f9698b9a1) else _7f38e480abd2(_a03ba2f3b387._990e95f70bed("kl_loss", _691a8db6b55d)),
            "val_contrastive_loss": _7f38e480abd2(_a03ba2f3b387._990e95f70bed("contrastive_loss", _4d0157f40f10)._a58aae97523e()._a9cb52eef1f7()._2bc0251def91()) if _cc97f3cd34f6(_a03ba2f3b387._990e95f70bed("contrastive_loss", _4d0157f40f10), _93798b6ebff3._2c2f9698b9a1) else _7f38e480abd2(_a03ba2f3b387._990e95f70bed("contrastive_loss", _4d0157f40f10)),
            "val_classification_loss": _7f38e480abd2(_cf5239c30bec._a58aae97523e()._a9cb52eef1f7()._2bc0251def91()),
            "val_loss": _7f38e480abd2(_084bd656c27b._a58aae97523e()._a9cb52eef1f7()._2bc0251def91()),
        }

        # include effective lambdas and others if provided by aux
        _d1fe0f44301b["val_lambda_kl"] = _7f38e480abd2(_a03ba2f3b387._990e95f70bed("lambda_kl", _a03ba2f3b387._990e95f70bed("lambda_kl_eff", _7f38e480abd2(_f16671dec8cc(self, "kl_base", 0.30)))))
        _d1fe0f44301b["val_lambda_contrast"] = _7f38e480abd2(_a03ba2f3b387._990e95f70bed("lambda_cos", _a03ba2f3b387._990e95f70bed("lambda_cos_eff", _7f38e480abd2(_f16671dec8cc(self, "cos_base", 0.25)))))
        _d1fe0f44301b["val_w_mean"] = _7f38e480abd2(_a03ba2f3b387._990e95f70bed("w_mean", 0.0))
        _d1fe0f44301b["val_aux_scale"] = _7f38e480abd2(_a03ba2f3b387._990e95f70bed("aux_scale", 0.0))
        _d1fe0f44301b["val_shift_r"] = _7f38e480abd2(_a03ba2f3b387._990e95f70bed("shift_r", 0.0))
        _d1fe0f44301b["val_teacher_conf_mean"] = _7f38e480abd2(_a03ba2f3b387._990e95f70bed("teacher_conf_mean", 0.0))

        self._d1fe0f44301b(
            _d1fe0f44301b,
            _96e77c0a512a=_96e77c0a512a,
            _c2e81ef67f49=_6ba42ed9e571,
            _9d8f06e839aa=_bfaf21e8f1ce,
            _3a66f124ee19=_6ba42ed9e571,
            _36768b0ed684=_bfaf21e8f1ce,
            _86c471169b89=_bfaf21e8f1ce,
        )

        # build preds and labels per example (preserve your previous behavior)
        _eab76ddfd8f7 = []
        _06184fe9157e = []
        for _750d1482b80f in _0638c39f3305(_96e77c0a512a):
            _60b029533d19 = _c3bd6fa2d3a1[_750d1482b80f]
            _244ddf304566 = _0a56d3aa120b[_750d1482b80f]
            _fb891cd31d3c = _93798b6ebff3._96118bcee280(_60b029533d19, _b3561ed5dbe7=-1)
            _f84ad128eaa1 = _244ddf304566
            _eab76ddfd8f7._7293a3436d99(_fb891cd31d3c)
            _06184fe9157e._7293a3436d99(_f84ad128eaa1)

        _7b25b1d2b198 = {
            "lang_codes": _8248b663a89c,
            "preds": _eab76ddfd8f7,
            "labels": _06184fe9157e,
            "sample_ids": _231aa48f70a5,
            "chunk_ids": _427c450ba75e,
            "word_positions": _a57ea82df12f,
            "val_loss": _084bd656c27b,
            "prompt_lens": _37f3371303d3,
            "num_chunks": _56a3047229c7,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._39c403a3c271._7293a3436d99(_7b25b1d2b198)

        # explicit frees (same as you had)
        del _d68d4b91c7f5, _0a56d3aa120b, _c3bd6fa2d3a1, _4d65bd339691, _2f2e21a70319, _26e8125f5c93, _b43896b5eb84
        del _691a8db6b55d, _4d0157f40f10, _cf5239c30bec, _eab76ddfd8f7, _06184fe9157e

        return _7b25b1d2b198


    def _15636f669f6e(self, _97403dd41e6b, _d27907fe17f1, _3b3472ca4f75=_e75782893652):
        _ee8062156c4f = os._c963bbd67ba2()
        _80f7215ca104 = f"trial_{_3b3472ca4f75}" if _3b3472ca4f75 is not _e75782893652 else "default"
        _cfe65d617e09(f"[DEBUG rank={_93798b6ebff3._bffe434e3f41._6d6df9f71591() if _93798b6ebff3._bffe434e3f41._0ea389cfc603() else 0}] metrics_dict confusion_matrix sum={_b5dcd9b7b532(_b5dcd9b7b532(_5669a480def2) for _5669a480def2 in _97403dd41e6b['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _49d80737c6ed = os._b1a928f3033a._f544e7a051d8(_ee8062156c4f, "metrics", self._48a0b1a6c95f,  _80f7215ca104)
        os._62fa4703cd9e(_49d80737c6ed, _799c65ac561a=_bfaf21e8f1ce)
        _13dc3c349e3a = os._b1a928f3033a._f544e7a051d8(_49d80737c6ed, _d27907fe17f1)
        _0214b83c2748 = _44427ee2d19e._4173f213dc93(_97403dd41e6b)
        _0214b83c2748._29c69a1195ab(_13dc3c349e3a, _dfeb4f1b20e9=_6ba42ed9e571)
        _cfe65d617e09(f"[metrics] Saved {_13dc3c349e3a}")

    def _5a84c85c47c2(self):
        # pick correct device for this rank
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            if _93798b6ebff3._bffe434e3f41._0ea389cfc603():
                _713436df354b = _93798b6ebff3._bffe434e3f41._6d6df9f71591()
            else:
                _713436df354b = 0
            _93798b6ebff3._11cb931ce190._d62238c9af80(_713436df354b)
            self._6db2aff10bdd = _93798b6ebff3._1ab67dadd454(f"cuda:{_713436df354b}")
        else:
            self._6db2aff10bdd = _93798b6ebff3._1ab67dadd454("cpu")

        self._30c0f9d5f93b()

    def _0597afbd1c9a(self):
        _c3bd6fa2d3a1 = _f16671dec8cc(self, "_validation_outputs", _e75782893652)
        if not _c3bd6fa2d3a1:
            return

        _a689c9f98ff2, _16e30626b3db, _df60cb8507ae, _a6112b38288c = \
            self._5fda03c9b730(_c3bd6fa2d3a1)

        _71226ff96d2c, _cc42880e1c11 = [], []
        for _1768aacdec86 in _835bf9fcbd10(_df60cb8507ae._2ff5d0680b5c()):
            _30502c04d20c = _a689c9f98ff2[_1768aacdec86]._98e7d7bfd062()
            _43815abac0af = _16e30626b3db[_1768aacdec86]._98e7d7bfd062()
            _8227b7ced0b2 = _df60cb8507ae[_1768aacdec86]
            _4f08f0e097f5 = _a6112b38288c[_1768aacdec86]
            if _8227b7ced0b2._fe5fd09cbd19() > 0 and _4f08f0e097f5._fe5fd09cbd19() > 0:
                _71226ff96d2c._7293a3436d99(_8227b7ced0b2)
                _cc42880e1c11._7293a3436d99(_4f08f0e097f5)

        if not _71226ff96d2c:
            _cfe65d617e09("[VAL END] Nothing to score.")
            self._39c403a3c271._d5994296b7ee()
            return

        _7ba27ef18200 = _93798b6ebff3._6e1cccf08116(_71226ff96d2c)._05b61fc5c72d(_1ab67dadd454=self._f058c9c3ab41['micro_accuracy']._1ab67dadd454, _526db6377dd5=_bfaf21e8f1ce)
        _0a56d3aa120b = _93798b6ebff3._6e1cccf08116(_cc42880e1c11)._05b61fc5c72d(_1ab67dadd454=self._f058c9c3ab41['micro_accuracy']._1ab67dadd454, _526db6377dd5=_bfaf21e8f1ce)

        self._f058c9c3ab41['micro_accuracy']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_accuracy']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_precision']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_recall']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_f1']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_accuracy']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_precision']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_recall']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_f1']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['confmat']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)

        _7c8b50d8983c  = self._f058c9c3ab41['micro_accuracy']._7131993708f6()._2bc0251def91()
        _e33c28b9a5b8  = self._f058c9c3ab41['macro_accuracy']._7131993708f6()._2bc0251def91()
        _58a0277f7693 = self._f058c9c3ab41['macro_precision']._7131993708f6()._2bc0251def91()
        _f5d3ddb9d44a    = self._f058c9c3ab41['macro_recall']._7131993708f6()._2bc0251def91()
        _e32ec0b22515        = self._f058c9c3ab41['macro_f1']._7131993708f6()._2bc0251def91()

        self._fc76fcca2828("val_accuracy", _e33c28b9a5b8, _86c471169b89=_bfaf21e8f1ce)

        try:
            _1ec84ede0ec8 = self._f1216663ccbb
            _97403dd41e6b = {
                "epoch": [_1ec84ede0ec8],
                "class_names": [self._1e4a78dd72e4],
                "micro_accuracy": [_7c8b50d8983c],
                "macro_accuracy": [_e33c28b9a5b8],
                "macro_precision": [_58a0277f7693],
                "macro_recall": [_f5d3ddb9d44a],
                "macro_f1": [_e32ec0b22515],
                "classwise_accuracy": [self._f058c9c3ab41['classwise_accuracy']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "classwise_precision": [self._f058c9c3ab41['classwise_precision']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "classwise_recall": [self._f058c9c3ab41['classwise_recall']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "classwise_f1": [self._f058c9c3ab41['classwise_f1']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "confusion_matrix": [self._f058c9c3ab41['confmat']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
            }
            self._04be082d3bdd(_97403dd41e6b, f"val_epoch_{_1ec84ede0ec8}.csv", _3b3472ca4f75=self._3b3472ca4f75)
        except _15abe8b3010d as _10713e26fb79:
            _cfe65d617e09(f"[VAL END] save metrics FAILED: {_10713e26fb79}")

        # cleanup
        self._f058c9c3ab41['micro_accuracy']._6d559769edb3(); self._f058c9c3ab41['macro_accuracy']._6d559769edb3()
        self._f058c9c3ab41['macro_precision']._6d559769edb3(); self._f058c9c3ab41['macro_recall']._6d559769edb3(); self._f058c9c3ab41['macro_f1']._6d559769edb3()
        self._f058c9c3ab41['classwise_accuracy']._6d559769edb3(); self._f058c9c3ab41['classwise_precision']._6d559769edb3()
        self._f058c9c3ab41['classwise_recall']._6d559769edb3(); self._f058c9c3ab41['classwise_f1']._6d559769edb3()
        self._f058c9c3ab41['confmat']._6d559769edb3(); self._39c403a3c271._d5994296b7ee()
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            _93798b6ebff3._11cb931ce190._403e12664643()
        _cfe65d617e09("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_93798b6ebff3._f64d8fabfc8c()
    def _ea965a973371(self, _d68d4b91c7f5: _93798b6ebff3._2c2f9698b9a1, **_8a173810a8d9):
        _8a173810a8d9._847754b5fe3a("pad_token_id", _e75782893652)
        _8a173810a8d9._847754b5fe3a("attention_mask", _e75782893652)
        return self._0c30d10657bb._aebf7bc9837a(
            _d68d4b91c7f5=_d68d4b91c7f5,
            _9b6ad247b2f4=(_d68d4b91c7f5 != self._a4f5917d1c48._9bf964b708b9),
            _9bf964b708b9=self._a4f5917d1c48._9bf964b708b9,
            _e94689b3f34e=self._a4f5917d1c48._e94689b3f34e,
            **_8a173810a8d9
        )

    def _6ab491ec6413(self, _7df4ed909fbb, _f3aed6051df4):
        _d68d4b91c7f5 = _7df4ed909fbb["input_ids"]._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)
        _0a56d3aa120b    = _7df4ed909fbb["labels"]._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)
        _8248b663a89c     = _7df4ed909fbb._990e95f70bed("lang_codes", _e75782893652)
        _231aa48f70a5     = _7df4ed909fbb._990e95f70bed("sample_ids", _e75782893652)
        _427c450ba75e      = _7df4ed909fbb._990e95f70bed("chunk_ids", _e75782893652)
        _a57ea82df12f = _7df4ed909fbb._990e95f70bed("word_positions", _e75782893652)
        _37f3371303d3    = _7df4ed909fbb._990e95f70bed("prompt_lens", _e75782893652)
        _56a3047229c7 = _7df4ed909fbb._990e95f70bed("num_chunks", _e75782893652)

        _96e77c0a512a = _d68d4b91c7f5._7e5fa7500322(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _bae596a25a55 = self._aebf7bc9837a(
            _d68d4b91c7f5,
            _7560cb67aa49=32,
            _fbf3a1614550=_6ba42ed9e571,
            _5b7fcd41c606=_e75782893652,     # for deterministic answers
            _1f0abe322f27=_e75782893652,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _eab76ddfd8f7 = []
        _06184fe9157e = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _750d1482b80f in _0638c39f3305(_96e77c0a512a):
            _eab76ddfd8f7._7293a3436d99(_bae596a25a55[_750d1482b80f])   # FULL sequence
            _06184fe9157e._7293a3436d99(_0a56d3aa120b[_750d1482b80f])          # FULL labels


        _7b25b1d2b198 = {
            "lang_codes": _8248b663a89c,
            "preds": _eab76ddfd8f7,
            "labels": _06184fe9157e,
            "sample_ids": _231aa48f70a5,
            "chunk_ids": _427c450ba75e,
            "word_positions": _a57ea82df12f,
            "prompt_lens": _37f3371303d3,
            "num_chunks": _56a3047229c7,
        }

        self._94a9e1fd9d90._7293a3436d99(_7b25b1d2b198)

        # Exact same cleanup as before
        del _d68d4b91c7f5, _0a56d3aa120b, _bae596a25a55, _eab76ddfd8f7, _06184fe9157e

        return _7b25b1d2b198

    def _40469816e56e(self):
        # pick correct device for this rank
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            if _93798b6ebff3._bffe434e3f41._0ea389cfc603():
                _713436df354b = _93798b6ebff3._bffe434e3f41._6d6df9f71591()
            else:
                _713436df354b = 0
            _93798b6ebff3._11cb931ce190._d62238c9af80(_713436df354b)
            self._6db2aff10bdd = _93798b6ebff3._1ab67dadd454(f"cuda:{_713436df354b}")
        else:
            self._6db2aff10bdd = _93798b6ebff3._1ab67dadd454("cpu")

        self._30c0f9d5f93b()
        
    def _54c907e2b78d(self):
        _c3bd6fa2d3a1 = _f16671dec8cc(self, "_test_outputs", _e75782893652)
        _cfe65d617e09(f"[DEBUG rank={_93798b6ebff3._bffe434e3f41._6d6df9f71591()}] outputs_len={_6fa24e8f3359(_c3bd6fa2d3a1)}")
        if not _c3bd6fa2d3a1:
            return

        _a689c9f98ff2, _16e30626b3db, _df60cb8507ae, _a6112b38288c = \
            self._5fda03c9b730(_c3bd6fa2d3a1)

        _71226ff96d2c, _cc42880e1c11 = [], []
        for _1768aacdec86 in _835bf9fcbd10(_df60cb8507ae._2ff5d0680b5c()):
            _30502c04d20c = _a689c9f98ff2[_1768aacdec86]._98e7d7bfd062()
            _43815abac0af = _16e30626b3db[_1768aacdec86]._98e7d7bfd062()
            _8227b7ced0b2 = _df60cb8507ae[_1768aacdec86]
            _4f08f0e097f5 = _a6112b38288c[_1768aacdec86]

            if _8227b7ced0b2._fe5fd09cbd19() > 0 and _4f08f0e097f5._fe5fd09cbd19() > 0:
                _71226ff96d2c._7293a3436d99(_8227b7ced0b2)
                _cc42880e1c11._7293a3436d99(_4f08f0e097f5)

        if not _71226ff96d2c:
            _cfe65d617e09("[TEST END] Nothing to score.")
            self._39c403a3c271._d5994296b7ee()
            return

        _7ba27ef18200 = _93798b6ebff3._6e1cccf08116(_71226ff96d2c)._05b61fc5c72d(_1ab67dadd454=self._f058c9c3ab41['micro_accuracy']._1ab67dadd454, _526db6377dd5=_bfaf21e8f1ce)
        _0a56d3aa120b = _93798b6ebff3._6e1cccf08116(_cc42880e1c11)._05b61fc5c72d(_1ab67dadd454=self._f058c9c3ab41['micro_accuracy']._1ab67dadd454, _526db6377dd5=_bfaf21e8f1ce)

        self._f058c9c3ab41['micro_accuracy']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_accuracy']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_precision']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_recall']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['macro_f1']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_accuracy']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_precision']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_recall']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['classwise_f1']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)
        self._f058c9c3ab41['confmat']._079dd6eff35b(_7ba27ef18200, _0a56d3aa120b)

        _7c8b50d8983c  = self._f058c9c3ab41['micro_accuracy']._7131993708f6()._2bc0251def91()
        _e33c28b9a5b8  = self._f058c9c3ab41['macro_accuracy']._7131993708f6()._2bc0251def91()
        _58a0277f7693 = self._f058c9c3ab41['macro_precision']._7131993708f6()._2bc0251def91()
        _f5d3ddb9d44a    = self._f058c9c3ab41['macro_recall']._7131993708f6()._2bc0251def91()
        _e32ec0b22515        = self._f058c9c3ab41['macro_f1']._7131993708f6()._2bc0251def91()

        self._fc76fcca2828("test_accuracy", _e33c28b9a5b8, _86c471169b89=_bfaf21e8f1ce)

        try:
            _1ec84ede0ec8 = self._f1216663ccbb
            _97403dd41e6b = {
                "epoch": [_1ec84ede0ec8],
                "class_names": [self._1e4a78dd72e4],
                "micro_accuracy": [_7c8b50d8983c],
                "macro_accuracy": [_e33c28b9a5b8],
                "macro_precision": [_58a0277f7693],
                "macro_recall": [_f5d3ddb9d44a],
                "macro_f1": [_e32ec0b22515],
                "classwise_accuracy": [self._f058c9c3ab41['classwise_accuracy']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "classwise_precision": [self._f058c9c3ab41['classwise_precision']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "classwise_recall": [self._f058c9c3ab41['classwise_recall']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "classwise_f1": [self._f058c9c3ab41['classwise_f1']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
                "confusion_matrix": [self._f058c9c3ab41['confmat']._7131993708f6()._05b61fc5c72d(_1ab67dadd454="cpu")._4015c538de24()._98e7d7bfd062()],
            }
            self._04be082d3bdd(_97403dd41e6b, f"test_final.csv", _3b3472ca4f75=self._3b3472ca4f75)
        except _15abe8b3010d as _10713e26fb79:
            _cfe65d617e09(f"[TEST END] save metrics FAILED: {_10713e26fb79}")

        # cleanup
        self._f058c9c3ab41['micro_accuracy']._6d559769edb3(); self._f058c9c3ab41['macro_accuracy']._6d559769edb3()
        self._f058c9c3ab41['macro_precision']._6d559769edb3(); self._f058c9c3ab41['macro_recall']._6d559769edb3(); self._f058c9c3ab41['macro_f1']._6d559769edb3()
        self._f058c9c3ab41['classwise_accuracy']._6d559769edb3(); self._f058c9c3ab41['classwise_precision']._6d559769edb3()
        self._f058c9c3ab41['classwise_recall']._6d559769edb3(); self._f058c9c3ab41['classwise_f1']._6d559769edb3()
        self._f058c9c3ab41['confmat']._6d559769edb3(); self._39c403a3c271._d5994296b7ee()
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            _93798b6ebff3._11cb931ce190._403e12664643()
        _cfe65d617e09("[TEST END] Finished and cleaned up.")

    def _97cc89b35b93(self, _7df4ed909fbb, _f3aed6051df4, _49e204083162=0):
        """Optimized prediction step with efficient memory handling."""
        _d68d4b91c7f5, _ = _7df4ed909fbb
        _d68d4b91c7f5 = _d68d4b91c7f5._05b61fc5c72d(self._6db2aff10bdd, _526db6377dd5=_bfaf21e8f1ce)
        _c3bd6fa2d3a1, _, _ = self(_d68d4b91c7f5)
        _279d3201f2a2 = _93798b6ebff3._96118bcee280(_c3bd6fa2d3a1, _b3561ed5dbe7=-1)
        del _d68d4b91c7f5, _c3bd6fa2d3a1
        if _93798b6ebff3._11cb931ce190._8dbd723b9c79():
            _93798b6ebff3._11cb931ce190._403e12664643()
        return {"predictions": _279d3201f2a2._a9cb52eef1f7()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _ca8b47e209cc(self, _c3bd6fa2d3a1, _ce573ae2d432=_bfaf21e8f1ce, _f59cbf0ae04e="cpu"):
        from collections import _459a586f6b23, _9ab3c67fe3dc
        import _93798b6ebff3
        _d294ea3eff64 = self._b2a09c79bbff
        def _4a7e8add5282(_4db82363fae7):
            if _cc97f3cd34f6(_4db82363fae7, _93798b6ebff3._2c2f9698b9a1): return _4db82363fae7._a58aae97523e()._05b61fc5c72d(_1ab67dadd454=_f59cbf0ae04e, _526db6377dd5=_bfaf21e8f1ce)._efce05cea4fa(-1)._98e7d7bfd062()
            return _16add58a9554(_4db82363fae7) if _cc97f3cd34f6(_4db82363fae7, (_16add58a9554, _2c1658a48f84)) else [_4db82363fae7]
        
        _a83b741a83a1 = _4cce9b3e0374()
        _a689c9f98ff2, _16e30626b3db, _8aeb370b3270 = {}, {}, []
        if _ce573ae2d432:
            _cfe65d617e09(f"[reconcile] start: num_outputs={_6fa24e8f3359(_c3bd6fa2d3a1)}")
        
        _713f4887e759 = _459a586f6b23(_16add58a9554)
        
        for _35c9bb096dfb in _c3bd6fa2d3a1:
            _231aa48f70a5     = _35c9bb096dfb["sample_ids"]
            _427c450ba75e      = _35c9bb096dfb["chunk_ids"]
            _32a9f22a377f    = _35c9bb096dfb["preds"]
            _51d0c41b3031   = _35c9bb096dfb["labels"]
            _a57ea82df12f = _35c9bb096dfb["word_positions"]
            _37f3371303d3    = _35c9bb096dfb["prompt_lens"]

            for _750d1482b80f, _1768aacdec86 in _340cb0cc7a0a(_231aa48f70a5):
                _388bc6818c75 = _7534c17e0a07(_427c450ba75e[_750d1482b80f])
                if (_1768aacdec86, _388bc6818c75) in _a83b741a83a1:
                    continue
                _a83b741a83a1._eb9c61162af7((_1768aacdec86, _388bc6818c75))

                _616739185256 = _7534c17e0a07(_37f3371303d3[_750d1482b80f])
                _70ea5337c5fc  = _137933295cdd(_a57ea82df12f[_750d1482b80f])
                _827ebdd1ad19    = _137933295cdd(_32a9f22a377f[_750d1482b80f])
                _04450ef7577f   = _137933295cdd(_51d0c41b3031[_750d1482b80f])

                _6dcf9da1ed7d  = [_b9910be6b60a for _b9910be6b60a in _827ebdd1ad19[_616739185256:] if _b9910be6b60a != _d294ea3eff64]
                _55ac71f507ee = [_16d639108ff1 for _16d639108ff1 in _04450ef7577f[_616739185256:] if _16d639108ff1 != _d294ea3eff64]

                if _1768aacdec86 not in _8aeb370b3270:
                    _8aeb370b3270._7293a3436d99(_1768aacdec86)

                _713f4887e759[_1768aacdec86]._7293a3436d99((_388bc6818c75, _70ea5337c5fc, _6dcf9da1ed7d, _55ac71f507ee))
        
        _3048f3224a03 = _e75782893652
        for _1768aacdec86 in _8aeb370b3270:
            _abca7736d1b6 = _713f4887e759[_1768aacdec86]
            _abca7736d1b6._c08babd51264(_cde82e824517=lambda _4db82363fae7: _4db82363fae7[0])
            if _3048f3224a03 is _e75782893652 and _6fa24e8f3359(_abca7736d1b6) > 1:
                _3048f3224a03 = _1768aacdec86
            
            _65538802c946 = _459a586f6b23(_16add58a9554)
            _7f45b3688091    = _459a586f6b23(_16add58a9554)
            _56e634aba648 = _459a586f6b23(_16add58a9554)
            _1c9ff7e6c00e    = _459a586f6b23(_16add58a9554)
            
            _d6b414ac90ab = _4cce9b3e0374()
            for _, _b842a343b846, _, _ in _abca7736d1b6:
                for _137946019431 in _b842a343b846:
                    if _137946019431 >= 0:
                        _d6b414ac90ab._eb9c61162af7(_137946019431)
            
            if not _d6b414ac90ab:
                continue
            
            _155f58bcf1cb = _835bf9fcbd10(_d6b414ac90ab)
            _e5c672db62a1 = _348c1b41a78f(_155f58bcf1cb)
            
            for _388bc6818c75, _b842a343b846, _7ba27ef18200, _0a56d3aa120b in _abca7736d1b6:
                _aa9f6c01be14 = _e75782893652
                _009b241a42e5 = []
                _dbb62673f76e = []
                for _11d4d2581d21, _c76fe88bb5ce, _c0051217dfff in _06419fbf5e2e(_b842a343b846, _7ba27ef18200, _0a56d3aa120b):
                    _360171b4c922 = _7534c17e0a07(_11d4d2581d21)
                    if _360171b4c922 >= 0:
                        if _360171b4c922 != _aa9f6c01be14:
                            if _aa9f6c01be14 is not _e75782893652:
                                _65538802c946[_aa9f6c01be14]._7293a3436d99(_009b241a42e5[:])
                                _56e634aba648[_aa9f6c01be14]._7293a3436d99(_dbb62673f76e[:])
                            _aa9f6c01be14 = _360171b4c922
                            _009b241a42e5 = [_7534c17e0a07(_c76fe88bb5ce)]
                            _dbb62673f76e = [_7534c17e0a07(_c0051217dfff)]
                        else:
                            _009b241a42e5._7293a3436d99(_7534c17e0a07(_c76fe88bb5ce))
                            _dbb62673f76e._7293a3436d99(_7534c17e0a07(_c0051217dfff))
                    else:
                        if _aa9f6c01be14 is not _e75782893652:
                            _7f45b3688091[_aa9f6c01be14]._7293a3436d99(_7534c17e0a07(_c76fe88bb5ce))
                            _1c9ff7e6c00e[_aa9f6c01be14]._7293a3436d99(_7534c17e0a07(_c0051217dfff))
                if _aa9f6c01be14 is not _e75782893652:
                    _65538802c946[_aa9f6c01be14]._7293a3436d99(_009b241a42e5[:])
                    _56e634aba648[_aa9f6c01be14]._7293a3436d99(_dbb62673f76e[:])
            
            _ca37e788380a = []
            _2d48f19cf225 = []
            _66a798c9f3b3 = _d973c8091bd0(_66b03b760dbc[0] for _66b03b760dbc in self._d2f3ff328be7 if self._d2f3ff328be7[_66b03b760dbc] == 0)
            _bbce2b26e2ac = self._b702943f1422
            
            for _0483c65f3537 in _155f58bcf1cb:
                _fac863ab4ffb = _65538802c946._990e95f70bed(_0483c65f3537, [])
                _54e045655f2a = _56e634aba648._990e95f70bed(_0483c65f3537, [])
                
                _de64dffb604b = _348c1b41a78f((_6fa24e8f3359(_dce527ed1e77) for _dce527ed1e77 in _fac863ab4ffb + _54e045655f2a), _85499d32c61e=0)
                
                if _de64dffb604b == 0:
                    continue
                
                _e282d71816d6 = []
                for _e712a598291f in _0638c39f3305(_de64dffb604b):
                    _e3e463e161e4 = [_dce527ed1e77[_e712a598291f] for _dce527ed1e77 in _fac863ab4ffb if _e712a598291f < _6fa24e8f3359(_dce527ed1e77)]
                    _e3e463e161e4 = [_04c57bbe6a60 for _04c57bbe6a60 in _e3e463e161e4 if _04c57bbe6a60 != _d294ea3eff64]
                    _68fd37928c91 = _9ab3c67fe3dc(_e3e463e161e4)._341e9b8e25a4(1)[0][0] if _e3e463e161e4 else _66a798c9f3b3
                    _e282d71816d6._7293a3436d99(_68fd37928c91)
                _ca37e788380a._e73c5cb9ca1a(_e282d71816d6)
                
                _45e8e0a3a1d6 = []
                for _e712a598291f in _0638c39f3305(_de64dffb604b):
                    _e3e463e161e4 = [_dce527ed1e77[_e712a598291f] for _dce527ed1e77 in _54e045655f2a if _e712a598291f < _6fa24e8f3359(_dce527ed1e77)]
                    _e3e463e161e4 = [_04c57bbe6a60 for _04c57bbe6a60 in _e3e463e161e4 if _04c57bbe6a60 != _d294ea3eff64]
                    _68fd37928c91 = _9ab3c67fe3dc(_e3e463e161e4)._341e9b8e25a4(1)[0][0] if _e3e463e161e4 else _d294ea3eff64
                    _45e8e0a3a1d6._7293a3436d99(_68fd37928c91)
                _2d48f19cf225._e73c5cb9ca1a(_45e8e0a3a1d6)
                
                if _0483c65f3537 < _e5c672db62a1:
                    _76bfc5269099 = [_04c57bbe6a60 for _04c57bbe6a60 in _7f45b3688091._990e95f70bed(_0483c65f3537, []) if _04c57bbe6a60 != _d294ea3eff64]
                    _6cf5f137d61e = _9ab3c67fe3dc(_76bfc5269099)._341e9b8e25a4(1)[0][0] if _76bfc5269099 else _bbce2b26e2ac
                    _ca37e788380a._7293a3436d99(_6cf5f137d61e)
                    
                    _11223bdf539f = [_04c57bbe6a60 for _04c57bbe6a60 in _1c9ff7e6c00e._990e95f70bed(_0483c65f3537, []) if _04c57bbe6a60 != _d294ea3eff64]
                    _8457b021b17b = _9ab3c67fe3dc(_11223bdf539f)._341e9b8e25a4(1)[0][0] if _11223bdf539f else _bbce2b26e2ac
                    _2d48f19cf225._7293a3436d99(_8457b021b17b)
            
            if _6fa24e8f3359(_ca37e788380a) > _6fa24e8f3359(_2d48f19cf225):
                _ca37e788380a = _ca37e788380a[:_6fa24e8f3359(_2d48f19cf225)]
            elif _6fa24e8f3359(_ca37e788380a) < _6fa24e8f3359(_2d48f19cf225):
                _ca37e788380a += [_66a798c9f3b3] * (_6fa24e8f3359(_2d48f19cf225) - _6fa24e8f3359(_ca37e788380a))
            
            _a689c9f98ff2[_1768aacdec86] = _93798b6ebff3._900181899e6d(_ca37e788380a, _1ab67dadd454=_f59cbf0ae04e)
            _16e30626b3db[_1768aacdec86] = _93798b6ebff3._900181899e6d(_2d48f19cf225, _1ab67dadd454=_f59cbf0ae04e)

        if _ce573ae2d432 and _3048f3224a03 is not _e75782893652:
            _cfe65d617e09(f"[SUMMARY] reconciled samples in batch = {_6fa24e8f3359(_8aeb370b3270)} \
                sid={_3048f3224a03} total_preds={_6fa24e8f3359(_a689c9f98ff2[_3048f3224a03])} total_labels={_6fa24e8f3359(_16e30626b3db[_3048f3224a03])} \
                    raw_preds {_a689c9f98ff2[_3048f3224a03]} and raw_labels{_16e30626b3db[_3048f3224a03]}\
                        chunks {_713f4887e759[_3048f3224a03]}")

        _f0d710cb140a = _b5dcd9b7b532(_6fa24e8f3359(_16d639108ff1) for _16d639108ff1 in _16e30626b3db._a1c4cdc86576())
        _cfe65d617e09(f"Total reconciled labels: {_f0d710cb140a}")
        _2ddd8df173cb, _bb290076cd0e = self._09ebce7dc46f(_a689c9f98ff2, _16e30626b3db, _ce573ae2d432=_ce573ae2d432, _f59cbf0ae04e=_f59cbf0ae04e)
        _645e6d82b21a = _b5dcd9b7b532(_6fa24e8f3359(_16d639108ff1) for _16d639108ff1 in _bb290076cd0e._a1c4cdc86576())
        _cfe65d617e09(f"Total reconciled labels classes: {_645e6d82b21a}")
        return _a689c9f98ff2, _16e30626b3db, _2ddd8df173cb, _bb290076cd0e

    def _20bcb3bc84d6(self, _a689c9f98ff2, _16e30626b3db, _ce573ae2d432=_bfaf21e8f1ce, _f59cbf0ae04e="cpu"):
        _d2f3ff328be7 = _f16671dec8cc(self, "seq2class", {})
        _23b5fcb90576 = _f16671dec8cc(self, "tokenizer_separator_token", _e75782893652)
        _d294ea3eff64 = _f16671dec8cc(self, "ignore_idx", -100)
        
        def _9331de27b83c(_136eff7d7c12, _1c1659a63303):
            _576a41c09959 = []
            _aa9f6c01be14 = []
            for _750d1482b80f, token in _340cb0cc7a0a(_136eff7d7c12):
                if token == _1c1659a63303 and _aa9f6c01be14:
                    _576a41c09959._7293a3436d99(_aa9f6c01be14)
                    _aa9f6c01be14 = []
                elif token != _1c1659a63303:
                    _aa9f6c01be14._7293a3436d99(token)
            if _aa9f6c01be14:
                _576a41c09959._7293a3436d99(_aa9f6c01be14)
            return _576a41c09959
        
        def _006524575a7c(_efef07d55aa6, _d2f3ff328be7, _ce573ae2d432, _1768aacdec86):
            _35c9bb096dfb = []
            _25289a0ddda7 = _835bf9fcbd10(_d2f3ff328be7._2ff5d0680b5c(), _cde82e824517=_6fa24e8f3359, _3eb363a5778c=_bfaf21e8f1ce)
            for _750d1482b80f, _140228bdcc5c in _340cb0cc7a0a(_efef07d55aa6, 1):
                _c3d32da51b28 = _2c1658a48f84(_140228bdcc5c)
                _4fbc533e21d4 = self._529f1a527d0b
                for _cde82e824517 in _25289a0ddda7:
                    if _6fa24e8f3359(_c3d32da51b28) >= _6fa24e8f3359(_cde82e824517) and _c3d32da51b28[:_6fa24e8f3359(_cde82e824517)] == _cde82e824517:
                        _4fbc533e21d4 = _d2f3ff328be7[_cde82e824517]
                        break
                _35c9bb096dfb._7293a3436d99(_4fbc533e21d4)

            return _35c9bb096dfb
        
        _df60cb8507ae, _a6112b38288c = {}, {}
        for _1768aacdec86 in _a689c9f98ff2:
            _b9910be6b60a = _a689c9f98ff2[_1768aacdec86]
            _16d639108ff1 = _16e30626b3db._990e95f70bed(_1768aacdec86, _e75782893652)
            _7ba27ef18200 = _b9910be6b60a._98e7d7bfd062() if _cc97f3cd34f6(_b9910be6b60a, _93798b6ebff3._2c2f9698b9a1) else _16add58a9554(_b9910be6b60a)
            _0a56d3aa120b = _16d639108ff1._98e7d7bfd062() if _cc97f3cd34f6(_16d639108ff1, _93798b6ebff3._2c2f9698b9a1) else _16add58a9554(_16d639108ff1) if _16d639108ff1 else _e75782893652
            if _0a56d3aa120b is not _e75782893652:
                _95f7a3f39f28 = _b410470fab71(_0a56d3aa120b, _23b5fcb90576)
                _5b431371e0b5 = _fbd03ef514cc(_95f7a3f39f28, _d2f3ff328be7, _1768aacdec86 == 1 or _ce573ae2d432, _1768aacdec86)
                _28aa8b4e1172 = _b410470fab71(_7ba27ef18200, _23b5fcb90576)
                _73d8c5fd7e20 = _fbd03ef514cc(_28aa8b4e1172, _d2f3ff328be7, _1768aacdec86 == 1 or _ce573ae2d432, _1768aacdec86)
                if _6fa24e8f3359(_73d8c5fd7e20) < _6fa24e8f3359(_5b431371e0b5):
                    _73d8c5fd7e20 += [0] * (_6fa24e8f3359(_5b431371e0b5) - _6fa24e8f3359(_73d8c5fd7e20))
                elif _6fa24e8f3359(_73d8c5fd7e20) > _6fa24e8f3359(_5b431371e0b5):
                    _73d8c5fd7e20 = _73d8c5fd7e20[:_6fa24e8f3359(_5b431371e0b5)]
            else:
                _28aa8b4e1172 = _b410470fab71(_7ba27ef18200, _23b5fcb90576)
                _73d8c5fd7e20 = _fbd03ef514cc(_28aa8b4e1172, _d2f3ff328be7, _1768aacdec86 == 1 or _ce573ae2d432, _1768aacdec86)
                _5b431371e0b5 = [_d294ea3eff64] * _6fa24e8f3359(_73d8c5fd7e20)
            _df60cb8507ae[_1768aacdec86] = _93798b6ebff3._900181899e6d(_73d8c5fd7e20, _1ab67dadd454=_f59cbf0ae04e, _89fe9fce5a0e=_93798b6ebff3._0d33bbbfdeeb)
            _a6112b38288c[_1768aacdec86] = _93798b6ebff3._900181899e6d(_5b431371e0b5, _1ab67dadd454=_f59cbf0ae04e, _89fe9fce5a0e=_93798b6ebff3._0d33bbbfdeeb)
        return _df60cb8507ae, _a6112b38288c

    def _0776e9bc6599(self, _7ce6c54a06e2):
        _93798b6ebff3._fddbd1ba5163._9ead87a429d4._c726b66c4382(self._c26928b89f7c(), _1c8f768c0a3a=1.0)
    
    def _de8a5fc7e6a3(self, _7ce6c54a06e2):
        for _f49daefe7d65 in self._c26928b89f7c():
            if _f49daefe7d65 is not _e75782893652:
                _f49daefe7d65._c5166620bd1b._cbac11922085(-5, 5)

    def _5eb96dc74b1d(self):
        _f86cb6e8910a = 0
        for _f49daefe7d65 in self._c26928b89f7c():
            if _f49daefe7d65._52eda3e78b57 is not _e75782893652:
                _500e123e1402 = _f49daefe7d65._52eda3e78b57._a58aae97523e()._c5166620bd1b._915c29ac5707(2)
                _f86cb6e8910a += _500e123e1402._2bc0251def91() ** 2
        return _f86cb6e8910a ** 0.5  # L2 norm

    def _9605f9200c6c(self):
        _0596c0c5f4ba = [_b9910be6b60a for _b9910be6b60a in self._c26928b89f7c() if _b9910be6b60a._14b204165982]
        if not _0596c0c5f4ba:
            _cfe65d617e09("No trainable parameters. Skipping optimizer creation.")
            return _e75782893652
        
        _cfc848f7a9ca = _fb593deab6ae(lambda _b9910be6b60a: _b9910be6b60a._14b204165982, self._c26928b89f7c())

        _50c8f26ecc27 = {
            "adamw": _93798b6ebff3._b49344a6cf21._008e2fdc21fe,
            "adamax": _93798b6ebff3._b49344a6cf21._ce24e55fe18a,
            "adam": _93798b6ebff3._b49344a6cf21._2245ee7ba6aa,
        }
        _37b47d276411 = _50c8f26ecc27._990e95f70bed(self._b3d77507af16._07c13b998630(), _93798b6ebff3._b49344a6cf21._2245ee7ba6aa)

        _7ce6c54a06e2 = _37b47d276411(_cfc848f7a9ca, _f768cc074088=self._33c1f40507f2._f768cc074088, _445ed4109399=0.001)

        _709e5025987c = self._7d9b2049da39._c13457725c8f
        _aa6a06390f32 = math._b855c58443e6(0.1 * _709e5025987c)

        _92f7f08603e5 = _93798b6ebff3._b49344a6cf21._d82a7c5ebf98._73c701477f99(_7ce6c54a06e2, _308220c3531a=lambda _7b3c7b0cb9cc: (_7b3c7b0cb9cc + 1) / _aa6a06390f32)

        _17a61bc13381 = _93798b6ebff3._b49344a6cf21._d82a7c5ebf98._496705a651dd(
            _7ce6c54a06e2,
            _13ce2493676d=_348c1b41a78f(1, _709e5025987c - _aa6a06390f32),
            _b8039d18fc98=2,
            _97ac7a37a8ca=1e-6
        )
        _d82a7c5ebf98 = _93798b6ebff3._b49344a6cf21._d82a7c5ebf98._2f8df18f972b(
            _7ce6c54a06e2,
            _03c399eb126f=[_92f7f08603e5, _17a61bc13381],
            _c21e9c0467da=[_aa6a06390f32]
        )
        return {"optimizer": _7ce6c54a06e2, "lr_scheduler": {"scheduler": _d82a7c5ebf98, "interval": "epoch", "monitor": "val_loss"}}
