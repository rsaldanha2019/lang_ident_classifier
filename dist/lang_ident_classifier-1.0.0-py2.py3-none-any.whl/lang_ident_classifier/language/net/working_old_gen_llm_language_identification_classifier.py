# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from collections import _94ae7cf05fb7
import copy
from _98babb06ccb6 import _889ed3a9aeea
import _012c0519a8c5
import math
import os
from typing import _4bb238427266
import _e8d64e4f9d82 as _e9b360196950
import _d77b2ec5464e as _3bb4c2af4264
import _1f8391c25d8a
import _9ad19b6e4e96 as _b9a57d0b02be
from _9caf25b4cece._e2b25a564296._0c4d190ce8bc._be40952d7b31 import _f91612bbaa0d
from _06db6ed2db64 import _445134f57550, _787cc61eba55, _3dbfe294778f, _fbfeb189e911, _81d8bdc3aada

from _4a57d0beb0fd._bd3030829aa0._f9ba8d44fa75._43c1c6343e4a import _fa1673317482
from _4a57d0beb0fd._bd3030829aa0._22c6682a9281._1c6354a4d183 import _9e614805fce5
from _4a57d0beb0fd._bd3030829aa0._22c6682a9281._f7988bbba75b import _5ce59ffa7a1c
from _4a57d0beb0fd._bd3030829aa0._22c6682a9281._1cd40090ad33 import _3bf42766b0ef
from _4a57d0beb0fd._bd3030829aa0._f8abd78ec9dd._b039e78d64fb import _fb78b833be6e
# expose only the classifier from the module
_b1a840c1b3fa = ["GenLLMLanguageIdentificationClassifier"]

_0c3a89bf078d = 'cuda' if _1f8391c25d8a._866331966c7c._57452291d6c6() else 'cpu'
_1fdf979912ab = _9dd4dec2f1c9  # global frozen embedding (kept for compatibility)

    
class _056cf7e5c010(_b9a57d0b02be._a272ba6c078e):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _e7617c64c2be(_1f8391c25d8a._3e9d2081bce2._9ad672b61fd7):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _22a2398847ef(self, _4c09c4b05104: _b6f63f227d33, _d43e53512899: _b6f63f227d33 = 64):
            _7216ad2e2bf5()._1aaf70ef4742()
            self._da5b76daab28 = _1f8391c25d8a._3e9d2081bce2._381e8cfb782f(_4c09c4b05104, _d43e53512899, _b1cdb6f26ae4=_9cc4b43b27dc)
            self._299ce25f2fd4 = _1f8391c25d8a._3e9d2081bce2._01839ef7f3e2(_99f548c958fd=_933f44d53181)
            self._8bb5cfb80669 = _1f8391c25d8a._3e9d2081bce2._381e8cfb782f(_d43e53512899, _4c09c4b05104, _b1cdb6f26ae4=_9cc4b43b27dc)
            # start adapter near-zero so initial behavior is identity
            _1f8391c25d8a._3e9d2081bce2._77e4f2d35b2b._40795c0fd463(self._8bb5cfb80669._3198240ba49b)
            _1f8391c25d8a._3e9d2081bce2._77e4f2d35b2b._73f2ce1bbd80(self._da5b76daab28._3198240ba49b, _75f8c17b479e=math._80627c5657b5(5))

        def _c04f96287461(self, _66fc5431d49f: _1f8391c25d8a._cf02ae8569a7) -> _1f8391c25d8a._cf02ae8569a7:
            # supports x shape (B, L, D) or (B, D)
            if _66fc5431d49f._4c09c4b05104() == 2:
                _0c8f88d30676 = self._8bb5cfb80669(self._299ce25f2fd4(self._da5b76daab28(_66fc5431d49f)))
                return _66fc5431d49f + _0c8f88d30676
            _bb4197dcc997, _311ecd83ef27, _1949f9c48897 = _66fc5431d49f._3154440a69a0
            _0460e80487f4 = _66fc5431d49f._5c310c457d52(-1, _1949f9c48897)                    # (B*L, D)
            _0460e80487f4 = self._8bb5cfb80669(self._299ce25f2fd4(self._da5b76daab28(_0460e80487f4)))  # (B*L, D)
            _0460e80487f4 = _0460e80487f4._5c310c457d52(_bb4197dcc997, _311ecd83ef27, _1949f9c48897)
            return _66fc5431d49f + _0460e80487f4
        
    class _2d1aefb1de90(_1f8391c25d8a._3e9d2081bce2._9ad672b61fd7):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _22a2398847ef(self, _efb047ed1eb4, _dfdf4d55ee61=-5, _4080cb195a06=5):
            _7216ad2e2bf5()._1aaf70ef4742()
            self._efb047ed1eb4 = _efb047ed1eb4
            self._dfdf4d55ee61 = _dfdf4d55ee61
            self._4080cb195a06 = _4080cb195a06
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _c04f96287461(self, *_806e14d5b7e6, **_752d868a02bb):
            _806e14d5b7e6 = _3942976c761f(
                _a32c5262d831._51fedc788d0f(_1f8391c25d8a._1ad56d355ddc)._92005295123e(-10, 10) if _9dc4a511b2b9(_a32c5262d831, _1f8391c25d8a._cf02ae8569a7) and _a32c5262d831._ae7e1b63f6e5 != _1f8391c25d8a._1ad56d355ddc else _a32c5262d831
                for _a32c5262d831 in _806e14d5b7e6
            )
            for _b8b35b8b95d7, _a32c5262d831 in _57c78ca28b3f(_806e14d5b7e6):
                if _9dc4a511b2b9(_a32c5262d831, _1f8391c25d8a._cf02ae8569a7) and not _1f8391c25d8a._81f58c47268f(_a32c5262d831)._0d87c09dad3f():
                    _a32c5262d831 = _1f8391c25d8a._1a2467c90e2e(_a32c5262d831)
            _361559ffbf68 = self._efb047ed1eb4(*_806e14d5b7e6, **_752d868a02bb)
            if _9dc4a511b2b9(_361559ffbf68, _1f8391c25d8a._cf02ae8569a7):
                _361559ffbf68 = _361559ffbf68._51fedc788d0f(_1f8391c25d8a._1ad56d355ddc)
                if not _1f8391c25d8a._81f58c47268f(_361559ffbf68)._0d87c09dad3f():
                    _361559ffbf68 = _1f8391c25d8a._1a2467c90e2e(_361559ffbf68)
                _361559ffbf68._6cf961db544a(self._dfdf4d55ee61, self._4080cb195a06)
            return _361559ffbf68

    # --- original __init__ signature and body preserved ---
    def _22a2398847ef(
        self,
        _5839619b9042,
        _45409901e504,
        _ccd5ab415151,
        _83f723ce2f93,
        _765b3df88285,
        _e57623bc2867,
        _95fc30c6a723,
        _fdc010bef8a4,
        _6e4a4d5953a5,
        _805d608085e9,
        _466f0738f5b7,
        _58eb6a8c861a: _b6f63f227d33 = 20,
        _f46a626181df = _9dd4dec2f1c9,
        _663d2e3c4d67=_9dd4dec2f1c9,
        _e849565bb81e=0.9,
        _f7617f12bc7a:_9b440b89d49c=_9dd4dec2f1c9,
    ):
        _7216ad2e2bf5(_d851a1f1afb1, self)._1aaf70ef4742()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._a610bc62e5e3({
            "lr": _15458df9d9dd(_ccd5ab415151),
            "optimizer": _9b440b89d49c(_83f723ce2f93),
            "num_backbone_model_units_unfrozen": _b6f63f227d33(_95fc30c6a723),
            "loss_type": _9b440b89d49c(_fdc010bef8a4),
            "is_train": _416f3301e509(_6e4a4d5953a5),
            "random_seed": _b6f63f227d33(_58eb6a8c861a),
        })
        self._58eb6a8c861a = _58eb6a8c861a
        _b9a57d0b02be._1017a54b3212(_58eb6a8c861a, _411ddb753e22=_933f44d53181)
        _1f8391c25d8a._7642a4ecf67d(_58eb6a8c861a)
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            _1f8391c25d8a._866331966c7c._4e6a8144ab72(_58eb6a8c861a)
        _e9b360196950.random._4a7ba0f3a290(_58eb6a8c861a)
        self._663d2e3c4d67 = _b6f63f227d33(_663d2e3c4d67) if _663d2e3c4d67 is not _9dd4dec2f1c9 else _9dd4dec2f1c9
        self._805d608085e9 = _805d608085e9
        self._f7617f12bc7a = _f7617f12bc7a
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._805d608085e9._9ac00857dfde and "<PAD>" not in self._805d608085e9._3a3e7e89225d():
            self._805d608085e9._1632e4523df9(["<PAD>"], _e10ce68abaa1=_9cc4b43b27dc)
            _0b66f0fc17a7 = self._805d608085e9._c0c784263274("<PAD>")
            _b066cff2a533(f"Added padding token  <PAD> with (id: {_0b66f0fc17a7})")
        
        self._9015caf95d75 = _805d608085e9._c7f008abe1f5(" ", _51cadd8f4528=_9cc4b43b27dc)[0]
        self._f2605f2613b5 = (
            _1f8391c25d8a._0c6d7db9100c("cuda:{}"._891a96bccb60(_e57623bc2867["gpu_local_rank"]))
            if _e57623bc2867["gpu_local_rank"] != -1
            else "cpu"
        )
        self._f46a626181df = _f46a626181df
        self._e849565bb81e = _e849565bb81e
        self._45409901e504 =  ["unk"] + _45409901e504 if self._e849565bb81e > 0 else _45409901e504
        self._bea3bb72f468 = _15f81e41435c(self._45409901e504)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._75873e456f59 = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _fad76a2e714c in self._45409901e504:
            if _15f81e41435c(self._805d608085e9._c7f008abe1f5(_fad76a2e714c, _51cadd8f4528=_9cc4b43b27dc)) > 1:
                token = f"{_fad76a2e714c}"
                if token not in self._805d608085e9._3a3e7e89225d():
                    self._805d608085e9._1632e4523df9([token], _e10ce68abaa1=_9cc4b43b27dc)
                    _0b66f0fc17a7 = self._805d608085e9._c0c784263274(token)
                    _b066cff2a533(f"Added class '{_fad76a2e714c}' Token: {token} (id: {_0b66f0fc17a7})")

        # Map every class to single token ID
        self._75873e456f59 = {
            _68581fb94c01: [self._805d608085e9._c0c784263274(f"{_fad76a2e714c}")]
            for _68581fb94c01, _fad76a2e714c in _57c78ca28b3f(self._45409901e504)
        }

        self._b09fb68d8fbe = {_3942976c761f(_ee0fd82e4085): _06018981cd55 for _06018981cd55, _ee0fd82e4085 in self._75873e456f59._2acacd5cb0b5()}
        self._cd1651b240d5 = _94ae7cf05fb7(_03e16f5514e2)
        for _4d13ff7c4202, _ee0fd82e4085 in self._75873e456f59._2acacd5cb0b5():
            self._cd1651b240d5[_15f81e41435c(_ee0fd82e4085)]._c3dbc972a2d7((_4d13ff7c4202, _ee0fd82e4085))
        self._df35fad62951 = 0
        _b066cff2a533(f"SEQ {self._75873e456f59} and {self._b09fb68d8fbe}")
        self._d457c19fe425 = _805d608085e9._9ac00857dfde or _805d608085e9._865c168e3585
        self._765b3df88285 = _765b3df88285
        self._671c9364a741 = "multiclass"
        self._1db22fb718b5 = -100
        self._8997c29fc36f = _805d608085e9._c7f008abe1f5("assistant<|end_header_id|>\n\n", _51cadd8f4528=_9cc4b43b27dc)
        self._afe00ca678e1 = self._a75a4cf2d489()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._c587a2f2997e = _5839619b9042
        # Resize vocab based token embeddings
        self._c587a2f2997e._85bd5953c9d5(_15f81e41435c(self._805d608085e9))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._c587a2f2997e._edd1d674c55b(_9cc4b43b27dc)
        _7ecdae1d5afb = _fb78b833be6e()  # bfloat16 or float16

        for _a87e52c2b394, _efb047ed1eb4 in self._d121344f571a():
            if not _8b987aee18cc(_6241b74ed14c._1e5860305c6a for _6241b74ed14c in _efb047ed1eb4._6afe756ccf67(_7db572dfd6c8=_9cc4b43b27dc)):
                # FROZEN → BF16 (save memory)
                _efb047ed1eb4._51fedc788d0f(_ae7e1b63f6e5=_7ecdae1d5afb)
            else:
                # TRAINABLE → FP32 (stable grads)
                _efb047ed1eb4._51fedc788d0f(_ae7e1b63f6e5=_1f8391c25d8a._1ad56d355ddc)
        self._c587a2f2997e._51fedc788d0f(self._f2605f2613b5)
        if _0e98ea4f0f2c(self._c587a2f2997e, "gradient_checkpointing_enable"):
            self._c587a2f2997e._648ffccac37a()
        # determine embedding dim robustly from model config if available
        _09336afc33a4 = _9b638b7cdb4d(_9b638b7cdb4d(self._c587a2f2997e, "config", _9dd4dec2f1c9), "hidden_size", _9dd4dec2f1c9)
        if _09336afc33a4 is _9dd4dec2f1c9:
            # fallback to common default — change if your model uses a different hidden size
            _09336afc33a4 = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _0e98ea4f0f2c(self._c587a2f2997e, "lm_head") and _9b638b7cdb4d(self._c587a2f2997e, "lm_head") is not _9dd4dec2f1c9:
            self._87c4fd3f614d = self._c587a2f2997e._65936aebccc8
        else:
            _ff124cf3e1b3 = _9b638b7cdb4d(self._c587a2f2997e, "get_output_embeddings", _9dd4dec2f1c9)
            self._87c4fd3f614d = _ff124cf3e1b3() if _1b43118c9580(_ff124cf3e1b3) else _9dd4dec2f1c9

        # mark presence and ensure module (if any) is on the same device
        self._a8bd2087ac8a = self._87c4fd3f614d is not _9dd4dec2f1c9
        if self._a8bd2087ac8a:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._87c4fd3f614d._51fedc788d0f(self._f2605f2613b5)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._5ee958ce45df = self._88c8bc7c4aac(_4c09c4b05104=_09336afc33a4, _d43e53512899=64)
        self._5ee958ce45df._51fedc788d0f(self._f2605f2613b5)
        for _6241b74ed14c in self._5ee958ce45df._6afe756ccf67():
            _6241b74ed14c._1e5860305c6a = _933f44d53181
            
        if _95fc30c6a723 > 0:
            if "llama" in self._f46a626181df:
                for _c5ac3c413f74 in self._c587a2f2997e._6afe756ccf67():
                    if not _c5ac3c413f74._428d0c08a8e2:
                        _c5ac3c413f74 = _c5ac3c413f74._6cfaa9e67501()
                    _c5ac3c413f74._1e5860305c6a = _9cc4b43b27dc  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _a7c9ed74bc21 = self._c587a2f2997e._c404207b8e10._64c77451098c  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _184bab448316 in _a7c9ed74bc21[-_95fc30c6a723:]:
                    for _c5ac3c413f74 in _184bab448316._6afe756ccf67():
                        if _9dc4a511b2b9(_c5ac3c413f74, _1f8391c25d8a._cf02ae8569a7) and (_c5ac3c413f74._bb7228759eb2() or _1f8391c25d8a._34263673f852(_c5ac3c413f74)):
                            _c5ac3c413f74._1e5860305c6a = _933f44d53181
                if _0e98ea4f0f2c(self._c587a2f2997e, "lm_head"):
                    self._c587a2f2997e._65936aebccc8._1e5860305c6a = _933f44d53181

        self._176d596a97af = 1
        _b066cff2a533(f"DEBUG xth_batch init {self._176d596a97af}")
        global _1fdf979912ab
        _1fdf979912ab = copy._82bf7f24bdd8(self._c587a2f2997e)._b449334bbf0e()
        self._ccd5ab415151 = _ccd5ab415151

        self._43ec507a84f1 = {}
        self._d9b1fdaf78de = {}

        # Loss function initialization
        if _fdc010bef8a4._db3e61ea2f8c() == "class_weighted_cross_entropy_loss":
            self._d9b1fdaf78de['criterion'] = _5ce59ffa7a1c(_765b3df88285=self._765b3df88285,
                                                            _0c6d7db9100c=self._f2605f2613b5,
                                                            _bad305b2a7b4=self._1db22fb718b5,
                                                            _5cb07e008b41=self._9015caf95d75)
        elif _fdc010bef8a4._db3e61ea2f8c() == "focal_loss":
            self._d9b1fdaf78de['criterion'] = _3bf42766b0ef(_ff6c01fd318a=0.25,
                                                     _0c6d7db9100c=self._f2605f2613b5,
                                                     _bad305b2a7b4=self._1db22fb718b5,
                                                     _5cb07e008b41=self._9015caf95d75)
        elif _fdc010bef8a4._db3e61ea2f8c() == "class_weighted_focal_loss":
            self._d9b1fdaf78de['criterion'] = _3bf42766b0ef(_ff6c01fd318a=self._765b3df88285,
                                                     _0c6d7db9100c=self._f2605f2613b5,
                                                     _bad305b2a7b4=self._1db22fb718b5,
                                                     _5cb07e008b41=self._9015caf95d75)
        elif _fdc010bef8a4._db3e61ea2f8c() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._d9b1fdaf78de['criterion'] = _9e614805fce5(_ff6c01fd318a=self._765b3df88285,
                                                                      _083cc72773d0='type1',
                                                                      _0c6d7db9100c=self._f2605f2613b5,
                                                                      _bad305b2a7b4=self._1db22fb718b5,
                                                                      _5cb07e008b41=self._9015caf95d75)
        elif _fdc010bef8a4._db3e61ea2f8c() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._d9b1fdaf78de['criterion'] = _9e614805fce5(_ff6c01fd318a=self._765b3df88285,
                                                                      _083cc72773d0='type2',
                                                                      _0c6d7db9100c=self._f2605f2613b5,
                                                                      _bad305b2a7b4=self._1db22fb718b5,
                                                                      _5cb07e008b41=self._9015caf95d75)
        elif _fdc010bef8a4._db3e61ea2f8c() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._d9b1fdaf78de['criterion'] = _9e614805fce5(_ff6c01fd318a=self._765b3df88285,
                                                                      _083cc72773d0='type3',
                                                                      _0c6d7db9100c=self._f2605f2613b5,
                                                                      _bad305b2a7b4=self._1db22fb718b5,
                                                                      _5cb07e008b41=self._9015caf95d75)
        else:
            self._d9b1fdaf78de['criterion'] = _5ce59ffa7a1c(_0c6d7db9100c=self._f2605f2613b5,
                                                            _bad305b2a7b4=self._1db22fb718b5,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._f3c520014035 = 0.99
        self._bac44a4819be = 0.3
        self._ff0bc8e5a721 = 0.30
        self._0bc72980a923 = 0.25
        self._82eb50a29011 = 0.6
        self._465de0d13f65 = 0.995
        self._81df44b6fc16 = 0.60
        self._28ee3443e44c = 0.20
        self._9c9851e28aaa = _9b638b7cdb4d(self, "batch_counter", 0)


        self._7c4747302256 = []
        self._497f446b528c = []

        self._5331e981f1a1 = _83f723ce2f93._db3e61ea2f8c()
        self._86e91b6dff58()

        self._3561eabb08f0(self._c587a2f2997e)
    
    def _27176cbf2710(self):
        # rebuild all metrics on the correct device
        self._43ec507a84f1['micro_accuracy'] = _445134f57550(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f="micro",
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['macro_accuracy'] = _445134f57550(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f="macro",
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['macro_precision'] = _3dbfe294778f(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f="macro",
            _7bb5ca06203c=self. _671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['macro_recall'] = _fbfeb189e911(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f="macro",
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['macro_f1'] = _81d8bdc3aada(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f="macro",
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['classwise_accuracy'] = _445134f57550(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f=_9dd4dec2f1c9,
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['classwise_precision'] = _3dbfe294778f(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f=_9dd4dec2f1c9,
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['classwise_recall'] = _fbfeb189e911(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f=_9dd4dec2f1c9,
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['classwise_f1'] = _81d8bdc3aada(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _b650967d8d9f=_9dd4dec2f1c9,
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)

        self._43ec507a84f1['confmat'] = _787cc61eba55(
            _bea3bb72f468=_15f81e41435c(self._45409901e504),
            _7bb5ca06203c=self._671c9364a741,
            _bad305b2a7b4=self._1db22fb718b5,
        )._51fedc788d0f(self._f2605f2613b5)


    def _4a6036b35d9c(self, _b1effe89ba8b=_9dd4dec2f1c9):
        """Calculate batch counts and set xth_batch_to_consider."""
        _d09294932f48 = 0
        _fc426203e18b = 0
        if self._2ff0b9d9e112._e96bcf6ad667 is not _9dd4dec2f1c9:
            if _0e98ea4f0f2c(self._2ff0b9d9e112._e96bcf6ad667, 'train_dataset') and self._2ff0b9d9e112._e96bcf6ad667._2baaddb74fba is not _9dd4dec2f1c9:
                _d09294932f48 = _15f81e41435c(self._2ff0b9d9e112._e96bcf6ad667._2baaddb74fba)
            if _0e98ea4f0f2c(self._2ff0b9d9e112._e96bcf6ad667, 'val_dataset') and self._2ff0b9d9e112._e96bcf6ad667._0379eba7a16a is not _9dd4dec2f1c9:
                _fc426203e18b = _15f81e41435c(self._2ff0b9d9e112._e96bcf6ad667._0379eba7a16a)
            _c6d3e4c68a0a = self._2ff0b9d9e112._e96bcf6ad667._c6d3e4c68a0a
            _49020ab2a819 = (_d09294932f48 + _c6d3e4c68a0a - 1) // _c6d3e4c68a0a if _d09294932f48 > 0 else 1
            _9a7036adbb0f = (_fc426203e18b + _c6d3e4c68a0a - 1) // _c6d3e4c68a0a if _fc426203e18b > 0 else 1
            _47cef3b31373 = _b5f11d4a1417(_49020ab2a819, _9a7036adbb0f) if _fc426203e18b > 0 else _49020ab2a819
            _e40306b789a9 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._176d596a97af = 1
            _b066cff2a533(f"DEBUG Batch Info: num_train_batches={_49020ab2a819}, num_val_batches={_9a7036adbb0f}, xth_batch_to_consider={self._176d596a97af}")

    def _7759c4954efd(self, _c121f9f06cf2, _adab96b0cd2a):
        if _c121f9f06cf2._db3e61ea2f8c() == "parametric_relu":
            return _1f8391c25d8a._3e9d2081bce2._636b2067afa3(_adab96b0cd2a=1)
        elif _c121f9f06cf2._db3e61ea2f8c() == "leaky_relu":
            return _1f8391c25d8a._3e9d2081bce2._eee695b7d29b(_99f548c958fd=_9cc4b43b27dc)
        else:
            return _1f8391c25d8a._3e9d2081bce2._01839ef7f3e2(_99f548c958fd=_9cc4b43b27dc)

    def _08a51288eaf5(self, _efb047ed1eb4, _d9243d886aa1=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _a87e52c2b394, _bb6c11f2ad6c in _efb047ed1eb4._c9a9ee34852e():
            _10dc0e168496 = f"{_d9243d886aa1}.{_a87e52c2b394}" if _d9243d886aa1 else _a87e52c2b394

            def _b9d2f986dee0(_de8f5388c268, _a32c5262d831, _0c8f88d30676):
                if _9dc4a511b2b9(_0c8f88d30676, _1f8391c25d8a._cf02ae8569a7) and _0c8f88d30676._08099ca762b3()._8b987aee18cc():
                    _b066cff2a533(f"NaN detected in {_10dc0e168496} ({_de8f5388c268._54d003aaed41.__name__}) ({_0c8f88d30676._ae7e1b63f6e5})")

            _bb6c11f2ad6c._932ad4936786(_00bf6550ac91)

            self._3561eabb08f0(_bb6c11f2ad6c, _10dc0e168496)

    def _2412236ecbc7(self, _efb047ed1eb4):
        return _8b987aee18cc(_6241b74ed14c._1e5860305c6a for _6241b74ed14c in _efb047ed1eb4._6afe756ccf67())

    def _38b0955b1469(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _33b7bbe4b709 = []
        for _a87e52c2b394, _efb047ed1eb4 in self._d121344f571a():
            if not self._042fb6f06e4b(_efb047ed1eb4):
                continue
            _8ad7dabbb9a1 = (
                "norm" in _a87e52c2b394._096ff9a6ff19() or 
                "linear4bit" in _a87e52c2b394._096ff9a6ff19() or 
                _8b987aee18cc(_299ce25f2fd4 in _a87e52c2b394._096ff9a6ff19() for _299ce25f2fd4 in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _a87e52c2b394._096ff9a6ff19() or 
                "dropout" in _a87e52c2b394._096ff9a6ff19() or 
                _9dc4a511b2b9(_efb047ed1eb4, (_f91612bbaa0d, _1f8391c25d8a._3e9d2081bce2._381e8cfb782f, _1f8391c25d8a._3e9d2081bce2._7872c11ca00b))
            )
            if _8ad7dabbb9a1:
                if _0e98ea4f0f2c(_efb047ed1eb4, "eps"):
                    _efb047ed1eb4._f017252a5af1 = 1e-3
                _efb047ed1eb4 = _efb047ed1eb4._51fedc788d0f(_1f8391c25d8a._1ad56d355ddc)
                if not _9dc4a511b2b9(_efb047ed1eb4, _d851a1f1afb1._deec11c9a9a6):
                    _33b7bbe4b709._c3dbc972a2d7((_a87e52c2b394, _d851a1f1afb1._deec11c9a9a6(_efb047ed1eb4, _dfdf4d55ee61=-10, _4080cb195a06=10)))
        for _a87e52c2b394, _99e144238867 in _33b7bbe4b709:
            _ba0a750b5be8, _a450782f8974 = self._c6b7d2d4992e(_a87e52c2b394)
            if _ba0a750b5be8 is not _9dd4dec2f1c9:
                _ee201e071f94(_ba0a750b5be8, _a450782f8974, _99e144238867)

    def _acd2c38a168b(self, _3188a63b286d):
        """Finds the parent module and attribute name given the full module path."""
        _8f16cf1c0663 = _3188a63b286d._b2245437d2dc('.')
        _07c9d91a45d4 = self
        for _bf8408335245 in _8f16cf1c0663[:-1]:
            _07c9d91a45d4 = _9b638b7cdb4d(_07c9d91a45d4, _bf8408335245, _9dd4dec2f1c9)
            if _07c9d91a45d4 is _9dd4dec2f1c9:
                return _9dd4dec2f1c9, _9dd4dec2f1c9
        return _07c9d91a45d4, _8f16cf1c0663[-1]

    def _1ec2c4ca060e(self, _0a2229388cc9: _1f8391c25d8a._cf02ae8569a7, _e27eb07644ac: _1f8391c25d8a._cf02ae8569a7, _d550ffe902e4: _1f8391c25d8a._cf02ae8569a7) -> _69b8d2e84862:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _0c6d7db9100c = _0a2229388cc9._0c6d7db9100c

        # 1) gating w (use cached per-example teacher_conf if available)
        _b0f676046ac7 = _9b638b7cdb4d(self, "_last_teacher_conf", _9dd4dec2f1c9)
        if _b0f676046ac7 is _9dd4dec2f1c9:
            # no teacher info => w = 0 (no distillation)
            _8106aecc184a = 0.0
        else:
            _7f2597264bb8 = (_b0f676046ac7 >= _15458df9d9dd(_9b638b7cdb4d(self, "teacher_conf_tau", 0.6)))._15458df9d9dd()
            _8106aecc184a = _15458df9d9dd(_7f2597264bb8._1d44aafb5433()._4080ad9d90bf()._6622859f2ca5()) if _7f2597264bb8._3371d376fb1b() > 0 else 0.0

        # apply gating to the batch scalars
        _1417625d5afc = _e27eb07644ac * _15458df9d9dd(_8106aecc184a)
        _4eb5e2c6a239 = _d550ffe902e4 * _15458df9d9dd(_8106aecc184a)

        # 2) EMAs for autoscaling
        _0ea57d0ca49d = _15458df9d9dd((_1417625d5afc + _4eb5e2c6a239)._6cfaa9e67501()._4080ad9d90bf()._6622859f2ca5())
        _905413508fa8 = _15458df9d9dd(_0a2229388cc9._6cfaa9e67501()._4080ad9d90bf()._6622859f2ca5())
        if _9b638b7cdb4d(self, "ema_task", _9dd4dec2f1c9) is _9dd4dec2f1c9:
            self._e0bbb7bbdbff = _905413508fa8
            self._276b260001fd = _0ea57d0ca49d + 1e-12
        else:
            _ff6c01fd318a = _15458df9d9dd(_9b638b7cdb4d(self, "ema_alpha", 0.99))
            self._e0bbb7bbdbff = _ff6c01fd318a * _15458df9d9dd(self._e0bbb7bbdbff) + (1.0 - _ff6c01fd318a) * _905413508fa8
            self._276b260001fd  = _ff6c01fd318a * _15458df9d9dd(self._276b260001fd)  + (1.0 - _ff6c01fd318a) * _0ea57d0ca49d

        _2cf7a7faf4f4 = _15458df9d9dd(_9b638b7cdb4d(self, "distill_target_ratio", 0.3))
        _536a1fbf8fa7 = (_15458df9d9dd(self._e0bbb7bbdbff) / (_15458df9d9dd(self._276b260001fd) + 1e-12)) * _2cf7a7faf4f4
        _ceba8187cc5e = _15458df9d9dd(_536a1fbf8fa7)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _731e782efe0e = _15458df9d9dd(_9b638b7cdb4d(self._2ff0b9d9e112, "current_epoch", _9b638b7cdb4d(self._2ff0b9d9e112, "global_step", 0.0)))
        _a1afc3f561fd = _15458df9d9dd(_28b6a2a59b3f(1, _9b638b7cdb4d(self._2ff0b9d9e112, "max_epochs", 1)))
        _53450536a074 = _b5f11d4a1417(_28b6a2a59b3f(_731e782efe0e / _a1afc3f561fd, 0.0), 1.0)
        _d9b2661cb74e = 0.30
        _2aae4e94e276 = _15458df9d9dd(_9b638b7cdb4d(self, "kl_base", 0.30)) * _b5f11d4a1417(_53450536a074 / _d9b2661cb74e, 1.0)
        _0bc72980a923 = _15458df9d9dd(_9b638b7cdb4d(self, "cos_base", 0.25))
        _08f7338d34bd = _0bc72980a923 + (0.10 - _0bc72980a923) * _53450536a074

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _1f85c7fb762e = _15458df9d9dd(self._bb6ee9e0d8d9._1d44aafb5433()._4080ad9d90bf()._6622859f2ca5()) if _9b638b7cdb4d(self, "_last_teacher_conf", _9dd4dec2f1c9) is not _9dd4dec2f1c9 else 0.0
        if _9b638b7cdb4d(self, "ema_teacher_conf", _9dd4dec2f1c9) is _9dd4dec2f1c9:
            self._60d11f993638 = _1f85c7fb762e
        else:
            _bb4197dcc997 = _15458df9d9dd(_9b638b7cdb4d(self, "teacher_conf_beta", 0.995))
            self._60d11f993638 = _bb4197dcc997 * _15458df9d9dd(self._60d11f993638) + (1.0 - _bb4197dcc997) * _1f85c7fb762e

        _81df44b6fc16 = _15458df9d9dd(_9b638b7cdb4d(self, "tau_warn", 0.60))
        _28ee3443e44c = _15458df9d9dd(_9b638b7cdb4d(self, "tau_detect", 0.20))
        _ce510239ef61 = _28b6a2a59b3f(1e-12, (_81df44b6fc16 - _28ee3443e44c))
        _37dd922d7e2f = (_15458df9d9dd(self._60d11f993638) - _28ee3443e44c) / _ce510239ef61
        _37dd922d7e2f = _28b6a2a59b3f(0.0, _b5f11d4a1417(1.0, _37dd922d7e2f))

        _19bb3559cc0d = _2aae4e94e276 * _37dd922d7e2f
        _d4a13ce74ce2 = _08f7338d34bd * _37dd922d7e2f

        # 5) final aux term
        _aca21a31e28e = _1f8391c25d8a._36f9d92fff87(0.0, _0c6d7db9100c=_0c6d7db9100c)
        _aca21a31e28e = _aca21a31e28e + (_19bb3559cc0d * _1417625d5afc + _d4a13ce74ce2 * _4eb5e2c6a239) * _15458df9d9dd(_ceba8187cc5e)

        # diagnostics
        _0c8f88d30676 = {
            "aux_term": _aca21a31e28e,
            "kl_batch": _e27eb07644ac,
            "contrast_batch": _d550ffe902e4,
            "kl_loss": _1417625d5afc,
            "contrastive_loss": _4eb5e2c6a239,
            "w_mean": _8106aecc184a,
            "aux_scale": _15458df9d9dd(_ceba8187cc5e),
            "lambda_kl_eff": _15458df9d9dd(_19bb3559cc0d),
            "lambda_cos_eff": _15458df9d9dd(_d4a13ce74ce2),
            "teacher_conf_mean": _15458df9d9dd(self._60d11f993638),
            "shift_r": _15458df9d9dd(_37dd922d7e2f)
        }
        return _0c8f88d30676

    def _c04f96287461(self, _7da5449d3d15):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _7da5449d3d15 = _7da5449d3d15._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)
        _79d5830ca7fd = (_7da5449d3d15 != self._805d608085e9._9ac00857dfde)._51fedc788d0f(_ae7e1b63f6e5=_1f8391c25d8a._416f3301e509, _0c6d7db9100c=self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)

        # model forward (request hidden states)
        _7ff6b1ea50ad = self._c587a2f2997e(
            _7da5449d3d15=_7da5449d3d15,
            _79d5830ca7fd=_79d5830ca7fd,
            _498bf2f63989=_933f44d53181,
            _e81f824b8cba=_933f44d53181,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _9529f68f291e = _9b638b7cdb4d(_7ff6b1ea50ad, "last_hidden_state", _9dd4dec2f1c9)
        if _9529f68f291e is _9dd4dec2f1c9:
            _9529f68f291e = _7ff6b1ea50ad._539032a931a5[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _9529f68f291e._ae7e1b63f6e5 != _1f8391c25d8a._1ad56d355ddc:
            _9529f68f291e = _9529f68f291e._51fedc788d0f(_1f8391c25d8a._1ad56d355ddc)
        _f1997a90184f = self._5ee958ce45df(_9529f68f291e)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._a8bd2087ac8a:
            _6cb6641514b7 = self._87c4fd3f614d(_f1997a90184f)
        else:
            _6cb6641514b7 = _7ff6b1ea50ad._6cb6641514b7


        _6cb6641514b7 = _6cb6641514b7._51fedc788d0f(_1f8391c25d8a._1ad56d355ddc)._92005295123e(-20, 20)

        # default zero scalars
        _1417625d5afc = _1f8391c25d8a._36f9d92fff87(0.0, _0c6d7db9100c=self._f2605f2613b5)
        _4eb5e2c6a239 = _1f8391c25d8a._36f9d92fff87(0.0, _0c6d7db9100c=self._f2605f2613b5)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _0fad8940d475 = _9b638b7cdb4d(self, "trainer", _9dd4dec2f1c9)
        _10c7aa3146d2 = _9cc4b43b27dc
        if _0fad8940d475 is not _9dd4dec2f1c9:
            _10c7aa3146d2 = _416f3301e509(_9b638b7cdb4d(self._2ff0b9d9e112, "training", _9cc4b43b27dc) or _9b638b7cdb4d(self._2ff0b9d9e112, "validating", _9cc4b43b27dc))

        if _10c7aa3146d2 and (_9b638b7cdb4d(self, "batch_counter", 0) % _9b638b7cdb4d(self, "xth_batch_to_consider", 1) == 0):
            with _1f8391c25d8a._1bd82f4221ea():
                _efcd360a6cd5 = _1fdf979912ab(
                    _7da5449d3d15=_7da5449d3d15,
                    _79d5830ca7fd=_79d5830ca7fd,
                    _498bf2f63989=_933f44d53181,
                    _e81f824b8cba=_933f44d53181,
                )
                _5ac6fff94198 = _9b638b7cdb4d(_efcd360a6cd5, "last_hidden_state", _9dd4dec2f1c9)
                if _5ac6fff94198 is _9dd4dec2f1c9:
                    _5ac6fff94198 = _efcd360a6cd5._539032a931a5[-1]

            # compute embedding-level KL + contrastive (scalar)
            _1417625d5afc, _4eb5e2c6a239 = self._c707233927c3(_f1997a90184f, _5ac6fff94198, _0c6d7db9100c=self._f2605f2613b5)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _31873c752f24(_66fc5431d49f): return _66fc5431d49f._1d44aafb5433(_4c09c4b05104=1) if _66fc5431d49f._4c09c4b05104() == 3 else _66fc5431d49f
            _e3fd65bf3f20 = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._769cceb3bda9(_b3b2590003eb(_f1997a90184f), _6241b74ed14c=2, _4c09c4b05104=-1, _f017252a5af1=1e-6)
            _50051bd6a08e = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._769cceb3bda9(_b3b2590003eb(_5ac6fff94198), _6241b74ed14c=2, _4c09c4b05104=-1, _f017252a5af1=1e-6)
            _588fb8b14d04 = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._6434358cb9d8(_e3fd65bf3f20, _50051bd6a08e, _4c09c4b05104=-1)  # [-1,1]
            _b0f676046ac7 = _588fb8b14d04._92005295123e(_b5f11d4a1417=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._516bf220538c = _f1997a90184f._6cfaa9e67501()
            self._85b85601cb5a = _5ac6fff94198._6cfaa9e67501()
            self._bb6ee9e0d8d9 = _b0f676046ac7._6cfaa9e67501()  # shape (B,)

        # increment counter
        self._9c9851e28aaa = _9b638b7cdb4d(self, "batch_counter", 0) + 1

        return _6cb6641514b7, _1417625d5afc, _4eb5e2c6a239


    def _a36305864ec5(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _f0e93f4dec6e(_efb047ed1eb4, _806e14d5b7e6, _4099d51d99d4):
            if _8b987aee18cc(_a32c5262d831._ae7e1b63f6e5 == _1f8391c25d8a._49a4f617df28 for _a32c5262d831 in _806e14d5b7e6 if _9dc4a511b2b9(_a32c5262d831, _1f8391c25d8a._cf02ae8569a7)):
                _b066cff2a533(f"Layer {_efb047ed1eb4._54d003aaed41.__name__} is using float16!")

        for _8ebce8e44e81 in self._e2786d2b11fe():
            _cccaa6c0d1e3 = _8ebce8e44e81._932ad4936786(_8d0c061bf053)
            self._28e285dbd1f3._c3dbc972a2d7(_cccaa6c0d1e3)

    def _8787d063c38b(self):
        """Remove all registered forward hooks."""
        for _cccaa6c0d1e3 in _9b638b7cdb4d(self, "amp_hooks", []):
            _cccaa6c0d1e3._040c0d4fa3df()
        self._28e285dbd1f3 = []

    def _02442436b3cf(self, _7da5449d3d15, _00539eb52d2e, _d6097087bcd5):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _2201c1ff7e19 = [self._805d608085e9._6c41498199d1(_46fae40b6098) for _46fae40b6098 in _7da5449d3d15]
        _d8459278e496, _2bcabe1937cb = [], []

        for _5432b8afa856, _0d11dd0ac512, _07add132a3b5 in _d844be4be1a0(_2201c1ff7e19, _00539eb52d2e, _d6097087bcd5):
            for token, _e4122c330e4b, _d9e2d4cc834f in _d844be4be1a0(_5432b8afa856, _0d11dd0ac512, _07add132a3b5):
                if token == self._805d608085e9._a7ebc278acdc or _d9e2d4cc834f == self._1db22fb718b5:
                    continue

                _2cfecdc8137e = (
                    token._8b2f17251f7c("##") or
                    token._8b2f17251f7c("▁") or
                    token in ["<unk>", "<pad>"]
                )

                if _2cfecdc8137e:
                    continue

                _d8459278e496._c3dbc972a2d7(_e4122c330e4b._6622859f2ca5())
                _2bcabe1937cb._c3dbc972a2d7(_d9e2d4cc834f._6622859f2ca5())

        return _1f8391c25d8a._36f9d92fff87(_d8459278e496), _1f8391c25d8a._36f9d92fff87(_2bcabe1937cb)

    def _b7f001c05a87(self):
        _172ba8830209 = _1f8391c25d8a._1ad56d355ddc
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            _af6497883c22, _ca9a9c9c4a93 = _1f8391c25d8a._866331966c7c._4d89ab6265fd()
            if _af6497883c22 >= 8:
                _172ba8830209 = _1f8391c25d8a._c1b00e0f1994
            else:
                _172ba8830209 = _1f8391c25d8a._49a4f617df28
        return _172ba8830209

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _7df40a942aad(
        self,
        _a23cfef137de: _1f8391c25d8a._cf02ae8569a7,
        _34ed27cc7499: _1f8391c25d8a._cf02ae8569a7,
        _0c6d7db9100c: _9b440b89d49c = "cpu",
    ) -> _4bb238427266[_1f8391c25d8a._cf02ae8569a7, _1f8391c25d8a._cf02ae8569a7]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _8ed9d9afed33 = 2.0
            # NaN/Inf guard
            _a23cfef137de = _a23cfef137de._92005295123e(_b5f11d4a1417=-30, _28b6a2a59b3f=30)
            _34ed27cc7499 = _34ed27cc7499._92005295123e(_b5f11d4a1417=-30, _28b6a2a59b3f=30)

            # Move once if needed
            _4b0b078dc82c = _1f8391c25d8a._0c6d7db9100c(_0c6d7db9100c)
            if _a23cfef137de._0c6d7db9100c != _4b0b078dc82c:
                _a23cfef137de = _a23cfef137de._51fedc788d0f(_0c6d7db9100c=_4b0b078dc82c, _2e4be6fde4b0=_933f44d53181, _ae7e1b63f6e5=self._afe00ca678e1)
                _34ed27cc7499 = _34ed27cc7499._51fedc788d0f(_0c6d7db9100c=_4b0b078dc82c, _2e4be6fde4b0=_933f44d53181, _ae7e1b63f6e5=self._afe00ca678e1)

            _c6d3e4c68a0a = _a23cfef137de._ced07060cace(0)
            _09336afc33a4 = _a23cfef137de._ced07060cace(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _802e3a944135 = (_c6d3e4c68a0a * _09336afc33a4) > 32_000_000

            if not _802e3a944135 or _c6d3e4c68a0a <= 8:
                # Direct computation
                _85d7a3fbfd62 = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._fa92dc832f97(_a23cfef137de / _8ed9d9afed33, _4c09c4b05104=-1)
                _8f5978a3e578 = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._9f701dbc47fe(_34ed27cc7499 / _8ed9d9afed33, _4c09c4b05104=-1)
                _1417625d5afc = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._c3bb795e690e(_85d7a3fbfd62, _8f5978a3e578, _08bfb20e5d6b="batchmean") * (_8ed9d9afed33 * _8ed9d9afed33)
                _4eb5e2c6a239 = 1 - _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._6434358cb9d8(_a23cfef137de, _34ed27cc7499, _4c09c4b05104=-1)._1d44aafb5433()
                return _1417625d5afc, _4eb5e2c6a239

            # Chunked mode for large inputs
            _e66c6742d38d = _28b6a2a59b3f(1, _c6d3e4c68a0a // 8)
            _05a9edfbd6ee, _ccda90acc865 = [], []

            for _b8b35b8b95d7 in _64dc3aca6b7d(0, _c6d3e4c68a0a, _e66c6742d38d):
                _40af2cde509f = _a23cfef137de[_b8b35b8b95d7:_b8b35b8b95d7 + _e66c6742d38d]
                _40300a479b34 = _34ed27cc7499[_b8b35b8b95d7:_b8b35b8b95d7 + _e66c6742d38d]

                _85d7a3fbfd62 = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._fa92dc832f97(_40af2cde509f / _8ed9d9afed33, _4c09c4b05104=-1)
                _8f5978a3e578 = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._9f701dbc47fe(_40300a479b34 / _8ed9d9afed33, _4c09c4b05104=-1)

                _10deda11f492 = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._c3bb795e690e(_85d7a3fbfd62, _8f5978a3e578, _08bfb20e5d6b="batchmean") * (_8ed9d9afed33 * _8ed9d9afed33)
                _f479e1f6df0a = _1f8391c25d8a._3e9d2081bce2._9b9358d169fd._6434358cb9d8(_40af2cde509f, _40300a479b34, _4c09c4b05104=-1)._1d44aafb5433()
                _4584e2119ae9 = 1 - _f479e1f6df0a

                _05a9edfbd6ee._c3dbc972a2d7(_10deda11f492)
                _ccda90acc865._c3dbc972a2d7(_4584e2119ae9)

            _1417625d5afc = _1f8391c25d8a._f5b6de9b46b8(_05a9edfbd6ee)._1d44aafb5433()
            _4eb5e2c6a239 = _1f8391c25d8a._f5b6de9b46b8(_ccda90acc865)._1d44aafb5433()
            return _1417625d5afc, _4eb5e2c6a239

        except _b6308442d6eb as _f5913689d771:
            raise _81f0e7aa6329(f"KL/contrastive loss computation failed: {_9b440b89d49c(_f5913689d771)}")


    def _9a76fc38fafd(self, _5d41b51fcc6b, _ded015adf38f):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _7da5449d3d15 = _5d41b51fcc6b["input_ids"]
            _2c636b3c77a8 = _5d41b51fcc6b["labels"]
            _0fe3d064302b = _5d41b51fcc6b._493cd1711e09("prompt_lens", _9dd4dec2f1c9)
            _c6d3e4c68a0a = _7da5449d3d15._ced07060cace(0)

            # move to device
            _7da5449d3d15 = _7da5449d3d15._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)
            _2c636b3c77a8 = _2c636b3c77a8._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _4099d51d99d4, _e27eb07644ac, _d550ffe902e4 = self(_7da5449d3d15)

            # causal LM shift for next-token classification (unchanged)
            _6d3d67feecdb = _4099d51d99d4[:, :-1, :]._682b48bf1431()
            _90a80006a4f0 = _2c636b3c77a8[:, 1:]._682b48bf1431()
            _3b40b0094610 = _6d3d67feecdb._5c310c457d52(-1, _6d3d67feecdb._ced07060cace(-1))
            _c18afae9fee2 = _90a80006a4f0._5c310c457d52(-1)

            # classification/task loss
            _458b16b602bd = self._d9b1fdaf78de['criterion'](_3b40b0094610, _c18afae9fee2)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _e27eb07644ac = _1f8391c25d8a._1a2467c90e2e(_e27eb07644ac, _65a627feab8e=0.0, _16fc8080707d=0.0, _b4a52275ad3c=0.0)
            _d550ffe902e4 = _1f8391c25d8a._1a2467c90e2e(_d550ffe902e4, _65a627feab8e=0.0, _16fc8080707d=0.0, _b4a52275ad3c=0.0)
            _458b16b602bd = _1f8391c25d8a._1a2467c90e2e(_458b16b602bd, _65a627feab8e=0.0, _16fc8080707d=0.0, _b4a52275ad3c=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _2fc79952c9f4 = self._08644c1f71e1(_458b16b602bd, _e27eb07644ac, _d550ffe902e4)
            _aca21a31e28e = _2fc79952c9f4["aux_term"]

            # final combined loss (single-equation)
            _d775ad9038ba = _458b16b602bd + _aca21a31e28e

            # Optional NaN print as before (keeps your original check)
            if _1f8391c25d8a._08099ca762b3(_458b16b602bd):
                _b066cff2a533(f"Step {_ded015adf38f}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _e1aec4a92444 = {
                "epoch": _15458df9d9dd(_9b638b7cdb4d(self, "current_epoch", _9b638b7cdb4d(self._2ff0b9d9e112, "current_epoch", 0))),
                "train_kl_loss": _2fc79952c9f4._493cd1711e09("kl_loss", _e27eb07644ac)._6cfaa9e67501() if _9dc4a511b2b9(_2fc79952c9f4._493cd1711e09("kl_loss", _e27eb07644ac), _1f8391c25d8a._cf02ae8569a7) else _2fc79952c9f4._493cd1711e09("kl_loss", _e27eb07644ac),
                "train_contrastive_loss": _2fc79952c9f4._493cd1711e09("contrastive_loss", _d550ffe902e4)._6cfaa9e67501() if _9dc4a511b2b9(_2fc79952c9f4._493cd1711e09("contrastive_loss", _d550ffe902e4), _1f8391c25d8a._cf02ae8569a7) else _2fc79952c9f4._493cd1711e09("contrastive_loss", _d550ffe902e4),
                "train_classification_loss": _458b16b602bd._6cfaa9e67501(),
                "train_loss": _d775ad9038ba._6cfaa9e67501(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _15458df9d9dd(_9b638b7cdb4d(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _2fc79952c9f4._493cd1711e09("lambda_kl_eff", _15458df9d9dd(_9b638b7cdb4d(self, "kl_base", 0.30))),
                "train_lambda_contrast": _2fc79952c9f4._493cd1711e09("lambda_cos_eff", _15458df9d9dd(_9b638b7cdb4d(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _21095c3a0a88 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _21095c3a0a88 in _2fc79952c9f4:
                    _eb73a473878a = _2fc79952c9f4[_21095c3a0a88]
                    # convert single-element tensors to python floats for logging
                    if _9dc4a511b2b9(_eb73a473878a, _1f8391c25d8a._cf02ae8569a7) and _eb73a473878a._3371d376fb1b() == 1:
                        _e1aec4a92444[f"train_{_21095c3a0a88}"] = _15458df9d9dd(_eb73a473878a._6cfaa9e67501()._4080ad9d90bf()._6622859f2ca5())
                    else:
                        _e1aec4a92444[f"train_{_21095c3a0a88}"] = _eb73a473878a

            # log exactly like you did
            self._4d7e86f4d16f(
                _e1aec4a92444,
                _c6d3e4c68a0a=_c6d3e4c68a0a,
                _eb2b513b7439=_9cc4b43b27dc,
                _5217bd176033=_933f44d53181,
                _a22e3ef4309c=_9cc4b43b27dc,
                _9f52a86f2a74=_933f44d53181,
                _66503e017783=_933f44d53181,
            )

            # free references as you did
            del _7da5449d3d15, _2c636b3c77a8, _4099d51d99d4, _e27eb07644ac, _458b16b602bd, _d550ffe902e4, _90a80006a4f0, _6d3d67feecdb, _c18afae9fee2, _3b40b0094610

            return _d775ad9038ba

        except _b6308442d6eb as _f5913689d771:
            raise _81f0e7aa6329(f"Error in training_step: {_f5913689d771}") from _f5913689d771

    def _110306d41e7c(self):
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            _1f8391c25d8a._866331966c7c._44fbf7240c01()
        _012c0519a8c5._bb2a22b57cab()
        return _7216ad2e2bf5()._b8ce6a2b2a8d()

    def _db8e293770a5(self, _5d41b51fcc6b, _ded015adf38f):
        _7da5449d3d15      = _5d41b51fcc6b["input_ids"]._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)
        _2c636b3c77a8         = _5d41b51fcc6b["labels"]._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)
        _e82bf8ae17af     = _5d41b51fcc6b._493cd1711e09("lang_codes", _9dd4dec2f1c9)
        _d3cdbcde2602     = _5d41b51fcc6b._493cd1711e09("sample_ids", _9dd4dec2f1c9)
        _46b666754ba2      = _5d41b51fcc6b._493cd1711e09("chunk_ids", _9dd4dec2f1c9)
        _dc4427928b79 = _5d41b51fcc6b._493cd1711e09("word_positions", _9dd4dec2f1c9)
        _0fe3d064302b    = _5d41b51fcc6b._493cd1711e09("prompt_lens", _9dd4dec2f1c9)
        _8c342d28a8f5 = _5d41b51fcc6b._493cd1711e09("num_chunks", _9dd4dec2f1c9)

        _c6d3e4c68a0a = _7da5449d3d15._ced07060cace(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _4099d51d99d4, _e27eb07644ac, _d550ffe902e4 = self(_7da5449d3d15)

        # causal LM shift for next-token classification (same as training)
        _6d3d67feecdb = _4099d51d99d4[:, :-1, :]._682b48bf1431()
        _90a80006a4f0 = _2c636b3c77a8[:, 1:]._682b48bf1431()
        _3b40b0094610 = _6d3d67feecdb._5c310c457d52(-1, _6d3d67feecdb._ced07060cace(-1))
        _c18afae9fee2 = _90a80006a4f0._5c310c457d52(-1)

        if _ded015adf38f == 0:
            try:
                _b066cff2a533(
                    f"VAL TEST BATCH {_ded015adf38f} Input IDs: {_7da5449d3d15._140b032a0d76()[0]}, "
                    f"Predictions: {_1f8391c25d8a._266f34e9ceaf(_6d3d67feecdb, _4c09c4b05104=-1)._140b032a0d76()[0]}, "
                    f"Labels: {_90a80006a4f0._140b032a0d76()[0]}"
                )
            except _b6308442d6eb:
                # printing should never crash validation
                pass

        # classification loss
        _458b16b602bd = self._d9b1fdaf78de['criterion'](_3b40b0094610, _c18afae9fee2)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _e27eb07644ac = _1f8391c25d8a._1a2467c90e2e(_e27eb07644ac, _65a627feab8e=0.0, _16fc8080707d=0.0, _b4a52275ad3c=0.0)
        _d550ffe902e4 = _1f8391c25d8a._1a2467c90e2e(_d550ffe902e4, _65a627feab8e=0.0, _16fc8080707d=0.0, _b4a52275ad3c=0.0)
        _458b16b602bd = _1f8391c25d8a._1a2467c90e2e(_458b16b602bd, _65a627feab8e=0.0, _16fc8080707d=0.0, _b4a52275ad3c=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _2fc79952c9f4 = self._08644c1f71e1(_458b16b602bd, _e27eb07644ac, _d550ffe902e4)
        _aca21a31e28e = _2fc79952c9f4["aux_term"]
        _d775ad9038ba = _458b16b602bd + _aca21a31e28e

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _4d7e86f4d16f = {
            "val_kl_loss": _15458df9d9dd(_2fc79952c9f4._493cd1711e09("kl_loss", _e27eb07644ac)._6cfaa9e67501()._4080ad9d90bf()._6622859f2ca5()) if _9dc4a511b2b9(_2fc79952c9f4._493cd1711e09("kl_loss", _e27eb07644ac), _1f8391c25d8a._cf02ae8569a7) else _15458df9d9dd(_2fc79952c9f4._493cd1711e09("kl_loss", _e27eb07644ac)),
            "val_contrastive_loss": _15458df9d9dd(_2fc79952c9f4._493cd1711e09("contrastive_loss", _d550ffe902e4)._6cfaa9e67501()._4080ad9d90bf()._6622859f2ca5()) if _9dc4a511b2b9(_2fc79952c9f4._493cd1711e09("contrastive_loss", _d550ffe902e4), _1f8391c25d8a._cf02ae8569a7) else _15458df9d9dd(_2fc79952c9f4._493cd1711e09("contrastive_loss", _d550ffe902e4)),
            "val_classification_loss": _15458df9d9dd(_458b16b602bd._6cfaa9e67501()._4080ad9d90bf()._6622859f2ca5()),
            "val_loss": _15458df9d9dd(_d775ad9038ba._6cfaa9e67501()._4080ad9d90bf()._6622859f2ca5()),
        }

        # include effective lambdas and others if provided by aux
        _4d7e86f4d16f["val_lambda_kl"] = _15458df9d9dd(_2fc79952c9f4._493cd1711e09("lambda_kl", _2fc79952c9f4._493cd1711e09("lambda_kl_eff", _15458df9d9dd(_9b638b7cdb4d(self, "kl_base", 0.30)))))
        _4d7e86f4d16f["val_lambda_contrast"] = _15458df9d9dd(_2fc79952c9f4._493cd1711e09("lambda_cos", _2fc79952c9f4._493cd1711e09("lambda_cos_eff", _15458df9d9dd(_9b638b7cdb4d(self, "cos_base", 0.25)))))
        _4d7e86f4d16f["val_w_mean"] = _15458df9d9dd(_2fc79952c9f4._493cd1711e09("w_mean", 0.0))
        _4d7e86f4d16f["val_aux_scale"] = _15458df9d9dd(_2fc79952c9f4._493cd1711e09("aux_scale", 0.0))
        _4d7e86f4d16f["val_shift_r"] = _15458df9d9dd(_2fc79952c9f4._493cd1711e09("shift_r", 0.0))
        _4d7e86f4d16f["val_teacher_conf_mean"] = _15458df9d9dd(_2fc79952c9f4._493cd1711e09("teacher_conf_mean", 0.0))

        self._4d7e86f4d16f(
            _4d7e86f4d16f,
            _c6d3e4c68a0a=_c6d3e4c68a0a,
            _eb2b513b7439=_9cc4b43b27dc,
            _5217bd176033=_933f44d53181,
            _a22e3ef4309c=_9cc4b43b27dc,
            _9f52a86f2a74=_933f44d53181,
            _66503e017783=_933f44d53181,
        )

        # build preds and labels per example (preserve your previous behavior)
        _e73a277efb02 = []
        _508d43fd914a = []
        for _b8b35b8b95d7 in _64dc3aca6b7d(_c6d3e4c68a0a):
            _44e14717c517 = _4099d51d99d4[_b8b35b8b95d7]
            _d9e2d4cc834f = _2c636b3c77a8[_b8b35b8b95d7]
            _fce21c8b4e7d = _1f8391c25d8a._266f34e9ceaf(_44e14717c517, _4c09c4b05104=-1)
            _079a23fc59df = _d9e2d4cc834f
            _e73a277efb02._c3dbc972a2d7(_fce21c8b4e7d)
            _508d43fd914a._c3dbc972a2d7(_079a23fc59df)

        _361559ffbf68 = {
            "lang_codes": _e82bf8ae17af,
            "preds": _e73a277efb02,
            "labels": _508d43fd914a,
            "sample_ids": _d3cdbcde2602,
            "chunk_ids": _46b666754ba2,
            "word_positions": _dc4427928b79,
            "val_loss": _d775ad9038ba,
            "prompt_lens": _0fe3d064302b,
            "num_chunks": _8c342d28a8f5,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._7c4747302256._c3dbc972a2d7(_361559ffbf68)

        # explicit frees (same as you had)
        del _7da5449d3d15, _2c636b3c77a8, _4099d51d99d4, _3b40b0094610, _c18afae9fee2, _6d3d67feecdb, _90a80006a4f0
        del _e27eb07644ac, _d550ffe902e4, _458b16b602bd, _e73a277efb02, _508d43fd914a

        return _361559ffbf68


    def _784838380fef(self, _3fb5b41e3bb5, _a34577e7e4ad, _663d2e3c4d67=_9dd4dec2f1c9):
        _614ddce1c246 = os._815f9326efc8()
        _aa7d84a92bfa = f"trial_{_663d2e3c4d67}" if _663d2e3c4d67 is not _9dd4dec2f1c9 else "default"
        _b066cff2a533(f"[DEBUG rank={_1f8391c25d8a._42b36bcacd6a._a84847bd3752() if _1f8391c25d8a._42b36bcacd6a._be8530dc2d3b() else 0}] metrics_dict confusion_matrix sum={_fb6c4519051b(_fb6c4519051b(_bf814666078c) for _bf814666078c in _3fb5b41e3bb5['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _ac9a8b050793 = os._b430fdeb4adf._53ea0466ec4a(_614ddce1c246, "metrics", self._f7617f12bc7a,  _aa7d84a92bfa)
        os._17513e961af8(_ac9a8b050793, _1cb06ec0f81c=_933f44d53181)
        _4ceb118a0a5d = os._b430fdeb4adf._53ea0466ec4a(_ac9a8b050793, _a34577e7e4ad)
        _2d04ffa19259 = _3bb4c2af4264._6198b9b72473(_3fb5b41e3bb5)
        _2d04ffa19259._28c043292909(_4ceb118a0a5d, _d35880d31bd1=_9cc4b43b27dc)
        _b066cff2a533(f"[metrics] Saved {_4ceb118a0a5d}")

    def _d509f882d317(self):
        # pick correct device for this rank
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            if _1f8391c25d8a._42b36bcacd6a._be8530dc2d3b():
                _eacaf8cbc5de = _1f8391c25d8a._42b36bcacd6a._a84847bd3752()
            else:
                _eacaf8cbc5de = 0
            _1f8391c25d8a._866331966c7c._ac09c53f6e77(_eacaf8cbc5de)
            self._f2605f2613b5 = _1f8391c25d8a._0c6d7db9100c(f"cuda:{_eacaf8cbc5de}")
        else:
            self._f2605f2613b5 = _1f8391c25d8a._0c6d7db9100c("cpu")

        self._3293cef233f2()

    def _5d9ff5d48113(self):
        _4099d51d99d4 = _9b638b7cdb4d(self, "_validation_outputs", _9dd4dec2f1c9)
        if not _4099d51d99d4:
            return

        _a4fa12432992, _5ba7f4d6906a, _8ce667be2b5a, _06f36e8af4cd = \
            self._443a7f073e54(_4099d51d99d4)

        _dc872a588267, _12ca58a7e8e9 = [], []
        for _e7efde9bf2e8 in _a41d656755aa(_8ce667be2b5a._333bd9c44ac6()):
            _73214aafb99b = _a4fa12432992[_e7efde9bf2e8]._140b032a0d76()
            _b8b6b996b590 = _5ba7f4d6906a[_e7efde9bf2e8]._140b032a0d76()
            _9c37a89fe584 = _8ce667be2b5a[_e7efde9bf2e8]
            _5fab2d1dc780 = _06f36e8af4cd[_e7efde9bf2e8]
            if _9c37a89fe584._3371d376fb1b() > 0 and _5fab2d1dc780._3371d376fb1b() > 0:
                _dc872a588267._c3dbc972a2d7(_9c37a89fe584)
                _12ca58a7e8e9._c3dbc972a2d7(_5fab2d1dc780)

        if not _dc872a588267:
            _b066cff2a533("[VAL END] Nothing to score.")
            self._7c4747302256._de073e4e6a5d()
            return

        _08ec337cd43b = _1f8391c25d8a._93740efb0b90(_dc872a588267)._51fedc788d0f(_0c6d7db9100c=self._43ec507a84f1['micro_accuracy']._0c6d7db9100c, _2e4be6fde4b0=_933f44d53181)
        _2c636b3c77a8 = _1f8391c25d8a._93740efb0b90(_12ca58a7e8e9)._51fedc788d0f(_0c6d7db9100c=self._43ec507a84f1['micro_accuracy']._0c6d7db9100c, _2e4be6fde4b0=_933f44d53181)

        self._43ec507a84f1['micro_accuracy']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_accuracy']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_precision']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_recall']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_f1']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_accuracy']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_precision']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_recall']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_f1']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['confmat']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)

        _b811f7b9f287  = self._43ec507a84f1['micro_accuracy']._686b9d6200ad()._6622859f2ca5()
        _98708a066233  = self._43ec507a84f1['macro_accuracy']._686b9d6200ad()._6622859f2ca5()
        _8a1925c84fce = self._43ec507a84f1['macro_precision']._686b9d6200ad()._6622859f2ca5()
        _16e36359efec    = self._43ec507a84f1['macro_recall']._686b9d6200ad()._6622859f2ca5()
        _7fe4c95990de        = self._43ec507a84f1['macro_f1']._686b9d6200ad()._6622859f2ca5()

        self._b0106421458e("val_accuracy", _98708a066233, _66503e017783=_933f44d53181)

        try:
            _2c13f2b5464e = self._fcb9c438ee49
            _3fb5b41e3bb5 = {
                "epoch": [_2c13f2b5464e],
                "class_names": [self._45409901e504],
                "micro_accuracy": [_b811f7b9f287],
                "macro_accuracy": [_98708a066233],
                "macro_precision": [_8a1925c84fce],
                "macro_recall": [_16e36359efec],
                "macro_f1": [_7fe4c95990de],
                "classwise_accuracy": [self._43ec507a84f1['classwise_accuracy']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "classwise_precision": [self._43ec507a84f1['classwise_precision']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "classwise_recall": [self._43ec507a84f1['classwise_recall']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "classwise_f1": [self._43ec507a84f1['classwise_f1']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "confusion_matrix": [self._43ec507a84f1['confmat']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
            }
            self._0e8439dc1e25(_3fb5b41e3bb5, f"val_epoch_{_2c13f2b5464e}.csv", _663d2e3c4d67=self._663d2e3c4d67)
        except _b6308442d6eb as _f5913689d771:
            _b066cff2a533(f"[VAL END] save metrics FAILED: {_f5913689d771}")

        # cleanup
        self._43ec507a84f1['micro_accuracy']._21e89eac6620(); self._43ec507a84f1['macro_accuracy']._21e89eac6620()
        self._43ec507a84f1['macro_precision']._21e89eac6620(); self._43ec507a84f1['macro_recall']._21e89eac6620(); self._43ec507a84f1['macro_f1']._21e89eac6620()
        self._43ec507a84f1['classwise_accuracy']._21e89eac6620(); self._43ec507a84f1['classwise_precision']._21e89eac6620()
        self._43ec507a84f1['classwise_recall']._21e89eac6620(); self._43ec507a84f1['classwise_f1']._21e89eac6620()
        self._43ec507a84f1['confmat']._21e89eac6620(); self._7c4747302256._de073e4e6a5d()
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            _1f8391c25d8a._866331966c7c._44fbf7240c01()
        _b066cff2a533("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_1f8391c25d8a._1bd82f4221ea()
    def _f7f1fbe9b8df(self, _7da5449d3d15: _1f8391c25d8a._cf02ae8569a7, **_752d868a02bb):
        _752d868a02bb._430ac8070309("pad_token_id", _9dd4dec2f1c9)
        _752d868a02bb._430ac8070309("attention_mask", _9dd4dec2f1c9)
        return self._c587a2f2997e._acdc117be675(
            _7da5449d3d15=_7da5449d3d15,
            _79d5830ca7fd=(_7da5449d3d15 != self._805d608085e9._9ac00857dfde),
            _9ac00857dfde=self._805d608085e9._9ac00857dfde,
            _865c168e3585=self._805d608085e9._865c168e3585,
            **_752d868a02bb
        )

    def _40a942b245b6(self, _5d41b51fcc6b, _ded015adf38f):
        _7da5449d3d15 = _5d41b51fcc6b["input_ids"]._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)
        _2c636b3c77a8    = _5d41b51fcc6b["labels"]._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)
        _e82bf8ae17af     = _5d41b51fcc6b._493cd1711e09("lang_codes", _9dd4dec2f1c9)
        _d3cdbcde2602     = _5d41b51fcc6b._493cd1711e09("sample_ids", _9dd4dec2f1c9)
        _46b666754ba2      = _5d41b51fcc6b._493cd1711e09("chunk_ids", _9dd4dec2f1c9)
        _dc4427928b79 = _5d41b51fcc6b._493cd1711e09("word_positions", _9dd4dec2f1c9)
        _0fe3d064302b    = _5d41b51fcc6b._493cd1711e09("prompt_lens", _9dd4dec2f1c9)
        _8c342d28a8f5 = _5d41b51fcc6b._493cd1711e09("num_chunks", _9dd4dec2f1c9)

        _c6d3e4c68a0a = _7da5449d3d15._ced07060cace(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _3b435f11ce58 = self._acdc117be675(
            _7da5449d3d15,
            _2488def94ee4=32,
            _6e4ea7e52607=_9cc4b43b27dc,
            _667dc5210133=_9dd4dec2f1c9,     # for deterministic answers
            _86aaa88ced9a=_9dd4dec2f1c9,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _e73a277efb02 = []
        _508d43fd914a = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _b8b35b8b95d7 in _64dc3aca6b7d(_c6d3e4c68a0a):
            _e73a277efb02._c3dbc972a2d7(_3b435f11ce58[_b8b35b8b95d7])   # FULL sequence
            _508d43fd914a._c3dbc972a2d7(_2c636b3c77a8[_b8b35b8b95d7])          # FULL labels


        _361559ffbf68 = {
            "lang_codes": _e82bf8ae17af,
            "preds": _e73a277efb02,
            "labels": _508d43fd914a,
            "sample_ids": _d3cdbcde2602,
            "chunk_ids": _46b666754ba2,
            "word_positions": _dc4427928b79,
            "prompt_lens": _0fe3d064302b,
            "num_chunks": _8c342d28a8f5,
        }

        self._497f446b528c._c3dbc972a2d7(_361559ffbf68)

        # Exact same cleanup as before
        del _7da5449d3d15, _2c636b3c77a8, _3b435f11ce58, _e73a277efb02, _508d43fd914a

        return _361559ffbf68

    def _080d9b005df6(self):
        # pick correct device for this rank
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            if _1f8391c25d8a._42b36bcacd6a._be8530dc2d3b():
                _eacaf8cbc5de = _1f8391c25d8a._42b36bcacd6a._a84847bd3752()
            else:
                _eacaf8cbc5de = 0
            _1f8391c25d8a._866331966c7c._ac09c53f6e77(_eacaf8cbc5de)
            self._f2605f2613b5 = _1f8391c25d8a._0c6d7db9100c(f"cuda:{_eacaf8cbc5de}")
        else:
            self._f2605f2613b5 = _1f8391c25d8a._0c6d7db9100c("cpu")

        self._3293cef233f2()
        
    def _f23846f87d92(self):
        _4099d51d99d4 = _9b638b7cdb4d(self, "_test_outputs", _9dd4dec2f1c9)
        _b066cff2a533(f"[DEBUG rank={_1f8391c25d8a._42b36bcacd6a._a84847bd3752()}] outputs_len={_15f81e41435c(_4099d51d99d4)}")
        if not _4099d51d99d4:
            return

        _a4fa12432992, _5ba7f4d6906a, _8ce667be2b5a, _06f36e8af4cd = \
            self._443a7f073e54(_4099d51d99d4)

        _dc872a588267, _12ca58a7e8e9 = [], []
        for _e7efde9bf2e8 in _a41d656755aa(_8ce667be2b5a._333bd9c44ac6()):
            _73214aafb99b = _a4fa12432992[_e7efde9bf2e8]._140b032a0d76()
            _b8b6b996b590 = _5ba7f4d6906a[_e7efde9bf2e8]._140b032a0d76()
            _9c37a89fe584 = _8ce667be2b5a[_e7efde9bf2e8]
            _5fab2d1dc780 = _06f36e8af4cd[_e7efde9bf2e8]

            if _9c37a89fe584._3371d376fb1b() > 0 and _5fab2d1dc780._3371d376fb1b() > 0:
                _dc872a588267._c3dbc972a2d7(_9c37a89fe584)
                _12ca58a7e8e9._c3dbc972a2d7(_5fab2d1dc780)

        if not _dc872a588267:
            _b066cff2a533("[TEST END] Nothing to score.")
            self._7c4747302256._de073e4e6a5d()
            return

        _08ec337cd43b = _1f8391c25d8a._93740efb0b90(_dc872a588267)._51fedc788d0f(_0c6d7db9100c=self._43ec507a84f1['micro_accuracy']._0c6d7db9100c, _2e4be6fde4b0=_933f44d53181)
        _2c636b3c77a8 = _1f8391c25d8a._93740efb0b90(_12ca58a7e8e9)._51fedc788d0f(_0c6d7db9100c=self._43ec507a84f1['micro_accuracy']._0c6d7db9100c, _2e4be6fde4b0=_933f44d53181)

        self._43ec507a84f1['micro_accuracy']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_accuracy']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_precision']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_recall']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['macro_f1']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_accuracy']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_precision']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_recall']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['classwise_f1']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)
        self._43ec507a84f1['confmat']._97b2a5a9ea99(_08ec337cd43b, _2c636b3c77a8)

        _b811f7b9f287  = self._43ec507a84f1['micro_accuracy']._686b9d6200ad()._6622859f2ca5()
        _98708a066233  = self._43ec507a84f1['macro_accuracy']._686b9d6200ad()._6622859f2ca5()
        _8a1925c84fce = self._43ec507a84f1['macro_precision']._686b9d6200ad()._6622859f2ca5()
        _16e36359efec    = self._43ec507a84f1['macro_recall']._686b9d6200ad()._6622859f2ca5()
        _7fe4c95990de        = self._43ec507a84f1['macro_f1']._686b9d6200ad()._6622859f2ca5()

        self._b0106421458e("test_accuracy", _98708a066233, _66503e017783=_933f44d53181)

        try:
            _2c13f2b5464e = self._fcb9c438ee49
            _3fb5b41e3bb5 = {
                "epoch": [_2c13f2b5464e],
                "class_names": [self._45409901e504],
                "micro_accuracy": [_b811f7b9f287],
                "macro_accuracy": [_98708a066233],
                "macro_precision": [_8a1925c84fce],
                "macro_recall": [_16e36359efec],
                "macro_f1": [_7fe4c95990de],
                "classwise_accuracy": [self._43ec507a84f1['classwise_accuracy']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "classwise_precision": [self._43ec507a84f1['classwise_precision']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "classwise_recall": [self._43ec507a84f1['classwise_recall']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "classwise_f1": [self._43ec507a84f1['classwise_f1']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
                "confusion_matrix": [self._43ec507a84f1['confmat']._686b9d6200ad()._51fedc788d0f(_0c6d7db9100c="cpu")._e8d64e4f9d82()._140b032a0d76()],
            }
            self._0e8439dc1e25(_3fb5b41e3bb5, f"test_final.csv", _663d2e3c4d67=self._663d2e3c4d67)
        except _b6308442d6eb as _f5913689d771:
            _b066cff2a533(f"[TEST END] save metrics FAILED: {_f5913689d771}")

        # cleanup
        self._43ec507a84f1['micro_accuracy']._21e89eac6620(); self._43ec507a84f1['macro_accuracy']._21e89eac6620()
        self._43ec507a84f1['macro_precision']._21e89eac6620(); self._43ec507a84f1['macro_recall']._21e89eac6620(); self._43ec507a84f1['macro_f1']._21e89eac6620()
        self._43ec507a84f1['classwise_accuracy']._21e89eac6620(); self._43ec507a84f1['classwise_precision']._21e89eac6620()
        self._43ec507a84f1['classwise_recall']._21e89eac6620(); self._43ec507a84f1['classwise_f1']._21e89eac6620()
        self._43ec507a84f1['confmat']._21e89eac6620(); self._7c4747302256._de073e4e6a5d()
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            _1f8391c25d8a._866331966c7c._44fbf7240c01()
        _b066cff2a533("[TEST END] Finished and cleaned up.")

    def _74eba880a258(self, _5d41b51fcc6b, _ded015adf38f, _2030acd0fa93=0):
        """Optimized prediction step with efficient memory handling."""
        _7da5449d3d15, _ = _5d41b51fcc6b
        _7da5449d3d15 = _7da5449d3d15._51fedc788d0f(self._f2605f2613b5, _2e4be6fde4b0=_933f44d53181)
        _4099d51d99d4, _, _ = self(_7da5449d3d15)
        _44d9611bf54a = _1f8391c25d8a._266f34e9ceaf(_4099d51d99d4, _4c09c4b05104=-1)
        del _7da5449d3d15, _4099d51d99d4
        if _1f8391c25d8a._866331966c7c._57452291d6c6():
            _1f8391c25d8a._866331966c7c._44fbf7240c01()
        return {"predictions": _44d9611bf54a._4080ad9d90bf()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _b66ea5cc1f8a(self, _4099d51d99d4, _3dd36847e49d=_933f44d53181, _4b0b078dc82c="cpu"):
        from collections import _94ae7cf05fb7, _472392c744af
        import _1f8391c25d8a
        _bad305b2a7b4 = self._1db22fb718b5
        def _379a7096b133(_66fc5431d49f):
            if _9dc4a511b2b9(_66fc5431d49f, _1f8391c25d8a._cf02ae8569a7): return _66fc5431d49f._6cfaa9e67501()._51fedc788d0f(_0c6d7db9100c=_4b0b078dc82c, _2e4be6fde4b0=_933f44d53181)._ad8d0e2d7216(-1)._140b032a0d76()
            return _03e16f5514e2(_66fc5431d49f) if _9dc4a511b2b9(_66fc5431d49f, (_03e16f5514e2, _3942976c761f)) else [_66fc5431d49f]
        
        _a45fdc5510a4 = _3d6ced4bb7d9()
        _a4fa12432992, _5ba7f4d6906a, _d345c7ea73ef = {}, {}, []
        if _3dd36847e49d:
            _b066cff2a533(f"[reconcile] start: num_outputs={_15f81e41435c(_4099d51d99d4)}")
        
        _b76dba6b056f = _94ae7cf05fb7(_03e16f5514e2)
        
        for _0c8f88d30676 in _4099d51d99d4:
            _d3cdbcde2602     = _0c8f88d30676["sample_ids"]
            _46b666754ba2      = _0c8f88d30676["chunk_ids"]
            _d3ded777c49a    = _0c8f88d30676["preds"]
            _78c6a4b97f0b   = _0c8f88d30676["labels"]
            _dc4427928b79 = _0c8f88d30676["word_positions"]
            _0fe3d064302b    = _0c8f88d30676["prompt_lens"]

            for _b8b35b8b95d7, _e7efde9bf2e8 in _57c78ca28b3f(_d3cdbcde2602):
                _06018981cd55 = _b6f63f227d33(_46b666754ba2[_b8b35b8b95d7])
                if (_e7efde9bf2e8, _06018981cd55) in _a45fdc5510a4:
                    continue
                _a45fdc5510a4._11fcccbf066d((_e7efde9bf2e8, _06018981cd55))

                _77c632e0d0f9 = _b6f63f227d33(_0fe3d064302b[_b8b35b8b95d7])
                _009fa721e46b  = _10c3d62aa2d9(_dc4427928b79[_b8b35b8b95d7])
                _d3d68a545180    = _10c3d62aa2d9(_d3ded777c49a[_b8b35b8b95d7])
                _9f51e23163be   = _10c3d62aa2d9(_78c6a4b97f0b[_b8b35b8b95d7])

                _fa37f1ca5e31  = [_6241b74ed14c for _6241b74ed14c in _d3d68a545180[_77c632e0d0f9:] if _6241b74ed14c != _bad305b2a7b4]
                _70e8486521ff = [_311ecd83ef27 for _311ecd83ef27 in _9f51e23163be[_77c632e0d0f9:] if _311ecd83ef27 != _bad305b2a7b4]

                if _e7efde9bf2e8 not in _d345c7ea73ef:
                    _d345c7ea73ef._c3dbc972a2d7(_e7efde9bf2e8)

                _b76dba6b056f[_e7efde9bf2e8]._c3dbc972a2d7((_06018981cd55, _009fa721e46b, _fa37f1ca5e31, _70e8486521ff))
        
        _2577fcbc100f = _9dd4dec2f1c9
        for _e7efde9bf2e8 in _d345c7ea73ef:
            _db728feefb6f = _b76dba6b056f[_e7efde9bf2e8]
            _db728feefb6f._3f8e24f47e27(_bb5c7d11de82=lambda _66fc5431d49f: _66fc5431d49f[0])
            if _2577fcbc100f is _9dd4dec2f1c9 and _15f81e41435c(_db728feefb6f) > 1:
                _2577fcbc100f = _e7efde9bf2e8
            
            _5c882b4933fa = _94ae7cf05fb7(_03e16f5514e2)
            _e41de2ff1973    = _94ae7cf05fb7(_03e16f5514e2)
            _915bc22da593 = _94ae7cf05fb7(_03e16f5514e2)
            _4d986ca642b6    = _94ae7cf05fb7(_03e16f5514e2)
            
            _0074b7c54e53 = _3d6ced4bb7d9()
            for _, _dd25d1f91094, _, _ in _db728feefb6f:
                for _e00917b46614 in _dd25d1f91094:
                    if _e00917b46614 >= 0:
                        _0074b7c54e53._11fcccbf066d(_e00917b46614)
            
            if not _0074b7c54e53:
                continue
            
            _dbc4167de0ad = _a41d656755aa(_0074b7c54e53)
            _af421b243d03 = _28b6a2a59b3f(_dbc4167de0ad)
            
            for _06018981cd55, _dd25d1f91094, _08ec337cd43b, _2c636b3c77a8 in _db728feefb6f:
                _31da66fe0a19 = _9dd4dec2f1c9
                _02f95ae4dd77 = []
                _bb4505f6b451 = []
                for _899d41a7acc2, _8418b7b86393, _7dfad8cfe458 in _d844be4be1a0(_dd25d1f91094, _08ec337cd43b, _2c636b3c77a8):
                    _41fc8d876838 = _b6f63f227d33(_899d41a7acc2)
                    if _41fc8d876838 >= 0:
                        if _41fc8d876838 != _31da66fe0a19:
                            if _31da66fe0a19 is not _9dd4dec2f1c9:
                                _5c882b4933fa[_31da66fe0a19]._c3dbc972a2d7(_02f95ae4dd77[:])
                                _915bc22da593[_31da66fe0a19]._c3dbc972a2d7(_bb4505f6b451[:])
                            _31da66fe0a19 = _41fc8d876838
                            _02f95ae4dd77 = [_b6f63f227d33(_8418b7b86393)]
                            _bb4505f6b451 = [_b6f63f227d33(_7dfad8cfe458)]
                        else:
                            _02f95ae4dd77._c3dbc972a2d7(_b6f63f227d33(_8418b7b86393))
                            _bb4505f6b451._c3dbc972a2d7(_b6f63f227d33(_7dfad8cfe458))
                    else:
                        if _31da66fe0a19 is not _9dd4dec2f1c9:
                            _e41de2ff1973[_31da66fe0a19]._c3dbc972a2d7(_b6f63f227d33(_8418b7b86393))
                            _4d986ca642b6[_31da66fe0a19]._c3dbc972a2d7(_b6f63f227d33(_7dfad8cfe458))
                if _31da66fe0a19 is not _9dd4dec2f1c9:
                    _5c882b4933fa[_31da66fe0a19]._c3dbc972a2d7(_02f95ae4dd77[:])
                    _915bc22da593[_31da66fe0a19]._c3dbc972a2d7(_bb4505f6b451[:])
            
            _4a5a4c5c84f7 = []
            _c364bcf49f94 = []
            _a8a6b88bba0e = _aa880ed50744(_b35237987d52[0] for _b35237987d52 in self._b09fb68d8fbe if self._b09fb68d8fbe[_b35237987d52] == 0)
            _dc83cede6cc2 = self._9015caf95d75
            
            for _84856130cbfc in _dbc4167de0ad:
                _c474d4885534 = _5c882b4933fa._493cd1711e09(_84856130cbfc, [])
                _1b22b8858c06 = _915bc22da593._493cd1711e09(_84856130cbfc, [])
                
                _d0c469cab746 = _28b6a2a59b3f((_15f81e41435c(_4942cf4bef0f) for _4942cf4bef0f in _c474d4885534 + _1b22b8858c06), _b1091e2c4b57=0)
                
                if _d0c469cab746 == 0:
                    continue
                
                _d8459278e496 = []
                for _43f1cbed3797 in _64dc3aca6b7d(_d0c469cab746):
                    _a1244bbcbdb2 = [_4942cf4bef0f[_43f1cbed3797] for _4942cf4bef0f in _c474d4885534 if _43f1cbed3797 < _15f81e41435c(_4942cf4bef0f)]
                    _a1244bbcbdb2 = [_2ff79736a664 for _2ff79736a664 in _a1244bbcbdb2 if _2ff79736a664 != _bad305b2a7b4]
                    _66b08a430b8c = _472392c744af(_a1244bbcbdb2)._e56aa236aaaa(1)[0][0] if _a1244bbcbdb2 else _a8a6b88bba0e
                    _d8459278e496._c3dbc972a2d7(_66b08a430b8c)
                _4a5a4c5c84f7._757a1f3b822a(_d8459278e496)
                
                _2bcabe1937cb = []
                for _43f1cbed3797 in _64dc3aca6b7d(_d0c469cab746):
                    _a1244bbcbdb2 = [_4942cf4bef0f[_43f1cbed3797] for _4942cf4bef0f in _1b22b8858c06 if _43f1cbed3797 < _15f81e41435c(_4942cf4bef0f)]
                    _a1244bbcbdb2 = [_2ff79736a664 for _2ff79736a664 in _a1244bbcbdb2 if _2ff79736a664 != _bad305b2a7b4]
                    _66b08a430b8c = _472392c744af(_a1244bbcbdb2)._e56aa236aaaa(1)[0][0] if _a1244bbcbdb2 else _bad305b2a7b4
                    _2bcabe1937cb._c3dbc972a2d7(_66b08a430b8c)
                _c364bcf49f94._757a1f3b822a(_2bcabe1937cb)
                
                if _84856130cbfc < _af421b243d03:
                    _09e3251e862c = [_2ff79736a664 for _2ff79736a664 in _e41de2ff1973._493cd1711e09(_84856130cbfc, []) if _2ff79736a664 != _bad305b2a7b4]
                    _ebd3c2096da6 = _472392c744af(_09e3251e862c)._e56aa236aaaa(1)[0][0] if _09e3251e862c else _dc83cede6cc2
                    _4a5a4c5c84f7._c3dbc972a2d7(_ebd3c2096da6)
                    
                    _66f90e0afbaa = [_2ff79736a664 for _2ff79736a664 in _4d986ca642b6._493cd1711e09(_84856130cbfc, []) if _2ff79736a664 != _bad305b2a7b4]
                    _2b95e13bab5e = _472392c744af(_66f90e0afbaa)._e56aa236aaaa(1)[0][0] if _66f90e0afbaa else _dc83cede6cc2
                    _c364bcf49f94._c3dbc972a2d7(_2b95e13bab5e)
            
            if _15f81e41435c(_4a5a4c5c84f7) > _15f81e41435c(_c364bcf49f94):
                _4a5a4c5c84f7 = _4a5a4c5c84f7[:_15f81e41435c(_c364bcf49f94)]
            elif _15f81e41435c(_4a5a4c5c84f7) < _15f81e41435c(_c364bcf49f94):
                _4a5a4c5c84f7 += [_a8a6b88bba0e] * (_15f81e41435c(_c364bcf49f94) - _15f81e41435c(_4a5a4c5c84f7))
            
            _a4fa12432992[_e7efde9bf2e8] = _1f8391c25d8a._36f9d92fff87(_4a5a4c5c84f7, _0c6d7db9100c=_4b0b078dc82c)
            _5ba7f4d6906a[_e7efde9bf2e8] = _1f8391c25d8a._36f9d92fff87(_c364bcf49f94, _0c6d7db9100c=_4b0b078dc82c)

        if _3dd36847e49d and _2577fcbc100f is not _9dd4dec2f1c9:
            _b066cff2a533(f"[SUMMARY] reconciled samples in batch = {_15f81e41435c(_d345c7ea73ef)} \
                sid={_2577fcbc100f} total_preds={_15f81e41435c(_a4fa12432992[_2577fcbc100f])} total_labels={_15f81e41435c(_5ba7f4d6906a[_2577fcbc100f])} \
                    raw_preds {_a4fa12432992[_2577fcbc100f]} and raw_labels{_5ba7f4d6906a[_2577fcbc100f]}\
                        chunks {_b76dba6b056f[_2577fcbc100f]}")

        _40f14277052f = _fb6c4519051b(_15f81e41435c(_311ecd83ef27) for _311ecd83ef27 in _5ba7f4d6906a._6c403f1d51b2())
        _b066cff2a533(f"Total reconciled labels: {_40f14277052f}")
        _f00c79f723e4, _d4ccb4ec8138 = self._3a254227f1a1(_a4fa12432992, _5ba7f4d6906a, _3dd36847e49d=_3dd36847e49d, _4b0b078dc82c=_4b0b078dc82c)
        _2620ba4a75c3 = _fb6c4519051b(_15f81e41435c(_311ecd83ef27) for _311ecd83ef27 in _d4ccb4ec8138._6c403f1d51b2())
        _b066cff2a533(f"Total reconciled labels classes: {_2620ba4a75c3}")
        return _a4fa12432992, _5ba7f4d6906a, _f00c79f723e4, _d4ccb4ec8138

    def _230fad04f68a(self, _a4fa12432992, _5ba7f4d6906a, _3dd36847e49d=_933f44d53181, _4b0b078dc82c="cpu"):
        _b09fb68d8fbe = _9b638b7cdb4d(self, "seq2class", {})
        _890bd12c6d7c = _9b638b7cdb4d(self, "tokenizer_separator_token", _9dd4dec2f1c9)
        _bad305b2a7b4 = _9b638b7cdb4d(self, "ignore_idx", -100)
        
        def _f9487b5e7cdc(_2201c1ff7e19, _2a6ef73095d2):
            _8c3542dfe26e = []
            _31da66fe0a19 = []
            for _b8b35b8b95d7, token in _57c78ca28b3f(_2201c1ff7e19):
                if token == _2a6ef73095d2 and _31da66fe0a19:
                    _8c3542dfe26e._c3dbc972a2d7(_31da66fe0a19)
                    _31da66fe0a19 = []
                elif token != _2a6ef73095d2:
                    _31da66fe0a19._c3dbc972a2d7(token)
            if _31da66fe0a19:
                _8c3542dfe26e._c3dbc972a2d7(_31da66fe0a19)
            return _8c3542dfe26e
        
        def _518231877b90(_35c232715075, _b09fb68d8fbe, _3dd36847e49d, _e7efde9bf2e8):
            _0c8f88d30676 = []
            _e16a04229791 = _a41d656755aa(_b09fb68d8fbe._333bd9c44ac6(), _bb5c7d11de82=_15f81e41435c, _0f967dee9a5f=_933f44d53181)
            for _b8b35b8b95d7, _2d4faebe2aa1 in _57c78ca28b3f(_35c232715075, 1):
                _f73a94a0331d = _3942976c761f(_2d4faebe2aa1)
                _335ad9d2d04e = self._df35fad62951
                for _bb5c7d11de82 in _e16a04229791:
                    if _15f81e41435c(_f73a94a0331d) >= _15f81e41435c(_bb5c7d11de82) and _f73a94a0331d[:_15f81e41435c(_bb5c7d11de82)] == _bb5c7d11de82:
                        _335ad9d2d04e = _b09fb68d8fbe[_bb5c7d11de82]
                        break
                _0c8f88d30676._c3dbc972a2d7(_335ad9d2d04e)

            return _0c8f88d30676
        
        _8ce667be2b5a, _06f36e8af4cd = {}, {}
        for _e7efde9bf2e8 in _a4fa12432992:
            _6241b74ed14c = _a4fa12432992[_e7efde9bf2e8]
            _311ecd83ef27 = _5ba7f4d6906a._493cd1711e09(_e7efde9bf2e8, _9dd4dec2f1c9)
            _08ec337cd43b = _6241b74ed14c._140b032a0d76() if _9dc4a511b2b9(_6241b74ed14c, _1f8391c25d8a._cf02ae8569a7) else _03e16f5514e2(_6241b74ed14c)
            _2c636b3c77a8 = _311ecd83ef27._140b032a0d76() if _9dc4a511b2b9(_311ecd83ef27, _1f8391c25d8a._cf02ae8569a7) else _03e16f5514e2(_311ecd83ef27) if _311ecd83ef27 else _9dd4dec2f1c9
            if _2c636b3c77a8 is not _9dd4dec2f1c9:
                _a124d978391d = _f4585d74a6ae(_2c636b3c77a8, _890bd12c6d7c)
                _659a32596065 = _611cde0dd00d(_a124d978391d, _b09fb68d8fbe, _e7efde9bf2e8 == 1 or _3dd36847e49d, _e7efde9bf2e8)
                _6101099afc20 = _f4585d74a6ae(_08ec337cd43b, _890bd12c6d7c)
                _09743a1fb491 = _611cde0dd00d(_6101099afc20, _b09fb68d8fbe, _e7efde9bf2e8 == 1 or _3dd36847e49d, _e7efde9bf2e8)
                if _15f81e41435c(_09743a1fb491) < _15f81e41435c(_659a32596065):
                    _09743a1fb491 += [0] * (_15f81e41435c(_659a32596065) - _15f81e41435c(_09743a1fb491))
                elif _15f81e41435c(_09743a1fb491) > _15f81e41435c(_659a32596065):
                    _09743a1fb491 = _09743a1fb491[:_15f81e41435c(_659a32596065)]
            else:
                _6101099afc20 = _f4585d74a6ae(_08ec337cd43b, _890bd12c6d7c)
                _09743a1fb491 = _611cde0dd00d(_6101099afc20, _b09fb68d8fbe, _e7efde9bf2e8 == 1 or _3dd36847e49d, _e7efde9bf2e8)
                _659a32596065 = [_bad305b2a7b4] * _15f81e41435c(_09743a1fb491)
            _8ce667be2b5a[_e7efde9bf2e8] = _1f8391c25d8a._36f9d92fff87(_09743a1fb491, _0c6d7db9100c=_4b0b078dc82c, _ae7e1b63f6e5=_1f8391c25d8a._22a7848c1804)
            _06f36e8af4cd[_e7efde9bf2e8] = _1f8391c25d8a._36f9d92fff87(_659a32596065, _0c6d7db9100c=_4b0b078dc82c, _ae7e1b63f6e5=_1f8391c25d8a._22a7848c1804)
        return _8ce667be2b5a, _06f36e8af4cd

    def _c5843096003b(self, _83f723ce2f93):
        _1f8391c25d8a._3e9d2081bce2._f8abd78ec9dd._b73c61cd9bfb(self._6afe756ccf67(), _fd56a4875bd2=1.0)
    
    def _9f23a7b8572c(self, _83f723ce2f93):
        for _c5ac3c413f74 in self._6afe756ccf67():
            if _c5ac3c413f74 is not _9dd4dec2f1c9:
                _c5ac3c413f74._2527a050966d._6cf961db544a(-5, 5)

    def _0bb2517c417d(self):
        _6985e7142324 = 0
        for _c5ac3c413f74 in self._6afe756ccf67():
            if _c5ac3c413f74._bf424ad85480 is not _9dd4dec2f1c9:
                _fad029f2cb2c = _c5ac3c413f74._bf424ad85480._6cfaa9e67501()._2527a050966d._add1038eb898(2)
                _6985e7142324 += _fad029f2cb2c._6622859f2ca5() ** 2
        return _6985e7142324 ** 0.5  # L2 norm

    def _e69f23afd4ea(self):
        _59368e3d0fdd = [_6241b74ed14c for _6241b74ed14c in self._6afe756ccf67() if _6241b74ed14c._1e5860305c6a]
        if not _59368e3d0fdd:
            _b066cff2a533("No trainable parameters. Skipping optimizer creation.")
            return _9dd4dec2f1c9
        
        _0309b8a3b039 = _410213270d75(lambda _6241b74ed14c: _6241b74ed14c._1e5860305c6a, self._6afe756ccf67())

        _1df8d19ed504 = {
            "adamw": _1f8391c25d8a._046bcaad6cca._fa54d4801ab0,
            "adamax": _1f8391c25d8a._046bcaad6cca._c51b9d116a79,
            "adam": _1f8391c25d8a._046bcaad6cca._4355a8c9ab5d,
        }
        _ed8a7f4e4f94 = _1df8d19ed504._493cd1711e09(self._5331e981f1a1._096ff9a6ff19(), _1f8391c25d8a._046bcaad6cca._4355a8c9ab5d)

        _83f723ce2f93 = _ed8a7f4e4f94(_0309b8a3b039, _ccd5ab415151=self._5be80d6bf3fb._ccd5ab415151, _b7623606eb09=0.001)

        _47c6d4b03b00 = self._2ff0b9d9e112._a1afc3f561fd
        _305b03048c3b = math._703f0153866f(0.1 * _47c6d4b03b00)

        _a1de99eb7efe = _1f8391c25d8a._046bcaad6cca._f67cf51eb5a1._e0ea663934a9(_83f723ce2f93, _b57ef692398c=lambda _731e782efe0e: (_731e782efe0e + 1) / _305b03048c3b)

        _c6b399150abd = _1f8391c25d8a._046bcaad6cca._f67cf51eb5a1._16d5f4558c07(
            _83f723ce2f93,
            _971164be8337=_28b6a2a59b3f(1, _47c6d4b03b00 - _305b03048c3b),
            _dd2516328722=2,
            _eabbb5608560=1e-6
        )
        _f67cf51eb5a1 = _1f8391c25d8a._046bcaad6cca._f67cf51eb5a1._51ac16390cdf(
            _83f723ce2f93,
            _040889a8b4da=[_a1de99eb7efe, _c6b399150abd],
            _4f2f8fd545a7=[_305b03048c3b]
        )
        return {"optimizer": _83f723ce2f93, "lr_scheduler": {"scheduler": _f67cf51eb5a1, "interval": "epoch", "monitor": "val_loss"}}
