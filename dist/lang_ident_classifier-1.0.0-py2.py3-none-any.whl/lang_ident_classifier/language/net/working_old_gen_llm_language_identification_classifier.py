# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : gen_llm_language_identification_classifier.py
# @Time             : 2025-10-23 14:02 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------


from _6e2e8f8c4ce9 import _8c22bbe80f99
import _e3793ff11f55
from _57e646951e65 import _172ac6206677
import _cab4f045067b
import _85e2a9ab5578
import _c409d48270dc
from _023db692ed59 import _84a0d7c18a5f
import _9ed293b4c4b4 as _6743283d9eaf
import _5ce544fa83bb as _899bc7544583
import _e4bb64dcbbdf
import _b05f8f2f6185 as _61a8c04c8e73
from _a890c4eeb3b7._fbbd06eff3ec._3cb8cfa9c5a3._cdeb74554b25 import _617518bbfcd6
from _97a5c1a05b4e import _8e739537fc38, _01d99af120c4, _fd59b03049d4, _29f325e82dab, _ca05bd251e9e

from _7495bca1c83c._09a13a009ab0._fa0651e4fd95._3b4aa77ddd56 import _4c75f3c58a12
from _7495bca1c83c._09a13a009ab0._6e0c4c329726._14c6ee8520d2 import _a69433bfc037
from _7495bca1c83c._09a13a009ab0._6e0c4c329726._8b22e4906483 import _12b4f3b05d33
from _7495bca1c83c._09a13a009ab0._6e0c4c329726._da4ee250831e import _1afe787e7877
from _7495bca1c83c._09a13a009ab0._904487d6d25c._a374cc048e40 import _dc35915e1530
# expose only the classifier from the module
_69581b388a95 = ["GenLLMLanguageIdentificationClassifier"]

_b440832c3234 = 'cuda' if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f() else 'cpu'
_54bf526a88c9 = _328c4ab5cbf4  # global frozen embedding (kept for compatibility)

    
class _1aedcd85b24b(_61a8c04c8e73._aceb9241dca2):
    """
    Original GenLLM classifier logic preserved.
    SafeModuleWrapper has been moved here as a nested private class (name starts with underscore).
    """

    class _12a7cad41081(_e4bb64dcbbdf._e9327961453e._d42bc316140d):
        """
        Tiny residual adapter: down-project -> ReLU -> up-project, residual-add.
        Keeps new knowledge in a small set of parameters.
        """
        def _4539ecd2bebe(self, _c076e801db28: _a54de05ad7e6, _a45184c55765: _a54de05ad7e6 = 64):
            _fd539caec650()._13f1a8114e2e()
            self._bc03b3201589 = _e4bb64dcbbdf._e9327961453e._496e4f168b21(_c076e801db28, _a45184c55765, _73f4b996f923=_32fbcb72e5da)
            self._41e02d75a95a = _e4bb64dcbbdf._e9327961453e._6db0d34fa3d2(_96ceb41f0e7f=_af637352b06d)
            self._ff22f73c3784 = _e4bb64dcbbdf._e9327961453e._496e4f168b21(_a45184c55765, _c076e801db28, _73f4b996f923=_32fbcb72e5da)
            # start adapter near-zero so initial behavior is identity
            _e4bb64dcbbdf._e9327961453e._dfaf2dff2f3b._dac84ba3721a(self._ff22f73c3784._6063c232ab97)
            _e4bb64dcbbdf._e9327961453e._dfaf2dff2f3b._2625686fae0e(self._bc03b3201589._6063c232ab97, _2c98adec120d=_85e2a9ab5578._a0b3d53eaa5f(5))

        def _b73e5fa6a3ae(self, _ec38718c4c78: _e4bb64dcbbdf._d76c026675cc) -> _e4bb64dcbbdf._d76c026675cc:
            # supports x shape (B, L, D) or (B, D)
            if _ec38718c4c78._c076e801db28() == 2:
                _c50c98af98ee = self._ff22f73c3784(self._41e02d75a95a(self._bc03b3201589(_ec38718c4c78)))
                return _ec38718c4c78 + _c50c98af98ee
            _58f0f386bf7d, _e79c19c8c55f, _d8c7af75c9ee = _ec38718c4c78._6c1aa951182d
            _60eef9790f15 = _ec38718c4c78._d65b5ff16279(-1, _d8c7af75c9ee)                    # (B*L, D)
            _60eef9790f15 = self._ff22f73c3784(self._41e02d75a95a(self._bc03b3201589(_60eef9790f15)))  # (B*L, D)
            _60eef9790f15 = _60eef9790f15._d65b5ff16279(_58f0f386bf7d, _e79c19c8c55f, _d8c7af75c9ee)
            return _ec38718c4c78 + _60eef9790f15
        
    class _3ae7e02887a3(_e4bb64dcbbdf._e9327961453e._d42bc316140d):
        """
        Private wrapper to stabilize fragile submodules.
        Moved inside the main class so it isn't exported at module level.
        Behavior preserved from original code: attempts torch.compile, sanitizes inputs/outputs.
        """

        def _4539ecd2bebe(self, _470b6998a105, _4526ea9a6449=-5, _6ea87c5d9d49=5):
            _fd539caec650()._13f1a8114e2e()
            self._470b6998a105 = _470b6998a105
            self._4526ea9a6449 = _4526ea9a6449
            self._6ea87c5d9d49 = _6ea87c5d9d49
            # torch._dynamo.config.suppress_errors = True
            # if not isinstance(module, LlamaRMSNorm):
            #     # preserve original behavior: compile unless it's LlamaRMSNorm
            #     # self.module = torch.compile(self.module, mode="default", backend="cudagraphs")
            #     self.module = torch.compile(self.module, mode="default", dynamic=True)

        def _b73e5fa6a3ae(self, *_b0d9188b5704, **_c3cbc138b699):
            _b0d9188b5704 = _65b2274d3707(
                _fc27d0e3fde6._1527c1bbfcb3(_e4bb64dcbbdf._50e552eb663c)._8d7544c4ca4d(-10, 10) if _36b35b705a0a(_fc27d0e3fde6, _e4bb64dcbbdf._d76c026675cc) and _fc27d0e3fde6._696888dee613 != _e4bb64dcbbdf._50e552eb663c else _fc27d0e3fde6
                for _fc27d0e3fde6 in _b0d9188b5704
            )
            for _e778c53ecf17, _fc27d0e3fde6 in _e9a296ba2794(_b0d9188b5704):
                if _36b35b705a0a(_fc27d0e3fde6, _e4bb64dcbbdf._d76c026675cc) and not _e4bb64dcbbdf._d8aa37e7114c(_fc27d0e3fde6)._d2f1329f198b():
                    _fc27d0e3fde6 = _e4bb64dcbbdf._e946f671652b(_fc27d0e3fde6)
            _88353bb66cc4 = self._470b6998a105(*_b0d9188b5704, **_c3cbc138b699)
            if _36b35b705a0a(_88353bb66cc4, _e4bb64dcbbdf._d76c026675cc):
                _88353bb66cc4 = _88353bb66cc4._1527c1bbfcb3(_e4bb64dcbbdf._50e552eb663c)
                if not _e4bb64dcbbdf._d8aa37e7114c(_88353bb66cc4)._d2f1329f198b():
                    _88353bb66cc4 = _e4bb64dcbbdf._e946f671652b(_88353bb66cc4)
                _88353bb66cc4._b6c76a56ce51(self._4526ea9a6449, self._6ea87c5d9d49)
            return _88353bb66cc4

    # --- original __init__ signature and body preserved ---
    def _4539ecd2bebe(
        self,
        _5ae89e1d2a89,
        _16c7f5a2aa2e,
        _ffca64ad2db0,
        _0e322d0ed6a6,
        _a00ea936dab7,
        _58f02110d852,
        _9f62147308ef,
        _1a274143fe77,
        _b82fb7ea2bc1,
        _34e585f62f92,
        _c7f61910de9e,
        _7ffee4c06f0d: _a54de05ad7e6 = 20,
        _54fbffbd9123 = _328c4ab5cbf4,
        _392b042b7b82=_328c4ab5cbf4,
        _22c7c7029692=0.9,
        _e8c3c33f8ac2:_ba532de2f4f7=_328c4ab5cbf4,
    ):
        _fd539caec650(_57178ad0c6d2, self)._13f1a8114e2e()
        # self.save_hyperparameters(ignore=["pretrained_embedding_model","tokenizer"])
        self._c3c681dcddb3({
            "lr": _da69e38d0aaf(_ffca64ad2db0),
            "optimizer": _ba532de2f4f7(_0e322d0ed6a6),
            "num_backbone_model_units_unfrozen": _a54de05ad7e6(_9f62147308ef),
            "loss_type": _ba532de2f4f7(_1a274143fe77),
            "is_train": _f8f4aab1c1b9(_b82fb7ea2bc1),
            "random_seed": _a54de05ad7e6(_7ffee4c06f0d),
        })
        self._7ffee4c06f0d = _7ffee4c06f0d
        _61a8c04c8e73._9cd53e05d21f(_7ffee4c06f0d, _dca4ebf0bd4f=_af637352b06d)
        _e4bb64dcbbdf._99165ef2767f(_7ffee4c06f0d)
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            _e4bb64dcbbdf._dcc587a46759._57e8ed64c24d(_7ffee4c06f0d)
        _6743283d9eaf._9d8d8c8ba432._7f7fccc4572f(_7ffee4c06f0d)
        self._392b042b7b82 = _a54de05ad7e6(_392b042b7b82) if _392b042b7b82 is not _328c4ab5cbf4 else _328c4ab5cbf4
        self._34e585f62f92 = _34e585f62f92
        self._e8c3c33f8ac2 = _e8c3c33f8ac2
        # TODO: REMOVE THIS HARDCODING
        # if not self.tokenizer.pad_token_id:
        #     self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|>
        if not self._34e585f62f92._391be92f0c3a and "<PAD>" not in self._34e585f62f92._a00248e73f3b():
            self._34e585f62f92._2e5cadf487c4(["<PAD>"], _4df6f7b6dae9=_32fbcb72e5da)
            _bcac40d6cfb9 = self._34e585f62f92._68bc761b2def("<PAD>")
            _4cf0297f2b73(f"Added padding token  <PAD> with (id: {_bcac40d6cfb9})")
        
        self._9e7775c9f702 = _34e585f62f92._c379ee6da8be(" ", _ef017ce5d796=_32fbcb72e5da)[0]
        self._e582a322b0e0 = (
            _e4bb64dcbbdf._eefb4dad793c("cuda:{}"._593edc59ede7(_58f02110d852["gpu_local_rank"]))
            if _58f02110d852["gpu_local_rank"] != -1
            else "cpu"
        )
        self._54fbffbd9123 = _54fbffbd9123
        self._22c7c7029692 = _22c7c7029692
        self._16c7f5a2aa2e =  ["unk"] + _16c7f5a2aa2e if self._22c7c7029692 > 0 else _16c7f5a2aa2e
        self._6955b7bc9d35 = _de338412d1d9(self._16c7f5a2aa2e)
        # self.decision_threshold = decision_threshold
        # self.class_names =  ["unk"] + class_names if self.decision_threshold > 0 else class_names
        # self.class_names =  class_names
        self._a9d5da5c4947 = {}
        # for idx, cname in enumerate(self.class_names):
        #     seq = self.tokenizer.encode(cname, add_special_tokens=False)
        #     self.class2seq[idx] = seq
        # Add only if class name splits into >1 token
        for _fcc7d2505631 in self._16c7f5a2aa2e:
            if _de338412d1d9(self._34e585f62f92._c379ee6da8be(_fcc7d2505631, _ef017ce5d796=_32fbcb72e5da)) > 1:
                _b0eb6528d6fd = f"{_fcc7d2505631}"
                if _b0eb6528d6fd not in self._34e585f62f92._a00248e73f3b():
                    self._34e585f62f92._2e5cadf487c4([_b0eb6528d6fd], _4df6f7b6dae9=_32fbcb72e5da)
                    _bcac40d6cfb9 = self._34e585f62f92._68bc761b2def(_b0eb6528d6fd)
                    _4cf0297f2b73(f"Added class '{_fcc7d2505631}' Token: {_b0eb6528d6fd} (id: {_bcac40d6cfb9})")

        # Map every class to single token ID
        self._a9d5da5c4947 = {
            _109547f9d4fc: [self._34e585f62f92._68bc761b2def(f"{_fcc7d2505631}")]
            for _109547f9d4fc, _fcc7d2505631 in _e9a296ba2794(self._16c7f5a2aa2e)
        }

        self._dc7e4539997c = {_65b2274d3707(_0c484b3b7363): _d9468c96802b for _d9468c96802b, _0c484b3b7363 in self._a9d5da5c4947._413af3e89067()}
        self._c6832cff36f9 = _8c22bbe80f99(_b753ba625fdf)
        for _486d8bcc1d41, _0c484b3b7363 in self._a9d5da5c4947._413af3e89067():
            self._c6832cff36f9[_de338412d1d9(_0c484b3b7363)]._82be82402d25((_486d8bcc1d41, _0c484b3b7363))
        self._13834352031a = 0
        _4cf0297f2b73(f"SEQ {self._a9d5da5c4947} and {self._dc7e4539997c}")
        self._5016022be9b4 = _34e585f62f92._391be92f0c3a or _34e585f62f92._21a8281b2699
        self._a00ea936dab7 = _a00ea936dab7
        self._d950148c26bb = "multiclass"
        self._4bf55032d159 = -100
        self._4c82cc759594 = _34e585f62f92._c379ee6da8be("assistant<|end_header_id|>\n\n", _ef017ce5d796=_32fbcb72e5da)
        self._58a846e930f4 = self._6923ec745247()

        # Set the embedding layer directly from self.embedding
        # Ensure embeddings always run in FP32
        self._c4e5d5564c5d = _5ae89e1d2a89
        # Resize vocab based token embeddings
        self._c4e5d5564c5d._8d9aa1bbadf4(_de338412d1d9(self._34e585f62f92))

        # self.embedding.requires_grad_(False).to(self.curr_device, non_blocking=True)
        self._c4e5d5564c5d._c2a73301902e(_32fbcb72e5da)
        _54bafdeed0a3 = _dc35915e1530()  # bfloat16 or float16

        for _0fc57c410621, _470b6998a105 in self._6b7614aadd95():
            if not _1efa1004f500(_160d36fbe03b._4ea9af606fe6 for _160d36fbe03b in _470b6998a105._e53c99d6ebb7(_af6099d8c86e=_32fbcb72e5da)):
                # FROZEN → BF16 (save memory)
                _470b6998a105._1527c1bbfcb3(_696888dee613=_54bafdeed0a3)
            else:
                # TRAINABLE → FP32 (stable grads)
                _470b6998a105._1527c1bbfcb3(_696888dee613=_e4bb64dcbbdf._50e552eb663c)
        self._c4e5d5564c5d._1527c1bbfcb3(self._e582a322b0e0)
        if _e297b1612eac(self._c4e5d5564c5d, "gradient_checkpointing_enable"):
            self._c4e5d5564c5d._9a65be39f87c()
        # determine embedding dim robustly from model config if available
        _36f95afdd2b6 = _baf3f8ae377b(_baf3f8ae377b(self._c4e5d5564c5d, "config", _328c4ab5cbf4), "hidden_size", _328c4ab5cbf4)
        if _36f95afdd2b6 is _328c4ab5cbf4:
            # fallback to common default — change if your model uses a different hidden size
            _36f95afdd2b6 = 768
        
        # cache output projection to avoid runtime getattr/hasattr in forward (compile-friendly)
        if _e297b1612eac(self._c4e5d5564c5d, "lm_head") and _baf3f8ae377b(self._c4e5d5564c5d, "lm_head") is not _328c4ab5cbf4:
            self._94d354d2f71c = self._c4e5d5564c5d._53a41106bfb0
        else:
            _7ec95f718db3 = _baf3f8ae377b(self._c4e5d5564c5d, "get_output_embeddings", _328c4ab5cbf4)
            self._94d354d2f71c = _7ec95f718db3() if _434032815198(_7ec95f718db3) else _328c4ab5cbf4

        # mark presence and ensure module (if any) is on the same device
        self._a2e7233d4eac = self._94d354d2f71c is not _328c4ab5cbf4
        if self._a2e7233d4eac:
            # move lm_head params/buffers to the model device (safe no-op if already there)
            self._94d354d2f71c._1527c1bbfcb3(self._e582a322b0e0)


        # create small adapter (bottleneck 64 recommended; reduce to 32 for very small memory)
        self._fcec8c5849f9 = self._938fab852c97(_c076e801db28=_36f95afdd2b6, _a45184c55765=64)
        self._fcec8c5849f9._1527c1bbfcb3(self._e582a322b0e0)
        for _160d36fbe03b in self._fcec8c5849f9._e53c99d6ebb7():
            _160d36fbe03b._4ea9af606fe6 = _af637352b06d
            
        if _9f62147308ef > 0:
            if "llama" in self._54fbffbd9123:
                for _65ce7806825e in self._c4e5d5564c5d._e53c99d6ebb7():
                    if not _65ce7806825e._7e4ce60a0667:
                        _65ce7806825e = _65ce7806825e._6acdfe891462()
                    _65ce7806825e._4ea9af606fe6 = _32fbcb72e5da  # Freeze all layers initially

                # Access the LlamaDecoderLayers directly
                _dd266412b865 = self._c4e5d5564c5d._9cf0b3129cf7._c2bf4f6fc568  # (LlamaModel -> layers: ModuleList)

                # Unfreeze the last `num_backbone_model_units_unfrozen` layers
                for _3e292858b6a2 in _dd266412b865[-_9f62147308ef:]:
                    for _65ce7806825e in _3e292858b6a2._e53c99d6ebb7():
                        if _36b35b705a0a(_65ce7806825e, _e4bb64dcbbdf._d76c026675cc) and (_65ce7806825e._47315a0d5e00() or _e4bb64dcbbdf._d713fb159aee(_65ce7806825e)):
                            _65ce7806825e._4ea9af606fe6 = _af637352b06d
                if _e297b1612eac(self._c4e5d5564c5d, "lm_head"):
                    self._c4e5d5564c5d._53a41106bfb0._4ea9af606fe6 = _af637352b06d

        self._c483d2261737 = 1
        _4cf0297f2b73(f"DEBUG xth_batch init {self._c483d2261737}")
        global _54bf526a88c9
        _54bf526a88c9 = _e3793ff11f55._67f5d75835b6(self._c4e5d5564c5d)._1c17e9b0ef3d()
        self._ffca64ad2db0 = _ffca64ad2db0

        self._6648d9694cb6 = {}
        self._d592d7d7d80d = {}

        # Loss function initialization
        if _1a274143fe77._956e2df2edc7() == "class_weighted_cross_entropy_loss":
            self._d592d7d7d80d['criterion'] = _12b4f3b05d33(_a00ea936dab7=self._a00ea936dab7,
                                                            _eefb4dad793c=self._e582a322b0e0,
                                                            _b09acbd6d439=self._4bf55032d159,
                                                            _18154878fb79=self._9e7775c9f702)
        elif _1a274143fe77._956e2df2edc7() == "focal_loss":
            self._d592d7d7d80d['criterion'] = _1afe787e7877(_39d4ce721bc8=0.25,
                                                     _eefb4dad793c=self._e582a322b0e0,
                                                     _b09acbd6d439=self._4bf55032d159,
                                                     _18154878fb79=self._9e7775c9f702)
        elif _1a274143fe77._956e2df2edc7() == "class_weighted_focal_loss":
            self._d592d7d7d80d['criterion'] = _1afe787e7877(_39d4ce721bc8=self._a00ea936dab7,
                                                     _eefb4dad793c=self._e582a322b0e0,
                                                     _b09acbd6d439=self._4bf55032d159,
                                                     _18154878fb79=self._9e7775c9f702)
        elif _1a274143fe77._956e2df2edc7() == "class_weighted_focal_loss_with_adaptive_focus_type1":
            self._d592d7d7d80d['criterion'] = _a69433bfc037(_39d4ce721bc8=self._a00ea936dab7,
                                                                      _c27ccdd5c5aa='type1',
                                                                      _eefb4dad793c=self._e582a322b0e0,
                                                                      _b09acbd6d439=self._4bf55032d159,
                                                                      _18154878fb79=self._9e7775c9f702)
        elif _1a274143fe77._956e2df2edc7() == "class_weighted_focal_loss_with_adaptive_focus_type2":
            self._d592d7d7d80d['criterion'] = _a69433bfc037(_39d4ce721bc8=self._a00ea936dab7,
                                                                      _c27ccdd5c5aa='type2',
                                                                      _eefb4dad793c=self._e582a322b0e0,
                                                                      _b09acbd6d439=self._4bf55032d159,
                                                                      _18154878fb79=self._9e7775c9f702)
        elif _1a274143fe77._956e2df2edc7() == "class_weighted_focal_loss_with_adaptive_focus_type3":
            self._d592d7d7d80d['criterion'] = _a69433bfc037(_39d4ce721bc8=self._a00ea936dab7,
                                                                      _c27ccdd5c5aa='type3',
                                                                      _eefb4dad793c=self._e582a322b0e0,
                                                                      _b09acbd6d439=self._4bf55032d159,
                                                                      _18154878fb79=self._9e7775c9f702)
        else:
            self._d592d7d7d80d['criterion'] = _12b4f3b05d33(_eefb4dad793c=self._e582a322b0e0,
                                                            _b09acbd6d439=self._4bf55032d159,)

        # self.metrics['micro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="micro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['macro_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average="macro",
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_accuracy'] = Accuracy(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_precision'] = Precision(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_recall'] = Recall(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['classwise_f1'] = F1Score(
        #     num_classes=len(self.class_names),
        #     average=None,
        #     task=self.classification_task,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        # self.metrics['confmat'] = ConfusionMatrix(
        #     num_classes=len(self.class_names),
        #     task=self.classification_task,
        #     normalize=None,
        #     ignore_index=self.ignore_idx,
        # ).to(self.curr_device, non_blocking=True)

        self._07e0430d8465 = 0.99
        self._091f397f836e = 0.3
        self._db2b03a63fa8 = 0.30
        self._08fcfe082b28 = 0.25
        self._e445b263da6b = 0.6
        self._d100448a95b2 = 0.995
        self._eef2e9f4c56f = 0.60
        self._6a743d3f63e2 = 0.20
        self._53d2c66b920a = _baf3f8ae377b(self, "batch_counter", 0)


        self._9966df9990bd = []
        self._6028b5ae0973 = []

        self._3ac063483aca = _0e322d0ed6a6._956e2df2edc7()
        self._6a755f2e0627()

        self._8f62a9497836(self._c4e5d5564c5d)
    
    def _c7b6a1bd5ed2(self):
        # rebuild all metrics on the correct device
        self._6648d9694cb6['micro_accuracy'] = _8e739537fc38(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b="micro",
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['macro_accuracy'] = _8e739537fc38(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b="macro",
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['macro_precision'] = _fd59b03049d4(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b="macro",
            _9942f2fbd14c=self. _d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['macro_recall'] = _29f325e82dab(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b="macro",
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['macro_f1'] = _ca05bd251e9e(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b="macro",
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['classwise_accuracy'] = _8e739537fc38(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b=_328c4ab5cbf4,
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['classwise_precision'] = _fd59b03049d4(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b=_328c4ab5cbf4,
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['classwise_recall'] = _29f325e82dab(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b=_328c4ab5cbf4,
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['classwise_f1'] = _ca05bd251e9e(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _2ec5af93d60b=_328c4ab5cbf4,
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)

        self._6648d9694cb6['confmat'] = _01d99af120c4(
            _6955b7bc9d35=_de338412d1d9(self._16c7f5a2aa2e),
            _9942f2fbd14c=self._d950148c26bb,
            _b09acbd6d439=self._4bf55032d159,
        )._1527c1bbfcb3(self._e582a322b0e0)


    def _7d2fe3291b67(self, _7fd3fa274f47=_328c4ab5cbf4):
        """Calculate batch counts and set xth_batch_to_consider."""
        _6e75bbb741af = 0
        _690b65286b2c = 0
        if self._c3a3ce9f96f2._3ee5ff7cf5fb is not _328c4ab5cbf4:
            if _e297b1612eac(self._c3a3ce9f96f2._3ee5ff7cf5fb, 'train_dataset') and self._c3a3ce9f96f2._3ee5ff7cf5fb._e06ae18e6d9a is not _328c4ab5cbf4:
                _6e75bbb741af = _de338412d1d9(self._c3a3ce9f96f2._3ee5ff7cf5fb._e06ae18e6d9a)
            if _e297b1612eac(self._c3a3ce9f96f2._3ee5ff7cf5fb, 'val_dataset') and self._c3a3ce9f96f2._3ee5ff7cf5fb._f9b8b507daff is not _328c4ab5cbf4:
                _690b65286b2c = _de338412d1d9(self._c3a3ce9f96f2._3ee5ff7cf5fb._f9b8b507daff)
            _71a1ba50a347 = self._c3a3ce9f96f2._3ee5ff7cf5fb._71a1ba50a347
            _cd3d00d4d6a9 = (_6e75bbb741af + _71a1ba50a347 - 1) // _71a1ba50a347 if _6e75bbb741af > 0 else 1
            _0119d29549ba = (_690b65286b2c + _71a1ba50a347 - 1) // _71a1ba50a347 if _690b65286b2c > 0 else 1
            _03300fe7821e = _20fefce46ebd(_cd3d00d4d6a9, _0119d29549ba) if _690b65286b2c > 0 else _cd3d00d4d6a9
            _8479cf3f5468 = 0.1
            # self.xth_batch_to_consider = max(1, int(xth_fraction * num_batches))
            self._c483d2261737 = 1
            _4cf0297f2b73(f"DEBUG Batch Info: num_train_batches={_cd3d00d4d6a9}, num_val_batches={_0119d29549ba}, xth_batch_to_consider={self._c483d2261737}")

    def _e3af97ca71c1(self, _d7df332fc684, _137d697be814):
        if _d7df332fc684._956e2df2edc7() == "parametric_relu":
            return _e4bb64dcbbdf._e9327961453e._d34ad99a90d2(_137d697be814=1)
        elif _d7df332fc684._956e2df2edc7() == "leaky_relu":
            return _e4bb64dcbbdf._e9327961453e._cc1244d1d4ad(_96ceb41f0e7f=_32fbcb72e5da)
        else:
            return _e4bb64dcbbdf._e9327961453e._6db0d34fa3d2(_96ceb41f0e7f=_32fbcb72e5da)

    def _92834e726b83(self, _470b6998a105, _d79006fc0aa0=""):
        """ Recursively attach hooks to all layers in the model to detect NaNs. """
        for _0fc57c410621, _b19f84770315 in _470b6998a105._c0dfe27db976():
            _888876b5908b = f"{_d79006fc0aa0}.{_0fc57c410621}" if _d79006fc0aa0 else _0fc57c410621

            def _c7ebed40c3a9(_3627dc104880, _fc27d0e3fde6, _c50c98af98ee):
                if _36b35b705a0a(_c50c98af98ee, _e4bb64dcbbdf._d76c026675cc) and _c50c98af98ee._28b2cf905d29()._1efa1004f500():
                    _4cf0297f2b73(f"NaN detected in {_888876b5908b} ({_3627dc104880._634dfc1903fb.__name__}) ({_c50c98af98ee._696888dee613})")

            _b19f84770315._f5f1fa143385(_f7e2115519dc)

            self._8f62a9497836(_b19f84770315, _888876b5908b)

    def _23fb41f7cfe3(self, _470b6998a105):
        return _1efa1004f500(_160d36fbe03b._4ea9af606fe6 for _160d36fbe03b in _470b6998a105._e53c99d6ebb7())

    def _aa8ac04c200a(self):
        """Convert RMSNorm, Linear4bit, SiLU, dropout, and attention layers to float32 and wrap them safely."""
        _8d8f40f73188 = []
        for _0fc57c410621, _470b6998a105 in self._6b7614aadd95():
            if not self._a2f757f695e8(_470b6998a105):
                continue
            _150da7ca13b2 = (
                "norm" in _0fc57c410621._7da5fdcdd27e() or 
                "linear4bit" in _0fc57c410621._7da5fdcdd27e() or 
                _1efa1004f500(_41e02d75a95a in _0fc57c410621._7da5fdcdd27e() for _41e02d75a95a in ["gelu", "selu", "relu", "prelu", "leakyrelu", "elu", "sigmoid", "tanh", "gated", "act"]) or 
                "attention" in _0fc57c410621._7da5fdcdd27e() or 
                "dropout" in _0fc57c410621._7da5fdcdd27e() or 
                _36b35b705a0a(_470b6998a105, (_617518bbfcd6, _e4bb64dcbbdf._e9327961453e._496e4f168b21, _e4bb64dcbbdf._e9327961453e._c9a5b2a5ca51))
            )
            if _150da7ca13b2:
                if _e297b1612eac(_470b6998a105, "eps"):
                    _470b6998a105._fd52291b2981 = 1e-3
                _470b6998a105 = _470b6998a105._1527c1bbfcb3(_e4bb64dcbbdf._50e552eb663c)
                if not _36b35b705a0a(_470b6998a105, _57178ad0c6d2._3d16f4780663):
                    _8d8f40f73188._82be82402d25((_0fc57c410621, _57178ad0c6d2._3d16f4780663(_470b6998a105, _4526ea9a6449=-10, _6ea87c5d9d49=10)))
        for _0fc57c410621, _90755d678c98 in _8d8f40f73188:
            _3b3f6be4e14a, _6de8815b9478 = self._919a0a487e00(_0fc57c410621)
            if _3b3f6be4e14a is not _328c4ab5cbf4:
                _24bff0c522f7(_3b3f6be4e14a, _6de8815b9478, _90755d678c98)

    def _b3a60e693f39(self, _998835ee1a3e):
        """Finds the parent module and attribute name given the full module path."""
        _7c1a61fe3bd7 = _998835ee1a3e._6adb0b776a69('.')
        _7c469e9fe0dd = self
        for _57256bc2d4f8 in _7c1a61fe3bd7[:-1]:
            _7c469e9fe0dd = _baf3f8ae377b(_7c469e9fe0dd, _57256bc2d4f8, _328c4ab5cbf4)
            if _7c469e9fe0dd is _328c4ab5cbf4:
                return _328c4ab5cbf4, _328c4ab5cbf4
        return _7c469e9fe0dd, _7c1a61fe3bd7[-1]

    def _cb710ceae23c(self, _69339520d1f1: _e4bb64dcbbdf._d76c026675cc, _08f39447100a: _e4bb64dcbbdf._d76c026675cc, _93a02817ebbb: _e4bb64dcbbdf._d76c026675cc) -> _b2f6c7aff653:
        """
        Build aux_term = s(t) * (lambda_kl_eff * kl_loss + lambda_cos_eff * contrast_loss)
        Uses cached self._last_teacher_conf if available for gating w.
        Returns dict with aux_term and diagnostics.
        """
        _eefb4dad793c = _69339520d1f1._eefb4dad793c

        # 1) gating w (use cached per-example teacher_conf if available)
        _f14ed7b3d69b = _baf3f8ae377b(self, "_last_teacher_conf", _328c4ab5cbf4)
        if _f14ed7b3d69b is _328c4ab5cbf4:
            # no teacher info => w = 0 (no distillation)
            _a50250739193 = 0.0
        else:
            _7656fa71a2bc = (_f14ed7b3d69b >= _da69e38d0aaf(_baf3f8ae377b(self, "teacher_conf_tau", 0.6)))._da69e38d0aaf()
            _a50250739193 = _da69e38d0aaf(_7656fa71a2bc._ea09f63bba46()._14658237ae7a()._2e7bf07d832c()) if _7656fa71a2bc._1c7b5f322389() > 0 else 0.0

        # apply gating to the batch scalars
        _b02d3395fd9e = _08f39447100a * _da69e38d0aaf(_a50250739193)
        _7b4b41aac271 = _93a02817ebbb * _da69e38d0aaf(_a50250739193)

        # 2) EMAs for autoscaling
        _cdc6cf1cb5d8 = _da69e38d0aaf((_b02d3395fd9e + _7b4b41aac271)._6acdfe891462()._14658237ae7a()._2e7bf07d832c())
        _551303f749a4 = _da69e38d0aaf(_69339520d1f1._6acdfe891462()._14658237ae7a()._2e7bf07d832c())
        if _baf3f8ae377b(self, "ema_task", _328c4ab5cbf4) is _328c4ab5cbf4:
            self._8afae17eeb51 = _551303f749a4
            self._eedb4d627576 = _cdc6cf1cb5d8 + 1e-12
        else:
            _39d4ce721bc8 = _da69e38d0aaf(_baf3f8ae377b(self, "ema_alpha", 0.99))
            self._8afae17eeb51 = _39d4ce721bc8 * _da69e38d0aaf(self._8afae17eeb51) + (1.0 - _39d4ce721bc8) * _551303f749a4
            self._eedb4d627576  = _39d4ce721bc8 * _da69e38d0aaf(self._eedb4d627576)  + (1.0 - _39d4ce721bc8) * _cdc6cf1cb5d8

        _2b0d4f04ee94 = _da69e38d0aaf(_baf3f8ae377b(self, "distill_target_ratio", 0.3))
        _7bd6bef15165 = (_da69e38d0aaf(self._8afae17eeb51) / (_da69e38d0aaf(self._eedb4d627576) + 1e-12)) * _2b0d4f04ee94
        _3a4eef6df8f8 = _da69e38d0aaf(_7bd6bef15165)

        # 3) epoch schedules for lambda_kl and lambda_cos
        _6c9719e7cdf4 = _da69e38d0aaf(_baf3f8ae377b(self._c3a3ce9f96f2, "current_epoch", _baf3f8ae377b(self._c3a3ce9f96f2, "global_step", 0.0)))
        _21759617337b = _da69e38d0aaf(_0e9a0670a19a(1, _baf3f8ae377b(self._c3a3ce9f96f2, "max_epochs", 1)))
        _aab7ff41e0cd = _20fefce46ebd(_0e9a0670a19a(_6c9719e7cdf4 / _21759617337b, 0.0), 1.0)
        _9d8724772a67 = 0.30
        _8f1e114bddf3 = _da69e38d0aaf(_baf3f8ae377b(self, "kl_base", 0.30)) * _20fefce46ebd(_aab7ff41e0cd / _9d8724772a67, 1.0)
        _08fcfe082b28 = _da69e38d0aaf(_baf3f8ae377b(self, "cos_base", 0.25))
        _c841e96edb9b = _08fcfe082b28 + (0.10 - _08fcfe082b28) * _aab7ff41e0cd

        # 4) shift detector r(t) using EMA on teacher_conf mean
        _48d28d2e4063 = _da69e38d0aaf(self._591ac4f21f1c._ea09f63bba46()._14658237ae7a()._2e7bf07d832c()) if _baf3f8ae377b(self, "_last_teacher_conf", _328c4ab5cbf4) is not _328c4ab5cbf4 else 0.0
        if _baf3f8ae377b(self, "ema_teacher_conf", _328c4ab5cbf4) is _328c4ab5cbf4:
            self._5c7834b4cf9b = _48d28d2e4063
        else:
            _58f0f386bf7d = _da69e38d0aaf(_baf3f8ae377b(self, "teacher_conf_beta", 0.995))
            self._5c7834b4cf9b = _58f0f386bf7d * _da69e38d0aaf(self._5c7834b4cf9b) + (1.0 - _58f0f386bf7d) * _48d28d2e4063

        _eef2e9f4c56f = _da69e38d0aaf(_baf3f8ae377b(self, "tau_warn", 0.60))
        _6a743d3f63e2 = _da69e38d0aaf(_baf3f8ae377b(self, "tau_detect", 0.20))
        _ebef011d137d = _0e9a0670a19a(1e-12, (_eef2e9f4c56f - _6a743d3f63e2))
        _040fe991045e = (_da69e38d0aaf(self._5c7834b4cf9b) - _6a743d3f63e2) / _ebef011d137d
        _040fe991045e = _0e9a0670a19a(0.0, _20fefce46ebd(1.0, _040fe991045e))

        _4ec74658adbe = _8f1e114bddf3 * _040fe991045e
        _ba0cb9fae294 = _c841e96edb9b * _040fe991045e

        # 5) final aux term
        _1e058dda2415 = _e4bb64dcbbdf._ca7134fdff4b(0.0, _eefb4dad793c=_eefb4dad793c)
        _1e058dda2415 = _1e058dda2415 + (_4ec74658adbe * _b02d3395fd9e + _ba0cb9fae294 * _7b4b41aac271) * _da69e38d0aaf(_3a4eef6df8f8)

        # diagnostics
        _c50c98af98ee = {
            "aux_term": _1e058dda2415,
            "kl_batch": _08f39447100a,
            "contrast_batch": _93a02817ebbb,
            "kl_loss": _b02d3395fd9e,
            "contrastive_loss": _7b4b41aac271,
            "w_mean": _a50250739193,
            "aux_scale": _da69e38d0aaf(_3a4eef6df8f8),
            "lambda_kl_eff": _da69e38d0aaf(_4ec74658adbe),
            "lambda_cos_eff": _da69e38d0aaf(_ba0cb9fae294),
            "teacher_conf_mean": _da69e38d0aaf(self._5c7834b4cf9b),
            "shift_r": _da69e38d0aaf(_040fe991045e)
        }
        return _c50c98af98ee

    def _b73e5fa6a3ae(self, _ae30eb9ff7ab):
        """
        Backwards-compatible forward: returns (logits, kl_loss, contrastive_loss).
        Also caches student/teacher hidden states and teacher_conf on self for use in training_step.
        """
        _ae30eb9ff7ab = _ae30eb9ff7ab._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)
        _55ede0a13f10 = (_ae30eb9ff7ab != self._34e585f62f92._391be92f0c3a)._1527c1bbfcb3(_696888dee613=_e4bb64dcbbdf._f8f4aab1c1b9, _eefb4dad793c=self._e582a322b0e0, _06f7f35956a6=_af637352b06d)

        # model forward (request hidden states)
        _df320e901027 = self._c4e5d5564c5d(
            _ae30eb9ff7ab=_ae30eb9ff7ab,
            _55ede0a13f10=_55ede0a13f10,
            _c179c88ca7fb=_af637352b06d,
            _1a364d57b93a=_af637352b06d,
        )

        # student token embeddings (last layer). HF causal LMs use hidden_states[-1]
        _575e37adce61 = _baf3f8ae377b(_df320e901027, "last_hidden_state", _328c4ab5cbf4)
        if _575e37adce61 is _328c4ab5cbf4:
            _575e37adce61 = _df320e901027._02e3e933c1c9[-1]   # (B, L, D)

        # ensure adapter runs in float32, then apply it
        if _575e37adce61._696888dee613 != _e4bb64dcbbdf._50e552eb663c:
            _575e37adce61 = _575e37adce61._1527c1bbfcb3(_e4bb64dcbbdf._50e552eb663c)
        _4a18dd89391e = self._fcec8c5849f9(_575e37adce61)  # (B, L, D)

        # project adapted hidden -> logits (lm_head or logits)
        if self._a2e7233d4eac:
            _0cf53bc3e885 = self._94d354d2f71c(_4a18dd89391e)
        else:
            _0cf53bc3e885 = _df320e901027._0cf53bc3e885


        _0cf53bc3e885 = _0cf53bc3e885._1527c1bbfcb3(_e4bb64dcbbdf._50e552eb663c)._8d7544c4ca4d(-20, 20)

        # default zero scalars
        _b02d3395fd9e = _e4bb64dcbbdf._ca7134fdff4b(0.0, _eefb4dad793c=self._e582a322b0e0)
        _7b4b41aac271 = _e4bb64dcbbdf._ca7134fdff4b(0.0, _eefb4dad793c=self._e582a322b0e0)

        # occasionally compute embedding-level distillation (student_hidden vs frozen_hidden)
        _0e2d75025280 = _baf3f8ae377b(self, "trainer", _328c4ab5cbf4)
        _f39a0695ec7e = _32fbcb72e5da
        if _0e2d75025280 is not _328c4ab5cbf4:
            _f39a0695ec7e = _f8f4aab1c1b9(_baf3f8ae377b(self._c3a3ce9f96f2, "training", _32fbcb72e5da) or _baf3f8ae377b(self._c3a3ce9f96f2, "validating", _32fbcb72e5da))

        if _f39a0695ec7e and (_baf3f8ae377b(self, "batch_counter", 0) % _baf3f8ae377b(self, "xth_batch_to_consider", 1) == 0):
            with _e4bb64dcbbdf._683e86302fff():
                _6ac77db82c81 = _54bf526a88c9(
                    _ae30eb9ff7ab=_ae30eb9ff7ab,
                    _55ede0a13f10=_55ede0a13f10,
                    _c179c88ca7fb=_af637352b06d,
                    _1a364d57b93a=_af637352b06d,
                )
                _58d09551eefc = _baf3f8ae377b(_6ac77db82c81, "last_hidden_state", _328c4ab5cbf4)
                if _58d09551eefc is _328c4ab5cbf4:
                    _58d09551eefc = _6ac77db82c81._02e3e933c1c9[-1]

            # compute embedding-level KL + contrastive (scalar)
            _b02d3395fd9e, _7b4b41aac271 = self._dabd426e9d62(_4a18dd89391e, _58d09551eefc, _eefb4dad793c=self._e582a322b0e0)

            # cache student/teacher hidden and per-example teacher_conf for training_step helper usage
            # mean-pool per-example reps (B, D) for teacher_conf
            def _db436b4a9b2c(_ec38718c4c78): return _ec38718c4c78._ea09f63bba46(_c076e801db28=1) if _ec38718c4c78._c076e801db28() == 3 else _ec38718c4c78
            _e4fc2a4de6c2 = _e4bb64dcbbdf._e9327961453e._004230f941e1._59f94b4b095d(_eee9f51fc38e(_4a18dd89391e), _160d36fbe03b=2, _c076e801db28=-1, _fd52291b2981=1e-6)
            _1c9cdab9e4a1 = _e4bb64dcbbdf._e9327961453e._004230f941e1._59f94b4b095d(_eee9f51fc38e(_58d09551eefc), _160d36fbe03b=2, _c076e801db28=-1, _fd52291b2981=1e-6)
            _d909c6b5f33c = _e4bb64dcbbdf._e9327961453e._004230f941e1._8d9569f81758(_e4fc2a4de6c2, _1c9cdab9e4a1, _c076e801db28=-1)  # [-1,1]
            _f14ed7b3d69b = _d909c6b5f33c._8d7544c4ca4d(_20fefce46ebd=0.0)  # treat negatives as 0

            # cache (detached to avoid keeping graphs)
            self._d41b1d31f902 = _4a18dd89391e._6acdfe891462()
            self._3828543b9c15 = _58d09551eefc._6acdfe891462()
            self._591ac4f21f1c = _f14ed7b3d69b._6acdfe891462()  # shape (B,)

        # increment counter
        self._53d2c66b920a = _baf3f8ae377b(self, "batch_counter", 0) + 1

        return _0cf53bc3e885, _b02d3395fd9e, _7b4b41aac271


    def _246112984001(self):
        """Registers hooks to detect float16 AMP computation in forward pass."""
        def _1bac9c9ba982(_470b6998a105, _b0d9188b5704, _e1c91bd56f72):
            if _1efa1004f500(_fc27d0e3fde6._696888dee613 == _e4bb64dcbbdf._b99ca52b405e for _fc27d0e3fde6 in _b0d9188b5704 if _36b35b705a0a(_fc27d0e3fde6, _e4bb64dcbbdf._d76c026675cc)):
                _4cf0297f2b73(f"Layer {_470b6998a105._634dfc1903fb.__name__} is using float16!")

        for _54dabf3aaf91 in self._7ba83d832693():
            _02ea12844ecc = _54dabf3aaf91._f5f1fa143385(_1d9acb480457)
            self._2b6e0a0c0cc3._82be82402d25(_02ea12844ecc)

    def _ed7bc835fe08(self):
        """Remove all registered forward hooks."""
        for _02ea12844ecc in _baf3f8ae377b(self, "amp_hooks", []):
            _02ea12844ecc._1b2dd9b109c2()
        self._2b6e0a0c0cc3 = []

    def _fb132cd71c0b(self, _ae30eb9ff7ab, _4df9e650fd66, _a9448ce0251b):
        """
        Aligns token-level predictions to word-level by keeping only the first subword's label.
        """
        _6ca1dd5a6e14 = [self._34e585f62f92._38dd638cbc64(_14f072bdc760) for _14f072bdc760 in _ae30eb9ff7ab]
        _87e02c692329, _b2591ef44271 = [], []

        for _20cd46916acb, _75e17d0f855b, _b6a4c876d2ac in _b9f699e873dc(_6ca1dd5a6e14, _4df9e650fd66, _a9448ce0251b):
            for _b0eb6528d6fd, _246b28cfc196, _5f024c31d63b in _b9f699e873dc(_20cd46916acb, _75e17d0f855b, _b6a4c876d2ac):
                if _b0eb6528d6fd == self._34e585f62f92._cbde147a6645 or _5f024c31d63b == self._4bf55032d159:
                    continue

                _520e553d5672 = (
                    _b0eb6528d6fd._0106cdda17ad("##") or
                    _b0eb6528d6fd._0106cdda17ad("▁") or
                    _b0eb6528d6fd in ["<unk>", "<pad>"]
                )

                if _520e553d5672:
                    continue

                _87e02c692329._82be82402d25(_246b28cfc196._2e7bf07d832c())
                _b2591ef44271._82be82402d25(_5f024c31d63b._2e7bf07d832c())

        return _e4bb64dcbbdf._ca7134fdff4b(_87e02c692329), _e4bb64dcbbdf._ca7134fdff4b(_b2591ef44271)

    def _1b59d03cf569(self):
        _60885243e28b = _e4bb64dcbbdf._50e552eb663c
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            _d3bc39d4fdc8, _be76a73f73e2 = _e4bb64dcbbdf._dcc587a46759._07895c6df357()
            if _d3bc39d4fdc8 >= 8:
                _60885243e28b = _e4bb64dcbbdf._dac1959b89b8
            else:
                _60885243e28b = _e4bb64dcbbdf._b99ca52b405e
        return _60885243e28b

    # def compute_kl_contrastive_loss(self, new_emb, old_emb, device="cpu"):
    #     batch_size = new_emb.size(0)
    #     chunk_size = max(1, batch_size // 8)
    #     kl_losses = []
    #     contrastive_losses = []
    #     T = 2.0
    #     for i in range(0, batch_size, chunk_size):
    #         new_chunk = new_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         old_chunk = old_emb[i:i+chunk_size].to(device=device, non_blocking=True, dtype=self.compute_device_dtype_for_half_precision)
    #         new_emb_log = torch.nn.functional.log_softmax(new_chunk / T, dim=-1)
    #         old_emb_prob = torch.nn.functional.softmax(old_chunk / T, dim=-1)
    #         kl_loss = torch.nn.functional.kl_div(new_emb_log, old_emb_prob, reduction="batchmean") * (T * T) / new_chunk.shape[-1]
    #         embedding_drift = torch.nn.functional.cosine_similarity(new_chunk, old_chunk, dim=-1).mean()
    #         contrastive_loss = 1 - embedding_drift
    #         kl_losses.append(kl_loss)
    #         contrastive_losses.append(contrastive_loss)
    #         del new_chunk, old_chunk, new_emb_log, old_emb_prob
    #     kl_loss = torch.stack(kl_losses).mean().to(self.curr_device, non_blocking=True)
    #     contrastive_loss = torch.stack(contrastive_losses).mean().to(self.curr_device, non_blocking=True)
    #     return kl_loss, contrastive_loss

    def _36834636aa59(
        self,
        _db13290732ec: _e4bb64dcbbdf._d76c026675cc,
        _ff765f065135: _e4bb64dcbbdf._d76c026675cc,
        _eefb4dad793c: _ba532de2f4f7 = "cpu",
    ) -> _84a0d7c18a5f[_e4bb64dcbbdf._d76c026675cc, _e4bb64dcbbdf._d76c026675cc]:
        """
        Compute KL divergence and contrastive loss between new and old embeddings.
        Automatically switches to chunked mode for large batches to save memory.

        Args:
            new_emb (torch.Tensor): New embeddings (student).
            old_emb (torch.Tensor): Old embeddings (teacher, detached).
            device (str): Target device for computation.

        Returns:
            Tuple[torch.Tensor, torch.Tensor]: (KL loss, Contrastive loss)
        """
        try:
            _7385e096c17b = 2.0
            # NaN/Inf guard
            _db13290732ec = _db13290732ec._8d7544c4ca4d(_20fefce46ebd=-30, _0e9a0670a19a=30)
            _ff765f065135 = _ff765f065135._8d7544c4ca4d(_20fefce46ebd=-30, _0e9a0670a19a=30)

            # Move once if needed
            _bf0a2f43dd8a = _e4bb64dcbbdf._eefb4dad793c(_eefb4dad793c)
            if _db13290732ec._eefb4dad793c != _bf0a2f43dd8a:
                _db13290732ec = _db13290732ec._1527c1bbfcb3(_eefb4dad793c=_bf0a2f43dd8a, _06f7f35956a6=_af637352b06d, _696888dee613=self._58a846e930f4)
                _ff765f065135 = _ff765f065135._1527c1bbfcb3(_eefb4dad793c=_bf0a2f43dd8a, _06f7f35956a6=_af637352b06d, _696888dee613=self._58a846e930f4)

            _71a1ba50a347 = _db13290732ec._4eca631b25ae(0)
            _36f95afdd2b6 = _db13290732ec._4eca631b25ae(-1)

            # Auto decide if chunking is needed based on memory footprint
            # (threshold ~ 32 million elements ≈ 128MB in fp16)
            _640ff272eb8f = (_71a1ba50a347 * _36f95afdd2b6) > 32_000_000

            if not _640ff272eb8f or _71a1ba50a347 <= 8:
                # Direct computation
                _cffed936076b = _e4bb64dcbbdf._e9327961453e._004230f941e1._09249eb296aa(_db13290732ec / _7385e096c17b, _c076e801db28=-1)
                _cb51a7ac3846 = _e4bb64dcbbdf._e9327961453e._004230f941e1._cf51b64a167c(_ff765f065135 / _7385e096c17b, _c076e801db28=-1)
                _b02d3395fd9e = _e4bb64dcbbdf._e9327961453e._004230f941e1._73f74123dfbe(_cffed936076b, _cb51a7ac3846, _3f2365137d1e="batchmean") * (_7385e096c17b * _7385e096c17b)
                _7b4b41aac271 = 1 - _e4bb64dcbbdf._e9327961453e._004230f941e1._8d9569f81758(_db13290732ec, _ff765f065135, _c076e801db28=-1)._ea09f63bba46()
                return _b02d3395fd9e, _7b4b41aac271

            # Chunked mode for large inputs
            _d8d928af2162 = _0e9a0670a19a(1, _71a1ba50a347 // 8)
            _a3ef65c8b964, _e3f4d82bce2f = [], []

            for _e778c53ecf17 in _9e6fa91af473(0, _71a1ba50a347, _d8d928af2162):
                _57812bbc3f72 = _db13290732ec[_e778c53ecf17:_e778c53ecf17 + _d8d928af2162]
                _1be3e7275b76 = _ff765f065135[_e778c53ecf17:_e778c53ecf17 + _d8d928af2162]

                _cffed936076b = _e4bb64dcbbdf._e9327961453e._004230f941e1._09249eb296aa(_57812bbc3f72 / _7385e096c17b, _c076e801db28=-1)
                _cb51a7ac3846 = _e4bb64dcbbdf._e9327961453e._004230f941e1._cf51b64a167c(_1be3e7275b76 / _7385e096c17b, _c076e801db28=-1)

                _2dd643e9543a = _e4bb64dcbbdf._e9327961453e._004230f941e1._73f74123dfbe(_cffed936076b, _cb51a7ac3846, _3f2365137d1e="batchmean") * (_7385e096c17b * _7385e096c17b)
                _74a34b37a3e5 = _e4bb64dcbbdf._e9327961453e._004230f941e1._8d9569f81758(_57812bbc3f72, _1be3e7275b76, _c076e801db28=-1)._ea09f63bba46()
                _33ac15d39909 = 1 - _74a34b37a3e5

                _a3ef65c8b964._82be82402d25(_2dd643e9543a)
                _e3f4d82bce2f._82be82402d25(_33ac15d39909)

            _b02d3395fd9e = _e4bb64dcbbdf._9e547f5398d6(_a3ef65c8b964)._ea09f63bba46()
            _7b4b41aac271 = _e4bb64dcbbdf._9e547f5398d6(_e3f4d82bce2f)._ea09f63bba46()
            return _b02d3395fd9e, _7b4b41aac271

        except _008c61da9a71 as _27b8f707cc0f:
            raise _65e2571aed76(f"KL/contrastive loss computation failed: {_ba532de2f4f7(_27b8f707cc0f)}")


    def _910c8f428cec(self, _06fe8db9f2a3, _df4c3273fb4b):
        """Optimized training step with reduced memory footprint and improved stability.
        Backwards-compatible: keeps NaN guards, logging, prompt_lens, and uses the
        agreed combined-loss equation via compute_auxiliary_distill_term.
        """
        try:
            _ae30eb9ff7ab = _06fe8db9f2a3["input_ids"]
            _8386e4da262e = _06fe8db9f2a3["labels"]
            _b29988b088d5 = _06fe8db9f2a3._58419f1dadac("prompt_lens", _328c4ab5cbf4)
            _71a1ba50a347 = _ae30eb9ff7ab._4eca631b25ae(0)

            # move to device
            _ae30eb9ff7ab = _ae30eb9ff7ab._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)
            _8386e4da262e = _8386e4da262e._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)

            # forward: returns logits and the raw embedding-level batch scalars (keeps your current signature)
            _e1c91bd56f72, _08f39447100a, _93a02817ebbb = self(_ae30eb9ff7ab)

            # causal LM shift for next-token classification (unchanged)
            _5fc63d7f1800 = _e1c91bd56f72[:, :-1, :]._9e7d43e5ebec()
            _12e339071962 = _8386e4da262e[:, 1:]._9e7d43e5ebec()
            _7a44d2749076 = _5fc63d7f1800._d65b5ff16279(-1, _5fc63d7f1800._4eca631b25ae(-1))
            _29fe19f4938b = _12e339071962._d65b5ff16279(-1)

            # classification/task loss
            _4cbf6401d365 = self._d592d7d7d80d['criterion'](_7a44d2749076, _29fe19f4938b)

            # numeric guards for scalars (preserve your current torch.where guards but simpler)
            _08f39447100a = _e4bb64dcbbdf._e946f671652b(_08f39447100a, _43302149dfd0=0.0, _e37d8e68b0fc=0.0, _a69b2c67102d=0.0)
            _93a02817ebbb = _e4bb64dcbbdf._e946f671652b(_93a02817ebbb, _43302149dfd0=0.0, _e37d8e68b0fc=0.0, _a69b2c67102d=0.0)
            _4cbf6401d365 = _e4bb64dcbbdf._e946f671652b(_4cbf6401d365, _43302149dfd0=0.0, _e37d8e68b0fc=0.0, _a69b2c67102d=0.0)

            # compute auxiliary term (implements the full equation and returns diagnostics)
            _8f450b4faea4 = self._3102426b0426(_4cbf6401d365, _08f39447100a, _93a02817ebbb)
            _1e058dda2415 = _8f450b4faea4["aux_term"]

            # final combined loss (single-equation)
            _dde82b053f83 = _4cbf6401d365 + _1e058dda2415

            # Optional NaN print as before (keeps your original check)
            if _e4bb64dcbbdf._28b2cf905d29(_4cbf6401d365):
                _4cf0297f2b73(f"Step {_df4c3273fb4b}: NaN loss detected!")

            # build training metrics similar to your original keys, plus aux diagnostics
            _a1ed42e52ec2 = {
                "epoch": _da69e38d0aaf(_baf3f8ae377b(self, "current_epoch", _baf3f8ae377b(self._c3a3ce9f96f2, "current_epoch", 0))),
                "train_kl_loss": _8f450b4faea4._58419f1dadac("kl_loss", _08f39447100a)._6acdfe891462() if _36b35b705a0a(_8f450b4faea4._58419f1dadac("kl_loss", _08f39447100a), _e4bb64dcbbdf._d76c026675cc) else _8f450b4faea4._58419f1dadac("kl_loss", _08f39447100a),
                "train_contrastive_loss": _8f450b4faea4._58419f1dadac("contrastive_loss", _93a02817ebbb)._6acdfe891462() if _36b35b705a0a(_8f450b4faea4._58419f1dadac("contrastive_loss", _93a02817ebbb), _e4bb64dcbbdf._d76c026675cc) else _8f450b4faea4._58419f1dadac("contrastive_loss", _93a02817ebbb),
                "train_classification_loss": _4cbf6401d365._6acdfe891462(),
                "train_loss": _dde82b053f83._6acdfe891462(),
                # keep your lambdas visible (we expose the effective ones used)
                "train_lambda_classification": _da69e38d0aaf(_baf3f8ae377b(self, "lambda_classification", 0.8)),
                "train_lambda_kl": _8f450b4faea4._58419f1dadac("lambda_kl_eff", _da69e38d0aaf(_baf3f8ae377b(self, "kl_base", 0.30))),
                "train_lambda_contrast": _8f450b4faea4._58419f1dadac("lambda_cos_eff", _da69e38d0aaf(_baf3f8ae377b(self, "cos_base", 0.25))),
            }

            # include extra aux diagnostics if present (w_mean, aux_scale, shift_r, teacher_conf_mean)
            for _df549f4d2e25 in ("w_mean", "aux_scale", "shift_r", "teacher_conf_mean", "kl_batch", "contrast_batch"):
                if _df549f4d2e25 in _8f450b4faea4:
                    _0b08d4a3558e = _8f450b4faea4[_df549f4d2e25]
                    # convert single-element tensors to python floats for logging
                    if _36b35b705a0a(_0b08d4a3558e, _e4bb64dcbbdf._d76c026675cc) and _0b08d4a3558e._1c7b5f322389() == 1:
                        _a1ed42e52ec2[f"train_{_df549f4d2e25}"] = _da69e38d0aaf(_0b08d4a3558e._6acdfe891462()._14658237ae7a()._2e7bf07d832c())
                    else:
                        _a1ed42e52ec2[f"train_{_df549f4d2e25}"] = _0b08d4a3558e

            # log exactly like you did
            self._049a47588366(
                _a1ed42e52ec2,
                _71a1ba50a347=_71a1ba50a347,
                _400de52ad634=_32fbcb72e5da,
                _1abe42117779=_af637352b06d,
                _58282af1a4ae=_32fbcb72e5da,
                _e20a71750dca=_af637352b06d,
                _63a7624f7d32=_af637352b06d,
            )

            # free references as you did
            del _ae30eb9ff7ab, _8386e4da262e, _e1c91bd56f72, _08f39447100a, _4cbf6401d365, _93a02817ebbb, _12e339071962, _5fc63d7f1800, _29fe19f4938b, _7a44d2749076

            return _dde82b053f83

        except _008c61da9a71 as _27b8f707cc0f:
            raise _65e2571aed76(f"Error in training_step: {_27b8f707cc0f}") from _27b8f707cc0f

    def _31957dac470c(self):
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            _e4bb64dcbbdf._dcc587a46759._c7f53112a63c()
        _cab4f045067b._ce001647a4a3()
        return _fd539caec650()._9e06e1c32001()

    def _cb62db8e39bb(self, _06fe8db9f2a3, _df4c3273fb4b):
        _ae30eb9ff7ab      = _06fe8db9f2a3["input_ids"]._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)
        _8386e4da262e         = _06fe8db9f2a3["labels"]._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)
        _c33d69e1c54c     = _06fe8db9f2a3._58419f1dadac("lang_codes", _328c4ab5cbf4)
        _7b8d03ad3787     = _06fe8db9f2a3._58419f1dadac("sample_ids", _328c4ab5cbf4)
        _d37b2f857ce5      = _06fe8db9f2a3._58419f1dadac("chunk_ids", _328c4ab5cbf4)
        _d9604a69777d = _06fe8db9f2a3._58419f1dadac("word_positions", _328c4ab5cbf4)
        _b29988b088d5    = _06fe8db9f2a3._58419f1dadac("prompt_lens", _328c4ab5cbf4)
        _612038de3832 = _06fe8db9f2a3._58419f1dadac("num_chunks", _328c4ab5cbf4)

        _71a1ba50a347 = _ae30eb9ff7ab._4eca631b25ae(0)

        # forward: expects (logits, kl_batch, contrast_batch)
        _e1c91bd56f72, _08f39447100a, _93a02817ebbb = self(_ae30eb9ff7ab)

        # causal LM shift for next-token classification (same as training)
        _5fc63d7f1800 = _e1c91bd56f72[:, :-1, :]._9e7d43e5ebec()
        _12e339071962 = _8386e4da262e[:, 1:]._9e7d43e5ebec()
        _7a44d2749076 = _5fc63d7f1800._d65b5ff16279(-1, _5fc63d7f1800._4eca631b25ae(-1))
        _29fe19f4938b = _12e339071962._d65b5ff16279(-1)

        if _df4c3273fb4b == 0:
            try:
                _4cf0297f2b73(
                    f"VAL TEST BATCH {_df4c3273fb4b} Input IDs: {_ae30eb9ff7ab._a834f564273d()[0]}, "
                    f"Predictions: {_e4bb64dcbbdf._f264ffd24a37(_5fc63d7f1800, _c076e801db28=-1)._a834f564273d()[0]}, "
                    f"Labels: {_12e339071962._a834f564273d()[0]}"
                )
            except _008c61da9a71:
                # printing should never crash validation
                pass

        # classification loss
        _4cbf6401d365 = self._d592d7d7d80d['criterion'](_7a44d2749076, _29fe19f4938b)

        # numeric guards (preserve your original torch.where behavior but simpler)
        _08f39447100a = _e4bb64dcbbdf._e946f671652b(_08f39447100a, _43302149dfd0=0.0, _e37d8e68b0fc=0.0, _a69b2c67102d=0.0)
        _93a02817ebbb = _e4bb64dcbbdf._e946f671652b(_93a02817ebbb, _43302149dfd0=0.0, _e37d8e68b0fc=0.0, _a69b2c67102d=0.0)
        _4cbf6401d365 = _e4bb64dcbbdf._e946f671652b(_4cbf6401d365, _43302149dfd0=0.0, _e37d8e68b0fc=0.0, _a69b2c67102d=0.0)

        # ---------------------
        # Compute auxiliary term using the same helper as training
        # This implements: combined = task_loss + s(t)*(lambda_kl_eff*w*KL + lambda_cos_eff*w*cos)
        _8f450b4faea4 = self._3102426b0426(_4cbf6401d365, _08f39447100a, _93a02817ebbb)
        _1e058dda2415 = _8f450b4faea4["aux_term"]
        _dde82b053f83 = _4cbf6401d365 + _1e058dda2415

        # Logging: preserve your keys but prefer the aux diagnostics where available
        _049a47588366 = {
            "val_kl_loss": _da69e38d0aaf(_8f450b4faea4._58419f1dadac("kl_loss", _08f39447100a)._6acdfe891462()._14658237ae7a()._2e7bf07d832c()) if _36b35b705a0a(_8f450b4faea4._58419f1dadac("kl_loss", _08f39447100a), _e4bb64dcbbdf._d76c026675cc) else _da69e38d0aaf(_8f450b4faea4._58419f1dadac("kl_loss", _08f39447100a)),
            "val_contrastive_loss": _da69e38d0aaf(_8f450b4faea4._58419f1dadac("contrastive_loss", _93a02817ebbb)._6acdfe891462()._14658237ae7a()._2e7bf07d832c()) if _36b35b705a0a(_8f450b4faea4._58419f1dadac("contrastive_loss", _93a02817ebbb), _e4bb64dcbbdf._d76c026675cc) else _da69e38d0aaf(_8f450b4faea4._58419f1dadac("contrastive_loss", _93a02817ebbb)),
            "val_classification_loss": _da69e38d0aaf(_4cbf6401d365._6acdfe891462()._14658237ae7a()._2e7bf07d832c()),
            "val_loss": _da69e38d0aaf(_dde82b053f83._6acdfe891462()._14658237ae7a()._2e7bf07d832c()),
        }

        # include effective lambdas and others if provided by aux
        _049a47588366["val_lambda_kl"] = _da69e38d0aaf(_8f450b4faea4._58419f1dadac("lambda_kl", _8f450b4faea4._58419f1dadac("lambda_kl_eff", _da69e38d0aaf(_baf3f8ae377b(self, "kl_base", 0.30)))))
        _049a47588366["val_lambda_contrast"] = _da69e38d0aaf(_8f450b4faea4._58419f1dadac("lambda_cos", _8f450b4faea4._58419f1dadac("lambda_cos_eff", _da69e38d0aaf(_baf3f8ae377b(self, "cos_base", 0.25)))))
        _049a47588366["val_w_mean"] = _da69e38d0aaf(_8f450b4faea4._58419f1dadac("w_mean", 0.0))
        _049a47588366["val_aux_scale"] = _da69e38d0aaf(_8f450b4faea4._58419f1dadac("aux_scale", 0.0))
        _049a47588366["val_shift_r"] = _da69e38d0aaf(_8f450b4faea4._58419f1dadac("shift_r", 0.0))
        _049a47588366["val_teacher_conf_mean"] = _da69e38d0aaf(_8f450b4faea4._58419f1dadac("teacher_conf_mean", 0.0))

        self._049a47588366(
            _049a47588366,
            _71a1ba50a347=_71a1ba50a347,
            _400de52ad634=_32fbcb72e5da,
            _1abe42117779=_af637352b06d,
            _58282af1a4ae=_32fbcb72e5da,
            _e20a71750dca=_af637352b06d,
            _63a7624f7d32=_af637352b06d,
        )

        # build preds and labels per example (preserve your previous behavior)
        _81e2af3281de = []
        _fd4afc239abd = []
        for _e778c53ecf17 in _9e6fa91af473(_71a1ba50a347):
            _b7c5db7522a5 = _e1c91bd56f72[_e778c53ecf17]
            _5f024c31d63b = _8386e4da262e[_e778c53ecf17]
            _5f9f0f3c7a3a = _e4bb64dcbbdf._f264ffd24a37(_b7c5db7522a5, _c076e801db28=-1)
            _ead2c323fa25 = _5f024c31d63b
            _81e2af3281de._82be82402d25(_5f9f0f3c7a3a)
            _fd4afc239abd._82be82402d25(_ead2c323fa25)

        _88353bb66cc4 = {
            "lang_codes": _c33d69e1c54c,
            "preds": _81e2af3281de,
            "labels": _fd4afc239abd,
            "sample_ids": _7b8d03ad3787,
            "chunk_ids": _d37b2f857ce5,
            "word_positions": _d9604a69777d,
            "val_loss": _dde82b053f83,
            "prompt_lens": _b29988b088d5,
            "num_chunks": _612038de3832,
        }

        # store for epoch-end aggregation (your code uses self._validation_outputs)
        self._9966df9990bd._82be82402d25(_88353bb66cc4)

        # explicit frees (same as you had)
        del _ae30eb9ff7ab, _8386e4da262e, _e1c91bd56f72, _7a44d2749076, _29fe19f4938b, _5fc63d7f1800, _12e339071962
        del _08f39447100a, _93a02817ebbb, _4cbf6401d365, _81e2af3281de, _fd4afc239abd

        return _88353bb66cc4


    def _bca2c2398421(self, _f7b9a68a53c1, _3c1d41f835d4, _392b042b7b82=_328c4ab5cbf4):
        _99d747b3d0a7 = _c409d48270dc._c8fcdef30bb5()
        _07cda18524ba = f"trial_{_392b042b7b82}" if _392b042b7b82 is not _328c4ab5cbf4 else "default"
        _4cf0297f2b73(f"[DEBUG rank={_e4bb64dcbbdf._1543b0d6059e._e3d025d9912b() if _e4bb64dcbbdf._1543b0d6059e._1fd6fb60e851() else 0}] metrics_dict confusion_matrix sum={_725721748919(_725721748919(_8d80a5be3ec3) for _8d80a5be3ec3 in _f7b9a68a53c1['confusion_matrix'][0])}")
        # save_dir = os.path.join(project_dir, "exp_metrics_detailed", trial_id)
        _ee7f49162a22 = _c409d48270dc._245b57d1c458._8b44682160c1(_99d747b3d0a7, "metrics", self._e8c3c33f8ac2,  _07cda18524ba)
        _c409d48270dc._a77a2d67aba6(_ee7f49162a22, _8d30577f6917=_af637352b06d)
        _76610c2c2324 = _c409d48270dc._245b57d1c458._8b44682160c1(_ee7f49162a22, _3c1d41f835d4)
        _41a8ddcc48b7 = _899bc7544583._d1024f61aa3f(_f7b9a68a53c1)
        _41a8ddcc48b7._a5358293bf47(_76610c2c2324, _5bddaa5ee023=_32fbcb72e5da)
        _4cf0297f2b73(f"[metrics] Saved {_76610c2c2324}")

    def _7bb89f69ec2b(self):
        # pick correct device for this rank
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            if _e4bb64dcbbdf._1543b0d6059e._1fd6fb60e851():
                _e24553bd0410 = _e4bb64dcbbdf._1543b0d6059e._e3d025d9912b()
            else:
                _e24553bd0410 = 0
            _e4bb64dcbbdf._dcc587a46759._421f99d9a059(_e24553bd0410)
            self._e582a322b0e0 = _e4bb64dcbbdf._eefb4dad793c(f"cuda:{_e24553bd0410}")
        else:
            self._e582a322b0e0 = _e4bb64dcbbdf._eefb4dad793c("cpu")

        self._5e8d18bf03b2()

    def _7c7889a6a268(self):
        _e1c91bd56f72 = _baf3f8ae377b(self, "_validation_outputs", _328c4ab5cbf4)
        if not _e1c91bd56f72:
            return

        _77917cd4e785, _414732c3ed98, _925adccb21aa, _bd29fd05bc2d = \
            self._dd3a13bf81dc(_e1c91bd56f72)

        _fe667eda3aeb, _a50c0186acab = [], []
        for _efe41b43deb3 in _247b1b8a42b3(_925adccb21aa._9a9e50c11864()):
            _eca2dd097f0f = _77917cd4e785[_efe41b43deb3]._a834f564273d()
            _8015122319ac = _414732c3ed98[_efe41b43deb3]._a834f564273d()
            _88429f6aa449 = _925adccb21aa[_efe41b43deb3]
            _9cd70f43a54e = _bd29fd05bc2d[_efe41b43deb3]
            if _88429f6aa449._1c7b5f322389() > 0 and _9cd70f43a54e._1c7b5f322389() > 0:
                _fe667eda3aeb._82be82402d25(_88429f6aa449)
                _a50c0186acab._82be82402d25(_9cd70f43a54e)

        if not _fe667eda3aeb:
            _4cf0297f2b73("[VAL END] Nothing to score.")
            self._9966df9990bd._e194e48ab7a5()
            return

        _eb071efcc082 = _e4bb64dcbbdf._222336c39588(_fe667eda3aeb)._1527c1bbfcb3(_eefb4dad793c=self._6648d9694cb6['micro_accuracy']._eefb4dad793c, _06f7f35956a6=_af637352b06d)
        _8386e4da262e = _e4bb64dcbbdf._222336c39588(_a50c0186acab)._1527c1bbfcb3(_eefb4dad793c=self._6648d9694cb6['micro_accuracy']._eefb4dad793c, _06f7f35956a6=_af637352b06d)

        self._6648d9694cb6['micro_accuracy']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_accuracy']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_precision']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_recall']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_f1']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_accuracy']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_precision']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_recall']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_f1']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['confmat']._6a80b06248ab(_eb071efcc082, _8386e4da262e)

        _a76d819a2f5a  = self._6648d9694cb6['micro_accuracy']._db26840c90fc()._2e7bf07d832c()
        _55368e7212d4  = self._6648d9694cb6['macro_accuracy']._db26840c90fc()._2e7bf07d832c()
        _e6746a3c876b = self._6648d9694cb6['macro_precision']._db26840c90fc()._2e7bf07d832c()
        _bbadbcc8cf73    = self._6648d9694cb6['macro_recall']._db26840c90fc()._2e7bf07d832c()
        _2ddbb3a86d4e        = self._6648d9694cb6['macro_f1']._db26840c90fc()._2e7bf07d832c()

        self._9c38242336f5("val_accuracy", _55368e7212d4, _63a7624f7d32=_af637352b06d)

        try:
            _3d665e17fb61 = self._1ffcfdd6db43
            _f7b9a68a53c1 = {
                "epoch": [_3d665e17fb61],
                "class_names": [self._16c7f5a2aa2e],
                "micro_accuracy": [_a76d819a2f5a],
                "macro_accuracy": [_55368e7212d4],
                "macro_precision": [_e6746a3c876b],
                "macro_recall": [_bbadbcc8cf73],
                "macro_f1": [_2ddbb3a86d4e],
                "classwise_accuracy": [self._6648d9694cb6['classwise_accuracy']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "classwise_precision": [self._6648d9694cb6['classwise_precision']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "classwise_recall": [self._6648d9694cb6['classwise_recall']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "classwise_f1": [self._6648d9694cb6['classwise_f1']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "confusion_matrix": [self._6648d9694cb6['confmat']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
            }
            self._5af15e718292(_f7b9a68a53c1, f"val_epoch_{_3d665e17fb61}.csv", _392b042b7b82=self._392b042b7b82)
        except _008c61da9a71 as _27b8f707cc0f:
            _4cf0297f2b73(f"[VAL END] save metrics FAILED: {_27b8f707cc0f}")

        # cleanup
        self._6648d9694cb6['micro_accuracy']._135ee312bb0b(); self._6648d9694cb6['macro_accuracy']._135ee312bb0b()
        self._6648d9694cb6['macro_precision']._135ee312bb0b(); self._6648d9694cb6['macro_recall']._135ee312bb0b(); self._6648d9694cb6['macro_f1']._135ee312bb0b()
        self._6648d9694cb6['classwise_accuracy']._135ee312bb0b(); self._6648d9694cb6['classwise_precision']._135ee312bb0b()
        self._6648d9694cb6['classwise_recall']._135ee312bb0b(); self._6648d9694cb6['classwise_f1']._135ee312bb0b()
        self._6648d9694cb6['confmat']._135ee312bb0b(); self._9966df9990bd._e194e48ab7a5()
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            _e4bb64dcbbdf._dcc587a46759._c7f53112a63c()
        _4cf0297f2b73("[VAL END] Finished and cleaned up.")

    # def test_step(self, batch, batch_idx):
    #     # unpack and move to device
    #     input_ids      = batch["input_ids"].to(self.curr_device, non_blocking=True)
    #     labels         = batch["labels"].to(self.curr_device, non_blocking=True)
    #     lang_codes     = batch.get("lang_codes", None)
    #     sample_ids     = batch.get("sample_ids", None)
    #     chunk_ids      = batch.get("chunk_ids", None)
    #     word_positions = batch.get("word_positions", None)
    #     prompt_lens    = batch.get("prompt_lens", None)
    #     batch_num_chunks = batch.get("num_chunks", None)

    #     batch_size = input_ids.size(0)

    #     # forward: expects (logits, kl_batch, contrast_batch)
    #     outputs, kl_batch, contrast_batch = self(input_ids)

    #     # causal LM shift for next-token classification
    #     shift_logits = outputs[:, :-1, :].contiguous()
    #     shift_labels = labels[:, 1:].contiguous()
    #     logits_flat = shift_logits.view(-1, shift_logits.size(-1))
    #     labels_flat = shift_labels.view(-1)

    #     # build per-example preds/labels (preserve original behavior)
    #     preds_list = []
    #     labels_list = []
    #     for i in range(batch_size):
    #         logit = outputs[i]   # (L, V)
    #         label = labels[i]
    #         valid_pred = torch.argmax(logit, dim=-1)
    #         valid_label = label
    #         preds_list.append(valid_pred)
    #         labels_list.append(valid_label)

    #     output = {
    #         "lang_codes": lang_codes,
    #         "preds": preds_list,
    #         "labels": labels_list,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #         "prompt_lens": prompt_lens,
    #         "num_chunks": batch_num_chunks,
    #     }

    #     # append and cleanup
    #     self._test_outputs.append(output)

    #     del input_ids, labels, outputs, logits_flat, labels_flat, shift_logits, shift_labels
    #     del kl_batch, contrast_batch, preds_list, labels_list

    #     return output


    @_e4bb64dcbbdf._683e86302fff()
    def _27f98a22ee2f(self, _ae30eb9ff7ab: _e4bb64dcbbdf._d76c026675cc, **_c3cbc138b699):
        _c3cbc138b699._6f3a5ed6a5cd("pad_token_id", _328c4ab5cbf4)
        _c3cbc138b699._6f3a5ed6a5cd("attention_mask", _328c4ab5cbf4)
        return self._c4e5d5564c5d._084e2900f20b(
            _ae30eb9ff7ab=_ae30eb9ff7ab,
            _55ede0a13f10=(_ae30eb9ff7ab != self._34e585f62f92._391be92f0c3a),
            _391be92f0c3a=self._34e585f62f92._391be92f0c3a,
            _21a8281b2699=self._34e585f62f92._21a8281b2699,
            **_c3cbc138b699
        )

    def _9c828154e30f(self, _06fe8db9f2a3, _df4c3273fb4b):
        _ae30eb9ff7ab = _06fe8db9f2a3["input_ids"]._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)
        _8386e4da262e    = _06fe8db9f2a3["labels"]._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)
        _c33d69e1c54c     = _06fe8db9f2a3._58419f1dadac("lang_codes", _328c4ab5cbf4)
        _7b8d03ad3787     = _06fe8db9f2a3._58419f1dadac("sample_ids", _328c4ab5cbf4)
        _d37b2f857ce5      = _06fe8db9f2a3._58419f1dadac("chunk_ids", _328c4ab5cbf4)
        _d9604a69777d = _06fe8db9f2a3._58419f1dadac("word_positions", _328c4ab5cbf4)
        _b29988b088d5    = _06fe8db9f2a3._58419f1dadac("prompt_lens", _328c4ab5cbf4)
        _612038de3832 = _06fe8db9f2a3._58419f1dadac("num_chunks", _328c4ab5cbf4)

        _71a1ba50a347 = _ae30eb9ff7ab._4eca631b25ae(0)

        # Fast generation using the generate() method (bypasses FSDP slow path)
        _fa0f7cf795fa = self._084e2900f20b(
            _ae30eb9ff7ab,
            _2fda6e02d834=32,
            _361418a0d1ab=_32fbcb72e5da,
            _74a2585cfe8f=_328c4ab5cbf4,     # for deterministic answers
            _96912c70e3d8=_328c4ab5cbf4,           # for deterministic answers
        )

        # Mimic original behavior: treat generated_ids as "logits" output
        # We take argmax on the generated tokens (already chosen)
        _81e2af3281de = []
        _fd4afc239abd = []
        # for i in range(batch_size):
        #     pred_tokens = generated_ids[i]                    # (seq_len,)
        #     label_tokens = labels[i]
        #     preds_list.append(pred_tokens)
        #     labels_list.append(label_tokens)
        for _e778c53ecf17 in _9e6fa91af473(_71a1ba50a347):
            _81e2af3281de._82be82402d25(_fa0f7cf795fa[_e778c53ecf17])   # FULL sequence
            _fd4afc239abd._82be82402d25(_8386e4da262e[_e778c53ecf17])          # FULL labels


        _88353bb66cc4 = {
            "lang_codes": _c33d69e1c54c,
            "preds": _81e2af3281de,
            "labels": _fd4afc239abd,
            "sample_ids": _7b8d03ad3787,
            "chunk_ids": _d37b2f857ce5,
            "word_positions": _d9604a69777d,
            "prompt_lens": _b29988b088d5,
            "num_chunks": _612038de3832,
        }

        self._6028b5ae0973._82be82402d25(_88353bb66cc4)

        # Exact same cleanup as before
        del _ae30eb9ff7ab, _8386e4da262e, _fa0f7cf795fa, _81e2af3281de, _fd4afc239abd

        return _88353bb66cc4

    def _238a2cb806b3(self):
        # pick correct device for this rank
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            if _e4bb64dcbbdf._1543b0d6059e._1fd6fb60e851():
                _e24553bd0410 = _e4bb64dcbbdf._1543b0d6059e._e3d025d9912b()
            else:
                _e24553bd0410 = 0
            _e4bb64dcbbdf._dcc587a46759._421f99d9a059(_e24553bd0410)
            self._e582a322b0e0 = _e4bb64dcbbdf._eefb4dad793c(f"cuda:{_e24553bd0410}")
        else:
            self._e582a322b0e0 = _e4bb64dcbbdf._eefb4dad793c("cpu")

        self._5e8d18bf03b2()
        
    def _a3cfb9fec3fd(self):
        _e1c91bd56f72 = _baf3f8ae377b(self, "_test_outputs", _328c4ab5cbf4)
        _4cf0297f2b73(f"[DEBUG rank={_e4bb64dcbbdf._1543b0d6059e._e3d025d9912b()}] outputs_len={_de338412d1d9(_e1c91bd56f72)}")
        if not _e1c91bd56f72:
            return

        _77917cd4e785, _414732c3ed98, _925adccb21aa, _bd29fd05bc2d = \
            self._dd3a13bf81dc(_e1c91bd56f72)

        _fe667eda3aeb, _a50c0186acab = [], []
        for _efe41b43deb3 in _247b1b8a42b3(_925adccb21aa._9a9e50c11864()):
            _eca2dd097f0f = _77917cd4e785[_efe41b43deb3]._a834f564273d()
            _8015122319ac = _414732c3ed98[_efe41b43deb3]._a834f564273d()
            _88429f6aa449 = _925adccb21aa[_efe41b43deb3]
            _9cd70f43a54e = _bd29fd05bc2d[_efe41b43deb3]

            if _88429f6aa449._1c7b5f322389() > 0 and _9cd70f43a54e._1c7b5f322389() > 0:
                _fe667eda3aeb._82be82402d25(_88429f6aa449)
                _a50c0186acab._82be82402d25(_9cd70f43a54e)

        if not _fe667eda3aeb:
            _4cf0297f2b73("[TEST END] Nothing to score.")
            self._9966df9990bd._e194e48ab7a5()
            return

        _eb071efcc082 = _e4bb64dcbbdf._222336c39588(_fe667eda3aeb)._1527c1bbfcb3(_eefb4dad793c=self._6648d9694cb6['micro_accuracy']._eefb4dad793c, _06f7f35956a6=_af637352b06d)
        _8386e4da262e = _e4bb64dcbbdf._222336c39588(_a50c0186acab)._1527c1bbfcb3(_eefb4dad793c=self._6648d9694cb6['micro_accuracy']._eefb4dad793c, _06f7f35956a6=_af637352b06d)

        self._6648d9694cb6['micro_accuracy']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_accuracy']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_precision']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_recall']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['macro_f1']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_accuracy']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_precision']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_recall']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['classwise_f1']._6a80b06248ab(_eb071efcc082, _8386e4da262e)
        self._6648d9694cb6['confmat']._6a80b06248ab(_eb071efcc082, _8386e4da262e)

        _a76d819a2f5a  = self._6648d9694cb6['micro_accuracy']._db26840c90fc()._2e7bf07d832c()
        _55368e7212d4  = self._6648d9694cb6['macro_accuracy']._db26840c90fc()._2e7bf07d832c()
        _e6746a3c876b = self._6648d9694cb6['macro_precision']._db26840c90fc()._2e7bf07d832c()
        _bbadbcc8cf73    = self._6648d9694cb6['macro_recall']._db26840c90fc()._2e7bf07d832c()
        _2ddbb3a86d4e        = self._6648d9694cb6['macro_f1']._db26840c90fc()._2e7bf07d832c()

        self._9c38242336f5("test_accuracy", _55368e7212d4, _63a7624f7d32=_af637352b06d)

        try:
            _3d665e17fb61 = self._1ffcfdd6db43
            _f7b9a68a53c1 = {
                "epoch": [_3d665e17fb61],
                "class_names": [self._16c7f5a2aa2e],
                "micro_accuracy": [_a76d819a2f5a],
                "macro_accuracy": [_55368e7212d4],
                "macro_precision": [_e6746a3c876b],
                "macro_recall": [_bbadbcc8cf73],
                "macro_f1": [_2ddbb3a86d4e],
                "classwise_accuracy": [self._6648d9694cb6['classwise_accuracy']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "classwise_precision": [self._6648d9694cb6['classwise_precision']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "classwise_recall": [self._6648d9694cb6['classwise_recall']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "classwise_f1": [self._6648d9694cb6['classwise_f1']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
                "confusion_matrix": [self._6648d9694cb6['confmat']._db26840c90fc()._1527c1bbfcb3(_eefb4dad793c="cpu")._9ed293b4c4b4()._a834f564273d()],
            }
            self._5af15e718292(_f7b9a68a53c1, f"test_final.csv", _392b042b7b82=self._392b042b7b82)
        except _008c61da9a71 as _27b8f707cc0f:
            _4cf0297f2b73(f"[TEST END] save metrics FAILED: {_27b8f707cc0f}")

        # cleanup
        self._6648d9694cb6['micro_accuracy']._135ee312bb0b(); self._6648d9694cb6['macro_accuracy']._135ee312bb0b()
        self._6648d9694cb6['macro_precision']._135ee312bb0b(); self._6648d9694cb6['macro_recall']._135ee312bb0b(); self._6648d9694cb6['macro_f1']._135ee312bb0b()
        self._6648d9694cb6['classwise_accuracy']._135ee312bb0b(); self._6648d9694cb6['classwise_precision']._135ee312bb0b()
        self._6648d9694cb6['classwise_recall']._135ee312bb0b(); self._6648d9694cb6['classwise_f1']._135ee312bb0b()
        self._6648d9694cb6['confmat']._135ee312bb0b(); self._9966df9990bd._e194e48ab7a5()
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            _e4bb64dcbbdf._dcc587a46759._c7f53112a63c()
        _4cf0297f2b73("[TEST END] Finished and cleaned up.")

    def _d27eb3d12e9d(self, _06fe8db9f2a3, _df4c3273fb4b, _7618f229caa6=0):
        """Optimized prediction step with efficient memory handling."""
        _ae30eb9ff7ab, _ = _06fe8db9f2a3
        _ae30eb9ff7ab = _ae30eb9ff7ab._1527c1bbfcb3(self._e582a322b0e0, _06f7f35956a6=_af637352b06d)
        _e1c91bd56f72, _, _ = self(_ae30eb9ff7ab)
        _1f96f0c531b6 = _e4bb64dcbbdf._f264ffd24a37(_e1c91bd56f72, _c076e801db28=-1)
        del _ae30eb9ff7ab, _e1c91bd56f72
        if _e4bb64dcbbdf._dcc587a46759._0621157b5a2f():
            _e4bb64dcbbdf._dcc587a46759._c7f53112a63c()
        return {"predictions": _1f96f0c531b6._14658237ae7a()}

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        

    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Before reconcile missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in set(sid for out in outputs for sid in out.get('sample_ids', []))]}")
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens = out["prompt_lens"]
    #         num_chunks = out["num_chunks"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])

    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i = to_list(word_positions[i])
    #             sep_tokens = self.pred_filter_tokens
    #             # preds_i     = to_list(chunk_preds[i])[prompt_len_i:]
    #             # labels_i    = to_list(chunk_labels[i])[prompt_len_i:]
    #             preds_raw  = to_list(chunk_preds[i])
    #             labels_raw = to_list(chunk_labels[i])

    #             # If preds are shorter than labels, they are generation-only (test)
    #             # if len(preds_raw) < len(labels_raw):
    #             #     preds_i  = preds_raw
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             # else:
    #             #     preds_i  = preds_raw[prompt_len_i:]
    #             #     labels_i = labels_raw[prompt_len_i:]
    #             preds_i  = preds_raw[prompt_len_i:] if len(preds_raw) > prompt_len_i else []
    #             labels_i = labels_raw[prompt_len_i:] if len(labels_raw) > prompt_len_i else []
    #             # preds_i  = preds_raw[prompt_len_i:]
    #             # labels_i = labels_raw[prompt_len_i:]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             if 'chunks_by_sid' not in locals():
    #                 chunks_by_sid = defaultdict(list)
    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
            
    #     sample_debug_id = None
    #     rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    #     print(f"[DEBUG rank={torch.distributed.get_rank()}] Missing sample_ids={[sid for sid in range(0 if torch.distributed.get_rank() == 0 else 637, 637 if torch.distributed.get_rank() == 0 else 1274) if sid not in final_sids]}")
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         print(f"[WARN] Rank {rank} Missing chunks sample_id={sid}, missing {out['num_chunks'][i] - len(chunks)} chunks") if any(out['sample_ids'][i] == sid and out['num_chunks'][i] > len(chunks) for out in outputs for i in range(len(out['sample_ids']))) else None
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels = defaultdict(list)
    #         for cid, positions, preds, labels in chunks:
    #             chunk_word_preds = {}
    #             chunk_word_labels = {}
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             chunk_word_preds[current_word] = current_preds[:]
    #                             chunk_word_labels[current_word] = current_labels[:]
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 chunk_word_preds[current_word] = current_preds[:]
    #                 chunk_word_labels[current_word] = current_labels[:]
    #             for w, toks in chunk_word_preds.items():
    #                 word_to_token_preds[w].append(toks)
    #                 word_to_token_labels[w].append(chunk_word_labels[w])
    #         if not word_to_token_preds:
    #             continue
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
    #             sub_len = len(token_lists_l[0])
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 while len(col) < len(token_lists_l):
    #                     col.append(unk_id)
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds[:sub_len])
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l]
    #                 # voted = Counter(col).most_common(1)[0][0]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
    #             if w < max_w:
    #                 sep_col_p = word_to_sep_preds[w]
    #                 if sep_col_p:
    #                     # sep_p = Counter(sep_col_p).most_common(1)[0][0]
    #                     sep_col_p = [c for c in sep_col_p if c != ignore_index]
    #                     sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else self.tokenizer_separator_token
    #                     preds_final.append(sep_p)
    #                 sep_col_l = word_to_sep_labels[w]
    #                 if sep_col_l:
    #                     # sep_l = Counter(sep_col_l).most_common(1)[0][0]
    #                     sep_col_l = [c for c in sep_col_l if c != ignore_index]
    #                     sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else self.tokenizer_separator_token
    #                     labels_final.append(sep_l)
    #                 else:
    #                     labels_final.append(self.tokenizer_separator_token)
    #                     preds_final.append(self.tokenizer_separator_token)
    #         # unk_id = next((k[0] for k, v in self.seq2class.items() if v == 0), 3200)
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         label_words = sum(1 for i, x in enumerate(labels_final) if x != self.tokenizer_separator_token and (i == 0 or labels_final[i-1] == self.tokenizer_separator_token))
    #         pred_words = sum(1 for i, x in enumerate(preds_final) if x != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token))
    #         # if pred_words < label_words:
    #         #     for _ in range(pred_words, label_words):
    #         #         if len(preds_final) > 0 and preds_final[-1] != self.tokenizer_separator_token:
    #         #             preds_final.append(self.tokenizer_separator_token)
    #         #         preds_final.append(unk_id)
    #         # elif pred_words > label_words:
    #         #     new_preds = []
    #         #     word_count = 0
    #         #     for i, p in enumerate(preds_final):
    #         #         if p != self.tokenizer_separator_token and (i == 0 or preds_final[i-1] == self.tokenizer_separator_token):
    #         #             word_count += 1
    #         #         if word_count <= label_words:
    #         #             new_preds.append(p)
    #         #         elif p == self.tokenizer_separator_token and word_count == label_words:
    #         #             new_preds.append(p)
    #         #             break
    #         #     preds_final = new_preds

    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final if labels_final else [self.ignore_idx] * len(preds_final), device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")
        
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
        
    #     if verbose and sample_debug_id:
    #         print(f"After Overlay [DEBUG sid={sample_debug_id}] raw_preds={preds_by_sid[sample_debug_id]} and raw_labels={labels_by_sid[sample_debug_id]} and preds={preds_by_sid_classes[sample_debug_id]} and labels={labels_by_sid_classes[sample_debug_id]}")
        
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    # def reconcile_chunks(self, outputs, verbose=True, target_device="cpu"):
    #     from collections import defaultdict, Counter
    #     import torch
    #     ignore_index = self.ignore_idx
    #     def to_list(x):
    #         if isinstance(x, torch.Tensor): return x.detach().to(device=target_device, non_blocking=True).reshape(-1).tolist()
    #         return list(x) if isinstance(x, (list, tuple)) else [x]
        
    #     seen_chunks = set()
    #     preds_by_sid, labels_by_sid, final_sids = {}, {}, []
    #     if verbose:
    #         print(f"[reconcile] start: num_outputs={len(outputs)}")
        
    #     chunks_by_sid = defaultdict(list)
        
    #     for out in outputs:
    #         sample_ids     = out["sample_ids"]
    #         chunk_ids      = out["chunk_ids"]
    #         chunk_preds    = out["preds"]
    #         chunk_labels   = out["labels"]
    #         word_positions = out["word_positions"]
    #         prompt_lens    = out["prompt_lens"]

    #         for i, sid in enumerate(sample_ids):
    #             cid = int(chunk_ids[i])
    #             if (sid, cid) in seen_chunks:
    #                 continue
    #             seen_chunks.add((sid, cid))

    #             prompt_len_i = int(prompt_lens[i])
    #             positions_i  = to_list(word_positions[i])
    #             preds_raw    = to_list(chunk_preds[i])
    #             labels_raw   = to_list(chunk_labels[i])

    #             preds_i  = [p for p in preds_raw[prompt_len_i:] if p != ignore_index]
    #             labels_i = [l for l in labels_raw[prompt_len_i:] if l != ignore_index]

    #             if sid not in final_sids:
    #                 final_sids.append(sid)

    #             chunks_by_sid[sid].append((cid, positions_i, preds_i, labels_i))
        
    #     sample_debug_id = None
    #     for sid in final_sids:
    #         chunks = chunks_by_sid[sid]
    #         if sample_debug_id is None and len(chunks) > 1:
    #             sample_debug_id = sid
    #         chunks.sort(key=lambda x: x[0])
            
    #         word_to_token_preds = defaultdict(list)
    #         word_to_sep_preds    = defaultdict(list)
    #         word_to_token_labels = defaultdict(list)
    #         word_to_sep_labels    = defaultdict(list)
            
    #         for cid, positions, preds, labels in chunks:
    #             current_word = None
    #             current_preds = []
    #             current_labels = []
    #             for posi, pre, lab in zip(positions, preds, labels):
    #                 ipos = int(posi)
    #                 if ipos >= 0:
    #                     if ipos != current_word:
    #                         if current_word is not None:
    #                             word_to_token_preds[current_word].append(current_preds[:])
    #                             word_to_token_labels[current_word].append(current_labels[:])
    #                         current_word = ipos
    #                         current_preds = [int(pre)]
    #                         current_labels = [int(lab)]
    #                     else:
    #                         current_preds.append(int(pre))
    #                         current_labels.append(int(lab))
    #                 else:
    #                     if current_word is not None:
    #                         word_to_sep_preds[current_word].append(int(pre))
    #                         word_to_sep_labels[current_word].append(int(lab))
    #             if current_word is not None:
    #                 word_to_token_preds[current_word].append(current_preds[:])
    #                 word_to_token_labels[current_word].append(current_labels[:])
            
    #         if not word_to_token_preds:
    #             continue
            
    #         max_w = max(word_to_token_preds.keys())
    #         preds_final = []
    #         labels_final = []
    #         unk_id = next(k[0] for k in self.seq2class if self.seq2class[k] == 0)
    #         sep_id = self.tokenizer_separator_token
            
    #         for w in sorted(word_to_token_preds.keys()):
    #             token_lists_p = word_to_token_preds[w]
    #             token_lists_l = word_to_token_labels[w]
                
    #             all_lens = [len(tl) for tl in token_lists_p + token_lists_l]
    #             sub_len = max(all_lens) if all_lens else 0
                
    #             if sub_len == 0:
    #                 continue
                
    #             # Vote preds
    #             word_preds = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_p if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0] if col else unk_id
    #                 word_preds.append(voted)
    #             preds_final.extend(word_preds)
                
    #             # Vote labels (absolute)
    #             word_labels = []
    #             for sub_i in range(sub_len):
    #                 col = [tl[sub_i] for tl in token_lists_l if sub_i < len(tl)]
    #                 col = [c for c in col if c != ignore_index]
    #                 voted = Counter(col).most_common(1)[0][0]
    #                 word_labels.append(voted)
    #             labels_final.extend(word_labels)
                
    #             if w < max_w:
    #                 # Separator preds
    #                 sep_col_p = [c for c in word_to_sep_preds[w] if c != ignore_index]
    #                 sep_p = Counter(sep_col_p).most_common(1)[0][0] if sep_col_p else sep_id
    #                 preds_final.append(sep_p)
                    
    #                 # Separator labels
    #                 sep_col_l = [c for c in word_to_sep_labels[w] if c != ignore_index]
    #                 sep_l = Counter(sep_col_l).most_common(1)[0][0] if sep_col_l else sep_id
    #                 labels_final.append(sep_l)
            
    #         # Final alignment: labels are ground truth length
    #         if len(preds_final) > len(labels_final):
    #             preds_final = preds_final[:len(labels_final)]
    #         elif len(preds_final) < len(labels_final):
    #             preds_final += [unk_id] * (len(labels_final) - len(preds_final))
            
    #         preds_by_sid[sid] = torch.tensor(preds_final, device=target_device)
    #         labels_by_sid[sid] = torch.tensor(labels_final, device=target_device)

    #     if verbose and sample_debug_id:
    #         print(f"[SUMMARY] reconciled samples in batch = {len(final_sids)} \
    #               sid={sample_debug_id} total_preds={len(preds_by_sid[sample_debug_id])} total_labels={len(labels_by_sid[sample_debug_id])} \
    #                 raw_preds {preds_by_sid[sample_debug_id]} and raw_labels{labels_by_sid[sample_debug_id]}\
    #                     chunks {chunks_by_sid[sample_debug_id]}")

    #     total = sum(len(l) for l in labels_by_sid.values())
    #     print(f"Total reconciled labels: {total}")
    #     preds_by_sid_classes, labels_by_sid_classes = self.overlay_classes(preds_by_sid, labels_by_sid, verbose=verbose, target_device=target_device)
    #     total_label_classes = sum(len(l) for l in labels_by_sid_classes.values())
    #     print(f"Total reconciled labels classes: {total_label_classes}")
    #     return preds_by_sid, labels_by_sid, preds_by_sid_classes, labels_by_sid_classes

    def _772f8d4f61b6(self, _e1c91bd56f72, _437aa181a3b0=_af637352b06d, _bf0a2f43dd8a="cpu"):
        from _6e2e8f8c4ce9 import _8c22bbe80f99, _850599013d83
        import _e4bb64dcbbdf
        _b09acbd6d439 = self._4bf55032d159
        def _4c5c0aa67367(_ec38718c4c78):
            if _36b35b705a0a(_ec38718c4c78, _e4bb64dcbbdf._d76c026675cc): return _ec38718c4c78._6acdfe891462()._1527c1bbfcb3(_eefb4dad793c=_bf0a2f43dd8a, _06f7f35956a6=_af637352b06d)._f93f827c1ba5(-1)._a834f564273d()
            return _b753ba625fdf(_ec38718c4c78) if _36b35b705a0a(_ec38718c4c78, (_b753ba625fdf, _65b2274d3707)) else [_ec38718c4c78]
        
        _64fb5669beaf = _8ff2965161bf()
        _77917cd4e785, _414732c3ed98, _e8c3ac39f1f1 = {}, {}, []
        if _437aa181a3b0:
            _4cf0297f2b73(f"[reconcile] start: num_outputs={_de338412d1d9(_e1c91bd56f72)}")
        
        _52df009619d0 = _8c22bbe80f99(_b753ba625fdf)
        
        for _c50c98af98ee in _e1c91bd56f72:
            _7b8d03ad3787     = _c50c98af98ee["sample_ids"]
            _d37b2f857ce5      = _c50c98af98ee["chunk_ids"]
            _86f2dd34fb60    = _c50c98af98ee["preds"]
            _c37796c2cc02   = _c50c98af98ee["labels"]
            _d9604a69777d = _c50c98af98ee["word_positions"]
            _b29988b088d5    = _c50c98af98ee["prompt_lens"]

            for _e778c53ecf17, _efe41b43deb3 in _e9a296ba2794(_7b8d03ad3787):
                _d9468c96802b = _a54de05ad7e6(_d37b2f857ce5[_e778c53ecf17])
                if (_efe41b43deb3, _d9468c96802b) in _64fb5669beaf:
                    continue
                _64fb5669beaf._10ce3a0bbce1((_efe41b43deb3, _d9468c96802b))

                _1a64fabc2730 = _a54de05ad7e6(_b29988b088d5[_e778c53ecf17])
                _a2693c9b20c6  = _ef842d0b717b(_d9604a69777d[_e778c53ecf17])
                _aaa28b8ff92e    = _ef842d0b717b(_86f2dd34fb60[_e778c53ecf17])
                _39c3abed1ad5   = _ef842d0b717b(_c37796c2cc02[_e778c53ecf17])

                _1e0c51555427  = [_160d36fbe03b for _160d36fbe03b in _aaa28b8ff92e[_1a64fabc2730:] if _160d36fbe03b != _b09acbd6d439]
                _26edda87ebc4 = [_e79c19c8c55f for _e79c19c8c55f in _39c3abed1ad5[_1a64fabc2730:] if _e79c19c8c55f != _b09acbd6d439]

                if _efe41b43deb3 not in _e8c3ac39f1f1:
                    _e8c3ac39f1f1._82be82402d25(_efe41b43deb3)

                _52df009619d0[_efe41b43deb3]._82be82402d25((_d9468c96802b, _a2693c9b20c6, _1e0c51555427, _26edda87ebc4))
        
        _70f9fa4bae8d = _328c4ab5cbf4
        for _efe41b43deb3 in _e8c3ac39f1f1:
            _7ad4cc0187e4 = _52df009619d0[_efe41b43deb3]
            _7ad4cc0187e4._589513cc8a26(_6d0a904f1fd3=lambda _ec38718c4c78: _ec38718c4c78[0])
            if _70f9fa4bae8d is _328c4ab5cbf4 and _de338412d1d9(_7ad4cc0187e4) > 1:
                _70f9fa4bae8d = _efe41b43deb3
            
            _ae44a1ab6003 = _8c22bbe80f99(_b753ba625fdf)
            _fc746f9e6539    = _8c22bbe80f99(_b753ba625fdf)
            _3c06138bbead = _8c22bbe80f99(_b753ba625fdf)
            _e828808814c6    = _8c22bbe80f99(_b753ba625fdf)
            
            _d28ccc8d4b47 = _8ff2965161bf()
            for _, _a3c076a4de2b, _, _ in _7ad4cc0187e4:
                for _f97778ce9024 in _a3c076a4de2b:
                    if _f97778ce9024 >= 0:
                        _d28ccc8d4b47._10ce3a0bbce1(_f97778ce9024)
            
            if not _d28ccc8d4b47:
                continue
            
            _450c0c6fa636 = _247b1b8a42b3(_d28ccc8d4b47)
            _4ef34209ea23 = _0e9a0670a19a(_450c0c6fa636)
            
            for _d9468c96802b, _a3c076a4de2b, _eb071efcc082, _8386e4da262e in _7ad4cc0187e4:
                _f9ba1ef54f19 = _328c4ab5cbf4
                _be364128c95c = []
                _44d801f16619 = []
                for _f4ce84cfcdf6, _27ccf24bd6d1, _9968809cdeb5 in _b9f699e873dc(_a3c076a4de2b, _eb071efcc082, _8386e4da262e):
                    _28fe067900ba = _a54de05ad7e6(_f4ce84cfcdf6)
                    if _28fe067900ba >= 0:
                        if _28fe067900ba != _f9ba1ef54f19:
                            if _f9ba1ef54f19 is not _328c4ab5cbf4:
                                _ae44a1ab6003[_f9ba1ef54f19]._82be82402d25(_be364128c95c[:])
                                _3c06138bbead[_f9ba1ef54f19]._82be82402d25(_44d801f16619[:])
                            _f9ba1ef54f19 = _28fe067900ba
                            _be364128c95c = [_a54de05ad7e6(_27ccf24bd6d1)]
                            _44d801f16619 = [_a54de05ad7e6(_9968809cdeb5)]
                        else:
                            _be364128c95c._82be82402d25(_a54de05ad7e6(_27ccf24bd6d1))
                            _44d801f16619._82be82402d25(_a54de05ad7e6(_9968809cdeb5))
                    else:
                        if _f9ba1ef54f19 is not _328c4ab5cbf4:
                            _fc746f9e6539[_f9ba1ef54f19]._82be82402d25(_a54de05ad7e6(_27ccf24bd6d1))
                            _e828808814c6[_f9ba1ef54f19]._82be82402d25(_a54de05ad7e6(_9968809cdeb5))
                if _f9ba1ef54f19 is not _328c4ab5cbf4:
                    _ae44a1ab6003[_f9ba1ef54f19]._82be82402d25(_be364128c95c[:])
                    _3c06138bbead[_f9ba1ef54f19]._82be82402d25(_44d801f16619[:])
            
            _86156ffc7cf4 = []
            _0ada8bf162f4 = []
            _dd47c3e6b121 = _62085dbec4a7(_ab1a70ba932b[0] for _ab1a70ba932b in self._dc7e4539997c if self._dc7e4539997c[_ab1a70ba932b] == 0)
            _c7c3f8c7ec90 = self._9e7775c9f702
            
            for _a9db203bb58a in _450c0c6fa636:
                _ca3acb7c9d86 = _ae44a1ab6003._58419f1dadac(_a9db203bb58a, [])
                _76772ca1d0f3 = _3c06138bbead._58419f1dadac(_a9db203bb58a, [])
                
                _d45be6ccb352 = _0e9a0670a19a((_de338412d1d9(_6d944ca18a49) for _6d944ca18a49 in _ca3acb7c9d86 + _76772ca1d0f3), _e8bc0dc9cf44=0)
                
                if _d45be6ccb352 == 0:
                    continue
                
                _87e02c692329 = []
                for _5a7f536b1a55 in _9e6fa91af473(_d45be6ccb352):
                    _717161488374 = [_6d944ca18a49[_5a7f536b1a55] for _6d944ca18a49 in _ca3acb7c9d86 if _5a7f536b1a55 < _de338412d1d9(_6d944ca18a49)]
                    _717161488374 = [_702a6b641c1d for _702a6b641c1d in _717161488374 if _702a6b641c1d != _b09acbd6d439]
                    _b8f574ca526b = _850599013d83(_717161488374)._ddcb9c298e85(1)[0][0] if _717161488374 else _dd47c3e6b121
                    _87e02c692329._82be82402d25(_b8f574ca526b)
                _86156ffc7cf4._fd52db86bee7(_87e02c692329)
                
                _b2591ef44271 = []
                for _5a7f536b1a55 in _9e6fa91af473(_d45be6ccb352):
                    _717161488374 = [_6d944ca18a49[_5a7f536b1a55] for _6d944ca18a49 in _76772ca1d0f3 if _5a7f536b1a55 < _de338412d1d9(_6d944ca18a49)]
                    _717161488374 = [_702a6b641c1d for _702a6b641c1d in _717161488374 if _702a6b641c1d != _b09acbd6d439]
                    _b8f574ca526b = _850599013d83(_717161488374)._ddcb9c298e85(1)[0][0] if _717161488374 else _b09acbd6d439
                    _b2591ef44271._82be82402d25(_b8f574ca526b)
                _0ada8bf162f4._fd52db86bee7(_b2591ef44271)
                
                if _a9db203bb58a < _4ef34209ea23:
                    _4a4c8f937f83 = [_702a6b641c1d for _702a6b641c1d in _fc746f9e6539._58419f1dadac(_a9db203bb58a, []) if _702a6b641c1d != _b09acbd6d439]
                    _4d52fe1b81ef = _850599013d83(_4a4c8f937f83)._ddcb9c298e85(1)[0][0] if _4a4c8f937f83 else _c7c3f8c7ec90
                    _86156ffc7cf4._82be82402d25(_4d52fe1b81ef)
                    
                    _7f49a8934808 = [_702a6b641c1d for _702a6b641c1d in _e828808814c6._58419f1dadac(_a9db203bb58a, []) if _702a6b641c1d != _b09acbd6d439]
                    _330a33252c7b = _850599013d83(_7f49a8934808)._ddcb9c298e85(1)[0][0] if _7f49a8934808 else _c7c3f8c7ec90
                    _0ada8bf162f4._82be82402d25(_330a33252c7b)
            
            if _de338412d1d9(_86156ffc7cf4) > _de338412d1d9(_0ada8bf162f4):
                _86156ffc7cf4 = _86156ffc7cf4[:_de338412d1d9(_0ada8bf162f4)]
            elif _de338412d1d9(_86156ffc7cf4) < _de338412d1d9(_0ada8bf162f4):
                _86156ffc7cf4 += [_dd47c3e6b121] * (_de338412d1d9(_0ada8bf162f4) - _de338412d1d9(_86156ffc7cf4))
            
            _77917cd4e785[_efe41b43deb3] = _e4bb64dcbbdf._ca7134fdff4b(_86156ffc7cf4, _eefb4dad793c=_bf0a2f43dd8a)
            _414732c3ed98[_efe41b43deb3] = _e4bb64dcbbdf._ca7134fdff4b(_0ada8bf162f4, _eefb4dad793c=_bf0a2f43dd8a)

        if _437aa181a3b0 and _70f9fa4bae8d is not _328c4ab5cbf4:
            _4cf0297f2b73(f"[SUMMARY] reconciled samples in batch = {_de338412d1d9(_e8c3ac39f1f1)} \
                sid={_70f9fa4bae8d} total_preds={_de338412d1d9(_77917cd4e785[_70f9fa4bae8d])} total_labels={_de338412d1d9(_414732c3ed98[_70f9fa4bae8d])} \
                    raw_preds {_77917cd4e785[_70f9fa4bae8d]} and raw_labels{_414732c3ed98[_70f9fa4bae8d]}\
                        chunks {_52df009619d0[_70f9fa4bae8d]}")

        _2109debadbd4 = _725721748919(_de338412d1d9(_e79c19c8c55f) for _e79c19c8c55f in _414732c3ed98._48e71ad3d20b())
        _4cf0297f2b73(f"Total reconciled labels: {_2109debadbd4}")
        _b3c013b7afd8, _192242f5ccfc = self._c41a882e53e8(_77917cd4e785, _414732c3ed98, _437aa181a3b0=_437aa181a3b0, _bf0a2f43dd8a=_bf0a2f43dd8a)
        _e4ccde69b141 = _725721748919(_de338412d1d9(_e79c19c8c55f) for _e79c19c8c55f in _192242f5ccfc._48e71ad3d20b())
        _4cf0297f2b73(f"Total reconciled labels classes: {_e4ccde69b141}")
        return _77917cd4e785, _414732c3ed98, _b3c013b7afd8, _192242f5ccfc

    def _c364c10a442a(self, _77917cd4e785, _414732c3ed98, _437aa181a3b0=_af637352b06d, _bf0a2f43dd8a="cpu"):
        _dc7e4539997c = _baf3f8ae377b(self, "seq2class", {})
        _2f4fc2a85bb0 = _baf3f8ae377b(self, "tokenizer_separator_token", _328c4ab5cbf4)
        _b09acbd6d439 = _baf3f8ae377b(self, "ignore_idx", -100)
        
        def _74bc959b88f2(_6ca1dd5a6e14, _fa33a6d7d1aa):
            _cdbcbe0d4537 = []
            _f9ba1ef54f19 = []
            for _e778c53ecf17, _b0eb6528d6fd in _e9a296ba2794(_6ca1dd5a6e14):
                if _b0eb6528d6fd == _fa33a6d7d1aa and _f9ba1ef54f19:
                    _cdbcbe0d4537._82be82402d25(_f9ba1ef54f19)
                    _f9ba1ef54f19 = []
                elif _b0eb6528d6fd != _fa33a6d7d1aa:
                    _f9ba1ef54f19._82be82402d25(_b0eb6528d6fd)
            if _f9ba1ef54f19:
                _cdbcbe0d4537._82be82402d25(_f9ba1ef54f19)
            return _cdbcbe0d4537
        
        def _be1e4ea5703a(_5a35d2afd24a, _dc7e4539997c, _437aa181a3b0, _efe41b43deb3):
            _c50c98af98ee = []
            _8bf032eebb97 = _247b1b8a42b3(_dc7e4539997c._9a9e50c11864(), _6d0a904f1fd3=_de338412d1d9, _b6d0980005d9=_af637352b06d)
            for _e778c53ecf17, _bb4c436e2cc4 in _e9a296ba2794(_5a35d2afd24a, 1):
                _fa6c86940c1d = _65b2274d3707(_bb4c436e2cc4)
                _3b5262d7e266 = self._13834352031a
                for _6d0a904f1fd3 in _8bf032eebb97:
                    if _de338412d1d9(_fa6c86940c1d) >= _de338412d1d9(_6d0a904f1fd3) and _fa6c86940c1d[:_de338412d1d9(_6d0a904f1fd3)] == _6d0a904f1fd3:
                        _3b5262d7e266 = _dc7e4539997c[_6d0a904f1fd3]
                        break
                _c50c98af98ee._82be82402d25(_3b5262d7e266)

            return _c50c98af98ee
        
        _925adccb21aa, _bd29fd05bc2d = {}, {}
        for _efe41b43deb3 in _77917cd4e785:
            _160d36fbe03b = _77917cd4e785[_efe41b43deb3]
            _e79c19c8c55f = _414732c3ed98._58419f1dadac(_efe41b43deb3, _328c4ab5cbf4)
            _eb071efcc082 = _160d36fbe03b._a834f564273d() if _36b35b705a0a(_160d36fbe03b, _e4bb64dcbbdf._d76c026675cc) else _b753ba625fdf(_160d36fbe03b)
            _8386e4da262e = _e79c19c8c55f._a834f564273d() if _36b35b705a0a(_e79c19c8c55f, _e4bb64dcbbdf._d76c026675cc) else _b753ba625fdf(_e79c19c8c55f) if _e79c19c8c55f else _328c4ab5cbf4
            if _8386e4da262e is not _328c4ab5cbf4:
                _1d0ab228b396 = _8ff34157eb44(_8386e4da262e, _2f4fc2a85bb0)
                _940c1653461e = _7e0c1a42e88f(_1d0ab228b396, _dc7e4539997c, _efe41b43deb3 == 1 or _437aa181a3b0, _efe41b43deb3)
                _95987e30def6 = _8ff34157eb44(_eb071efcc082, _2f4fc2a85bb0)
                _7a8bf1399acf = _7e0c1a42e88f(_95987e30def6, _dc7e4539997c, _efe41b43deb3 == 1 or _437aa181a3b0, _efe41b43deb3)
                if _de338412d1d9(_7a8bf1399acf) < _de338412d1d9(_940c1653461e):
                    _7a8bf1399acf += [0] * (_de338412d1d9(_940c1653461e) - _de338412d1d9(_7a8bf1399acf))
                elif _de338412d1d9(_7a8bf1399acf) > _de338412d1d9(_940c1653461e):
                    _7a8bf1399acf = _7a8bf1399acf[:_de338412d1d9(_940c1653461e)]
            else:
                _95987e30def6 = _8ff34157eb44(_eb071efcc082, _2f4fc2a85bb0)
                _7a8bf1399acf = _7e0c1a42e88f(_95987e30def6, _dc7e4539997c, _efe41b43deb3 == 1 or _437aa181a3b0, _efe41b43deb3)
                _940c1653461e = [_b09acbd6d439] * _de338412d1d9(_7a8bf1399acf)
            _925adccb21aa[_efe41b43deb3] = _e4bb64dcbbdf._ca7134fdff4b(_7a8bf1399acf, _eefb4dad793c=_bf0a2f43dd8a, _696888dee613=_e4bb64dcbbdf._a5b2448817cb)
            _bd29fd05bc2d[_efe41b43deb3] = _e4bb64dcbbdf._ca7134fdff4b(_940c1653461e, _eefb4dad793c=_bf0a2f43dd8a, _696888dee613=_e4bb64dcbbdf._a5b2448817cb)
        return _925adccb21aa, _bd29fd05bc2d

    def _fa80705e1798(self, _0e322d0ed6a6):
        _e4bb64dcbbdf._e9327961453e._904487d6d25c._3e5985eed6bd(self._e53c99d6ebb7(), _57a4092cf66e=1.0)
    
    def _f8fa76990f9c(self, _0e322d0ed6a6):
        for _65ce7806825e in self._e53c99d6ebb7():
            if _65ce7806825e is not _328c4ab5cbf4:
                _65ce7806825e._3cf099342f1f._b6c76a56ce51(-5, 5)

    def _1c49263a54ba(self):
        _ec3399a95e36 = 0
        for _65ce7806825e in self._e53c99d6ebb7():
            if _65ce7806825e._35b25b831060 is not _328c4ab5cbf4:
                _5ed0aa51769a = _65ce7806825e._35b25b831060._6acdfe891462()._3cf099342f1f._7813a65f5834(2)
                _ec3399a95e36 += _5ed0aa51769a._2e7bf07d832c() ** 2
        return _ec3399a95e36 ** 0.5  # L2 norm

    def _1afdf1303e2b(self):
        _dd76d6c235a9 = [_160d36fbe03b for _160d36fbe03b in self._e53c99d6ebb7() if _160d36fbe03b._4ea9af606fe6]
        if not _dd76d6c235a9:
            _4cf0297f2b73("No trainable parameters. Skipping optimizer creation.")
            return _328c4ab5cbf4
        
        _135c8af3171b = _93b8b929efe2(lambda _160d36fbe03b: _160d36fbe03b._4ea9af606fe6, self._e53c99d6ebb7())

        _5e7dce84ce9c = {
            "adamw": _e4bb64dcbbdf._68dce49f23b6._83a56a8cc551,
            "adamax": _e4bb64dcbbdf._68dce49f23b6._33a96677638d,
            "adam": _e4bb64dcbbdf._68dce49f23b6._456dbb0d45f3,
        }
        _febc108423e3 = _5e7dce84ce9c._58419f1dadac(self._3ac063483aca._7da5fdcdd27e(), _e4bb64dcbbdf._68dce49f23b6._456dbb0d45f3)

        _0e322d0ed6a6 = _febc108423e3(_135c8af3171b, _ffca64ad2db0=self._5d064bcb6312._ffca64ad2db0, _c7824a456d71=0.001)

        _aa76f4437593 = self._c3a3ce9f96f2._21759617337b
        _7b48ba8a171d = _85e2a9ab5578._22bb9b3269b1(0.1 * _aa76f4437593)

        _4a99705f2406 = _e4bb64dcbbdf._68dce49f23b6._efa6daab126b._c17e683510c1(_0e322d0ed6a6, _61435798bca8=lambda _6c9719e7cdf4: (_6c9719e7cdf4 + 1) / _7b48ba8a171d)

        _650c9d8367a7 = _e4bb64dcbbdf._68dce49f23b6._efa6daab126b._82eee4c1237e(
            _0e322d0ed6a6,
            _0d9a8c972556=_0e9a0670a19a(1, _aa76f4437593 - _7b48ba8a171d),
            _b1593e4a715d=2,
            _c0a004e6c589=1e-6
        )
        _efa6daab126b = _e4bb64dcbbdf._68dce49f23b6._efa6daab126b._1e8a8baf20a6(
            _0e322d0ed6a6,
            _175ce93f70b0=[_4a99705f2406, _650c9d8367a7],
            _0b64c18218c4=[_7b48ba8a171d]
        )
        return {"optimizer": _0e322d0ed6a6, "lr_scheduler": {"scheduler": _efa6daab126b, "interval": "epoch", "monitor": "val_loss"}}
