# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : date_time_utils
# @Time             : 18/12/23 10:35 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from datetime import datetime
import time


class DateTimeUtils:
    """
    Methods for any date and time operations
    """

    def get_utc_datetime_timestamp_string(self, datetime_format: str) -> str:
        """
        takes a datetime format as input and returns the same for current utc
        :param datetime_format: datetime format as string
        :return: current utc timestamp in specified format
        """
        current_datetime = datetime.utcnow()
        curr_utc_timestamp = current_datetime.strftime(datetime_format)
        if not curr_utc_timestamp:
            err_msg = f"Invalid timestamp format : '{datetime_format}'"
            raise ValueError(err_msg)
        return curr_utc_timestamp

    def get_processing_time(self, start_time: int, end_time: int) -> (int, int, int, int, int): # type: ignore
        """
        takes two time values in seconds and returns the time elapsed
        in days, hours, minutes, seconds and milliseconds
        :param start_time: time in seconds
        :param end_time: time in seconds
        :return: days, hours, minutes, seconds, milliseconds
        """
        execution_time_seconds = max(0, end_time - start_time)
        # Calculate hours, minutes, and seconds
        days, days_seconds_remaining = divmod(execution_time_seconds, 86400)
        hours, hours_seconds_remaining = divmod(days_seconds_remaining, 3600)
        minutes, seconds = divmod(hours_seconds_remaining, 60)
        milliseconds = int((execution_time_seconds - int(execution_time_seconds)) * 1000)
        # Adjust milliseconds calculation
        milliseconds += int(seconds - int(seconds)) * 1000
        hours = int(hours)
        minutes = int(minutes)
        seconds = int(seconds)
        return (days, hours, minutes, seconds, milliseconds)
    
    def get_current_time_in_milliseconds(self):
        return int(time.time() * 1000)
    
    def get_utc_date_time(self):
        utc_time = datetime.utcnow()
        return utc_time.strftime("%Y-%m-%dT%H:%M:%SZ")
    
    def get_hms_from_milliseconds(self, milliseconds):
        milliseconds = int(milliseconds)
        seconds = (milliseconds / 1000) % 60
        seconds = int(seconds)
        minutes = (milliseconds / (1000 * 60)) % 60
        minutes = int(minutes)
        hours = int((milliseconds / (1000 * 60 * 60)) % 24)

        return hours, minutes, seconds

