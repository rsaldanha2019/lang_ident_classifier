# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : date_time_utils.py
# @Time             : 2025-10-23 13:52 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from _9cf186602c96 import _9cf186602c96
import time
from typing import _f7eb5e5b997b


class _f045098a2758:
    """
    Small utility helper for common date/time operations used across the project.

    Methods are intentionally simple and synchronous (no timezone conversions beyond UTC).
    All returned string timestamps are in UTC unless otherwise noted.

    Example
    -------
    >>> d = DateTimeUtils()
    >>> d.get_utc_datetime_timestamp_string("%Y-%m-%d")
    '2025-10-23'
    >>> d.get_current_time_in_milliseconds()  # returns an int like 1635123456789
    """

    def _0a8e5b046759(self, _c494e73e11cc: _28741584c797) -> _28741584c797:
        """
        Format the current UTC time using `datetime_format` (same as datetime.strftime).

        Parameters
        ----------
        datetime_format : str
            A strftime-compatible format string (example: "%Y-%m-%dT%H:%M:%SZ").

        Returns
        -------
        str
            Current UTC time formatted according to `datetime_format`.

        Raises
        ------
        ValueError
            If `datetime_format` is empty or if the resulting formatted string is empty.
        TypeError
            If `datetime_format` is not a string.
        """
        if not _d9275eb3f9ae(_c494e73e11cc, _28741584c797):
            raise _f34c690acb81("datetime_format must be a string (strftime format).")
        if _c494e73e11cc == "":
            raise _bb7920b8257b("datetime_format must be a non-empty format string.")

        _32718e3d317d = _9cf186602c96._17b153e497f3()
        _d89812e2006d = _32718e3d317d._4099ac1c61b6(_c494e73e11cc)
        if not _d89812e2006d:
            # safety check: strftime returning empty is unusual, but handle defensively
            raise _bb7920b8257b(f"Invalid timestamp format: '{_c494e73e11cc}' produced empty string.")
        return _d89812e2006d

    def _480ae1e2d2fb(self, _ca97326b34c3: _d73bacc023dd, _8575eaadf95c: _d73bacc023dd) -> _f7eb5e5b997b[_e731922dee3c, _e731922dee3c, _e731922dee3c, _e731922dee3c, _e731922dee3c]:
        """
        Compute elapsed time between two timestamps (seconds) and return a human-friendly breakdown.

        Parameters
        ----------
        start_time : float
            Start timestamp in seconds (e.g., time.time()).
        end_time : float
            End timestamp in seconds (e.g., time.time()).

        Returns
        -------
        tuple[int, int, int, int, int]
            A tuple of (days, hours, minutes, seconds, milliseconds) representing the
            non-negative elapsed time between `start_time` and `end_time`.

        Behavior notes
        --------------
        - If `end_time < start_time` the function returns zero elapsed time (no negative durations).
        - Milliseconds represent the fractional part of total seconds, rounded down
          to an integer millisecond count (0..999).

        Raises
        ------
        TypeError
            If start_time or end_time are not numeric (int/float).
        """
        # Basic type checking for clearer error messages
        if not (_d9275eb3f9ae(_ca97326b34c3, (_e731922dee3c, _d73bacc023dd)) and _d9275eb3f9ae(_8575eaadf95c, (_e731922dee3c, _d73bacc023dd))):
            raise _f34c690acb81("start_time and end_time must be numeric (seconds since epoch, int or float).")

        # Never return negative durations
        _4aef042ac29b = _42cb92bff95e(0.0, _d73bacc023dd(_8575eaadf95c) - _d73bacc023dd(_ca97326b34c3))

        # Break down into days/hours/minutes/seconds
        _0b22b596caf7, _d1fba6a2c026 = _17362230a17e(_e731922dee3c(_4aef042ac29b), 86400)     # seconds in a day
        _1058f9a07cef, _d1fba6a2c026 = _17362230a17e(_d1fba6a2c026, 3600)                    # seconds in an hour
        _d3cbbacb5c17, _5c5c11d19ddf = _17362230a17e(_d1fba6a2c026, 60)                # seconds and remaining seconds

        # Compute milliseconds from fractional part of original total_seconds
        _5c40cc6c1d8e = _4aef042ac29b - _e731922dee3c(_4aef042ac29b)
        _6880e4728176 = _e731922dee3c(_5c40cc6c1d8e * 1000)

        return _e731922dee3c(_0b22b596caf7), _e731922dee3c(_1058f9a07cef), _e731922dee3c(_d3cbbacb5c17), _e731922dee3c(_5c5c11d19ddf), _e731922dee3c(_6880e4728176)

    def _6c72ce19ae05(self) -> _e731922dee3c:
        """
        Return current time in milliseconds since the Unix epoch (UTC).

        Returns
        -------
        int
            Current time in milliseconds (like time.time() * 1000, truncated to int).
        """
        return _e731922dee3c(time.time() * 1000)

    def _f0a41466d825(self) -> _28741584c797:
        """
        Return current UTC date/time as an ISO-like string (YYYY-MM-DDTHH:MM:SSZ).

        Returns
        -------
        str
            Current UTC time formatted as "%Y-%m-%dT%H:%M:%SZ".
        """
        _2be8334d152e = _9cf186602c96._17b153e497f3()
        return _2be8334d152e._4099ac1c61b6("%Y-%m-%dT%H:%M:%SZ")

    def _d3fc9d8bbd11(self, _6880e4728176: _e731922dee3c) -> _f7eb5e5b997b[_e731922dee3c, _e731922dee3c, _e731922dee3c]:
        """
        Convert a millisecond duration into (hours, minutes, seconds).

        Parameters
        ----------
        milliseconds : int
            Duration in milliseconds.

        Returns
        -------
        tuple[int, int, int]
            (hours, minutes, seconds) corresponding to the duration. Hours are modulo 24
            (i.e., this returns the hh:mm:ss portion rather than total hours).

        Raises
        ------
        TypeError
            If `milliseconds` is not an int or cannot be converted to int.
        """
        try:
            _a46b2f90ea03 = _e731922dee3c(_6880e4728176)
        except _4da916af0ec1 as _ed8845d4f168:
            raise _f34c690acb81("milliseconds must be an integer or convertible to int.") from _ed8845d4f168

        _4aef042ac29b = _a46b2f90ea03 // 1000
        _5c5c11d19ddf = _4aef042ac29b % 60
        _d3cbbacb5c17 = (_4aef042ac29b // 60) % 60
        _1058f9a07cef = (_4aef042ac29b // 3600) % 24

        return _e731922dee3c(_1058f9a07cef), _e731922dee3c(_d3cbbacb5c17), _e731922dee3c(_5c5c11d19ddf)
