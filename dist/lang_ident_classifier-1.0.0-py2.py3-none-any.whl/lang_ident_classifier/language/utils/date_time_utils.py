
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(53851, 58294, 2), (22189, 20591, 2), (5963, 65009, 2), (7847, 52033, 2), (39537, 53018, 2), (62888, 18009, 2), (48729, 30964, 2), (58141, 7988, 2), (40880, 27550, 2), (2492, 39967, 2), (14021, 28792, 2), (3042, 62773, 2), (43538, 38270, 2), (33066, 30571, 2), (38780, 53585, 2), (28573, 33257, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('Me0Gwg==')
_nonce = base64.b64decode('4Es8xkrLFAQVY6jC')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('sChIjyRySpDAV10DsZGxvJryGtKxKUlF7BTfSZlQEAx5Ovhc7U1fvIsdA/X5QBBOZQq1w86rDIEeQAZtvQg6PBhYYBb2qpBUshWIbXSkZnbMPjOd4PAuDufgsS2HwcFUcifxfnisxv3b3NRkdhmHA/Rr3+sS7oNnOIvCnPkaDV3WBjhSmAsP4S0kEyDtS9ZG1kBf+m/0b37jaHVHs2Fy80sruRqMP3CUn++I6GoTisWdkIjzluleQQMdFgaWa2HleAfdUhAhs2LjTtrvwyCN5e+w45LEJnLN8SuJdNwV5AxrPvTM7nR9ui8QUmVpCHdvoah5t5vFMRZbNjtpKaDejLDGzSWaXmXMlcPOCZSfjCob7eWNly7O2fS4cYo6rV1L6/KK/hPzitg8KyicszPqGGsVexngeMAevcMF9VPNcCYflWwhdc6vFHvK4hbbMcrmZEQNICuPeVP6cG1nDDDZZHPwiWsNB9YP4/1165tyr5DmJt5rdhDqitx8cZK6BpS6A+hAzXKahLGLrnYyQZoJ+KpWIecCXJI+zaU8gHy60Xz6UkLskwT/kDUkn4jBF/7QcVa0fPkxxv5B0ZSN1fry4zNQbxZhAzu4Psu0k/ohEdld+eGqhIG60+yUUUlyaZ/Wsje11TNyszVbG12+CI/z3j7YacdzGfHwha3IyJHD/A+1gJ4jGJt8zkAVnwhijB0EiVKLQowqy0NhoWmc7eo2HPXnydxTsBLdqvMS/ikHZeAqDMSbznqWPeWlI1SGuEU8stee19Kxzq+ehIbcz4XlsbcDrNdSoDUE3Uic7w3TVNV7Uqn0tASqGCWlYbEj4HdvMCJfFW7jMpKBFKPZDx45xrqwwGAxHSLjACRZND9CdKIfpk43gGzonpcTqwlq32H0BL2Nf+4F3mhkuP3Qrsg9GccvWmNw/4PWeItopb6MeXB5j0rGJbwMuo33f4FAfRR2rQcBToH1HTS8TztgNJoseqmW/HZ79hvrpr5rVHCToMuonjYWSNn02BnE0RAoZfkEUprQuMK+zJWOLnzPoEu8VyrEn4uEFWYLGaxSBBFQP4NT9oPJqC9pxLExrFucrB0djZRLdUT9Tm3Tiku9ESPdpSP6KRD7Hh3NAKLoBR56tHR7rYwc24iMwahHPu/+WO30PBqhGzZ+koNocGKm162Wu/cedtL8Kw4Q8IWof5c/72HmjIu8+E6J0FAyk83nNmpK2ZnlBieUOSMu6cxsKWwejCG5mtOSo7D3oF0fQhsujqcRcEbUv7Co2ReqQn9QuhuSYxK56TpFpvhjLb5g2L4QyEN9i+dQnrKJ0xhcchxspNVMsVaYV7551ng6HNM0ssERM56HJ9uYvxQzry4x6hzY2ofO5zJ0UY3pk1o9NrqEYDwVb/KeNIFVPsNFpsJJv20E6/sxJEks8e9t+QLO1G+WLChg5jXK7Fz5xoNcRPrYZzFKGbfRzww8Kt6WGZyJUXo7XaAGSDOEqoIMxMUtXFjPcjE7zTtCX4UYVKl5FKzi95s0XMUXVrqdaDeyNNXTIDdMTWWedoycMa/7nWVrXkaYxlh+wNnk/2navTRV3ggjUNVcGn3zHR0GRjh3XCY9um8/ckgYJdpVMdAt84fmO1de7bA2TtZFhZvrqah6tmCaV45oXAVfIax9W+5Db3WuNaz0b7m9zNe1GazyBk0dqgTp6bZxikkjeDtcc3elDxGVBN+vV7GXgy5agTKfSeO80VUYtlEapBAMQKy6/XVm5d6EkyZnIA2gJd+2LNlCXI1MOgmO6qIvujp/XyUVsslL20UkHctbBVOH0r7Wei7ltgWITWrTx9RCR/byoikOsxIME9obJspUHZtQJOVCmu8nZj8goqbkPJgkT6AA7jobCVB2QL29fgb/oStHxTWJdHfsZaMXNUHOX4SpvldpBf+eTYRjPmGcnbYQVpcLwAjAFa9sQ2IR7hLtP/nqwFy7w0OmLw3GhYsi4i85gtKUjmZsTPBpz58u67hkit/jNaEOFKBeF1255nr39dsVrsfGclc1cn5Xe0WHwY+IU8WqJvcLO6WnlMl7Anj2NMuwie2UHDu1Xrl1g5lG4PCuFYWIkMvT/8Hp9zFXfG5VCY3IS1r5XpvyIKZOLTu1LTRU0Wewdw2015GLY/uwg51VMIP9de1tDtiuW3sYQU2fJ/hQHLHUwvHN0YDIxJVQhlofdJQDJs4NUKlz/GyFTHChjjmpIjp94Sfltz3331oglJOZ51ywiu2NT6GYPlnFiHJv3ouFDRhbsJRNJ7Ip9UmHvqokoCVxybGiRdr8EeuY13xOpq2EACl56gkjBwHTJKVYnngpFRsIWWzn+N10wNaaDqLTVtrQsFghnIKZzzrZPgpisNqtglmvvL/onuaANnrJArRL3hEOuKFpkacf6TBlnlDhxuMwAAhwmVtFIxgK9udz6u78lUZLEFadt4qmz5q44/B+R6wVp8C6MNa/GS5xoN1o7TBnCGCx61iUzFIVCQX52vvc7A8ltKZTV0B9U6cVeJj9bvKsWXrtfeHEQ4bPLc75ae5DhLU3R0eUbZAfl4E+MGmm56PlDVEaqMjEiuX06tFowSD3LN8QGsc7t6HJwpRdd00he0rYxe1St+Sg22kUGx2BOtUddzAPDnTNNPRqpfaZw2v+KGtNJTXEBGS2PZ57SbBqXowRSfqjbQJpUPfAU9+i8X8+dkvjOxQfGafSiS6eb5pyK6cw80up1llgrA/sODYyQvyDfdugKGfJSA/Sl9lxfSa5c8qEEPielZQVrEGqfS8sAziKxQbRUegRFcyeBhmWXGnFwk2FWYKaB+gBvEwWND9PJL2Vwc+JeIul11Hh8acg/lU0C5UNFHJYlTP97bcH56NHbsk9/aEGoW5dcxbq9YQRZ9XCIYeztLQ/zaGmP9Eo5yqRvkEtyQf6kSeKu04r0S97wMTn1SUJlhUYePhzgChPsggaXxYq+Y1nhQ66KtZfu3pG2zuiLa6h30uggAwVHUTK6BJwFSMP4CadN0Ca3SWZd3419SNR293NfkOZ7EjxR/rgf+wJA3tk1otqxWEZNO8tUWsqc6OgbgubFn8gkSCgtqUClKo+MimFr3sLT3S2iokSH7SFsdWtIxTAR0xxSZ0AVQGh9n50TNEAyky4KwDWVmzwcT6kTkSFTvu5cJ7PejUd+87rBRUcUorOPWZo63nzuULPOWx5D8xEXi99QJ9Q0keO/v/T7PdDMnvlO2VvxS8p5bV+YHFEqekHoCaA0BBGs0Qjjyz7thNQB6r2Yy8gv4LifX61A9+XN6y5CQdp6q65coaRCra8OqHRcpm2wI1ZYfxHVBjLBbNIBpRAZJ7lIoCrZNeeUz1joLocT9BVihV7D6WmUjnd9caDZmJ+nkgx9JpnwQoboiMf/dtLHBobgxKbNLfPwZrmTShQqThkdpS2nc66BrjggVhjrVkrn2C9qOAOf1+IAYwvaNZrAFdCaNaCO0vzxQVwgD3+a+5EBbx8JBdtE+MAplP6B36QDM66LtSgQ1ZFcfwlIcOtkAFirZUPfsl/RoWfQ1hFvtHQpci5eXT39nr3KymrdpWajzi0wFfgsh+9NAoN4qqqOVbql0jt9TVy2/7pT5wLtntKvvzZEyau1enVZq8r34D1tZW0dHDuwUBFxtQMLLyTw5gxa+8K/3EZIuFGP1srSSz/exscAdheKu+yG6cLM2szG+enZOEi3S9a4XH7Ox1Iq6EBTEC0OO+zLUkY11m/Ehjk+B30QU2Y5kxYFxvEifIlGf2zGEJwVcjbPtvgDCCJyOrdYIU+Acjpr/dhurvNJ+MFq7O5PeD92/yMSfhoFKO+zpRbo5x4ren2cwYDgZJYXZvhCh6OTD0XxMm7463vpQUiDi3Eol/SiqqH2JGSFNbEe0UN2mLcRAcbfzcqyemSC/7oUYKkK9vJnarDQpzVKYuuEakv+ybTl71TpUcJ5vqBX+Bz/cqghTYFxNa0flaKrQLSEzH1TxpUXHHlI47LhC5lq+2TaTH6H68DGTqNCu1hHVbelsUwqNl0NqqpBNxBVPW23RafsocJ3xjZnUFgybYI8Rmv3HWkWwVcMP8i3kaorknS0tcohFituxKLC8Du0JyW4zZ0Hb3fbVwFINyKvPIXnVbBS7zC2NJynb5HD5TLDF9K6hJGPmNeWuzbQ5kmO1RdwLid01rFplh+8SuXtW3NgdOhrCVETSrbI5zsZJh7vdY/bIc8DI0/vP72ZtiYLG9+KcxQGgaT8SnqJNSBgWr+/3aLQxpN/BRJxsdQGMDVbLPHv1riNVOpjYRUo13mCW4KiAqdRZFRoR8cUu1LHhmtsDS1mfLFCWhQa9YRMQK8WpSKwBe4Ss26SRhmy3lLtzRuCfKg5BVxZ76inVKNnop6EIHztWh4Erc2gnQEiCaVoXFFLZyChswpWON6u3dslkQs3hCRWNrZq5fq45nHADwyeBFXs3gnP0VX2x9n8Pd0+MhXo5GxIO/KyBnO3JefhbHLxmpj4WiDGp+stlYw/bkUlEAhiDmxMrMcjzniFu/qi8j+szOGGh+JzjSkCr7CZsaJJm1P+3Eospclxomd05nESIY6j1mGM2a+Z6d8NtSM5pNS3ouzf48d7UxJDzPk3nT+mYJL4W2RVg0r0RVGeJJPpypzlJwvGnEbfPfJccCUGUOTr25GGh1edtDldlSkbB5tz86qrbshZMoOMEpTaTGd6m4RTsz+bh3TDisxgEpmR1SC9zPRxZLS6bE3FA81xHBBZM+4+A5nXI/l+IADByRwmpGXNs8tocBt7Zzmd+Jr3glOdGV7WBqidRMIMQivTIJezCiHlVy4a4LdJcAYjT7fU53yfIlbgMH19F82MfeehezMBjtGrm3mzlDQffUzcjZTQ51/b8nbkQ538OioxnHaA9g/U5E17GfzoCThucJXoSgTcYsePayHnUquV9G2B+q1d8OME03MGspVNf7Eo/zxiEDOCUd8RPWjKVlzhRINwKUbBuiGFwOkIAIkeDMWT8bv/Nmy7HtQr/bq49B+f2lvPlCa7ek6ISTVI7d8AurYp1MkA6NpqjVDPcwJGTOEIKwYiZRfEMpmkC9SAD5wmnZgVW9kJyKe7n1eJj1s5YOG36hPelDxDCj2v1YyvCcPZDC8yE6UYhOhPKo6Ms33teacsp7+q7OPM1AmsJQX1W5j9heZ6YRnDt5JTTqrfgVwaqZrlwqfxdg4i9jyVss89PKY+pY5cOvuBszjVkF5GN5kLqKbRFRlFRNCyOhAbPgE/bWC/KPcq2XlOa6rxtmWT/difW8AiJQelH/BP+L+GzZ0GrXPjHgpewnz5W2WI+tA1KGY5+1//xmHpwJeXU2D/GUfhGL9wSc8FcyZpa3nsDZ6IGBR/ZSVEs9RMWHPv/zg7C65kHRc2UDXHAtUiOLWwf4RfpFHNWfKrOg98msxRHp6ELdS7kAQ++4QajAiybWobEG+gcQfLEIWlOhrufayftfdJxJA/ToZKB1AVlR5nO5Phi4RhT3Nu8RDzdmqL8OyiDMNqdtdC2X64z/oNBTaNMv2vb7c00E2DVlb7MYhL9ardbd/AWrOcd42wsxWXoEqBZO8x+ULtntG6s0ZN3fvYCfVga9dV5kg8H3OhSPt9if+Cqy2M4d3i4MzzFlqBinm2uaMIh7AKOW5/pHLTVOtNp9CLz6eNb00eDMkoyfRuT56rxEHWFDIKxDdAwJIzIUUVU1NZMRZDXKu4EBkAb/RFgQBuqA3iME9c7HdQ+QeieTZLy3HDyTgNUIPi2cPobgrGashFRpfbAkGemIseduSKyc063W/+T+GveegnfOk4UdPa9Zap//gJlT9exZol0+Pw/ZkQGvLLTXAyn4mI85okiLuzBSPWeqZKqavjK+KinaypEv5uoNM6dx4+81DhtiZ/zbXfYKp9kCvXZjse/5+CbEVz2vftizzZGb20VaDtn57KJQFBbvHCLz8cyMkCXxfQzdTRkvZYQDbVAQjVaraCMSD7B9d9ikZ9fIK9fDmKHkN64LgmaHPCEsIC7QpDF0h8vzrj0BmOWLAyg+5Ff4l9JVjCKttTApizJ3qjBi3JcNc8XF/sdzv3PDNNilYxWmhG2AcBNWQmYuZ7GNMzLqSpEzSm6irTSUjXqILpIbstywB3s8vsXUZNwsLrtwtyTIEoKCG6w1wuQwODFwD3ez7zhvToXWdJg4cWT6/mgGypPuk4pQHPKYOiocnYb24kjAOFS3PgVC1GKdJYkyHdiPWIyoBHV6Bp1/+FzCIG7RNeLxEAk6EHAU1aB902zCGMLnCoCsNm+ZZjeBMoWiL/RnUKW2BsCYoML2BNOtNSUkSJ7CIlBd8f3x4VMqJfhA0TKEdYZ/tsI4bZEpEUJIzXdqOv+uzXhB41Ek2KwiMOCeliKYP0pWSdRTFIo/L/cqAWSvzt72wdgSw6UBr2oYaL9H7DwDEzFlwWauTIAzKZVjwJMy4akCeeenSCuFJghsoQVs4+4ulOOzqyPGOTFGta4oM3qY67LqRuDjLdLoSHqpQZRKOg0BMOXo60gklK/0SOIy+dz0NfptlhaEEr4/a4m9vAl9WSyEZSGo4IIcaSqQd3QEatRORnyNfYTMk5NzxKKBOzIpIOcAYK/n9s4bNgzzzJrvs6VqhXkbEqsylJQbYxRMLzj+yJN8qaNC6EO90DvPO3Yl1XLaH9qYjMEx7pLe8936Lny6mexAFNUQh/kvurlvgeK/VCi4aZsYGMjZOASEs2H9eZIVjCiykdt3k8o4UX3rZV4L+bkBvEPxfhLgK5SJhgooumCSCKMsFkfxyZ/JVZbC9JVlBSBVi2iazGYOAeTak5v2ewM1T6iLp7xTfqlMOOckh+PbiTXaYBdAu3Kry6oEewS3wvUQAyDviVpaqxARsXuU/td7eZYkNPunx836M8CW3QtvQKouxl3x/U65cbFSQs+jJEyj3LsqIyty8bcfpyKzUMuyUSabn+5UsBr6O/jC9/HMBuXmJUQdLLZnuM9uWejIbYG6+vbu7VEi8Il2V24L7Zf/hzxnrKkeGLyUk0hfzY/DKV+oVHTVeNdjV2lyXVbOJ')
_tag = base64.b64decode('fuGfvpzyme+ge3SKBcvRVg==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
