# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : date_time_utils.py
# @Time             : 2025-10-23 13:52 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from _713d2fb57f01 import _713d2fb57f01
import time
from typing import _cee67a59fee3


class _c5f86744813f:
    """
    Small utility helper for common date/time operations used across the project.

    Methods are intentionally simple and synchronous (no timezone conversions beyond UTC).
    All returned string timestamps are in UTC unless otherwise noted.

    Example
    -------
    >>> d = DateTimeUtils()
    >>> d.get_utc_datetime_timestamp_string("%Y-%m-%d")
    '2025-10-23'
    >>> d.get_current_time_in_milliseconds()  # returns an int like 1635123456789
    """

    def _3c8367dfe282(self, _5c01e02c7e1d: _ebfd355f55d3) -> _ebfd355f55d3:
        """
        Format the current UTC time using `datetime_format` (same as datetime.strftime).

        Parameters
        ----------
        datetime_format : str
            A strftime-compatible format string (example: "%Y-%m-%dT%H:%M:%SZ").

        Returns
        -------
        str
            Current UTC time formatted according to `datetime_format`.

        Raises
        ------
        ValueError
            If `datetime_format` is empty or if the resulting formatted string is empty.
        TypeError
            If `datetime_format` is not a string.
        """
        if not _e551a6930fe0(_5c01e02c7e1d, _ebfd355f55d3):
            raise _3b3382ec4d7d("datetime_format must be a string (strftime format).")
        if _5c01e02c7e1d == "":
            raise _ccba6144d8e6("datetime_format must be a non-empty format string.")

        _d0e53f679ffb = _713d2fb57f01._1783853ea0a8()
        _c64eca3eac32 = _d0e53f679ffb._e35dcefcf4d5(_5c01e02c7e1d)
        if not _c64eca3eac32:
            # safety check: strftime returning empty is unusual, but handle defensively
            raise _ccba6144d8e6(f"Invalid timestamp format: '{_5c01e02c7e1d}' produced empty string.")
        return _c64eca3eac32

    def _026f0380f2f7(self, _dca1c9e7f9d6: _92246dab064e, _f998091abfc8: _92246dab064e) -> _cee67a59fee3[_5ab733d7bdcb, _5ab733d7bdcb, _5ab733d7bdcb, _5ab733d7bdcb, _5ab733d7bdcb]:
        """
        Compute elapsed time between two timestamps (seconds) and return a human-friendly breakdown.

        Parameters
        ----------
        start_time : float
            Start timestamp in seconds (e.g., time.time()).
        end_time : float
            End timestamp in seconds (e.g., time.time()).

        Returns
        -------
        tuple[int, int, int, int, int]
            A tuple of (days, hours, minutes, seconds, milliseconds) representing the
            non-negative elapsed time between `start_time` and `end_time`.

        Behavior notes
        --------------
        - If `end_time < start_time` the function returns zero elapsed time (no negative durations).
        - Milliseconds represent the fractional part of total seconds, rounded down
          to an integer millisecond count (0..999).

        Raises
        ------
        TypeError
            If start_time or end_time are not numeric (int/float).
        """
        # Basic type checking for clearer error messages
        if not (_e551a6930fe0(_dca1c9e7f9d6, (_5ab733d7bdcb, _92246dab064e)) and _e551a6930fe0(_f998091abfc8, (_5ab733d7bdcb, _92246dab064e))):
            raise _3b3382ec4d7d("start_time and end_time must be numeric (seconds since epoch, int or float).")

        # Never return negative durations
        _68f7293aad49 = _8a136ec6dd27(0.0, _92246dab064e(_f998091abfc8) - _92246dab064e(_dca1c9e7f9d6))

        # Break down into days/hours/minutes/seconds
        _7e98e471451a, _4ffeb2fdaca4 = _ac7ad6f43853(_5ab733d7bdcb(_68f7293aad49), 86400)     # seconds in a day
        _ec75029e8e26, _4ffeb2fdaca4 = _ac7ad6f43853(_4ffeb2fdaca4, 3600)                    # seconds in an hour
        _95a41a26cd13, _0cc7813d801d = _ac7ad6f43853(_4ffeb2fdaca4, 60)                # seconds and remaining seconds

        # Compute milliseconds from fractional part of original total_seconds
        _6dea50b803b3 = _68f7293aad49 - _5ab733d7bdcb(_68f7293aad49)
        _f74df9bc8c2c = _5ab733d7bdcb(_6dea50b803b3 * 1000)

        return _5ab733d7bdcb(_7e98e471451a), _5ab733d7bdcb(_ec75029e8e26), _5ab733d7bdcb(_95a41a26cd13), _5ab733d7bdcb(_0cc7813d801d), _5ab733d7bdcb(_f74df9bc8c2c)

    def _e9a4276695a4(self) -> _5ab733d7bdcb:
        """
        Return current time in milliseconds since the Unix epoch (UTC).

        Returns
        -------
        int
            Current time in milliseconds (like time.time() * 1000, truncated to int).
        """
        return _5ab733d7bdcb(time.time() * 1000)

    def _ea18ab1221ec(self) -> _ebfd355f55d3:
        """
        Return current UTC date/time as an ISO-like string (YYYY-MM-DDTHH:MM:SSZ).

        Returns
        -------
        str
            Current UTC time formatted as "%Y-%m-%dT%H:%M:%SZ".
        """
        _c5a12a44e53e = _713d2fb57f01._1783853ea0a8()
        return _c5a12a44e53e._e35dcefcf4d5("%Y-%m-%dT%H:%M:%SZ")

    def _cc5c41c4ea92(self, _f74df9bc8c2c: _5ab733d7bdcb) -> _cee67a59fee3[_5ab733d7bdcb, _5ab733d7bdcb, _5ab733d7bdcb]:
        """
        Convert a millisecond duration into (hours, minutes, seconds).

        Parameters
        ----------
        milliseconds : int
            Duration in milliseconds.

        Returns
        -------
        tuple[int, int, int]
            (hours, minutes, seconds) corresponding to the duration. Hours are modulo 24
            (i.e., this returns the hh:mm:ss portion rather than total hours).

        Raises
        ------
        TypeError
            If `milliseconds` is not an int or cannot be converted to int.
        """
        try:
            _454b57b398f7 = _5ab733d7bdcb(_f74df9bc8c2c)
        except _98ab285b3d46 as _ab26c14f1c42:
            raise _3b3382ec4d7d("milliseconds must be an integer or convertible to int.") from _ab26c14f1c42

        _68f7293aad49 = _454b57b398f7 // 1000
        _0cc7813d801d = _68f7293aad49 % 60
        _95a41a26cd13 = (_68f7293aad49 // 60) % 60
        _ec75029e8e26 = (_68f7293aad49 // 3600) % 24

        return _5ab733d7bdcb(_ec75029e8e26), _5ab733d7bdcb(_95a41a26cd13), _5ab733d7bdcb(_0cc7813d801d)
