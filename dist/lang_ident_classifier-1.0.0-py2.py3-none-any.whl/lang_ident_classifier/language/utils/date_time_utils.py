# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : date_time_utils.py
# @Time             : 2025-10-23 13:52 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from _b3a00f074b80 import _b3a00f074b80
import time
from typing import _eefc771965c7


class _ba4dd89a48c9:
    """
    Small utility helper for common date/time operations used across the project.

    Methods are intentionally simple and synchronous (no timezone conversions beyond UTC).
    All returned string timestamps are in UTC unless otherwise noted.

    Example
    -------
    >>> d = DateTimeUtils()
    >>> d.get_utc_datetime_timestamp_string("%Y-%m-%d")
    '2025-10-23'
    >>> d.get_current_time_in_milliseconds()  # returns an int like 1635123456789
    """

    def _66b6b489db58(self, _5b6ffe288859: _da8b6976b9f9) -> _da8b6976b9f9:
        """
        Format the current UTC time using `datetime_format` (same as datetime.strftime).

        Parameters
        ----------
        datetime_format : str
            A strftime-compatible format string (example: "%Y-%m-%dT%H:%M:%SZ").

        Returns
        -------
        str
            Current UTC time formatted according to `datetime_format`.

        Raises
        ------
        ValueError
            If `datetime_format` is empty or if the resulting formatted string is empty.
        TypeError
            If `datetime_format` is not a string.
        """
        if not _e5141cf48705(_5b6ffe288859, _da8b6976b9f9):
            raise _68bbea1a0310("datetime_format must be a string (strftime format).")
        if _5b6ffe288859 == "":
            raise _fa3d075256bd("datetime_format must be a non-empty format string.")

        _a9256a611a46 = _b3a00f074b80._5743e6a257e1()
        _9b3833048469 = _a9256a611a46._4e00ee3f56c1(_5b6ffe288859)
        if not _9b3833048469:
            # safety check: strftime returning empty is unusual, but handle defensively
            raise _fa3d075256bd(f"Invalid timestamp format: '{_5b6ffe288859}' produced empty string.")
        return _9b3833048469

    def _187aff0e2ebf(self, _f548130e63ba: _3207ca68182b, _42791b1e8495: _3207ca68182b) -> _eefc771965c7[_545b34b7ec89, _545b34b7ec89, _545b34b7ec89, _545b34b7ec89, _545b34b7ec89]:
        """
        Compute elapsed time between two timestamps (seconds) and return a human-friendly breakdown.

        Parameters
        ----------
        start_time : float
            Start timestamp in seconds (e.g., time.time()).
        end_time : float
            End timestamp in seconds (e.g., time.time()).

        Returns
        -------
        tuple[int, int, int, int, int]
            A tuple of (days, hours, minutes, seconds, milliseconds) representing the
            non-negative elapsed time between `start_time` and `end_time`.

        Behavior notes
        --------------
        - If `end_time < start_time` the function returns zero elapsed time (no negative durations).
        - Milliseconds represent the fractional part of total seconds, rounded down
          to an integer millisecond count (0..999).

        Raises
        ------
        TypeError
            If start_time or end_time are not numeric (int/float).
        """
        # Basic type checking for clearer error messages
        if not (_e5141cf48705(_f548130e63ba, (_545b34b7ec89, _3207ca68182b)) and _e5141cf48705(_42791b1e8495, (_545b34b7ec89, _3207ca68182b))):
            raise _68bbea1a0310("start_time and end_time must be numeric (seconds since epoch, int or float).")

        # Never return negative durations
        _7c4197dc9260 = _bb44a495a97e(0.0, _3207ca68182b(_42791b1e8495) - _3207ca68182b(_f548130e63ba))

        # Break down into days/hours/minutes/seconds
        _fd1d565f7ae3, _7deafe9d4893 = _7455e46cb385(_545b34b7ec89(_7c4197dc9260), 86400)     # seconds in a day
        _1f232628c84e, _7deafe9d4893 = _7455e46cb385(_7deafe9d4893, 3600)                    # seconds in an hour
        _a9985a44893d, _d13ef8539a9a = _7455e46cb385(_7deafe9d4893, 60)                # seconds and remaining seconds

        # Compute milliseconds from fractional part of original total_seconds
        _2937981e06ca = _7c4197dc9260 - _545b34b7ec89(_7c4197dc9260)
        _9033c6ad85aa = _545b34b7ec89(_2937981e06ca * 1000)

        return _545b34b7ec89(_fd1d565f7ae3), _545b34b7ec89(_1f232628c84e), _545b34b7ec89(_a9985a44893d), _545b34b7ec89(_d13ef8539a9a), _545b34b7ec89(_9033c6ad85aa)

    def _3d3933ba0a84(self) -> _545b34b7ec89:
        """
        Return current time in milliseconds since the Unix epoch (UTC).

        Returns
        -------
        int
            Current time in milliseconds (like time.time() * 1000, truncated to int).
        """
        return _545b34b7ec89(time.time() * 1000)

    def _734eef66421d(self) -> _da8b6976b9f9:
        """
        Return current UTC date/time as an ISO-like string (YYYY-MM-DDTHH:MM:SSZ).

        Returns
        -------
        str
            Current UTC time formatted as "%Y-%m-%dT%H:%M:%SZ".
        """
        _bb007a22c963 = _b3a00f074b80._5743e6a257e1()
        return _bb007a22c963._4e00ee3f56c1("%Y-%m-%dT%H:%M:%SZ")

    def _973b3bba00d7(self, _9033c6ad85aa: _545b34b7ec89) -> _eefc771965c7[_545b34b7ec89, _545b34b7ec89, _545b34b7ec89]:
        """
        Convert a millisecond duration into (hours, minutes, seconds).

        Parameters
        ----------
        milliseconds : int
            Duration in milliseconds.

        Returns
        -------
        tuple[int, int, int]
            (hours, minutes, seconds) corresponding to the duration. Hours are modulo 24
            (i.e., this returns the hh:mm:ss portion rather than total hours).

        Raises
        ------
        TypeError
            If `milliseconds` is not an int or cannot be converted to int.
        """
        try:
            _5d21886994cc = _545b34b7ec89(_9033c6ad85aa)
        except _871ecb522b7a as _aed1bf9694cf:
            raise _68bbea1a0310("milliseconds must be an integer or convertible to int.") from _aed1bf9694cf

        _7c4197dc9260 = _5d21886994cc // 1000
        _d13ef8539a9a = _7c4197dc9260 % 60
        _a9985a44893d = (_7c4197dc9260 // 60) % 60
        _1f232628c84e = (_7c4197dc9260 // 3600) % 24

        return _545b34b7ec89(_1f232628c84e), _545b34b7ec89(_a9985a44893d), _545b34b7ec89(_d13ef8539a9a)
