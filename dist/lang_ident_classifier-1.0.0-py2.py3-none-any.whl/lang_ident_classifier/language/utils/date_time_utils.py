# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : date_time_utils.py
# @Time             : 2025-10-23 13:52 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from _76a90dba9fbb import _76a90dba9fbb
import _04e4ab10531e
from _99251218eb06 import _b1d68e83dde7


class _796686afbc13:
    """
    Small utility helper for common date/time operations used across the project.

    Methods are intentionally simple and synchronous (no timezone conversions beyond UTC).
    All returned string timestamps are in UTC unless otherwise noted.

    Example
    -------
    >>> d = DateTimeUtils()
    >>> d.get_utc_datetime_timestamp_string("%Y-%m-%d")
    '2025-10-23'
    >>> d.get_current_time_in_milliseconds()  # returns an int like 1635123456789
    """

    def _60ea256baaf0(self, _6fe1167f5b50: _25099df4aba3) -> _25099df4aba3:
        """
        Format the current UTC time using `datetime_format` (same as datetime.strftime).

        Parameters
        ----------
        datetime_format : str
            A strftime-compatible format string (example: "%Y-%m-%dT%H:%M:%SZ").

        Returns
        -------
        str
            Current UTC time formatted according to `datetime_format`.

        Raises
        ------
        ValueError
            If `datetime_format` is empty or if the resulting formatted string is empty.
        TypeError
            If `datetime_format` is not a string.
        """
        if not _8fd726c89e43(_6fe1167f5b50, _25099df4aba3):
            raise _d75299be2a7f("datetime_format must be a string (strftime format).")
        if _6fe1167f5b50 == "":
            raise _6ab7c6058420("datetime_format must be a non-empty format string.")

        _c2a1d50b4368 = _76a90dba9fbb._7aa05513eca3()
        _5880e07d78aa = _c2a1d50b4368._8aace5acf5a8(_6fe1167f5b50)
        if not _5880e07d78aa:
            # safety check: strftime returning empty is unusual, but handle defensively
            raise _6ab7c6058420(f"Invalid timestamp format: '{_6fe1167f5b50}' produced empty string.")
        return _5880e07d78aa

    def _c9929474c77d(self, _0288985c38b6: _963f983672f0, _f8aaa4500f58: _963f983672f0) -> _b1d68e83dde7[_289657c71148, _289657c71148, _289657c71148, _289657c71148, _289657c71148]:
        """
        Compute elapsed time between two timestamps (seconds) and return a human-friendly breakdown.

        Parameters
        ----------
        start_time : float
            Start timestamp in seconds (e.g., time.time()).
        end_time : float
            End timestamp in seconds (e.g., time.time()).

        Returns
        -------
        tuple[int, int, int, int, int]
            A tuple of (days, hours, minutes, seconds, milliseconds) representing the
            non-negative elapsed time between `start_time` and `end_time`.

        Behavior notes
        --------------
        - If `end_time < start_time` the function returns zero elapsed time (no negative durations).
        - Milliseconds represent the fractional part of total seconds, rounded down
          to an integer millisecond count (0..999).

        Raises
        ------
        TypeError
            If start_time or end_time are not numeric (int/float).
        """
        # Basic type checking for clearer error messages
        if not (_8fd726c89e43(_0288985c38b6, (_289657c71148, _963f983672f0)) and _8fd726c89e43(_f8aaa4500f58, (_289657c71148, _963f983672f0))):
            raise _d75299be2a7f("start_time and end_time must be numeric (seconds since epoch, int or float).")

        # Never return negative durations
        _e3dc09a6f62c = _5961536c8550(0.0, _963f983672f0(_f8aaa4500f58) - _963f983672f0(_0288985c38b6))

        # Break down into days/hours/minutes/seconds
        _cda796e713c8, _2fecb70782e1 = _3d67da0ba553(_289657c71148(_e3dc09a6f62c), 86400)     # seconds in a day
        _b1476078f011, _2fecb70782e1 = _3d67da0ba553(_2fecb70782e1, 3600)                    # seconds in an hour
        _67df0e241c95, _c446f657093a = _3d67da0ba553(_2fecb70782e1, 60)                # seconds and remaining seconds

        # Compute milliseconds from fractional part of original total_seconds
        _e79803fabd23 = _e3dc09a6f62c - _289657c71148(_e3dc09a6f62c)
        _3678f5d684d5 = _289657c71148(_e79803fabd23 * 1000)

        return _289657c71148(_cda796e713c8), _289657c71148(_b1476078f011), _289657c71148(_67df0e241c95), _289657c71148(_c446f657093a), _289657c71148(_3678f5d684d5)

    def _d68c5035baaf(self) -> _289657c71148:
        """
        Return current time in milliseconds since the Unix epoch (UTC).

        Returns
        -------
        int
            Current time in milliseconds (like time.time() * 1000, truncated to int).
        """
        return _289657c71148(_04e4ab10531e._04e4ab10531e() * 1000)

    def _5056451de6f0(self) -> _25099df4aba3:
        """
        Return current UTC date/time as an ISO-like string (YYYY-MM-DDTHH:MM:SSZ).

        Returns
        -------
        str
            Current UTC time formatted as "%Y-%m-%dT%H:%M:%SZ".
        """
        _c966ee3dff9c = _76a90dba9fbb._7aa05513eca3()
        return _c966ee3dff9c._8aace5acf5a8("%Y-%m-%dT%H:%M:%SZ")

    def _44dec9b64efb(self, _3678f5d684d5: _289657c71148) -> _b1d68e83dde7[_289657c71148, _289657c71148, _289657c71148]:
        """
        Convert a millisecond duration into (hours, minutes, seconds).

        Parameters
        ----------
        milliseconds : int
            Duration in milliseconds.

        Returns
        -------
        tuple[int, int, int]
            (hours, minutes, seconds) corresponding to the duration. Hours are modulo 24
            (i.e., this returns the hh:mm:ss portion rather than total hours).

        Raises
        ------
        TypeError
            If `milliseconds` is not an int or cannot be converted to int.
        """
        try:
            _1782358a8737 = _289657c71148(_3678f5d684d5)
        except _4aa18eab4f93 as _5ac365e0a42e:
            raise _d75299be2a7f("milliseconds must be an integer or convertible to int.") from _5ac365e0a42e

        _e3dc09a6f62c = _1782358a8737 // 1000
        _c446f657093a = _e3dc09a6f62c % 60
        _67df0e241c95 = (_e3dc09a6f62c // 60) % 60
        _b1476078f011 = (_e3dc09a6f62c // 3600) % 24

        return _289657c71148(_b1476078f011), _289657c71148(_67df0e241c95), _289657c71148(_c446f657093a)
