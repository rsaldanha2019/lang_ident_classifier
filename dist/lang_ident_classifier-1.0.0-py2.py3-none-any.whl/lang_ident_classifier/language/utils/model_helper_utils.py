# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_helper_utils.py
# @Time             : 2025-10-27 12:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _256b500e934c
from _1186208335d6 import _1186208335d6, _f9dd14b24d03
from _0a96376fc035 import _41e0c105f695
import _08ea5e8411cc
import _4366ea870d0c
from _8334b6aaccfc import _8334b6aaccfc
import _d057459f6047
import _b97343356da6
from _8f07b6719b82 import _921c2a950bed
import _8f07b6719b82
import _a69842f5bb79
import _23809abd3aac
import _4148e2b7d4ad
import _6943e100b2d9
import _74797f52a6cc
import _cc7e0ad9cb23
import _a7969ef7506e
import _c4f69ce3981d
import _1770c17e139a
import _201a68e2080f
import _5a35d020af63
import _aa14140beb3c
from _c7699694a397 import _3a71b333d82c
import _1b0e7c96e766
import _b09c9757a8d1 as _3d2478cefa43
from _0853d9205c0d import _f91e7d2112db
from _e99927b81ff8 import _2ac0680c832f, _85461d34776f, _dac4c19e2251, _39ad40787adc, _cfac945da278, _1be3108d8aa2
from _e5f0dfe05c2f import _16432fdc8350, _6cfd60ee3ed4
from _81681cbc1c95 import _a548b7480b67
import _fd0ea7864762._c242ed22bb83._f0ae53a4db9b
import _e1fe4c15050c
from _4dbb5a184883._5191525a00e7 import _5912394d39ea
import _ace2a706caca
_74831b78b1ff = _ace2a706caca._d6bc337f8215._b07c92d1cb91()
if _74831b78b1ff:
    import _84aeef4d54d5 as _5d8c8e5ca4ce
import _ace2a706caca._124d80fe051e
import _ace2a706caca._124d80fe051e._1969c0e63951
from _ace2a706caca._124d80fe051e._1969c0e63951 import _0353d8256b54, _17ce811856fa, _d9d22daa0935
from _ace2a706caca._124d80fe051e._1969c0e63951._f3a8b406cf22 import _a2ef6498468b
from _ace2a706caca._124d80fe051e._1969c0e63951._f3a8b406cf22 import _ff27a6bf07fe
import _aca99323ac47 as _0e7eeab5dc97
import _40b7e4fbd9e0 as _643cd9bc8658
from _d5215640ebfd import _17b471958b21, _e472e0fe73b5, _d3f47f87cc8b, _7d74929bfda2, _67ce5e167eb6
from _d5215640ebfd import _24f75e440bb9
import _fd0ea7864762
from _fd0ea7864762._d825ead81c84 import _1048d1288d4c
from _ace2a706caca import _12d05e65bbc5, _88fafe2ba859
from _aca99323ac47 import _2d38af67cf82
from _aca99323ac47._4ad3239429f6 import _4e333803700f
from _7e891102391c import _eeb4e14121e3, _e4cccdcb16f5, _91d144ff40ca
from _7e891102391c import _f944cff4c316, _108107220d41
from _aca99323ac47._4ad3239429f6._7f0e77f134b1 import _05d62f5fd53c
from _ace2a706caca._124d80fe051e._1969c0e63951 import _099811d3f5e8
from _ace2a706caca._124d80fe051e._1969c0e63951 import _dcb010a44c07, _f2aed90c720c
from _ace2a706caca._124d80fe051e._1969c0e63951._333890683e27 import _368b4ddcc9ba
from _ace2a706caca._005ab0219f8a import _75fba1adce9b
from _aca99323ac47._4ad3239429f6._3dd9118dadbc._3f2642178d14 import _c7cc1909b691
from _259fe1417707._e2011283e6c9._c23235e9a6f6._39415fe84c65 import _3e141387e9a3
from _259fe1417707._e2011283e6c9._c23235e9a6f6._6ccf34c9ef81 import _08bdbf32b755


# Helper functions/classes extracted from original module
# class CustomFSDPStrategy(FSDPStrategy):
#     def __init__(self, ig_params, ig_modules=None):
#         super().__init__(sharding_strategy="FULL_SHARD",
#                          cpu_offload=CPUOffload(offload_params=False),  # Explicit CPU offload  # Move non-trainable parameters to CPU
#                         #  mixed_precision=MixedPrecision(param_dtype=torch.float16,   # Use bfloat16 for parameters
#                         #                                 reduce_dtype=torch.float16,   # Keep reduction in float32 for stability
#                         #                                 buffer_dtype=torch.float16,  # Buffers in bfloat16
#                         #                                 ),
#                          auto_wrap_policy="TRANSFORMER_BASED_WRAP",  # Auto-wrap transformer layers
#                         #  auto_wrap_policy=transformer_auto_wrap_policy,
#                         #  auto_wrap_policy=custom_wrap_policy(min_num_params=100_000),
#                         #  state_dict_type="sharded" if torch.cuda.device_count() > 1 else "full",
#                         **{"static_graph": False, # Lightning optimization hint
#                            "forward_prefetch": False # Helps overlap compute/comm
#                         }
#                         )
#         # self.cpu_offload = False
#         # fsdp_args = {"use_orig_params": True, "ignored_parameters": ig_params}
#         # fsdp_args = {"use_orig_params": True, "ignored_states": ig_params}
#         fsdp_args = {
#             "use_orig_params": True,  # Maintain original parameter references
#             "ignored_states": ig_params,  # Ignore specific states (if defined)
#         }
#         if ig_modules:
#             fsdp_args.update({"ignored_modules": ig_modules})
#         self.kwargs = fsdp_args
# # class CustomFSDPStrategy(FSDPStrategy):
# #     def __init__(self, ig_params, ig_modules=None):
# #         super().__init__(
# #             sharding_strategy="FULL_SHARD",
# #             cpu_offload=None,  # Turn CPU offload OFF for speed on PCIe
# #             mixed_precision=MixedPrecision(
# #                 param_dtype=torch.bfloat16,
# #                 reduce_dtype=torch.bfloat16,
# #                 buffer_dtype=torch.bfloat16,
# #             ),
# #             auto_wrap_policy="TRANSFORMER_BASED_WRAP",
# #             forward_prefetch=True,  # Overlap comm and compute
# #         )
# #         fsdp_args = {
# #             "use_orig_params": True,
# #             "ignored_states": ig_params,
# #         }
# #         if ig_modules:
# #             fsdp_args["ignored_modules"] = ig_modules
# #         self.kwargs = fsdp_args

#     @property
#     def lightning_restore_optimizer(self) -> bool:
#         """Override to disable Lightning restoring optimizers/schedulers.

#         This is useful for plugins which manage restoring optimizers/schedulers.
#         """
#         return False

#     def lightning_module_state_dict(self) -> Dict[str, Any]:
#         assert self.model is not None

#         with FullyShardedDataParallel.state_dict_type(
#                 module=self.model,
#                 state_dict_type=StateDictType.FULL_STATE_DICT,
#                 state_dict_config=FullStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#                 optim_state_dict_config=FullOptimStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#         ):
#             # state_dict = self.model.state_dict()
#             state_dict = OrderedDict([(k.replace("_forward_module.",""), v) if k.__contains__('_forward_module') else (k, v)
#                                       for k, v in self.model.state_dict().items()])

#             # for key in state_dict:
#             #     print(f"state dict {key} :: {state_dict[key].shape}")
#             return state_dict

#     def setup_module(self, module: torch.nn.Module) -> torch.nn.Module:
#         """Override setup to ensure reshard_after_forward is set for all FSDP-wrapped submodules."""
#         module = super().setup_module(module)

#         for m in module.modules():
#             if isinstance(m, FullyShardedDataParallel):
#                 m._reshard_after_forward = True
#                 m._use_sharded_views = False  # optional, helps release memory immediately

#         return module

#     def optimizer_state(self, optimizer: Optimizer) -> Dict[str, Tensor]:
#         # old return FullyShardedDataParallel.full_optim_state_dict(self.model, optim=optimizer, rank0_only=True)
#         """ Manually gathers the full optimizer state across all ranks in FullyShardedDataParallel. """
#         # Get local (sharded) optimizer state using FullyShardedDataParallel
#         optim_state = FullyShardedDataParallel.optim_state_dict(self.model, optim=optimizer)

#         if torch.distributed.is_initialized():
#             # Gather optimizer states from all ranks
#             full_optim_state = [None] * torch.distributed.get_world_size()
#             torch.distributed.all_gather_object(full_optim_state, optim_state)

#             if torch.distributed.get_rank() == 0:
#                 # Merge optimizer states into a full dictionary
#                 merged_state = {"state": {}, "param_groups": full_optim_state[0]["param_groups"]}

#                 for state in full_optim_state:
#                     for param_id, param_state in state["state"].items():
#                         if param_id not in merged_state["state"]:
#                             merged_state["state"][param_id] = param_state
#                         else:
#                             # Merge optimizer state parameters (e.g., momentum buffers)
#                             for key in param_state:
#                                 if isinstance(param_state[key], list):
#                                     merged_state["state"][param_id][key].extend(param_state[key])
#                                 else:
#                                     merged_state["state"][param_id][key] = param_state[key]  # Overwrite

#                 return merged_state  # Full optimizer state for checkpointing
#             else:
#                 return {}  # Empty dictionary for non-rank 0
#         else:
#             return optim_state  # Single-process training, return directly


class _7fdf1ec656f3(_05d62f5fd53c):
    """
    Unified FSDP strategy for BERT-family and LLaMA-family models.
    Skips FSDP wrapping of BNB 4bit/8bit layers to avoid FP32 shard bloat.
    """

    def _cc63f452f50b(self, _be74e58504d2=_a51422e3e83d, _c998cbd0e15b=_a51422e3e83d, _bdc07f2f8c6a: _2c502e56ef05 = "", _34109ff92eac: _659c33195fae = _877c64c361ea):
        from _ace2a706caca._124d80fe051e._1969c0e63951._f3a8b406cf22 import _a2ef6498468b
        from _0a96376fc035 import _41e0c105f695

        # --- Detect model family ---
        _b3e1609e5331 = _bdc07f2f8c6a._5d6fc1f32287()
        if _523e6ff8f33f(_d84358105a73 in _b3e1609e5331 for _d84358105a73 in ["llama", "mistral"]):
            try:
                from _7e891102391c._f0cfb097b073._ecae338da053._080eab60bdb4 import _326dc8c9608f
                from _7e891102391c._f0cfb097b073._1051433dc480._9cfb7108531c import _59b0b53e1e69
                _bb800d77e799 = (_326dc8c9608f, _59b0b53e1e69)
            except _d2cc34cc5f93:
                _bb800d77e799 = ()
        else:
            try:
                from _7e891102391c._f0cfb097b073._43c689194552._ad50bd6c59f1 import _c400f372c085
                from _7e891102391c._f0cfb097b073._ec165a3fd863._214adfdc251c import _96e5d26c6703
                from _7e891102391c._f0cfb097b073._ecc3bce46fdc._19b2fbd71251 import _914913fbdec6
                from _7e891102391c._f0cfb097b073._d55639c1ffca._899f6b993f70 import _8108e53e5da4
                from _7e891102391c._f0cfb097b073._f2436b822d0a._154526d01671 import _71144bfa7a83 as _da2b48c92cf2
                _bb800d77e799 = (_c400f372c085, _96e5d26c6703, _914913fbdec6, _8108e53e5da4, _da2b48c92cf2)
            except _d2cc34cc5f93:
                _bb800d77e799 = ()

        # # --- Auto-wrap policy ---
        # if not layer_cls:
        #     print(f"[WARN] Could not infer transformer layer class for {model_name}. FSDP will wrap nothing.")
        #     auto_wrap_policy = None
        # else:
        #     auto_wrap_policy = partial(transformer_auto_wrap_policy, transformer_layer_cls=layer_cls)

        # # --- Skip BNB 4bit/8bit layers from FSDP wrapping ---
        # if auto_wrap_policy is not None:
        #     try:
        #         from bitsandbytes.nn import Linear4bit, Linear8bitLt
        #         def _bnb_filter(module):
        #             return not isinstance(module, (Linear4bit, Linear8bitLt))
        #         original_policy = auto_wrap_policy
        #         auto_wrap_policy = lambda m: original_policy(m) and _bnb_filter(m)
        #     except Exception as e:
        #         print(f"[WARN] Could not import BNB layers for FSDP filter: {e}")
    
        def _4063421129ad(_f00dd644316b):
            return _f00dd644316b._eb13d7c58830 if _7a2ba19040bc(_f00dd644316b, "module") else _f00dd644316b

        if not _bb800d77e799:
            _dff18d813a05(f"[WARN] Could not infer transformer layer class for {_bdc07f2f8c6a}. FSDP will wrap nothing.")
            _87df33b938a6 = _a51422e3e83d
        else:
            # base policy: match actual transformer layers
            def _60d7055bf150(_f00dd644316b):
                _79e09e85ba7e = _de8deeb1262b(_f00dd644316b)
                return _f716567cce9b(_79e09e85ba7e, _bb800d77e799)

            # add BNB skip
            try:
                from _84aeef4d54d5._e8f7c0dca7e6 import _da0aac4aab5b, _832a8a332c4a

                def _d1fc76bdcc07(_f00dd644316b):
                    _79e09e85ba7e = _de8deeb1262b(_f00dd644316b)
                    return not _f716567cce9b(_79e09e85ba7e, (_da0aac4aab5b, _832a8a332c4a))
            except _d2cc34cc5f93:
                def _d1fc76bdcc07(_f00dd644316b):
                    return _a0e6a52e6576

            # final combined policy
            def _839e367503fc(_f00dd644316b):
                return _41dfc68136d3(_f00dd644316b) and _588a8b273b77(_f00dd644316b)

        _3ecbcd0e9dcd()._8dd52e165eb6(
            # sharding_strategy="FULL_SHARD" if is_training else "NO_SHARD", # NO_SHARD DECPRICATED
            _718f1bd994ce="FULL_SHARD",
            _071fbde93164=_0353d8256b54(_6ba58e789a56=_a0e6a52e6576) if _34109ff92eac else _877c64c361ea,
            _87df33b938a6=_87df33b938a6,
            _00a2d37e1d7b=_a0e6a52e6576,
            _d66568b1bafc=_877c64c361ea,  # Safe for dynamic LoRA + quantized
        )

        # FSDP kwargs
        _3f69d92ccb59 = {
            "use_orig_params": _a0e6a52e6576,
            "ignored_states": _be74e58504d2,
        }
        if _c998cbd0e15b:
            _3f69d92ccb59["ignored_modules"] = _c998cbd0e15b
        self._5defdaa1ed4f = _3f69d92ccb59

    @_18120453b5ac
    def _10f6ee243703(self) -> _659c33195fae:
        return _877c64c361ea

    def _913daa516810(self, _eb13d7c58830: _ace2a706caca._e8f7c0dca7e6._368e53f0c577) -> _ace2a706caca._e8f7c0dca7e6._368e53f0c577:
        _eb13d7c58830 = _3ecbcd0e9dcd()._c59f257bfd16(_eb13d7c58830)
        for _5bdd15e4f103 in _eb13d7c58830._e2342c9e6f2e():
            if _f716567cce9b(_5bdd15e4f103, _099811d3f5e8):
                _5bdd15e4f103._4f4343eacdd4 = _a0e6a52e6576
                _5bdd15e4f103._c330b4f5a183 = _877c64c361ea
        return _eb13d7c58830

    def _a3d67478ebaf(self) -> _85461d34776f[_2c502e56ef05, _2ac0680c832f]:
        assert self._ea3c84952bcb is not _a51422e3e83d
        with _099811d3f5e8._b41833512a68(
            _eb13d7c58830=self._ea3c84952bcb,
            _b41833512a68=_dcb010a44c07._e29693793f2f,
            _d860f46c22be=_f2aed90c720c(_29095617f5a6=(self._91f56235a767 > 1), _73eef72163da=_a0e6a52e6576),
            _0d7caeb36948=_368b4ddcc9ba(_29095617f5a6=(self._91f56235a767 > 1), _73eef72163da=_a0e6a52e6576),
        ):
            _4000ad160b88 = _3a71b333d82c([
                (_32a9fbcd9273._385a463f2e8f("_forward_module.", ""), _bd9b55510a53) if "_forward_module" in _32a9fbcd9273 else (_32a9fbcd9273, _bd9b55510a53)
                for _32a9fbcd9273, _bd9b55510a53 in self._ea3c84952bcb._4000ad160b88()._dc53f2774594()
            ])
            return _4000ad160b88

    def _11d97c4234f7(self, _350a5657ceb4: _75fba1adce9b) -> _85461d34776f[_2c502e56ef05, _ace2a706caca._12d05e65bbc5]:
        _9f616c2a6fa7 = _099811d3f5e8._4a658a4f6b8c(self._ea3c84952bcb, _005ab0219f8a=_350a5657ceb4)
        if _ace2a706caca._124d80fe051e._93e2d6ba7d05():
            _29c48ff13de5 = [_a51422e3e83d] * _ace2a706caca._124d80fe051e._18c4037bb49a()
            _ace2a706caca._124d80fe051e._c0de9a4dff81(_29c48ff13de5, _9f616c2a6fa7)
            if _ace2a706caca._124d80fe051e._61aca550e7d4() == 0:
                _1395a830acfe = {"state": {}, "param_groups": _29c48ff13de5[0]["param_groups"]}
                for _8833cb242f55 in _29c48ff13de5:
                    for _e73f059cea8e, _2a3483b04cec in _8833cb242f55["state"]._dc53f2774594():
                        if _e73f059cea8e not in _1395a830acfe["state"]:
                            _1395a830acfe["state"][_e73f059cea8e] = _2a3483b04cec
                        else:
                            for _32a9fbcd9273, _bd9b55510a53 in _2a3483b04cec._dc53f2774594():
                                if _f716567cce9b(_bd9b55510a53, _9cbc177b34f0):
                                    _1395a830acfe["state"][_e73f059cea8e][_32a9fbcd9273]._152559fede60(_bd9b55510a53)
                                else:
                                    _1395a830acfe["state"][_e73f059cea8e][_32a9fbcd9273] = _bd9b55510a53
                return _1395a830acfe
            else:
                return {}
        else:
            return _9f616c2a6fa7
        
class _726f6dfe9f51(_0e7eeab5dc97._ae6a35cffd4a):
    """Lightning callback that writes trial number to trainer.callback_metrics.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance.

    Behavior:
        On training start it will attempt to add a "trial_number" entry to the
        trainer.callback_metrics mapping. This is best-effort and will not raise
        if metrics are not writable.
    """

    def _cc63f452f50b(self, _d825ead81c84: _fd0ea7864762._d825ead81c84._27a6e8ada1d1):
        self._d825ead81c84 = _d825ead81c84

    def _98e041c96534(self, _b7fa458350ed: _0e7eeab5dc97._2d38af67cf82, _5e5a0982142e: _0e7eeab5dc97._dad5b8138e49):
        # Add custom key-value pair
        _b7fa458350ed._467e373bd0e9["trial_number"] = _88fafe2ba859(self._d825ead81c84._bd6e22e8b8b7)


class _57677943e284(_0e7eeab5dc97._ae6a35cffd4a):
    """Callback that monitors GPU usage and prunes an Optuna trial when usage is high.

    Args:
        trial (optuna.trial.Trial): Optuna trial object to prune.
        threshold (float): Fraction of GPU memory usage above which pruning should occur.

    Notes:
        - This callback is conservative: if CUDA is not available it is a no-op.
        - In distributed training it uses a broadcast so all ranks agree.
    """

    def _cc63f452f50b(self, _d825ead81c84, _82e30c45351c=0.90):
        """
        Args:
            trial (optuna.trial.Trial): Optuna trial object to prune.
            threshold (float): Fraction of GPU memory usage to trigger pruning.
        """
        self._d825ead81c84 = _d825ead81c84
        self._82e30c45351c = _82e30c45351c

    def _bd38a3d4539c(self, _b7fa458350ed):
        """Return True if GPU reserved memory fraction >= threshold.

        Args:
            trainer: Lightning trainer object. Required for `is_global_zero` check.

        Returns:
            bool: True if usage >= threshold, False otherwise.

        Raises:
            None
        """
        # Only rank 0 checks and decides
        if not _ace2a706caca._d6bc337f8215._b07c92d1cb91():
            return _877c64c361ea

        if _b7fa458350ed._929bcbd7ba34:
            for _8534adb02bf7 in _a94f5b4f7eb5(_ace2a706caca._d6bc337f8215._b295ec9cd8cf()):
                _e2dd2a46f849 = _ace2a706caca._d6bc337f8215._1772f555e229(_8534adb02bf7)._15a1ab13599d
                _b6c3d5f38f6e = _ace2a706caca._d6bc337f8215._021faa1bb187(_8534adb02bf7)
                _ad47de1ae47a = _b6c3d5f38f6e / _e2dd2a46f849

                if _ad47de1ae47a >= self._82e30c45351c:
                    _dff18d813a05(f"[GPU Monitor] GPU {_8534adb02bf7} usage excceded: {_ad47de1ae47a*100:.1f}%")
                    return _a0e6a52e6576
        return _877c64c361ea

    def _836eab96f3c8(self, _70d14c33246d):
        """Broadcast the boolean prune decision to all ranks.

        Args:
            flag (bool): Local prune decision.

        Returns:
            bool: Agreed prune decision across ranks.

        Raises:
            RuntimeError: If CUDA is expected but not available on broadcast.
        """
        if not _ace2a706caca._d6bc337f8215._b07c92d1cb91():
            # Nothing to broadcast; return local decision
            return _70d14c33246d
        _a54dc7e1a591 = _ace2a706caca._88fafe2ba859([_3b9c6678cf1b(_70d14c33246d)], _c0e71180ad2e='cuda')
        if _ace2a706caca._124d80fe051e._93e2d6ba7d05():
            _ace2a706caca._124d80fe051e._807cfee6e751(_a54dc7e1a591, _899bbff391bd=0)
        return _a54dc7e1a591._c077551a82a2() == 1

    def _dc1ddc6fdbf4(self, _b7fa458350ed, _5e5a0982142e, _b99f0393fd3c, _c92db4b1a22e, _7476070e010e=0):
        """Lightning hook executed at start of each training batch.

        Raises:
            optuna.TrialPruned: when GPU usage threshold is exceeded.
        """
        if not _74831b78b1ff:
            return  # for cpu alone
        _1adf651390bb = self._4d9b53996f9e(_b7fa458350ed)
        # Broadcast decision so all ranks agree
        _1adf651390bb = self._f935c6d82880(_1adf651390bb)

        if _1adf651390bb:
            if _b7fa458350ed._929bcbd7ba34:
                _dff18d813a05("[GPUUsagePruneCallback] GPU memory exceeded threshold. Pruning trial.")
            raise _fd0ea7864762._f1dd47623508("GPU memory exceeded threshold")


def _b7a5e1f3c0de() -> _3b9c6678cf1b:
    """Compute local GPU rank based on environment variables.

    The function inspects `CUDA_VISIBLE_DEVICES`, `LOCAL_RANK` and `RANK` and
    returns an integer representing the local GPU index.

    Returns:
        int: local GPU rank (0-based). Returns -1 when CUDA is not available.

    Raises:
        ValueError: if computed local_rank is out of bounds for visible GPUs.
    """
    if not _ace2a706caca._d6bc337f8215._b07c92d1cb91():
        _dff18d813a05("[adjust_local_gpu_rank] CUDA not available, using CPU (-1)", _ed4db36f971a=_a0e6a52e6576)
        return -1  # CPU fallback

    _48e923bf1eb2 = _1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1("CUDA_VISIBLE_DEVICES", "")
    if _48e923bf1eb2 == "":
        # No filtering: all GPUs visible
        _09191552d833 = [_2c502e56ef05(_a4fca43e2598) for _a4fca43e2598 in _a94f5b4f7eb5(_ace2a706caca._d6bc337f8215._b295ec9cd8cf())]
    else:
        # For MIG UUIDs or indices, keep as string list (don't cast to int)
        _09191552d833 = [_d84358105a73._3a1f1beecd95() for _d84358105a73 in _48e923bf1eb2._925ca7f915b1(",") if _d84358105a73._3a1f1beecd95() != ""]

    _eafcdfa8ed7c = _1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1("LOCAL_RANK")
    _14b75fc03027 = _1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1("RANK")

    if _eafcdfa8ed7c is not _a51422e3e83d:
        _c2c4fcdd995c = _3b9c6678cf1b(_eafcdfa8ed7c)
        _dff18d813a05(f"[adjust_local_gpu_rank] Using LOCAL_RANK={_c2c4fcdd995c}", _ed4db36f971a=_a0e6a52e6576)
    elif _14b75fc03027 is not _a51422e3e83d:
        _c2c4fcdd995c = _3b9c6678cf1b(_14b75fc03027)
        _dff18d813a05(f"[adjust_local_gpu_rank] LOCAL_RANK not set, using RANK={_c2c4fcdd995c}", _ed4db36f971a=_a0e6a52e6576)
    else:
        _c2c4fcdd995c = 0
        _dff18d813a05("[adjust_local_gpu_rank] LOCAL_RANK and RANK not set, defaulting to 0", _ed4db36f971a=_a0e6a52e6576)

    if _c2c4fcdd995c >= _098ff4aa9e03(_09191552d833):
        raise _2cbaed531abc(
            f"[adjust_local_gpu_rank] local_rank ({_c2c4fcdd995c}) >= number of visible GPUs ({_098ff4aa9e03(_09191552d833)}).")

    # Returning integer index for compatibility with how calling code uses it.
    _d1ca46782f63 = _c2c4fcdd995c
    _dff18d813a05(f"[adjust_local_gpu_rank] CUDA_VISIBLE_DEVICES={_09191552d833}, selected device={_d1ca46782f63}", _ed4db36f971a=_a0e6a52e6576)

    return _d1ca46782f63


def _6184e53d103a() -> _9f1b04ce9db9:
    """Collect basic device and host information for logging.

    Returns:
        dict: keys include 'gpu_world_size', 'gpu_global_rank', 'gpu_local_rank',
              'node_name', and 'cpu_info'.

    Notes:
        - If CUDA is unavailable and SLURM is not detected, gpu_* keys are populated with -1.
    """
    _ea4e6c01b4f1 = _9f1b04ce9db9()
    if _ace2a706caca._d6bc337f8215._b07c92d1cb91():
        _ea4e6c01b4f1['gpu_world_size'] = _2c502e56ef05(_1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1('WORLD_SIZE', '1'))  # get WORLD_SIZE or set default 1
        _ea4e6c01b4f1['gpu_global_rank'] = _2c502e56ef05(_1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1('RANK', '0'))
        _ea4e6c01b4f1['gpu_local_rank'] = _2c502e56ef05(_8687afc34ea0())
    elif _c7cc1909b691._d2488f90d7f2() and _ace2a706caca._d6bc337f8215._b07c92d1cb91() is _877c64c361ea:
        _ea4e6c01b4f1['gpu_world_size'] = _2c502e56ef05(_c7cc1909b691._91f56235a767(_0e7eeab5dc97))
        _ea4e6c01b4f1['gpu_global_rank'] = _2c502e56ef05(_c7cc1909b691._90e9edb90915(_0e7eeab5dc97))
        _ea4e6c01b4f1['gpu_local_rank'] = -1
    else:
        _ea4e6c01b4f1['gpu_world_size'] = -1
        _ea4e6c01b4f1['gpu_global_rank'] = -1
        _ea4e6c01b4f1['gpu_local_rank'] = -1
    _ea4e6c01b4f1['node_name'] = _74797f52a6cc._556042667518()
    try:
        _ea4e6c01b4f1['cpu_info'] = "CPU :: {} COUNT :: {}"._356a64b340d3(_5a35d020af63._9afd76b38146()['brand_raw'], _1b0e7c96e766._8db35719f61a())
    except _d2cc34cc5f93:
        _ea4e6c01b4f1['cpu_info'] = f"CPU COUNT :: {_1b0e7c96e766._8db35719f61a()}"
    return _ea4e6c01b4f1


def _bd1bfddbfb55(_6c32d33acac5: _2c502e56ef05, _377ccd1bb83d: _2c502e56ef05, _2f287bd6bcdf: _921c2a950bed):
    """Remove all files in a directory except a single filename to keep.

    Args:
        directory (str): Directory to clean.
        file_to_keep (str): Basename of file to retain.
        log (Logger): Logger instance for informational messages.

    Raises:
        FileNotFoundError: If `directory` does not exist.
        PermissionError: If file removal fails due to permissions (propagates underlying OSError).
    """
    if not _1b0e7c96e766._060fab3cdbe0._bd17c815cd2b(_6c32d33acac5):
        raise _95d0acb31331(f"Directory not found: {_6c32d33acac5}")

    for _b08d2f83bf1e in _1b0e7c96e766._51e297612ee0(_6c32d33acac5):
        _c50fe8d6442c = _1b0e7c96e766._060fab3cdbe0._d5744f9fa356(_6c32d33acac5, _b08d2f83bf1e)
        if _1b0e7c96e766._060fab3cdbe0._e6617454294c(_c50fe8d6442c) and _b08d2f83bf1e != _377ccd1bb83d:
            _2f287bd6bcdf._98a0d26c3dbe(f"Removing checkpoint: {_c50fe8d6442c}")
            _1b0e7c96e766._1de650fb4dea(_c50fe8d6442c)


def _4f153ae8ac60(_2f287bd6bcdf: _921c2a950bed, _6fe9c3d33f0a: _2c502e56ef05, _7b02c53e795d: _fd0ea7864762._216e21c349bf, _d825ead81c84: _fd0ea7864762._d825ead81c84._27a6e8ada1d1):
    """Clear outdated checkpoint directories for the given model config.

    Args:
        log (Logger): Logger instance.
        model_config_name (str): Model configuration name used to build checkpoint root path.
        study (optuna.Study): Optuna study object (kept in signature for compatibility).
        trial (optuna.trial.Trial): Current trial; its number is preserved.

    Notes:
        - This function removes directories for older trials (non-current).
        - It will not raise if directories are missing; failures to remove are logged.
    """
    _df207650d426 = f"checkpoints/{_6fe9c3d33f0a}/trial_{_d825ead81c84._bd6e22e8b8b7}"
    _ad4cf0b534c0 = f"{_df207650d426}/last-v{_d825ead81c84._bd6e22e8b8b7}.ckpt"

    # If the directory is empty, we can remove it
    if _1b0e7c96e766._060fab3cdbe0._bd17c815cd2b(_df207650d426):
        if not _1b0e7c96e766._51e297612ee0(_df207650d426):  # Check if empty
            try:
                _1b0e7c96e766._9b2ca6702688(_df207650d426)  # Remove only if empty
                _2f287bd6bcdf._98a0d26c3dbe(f"Removed empty directory: {_df207650d426}")
            except _d2cc34cc5f93:
                _2f287bd6bcdf._ac261d10a052(f"Failed to remove directory: {_df207650d426}")
        else:
            # Check if the directory does not belong to the current trial and remove it
            _0d03472b749a = f"checkpoints/{_6fe9c3d33f0a}"
            if _1b0e7c96e766._060fab3cdbe0._bd17c815cd2b(_0d03472b749a):
                _f4ea1115968a = _1b0e7c96e766._51e297612ee0(_0d03472b749a)
                for _4eb30b814dab in _f4ea1115968a:
                    _673612b417c8 = _4148e2b7d4ad._673612b417c8(r"trial_(\d+)", _4eb30b814dab)
                    if _673612b417c8:
                        _377c8097a38f = _3b9c6678cf1b(_673612b417c8._095474fd29d6(1))
                        if _377c8097a38f != _d825ead81c84._bd6e22e8b8b7:
                            _5b1068159a5d = f"{_0d03472b749a}/{_4eb30b814dab}"
                            if _1b0e7c96e766._060fab3cdbe0._bac5d0b6f5d6(_5b1068159a5d):
                                try:
                                    _2f287bd6bcdf._98a0d26c3dbe(f"Removing outdated trial directory: {_5b1068159a5d}")
                                    _6943e100b2d9._f39f8eff6f1a(_5b1068159a5d)
                                except _d2cc34cc5f93:
                                    _2f287bd6bcdf._ac261d10a052(f"Failed to remove dir {_5b1068159a5d}")


def _0624804e7bc7(_ea3c84952bcb, _72f1046aab49, _db79c36cda3d):
    """Load a checkpoint into the original (unwrapped) model when FSDP was used.

    Args:
        model: Original (unwrapped) model instance (kept for signature compatibility).
        fsdp_model: FSDP-wrapped model instance that contains `.module`.
        checkpoint_path (str): Path to checkpoint file.

    Returns:
        torch.nn.Module: original model with loaded state dict.

    Raises:
        FileNotFoundError: If the checkpoint file does not exist.
        AttributeError: If `fsdp_model` does not expose `.module`.
        RuntimeError: If loading state dict fails.
    """
    if not _1b0e7c96e766._060fab3cdbe0._bac5d0b6f5d6(_db79c36cda3d):
        raise _95d0acb31331(f"Checkpoint not found: {_db79c36cda3d}")

    # Access the original model (best-effort)
    if not _7a2ba19040bc(_72f1046aab49, "module"):
        raise _8d90e30f2c94("fsdp_model does not expose .module (not an FSDP-wrapped model)")

    _36ba70bf56cf = _72f1046aab49._eb13d7c58830

    # Load the checkpoint
    _8a4c9c5b6bff = _ace2a706caca._30756009ae2b(_db79c36cda3d)

    # Attempt to load state dict into original model
    try:
        # Note: original script used FSDP full-state helpers; preserve call but guard errors
        with _ace2a706caca._124d80fe051e._1969c0e63951._f2aed90c720c(_72f1046aab49):
            _36ba70bf56cf._c3c6cac3dda6(_8a4c9c5b6bff, _627e31399755=_a0e6a52e6576)
    except _d2cc34cc5f93:
        # Try fallback strict=False
        try:
            _36ba70bf56cf._c3c6cac3dda6(_8a4c9c5b6bff, _627e31399755=_877c64c361ea)
        except _d2cc34cc5f93 as _994b1eb9a3c6:
            raise _d11b6c62ad94(f"Failed to load checkpoint into original model: {_994b1eb9a3c6}") from _994b1eb9a3c6
    return _36ba70bf56cf

# def dequantize_bnb_model(model):
#     """
#     Replace bitsandbytes quantized linear layers in a model with standard torch.nn.Linear layers.

#     This function traverses the given model and converts all quantized linear
#     layers (Linear4bit, Linear8bitLt) into torch.nn.Linear equivalents with
#     dequantized float32 weights and bias. The conversion is done in-place.

#     Args:
#         model (torch.nn.Module):
#             Model instance that may contain bitsandbytes quantized linear layers.

#     Returns:
#         torch.nn.Module:
#             The same model with quantized linear layers replaced by dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If layer weights or bias cannot be converted to float32 or fail to copy into a new layer.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for module in list(model.modules()):
#         for name, child in list(module.named_children()):
#             if getattr(child, "_is_dequantized", False):
#                 continue
#             if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#                 try:
#                     try:
#                         w = child.weight.dequantize()
#                     except Exception:
#                         w = child.weight.data.to(torch.float32)
#                     b = None
#                     if getattr(child, "bias", None) is not None:
#                         b = child.bias.data.to(torch.float32)
#                     out_f, in_f = w.shape
#                     new_linear = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                     new_linear.weight.data.copy_(w)
#                     if b is not None:
#                         new_linear.bias.data.copy_(b)
#                     new_linear._is_dequantized = True
#                     setattr(module, name, new_linear)
#                 except Exception as e:
#                     raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#     return model


# def manual_dequantize(module):
#     """
#     Recursively replace bitsandbytes quantized linear layers in a module with torch.nn.Linear layers.

#     This function walks all children of the given module recursively and converts
#     quantized linear layers (Linear4bit, Linear8bitLt) to standard torch.nn.Linear
#     layers containing float32 weights and bias. Layers already marked as
#     dequantized are skipped.

#     Args:
#         module (torch.nn.Module):
#             Root module or submodule to process recursively.

#     Returns:
#         torch.nn.Module:
#             The same module with all quantized linear layers replaced by
#             dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If a quantized layer fails to convert or copy its weights to float32.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for name, child in list(module.named_children()):
#         if getattr(child, "_is_dequantized", False):
#             continue
#         if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#             try:
#                 try:
#                     w = child.weight.dequantize()
#                 except Exception:
#                     w = child.weight.data.to(torch.float32)
#                 b = None
#                 if getattr(child, "bias", None) is not None:
#                     b = child.bias.data.to(torch.float32)
#                 out_f, in_f = w.shape
#                 new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                 new_layer.weight.data.copy_(w)
#                 if b is not None:
#                     new_layer.bias.data.copy_(b)
#                 new_layer._is_dequantized = True
#                 setattr(module, name, new_layer)
#             except Exception as e:
#                 raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#         else:
#             manual_dequantize(child)
#     return module

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32) — no CPU moves, preserves device, removes ALL quantized layers.
#     Works even under PEFT, _SafeModuleWrapper, PeftModel, LoraModel, etc.

#     Bulletproof: detection by class name, not isinstance.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",        # some bnb builds use this
#     }

#     # Traverse parents so we can do setattr
#     for parent in list(model.modules()):
#         # Use raw _modules dict so we replace correct child
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # Skip non-BnB quantized layers
#             if cls not in QUANT_CLASS_NAMES:
#                 # Check nested wrapper: _SafeModuleWrapper, etc.
#                 inner = getattr(child, "module", None)
#                 if inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                     child = inner
#                     cls = child.__class__.__name__
#                 else:
#                     continue

#             # --------------------------------------------------------
#             # At this point, child is DEFINITELY a quantized Linear*
#             # --------------------------------------------------------

#             # Device
#             try:
#                 device = next(child.parameters()).device
#             except StopIteration:
#                 device = torch.device("cpu")

#             # ---- read weight ----
#             if hasattr(child, "weight") and hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---- read bias ----
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---- infer dims ----
#             # out_f, in_f = w.shape
#             # If weight is 1-D (flattened), infer dims from child attributes
#             if w.dim() == 1:
#                 out_f = child.out_features
#                 in_f = child.in_features
#             else:
#                 out_f, in_f = w.shape

#             # ---- create replacement ----
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---- REPLACE ----
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32). Preserves device. Never reshapes incorrectly.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",
#     }

#     for parent in list(model.modules()):
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # ---------- WRAPPER DETECTION ----------
#             wrapper = child                     # always keep wrapper
#             inner = getattr(child, "module", None)
#             is_quant = False

#             # direct quantized
#             if cls in QUANT_CLASS_NAMES:
#                 is_quant = True

#             # wrapped quantized
#             elif inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                 is_quant = True
#                 child = inner                    # but we still use wrapper for dims

#             if not is_quant:
#                 continue

#             # ---------- DEVICE ----------
#             try:
#                 device = next(child.parameters()).device
#             except Exception:
#                 device = torch.device("cpu")

#             # ---------- READ WEIGHTS ----------
#             if hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---------- READ BIAS ----------
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---------- TRUE DIMENSIONS FROM WRAPPER ----------
#             in_f = getattr(wrapper, "in_features", None)
#             out_f = getattr(wrapper, "out_features", None)

#             if in_f is None or out_f is None:
#                 # fallback to weight dims only if both missing
#                 print(f"FALLING BACK shape {w.shape}")
#                 out_f, in_f = w.shape

#             # ---------- CREATE NEW LINEAR ----------
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---------- REPLACE ----------
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
#     Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
#     Leaves LoRA and trainable modules untouched.
#     Safe: skips missing weights or broken layers automatically.
#     """
#     modules = list(model.named_modules())[::-1]  # bottom-up traversal

#     for name, module in modules:
#         if isinstance(module, (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)):
#             try:
#                 in_features = getattr(module, "in_features", module.weight.shape[1])
#                 out_features = getattr(module, "out_features", module.weight.shape[0])
#                 module_device = next(module.parameters(), None).device if module is not None else torch.device('cpu')
#                 print(f"dequant {module} on {module_device}")
#                 dequantized = torch.nn.Linear(
#                     in_features, out_features,
#                     bias=module.bias is not None,
#                     dtype=torch.float32,
#                     device=module_device
#                 )

#                 if module.weight is None or not hasattr(module.weight, "data"):
#                     continue

#                 dequantized.weight.data = module.weight.to(torch.float32)
#                 if module.bias is not None:
#                     dequantized.bias.data.copy_(module.bias.data)

#                 # Replace in parent
#                 parent = model
#                 parts = name.split(".")
#                 for p in parts[:-1]:
#                     parent = getattr(parent, p)
#                 setattr(parent, parts[-1], dequantized)

#                 del module
#                 gc.collect()
#                 torch.cuda.empty_cache()

#             except Exception as e:
#                 print(f"[WARN] Skipped dequantizing {name}: {e}")

#     return model

def _0c899d86ff75(_ea3c84952bcb: _ace2a706caca._e8f7c0dca7e6._368e53f0c577) -> _ace2a706caca._e8f7c0dca7e6._368e53f0c577:
    _9cba7bc707db = 0
    for _cc0f685166d8, _eb13d7c58830 in _9cbc177b34f0(_ea3c84952bcb._2368a971a394()):
        if not _f716567cce9b(_eb13d7c58830, (_5d8c8e5ca4ce._e8f7c0dca7e6._da0aac4aab5b, _5d8c8e5ca4ce._e8f7c0dca7e6._832a8a332c4a)):
            continue

        # print(f"Dequantizing {name} | {module.__class__.__name__} -> torch.nn.Linear")

        try:
            # 1. Force full dequantization using bnb internals (works on every model)
            if _f716567cce9b(_eb13d7c58830, _5d8c8e5ca4ce._e8f7c0dca7e6._da0aac4aab5b):
                # Handles NF4/FP4 + grouped QKV perfectly
                _47ae49c4c53a = _5d8c8e5ca4ce._b6930cc87ada._f03b9e374554(
                    _eb13d7c58830._47ae49c4c53a._a578c949b393,
                    _eb13d7c58830._47ae49c4c53a._8dc51c017d80
                )._d39e22aa48bb(_d95f28470fbb())
            else:  # Linear8bitLt
                _47ae49c4c53a = _eb13d7c58830._47ae49c4c53a._a578c949b393._d39e22aa48bb(_d95f28470fbb())

            _a4718a108cd5 = _eb13d7c58830._a4718a108cd5._d39e22aa48bb(_d95f28470fbb()) if _eb13d7c58830._a4718a108cd5 is not _a51422e3e83d else _a51422e3e83d

            # 2. Create clean fp32 Linear with correct shapes
            _2e17f1e42f24 = _ace2a706caca._e8f7c0dca7e6._7780e4460f59(
                _867e6c8f3169=_eb13d7c58830._867e6c8f3169,
                _762a325b5a4a=_eb13d7c58830._762a325b5a4a,
                _a4718a108cd5=_a4718a108cd5 is not _a51422e3e83d,
                _c0e71180ad2e=_eb13d7c58830._47ae49c4c53a._a578c949b393._c0e71180ad2e,
                _6082d97556c6=_d95f28470fbb()
            )
            _2e17f1e42f24._47ae49c4c53a._a578c949b393._194a9a5a5dbc(_47ae49c4c53a)
            if _a4718a108cd5 is not _a51422e3e83d:
                _2e17f1e42f24._a4718a108cd5._a578c949b393._194a9a5a5dbc(_a4718a108cd5)

            # 3. Replace in parent (safe even with wrappers)
            _720cc12eeb8f = _9f1b04ce9db9(_ea3c84952bcb._2368a971a394())
            _6cd0cad2a151 = "."._d5744f9fa356(_cc0f685166d8._925ca7f915b1(".")[:-1])
            _2d6057f8c77b = _720cc12eeb8f[_6cd0cad2a151] if _6cd0cad2a151 else _ea3c84952bcb
            _1ec988e8f13f(_2d6057f8c77b, _cc0f685166d8._925ca7f915b1(".")[-1], _2e17f1e42f24)
            del _eb13d7c58830._47ae49c4c53a   # instantly frees the 4bit/8bit buffer
            _9cba7bc707db += 1

        except _d2cc34cc5f93 as _994b1eb9a3c6:
            _dff18d813a05(f"[FATAL] Failed on {_cc0f685166d8}: {_994b1eb9a3c6}")
            raise

    _dff18d813a05(f"Successfully dequantized {_9cba7bc707db} bnb layers")
    _4366ea870d0c._871e42a6e65e()
    if _ace2a706caca._d6bc337f8215._b07c92d1cb91():
        _ace2a706caca._d6bc337f8215._bd8c3501dd43()
    return _ea3c84952bcb

# def dequantize_bnb_model(model: torch.nn.Module) -> torch.nn.Module:
#     import torch
#     from bitsandbytes.nn import Linear4bit

#     for name, module in list(model.named_modules()):
#         if not isinstance(module, Linear4bit):
#             continue

#         # THIS IS THE KEY LINE FOR NEW BITSANDBYTES
#         if hasattr(module.weight, "quant_state"):
#             # New format: packed bits + quant_state
#             weight = module.weight.dequantize(module.weight.quant_state)
#         else:
#             # Old format (rare now)
#             weight = module.weight.dequantize()

#         bias = module.bias if module.bias is not None else None

#         linear = torch.nn.Linear(
#             module.in_features,
#             module.out_features,
#             bias=bias is not None,
#             device=module.weight.device,
#             dtype=torch.float32
#         )
#         linear.weight.data = weight.to(torch.float32)
#         if bias is not None:
#             linear.bias.data = bias.data.to(torch.float32)

#         # Replace
#         parent = model
#         for part in name.split(".")[:-1]:
#             parent = getattr(parent, part)
#         setattr(parent, name.split(".")[-1], linear)

#     return model

def _d83dfe1c0b08(_ea3c84952bcb):
    """
    Convert any remaining uint8 weights to fp32, in-place.
    No reshaping, no heuristics — only dtype fix.
    """
    import _ace2a706caca

    for _eb13d7c58830 in _ea3c84952bcb._e2342c9e6f2e():
        for _cc0f685166d8, _ddfb99252c2e in _eb13d7c58830._4ae136d00245(_cf36143dfd8a=_877c64c361ea):
            if _ddfb99252c2e._6082d97556c6 == _ace2a706caca._dbcd13c21826:
                _ddfb99252c2e._a578c949b393 = _ddfb99252c2e._a578c949b393._09c419466158()

    return _ea3c84952bcb


def _38032aae7e27(_ea3c84952bcb):
    """Return the number of trainable parameters in a model.

    Args:
        model (torch.nn.Module): Model to inspect.

    Returns:
        int: Count of trainable parameters.
    """
    _764cd2967355 = _21d99727e1de(_82d8bb4ce67f._407274d91620() for _82d8bb4ce67f in _ea3c84952bcb._6f71467b4bb4() if _82d8bb4ce67f._6d9835de8f6e)
    return _3b9c6678cf1b(_764cd2967355)  # Ensure this returns an integer


# def get_target_modules(model, attribute_filter=None, name_filter=None, custom_filter=None):
#     """Collect submodules of `model` that satisfy the provided filters.

#     Args:
#         model (nn.Module or LightningModule): The model to analyze.
#         attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
#         name_filter (callable, optional): Function(name) -> bool to filter by module name.
#         custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.

#     Returns:
#         dict: Mapping from module name to module instance for modules that matched filters.

#     Raises:
#         TypeError: If `model` does not implement `named_modules`.
#     """
#     if not hasattr(model, "named_modules"):
#         raise TypeError("Provided model does not implement named_modules()")

#     target_modules = {}
#     for name, module in model.named_modules():
#         # Exclude LayerNorm and other unsupported layers
#         if "Norm" in module.__class__.__name__:
#             continue

#         # Skip frozen layers (requires_grad=False)
#         try:
#             if not any(param.requires_grad for param in module.parameters()):
#                 continue  # Skip this module if all its parameters are frozen
#         except Exception:
#             # If module.parameters() raises, skip it as not applicable
#             continue

#         if (
#             (attribute_filter is None or attribute_filter(module)) and
#             (name_filter is None or name_filter(name)) and
#             (custom_filter is None or custom_filter(name, module))
#         ):
#             target_modules[name] = module  # Store the module in the dictionary with its name as key
#     return target_modules

def _60901d3ff9e1(_ea3c84952bcb, _25e06b0b2a94=_a51422e3e83d, _4e775ab55ce0=_a51422e3e83d, _57358f667ccf=_a51422e3e83d, _8b90e10af362="embedding"):
    """Collect submodules of `model` that satisfy the provided filters.

    - Keeps modules that expose a weight Tensor even when that weight is not a Parameter
      (this allows detecting bitsandbytes wrappers like Linear4bit/Linear8bit).
    - Skips normalization modules by class-name ("Norm").
    - If a module has actual torch.nn.Parameters and all are requires_grad==False, it is skipped.
    - Returns dict mapping full dotted module path (prefixed by `prefix` if provided) -> module.

    Args:
        model (nn.Module or LightningModule): The model to analyze.
        attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
        name_filter (callable, optional): Function(name) -> bool to filter by module name.
        custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.
        prefix (str, optional): Base name of model path (default: "embedding").

    Returns:
        dict: Mapping from *full dotted module path* to module instance for matched modules.

    Raises:
        TypeError: If `model` does not implement named_modules().
    """
    import _ace2a706caca

    if not _7a2ba19040bc(_ea3c84952bcb, "named_modules"):
        raise _670e477c800e("Provided model does not implement named_modules()")

    _7d4f234d0ff1 = {}
    for _cc0f685166d8, _eb13d7c58830 in _ea3c84952bcb._2368a971a394():
        # Exclude normalization layers (class name contains "Norm")
        if "Norm" in _eb13d7c58830._7ac3ff53863a.__name__:
            continue

        # Determine if module has torch.nn.Parameters
        _5d5c6ed8ea84 = _877c64c361ea
        _3c08d8dc6e86 = []
        try:
            _3c08d8dc6e86 = _9cbc177b34f0(_eb13d7c58830._6f71467b4bb4())
            _5d5c6ed8ea84 = _098ff4aa9e03(_3c08d8dc6e86) > 0
        except _d2cc34cc5f93:
            _5d5c6ed8ea84 = _877c64c361ea

        # If module has Parameters and none require grad -> skip (frozen)
        if _5d5c6ed8ea84:
            try:
                if not _523e6ff8f33f(_82d8bb4ce67f._6d9835de8f6e for _82d8bb4ce67f in _3c08d8dc6e86):
                    continue
            except _d2cc34cc5f93:
                # conservative: don't skip if we can't determine requires_grad
                pass

        # Allow modules that have a 'weight' attribute that's a Tensor (covers bnb wrappers)
        _980fdc314f89 = _877c64c361ea
        try:
            _5a8535a188cf = _a61b6f6798fd(_eb13d7c58830, "weight", _a51422e3e83d)
            if _f716567cce9b(_5a8535a188cf, _ace2a706caca._12d05e65bbc5):
                # accept even if it's not a Parameter
                _980fdc314f89 = _a0e6a52e6576
        except _d2cc34cc5f93:
            _980fdc314f89 = _877c64c361ea

        # Apply attribute/name/custom filters (attribute_filter should expect module)
        try:
            _07d7bc67b1c4 = (_25e06b0b2a94 is _a51422e3e83d) or _25e06b0b2a94(_eb13d7c58830)
        except _d2cc34cc5f93:
            _07d7bc67b1c4 = _877c64c361ea

        try:
            _f1a826985d05 = (_4e775ab55ce0 is _a51422e3e83d) or _4e775ab55ce0(_cc0f685166d8)
        except _d2cc34cc5f93:
            _f1a826985d05 = _877c64c361ea

        try:
            _daae909dc6ec = (_57358f667ccf is _a51422e3e83d) or _57358f667ccf(_cc0f685166d8, _eb13d7c58830)
        except _d2cc34cc5f93:
            _daae909dc6ec = _877c64c361ea

        # Decide acceptance:
        # - If attribute_filter/name_filter/custom_filter pass -> accept
        # - Otherwise, fall back to accepting if module has a weight tensor (bnb)
        if (_07d7bc67b1c4 and _f1a826985d05 and _daae909dc6ec) or (not _5d5c6ed8ea84 and _980fdc314f89):
            _f5cd6ee144f4 = f"{_8b90e10af362}.{_cc0f685166d8}" if _8b90e10af362 else _cc0f685166d8
            _7d4f234d0ff1[_f5cd6ee144f4] = _eb13d7c58830

    return _7d4f234d0ff1


def _a0c5fb9dae55():
    """Safely clears GPU and CPU memory without disrupting distributed processes.

    Notes:
        - Best-effort: this function will not raise on cleanup errors, but will print/log them.
        - Ensures a distributed barrier at the end if torch.distributed is initialized.
    """
    # Run garbage collection to free CPU memory.
    _4366ea870d0c._871e42a6e65e()

    if _ace2a706caca._d6bc337f8215._b07c92d1cb91():
        # Clear CUDA memory cache.
        try:
            _ace2a706caca._d6bc337f8215._bd8c3501dd43()
            _ace2a706caca._d6bc337f8215._2fa99e277d00()
        except _d2cc34cc5f93:
            # Some CUDA versions might not have ipc_collect
            pass

        # Ensure all pending CUDA operations are finished.
        try:
            _ace2a706caca._d6bc337f8215._c6bb6951be90()
        except _d2cc34cc5f93:
            pass

        # Print memory stats before reset (optional).
        try:
            _7539ef3c113f = _ace2a706caca._d6bc337f8215._021faa1bb187()
            _7f90a50a848d = _ace2a706caca._d6bc337f8215._e4a32189cf04()
            _dff18d813a05(f"Before reset: Reserved = {_7539ef3c113f}, Allocated = {_7f90a50a848d}")
        except _d2cc34cc5f93:
            pass

        # Reset memory tracking (useful for debugging).
        try:
            _ace2a706caca._d6bc337f8215._73846978b427()
        except _d2cc34cc5f93:
            pass

    # Print current process memory usage.
    try:
        _c200883051cb = _e1fe4c15050c._7a7fbe0d18c3(_1b0e7c96e766._2330ff21db98())
        _da01b5f13a4a = _c200883051cb._75c76bcdc779()
        _dff18d813a05(f"Cleared GPU and CPU memory. Current process memory usage: {_da01b5f13a4a._7ad1e6dbb0da / 1024**2:.2f} MB")
    except _d2cc34cc5f93:
        pass

    # Ensure all distributed processes are synchronized before proceeding.
    if _ace2a706caca._124d80fe051e._93e2d6ba7d05():
        try:
            _ace2a706caca._124d80fe051e._c76b3ee8b659()
        except _d2cc34cc5f93:
            pass


def _280a74e2c097(_ea3c84952bcb):
    """Calculate approximate model size in gigabytes.

    Args:
        model (torch.nn.Module): The model to analyze.

    Returns:
        float: Total size in GB accounting for unique parameters.

    Raises:
        TypeError: If model does not implement `.parameters()`.
    """
    if not _7a2ba19040bc(_ea3c84952bcb, "parameters"):
        raise _670e477c800e("Provided object is not a model with parameters()")

    _c10c3a53e1eb = 0  # Size in bytes
    _a8f76b35f005 = _663d262edbc9()  # Set to track counted parameters by their unique IDs

    # Recursive function to sum the size of parameters in all submodules
    def _09a47bf24d2e(_eb13d7c58830):
        nonlocal _c10c3a53e1eb
        for _ddfb99252c2e in _eb13d7c58830._6f71467b4bb4():
            _04883f0273c1 = _048453393e87(_ddfb99252c2e)  # Unique identifier for the parameter
            if _04883f0273c1 not in _a8f76b35f005:  # Ensure each parameter is counted only once
                _0e567fc70ec2 = _ddfb99252c2e._50c43409a482()  # Size of one element in bytes
                _c10c3a53e1eb += _ddfb99252c2e._407274d91620() * _0e567fc70ec2  # Total memory in bytes
                _a8f76b35f005._382480dbfbcf(_04883f0273c1)  # Mark parameter as counted

    # Loop through all submodules (including nested ones)
    try:
        _ea3c84952bcb._1f35f78440c6(lambda _eb13d7c58830: _7cdfebba05f4(_eb13d7c58830))
    except _d2cc34cc5f93:
        # Fallback: iterate parameters directly
        for _ddfb99252c2e in _ea3c84952bcb._6f71467b4bb4():
            _04883f0273c1 = _048453393e87(_ddfb99252c2e)
            if _04883f0273c1 not in _a8f76b35f005:
                _c10c3a53e1eb += _ddfb99252c2e._407274d91620() * _ddfb99252c2e._50c43409a482()
                _a8f76b35f005._382480dbfbcf(_04883f0273c1)

    _c264beecaa9f = _09c419466158(_c10c3a53e1eb) / (1024 ** 3)  # Convert to GB
    return _c264beecaa9f


def _17e2412543b8(_ea3c84952bcb: _0e7eeab5dc97._dad5b8138e49, _de9aedd3a4ed: _3b9c6678cf1b = 1):
    """Return a PrettyTable summary of the model architecture and parameter counts.

    Args:
        model (pl.LightningModule): Model to summarize.
        depth (int): How deep in module name hierarchy to report (default 1).

    Returns:
        str: Multi-line string summary. If PrettyTable is unavailable this will raise.

    Raises:
        TypeError: If model does not implement `named_modules`.
    """
    if not _7a2ba19040bc(_ea3c84952bcb, "named_modules"):
        raise _670e477c800e("Provided model does not implement named_modules()")

    _16fcc6c00780 = _f91e7d2112db()
    _16fcc6c00780._3c81142fdae5 = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

    _c25ae86a5c37 = 0
    _764cd2967355 = 0
    _f41ac1aaf716 = 0

    _7b29462e8d64 = _663d262edbc9()  # Track parameters to prevent duplicate counting

    def _b30841f4a5e8(_eb13d7c58830):
        """Helper function to count trainable/non-trainable parameters uniquely."""
        _3c08d8dc6e86 = _9cbc177b34f0(_eb13d7c58830._6f71467b4bb4())
        _0963cdfbb2be = [_82d8bb4ce67f for _82d8bb4ce67f in _3c08d8dc6e86 if _048453393e87(_82d8bb4ce67f) not in _7b29462e8d64]

        _7b29462e8d64._6939f942a324(_048453393e87(_82d8bb4ce67f) for _82d8bb4ce67f in _0963cdfbb2be)  # Mark parameters as counted

        _e2dd2a46f849 = _21d99727e1de(_82d8bb4ce67f._407274d91620() for _82d8bb4ce67f in _0963cdfbb2be)
        _bc91b3c52909 = _21d99727e1de(_82d8bb4ce67f._407274d91620() for _82d8bb4ce67f in _0963cdfbb2be if _82d8bb4ce67f._6d9835de8f6e)
        _cf40a6b23859 = _e2dd2a46f849 - _bc91b3c52909

        return _e2dd2a46f849, _bc91b3c52909, _cf40a6b23859

    for _cc0f685166d8, _eb13d7c58830 in _ea3c84952bcb._2368a971a394():
        if _cc0f685166d8 == "" or _cc0f685166d8._d31aad9d095e('.') >= _de9aedd3a4ed:  # Skip root module and limit depth
            continue

        _3c08d8dc6e86, _bc91b3c52909, _cf40a6b23859 = _dd6d67b224ff(_eb13d7c58830)

        if _3c08d8dc6e86 > 0:  # Only add layers with parameters
            _16fcc6c00780._f6927a4e443d([_cc0f685166d8, _eb13d7c58830._7ac3ff53863a.__name__, f"{_3c08d8dc6e86:,}", f"{_bc91b3c52909:,}", f"{_cf40a6b23859:,}"])

        _c25ae86a5c37 += _3c08d8dc6e86
        _764cd2967355 += _bc91b3c52909
        _f41ac1aaf716 += _cf40a6b23859

    _12bfb0f1feaa = _42fb5fbca552(_ea3c84952bcb)

    _47f210230fcf = "\n" + _16fcc6c00780._5b552911b985()
    _47f210230fcf += f"\nTotal params: {_c25ae86a5c37:,}\n"
    _47f210230fcf += f"Trainable params: {_764cd2967355:,}\n"
    _47f210230fcf += f"Non-Trainable params: {_f41ac1aaf716:,}\n"
    _47f210230fcf += f"Model size: {_12bfb0f1feaa:.2f} GB\n"

    return _47f210230fcf


def _97e79108596c(_8c7c99f56180):
    """Return a devices specification suitable for Lightning Trainer based on DEVICE.

    Args:
        DEVICE (str): 'gpu' or 'cpu'.

    Returns:
        int | list: devices argument for Trainer (e.g., 1, [0], list(range(n)) or -1 for distributed).

    Raises:
        ValueError: If DEVICE is unknown or LOCAL_RANK out of bounds.
    """
    if _8c7c99f56180 == "cpu":
        return 1

    if _8c7c99f56180 == "gpu":
        _c1c331880e67 = _1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1("CUDA_VISIBLE_DEVICES")
        _317977ae8717 = _ace2a706caca._124d80fe051e._b07c92d1cb91() and _ace2a706caca._124d80fe051e._93e2d6ba7d05()

        if _317977ae8717:
            return -1  # Let Lightning handle all

        # Inside non-distributed
        if _c1c331880e67:
            _30efdabf50f7 = [_3b9c6678cf1b(_d84358105a73._3a1f1beecd95()) for _d84358105a73 in _c1c331880e67._925ca7f915b1(",")]
            _eafcdfa8ed7c = _1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1('LOCAL_RANK') or _1b0e7c96e766._76d8ee8b1fbe._85a26a0fb3c1('RANK')

            if _eafcdfa8ed7c is not _a51422e3e83d:
                _c2c4fcdd995c = _3b9c6678cf1b(_eafcdfa8ed7c)
                if _c2c4fcdd995c >= _098ff4aa9e03(_30efdabf50f7):
                    raise _2cbaed531abc(f"LOCAL_RANK {_c2c4fcdd995c} out of bounds for visible GPUs {_30efdabf50f7}")
                return [_c2c4fcdd995c]  # single target

            # No rank set, fallback to all visible
            return _9cbc177b34f0(_a94f5b4f7eb5(_098ff4aa9e03(_30efdabf50f7)))
        else:
            # No CUDA_VISIBLE_DEVICES → use all available
            return _9cbc177b34f0(_a94f5b4f7eb5(_ace2a706caca._d6bc337f8215._b295ec9cd8cf()))

    raise _2cbaed531abc(f"Unknown DEVICE {_8c7c99f56180}")


def _f782e39c06c8():
    """Return the preferred compute dtype for current GPU capability.

    Returns:
        torch.dtype: Preferred compute dtype (torch.bfloat16, torch.float16, or torch.float32).
    """
    _8101b73834ff = _ace2a706caca._4ff5fa947cfb
    if _ace2a706caca._d6bc337f8215._b07c92d1cb91():
        try:
            _21a5c9dab735, _0fc8339f54a5 = _ace2a706caca._d6bc337f8215._dfbea8a28141()
            # Ampere (8.0+) supports bfloat16
            if _21a5c9dab735 >= 8:
                _8101b73834ff = _ace2a706caca._1483f4cd6ab4
            else:
                _8101b73834ff = _ace2a706caca._9872e158c1d3
        except _d2cc34cc5f93:
            _8101b73834ff = _ace2a706caca._4ff5fa947cfb
    return _8101b73834ff


def _018d5c9de9a9(_d825ead81c84, _7b02c53e795d):
    """Return True when `trial.params` equals parameters of any past trial.

    Args:
        trial (optuna.trial.Trial): Trial to check.
        study (optuna.Study): Study to check against.

    Returns:
        bool: True if duplicate found, False otherwise.

    Raises:
        TypeError: If `trial` or `study` is None or lacks expected attributes.
    """
    if _d825ead81c84 is _a51422e3e83d or _7b02c53e795d is _a51422e3e83d:
        raise _670e477c800e("trial and study must be provided")

    # Get the current trial parameters
    _d3632d32e1a2 = _a61b6f6798fd(_d825ead81c84, "params", _a51422e3e83d)
    if _d3632d32e1a2 is _a51422e3e83d:
        raise _670e477c800e("trial.params is not available")

    # Check all completed trials for duplicates
    for _4b96d0e0da66 in _7b02c53e795d._642cc028bed8(_b663ad18ce78=(_fd0ea7864762._d825ead81c84._1048d1288d4c._4dfe162e30ea,
                                               _fd0ea7864762._d825ead81c84._1048d1288d4c._9f81c68aacac,
                                               _fd0ea7864762._d825ead81c84._1048d1288d4c._b9d07bfae4ad)):
        if _a61b6f6798fd(_4b96d0e0da66, "params", _a51422e3e83d) == _d3632d32e1a2:
            return _a0e6a52e6576
    return _877c64c361ea


class _8cb7166873e7(_fd0ea7864762._ed618f6c5537._55b4d44c0438):
    """Sampler wrapper that resamples a parameter when a duplicate trial would be created.

    Args:
        base_sampler (optuna.samplers.BaseSampler): Underlying sampler to delegate to.
    """

    def _cc63f452f50b(self, _69d190d16348: _fd0ea7864762._ed618f6c5537._55b4d44c0438):
        self._69d190d16348 = _69d190d16348  # Use TPESampler or any other sampler

    # Override and delegate infer_relative_search_space to the base sampler
    def _a2fb491bed06(self, _7b02c53e795d, _d825ead81c84):
        return self._69d190d16348._a7d37578245e(_7b02c53e795d, _d825ead81c84)

    # Override and delegate sample_relative to the base sampler
    def _85ee89e3f15f(self, _7b02c53e795d, _d825ead81c84, _46dc7367f0c8):
        return self._69d190d16348._9ccf9a1e9b37(_7b02c53e795d, _d825ead81c84, _46dc7367f0c8)

    # Override sample_independent to check for duplicates
    def _2ead68b20e88(self, _7b02c53e795d, _d825ead81c84, _442c2475f101, _b1f4ba93177d):
        """
        Sample independently using the base sampler. If the proposed parameter
        would create a duplicate trial (all params equal to a past trial),
        resample until unique.

        Args:
            study (optuna.Study)
            trial (optuna.trial.Trial)
            param_name (str)
            param_distribution: distribution object passed by Optuna

        Returns:
            The sampled parameter value.

        Raises:
            RuntimeError: If underlying base_sampler repeatedly fails to produce a non-duplicate
                          after many attempts (guard not implemented here to preserve original behavior).
        """
        while _a0e6a52e6576:
            # Sample a set of hyperparameters using the base sampler (TPESampler)
            _ddfb99252c2e = self._69d190d16348._0d2d8c7fa843(_7b02c53e795d, _d825ead81c84, _442c2475f101, _b1f4ba93177d)

            # Temporarily assign the parameter to the trial for comparison
            _d825ead81c84._3c08d8dc6e86[_442c2475f101] = _ddfb99252c2e

            # Check if this parameter set (with the current params) is a duplicate
            if not _daba6ad87541(_d825ead81c84, _7b02c53e795d):
                return _ddfb99252c2e  # If not duplicate, return the parameter


def _2121d11cf449(_52fd42b72fcb):
    """Compute gamma parameter for TPESampler.

    Args:
        n (int): Number of completed trials.

    Returns:
        int: Top 10% of n, capped at 25.
    """
    # top 10% of n completed trials
    return _f02a804a52ea(25, _3b9c6678cf1b(0.1 * _52fd42b72fcb))

def _6e9f2e104273(_4433166f7d1c, _cc0f685166d8: _2c502e56ef05, _6082d97556c6=_a51422e3e83d, _bdae102072b1: _659c33195fae = _a0e6a52e6576, _53420ddffe79=_a51422e3e83d, _ea5247df660c: _2c502e56ef05 = _a51422e3e83d):
    """
    Retrieve and validate a property from a dot-separated path (e.g. 'app.random_seed', 'run_config.batch_size').

    Args:
        props: Loaded YAML properties object (attribute/dict hybrid).
        name: Dot-separated property name (string).
        dtype: Optional type enforcement (e.g. int, float, str, "list[int]", "list[str]", etc.).
        required: If True, raises error when missing. If False, returns default.
        default: Optional fallback value when required=False and key missing.
        help: Optional human-readable hint for fixing config.

    Raises:
        AttributeError: If key missing and required=True.
        ValueError: If key exists but value is None.
        TypeError: If dtype enforcement fails.

    Returns:
        The retrieved (and possibly cast) value, or default.
    """

    # --- Navigate dotted path ---
    _5f4e066395a2 = _cc0f685166d8._925ca7f915b1(".")
    _81a6712aafff = _4433166f7d1c
    _8bb2475a8f1f = []
    for _82d8bb4ce67f in _5f4e066395a2:
        _8bb2475a8f1f._f61c115e9fef(_82d8bb4ce67f)
        if _81a6712aafff is _a51422e3e83d:
            if _bdae102072b1:
                raise _8d90e30f2c94(
                    f"Missing required property '{'.'._d5744f9fa356(_8bb2475a8f1f)}' (intermediate value is None). {_ea5247df660c or ''}"
                )
            return _53420ddffe79

        if _7a2ba19040bc(_81a6712aafff, _82d8bb4ce67f):
            _81a6712aafff = _a61b6f6798fd(_81a6712aafff, _82d8bb4ce67f)
        elif _f716567cce9b(_81a6712aafff, _9f1b04ce9db9) and _82d8bb4ce67f in _81a6712aafff:
            _81a6712aafff = _81a6712aafff[_82d8bb4ce67f]
        else:
            if _bdae102072b1:
                raise _8d90e30f2c94(
                    f"Missing required property '{'.'._d5744f9fa356(_8bb2475a8f1f)}'. {_ea5247df660c or ''}"
                )
            return _53420ddffe79

    _defa172c392a = _81a6712aafff

    # --- Explicit null check ---
    if _defa172c392a is _a51422e3e83d:
        raise _2cbaed531abc(
            f"Property '{_cc0f685166d8}' is explicitly null/None. Please set a valid value or remove the key to use default. {_ea5247df660c or ''}"
        )

    # --- Dtype enforcement ---
    if _6082d97556c6 is not _a51422e3e83d:
        def _2b42fc572db5(_96779611fec4):
            raise _670e477c800e(f"Property '{_cc0f685166d8}' type validation failed: {_96779611fec4}. {_ea5247df660c or ''}")

        if _f716567cce9b(_6082d97556c6, _2c502e56ef05) and _6082d97556c6._4d4ca15b94ae("list[") and _6082d97556c6._b73ac11839fa("]"):
            _522206912ddb = _6082d97556c6[5:-1]._3a1f1beecd95()
            if not _f716567cce9b(_defa172c392a, _9cbc177b34f0):
                _d7d13dceab22(f"expected list[{_522206912ddb}], got {_4586c0afec66(_defa172c392a).__name__}")
            _42bc618e06cf = {"int": _3b9c6678cf1b, "float": _09c419466158, "str": _2c502e56ef05, "bool": _659c33195fae}
            _6d5a66ce4d2e = _42bc618e06cf._85a26a0fb3c1(_522206912ddb)
            if _6d5a66ce4d2e is _a51422e3e83d:
                _d7d13dceab22(f"unsupported inner dtype '{_522206912ddb}'")
            try:
                _defa172c392a = [_6d5a66ce4d2e(_d84358105a73) for _d84358105a73 in _defa172c392a]
            except _d2cc34cc5f93 as _994b1eb9a3c6:
                _d7d13dceab22(f"failed to cast elements to {_522206912ddb}: {_994b1eb9a3c6}")
        else:
            try:
                _defa172c392a = _6082d97556c6(_defa172c392a)
            except _d2cc34cc5f93 as _994b1eb9a3c6:
                _d7d13dceab22(f"cannot cast to {_a61b6f6798fd(_6082d97556c6, '__name__', _6082d97556c6)}: {_994b1eb9a3c6}")

    return _defa172c392a


def _23b9f8ea978c(_d825ead81c84: _fd0ea7864762._d825ead81c84._27a6e8ada1d1, _7d4f234d0ff1: _9cbc177b34f0, _2ccad2452458: _2ac0680c832f):
    """Construct a PEFT LoraConfig from an Optuna trial's suggested hyperparameters.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance to query for hyperparameters.
        target_modules (list): list of target modules (may be empty).
        lora_task_type (Any): TaskType enum or equivalent required by LoraConfig.

    Returns:
        LoraConfig: Instance configured according to trial suggestions.

    Raises:
        Exception: Propagates exceptions from the underlying LoraConfig constructor or trial queries.
    """
    # Define the range for rank
    _607b22652ec9 = _d825ead81c84._4fcdbe8df2cf("lora_rank", 4, 16, _c889fd56a2c2=4)

    # Dynamically calculate scaling factor based on rank
    _862fd3b9c560 = _d825ead81c84._4fcdbe8df2cf("lora_alpha_scaling_factor", 8, 32, _c889fd56a2c2=4)
    # Add dropout options for LoRA
    _c3e1717b6241 = _d825ead81c84._a7b9bf2c4d85("lora_dropout", [0.0, 0.1, 0.2])

    # Create and return LoraConfig. Keep as the project's expected LoraConfig API.
    return _17b471958b21(
        _f57b055844e4=_607b22652ec9 if not _f716567cce9b(_607b22652ec9, _f631a26fd9c3) else _607b22652ec9[0],
        _862fd3b9c560=_862fd3b9c560 if not _f716567cce9b(_862fd3b9c560, _f631a26fd9c3) else _862fd3b9c560[0],
        _c3e1717b6241=_c3e1717b6241 if not _f716567cce9b(_c3e1717b6241, _f631a26fd9c3) else _c3e1717b6241[0],
        _7d4f234d0ff1=_7d4f234d0ff1 if _7d4f234d0ff1 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj", "embed_tokens", "lm_head"],
        _8c4c43ca5fa3=_2ccad2452458
    )

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Apply LoRA to model.embedding or equivalent embedding root for decoder models.
#     """
#     log.info(f"Model Structure before applying LoRA {model}")
#     log.info("Trainable params before LoRA: %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))

#     if not isinstance(target_embedding_modules, dict):
#         log.warning("Expected target_embedding_modules dict, got %s; skipping LoRA.", type(target_embedding_modules))
#         return model

#     root = getattr(model, "module", model)
#     model_name_to_mod = dict(root.named_modules())

#     # Resolve names (object identity, exact name, suffix)
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None
#         for nm, mm in model_name_to_mod.items():
#             if mm is emb_mod:
#                 found = nm; break
#         if found is None and emb_key in model_name_to_mod:
#             found = emb_key
#         if found is None:
#             short = emb_key.replace("embedding.", "").replace("module.", "").replace("embedding.module.", "")
#             for nm in model_name_to_mod:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in model", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # shallow clone config avoiding odict_keys issues
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # cleaned target module names relative to embedding
#     cleaned_targets = []
#     for full_nm in resolved:
#         t = full_nm.replace("model.embedding.", "").replace("embedding.", "").replace("module.", "").lstrip(".")
#         if t:
#             cleaned_targets.append(t)
#     # dedupe order-preserve
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     try:
#         cfg.target_modules = list(cleaned_targets)
#     except Exception:
#         setattr(cfg, "target_modules", list(cleaned_targets))

#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- UNWRAP WRAPPERS UNDER model.embedding (in-place) ---
#     def _resolve_embedding_root(obj):
#         """
#         Return tuple (embedding_module, path_key) where path_key indicates where to reattach:
#           - "embedding" -> model.embedding
#           - "model.model.embed_tokens" -> model.model.embed_tokens
#           - "transformer.wte" -> model.transformer.wte
#         Raises ValueError if none found.
#         """
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         # some wrappers: e.g., HF models that nest inside .base_model
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Try to unwrap common wrappers under the embedding subtree (in-place)
#     def _unwrap_candidate(obj):
#         if hasattr(obj, "module") and obj is not getattr(obj, "module"):
#             return getattr(obj, "module")
#         if hasattr(obj, "base_layer") and obj is not getattr(obj, "base_layer"):
#             return getattr(obj, "base_layer")
#         return None

#     for parent_name, parent in list(emb_unwrapped.named_modules()):
#         # use named_children on parent to replace attributes on parent
#         for child_name, child in list(parent.named_children()):
#             try:
#                 inner = _unwrap_candidate(child)
#                 if inner is not None:
#                     setattr(parent, child_name, inner)
#                     log.debug("Unwrapped %s.%s -> %s", parent_name or "embedding_root", child_name, inner.__class__.__name__)
#             except Exception:
#                 log.debug("Could not unwrap child %s of parent %s", child_name, parent_name)

#     # Recompute actual embedding root after unwrapping (in case we changed .module children)
#     emb_current = emb_current  # preserve original wrapper object reference (used for reattach)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Use small container exposing embedding so PEFT only touches embedding submodules
#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)
#     # attempt to move container to same device as embedding params to avoid device errors
#     try:
#         sample_dev = None
#         for p in emb_unwrapped.parameters():
#             sample_dev = p.device; break
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Call PEFT on the embedding container
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # Reinstall wrapped embedding back into the top-level model, preserving wrapper if present
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped_emb)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped_emb
#             else:
#                 model.embedding = wrapped_emb
#         elif emb_path == "model.model.embed_tokens":
#             model.model.embed_tokens = wrapped_emb
#         elif emb_path == "transformer.wte":
#             model.transformer.wte = wrapped_emb
#         elif emb_path == "base_model.model.embed_tokens":
#             model.base_model.model.embed_tokens = wrapped_emb
#         else:
#             # fallback, attempt best-effort attach by attribute traversal
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     log.info("Applied LoRA to model.embedding (PEFT-wrapped).")

#     # Freeze non-LoRA params inside embedding; keep LoRA params trainable
#     try:
#         for name, param in model.embedding.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside model.embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in model.embedding.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("LoRA enabled %d tensors, total %d params.", len(enabled), sum(v for _, v in enabled))
#     log.info("After LoRA: trainable params %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))
#     log.info(f"Model Structure after applying LoRA {model}")
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Unified LoRA application for both BERT-like and LLaMA-like models.
#     Works with quantized or non-quantized modules.

#     Returns the input `model` with LoRA adapters applied in-place.
#     """
#     # small local helper: resolve common embedding roots
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())
#     log.info("Root type: %s", type(root))
#     log.info("Named modules sample: %s", list(named_modules.keys())[:20])
#     log.info("Target embedding keys: %s", list(target_embedding_modules.keys()))

#     # --- resolve provided target_embedding_modules to names in root.named_modules() ---
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None

#         # identity match (object identity)
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 found = nm
#                 break
#         if found:
#             resolved.append(found); continue

#         # direct string variants (embedding. prefix / without)
#         if isinstance(emb_key, str):
#             variants = [emb_key]
#             if not emb_key.startswith("embedding."):
#                 variants.append("embedding." + emb_key)
#             else:
#                 variants.append(emb_key.replace("embedding.", "", 1))
#             for v in variants:
#                 if v in named_modules:
#                     found = v; break
#         if found:
#             resolved.append(found); continue

#         # suffix match (endswith)
#         if isinstance(emb_key, str):
#             short = emb_key.replace("embedding.", "").replace("module.", "").lstrip(".")
#             for nm in named_modules:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found); continue

#         # fallback: match by class name + first parameter shape
#         try:
#             if isinstance(emb_mod, torch.nn.Module):
#                 emb_cls = emb_mod.__class__.__name__
#                 ref_shape = None
#                 for p in emb_mod.parameters():
#                     ref_shape = tuple(p.shape); break
#                 if ref_shape is not None:
#                     for nm, mm in named_modules.items():
#                         if mm.__class__.__name__ != emb_cls:
#                             continue
#                         for p in mm.parameters():
#                             if tuple(p.shape) == ref_shape:
#                                 found = nm; break
#                         if found:
#                             break
#         except Exception:
#             pass
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in root.named_modules()", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")
#     log.info("Resolved LoRA targets: %s", resolved)

#     # --- clone & normalise LoRA config ---
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # Determine embedding root and path (for normalization)
#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Embedding root resolution failed: {e}")

#     # Normalize target module names to be *relative to the module we will pass to PEFT*
#     cleaned_targets = []
#     for full in resolved:
#         # If resolved name starts with the emb_path, strip that prefix
#         if isinstance(full, str) and full.startswith(emb_path + "."):
#             cleaned = full[len(emb_path) + 1 :]
#         else:
#             # also handle common alternatives
#             cleaned = full.replace("embedding.model.", "").replace("embedding.", "").replace("model.", "").lstrip(".")
#         if cleaned:
#             cleaned_targets.append(cleaned)
#     # dedupe preserve order
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     cfg.target_modules = list(cleaned_targets)
#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- if LLaMA-like (decoder) apply LoRA directly on decoder model to avoid embedding-wrapper issues ---
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         log.info("Detected LLaMA architecture — applying LoRA directly on decoder model.")
#         try:
#             # normalize: remove "model." prefix so PEFT matches internal names
#             cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]
#             # cfg.target_modules must be relative to model.embedding.model (we already normalized above)
#             wrapped_decoder = get_peft_model(model.embedding.model, cfg)
#             # replace decoder in-place
#             model.embedding.model = wrapped_decoder

#             # freeze everything except LoRA params inside the wrapped decoder
#             for n, p in model.embedding.model.named_parameters():
#                 p.requires_grad = ("lora" in n.lower())

#             log.info("Applied LoRA to LLaMA decoder; trainable params: %d",
#                      sum(1 for _, p in model.embedding.model.named_parameters() if p.requires_grad))
#             return model
#         except Exception as e:
#             log.error("Failed to apply LoRA directly on LLaMA decoder: %s", e)
#             raise

#     # --- otherwise: create container exposing 'embedding' so PEFT touches only embedding subtree ---
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # attach generation helper if root implements it (prevents PEFT complaining)
#     if hasattr(root, "prepare_inputs_for_generation"):
#         try:
#             setattr(emb_container, "prepare_inputs_for_generation", getattr(root, "prepare_inputs_for_generation"))
#         except Exception:
#             # non-fatal
#             pass

#     # move container to embedding device if known
#     try:
#         sample_dev = next((p.device for p in emb_unwrapped.parameters()), None)
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Wrap the container with PEFT
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # obtain wrapped embedding module and reattach into the model at emb_path
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         parts = emb_path.split(".")
#         tgt = model
#         for p in parts[:-1]:
#             tgt = getattr(tgt, p)
#         setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     # Freeze non-LoRA params inside the wrapped embedding; keep LoRA params trainable
#     try:
#         for name, param in wrapped_emb.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside wrapped embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in wrapped_emb.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("Applied LoRA successfully with %d trainable tensors.", len(enabled))
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     # ------------------------------------------------------------------
#     # Helper: ensure PEFT-required method exists
#     # ------------------------------------------------------------------
#     def _ensure_prepare_inputs_for_generation(obj, fallback):
#         if hasattr(obj, "prepare_inputs_for_generation"):
#             return
#         if hasattr(fallback, "prepare_inputs_for_generation"):
#             obj.prepare_inputs_for_generation = fallback.prepare_inputs_for_generation
#             return

#         def _noop_prepare_inputs_for_generation(*args, **kwargs):
#             return args[0] if args else None

#         obj.prepare_inputs_for_generation = _noop_prepare_inputs_for_generation

#     # ------------------------------------------------------------------
#     # Helper: resolve embedding root (unchanged logic)
#     # ------------------------------------------------------------------
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())

#     # ------------------------------------------------------------------
#     # Resolve target embedding modules (unchanged)
#     # ------------------------------------------------------------------
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 resolved.append(nm)
#                 break

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # ------------------------------------------------------------------
#     # Clone LoRA config
#     # ------------------------------------------------------------------
#     try:
#         cfg = lora_config.__class__(**vars(lora_config))
#     except Exception:
#         cfg = lora_config

#     # ------------------------------------------------------------------
#     # Normalize target module names
#     # ------------------------------------------------------------------
#     emb_current, emb_path = _resolve_embedding_root(model)

#     cleaned_targets = []
#     for full in resolved:
#         if full.startswith(emb_path + "."):
#             cleaned_targets.append(full[len(emb_path) + 1 :])

#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")

#     cfg.target_modules = cleaned_targets

#     # ------------------------------------------------------------------
#     # Detect LLaMA-style decoder (unchanged intent)
#     # ------------------------------------------------------------------
#     is_llama_decoder = (
#         hasattr(model, "embedding")
#         and hasattr(model.embedding, "model")
#         and hasattr(model.embedding.model, "layers")
#     )

#     is_gemma_decoder = (
#         hasattr(model, "model")
#         and hasattr(model.model, "model")
#         and hasattr(model.model.model, "layers")
#     )

#     # ------------------------------------------------------------------
#     # LLaMA decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_llama_decoder:
#         decoder = model.embedding.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.embedding.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model
    
#     # ------------------------------------------------------------------
#     # gemma decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_gemma_decoder:
#         decoder = model.model.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.model.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model

#     # ------------------------------------------------------------------
#     # Embedding-container path (PATCHED)
#     # ------------------------------------------------------------------
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # CRITICAL FIX: ensure hook exists UNCONDITIONALLY
#     _ensure_prepare_inputs_for_generation(emb_container, root)

#     wrapped_container = get_peft_model(emb_container, cfg)
#     wrapped_emb = wrapped_container.embedding

#     # Reattach wrapped embedding
#     parts = emb_path.split(".")
#     tgt = model
#     for p in parts[:-1]:
#         tgt = getattr(tgt, p)
#     setattr(tgt, parts[-1], wrapped_emb)

#     for name, param in wrapped_emb.named_parameters():
#         param.requires_grad = ("lora" in name.lower())

#     return model

def _628c8cced8cc(
    _ea3c84952bcb: "torch.nn.Module",
    _7be060b382a1: "Dict[str, torch.nn.Module]",
    _b9e21dc51925,
    _2f287bd6bcdf: "Any"
) -> "torch.nn.Module":

    def _ec0a36f48cfe(_e5cde0584448, _e6bb97f7421e):
        if _7a2ba19040bc(_e5cde0584448, "prepare_inputs_for_generation"):
            return
        if _7a2ba19040bc(_e6bb97f7421e, "prepare_inputs_for_generation"):
            _e5cde0584448._30506be04d2b = _e6bb97f7421e._30506be04d2b
            return

        def _611e1789dba3(*_59b694c7b3ec, **_5defdaa1ed4f):
            return _59b694c7b3ec[0] if _59b694c7b3ec else _a51422e3e83d

        _e5cde0584448._30506be04d2b = _dd20ef4c514b

    def _291f4767b301(_e5cde0584448):
        if _7a2ba19040bc(_e5cde0584448, "embedding"):
            return _a61b6f6798fd(_e5cde0584448, "embedding"), "embedding"
        if _7a2ba19040bc(_e5cde0584448, "model") and _7a2ba19040bc(_e5cde0584448._ea3c84952bcb, "embed_tokens"):
            return _a61b6f6798fd(_e5cde0584448._ea3c84952bcb, "embed_tokens"), "model.embed_tokens"
        if _7a2ba19040bc(_e5cde0584448, "model") and _7a2ba19040bc(_e5cde0584448._ea3c84952bcb, "model") and _7a2ba19040bc(_e5cde0584448._ea3c84952bcb._ea3c84952bcb, "embed_tokens"):
            return _a61b6f6798fd(_e5cde0584448._ea3c84952bcb._ea3c84952bcb, "embed_tokens"), "model.model.embed_tokens"
        if _7a2ba19040bc(_e5cde0584448, "transformer") and _7a2ba19040bc(_e5cde0584448._f9d943ce45c9, "wte"):
            return _a61b6f6798fd(_e5cde0584448._f9d943ce45c9, "wte"), "transformer.wte"
        if _7a2ba19040bc(_e5cde0584448, "base_model") and _7a2ba19040bc(_e5cde0584448._1c765594a3be, "model") and _7a2ba19040bc(_e5cde0584448._1c765594a3be._ea3c84952bcb, "embed_tokens"):
            return _a61b6f6798fd(_e5cde0584448._1c765594a3be._ea3c84952bcb, "embed_tokens"), "base_model.model.embed_tokens"
        raise _2cbaed531abc(f"Could not resolve embedding root for {_e5cde0584448._7ac3ff53863a.__name__}")

    _0d03472b749a = _a61b6f6798fd(_ea3c84952bcb, "module", _ea3c84952bcb)
    _2368a971a394 = _9f1b04ce9db9(_0d03472b749a._2368a971a394())

    # --------------------------------------------------
    # Detect decoders FIRST (ONLY MOVED)
    # --------------------------------------------------
    _61c62395cfb4 = (
        _7a2ba19040bc(_ea3c84952bcb, "embedding")
        and _7a2ba19040bc(_ea3c84952bcb._d67bea085101, "model")
        and _7a2ba19040bc(_ea3c84952bcb._d67bea085101._ea3c84952bcb, "layers")
    )

    _8e30ba35c6d6 = (
        _7a2ba19040bc(_ea3c84952bcb, "model")
        and _7a2ba19040bc(_ea3c84952bcb._ea3c84952bcb, "model")
        and _7a2ba19040bc(_ea3c84952bcb._ea3c84952bcb._ea3c84952bcb, "layers")
    )

    _7f4f345c43c3 = (
        _7a2ba19040bc(_ea3c84952bcb, "model")
        and _7a2ba19040bc(_ea3c84952bcb._ea3c84952bcb, "layers")
    )

    # --------------------------------------------------
    # Resolve target embedding modules (UNCHANGED)
    # --------------------------------------------------
    _0042ab0ef075 = []
    for _0fa30a42afda, _eb5d209605d1 in _7be060b382a1._dc53f2774594():
        for _a721444118e7, _d8472065f4a1 in _2368a971a394._dc53f2774594():
            if _d8472065f4a1 is _eb5d209605d1:
                _0042ab0ef075._f61c115e9fef(_a721444118e7)
                break

    if not _0042ab0ef075 and not _61c62395cfb4 and not _8e30ba35c6d6 and not _7f4f345c43c3:
        raise _2cbaed531abc("No embedding submodules resolved for LoRA — skipping.")

    # --------------------------------------------------
    # Clone LoRA config (UNCHANGED)
    # --------------------------------------------------
    try:
        _409ed279b3a8 = _b9e21dc51925._7ac3ff53863a(**_a44688d51627(_b9e21dc51925))
    except _d2cc34cc5f93:
        _409ed279b3a8 = _b9e21dc51925

    # --------------------------------------------------
    # Normalize target module names (UNCHANGED)
    # --------------------------------------------------
    _8f6aed2146b6, _ef4f89405946 = _ff9e968af9a6(_ea3c84952bcb)

    _d484c108e0b7 = []
    for _4020cfad2ee9 in _0042ab0ef075:
        if _4020cfad2ee9._4d4ca15b94ae(_ef4f89405946 + "."):
            _d484c108e0b7._f61c115e9fef(_4020cfad2ee9[_098ff4aa9e03(_ef4f89405946) + 1 :])

    if _d484c108e0b7:
        _409ed279b3a8._7d4f234d0ff1 = _d484c108e0b7

    # --------------------------------------------------
    # LLaMA decoder path (UNCHANGED)
    # --------------------------------------------------
    if _61c62395cfb4:
        _5b48889a4e32 = _ea3c84952bcb._d67bea085101._ea3c84952bcb
        _1a3fb7fd5352(_5b48889a4e32, _ea3c84952bcb)
        _409ed279b3a8._7d4f234d0ff1 = [_acb0e614ca45._385a463f2e8f("model.", "") for _acb0e614ca45 in _409ed279b3a8._7d4f234d0ff1]
        _15912dadb94a = _d3f47f87cc8b(_5b48889a4e32, _409ed279b3a8)
        _ea3c84952bcb._d67bea085101._ea3c84952bcb = _15912dadb94a
        for _52fd42b72fcb, _82d8bb4ce67f in _15912dadb94a._4ae136d00245():
            _82d8bb4ce67f._6d9835de8f6e = ("lora" in _52fd42b72fcb._5d6fc1f32287())
        return _ea3c84952bcb

    # --------------------------------------------------
    # Gemma decoder path (UNCHANGED)
    # --------------------------------------------------
    if _8e30ba35c6d6:
        _5b48889a4e32 = _ea3c84952bcb._ea3c84952bcb._ea3c84952bcb
        _1a3fb7fd5352(_5b48889a4e32, _ea3c84952bcb)
        _409ed279b3a8._7d4f234d0ff1 = [_acb0e614ca45._385a463f2e8f("model.", "") for _acb0e614ca45 in _409ed279b3a8._7d4f234d0ff1]
        _15912dadb94a = _d3f47f87cc8b(_5b48889a4e32, _409ed279b3a8)
        _ea3c84952bcb._ea3c84952bcb._ea3c84952bcb = _15912dadb94a
        for _52fd42b72fcb, _82d8bb4ce67f in _15912dadb94a._4ae136d00245():
            _82d8bb4ce67f._6d9835de8f6e = ("lora" in _52fd42b72fcb._5d6fc1f32287())
        return _ea3c84952bcb
    
    # --------------------------------------------------
    # Qwen decoder path (UNCHANGED)
    # --------------------------------------------------
    if _7f4f345c43c3:
        _5b48889a4e32 = _ea3c84952bcb._ea3c84952bcb
        _1a3fb7fd5352(_5b48889a4e32, _ea3c84952bcb)
        _409ed279b3a8._7d4f234d0ff1 = [_acb0e614ca45._385a463f2e8f("model.", "") for _acb0e614ca45 in _409ed279b3a8._7d4f234d0ff1]
        _15912dadb94a = _d3f47f87cc8b(_5b48889a4e32, _409ed279b3a8)
        _ea3c84952bcb._ea3c84952bcb = _15912dadb94a
        for _52fd42b72fcb, _82d8bb4ce67f in _15912dadb94a._4ae136d00245():
            _82d8bb4ce67f._6d9835de8f6e = ("lora" in _52fd42b72fcb._5d6fc1f32287())
        return _ea3c84952bcb

    # --------------------------------------------------
    # Embedding path (UNCHANGED)
    # --------------------------------------------------
    _3093962e60aa = _a61b6f6798fd(_8f6aed2146b6, "module", _8f6aed2146b6)

    class _c38957a18535(_ace2a706caca._e8f7c0dca7e6._368e53f0c577):
        def _cc63f452f50b(self, _0a9019aa1233):
            _3ecbcd0e9dcd()._8dd52e165eb6()
            self._d67bea085101 = _0a9019aa1233

    _96db88d320a1 = _fd8b90ce84f6(_3093962e60aa)
    _1a3fb7fd5352(_96db88d320a1, _0d03472b749a)

    _2b531082710d = _d3f47f87cc8b(_96db88d320a1, _409ed279b3a8)
    _f03e59d1adc1 = _2b531082710d._d67bea085101

    _5f4e066395a2 = _ef4f89405946._925ca7f915b1(".")
    _ddddbb59de6f = _ea3c84952bcb
    for _82d8bb4ce67f in _5f4e066395a2[:-1]:
        _ddddbb59de6f = _a61b6f6798fd(_ddddbb59de6f, _82d8bb4ce67f)
    _1ec988e8f13f(_ddddbb59de6f, _5f4e066395a2[-1], _f03e59d1adc1)

    for _cc0f685166d8, _ddfb99252c2e in _f03e59d1adc1._4ae136d00245():
        _ddfb99252c2e._6d9835de8f6e = ("lora" in _cc0f685166d8._5d6fc1f32287())

    return _ea3c84952bcb


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> "torch.nn.Module":
#     """
#     Reverse of apply_lora_to_model (focused on embedding subtree).
#     - Resolves the same embedding root as apply_lora_to_model.
#     - Prefers calling PEFT's merge API if present on the embedding wrapper.
#     - Otherwise performs a manual merge of inline lora wrappers (base_layer + lora_A/lora_B).
#     - Replaces wrapper modules with their base_layer so the final model contains plain nn.Modules.
#     - Works with ModuleDict(default=...), ParameterDict, and common lora_alpha container formats.
#     """
#     if log is None:
#         import logging
#         log = logging.getLogger(__name__)

#     import torch
#     from typing import Any, Dict

#     root = getattr(model, "module", model)

#     # --- Resolve embedding root using the same heuristics as apply_lora_to_model ---
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # --- Try PEFT merge if available (embedding-level) ---
#     try:
#         if hasattr(emb_current, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on embedding wrapper.")
#             merged = emb_current.merge_and_unload()
#             wrapped = merged if merged is not None else emb_current
#             # reattach to model according to emb_path (preserve wrapper if it exists)
#             try:
#                 if emb_path == "embedding":
#                     if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                         try:
#                             setattr(emb_current, "module", wrapped)
#                             model.embedding = emb_current
#                         except Exception:
#                             model.embedding = wrapped
#                     else:
#                         model.embedding = wrapped
#                 else:
#                     parts = emb_path.split(".")
#                     tgt = model
#                     for p in parts[:-1]:
#                         tgt = getattr(tgt, p)
#                     setattr(tgt, parts[-1], wrapped)
#                 log.info("PEFT embedding merge_and_unload() succeeded.")
#                 return model
#             except Exception:
#                 # if reattach fails, continue to manual merge
#                 log.warning("PEFT merge succeeded but reattach failed; continuing to manual merge.")
#         if hasattr(emb_unwrapped, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on emb_unwrapped.")
#             merged = emb_unwrapped.merge_and_unload()
#             wrapped = merged if merged is not None else emb_unwrapped
#             # try to reattach preserving wrapper
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped
#             else:
#                 parts = emb_path.split(".")
#                 tgt = model
#                 for p in parts[:-1]:
#                     tgt = getattr(tgt, p)
#                 setattr(tgt, parts[-1], wrapped)
#             log.info("PEFT emb_unwrapped merge_and_unload() succeeded.")
#             return model
#     except Exception as e:
#         log.warning("PEFT merge attempt raised: %s -- falling back to manual merge", e)

#     # --- Helpers for manual merge ---
#     def _normalize_alpha(alpha_raw):
#         # return float or None
#         try:
#             if alpha_raw is None:
#                 return None
#             if isinstance(alpha_raw, dict):
#                 # pick the first scalar-like value
#                 for v in alpha_raw.values():
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     # if v is a tensor scalar
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             continue
#                 # fallback: try first value cast
#                 try:
#                     return float(list(alpha_raw.values())[0])
#                 except Exception:
#                     return None
#             # ModuleDict or module with numeric attr/buffer
#             if hasattr(alpha_raw, "__class__") and "Module" in alpha_raw.__class__.__name__:
#                 # try attribute names
#                 for a in ("lora_alpha", "alpha"):
#                     v = getattr(alpha_raw, a, None)
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             pass
#                 # try parameters
#                 try:
#                     ps = list(alpha_raw.parameters())
#                     if ps:
#                         return float(ps[0].item())
#                 except Exception:
#                     pass
#                 return None
#             if isinstance(alpha_raw, (list, tuple)):
#                 if not alpha_raw:
#                     return None
#                 return float(alpha_raw[0])
#             if isinstance(alpha_raw, (int, float)):
#                 return float(alpha_raw)
#             # attempt cast
#             return float(alpha_raw)
#         except Exception:
#             return None

#     def _unwrap_map(obj) -> Dict[str, Any]:
#         """
#         Normalize lora_A / lora_B into a dict name->module/param object.
#         Accepts Module (single), ModuleDict/dict, ParameterDict-like.
#         """
#         out = {}
#         try:
#             # single module (not ModuleDict)
#             if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                 out[""] = obj
#                 return out
#         except Exception:
#             pass
#         # mapping-like
#         try:
#             items = list(obj.items())
#         except Exception:
#             items = []
#         for k, v in items:
#             out[k] = v
#         return out

#     def _tensor_from_obj(x):
#         # return a torch.Tensor (raw data) or None
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first param
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#             return None
#         if isinstance(x, torch.Tensor):
#             return x
#         return None

#     def _compute_delta(A_w, B_w, base):
#         """
#         Robustly compute delta for given A_w, B_w and base.weight shape.
#         Tries: B@A, A@B, inference from flattened tensors (reshape using base shape),
#         and chunked-sum heuristics. Raises RuntimeError if impossible.
#         """
#         # quick guards
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # common case: A 2D (r,in), B 2D (out,r) -> B@A
#         if A_w.dim() == 2 and B_w.dim() == 2 and B_w.shape[1] == A_w.shape[0]:
#             return B_w @ A_w

#         # if either is 1D (flattened), try to infer r using base shape
#         base_out = int(base.weight.shape[0])
#         base_in = int(base.weight.shape[1])
#         A_num = int(A_w.numel())
#         B_num = int(B_w.numel())

#         # attempt reshape inference: try r candidate derived from counts
#         # If B_num == base_out * r and A_num == r * base_in => reshape and B@A
#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat
#             # try candidate from A
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat

#         # try simple transpose fallbacks
#         try:
#             return B_w @ A_w
#         except Exception:
#             pass
#         try:
#             return A_w @ B_w
#         except Exception:
#             pass

#         # chunked heuristic: if one inner-dim is integer multiple of the other
#         try:
#             # promote to 2D (best-effort)
#             A_mat = A_w if A_w.dim() == 2 else A_w.view(A_w.shape[0], -1)
#             B_mat = B_w if B_w.dim() == 2 else B_w.view(-1, B_w.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)} for base {tuple(base.weight.shape)}")

#     # --- Manual merge walk under embedding subtree ---
#     merged = 0
#     replaced = 0
#     # iterate parents so we can setattr on them
#     for parent in list(emb_unwrapped.modules()):
#         for child_name, child in list(parent.named_children()):
#             # target wrappers: have base_layer and lora_A/lora_B
#             if not hasattr(child, "base_layer"):
#                 continue
#             if not (hasattr(child, "lora_A") and hasattr(child, "lora_B")):
#                 # attempt simple unwraps (module/base_layer) to remove wrapper objects
#                 try:
#                     if hasattr(child, "module") and child is not getattr(child, "module"):
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> module", type(parent).__name__, child_name)
#                         continue
#                     if hasattr(child, "base_layer"):
#                         setattr(parent, child_name, getattr(child, "base_layer"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> base_layer", type(parent).__name__, child_name)
#                         continue
#                 except Exception:
#                     pass
#                 continue

#             base = getattr(child, "base_layer", None)
#             if base is None or not hasattr(base, "weight"):
#                 log.warning("Skipping %s: no base_layer.weight", child_name)
#                 continue

#             # normalize maps
#             A_map = _unwrap_map(getattr(child, "lora_A", None))
#             B_map = _unwrap_map(getattr(child, "lora_B", None))
#             if not A_map or not B_map:
#                 # attempt remove wrapper if no A/B entries
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (empty A/B).", child_name)
#                 except Exception:
#                     log.warning("Could not replace empty wrapper %s", child_name)
#                 continue

#             # normalize alpha
#             alpha_raw = getattr(child, "lora_alpha", None)
#             alpha = _normalize_alpha(alpha_raw)

#             applied_here = 0
#             # iterate keys (broadcast single->many by using "" key)
#             keys = sorted(set(A_map.keys()) | set(B_map.keys()))
#             for k in keys:
#                 A_obj = A_map.get(k) or A_map.get("")
#                 B_obj = B_map.get(k) or B_map.get("")
#                 A_w = _tensor_from_obj(A_obj)
#                 B_w = _tensor_from_obj(B_obj)
#                 if A_w is None or B_w is None:
#                     log.debug("Skipping %s key=%s: A/B tensor not found", child_name, k)
#                     continue

#                 # handle zero-length adapters by removing wrapper aggressively (safe for plain model)
#                 if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                     log.warning("Empty/zero-dim A/B for %s key=%s — replacing wrapper with base.", child_name, k)
#                     try:
#                         setattr(parent, child_name, base)
#                         replaced += 1
#                         applied_here = 0
#                     except Exception as e:
#                         log.warning("Could not replace wrapper %s: %s", child_name, e)
#                     break  # move to next child

#                 try:
#                     # compute delta robustly
#                     delta = _compute_delta(A_w, B_w, base)
#                     # scale detection r and alpha
#                     r = A_w.shape[0] if A_w.dim() >= 1 else None
#                     scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0
#                     # apply under no_grad
#                     with torch.no_grad():
#                         base.weight.data += delta.to(base.weight.device, base.weight.dtype) * scale
#                     applied_here += 1
#                     merged += 1
#                     log.info("Merged LoRA into %s key=%s (scale=%s, delta_shape=%s)", child_name, k, scale, tuple(delta.shape))
#                 except Exception as e:
#                     log.warning("Failed computing LoRA delta for %s key=%s: %s", child_name, k, e)
#                     # continue trying other keys

#             # after keys processed, if any applied -> replace wrapper with base
#             if applied_here > 0:
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base after applying %d delta(s).", child_name, applied_here)
#                 except Exception as e:
#                     log.warning("Applied deltas but failed to replace wrapper %s: %s", child_name, e)
#             else:
#                 # no deltas applied; still try to remove wrapper for Lightning compatibility
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (no deltas applied).", child_name)
#                 except Exception as e:
#                     log.warning("Could not replace wrapper %s: %s", child_name, e)

#     # Reattach emb_unwrapped back to model if necessary (preserve wrapper object when possible)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # already mutated in-place for wrappers we replaced above; ignore attach errors
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers.", merged, replaced)
#     log.info(f"Model Structure after removing LoRA {model}")
#     return model


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> Tuple["torch.nn.Module", Dict[str, Any]]:
#     """
#     Reverse of apply_lora_to_model. Minimal-disruption strategy:
#       1) Try PEFT's merge APIs on high-level wrappers (safe).
#       2) If not available, do conservative manual merges:
#          - Only add computed LoRA delta into base.weight when base.weight.dtype is floating.
#          - If base.weight is quantized / non-floating (Byte/Int) or wrapper weight shapes mismatch,
#            skip numeric merge and replace wrapper with base_layer/module to avoid corrupting quant params.
#       3) Always replace wrapper modules with underlying base module to remove PEFT wrappers (so model is runnable).
#     Returns: (model, summary)
#       summary: {merged: int, replaced: int, skipped: int, warnings: [..], details: [..]}
#     """
#     if log is None:
#         log = logging.getLogger(__name__)

#     summary = {"merged": 0, "replaced": 0, "skipped": 0, "warnings": [], "details": []}

#     root = getattr(model, "module", model)

#     # same embedding resolver as apply_lora_to_model
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or a known embed_tokens ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # helper: attempt PEFT merge_and_unload on an object (safe)
#     def _try_peft_merge(obj, ctx_name: str) -> bool:
#         for attr in ("merge_and_unload", "merge_and_unload_legacy", "merge", "unload"):
#             fn = getattr(obj, attr, None)
#             if callable(fn):
#                 try:
#                     log.info("Calling %s() on %s", attr, ctx_name)
#                     res = fn()  # many APIs return None, some return the merged/base module
#                     summary["details"].append(f"Called {attr} on {ctx_name}")
#                     summary["merged"] += 1
#                     # if function returned a module, try to reattach above after caller handles
#                     return True
#                 except Exception as e:
#                     summary["warnings"].append(f"{ctx_name}.{attr}() raised: {e}")
#                     # continue trying other attrs
#         return False

#     # try high-level merges first (LLaMA decoder path)
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         # top-level peft wrapper might be model.embedding.model or model.embedding.model.* (PeftModelForCausalLM)
#         decoder = model.embedding.model
#         attached = False
#         # If decoder is a Peft wrapper, try calling merge_and_unload on it
#         if _try_peft_merge(decoder, "model.embedding.model"):
#             # after merge, try to reassign if merge returned something — some APIs inplace-change
#             # we still proceed to safer manual unwrapping pass later to catch nested wrappers
#             attached = True
#         # also try top-level embedding wrapper
#         if _try_peft_merge(model.embedding, "model.embedding"):
#             attached = True

#         # perform conservative unwrap / manual merge walk under decoder subtree
#         # We'll traverse decoder modules and apply manual merge only for floating base weights.
#         summary_walk = _manual_merge_walk(decoder, log, summary)  # function defined below
#         summary.update(summary_walk)
#         # ensure model.embedding.model remains set (if libra returned new module, it's usually already attached)
#         return model, summary

#     # Non-llama path: embedding container was created by apply -> there is an emb_unwrapped that got wrapped by PEFT.
#     # Try peft merge on emb_current (wrapper) and on emb_unwrapped
#     if _try_peft_merge(emb_current, f"{emb_path} (emb_current)"):
#         # PEFT merge done (or attempted). Still walk and clean wrappers to ensure no leftover fields.
#         pass
#     elif _try_peft_merge(emb_unwrapped, f"{emb_path} (emb_unwrapped)"):
#         pass

#     # if PEFT merge didn't exist/ succeed, fallback to conservative manual merging
#     summary_walk = _manual_merge_walk(emb_unwrapped, log, summary)
#     summary.update(summary_walk)

#     # Reattach candidate back to model (preserve wrapperless object)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             # try preserve wrapper object if existed
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # ignore reattach errors; model already mutated in place for replaced wrappers
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.",
#              summary.get("merged", 0), summary.get("replaced", 0), summary.get("skipped", 0))
#     return model


# Helper: manual merge walker (conservative)
# def _manual_merge_walk(root_module: "torch.nn.Module", log: Any, summary: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Walk modules under `root_module` and:
#       - For children that have .base_layer and lora_A/lora_B try to compute delta and add to base.weight
#         ONLY IF base.weight.dtype is floating (float32/float16/bfloat16).
#       - If base.weight is quantized/non-floating or shapes are incompatible, replace wrapper with base
#         (no numeric merge) to avoid corrupting quant metadata.
#       - If child has .module wrapper (PEFT/other), replace with child.module
#     Returns partial summary updates.
#     """
#     import torch
#     merged = summary.get("merged", 0)
#     replaced = summary.get("replaced", 0)
#     skipped = summary.get("skipped", 0)

#     def _is_floating_dtype(dt):
#         return dt in (torch.float32, torch.float16, torch.bfloat16)

#     def _tensor_from_obj(x):
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.Tensor):
#             return x
#         # Module: try weight param
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first parameter
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#         return None

#     def _compute_delta(A_w, B_w, base_w):
#         """
#         Robust compute similar to previous logic; returns tensor on CPU (float) if possible.
#         Will raise RuntimeError if impossible.
#         """
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # Bring tensors to float32 cpu for computation (do not change original module tensors)
#         A_f = A_w.detach().to(torch.float32).cpu()
#         B_f = B_w.detach().to(torch.float32).cpu()

#         # common: A (r, in), B (out, r) => B @ A
#         if A_f.dim() == 2 and B_f.dim() == 2 and B_f.shape[1] == A_f.shape[0]:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)

#         # try reshape inference using base shape
#         base_out = int(base_w.shape[0])
#         base_in = int(base_w.shape[1])
#         A_num = int(A_f.numel())
#         B_num = int(B_f.numel())

#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)

#         # fallbacks
#         try:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass
#         try:
#             return (A_f @ B_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass

#         # chunked heuristics (rare)
#         try:
#             A_mat = A_f if A_f.dim() == 2 else A_f.view(A_f.shape[0], -1)
#             B_mat = B_f if B_f.dim() == 2 else B_f.view(-1, B_f.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)} for base {tuple(base_w.shape)}")

#     # iterate parents so we can setattr on them
#     for parent in list(root_module.modules()):
#         for child_name, child in list(parent.named_children()):
#             # 1) If wrapper exposes PEFT API, try merge_and_unload first
#             try:
#                 if hasattr(child, "merge_and_unload") and callable(getattr(child, "merge_and_unload")):
#                     try:
#                         log.info("Calling merge_and_unload() on %s.%s", type(parent).__name__, child_name)
#                         child.merge_and_unload()
#                         # After PEFT merge, if child has module/base_layer then replace
#                         repl = getattr(child, "module", None) or getattr(child, "base_layer", None) or getattr(child, "base_model", None)
#                         if repl is not None and repl is not child:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"PEFT merged & replaced {type(parent).__name__}.{child_name}")
#                             continue
#                         else:
#                             # if merge_and_unload didn't return module, try to just remove wrapper by replacing with base if exists
#                             base = getattr(child, "base_layer", None) or getattr(child, "module", None)
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"PEFT merged (no return) and replaced {type(parent).__name__}.{child_name}")
#                                 continue
#                     except Exception as e:
#                         summary["warnings"].append(f"child.merge_and_unload failed {type(parent).__name__}.{child_name}: {e}")
#                         # fallthrough to manual strategies
#                 # 2) If there is a 'module' wrapper, unwrap it (safe)
#                 if hasattr(child, "module") and child is not getattr(child, "module"):
#                     try:
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         summary["details"].append(f"Unwrapped module {type(parent).__name__}.{child_name} -> module")
#                         continue
#                     except Exception:
#                         pass

#                 # 3) If base_layer + lora_A/lora_B perform conservative numeric merge only if base is floating dtype
#                 if hasattr(child, "base_layer") and (hasattr(child, "lora_A") or hasattr(child, "lora_B")):
#                     base = getattr(child, "base_layer", None)
#                     if base is None or not hasattr(base, "weight"):
#                         # can't merge numerically; just replace wrapper with base if possible
#                         try:
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no weight to merge)")
#                                 continue
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base")
#                             skipped += 1
#                             continue

#                     # get A/B tensors (may be ModuleDict / dict / Parameter)
#                     A_obj = getattr(child, "lora_A", None)
#                     B_obj = getattr(child, "lora_B", None)

#                     # support mappinglike or direct module
#                     def _unwrap_map(obj):
#                         out = {}
#                         if obj is None:
#                             return out
#                         if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                             out[""] = obj
#                             return out
#                         # mapping-like
#                         try:
#                             items = list(obj.items())
#                         except Exception:
#                             items = []
#                         for k, v in items:
#                             out[k] = v
#                         return out

#                     A_map = _unwrap_map(A_obj)
#                     B_map = _unwrap_map(B_obj)
#                     if not A_map or not B_map:
#                         # nothing numeric to merge; replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (empty A/B)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace empty wrapper {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # check dtype of base weight -> only attempt numeric merge for floating dtypes
#                     base_w = base.weight if hasattr(base, "weight") else None
#                     if base_w is None:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                             skipped += 1
#                         continue

#                     if not _is_floating_dtype(base_w.dtype):
#                         # quantized or non-floating base: avoid numeric merge; simply replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Skipped numeric merge for quantized base {type(parent).__name__}.{child_name}; replaced wrapper with base")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper for quantized base {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # attempt per-key merge
#                     applied_here = 0
#                     for k in sorted(set(A_map.keys()) | set(B_map.keys())):
#                         A_obj_k = A_map.get(k) or A_map.get("")
#                         B_obj_k = B_map.get(k) or B_map.get("")
#                         A_w = _tensor_from_obj(A_obj_k)
#                         B_w = _tensor_from_obj(B_obj_k)
#                         if A_w is None or B_w is None:
#                             summary["details"].append(f"Skipping key={k} for {type(parent).__name__}.{child_name}: A/B tensor not found")
#                             continue

#                         # check empty shapes
#                         if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                             # unsafe to compute; replace wrapper
#                             try:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Empty/zero-dim A/B for {type(parent).__name__}.{child_name} key={k}; replaced with base")
#                             except Exception as e:
#                                 summary["warnings"].append(f"Could not replace wrapper after empty A/B {type(parent).__name__}.{child_name}: {e}")
#                                 skipped += 1
#                             applied_here = 0
#                             break

#                         try:
#                             delta = _compute_delta(A_w, B_w, base_w)
#                             # detect r for scaling; fallback scale 1.0 if unknown
#                             r = None
#                             try:
#                                 r = int(A_w.shape[0]) if getattr(A_w, "dim", None) and A_w.dim() >= 1 else None
#                             except Exception:
#                                 r = None
#                             alpha_raw = getattr(child, "lora_alpha", None)
#                             alpha = None
#                             # attempt to normalize alpha scalar
#                             try:
#                                 if alpha_raw is None:
#                                     alpha = None
#                                 elif isinstance(alpha_raw, (int, float)):
#                                     alpha = float(alpha_raw)
#                                 elif isinstance(alpha_raw, dict):
#                                     # pick first numeric
#                                     for vv in alpha_raw.values():
#                                         if isinstance(vv, (int, float)):
#                                             alpha = float(vv)
#                                             break
#                                 elif hasattr(alpha_raw, "item"):
#                                     alpha = float(alpha_raw.item())
#                             except Exception:
#                                 alpha = None
#                             scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0

#                             with torch.no_grad():
#                                 base_w.data += delta.to(base_w.device, base_w.dtype) * float(scale)
#                             applied_here += 1
#                             merged += 1
#                             summary["details"].append(f"Merged LoRA into {type(parent).__name__}.{child_name} key={k} (scale={scale}, delta={tuple(delta.shape)})")
#                         except Exception as e:
#                             summary["warnings"].append(f"Failed computing LoRA delta for {type(parent).__name__}.{child_name} key={k}: {e}")
#                             # do not abort — try other keys

#                     # after keys processed: if we applied any merges, replace wrapper with base
#                     if applied_here > 0:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base after applying {applied_here} deltas")
#                         except Exception as e:
#                             summary["warnings"].append(f"Applied deltas but failed to replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1
#                     else:
#                         # no deltas applied -> replace wrapper anyway
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no deltas applied)")
#                         except Exception as e:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1

#                     continue  # next child

#                 # 4) base_model / model attribute replacement (PeftModel wrappers)
#                 if hasattr(child, "base_model") and getattr(child, "base_model") is not None and getattr(child, "base_model") is not child:
#                     try:
#                         setattr(parent, child_name, getattr(child, "base_model"))
#                         replaced += 1
#                         summary["details"].append(f"Replaced {type(parent).__name__}.{child_name} with base_model")
#                         continue
#                     except Exception:
#                         pass

#                 # 5) SafeModuleWrapper unwrapping
#                 cname = child.__class__.__name__.lower()
#                 if "safemodulewrapper" in cname or cname.startswith("_safemodulewrapper"):
#                     repl = getattr(child, "module", None)
#                     if repl is not None:
#                         try:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"Unwrapped SafeModuleWrapper {type(parent).__name__}.{child_name}")
#                             continue
#                         except Exception:
#                             pass

#                 # If none matched — skip safely
#                 skipped += 1
#                 summary["details"].append(f"Skipped {type(parent).__name__}.{child_name} (no wrapper/base_layer found)")
#             except Exception as e_parent_child:
#                 summary["warnings"].append(f"Error while inspecting {type(parent).__name__}.{child_name}: {e_parent_child}")
#                 skipped += 1
#                 continue

#     # update and return summary diffs
#     summary["merged"] = merged
#     summary["replaced"] = replaced
#     summary["skipped"] = skipped
#     return summary

# def merge_lora_into_base(model, log=None):
#     if log is None:
#         log = logging.getLogger(__name__)

#     # Find the PEFT-wrapped decoder (your custom path)
#     if hasattr(model, "embedding") and hasattr(model.embedding, "model"):
#         decoder = model.embedding.model

#         # Check if it's a PEFT model
#         if hasattr(decoder, "merge_and_unload"):
#             try:
#                 log.info("Merging LoRA using PEFT's native merge (this works)")
#                 merged_decoder = decoder.merge_and_unload()
#                 model.embedding.model = merged_decoder
#                 del decoder  # frees the old PEFT model + all LoRA tensors
#                 if torch.cuda.is_available():
#                     torch.cuda.empty_cache()
#                 log.info("LoRA merged successfully — no warnings, no errors")
#                 return model
#             except Exception as e:
#                 log.error(f"PEFT merge failed: {e}")

#     # Fallback: manual merge (your old code) — but now it will find nothing, so skip
#     log.info("No PEFT wrapper found — skipping manual merge (already clean or not needed)")
#     return model

def _5bcad34078d1(_ea3c84952bcb, _2f287bd6bcdf=_a51422e3e83d):
    if _2f287bd6bcdf is _a51422e3e83d:
        _2f287bd6bcdf = _8f07b6719b82._cf30cbd0baa9(__name__)

    _0d03472b749a = _a61b6f6798fd(_ea3c84952bcb, "module", _ea3c84952bcb)

    def _011f2b09b560(_e5cde0584448, _78fc09be6a8b):
        if _7a2ba19040bc(_e5cde0584448, "merge_and_unload"):
            _2f287bd6bcdf._98a0d26c3dbe("Merging LoRA via PEFT merge_and_unload")
            _1395a830acfe = _e5cde0584448._14bce7ac3ab7()
            _78fc09be6a8b(_1395a830acfe)
            if _ace2a706caca._d6bc337f8215._b07c92d1cb91():
                _ace2a706caca._d6bc337f8215._bd8c3501dd43()
            _2f287bd6bcdf._98a0d26c3dbe("LoRA merged successfully")
            return _a0e6a52e6576
        return _877c64c361ea

    # Decoder path (Lightning-safe)
    if _7a2ba19040bc(_0d03472b749a, "embedding") and _7a2ba19040bc(_0d03472b749a._d67bea085101, "model"):
        if _71ea409f6cd4(
            _0d03472b749a._d67bea085101._ea3c84952bcb,
            lambda _5bdd15e4f103: _1ec988e8f13f(_0d03472b749a._d67bea085101, "model", _5bdd15e4f103),
        ):
            return _ea3c84952bcb

    # Embedding path
    if _7a2ba19040bc(_0d03472b749a, "embedding"):
        if _71ea409f6cd4(
            _0d03472b749a._d67bea085101,
            lambda _5bdd15e4f103: _1ec988e8f13f(_0d03472b749a, "embedding", _5bdd15e4f103),
        ):
            return _ea3c84952bcb

    _2f287bd6bcdf._98a0d26c3dbe("No PEFT LoRA adapters found — nothing to merge")
    return _ea3c84952bcb


def _7c488c1660f9(_ea3c84952bcb: "torch.nn.Module") -> "torch.nn.Module":
    """
    Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
    Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
    Leaves LoRA and trainable modules untouched.
    Safe: skips missing weights or broken layers automatically.
    """
    import _4366ea870d0c
    import _ace2a706caca
    import _84aeef4d54d5 as _5d8c8e5ca4ce

    _e2342c9e6f2e = _9cbc177b34f0(_ea3c84952bcb._2368a971a394())[::-1]  # bottom-up traversal

    for _cc0f685166d8, _eb13d7c58830 in _e2342c9e6f2e:
        if _f716567cce9b(_eb13d7c58830, (_ace2a706caca._e8f7c0dca7e6._7780e4460f59, _ace2a706caca._e8f7c0dca7e6._561ab149f502)):
            # Skip LoRA or trainable layers
            if "lora" in _cc0f685166d8._5d6fc1f32287() or _523e6ff8f33f(_82d8bb4ce67f._6d9835de8f6e for _82d8bb4ce67f in _eb13d7c58830._6f71467b4bb4()):
                continue

            try:
                _89a3d68035ec = "nf4" if _f716567cce9b(_eb13d7c58830, _ace2a706caca._e8f7c0dca7e6._7780e4460f59) else "fp4"

                _867e6c8f3169 = _a61b6f6798fd(_eb13d7c58830, "in_features", _eb13d7c58830._47ae49c4c53a._d1dd5389c935[1])
                _762a325b5a4a = _a61b6f6798fd(_eb13d7c58830, "out_features", _eb13d7c58830._47ae49c4c53a._d1dd5389c935[0])

                _8a369731ba41 = _5d8c8e5ca4ce._e8f7c0dca7e6._da0aac4aab5b(
                    _867e6c8f3169, _762a325b5a4a,
                    _a4718a108cd5=_eb13d7c58830._a4718a108cd5 is not _a51422e3e83d,
                    _4e544eb2f51d=_d95f28470fbb(),
                    _89a3d68035ec=_89a3d68035ec
                )

                if _eb13d7c58830._47ae49c4c53a is _a51422e3e83d or not _7a2ba19040bc(_eb13d7c58830._47ae49c4c53a, "data"):
                    continue

                _8a369731ba41._47ae49c4c53a._a578c949b393._194a9a5a5dbc(_eb13d7c58830._47ae49c4c53a._a578c949b393)
                if _eb13d7c58830._a4718a108cd5 is not _a51422e3e83d:
                    _8a369731ba41._a4718a108cd5._a578c949b393._194a9a5a5dbc(_eb13d7c58830._a4718a108cd5._a578c949b393)

                # Replace in parent
                _2d6057f8c77b = _ea3c84952bcb
                _5f4e066395a2 = _cc0f685166d8._925ca7f915b1(".")
                for _82d8bb4ce67f in _5f4e066395a2[:-1]:
                    _2d6057f8c77b = _a61b6f6798fd(_2d6057f8c77b, _82d8bb4ce67f)
                _1ec988e8f13f(_2d6057f8c77b, _5f4e066395a2[-1], _8a369731ba41)

                del _eb13d7c58830
                _4366ea870d0c._871e42a6e65e()
                if _ace2a706caca._d6bc337f8215._b07c92d1cb91():
                    _ace2a706caca._d6bc337f8215._bd8c3501dd43()

            except _d2cc34cc5f93 as _994b1eb9a3c6:
                _dff18d813a05(f"[WARN] Skipped quantizing {_cc0f685166d8}: {_994b1eb9a3c6}")

    return _ea3c84952bcb


# def quantize_frozen_linear_layers(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Manually quantize all frozen torch.nn.Linear layers in the given model to 4-bit precision using bitsandbytes.
#     Leaves all LoRA or trainable modules untouched (those containing 'lora' in name or requiring gradients).

#     Args:
#         model (torch.nn.Module): The model instance to quantize (after LoRA is applied).

#     Returns:
#         torch.nn.Module: The same model instance with frozen Linear layers replaced by 4-bit quantized versions.
#     """
#     import bitsandbytes as bnb
#     from bitsandbytes.nn import Params4bit

#     modules = list(model.named_modules())  # snapshot to avoid OrderedDict mutation

#     for name, module in modules:
#         # Quantize only standard Linear layers that are frozen
#         if isinstance(module, torch.nn.Linear):
#             if "lora" in name.lower() or any(param.requires_grad for param in module.parameters()):
#                 continue  # skip LoRA or active trainable layers

#             # Create quantized Linear4bit replacement
#             quantized = bnb.nn.Linear4bit(
#                 module.in_features,
#                 module.out_features,
#                 bias=module.bias is not None,
#                 compute_dtype=get_supported_compute_dtype(),
#                 compress_statistics=True,
#                 quant_type="nf4"
#             )

#             # Properly quantize and assign weight
#             quantized.weight = Params4bit(
#                 module.weight.data,
#                 compress_statistics=True,
#                 quant_type="nf4",
#                 quant_storage=torch.uint8
#             )

#             # Copy bias if exists
#             if module.bias is not None:
#                 quantized.bias = module.bias.clone()

#             # Replace the original module in its parent container
#             parent = model
#             parts = name.split(".")
#             for p in parts[:-1]:
#                 parent = getattr(parent, p)
#             setattr(parent, parts[-1], quantized)

#     return model

def _5bcad34078d1(_ea3c84952bcb: "torch.nn.Module", _2f287bd6bcdf: "Any" = _a51422e3e83d) -> "torch.nn.Module":
    """
    Merge LoRA adapters into base layers (robust heuristics) and then aggressively
    remove/unwrap PEFT/LoRA wrapper objects so the final model no longer reports
    "LoRA present" / "PEFT present".
    """
    if _2f287bd6bcdf is _a51422e3e83d:
        _2f287bd6bcdf = _8f07b6719b82._cf30cbd0baa9(__name__)

    _1395a830acfe = 0
    _9cba7bc707db = 0
    _87533fb4bea4 = []

    # helper to get first tensor-like from many container types
    def _af699ab665ea(_d84358105a73):
        if _d84358105a73 is _a51422e3e83d:
            return _a51422e3e83d
        if _f716567cce9b(_d84358105a73, _ace2a706caca._e8f7c0dca7e6._767cdcbf205f):
            return _d84358105a73._a578c949b393
        if _f716567cce9b(_d84358105a73, _ace2a706caca._12d05e65bbc5):
            return _d84358105a73
        if _f716567cce9b(_d84358105a73, _ace2a706caca._e8f7c0dca7e6._368e53f0c577):
            _5a8535a188cf = _a61b6f6798fd(_d84358105a73, "weight", _a51422e3e83d)
            if _f716567cce9b(_5a8535a188cf, _ace2a706caca._e8f7c0dca7e6._767cdcbf205f):
                return _5a8535a188cf._a578c949b393
            try:
                _82d8bb4ce67f = _e7fb01b45087(_d84358105a73._6f71467b4bb4())
                return _82d8bb4ce67f._a578c949b393
            except _d2cc34cc5f93:
                pass
            try:
                _a54149e168fb = _e7fb01b45087(_d84358105a73._b4a0f64b9804())
                return _a54149e168fb
            except _d2cc34cc5f93:
                pass
            return _a51422e3e83d
        # dict-like or ModuleDict-like: return first tensor we can
        try:
            for _bd9b55510a53 in _a61b6f6798fd(_d84358105a73, "values", lambda: [])():
                _acb0e614ca45 = _8dfc5ee5dccc(_bd9b55510a53)
                if _acb0e614ca45 is not _a51422e3e83d:
                    return _acb0e614ca45
        except _d2cc34cc5f93:
            pass
        try:
            for _, _bd9b55510a53 in _a61b6f6798fd(_d84358105a73, "items", lambda: [])():
                _acb0e614ca45 = _8dfc5ee5dccc(_bd9b55510a53)
                if _acb0e614ca45 is not _a51422e3e83d:
                    return _acb0e614ca45
        except _d2cc34cc5f93:
            pass
        return _a51422e3e83d

    def _6328e40faf84(_a333ccfc5496: _ace2a706caca._12d05e65bbc5, _a9d9f2f71a3b: _ace2a706caca._12d05e65bbc5, _5942daae3ba4: _ace2a706caca._12d05e65bbc5):
        _23040e9b865c = _a333ccfc5496._cbf4e94e526b()._09c419466158()
        _77b6ff0540b4 = _a9d9f2f71a3b._cbf4e94e526b()._09c419466158()
        # common 2D case
        if _23040e9b865c._95acba49897d() == 2 and _77b6ff0540b4._95acba49897d() == 2 and _77b6ff0540b4._d1dd5389c935[1] == _23040e9b865c._d1dd5389c935[0]:
            return _77b6ff0540b4 @ _23040e9b865c
        # try reshape inference based on base shape
        _cfa7cb8877c8 = _3b9c6678cf1b(_5942daae3ba4._d1dd5389c935[0])
        _9608d650339c = _3b9c6678cf1b(_5942daae3ba4._d1dd5389c935[1]) if _5942daae3ba4._95acba49897d() > 1 else 1
        _9e1175ac9288 = _23040e9b865c._407274d91620()
        _54003ccb1d82 = _77b6ff0540b4._407274d91620()
        if _cfa7cb8877c8 > 0 and _9608d650339c > 0:
            if (_54003ccb1d82 % _cfa7cb8877c8 == 0):
                _f57b055844e4 = _54003ccb1d82 // _cfa7cb8877c8
                if _f57b055844e4 > 0 and (_9e1175ac9288 == _f57b055844e4 * _9608d650339c):
                    _3fe2c79981ee = _23040e9b865c._169dbd85baaf(_f57b055844e4, _9608d650339c) if _23040e9b865c._95acba49897d() == 1 else _23040e9b865c
                    _2ad5f17e65cf = _77b6ff0540b4._169dbd85baaf(_cfa7cb8877c8, _f57b055844e4) if _77b6ff0540b4._95acba49897d() == 1 else _77b6ff0540b4
                    if _2ad5f17e65cf._d1dd5389c935[1] == _3fe2c79981ee._d1dd5389c935[0]:
                        return _2ad5f17e65cf @ _3fe2c79981ee
            if (_9e1175ac9288 % _9608d650339c == 0):
                _f57b055844e4 = _9e1175ac9288 // _9608d650339c
                if _f57b055844e4 > 0 and (_54003ccb1d82 == _cfa7cb8877c8 * _f57b055844e4):
                    _3fe2c79981ee = _23040e9b865c._169dbd85baaf(_f57b055844e4, _9608d650339c) if _23040e9b865c._95acba49897d() == 1 else _23040e9b865c
                    _2ad5f17e65cf = _77b6ff0540b4._169dbd85baaf(_cfa7cb8877c8, _f57b055844e4) if _77b6ff0540b4._95acba49897d() == 1 else _77b6ff0540b4
                    if _2ad5f17e65cf._d1dd5389c935[1] == _3fe2c79981ee._d1dd5389c935[0]:
                        return _2ad5f17e65cf @ _3fe2c79981ee
        # fallback tries
        try:
            return _77b6ff0540b4 @ _23040e9b865c
        except _d2cc34cc5f93:
            pass
        # chunked heuristics
        try:
            _3fe2c79981ee = _23040e9b865c if _23040e9b865c._95acba49897d() == 2 else _23040e9b865c._169dbd85baaf(_23040e9b865c._d1dd5389c935[0], -1)
            _2ad5f17e65cf = _77b6ff0540b4 if _77b6ff0540b4._95acba49897d() == 2 else _77b6ff0540b4._169dbd85baaf(-1, _77b6ff0540b4._d1dd5389c935[0])
        except _d2cc34cc5f93 as _994b1eb9a3c6:
            raise _d11b6c62ad94(f"cannot promote A/B to 2D: {_994b1eb9a3c6}")
        _2ae09c6079d3 = _3fe2c79981ee._d1dd5389c935[0]
        _27b235ff4f8b = _2ad5f17e65cf._d1dd5389c935[1]
        if _2ae09c6079d3 and _27b235ff4f8b and (_27b235ff4f8b % _2ae09c6079d3 == 0):
            _b3b01c90bbcb = _27b235ff4f8b // _2ae09c6079d3
            _c7e37735e1ac = _2ad5f17e65cf._d1dd5389c935[0]
            _c5066a74f101 = _2ad5f17e65cf._169dbd85baaf(_c7e37735e1ac, _b3b01c90bbcb, _2ae09c6079d3)
            _7747db9a7138 = _a51422e3e83d
            for _a4fca43e2598 in _a94f5b4f7eb5(_b3b01c90bbcb):
                _afae546fa8d6 = _c5066a74f101[:, _a4fca43e2598, :] @ _3fe2c79981ee
                _7747db9a7138 = _afae546fa8d6 if _7747db9a7138 is _a51422e3e83d else (_7747db9a7138 + _afae546fa8d6)
            return _7747db9a7138
        if _2ae09c6079d3 and _27b235ff4f8b and (_2ae09c6079d3 % _27b235ff4f8b == 0):
            _b3b01c90bbcb = _2ae09c6079d3 // _27b235ff4f8b
            _9c6f38ed640a = _3fe2c79981ee._d1dd5389c935[1]
            _a08e666ab252 = _3fe2c79981ee._169dbd85baaf(_b3b01c90bbcb, _27b235ff4f8b, _9c6f38ed640a)
            _7747db9a7138 = _a51422e3e83d
            for _a4fca43e2598 in _a94f5b4f7eb5(_b3b01c90bbcb):
                _afae546fa8d6 = _2ad5f17e65cf @ _a08e666ab252[_a4fca43e2598]
                _7747db9a7138 = _afae546fa8d6 if _7747db9a7138 is _a51422e3e83d else (_7747db9a7138 + _afae546fa8d6)
            return _7747db9a7138
        raise _d11b6c62ad94(f"unsupported A/B shapes A={_f631a26fd9c3(_a333ccfc5496._d1dd5389c935)} B={_f631a26fd9c3(_a9d9f2f71a3b._d1dd5389c935)} for base {_f631a26fd9c3(_5942daae3ba4._d1dd5389c935)}")

    # gather parents to allow setattr replacements
    _e001fa9f9723 = []
    for _2d6057f8c77b in _ea3c84952bcb._e2342c9e6f2e():
        try:
            for _efbf9aee4680, _155ef56e9c1a in _9cbc177b34f0(_2d6057f8c77b._adddcc71dce2()):
                _e001fa9f9723._f61c115e9fef((_2d6057f8c77b, _efbf9aee4680, _155ef56e9c1a))
        except _d2cc34cc5f93:
            continue

    # --- manual merge (robust attempts) ---
    for _2d6057f8c77b, _efbf9aee4680, _155ef56e9c1a in _e001fa9f9723:
        try:
            # identify base candidate under wrapper
            _c32b60691c02 = _a61b6f6798fd(_155ef56e9c1a, "base_layer", _a51422e3e83d) or _a61b6f6798fd(_155ef56e9c1a, "module", _a51422e3e83d) or _a61b6f6798fd(_155ef56e9c1a, "model", _a51422e3e83d)
            if _c32b60691c02 is _a51422e3e83d or not _7a2ba19040bc(_c32b60691c02, "weight"):
                # if child itself is base-like with .weight, skip (nothing to merge)
                if _7a2ba19040bc(_155ef56e9c1a, "weight") and _f716567cce9b(_a61b6f6798fd(_155ef56e9c1a, "weight"), _ace2a706caca._e8f7c0dca7e6._767cdcbf205f):
                    continue
                # otherwise there's nothing we can merge here
                continue

            # locate A/B containers in child or nested attrs
            _6b01bc25acde = {}
            _80faf1836be9 = {}
            _a35bf9e2d07a = {}
            # candidate holders
            _f64ae2078994 = [_155ef56e9c1a]
            for _f9aa6d1316a8 in ("module", "base_layer", "lora_adapter", "adapter", "model", "base_model"):
                _bd9b55510a53 = _a61b6f6798fd(_155ef56e9c1a, _f9aa6d1316a8, _a51422e3e83d)
                if _bd9b55510a53 is not _a51422e3e83d and _bd9b55510a53 is not _155ef56e9c1a:
                    _f64ae2078994._f61c115e9fef(_bd9b55510a53)

            for _899bbff391bd in _f64ae2078994:
                if _7a2ba19040bc(_899bbff391bd, "lora_A"):
                    _264dd87947ae = _a61b6f6798fd(_899bbff391bd, "lora_A")
                    if _f716567cce9b(_264dd87947ae, _9f1b04ce9db9):
                        for _32a9fbcd9273, _bd9b55510a53 in _264dd87947ae._dc53f2774594():
                            _6b01bc25acde[_32a9fbcd9273] = _bd9b55510a53
                    else:
                        _6b01bc25acde["default"] = _264dd87947ae
                if _7a2ba19040bc(_899bbff391bd, "lora_B"):
                    _1bb20704ee9a = _a61b6f6798fd(_899bbff391bd, "lora_B")
                    if _f716567cce9b(_1bb20704ee9a, _9f1b04ce9db9):
                        for _32a9fbcd9273, _bd9b55510a53 in _1bb20704ee9a._dc53f2774594():
                            _80faf1836be9[_32a9fbcd9273] = _bd9b55510a53
                    else:
                        _80faf1836be9["default"] = _1bb20704ee9a
                if _7a2ba19040bc(_899bbff391bd, "adapters") and _f716567cce9b(_a61b6f6798fd(_899bbff391bd, "adapters"), _9f1b04ce9db9):
                    for _32a9fbcd9273, _bd9b55510a53 in _a61b6f6798fd(_899bbff391bd, "adapters")._dc53f2774594():
                        if _7a2ba19040bc(_bd9b55510a53, "lora_A"):
                            _6b01bc25acde[_32a9fbcd9273] = _a61b6f6798fd(_bd9b55510a53, "lora_A")
                        if _7a2ba19040bc(_bd9b55510a53, "lora_B"):
                            _80faf1836be9[_32a9fbcd9273] = _a61b6f6798fd(_bd9b55510a53, "lora_B")
                if _7a2ba19040bc(_899bbff391bd, "lora_alpha"):
                    _a35bf9e2d07a["default"] = _a61b6f6798fd(_899bbff391bd, "lora_alpha")
                if _7a2ba19040bc(_899bbff391bd, "alpha"):
                    # some libs store alpha under alpha
                    _a35bf9e2d07a["default"] = _a61b6f6798fd(_899bbff391bd, "alpha")

            if not _6b01bc25acde and not _80faf1836be9:
                _87533fb4bea4._f61c115e9fef(f"{_2d6057f8c77b._7ac3ff53863a.__name__}.{_efbf9aee4680}")
                continue

            _719bb01e96ef = _7136eb7278a9(_663d262edbc9(_9cbc177b34f0(_6b01bc25acde._719bb01e96ef()) + _9cbc177b34f0(_80faf1836be9._719bb01e96ef()) + ["default"]))
            _c0a24747135b = 0
            for _32a9fbcd9273 in _719bb01e96ef:
                _c0df830824b7 = _6b01bc25acde._85a26a0fb3c1(_32a9fbcd9273) or _6b01bc25acde._85a26a0fb3c1("default")
                _6d080ad2f334 = _80faf1836be9._85a26a0fb3c1(_32a9fbcd9273) or _80faf1836be9._85a26a0fb3c1("default")
                _a333ccfc5496 = _8dfc5ee5dccc(_c0df830824b7)
                _a9d9f2f71a3b = _8dfc5ee5dccc(_6d080ad2f334)
                if _a333ccfc5496 is _a51422e3e83d or _a9d9f2f71a3b is _a51422e3e83d:
                    _2f287bd6bcdf._da8a2153bf53("Skipping %s.%s key=%s (no tensor)", _2d6057f8c77b._7ac3ff53863a.__name__, _efbf9aee4680, _32a9fbcd9273)
                    continue
                if _a333ccfc5496._407274d91620() == 0 or _a9d9f2f71a3b._407274d91620() == 0:
                    _2f287bd6bcdf._77070723aefd("Empty/zero-dim A/B for %s.%s key=%s — replacing wrapper with base.", _2d6057f8c77b._7ac3ff53863a.__name__, _efbf9aee4680, _32a9fbcd9273)
                    try:
                        _1ec988e8f13f(_2d6057f8c77b, _efbf9aee4680, _c32b60691c02)
                        _9cba7bc707db += 1
                    except _d2cc34cc5f93 as _994b1eb9a3c6:
                        _2f287bd6bcdf._77070723aefd("Could not replace wrapper %s.%s: %s", _2d6057f8c77b._7ac3ff53863a.__name__, _efbf9aee4680, _994b1eb9a3c6)
                    _c0a24747135b = 0
                    break

                try:
                    _7747db9a7138 = _40af51bb50d0(_a333ccfc5496, _a9d9f2f71a3b, _c32b60691c02._47ae49c4c53a)
                except _d2cc34cc5f93 as _994b1eb9a3c6:
                    _2f287bd6bcdf._77070723aefd("Failed computing LoRA delta for %s.%s key=%s: %s", _2d6057f8c77b._7ac3ff53863a.__name__, _efbf9aee4680, _32a9fbcd9273, _994b1eb9a3c6)
                    _7747db9a7138 = _a51422e3e83d

                if _7747db9a7138 is _a51422e3e83d:
                    continue

                # alpha scaling
                _4a8141304c0e = _a35bf9e2d07a._85a26a0fb3c1(_32a9fbcd9273) or _a35bf9e2d07a._85a26a0fb3c1("default")
                _152bc6a92b76 = 1.0
                try:
                    if _4a8141304c0e is not _a51422e3e83d:
                        _a903cd74cb47 = _09c419466158(_4a8141304c0e._c077551a82a2()) if _f716567cce9b(_4a8141304c0e, _ace2a706caca._e8f7c0dca7e6._767cdcbf205f) else _09c419466158(_4a8141304c0e)
                        _f57b055844e4 = _a333ccfc5496._d1dd5389c935[0] if _a61b6f6798fd(_a333ccfc5496, "dim", lambda: 0)() > 0 else _a51422e3e83d
                        if _f57b055844e4:
                            _152bc6a92b76 = _a903cd74cb47 / _09c419466158(_f57b055844e4)
                except _d2cc34cc5f93:
                    _152bc6a92b76 = 1.0

                # apply
                try:
                    with _ace2a706caca._31596667f595():
                        _c32b60691c02._47ae49c4c53a._a578c949b393 = _c32b60691c02._47ae49c4c53a._a578c949b393 + (_7747db9a7138._d39e22aa48bb(_c32b60691c02._47ae49c4c53a._c0e71180ad2e, _ace2a706caca._4ff5fa947cfb) * _152bc6a92b76)._d39e22aa48bb(_c32b60691c02._47ae49c4c53a._6082d97556c6)
                    _1395a830acfe += 1
                    _c0a24747135b += 1
                    _2f287bd6bcdf._98a0d26c3dbe("Merged LoRA into %s.%s key=%s (scale=%s, delta_shape=%s)", _2d6057f8c77b._7ac3ff53863a.__name__, _efbf9aee4680, _32a9fbcd9273, _152bc6a92b76, _f631a26fd9c3(_7747db9a7138._d1dd5389c935) if _7a2ba19040bc(_7747db9a7138, "shape") else ())
                except _d2cc34cc5f93 as _994b1eb9a3c6:
                    _2f287bd6bcdf._77070723aefd("Failed applying delta into base for %s.%s key=%s: %s", _2d6057f8c77b._7ac3ff53863a.__name__, _efbf9aee4680, _32a9fbcd9273, _994b1eb9a3c6)
                    continue

            # after processing keys, attempt to replace wrapper with base
            try:
                _1ec988e8f13f(_2d6057f8c77b, _efbf9aee4680, _c32b60691c02)
                _9cba7bc707db += 1
            except _d2cc34cc5f93 as _994b1eb9a3c6:
                _2f287bd6bcdf._77070723aefd("Applied deltas but failed to replace wrapper %s.%s: %s", _2d6057f8c77b._7ac3ff53863a.__name__, _efbf9aee4680, _994b1eb9a3c6)

        except _d2cc34cc5f93 as _994b1eb9a3c6:
            _2f287bd6bcdf._77070723aefd("Unexpected failure merging %s.%s: %s", _2d6057f8c77b._7ac3ff53863a.__name__, _a61b6f6798fd(_155ef56e9c1a, "__class__", _4586c0afec66(_155ef56e9c1a)).__name__, _994b1eb9a3c6)
            continue

    # --- FINAL CLEANUP PASS: unwrap any remaining PEFT/Lora wrappers and remove LoRA attrs ---
    def _8fea175ef0a7(_0d03472b749a):
        nonlocal _9cba7bc707db
        for _2d6057f8c77b in _9cbc177b34f0(_0d03472b749a._e2342c9e6f2e()):
            try:
                for _cc0f685166d8, _155ef56e9c1a in _9cbc177b34f0(_2d6057f8c77b._adddcc71dce2()):
                    try:
                        _2a433f36f031 = _155ef56e9c1a._7ac3ff53863a.__name__
                        # 1) If wrapper has merge_and_unload or merge_and_unload() try it
                        try:
                            if _7a2ba19040bc(_155ef56e9c1a, "merge_and_unload"):
                                try:
                                    _8eaf344a8336 = _155ef56e9c1a._14bce7ac3ab7()
                                    # merge_and_unload sometimes returns a replacement module
                                    if _8eaf344a8336 is not _a51422e3e83d and _8eaf344a8336 is not _155ef56e9c1a:
                                        _1ec988e8f13f(_2d6057f8c77b, _cc0f685166d8, _8eaf344a8336)
                                        _9cba7bc707db += 1
                                        continue
                                except _d2cc34cc5f93:
                                    # ignore failing merge_and_unload
                                    pass
                            # sometimes wrapper is PeftModelForCausalLM or LoraModel
                            if "Peft" in _2a433f36f031 or "Lora" in _2a433f36f031 or "PeftModel" in _2a433f36f031:
                                _9e1fc8679a12 = _a61b6f6798fd(_155ef56e9c1a, "base_model", _a51422e3e83d) or _a61b6f6798fd(_155ef56e9c1a, "module", _a51422e3e83d) or _a61b6f6798fd(_155ef56e9c1a, "model", _a51422e3e83d)
                                if _9e1fc8679a12 is not _a51422e3e83d and _9e1fc8679a12 is not _155ef56e9c1a:
                                    _1ec988e8f13f(_2d6057f8c77b, _cc0f685166d8, _9e1fc8679a12)
                                    _9cba7bc707db += 1
                                    continue
                        except _d2cc34cc5f93:
                            pass

                        # 2) Remove lora attrs if present on child (making it plain)
                        for _65234dafad22 in ("lora_A", "lora_B", "lora_alpha", "adapters", "peft_config", "lora_dropout", "base_layer"):
                            if _7a2ba19040bc(_155ef56e9c1a, _65234dafad22):
                                try:
                                    _21ae66677b49(_155ef56e9c1a, _65234dafad22)
                                except _d2cc34cc5f93:
                                    try:
                                        _1ec988e8f13f(_155ef56e9c1a, _65234dafad22, _a51422e3e83d)
                                    except _d2cc34cc5f93:
                                        pass
                        # 3) If child has nested wrappers, try to reattach its inner module
                        if _7a2ba19040bc(_155ef56e9c1a, "module") and _155ef56e9c1a is not _a61b6f6798fd(_155ef56e9c1a, "module"):
                            try:
                                _1ec988e8f13f(_2d6057f8c77b, _cc0f685166d8, _a61b6f6798fd(_155ef56e9c1a, "module"))
                                _9cba7bc707db += 1
                                continue
                            except _d2cc34cc5f93:
                                pass
                    except _d2cc34cc5f93:
                        continue
            except _d2cc34cc5f93:
                continue

    _d8363556dda3(_ea3c84952bcb)

    # final parameter freezing: ensure LoRA params (if any) are not left trainable and normal params are frozen unless explicitly lora
    try:
        for _52fd42b72fcb, _82d8bb4ce67f in _ea3c84952bcb._4ae136d00245():
            if "lora" in _52fd42b72fcb._5d6fc1f32287():
                _82d8bb4ce67f._6d9835de8f6e = _a0e6a52e6576
            else:
                _82d8bb4ce67f._6d9835de8f6e = _877c64c361ea
    except _d2cc34cc5f93:
        pass

    _2f287bd6bcdf._98a0d26c3dbe("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.", _1395a830acfe, _9cba7bc707db, _098ff4aa9e03(_87533fb4bea4))
    if _ace2a706caca._d6bc337f8215._b07c92d1cb91():
        _ace2a706caca._d6bc337f8215._bd8c3501dd43()
        _ace2a706caca._d6bc337f8215._73846978b427()
    _4366ea870d0c._871e42a6e65e()
    if _87533fb4bea4:
        _2f287bd6bcdf._da8a2153bf53("Skipped modules (no A/B found): %s", _87533fb4bea4[:200])
    return _ea3c84952bcb

_0902424f979c = [
    'CustomFSDPStrategy',
    'OptunaLoggingCallback',
    'GPUUsagePruneCallback',
    'adjust_local_gpu_rank',
    'get_device_info',
    'remove_files_except',
    'load_checkpoint_with_fsdp',
    'dequantize_bnb_model',
    'manual_dequantize',
    'get_trainable_parameters',
    'get_target_modules',
    'clear_gpu_and_cpu_resources',
    'calculate_model_size_in_gb',
    'get_model_summary',
    'get_devices_for_trainer',
    'get_supported_compute_dtype',
    'is_duplicate',
    'NoDuplicateSampler',
    'gamma_for_tpe_sampler',
    'property_validation',
    'get_lora_config',
    'apply_lora_to_model',
    'merge_lora_into_base',
    'quantize_model_using_bnb',
]