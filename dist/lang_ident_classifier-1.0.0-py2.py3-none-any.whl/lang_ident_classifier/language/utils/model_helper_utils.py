# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_helper_utils.py
# @Time             : 2025-10-27 12:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _bec2aa274f7a
from _ef1eb2e213c9 import _ef1eb2e213c9, _5777a66d1b55
from functools import _98a68ec5ef00
import copy
import _2dfbc3ebb3a1
from _189e7eb7a25c import _189e7eb7a25c
import inspect
import json
from _5cf4a704967f import _e155f644eacc
import _5cf4a704967f
import _f70ba7fd7e18
import random
import re
import _2ec0692c6156
import _6d4d13666d6f
import _e0a2b4c59f9f
import sys
import threading
import time
import _f26d5a5fa816
import _57786bd79a66
import _25d84519237f
from collections import _4715e93ca17f
import os
import _4f2159e0c5ed as _ea3e74e4614c
from _5730314a88de import _e31f412b72d7
from typing import _7952803bd46e, _c013f52869a8, _1e6f208e7211, _4231149de517, _bb75be416eb8, _faac3ece906c
from _0f048559fef8 import _deb95895f6f0, _d0d7c4f7344b
from _c761a02426a8 import _5e59c46d7374
import _5b04d2c831a6._89e1e9163230._62c07435005a
import _87cbac691893
from _84e023a9505f._956b664ba892 import _c0f52e5e1451
import _d81d93427c1a
_6b9f713b3172 = _d81d93427c1a._a6a57237a415._3b67608be895()
if _6b9f713b3172:
    import _c53169b2a439 as _2a16287f21e3
import _d81d93427c1a._667e2515994d
import _d81d93427c1a._667e2515994d._2ac117fb6665
from _d81d93427c1a._667e2515994d._2ac117fb6665 import _6e49fbd4f264, _a46f6812b569, _9011903cfa8c
from _d81d93427c1a._667e2515994d._2ac117fb6665._3a28676a8829 import _2424bee156df
from _d81d93427c1a._667e2515994d._2ac117fb6665._3a28676a8829 import _768c898456dd
import _e2bbc1e15acb as _4bf225bad710
import _e6a89c5eff0d as _332dbea877d9
from _08d9a6359f28 import _222d4b01528c, _ef4513427525, _a76bf7f4a7b0, _4e6012ee4555, _f13fcd4744ed
from _08d9a6359f28 import _5dc5911b24ea
import _5b04d2c831a6
from _5b04d2c831a6._0b62b21a87a8 import _0a22f2ada9ee
from _d81d93427c1a import _4d242564a685, _8261f4fded78
from _e2bbc1e15acb import _b4b9917f122c
from _e2bbc1e15acb._02eed6f14544 import _f8f12d6e7c93
from _a9e1504f761e import _c9e3f7166419, _d38648fc3843, _144c916d119f
from _a9e1504f761e import _0918f15172d5, _67647366a089
from _e2bbc1e15acb._02eed6f14544._9d2725eba02c import _650b8ae8b638
from _d81d93427c1a._667e2515994d._2ac117fb6665 import _b6d8ac7254ee
from _d81d93427c1a._667e2515994d._2ac117fb6665 import _7c3d34fa48f6, _83d7f7943fa0
from _d81d93427c1a._667e2515994d._2ac117fb6665._42336d088ddf import _5a18a865df3f
from _d81d93427c1a._a28ffe49750d import _f5d028421b7f
from _e2bbc1e15acb._02eed6f14544._d3a3a8313a70._2759c532b618 import _e1770d5db913
from _934dcd66e035._5dd12fb4fedc._fcdeec842aab._87c35747c648 import _f0c9c05c105e
from _934dcd66e035._5dd12fb4fedc._fcdeec842aab._fbd32457377b import _9c0ff12e4d00


# Helper functions/classes extracted from original module
# class CustomFSDPStrategy(FSDPStrategy):
#     def __init__(self, ig_params, ig_modules=None):
#         super().__init__(sharding_strategy="FULL_SHARD",
#                          cpu_offload=CPUOffload(offload_params=False),  # Explicit CPU offload  # Move non-trainable parameters to CPU
#                         #  mixed_precision=MixedPrecision(param_dtype=torch.float16,   # Use bfloat16 for parameters
#                         #                                 reduce_dtype=torch.float16,   # Keep reduction in float32 for stability
#                         #                                 buffer_dtype=torch.float16,  # Buffers in bfloat16
#                         #                                 ),
#                          auto_wrap_policy="TRANSFORMER_BASED_WRAP",  # Auto-wrap transformer layers
#                         #  auto_wrap_policy=transformer_auto_wrap_policy,
#                         #  auto_wrap_policy=custom_wrap_policy(min_num_params=100_000),
#                         #  state_dict_type="sharded" if torch.cuda.device_count() > 1 else "full",
#                         **{"static_graph": False, # Lightning optimization hint
#                            "forward_prefetch": False # Helps overlap compute/comm
#                         }
#                         )
#         # self.cpu_offload = False
#         # fsdp_args = {"use_orig_params": True, "ignored_parameters": ig_params}
#         # fsdp_args = {"use_orig_params": True, "ignored_states": ig_params}
#         fsdp_args = {
#             "use_orig_params": True,  # Maintain original parameter references
#             "ignored_states": ig_params,  # Ignore specific states (if defined)
#         }
#         if ig_modules:
#             fsdp_args.update({"ignored_modules": ig_modules})
#         self.kwargs = fsdp_args
# # class CustomFSDPStrategy(FSDPStrategy):
# #     def __init__(self, ig_params, ig_modules=None):
# #         super().__init__(
# #             sharding_strategy="FULL_SHARD",
# #             cpu_offload=None,  # Turn CPU offload OFF for speed on PCIe
# #             mixed_precision=MixedPrecision(
# #                 param_dtype=torch.bfloat16,
# #                 reduce_dtype=torch.bfloat16,
# #                 buffer_dtype=torch.bfloat16,
# #             ),
# #             auto_wrap_policy="TRANSFORMER_BASED_WRAP",
# #             forward_prefetch=True,  # Overlap comm and compute
# #         )
# #         fsdp_args = {
# #             "use_orig_params": True,
# #             "ignored_states": ig_params,
# #         }
# #         if ig_modules:
# #             fsdp_args["ignored_modules"] = ig_modules
# #         self.kwargs = fsdp_args

#     @property
#     def lightning_restore_optimizer(self) -> bool:
#         """Override to disable Lightning restoring optimizers/schedulers.

#         This is useful for plugins which manage restoring optimizers/schedulers.
#         """
#         return False

#     def lightning_module_state_dict(self) -> Dict[str, Any]:
#         assert self.model is not None

#         with FullyShardedDataParallel.state_dict_type(
#                 module=self.model,
#                 state_dict_type=StateDictType.FULL_STATE_DICT,
#                 state_dict_config=FullStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#                 optim_state_dict_config=FullOptimStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#         ):
#             # state_dict = self.model.state_dict()
#             state_dict = OrderedDict([(k.replace("_forward_module.",""), v) if k.__contains__('_forward_module') else (k, v)
#                                       for k, v in self.model.state_dict().items()])

#             # for key in state_dict:
#             #     print(f"state dict {key} :: {state_dict[key].shape}")
#             return state_dict

#     def setup_module(self, module: torch.nn.Module) -> torch.nn.Module:
#         """Override setup to ensure reshard_after_forward is set for all FSDP-wrapped submodules."""
#         module = super().setup_module(module)

#         for m in module.modules():
#             if isinstance(m, FullyShardedDataParallel):
#                 m._reshard_after_forward = True
#                 m._use_sharded_views = False  # optional, helps release memory immediately

#         return module

#     def optimizer_state(self, optimizer: Optimizer) -> Dict[str, Tensor]:
#         # old return FullyShardedDataParallel.full_optim_state_dict(self.model, optim=optimizer, rank0_only=True)
#         """ Manually gathers the full optimizer state across all ranks in FullyShardedDataParallel. """
#         # Get local (sharded) optimizer state using FullyShardedDataParallel
#         optim_state = FullyShardedDataParallel.optim_state_dict(self.model, optim=optimizer)

#         if torch.distributed.is_initialized():
#             # Gather optimizer states from all ranks
#             full_optim_state = [None] * torch.distributed.get_world_size()
#             torch.distributed.all_gather_object(full_optim_state, optim_state)

#             if torch.distributed.get_rank() == 0:
#                 # Merge optimizer states into a full dictionary
#                 merged_state = {"state": {}, "param_groups": full_optim_state[0]["param_groups"]}

#                 for state in full_optim_state:
#                     for param_id, param_state in state["state"].items():
#                         if param_id not in merged_state["state"]:
#                             merged_state["state"][param_id] = param_state
#                         else:
#                             # Merge optimizer state parameters (e.g., momentum buffers)
#                             for key in param_state:
#                                 if isinstance(param_state[key], list):
#                                     merged_state["state"][param_id][key].extend(param_state[key])
#                                 else:
#                                     merged_state["state"][param_id][key] = param_state[key]  # Overwrite

#                 return merged_state  # Full optimizer state for checkpointing
#             else:
#                 return {}  # Empty dictionary for non-rank 0
#         else:
#             return optim_state  # Single-process training, return directly


class _a4b8a2d427eb(_650b8ae8b638):
    """
    Unified FSDP strategy for BERT-family and LLaMA-family models.
    Skips FSDP wrapping of BNB 4bit/8bit layers to avoid FP32 shard bloat.
    """

    def _ec0f058ef57a(self, _0b506eca4305=_524ba2a05836, _ba0975f9817e=_524ba2a05836, _f920ee24f6eb: _662df070d5b8 = "", _4329d039073c: _5d45beca4bb4 = _41ec058a66df):
        from _d81d93427c1a._667e2515994d._2ac117fb6665._3a28676a8829 import _2424bee156df
        from functools import _98a68ec5ef00

        # --- Detect model family ---
        _1fdbc24732b4 = _f920ee24f6eb._df056d9bbcc7()
        if _390490555b5d(_e4f9979f5171 in _1fdbc24732b4 for _e4f9979f5171 in ["llama", "mistral"]):
            try:
                from _a9e1504f761e._86fa66ecf5ca._ac9d55386ddc._dac3370b8d9b import _1e2dc7efc561
                from _a9e1504f761e._86fa66ecf5ca._72b618ec1b00._4144bcdaf203 import _f65bb065ebe9
                _6a7cbd37e9d9 = (_1e2dc7efc561, _f65bb065ebe9)
            except _841ed8fed949:
                _6a7cbd37e9d9 = ()
        else:
            try:
                from _a9e1504f761e._86fa66ecf5ca._9c67b0e2114f._69b30023d2b1 import _5914148e4e84
                from _a9e1504f761e._86fa66ecf5ca._fc5220fe53a6._30baba59c07e import _36bbd6de8390
                from _a9e1504f761e._86fa66ecf5ca._1116b3bddda7._cebbca93046a import _7d7d53ab5212
                from _a9e1504f761e._86fa66ecf5ca._1e64222a9072._d1f27922bf38 import _5527c3957e95
                from _a9e1504f761e._86fa66ecf5ca._cf5f777a491b._0f114057be2a import _65f33dbf5582 as _89da3235cdea
                _6a7cbd37e9d9 = (_5914148e4e84, _36bbd6de8390, _7d7d53ab5212, _5527c3957e95, _89da3235cdea)
            except _841ed8fed949:
                _6a7cbd37e9d9 = ()

        # # --- Auto-wrap policy ---
        # if not layer_cls:
        #     print(f"[WARN] Could not infer transformer layer class for {model_name}. FSDP will wrap nothing.")
        #     auto_wrap_policy = None
        # else:
        #     auto_wrap_policy = partial(transformer_auto_wrap_policy, transformer_layer_cls=layer_cls)

        # # --- Skip BNB 4bit/8bit layers from FSDP wrapping ---
        # if auto_wrap_policy is not None:
        #     try:
        #         from bitsandbytes.nn import Linear4bit, Linear8bitLt
        #         def _bnb_filter(module):
        #             return not isinstance(module, (Linear4bit, Linear8bitLt))
        #         original_policy = auto_wrap_policy
        #         auto_wrap_policy = lambda m: original_policy(m) and _bnb_filter(m)
        #     except Exception as e:
        #         print(f"[WARN] Could not import BNB layers for FSDP filter: {e}")
    
        def _a8ca7962f72f(_1e007bdcdad9):
            return _1e007bdcdad9._5561becc68e9 if _a280dd497c77(_1e007bdcdad9, "module") else _1e007bdcdad9

        if not _6a7cbd37e9d9:
            _f16c407b8ca5(f"[WARN] Could not infer transformer layer class for {_f920ee24f6eb}. FSDP will wrap nothing.")
            _84b20e7ba42a = _524ba2a05836
        else:
            # base policy: match actual transformer layers
            def _8edecbadf1f2(_1e007bdcdad9):
                _b2fe255392e5 = _9a0d262d22c8(_1e007bdcdad9)
                return _70694fd9bdfb(_b2fe255392e5, _6a7cbd37e9d9)

            # add BNB skip
            try:
                from _c53169b2a439._c45278b00078 import _ee90303c9014, _3ebde8c3cbeb

                def _36121eef63ae(_1e007bdcdad9):
                    _b2fe255392e5 = _9a0d262d22c8(_1e007bdcdad9)
                    return not _70694fd9bdfb(_b2fe255392e5, (_ee90303c9014, _3ebde8c3cbeb))
            except _841ed8fed949:
                def _36121eef63ae(_1e007bdcdad9):
                    return _36599a7dea7d

            # final combined policy
            def _03a483311eff(_1e007bdcdad9):
                return _a57ecdfdd11d(_1e007bdcdad9) and _aac2788ee44b(_1e007bdcdad9)

        _8c4b826f8b15()._7577560c19c4(
            # sharding_strategy="FULL_SHARD" if is_training else "NO_SHARD", # NO_SHARD DECPRICATED
            _21c4b3d8bca7="FULL_SHARD",
            _971d91ece2f6=_6e49fbd4f264(_59e8b71c1cfa=_36599a7dea7d) if _4329d039073c else _41ec058a66df,
            _84b20e7ba42a=_84b20e7ba42a,
            _c9401225cae2=_36599a7dea7d,
            _bf880263a06b=_41ec058a66df,  # Safe for dynamic LoRA + quantized
        )

        # FSDP kwargs
        _43d7042e5423 = {
            "use_orig_params": _36599a7dea7d,
            "ignored_states": _0b506eca4305,
        }
        if _ba0975f9817e:
            _43d7042e5423["ignored_modules"] = _ba0975f9817e
        self._f21802a8662e = _43d7042e5423

    @_e1c2581cfebc
    def _70776c03644b(self) -> _5d45beca4bb4:
        return _41ec058a66df

    def _1b713ce53cf0(self, _5561becc68e9: _d81d93427c1a._c45278b00078._7a76288dde4d) -> _d81d93427c1a._c45278b00078._7a76288dde4d:
        _5561becc68e9 = _8c4b826f8b15()._df678963332e(_5561becc68e9)
        for _70c1b1837a49 in _5561becc68e9._e88c3235a0b9():
            if _70694fd9bdfb(_70c1b1837a49, _b6d8ac7254ee):
                _70c1b1837a49._12c9f4e7efc6 = _36599a7dea7d
                _70c1b1837a49._a25d774962c4 = _41ec058a66df
        return _5561becc68e9

    def _422ce6fa9e63(self) -> _c013f52869a8[_662df070d5b8, _7952803bd46e]:
        assert self._922ce048d075 is not _524ba2a05836
        with _b6d8ac7254ee._50e131e0e6b9(
            _5561becc68e9=self._922ce048d075,
            _50e131e0e6b9=_7c3d34fa48f6._c9ef7aea746c,
            _3190dd98f3fa=_83d7f7943fa0(_0983face900a=(self._f90e76fbefa2 > 1), _0931034fd143=_36599a7dea7d),
            _d9e576084118=_5a18a865df3f(_0983face900a=(self._f90e76fbefa2 > 1), _0931034fd143=_36599a7dea7d),
        ):
            _043c375b4b0c = _4715e93ca17f([
                (_fc92d963ec28._12525aa774aa("_forward_module.", ""), _869f9593928d) if "_forward_module" in _fc92d963ec28 else (_fc92d963ec28, _869f9593928d)
                for _fc92d963ec28, _869f9593928d in self._922ce048d075._043c375b4b0c()._75da506dae97()
            ])
            return _043c375b4b0c

    def _e2ab6d2f2e98(self, _7c2cfeebeeda: _f5d028421b7f) -> _c013f52869a8[_662df070d5b8, _d81d93427c1a._4d242564a685]:
        _ddc0cd94bcce = _b6d8ac7254ee._8f115fcbe617(self._922ce048d075, _a28ffe49750d=_7c2cfeebeeda)
        if _d81d93427c1a._667e2515994d._f30ad9eb4cdf():
            _9f652f15c6fd = [_524ba2a05836] * _d81d93427c1a._667e2515994d._33b020c5c02c()
            _d81d93427c1a._667e2515994d._ff2936a53cca(_9f652f15c6fd, _ddc0cd94bcce)
            if _d81d93427c1a._667e2515994d._a9eb81db7f50() == 0:
                _214499e76f63 = {"state": {}, "param_groups": _9f652f15c6fd[0]["param_groups"]}
                for _30bfd4bc16e3 in _9f652f15c6fd:
                    for _47d30584c94d, _3732f3f0b096 in _30bfd4bc16e3["state"]._75da506dae97():
                        if _47d30584c94d not in _214499e76f63["state"]:
                            _214499e76f63["state"][_47d30584c94d] = _3732f3f0b096
                        else:
                            for _fc92d963ec28, _869f9593928d in _3732f3f0b096._75da506dae97():
                                if _70694fd9bdfb(_869f9593928d, _d0131183e828):
                                    _214499e76f63["state"][_47d30584c94d][_fc92d963ec28]._29973a2bbe30(_869f9593928d)
                                else:
                                    _214499e76f63["state"][_47d30584c94d][_fc92d963ec28] = _869f9593928d
                return _214499e76f63
            else:
                return {}
        else:
            return _ddc0cd94bcce
        
class _ebee3e0fc72f(_4bf225bad710._bf321c6b1fc8):
    """Lightning callback that writes trial number to trainer.callback_metrics.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance.

    Behavior:
        On training start it will attempt to add a "trial_number" entry to the
        trainer.callback_metrics mapping. This is best-effort and will not raise
        if metrics are not writable.
    """

    def _ec0f058ef57a(self, _0b62b21a87a8: _5b04d2c831a6._0b62b21a87a8._5117795fa16d):
        self._0b62b21a87a8 = _0b62b21a87a8

    def _f466d247c7ee(self, _1d1a0b421d50: _4bf225bad710._b4b9917f122c, _d70e7da4e201: _4bf225bad710._552339ab947b):
        # Add custom key-value pair
        _1d1a0b421d50._9458ebc067a0["trial_number"] = _8261f4fded78(self._0b62b21a87a8._66529f9ab4b4)


class _00cfbd1757de(_4bf225bad710._bf321c6b1fc8):
    """Callback that monitors GPU usage and prunes an Optuna trial when usage is high.

    Args:
        trial (optuna.trial.Trial): Optuna trial object to prune.
        threshold (float): Fraction of GPU memory usage above which pruning should occur.

    Notes:
        - This callback is conservative: if CUDA is not available it is a no-op.
        - In distributed training it uses a broadcast so all ranks agree.
    """

    def _ec0f058ef57a(self, _0b62b21a87a8, _5737c5fe8ebf=0.90):
        """
        Args:
            trial (optuna.trial.Trial): Optuna trial object to prune.
            threshold (float): Fraction of GPU memory usage to trigger pruning.
        """
        self._0b62b21a87a8 = _0b62b21a87a8
        self._5737c5fe8ebf = _5737c5fe8ebf

    def _895e6d180a17(self, _1d1a0b421d50):
        """Return True if GPU reserved memory fraction >= threshold.

        Args:
            trainer: Lightning trainer object. Required for `is_global_zero` check.

        Returns:
            bool: True if usage >= threshold, False otherwise.

        Raises:
            None
        """
        # Only rank 0 checks and decides
        if not _d81d93427c1a._a6a57237a415._3b67608be895():
            return _41ec058a66df

        if _1d1a0b421d50._9098ecaba8ff:
            for _9bfcd2182387 in _5f8d214ba478(_d81d93427c1a._a6a57237a415._f67292492c82()):
                _964ed3d3f0a7 = _d81d93427c1a._a6a57237a415._07b6758bf45f(_9bfcd2182387)._ba6ef52a52fc
                _8533e9ba1ea2 = _d81d93427c1a._a6a57237a415._39aea3d1759c(_9bfcd2182387)
                _b6f3cf241884 = _8533e9ba1ea2 / _964ed3d3f0a7

                if _b6f3cf241884 >= self._5737c5fe8ebf:
                    _f16c407b8ca5(f"[GPU Monitor] GPU {_9bfcd2182387} usage excceded: {_b6f3cf241884*100:.1f}%")
                    return _36599a7dea7d
        return _41ec058a66df

    def _15388a1c0c89(self, _1940dd688882):
        """Broadcast the boolean prune decision to all ranks.

        Args:
            flag (bool): Local prune decision.

        Returns:
            bool: Agreed prune decision across ranks.

        Raises:
            RuntimeError: If CUDA is expected but not available on broadcast.
        """
        if not _d81d93427c1a._a6a57237a415._3b67608be895():
            # Nothing to broadcast; return local decision
            return _1940dd688882
        _0c2baa75881d = _d81d93427c1a._8261f4fded78([_39496407e64d(_1940dd688882)], _6083938910b3='cuda')
        if _d81d93427c1a._667e2515994d._f30ad9eb4cdf():
            _d81d93427c1a._667e2515994d._21c38d5c0311(_0c2baa75881d, _de39241a4031=0)
        return _0c2baa75881d._f0d067107fa0() == 1

    def _2bd20606c7e6(self, _1d1a0b421d50, _d70e7da4e201, _058f69b68502, _fa4cfd1a1982, _d0159c57276e=0):
        """Lightning hook executed at start of each training batch.

        Raises:
            optuna.TrialPruned: when GPU usage threshold is exceeded.
        """
        if not _6b9f713b3172:
            return  # for cpu alone
        _0e741957dd16 = self._e8bd2a4e519d(_1d1a0b421d50)
        # Broadcast decision so all ranks agree
        _0e741957dd16 = self._7023fb8d717e(_0e741957dd16)

        if _0e741957dd16:
            if _1d1a0b421d50._9098ecaba8ff:
                _f16c407b8ca5("[GPUUsagePruneCallback] GPU memory exceeded threshold. Pruning trial.")
            raise _5b04d2c831a6._4dd87d5fad78("GPU memory exceeded threshold")


def _2c91e5de82b5() -> _39496407e64d:
    """Compute local GPU rank based on environment variables.

    The function inspects `CUDA_VISIBLE_DEVICES`, `LOCAL_RANK` and `RANK` and
    returns an integer representing the local GPU index.

    Returns:
        int: local GPU rank (0-based). Returns -1 when CUDA is not available.

    Raises:
        ValueError: if computed local_rank is out of bounds for visible GPUs.
    """
    if not _d81d93427c1a._a6a57237a415._3b67608be895():
        _f16c407b8ca5("[adjust_local_gpu_rank] CUDA not available, using CPU (-1)", _0514218a9501=_36599a7dea7d)
        return -1  # CPU fallback

    _9d5b9c697e21 = os._bc925bc75a0c._8671a70a6ed2("CUDA_VISIBLE_DEVICES", "")
    if _9d5b9c697e21 == "":
        # No filtering: all GPUs visible
        _be5054b53282 = [_662df070d5b8(_9143da251771) for _9143da251771 in _5f8d214ba478(_d81d93427c1a._a6a57237a415._f67292492c82())]
    else:
        # For MIG UUIDs or indices, keep as string list (don't cast to int)
        _be5054b53282 = [_e4f9979f5171._7de5cedd0988() for _e4f9979f5171 in _9d5b9c697e21._744a6185b985(",") if _e4f9979f5171._7de5cedd0988() != ""]

    _477ec5f0eeaa = os._bc925bc75a0c._8671a70a6ed2("LOCAL_RANK")
    _e7b0a31352b3 = os._bc925bc75a0c._8671a70a6ed2("RANK")

    if _477ec5f0eeaa is not _524ba2a05836:
        _f278307d8553 = _39496407e64d(_477ec5f0eeaa)
        _f16c407b8ca5(f"[adjust_local_gpu_rank] Using LOCAL_RANK={_f278307d8553}", _0514218a9501=_36599a7dea7d)
    elif _e7b0a31352b3 is not _524ba2a05836:
        _f278307d8553 = _39496407e64d(_e7b0a31352b3)
        _f16c407b8ca5(f"[adjust_local_gpu_rank] LOCAL_RANK not set, using RANK={_f278307d8553}", _0514218a9501=_36599a7dea7d)
    else:
        _f278307d8553 = 0
        _f16c407b8ca5("[adjust_local_gpu_rank] LOCAL_RANK and RANK not set, defaulting to 0", _0514218a9501=_36599a7dea7d)

    if _f278307d8553 >= _8af34819c3df(_be5054b53282):
        raise _2d3054eea56e(
            f"[adjust_local_gpu_rank] local_rank ({_f278307d8553}) >= number of visible GPUs ({_8af34819c3df(_be5054b53282)}).")

    # Returning integer index for compatibility with how calling code uses it.
    _d24260fc1062 = _f278307d8553
    _f16c407b8ca5(f"[adjust_local_gpu_rank] CUDA_VISIBLE_DEVICES={_be5054b53282}, selected device={_d24260fc1062}", _0514218a9501=_36599a7dea7d)

    return _d24260fc1062


def _b7ec06077e59() -> _89ef46fd6da5:
    """Collect basic device and host information for logging.

    Returns:
        dict: keys include 'gpu_world_size', 'gpu_global_rank', 'gpu_local_rank',
              'node_name', and 'cpu_info'.

    Notes:
        - If CUDA is unavailable and SLURM is not detected, gpu_* keys are populated with -1.
    """
    _3d1c6f9725f7 = _89ef46fd6da5()
    if _d81d93427c1a._a6a57237a415._3b67608be895():
        _3d1c6f9725f7['gpu_world_size'] = _662df070d5b8(os._bc925bc75a0c._8671a70a6ed2('WORLD_SIZE', '1'))  # get WORLD_SIZE or set default 1
        _3d1c6f9725f7['gpu_global_rank'] = _662df070d5b8(os._bc925bc75a0c._8671a70a6ed2('RANK', '0'))
        _3d1c6f9725f7['gpu_local_rank'] = _662df070d5b8(_bfb5ba8a4e16())
    elif _e1770d5db913._f49b22b68b4d() and _d81d93427c1a._a6a57237a415._3b67608be895() is _41ec058a66df:
        _3d1c6f9725f7['gpu_world_size'] = _662df070d5b8(_e1770d5db913._f90e76fbefa2(_4bf225bad710))
        _3d1c6f9725f7['gpu_global_rank'] = _662df070d5b8(_e1770d5db913._5563f30e6cf7(_4bf225bad710))
        _3d1c6f9725f7['gpu_local_rank'] = -1
    else:
        _3d1c6f9725f7['gpu_world_size'] = -1
        _3d1c6f9725f7['gpu_global_rank'] = -1
        _3d1c6f9725f7['gpu_local_rank'] = -1
    _3d1c6f9725f7['node_name'] = _6d4d13666d6f._b7dd889f8c59()
    try:
        _3d1c6f9725f7['cpu_info'] = "CPU :: {} COUNT :: {}"._d5c065bd1c33(_57786bd79a66._9f1756affb33()['brand_raw'], os._5d516e00e94f())
    except _841ed8fed949:
        _3d1c6f9725f7['cpu_info'] = f"CPU COUNT :: {os._5d516e00e94f()}"
    return _3d1c6f9725f7


def _859ba788ad28(_6185edd47862: _662df070d5b8, _1e4ba305c163: _662df070d5b8, _2e87d8ab8d7a: _e155f644eacc):
    """Remove all files in a directory except a single filename to keep.

    Args:
        directory (str): Directory to clean.
        file_to_keep (str): Basename of file to retain.
        log (Logger): Logger instance for informational messages.

    Raises:
        FileNotFoundError: If `directory` does not exist.
        PermissionError: If file removal fails due to permissions (propagates underlying OSError).
    """
    if not os._c3ad22d2b915._2e78b9af54aa(_6185edd47862):
        raise _dfaef85a2cdd(f"Directory not found: {_6185edd47862}")

    for _92dbfb0fc7fb in os._ac194d6c67e6(_6185edd47862):
        _3bf8e191c7ec = os._c3ad22d2b915._11b899e3a4c7(_6185edd47862, _92dbfb0fc7fb)
        if os._c3ad22d2b915._09cefbabe995(_3bf8e191c7ec) and _92dbfb0fc7fb != _1e4ba305c163:
            _2e87d8ab8d7a._74c5cd2722f0(f"Removing checkpoint: {_3bf8e191c7ec}")
            os._15149004c5f1(_3bf8e191c7ec)


def _64f8afd4d13a(_2e87d8ab8d7a: _e155f644eacc, _52ea141223cb: _662df070d5b8, _73b5f272db48: _5b04d2c831a6._ae6d6347eec5, _0b62b21a87a8: _5b04d2c831a6._0b62b21a87a8._5117795fa16d):
    """Clear outdated checkpoint directories for the given model config.

    Args:
        log (Logger): Logger instance.
        model_config_name (str): Model configuration name used to build checkpoint root path.
        study (optuna.Study): Optuna study object (kept in signature for compatibility).
        trial (optuna.trial.Trial): Current trial; its number is preserved.

    Notes:
        - This function removes directories for older trials (non-current).
        - It will not raise if directories are missing; failures to remove are logged.
    """
    _4cca290f1de4 = f"checkpoints/{_52ea141223cb}/trial_{_0b62b21a87a8._66529f9ab4b4}"
    _fa65bf321808 = f"{_4cca290f1de4}/last-v{_0b62b21a87a8._66529f9ab4b4}.ckpt"

    # If the directory is empty, we can remove it
    if os._c3ad22d2b915._2e78b9af54aa(_4cca290f1de4):
        if not os._ac194d6c67e6(_4cca290f1de4):  # Check if empty
            try:
                os._8b844dced4c5(_4cca290f1de4)  # Remove only if empty
                _2e87d8ab8d7a._74c5cd2722f0(f"Removed empty directory: {_4cca290f1de4}")
            except _841ed8fed949:
                _2e87d8ab8d7a._29554d4cda35(f"Failed to remove directory: {_4cca290f1de4}")
        else:
            # Check if the directory does not belong to the current trial and remove it
            _7f2903d420c8 = f"checkpoints/{_52ea141223cb}"
            if os._c3ad22d2b915._2e78b9af54aa(_7f2903d420c8):
                _d1dd96b704d2 = os._ac194d6c67e6(_7f2903d420c8)
                for _a547e6f85fee in _d1dd96b704d2:
                    _df7d5f6cf34b = re._df7d5f6cf34b(r"trial_(\d+)", _a547e6f85fee)
                    if _df7d5f6cf34b:
                        _fe132772d2fb = _39496407e64d(_df7d5f6cf34b._53969e6cbd16(1))
                        if _fe132772d2fb != _0b62b21a87a8._66529f9ab4b4:
                            _0a49b626553f = f"{_7f2903d420c8}/{_a547e6f85fee}"
                            if os._c3ad22d2b915._cef280824825(_0a49b626553f):
                                try:
                                    _2e87d8ab8d7a._74c5cd2722f0(f"Removing outdated trial directory: {_0a49b626553f}")
                                    _2ec0692c6156._8c8e545c80f7(_0a49b626553f)
                                except _841ed8fed949:
                                    _2e87d8ab8d7a._29554d4cda35(f"Failed to remove dir {_0a49b626553f}")


def _81261e25c9a1(_922ce048d075, _327c7f3ac0b2, _c32353f09991):
    """Load a checkpoint into the original (unwrapped) model when FSDP was used.

    Args:
        model: Original (unwrapped) model instance (kept for signature compatibility).
        fsdp_model: FSDP-wrapped model instance that contains `.module`.
        checkpoint_path (str): Path to checkpoint file.

    Returns:
        torch.nn.Module: original model with loaded state dict.

    Raises:
        FileNotFoundError: If the checkpoint file does not exist.
        AttributeError: If `fsdp_model` does not expose `.module`.
        RuntimeError: If loading state dict fails.
    """
    if not os._c3ad22d2b915._cef280824825(_c32353f09991):
        raise _dfaef85a2cdd(f"Checkpoint not found: {_c32353f09991}")

    # Access the original model (best-effort)
    if not _a280dd497c77(_327c7f3ac0b2, "module"):
        raise _1b7f411896ba("fsdp_model does not expose .module (not an FSDP-wrapped model)")

    _51d7f8aa056a = _327c7f3ac0b2._5561becc68e9

    # Load the checkpoint
    _6ca30f15d243 = _d81d93427c1a._e4e3751af8c7(_c32353f09991)

    # Attempt to load state dict into original model
    try:
        # Note: original script used FSDP full-state helpers; preserve call but guard errors
        with _d81d93427c1a._667e2515994d._2ac117fb6665._83d7f7943fa0(_327c7f3ac0b2):
            _51d7f8aa056a._bda76d4df33a(_6ca30f15d243, _18a0cb8f65eb=_36599a7dea7d)
    except _841ed8fed949:
        # Try fallback strict=False
        try:
            _51d7f8aa056a._bda76d4df33a(_6ca30f15d243, _18a0cb8f65eb=_41ec058a66df)
        except _841ed8fed949 as _3fcb765587f9:
            raise _8cca644149a1(f"Failed to load checkpoint into original model: {_3fcb765587f9}") from _3fcb765587f9
    return _51d7f8aa056a

# def dequantize_bnb_model(model):
#     """
#     Replace bitsandbytes quantized linear layers in a model with standard torch.nn.Linear layers.

#     This function traverses the given model and converts all quantized linear
#     layers (Linear4bit, Linear8bitLt) into torch.nn.Linear equivalents with
#     dequantized float32 weights and bias. The conversion is done in-place.

#     Args:
#         model (torch.nn.Module):
#             Model instance that may contain bitsandbytes quantized linear layers.

#     Returns:
#         torch.nn.Module:
#             The same model with quantized linear layers replaced by dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If layer weights or bias cannot be converted to float32 or fail to copy into a new layer.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for module in list(model.modules()):
#         for name, child in list(module.named_children()):
#             if getattr(child, "_is_dequantized", False):
#                 continue
#             if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#                 try:
#                     try:
#                         w = child.weight.dequantize()
#                     except Exception:
#                         w = child.weight.data.to(torch.float32)
#                     b = None
#                     if getattr(child, "bias", None) is not None:
#                         b = child.bias.data.to(torch.float32)
#                     out_f, in_f = w.shape
#                     new_linear = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                     new_linear.weight.data.copy_(w)
#                     if b is not None:
#                         new_linear.bias.data.copy_(b)
#                     new_linear._is_dequantized = True
#                     setattr(module, name, new_linear)
#                 except Exception as e:
#                     raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#     return model


# def manual_dequantize(module):
#     """
#     Recursively replace bitsandbytes quantized linear layers in a module with torch.nn.Linear layers.

#     This function walks all children of the given module recursively and converts
#     quantized linear layers (Linear4bit, Linear8bitLt) to standard torch.nn.Linear
#     layers containing float32 weights and bias. Layers already marked as
#     dequantized are skipped.

#     Args:
#         module (torch.nn.Module):
#             Root module or submodule to process recursively.

#     Returns:
#         torch.nn.Module:
#             The same module with all quantized linear layers replaced by
#             dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If a quantized layer fails to convert or copy its weights to float32.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for name, child in list(module.named_children()):
#         if getattr(child, "_is_dequantized", False):
#             continue
#         if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#             try:
#                 try:
#                     w = child.weight.dequantize()
#                 except Exception:
#                     w = child.weight.data.to(torch.float32)
#                 b = None
#                 if getattr(child, "bias", None) is not None:
#                     b = child.bias.data.to(torch.float32)
#                 out_f, in_f = w.shape
#                 new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                 new_layer.weight.data.copy_(w)
#                 if b is not None:
#                     new_layer.bias.data.copy_(b)
#                 new_layer._is_dequantized = True
#                 setattr(module, name, new_layer)
#             except Exception as e:
#                 raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#         else:
#             manual_dequantize(child)
#     return module

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32) — no CPU moves, preserves device, removes ALL quantized layers.
#     Works even under PEFT, _SafeModuleWrapper, PeftModel, LoraModel, etc.

#     Bulletproof: detection by class name, not isinstance.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",        # some bnb builds use this
#     }

#     # Traverse parents so we can do setattr
#     for parent in list(model.modules()):
#         # Use raw _modules dict so we replace correct child
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # Skip non-BnB quantized layers
#             if cls not in QUANT_CLASS_NAMES:
#                 # Check nested wrapper: _SafeModuleWrapper, etc.
#                 inner = getattr(child, "module", None)
#                 if inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                     child = inner
#                     cls = child.__class__.__name__
#                 else:
#                     continue

#             # --------------------------------------------------------
#             # At this point, child is DEFINITELY a quantized Linear*
#             # --------------------------------------------------------

#             # Device
#             try:
#                 device = next(child.parameters()).device
#             except StopIteration:
#                 device = torch.device("cpu")

#             # ---- read weight ----
#             if hasattr(child, "weight") and hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---- read bias ----
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---- infer dims ----
#             # out_f, in_f = w.shape
#             # If weight is 1-D (flattened), infer dims from child attributes
#             if w.dim() == 1:
#                 out_f = child.out_features
#                 in_f = child.in_features
#             else:
#                 out_f, in_f = w.shape

#             # ---- create replacement ----
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---- REPLACE ----
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32). Preserves device. Never reshapes incorrectly.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",
#     }

#     for parent in list(model.modules()):
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # ---------- WRAPPER DETECTION ----------
#             wrapper = child                     # always keep wrapper
#             inner = getattr(child, "module", None)
#             is_quant = False

#             # direct quantized
#             if cls in QUANT_CLASS_NAMES:
#                 is_quant = True

#             # wrapped quantized
#             elif inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                 is_quant = True
#                 child = inner                    # but we still use wrapper for dims

#             if not is_quant:
#                 continue

#             # ---------- DEVICE ----------
#             try:
#                 device = next(child.parameters()).device
#             except Exception:
#                 device = torch.device("cpu")

#             # ---------- READ WEIGHTS ----------
#             if hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---------- READ BIAS ----------
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---------- TRUE DIMENSIONS FROM WRAPPER ----------
#             in_f = getattr(wrapper, "in_features", None)
#             out_f = getattr(wrapper, "out_features", None)

#             if in_f is None or out_f is None:
#                 # fallback to weight dims only if both missing
#                 print(f"FALLING BACK shape {w.shape}")
#                 out_f, in_f = w.shape

#             # ---------- CREATE NEW LINEAR ----------
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---------- REPLACE ----------
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
#     Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
#     Leaves LoRA and trainable modules untouched.
#     Safe: skips missing weights or broken layers automatically.
#     """
#     modules = list(model.named_modules())[::-1]  # bottom-up traversal

#     for name, module in modules:
#         if isinstance(module, (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)):
#             try:
#                 in_features = getattr(module, "in_features", module.weight.shape[1])
#                 out_features = getattr(module, "out_features", module.weight.shape[0])
#                 module_device = next(module.parameters(), None).device if module is not None else torch.device('cpu')
#                 print(f"dequant {module} on {module_device}")
#                 dequantized = torch.nn.Linear(
#                     in_features, out_features,
#                     bias=module.bias is not None,
#                     dtype=torch.float32,
#                     device=module_device
#                 )

#                 if module.weight is None or not hasattr(module.weight, "data"):
#                     continue

#                 dequantized.weight.data = module.weight.to(torch.float32)
#                 if module.bias is not None:
#                     dequantized.bias.data.copy_(module.bias.data)

#                 # Replace in parent
#                 parent = model
#                 parts = name.split(".")
#                 for p in parts[:-1]:
#                     parent = getattr(parent, p)
#                 setattr(parent, parts[-1], dequantized)

#                 del module
#                 gc.collect()
#                 torch.cuda.empty_cache()

#             except Exception as e:
#                 print(f"[WARN] Skipped dequantizing {name}: {e}")

#     return model

def _c94753ec1245(_922ce048d075: _d81d93427c1a._c45278b00078._7a76288dde4d) -> _d81d93427c1a._c45278b00078._7a76288dde4d:
    _86048c2d3db0 = 0
    for _51cc92de1888, _5561becc68e9 in _d0131183e828(_922ce048d075._94f8a878a57b()):
        if not _70694fd9bdfb(_5561becc68e9, (_2a16287f21e3._c45278b00078._ee90303c9014, _2a16287f21e3._c45278b00078._3ebde8c3cbeb)):
            continue

        # print(f"Dequantizing {name} | {module.__class__.__name__} -> torch.nn.Linear")

        try:
            # 1. Force full dequantization using bnb internals (works on every model)
            if _70694fd9bdfb(_5561becc68e9, _2a16287f21e3._c45278b00078._ee90303c9014):
                # Handles NF4/FP4 + grouped QKV perfectly
                _59102c4df393 = _2a16287f21e3._f6ba6a5229b5._58430ee3fdb6(
                    _5561becc68e9._59102c4df393._0d47d5f7443a,
                    _5561becc68e9._59102c4df393._a022a30904d1
                )._91366dfaf637(_c78117e2e1b2())
            else:  # Linear8bitLt
                _59102c4df393 = _5561becc68e9._59102c4df393._0d47d5f7443a._91366dfaf637(_c78117e2e1b2())

            _ed43a77bc6e8 = _5561becc68e9._ed43a77bc6e8._91366dfaf637(_c78117e2e1b2()) if _5561becc68e9._ed43a77bc6e8 is not _524ba2a05836 else _524ba2a05836

            # 2. Create clean fp32 Linear with correct shapes
            _553b68ede71d = _d81d93427c1a._c45278b00078._003d0748fd95(
                _97bd5e7070cd=_5561becc68e9._97bd5e7070cd,
                _b2068bd9fd05=_5561becc68e9._b2068bd9fd05,
                _ed43a77bc6e8=_ed43a77bc6e8 is not _524ba2a05836,
                _6083938910b3=_5561becc68e9._59102c4df393._0d47d5f7443a._6083938910b3,
                _c65aa0ce8bf1=_c78117e2e1b2()
            )
            _553b68ede71d._59102c4df393._0d47d5f7443a._35612054130e(_59102c4df393)
            if _ed43a77bc6e8 is not _524ba2a05836:
                _553b68ede71d._ed43a77bc6e8._0d47d5f7443a._35612054130e(_ed43a77bc6e8)

            # 3. Replace in parent (safe even with wrappers)
            _9f828b3da86e = _89ef46fd6da5(_922ce048d075._94f8a878a57b())
            _28641db30f8b = "."._11b899e3a4c7(_51cc92de1888._744a6185b985(".")[:-1])
            _24fc54c82f9a = _9f828b3da86e[_28641db30f8b] if _28641db30f8b else _922ce048d075
            _4b65c5713a91(_24fc54c82f9a, _51cc92de1888._744a6185b985(".")[-1], _553b68ede71d)
            del _5561becc68e9._59102c4df393   # instantly frees the 4bit/8bit buffer
            _86048c2d3db0 += 1

        except _841ed8fed949 as _3fcb765587f9:
            _f16c407b8ca5(f"[FATAL] Failed on {_51cc92de1888}: {_3fcb765587f9}")
            raise

    _f16c407b8ca5(f"Successfully dequantized {_86048c2d3db0} bnb layers")
    _2dfbc3ebb3a1._41c949d8af60()
    if _d81d93427c1a._a6a57237a415._3b67608be895():
        _d81d93427c1a._a6a57237a415._5ddf05f09616()
    return _922ce048d075

# def dequantize_bnb_model(model: torch.nn.Module) -> torch.nn.Module:
#     import torch
#     from bitsandbytes.nn import Linear4bit

#     for name, module in list(model.named_modules()):
#         if not isinstance(module, Linear4bit):
#             continue

#         # THIS IS THE KEY LINE FOR NEW BITSANDBYTES
#         if hasattr(module.weight, "quant_state"):
#             # New format: packed bits + quant_state
#             weight = module.weight.dequantize(module.weight.quant_state)
#         else:
#             # Old format (rare now)
#             weight = module.weight.dequantize()

#         bias = module.bias if module.bias is not None else None

#         linear = torch.nn.Linear(
#             module.in_features,
#             module.out_features,
#             bias=bias is not None,
#             device=module.weight.device,
#             dtype=torch.float32
#         )
#         linear.weight.data = weight.to(torch.float32)
#         if bias is not None:
#             linear.bias.data = bias.data.to(torch.float32)

#         # Replace
#         parent = model
#         for part in name.split(".")[:-1]:
#             parent = getattr(parent, part)
#         setattr(parent, name.split(".")[-1], linear)

#     return model

def _e2d3538af911(_922ce048d075):
    """
    Convert any remaining uint8 weights to fp32, in-place.
    No reshaping, no heuristics — only dtype fix.
    """
    import _d81d93427c1a

    for _5561becc68e9 in _922ce048d075._e88c3235a0b9():
        for _51cc92de1888, _92c6d5a88c8b in _5561becc68e9._f2aca8219ca9(_5b1472ac46eb=_41ec058a66df):
            if _92c6d5a88c8b._c65aa0ce8bf1 == _d81d93427c1a._74f940bf2763:
                _92c6d5a88c8b._0d47d5f7443a = _92c6d5a88c8b._0d47d5f7443a._6c0631dc0444()

    return _922ce048d075


def _25a35230ff5a(_922ce048d075):
    """Return the number of trainable parameters in a model.

    Args:
        model (torch.nn.Module): Model to inspect.

    Returns:
        int: Count of trainable parameters.
    """
    _84d41a54b578 = _297f5e260780(_95f58f50e642._38c0040bcf0f() for _95f58f50e642 in _922ce048d075._f1185fbda52e() if _95f58f50e642._e785a1d5196d)
    return _39496407e64d(_84d41a54b578)  # Ensure this returns an integer


# def get_target_modules(model, attribute_filter=None, name_filter=None, custom_filter=None):
#     """Collect submodules of `model` that satisfy the provided filters.

#     Args:
#         model (nn.Module or LightningModule): The model to analyze.
#         attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
#         name_filter (callable, optional): Function(name) -> bool to filter by module name.
#         custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.

#     Returns:
#         dict: Mapping from module name to module instance for modules that matched filters.

#     Raises:
#         TypeError: If `model` does not implement `named_modules`.
#     """
#     if not hasattr(model, "named_modules"):
#         raise TypeError("Provided model does not implement named_modules()")

#     target_modules = {}
#     for name, module in model.named_modules():
#         # Exclude LayerNorm and other unsupported layers
#         if "Norm" in module.__class__.__name__:
#             continue

#         # Skip frozen layers (requires_grad=False)
#         try:
#             if not any(param.requires_grad for param in module.parameters()):
#                 continue  # Skip this module if all its parameters are frozen
#         except Exception:
#             # If module.parameters() raises, skip it as not applicable
#             continue

#         if (
#             (attribute_filter is None or attribute_filter(module)) and
#             (name_filter is None or name_filter(name)) and
#             (custom_filter is None or custom_filter(name, module))
#         ):
#             target_modules[name] = module  # Store the module in the dictionary with its name as key
#     return target_modules

def _b911671c7225(_922ce048d075, _ceb24d4bd126=_524ba2a05836, _fc89e68008e4=_524ba2a05836, _eba81b9f85ca=_524ba2a05836, _af3138d587eb="embedding"):
    """Collect submodules of `model` that satisfy the provided filters.

    - Keeps modules that expose a weight Tensor even when that weight is not a Parameter
      (this allows detecting bitsandbytes wrappers like Linear4bit/Linear8bit).
    - Skips normalization modules by class-name ("Norm").
    - If a module has actual torch.nn.Parameters and all are requires_grad==False, it is skipped.
    - Returns dict mapping full dotted module path (prefixed by `prefix` if provided) -> module.

    Args:
        model (nn.Module or LightningModule): The model to analyze.
        attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
        name_filter (callable, optional): Function(name) -> bool to filter by module name.
        custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.
        prefix (str, optional): Base name of model path (default: "embedding").

    Returns:
        dict: Mapping from *full dotted module path* to module instance for matched modules.

    Raises:
        TypeError: If `model` does not implement named_modules().
    """
    import _d81d93427c1a

    if not _a280dd497c77(_922ce048d075, "named_modules"):
        raise _a5254fb06373("Provided model does not implement named_modules()")

    _ff532b9bd95d = {}
    for _51cc92de1888, _5561becc68e9 in _922ce048d075._94f8a878a57b():
        # Exclude normalization layers (class name contains "Norm")
        if "Norm" in _5561becc68e9._6b5e0d33eddd.__name__:
            continue

        # Determine if module has torch.nn.Parameters
        _0a5ec72061e0 = _41ec058a66df
        _fe8330bc6b28 = []
        try:
            _fe8330bc6b28 = _d0131183e828(_5561becc68e9._f1185fbda52e())
            _0a5ec72061e0 = _8af34819c3df(_fe8330bc6b28) > 0
        except _841ed8fed949:
            _0a5ec72061e0 = _41ec058a66df

        # If module has Parameters and none require grad -> skip (frozen)
        if _0a5ec72061e0:
            try:
                if not _390490555b5d(_95f58f50e642._e785a1d5196d for _95f58f50e642 in _fe8330bc6b28):
                    continue
            except _841ed8fed949:
                # conservative: don't skip if we can't determine requires_grad
                pass

        # Allow modules that have a 'weight' attribute that's a Tensor (covers bnb wrappers)
        _d8db20bc4c28 = _41ec058a66df
        try:
            _22d2977ec20c = _e24a018c4da9(_5561becc68e9, "weight", _524ba2a05836)
            if _70694fd9bdfb(_22d2977ec20c, _d81d93427c1a._4d242564a685):
                # accept even if it's not a Parameter
                _d8db20bc4c28 = _36599a7dea7d
        except _841ed8fed949:
            _d8db20bc4c28 = _41ec058a66df

        # Apply attribute/name/custom filters (attribute_filter should expect module)
        try:
            _fd6cd87f8944 = (_ceb24d4bd126 is _524ba2a05836) or _ceb24d4bd126(_5561becc68e9)
        except _841ed8fed949:
            _fd6cd87f8944 = _41ec058a66df

        try:
            _a3de2f5a605c = (_fc89e68008e4 is _524ba2a05836) or _fc89e68008e4(_51cc92de1888)
        except _841ed8fed949:
            _a3de2f5a605c = _41ec058a66df

        try:
            _ab0e7853e9fb = (_eba81b9f85ca is _524ba2a05836) or _eba81b9f85ca(_51cc92de1888, _5561becc68e9)
        except _841ed8fed949:
            _ab0e7853e9fb = _41ec058a66df

        # Decide acceptance:
        # - If attribute_filter/name_filter/custom_filter pass -> accept
        # - Otherwise, fall back to accepting if module has a weight tensor (bnb)
        if (_fd6cd87f8944 and _a3de2f5a605c and _ab0e7853e9fb) or (not _0a5ec72061e0 and _d8db20bc4c28):
            _a11bc304a103 = f"{_af3138d587eb}.{_51cc92de1888}" if _af3138d587eb else _51cc92de1888
            _ff532b9bd95d[_a11bc304a103] = _5561becc68e9

    return _ff532b9bd95d


def _ac7493dae2c4():
    """Safely clears GPU and CPU memory without disrupting distributed processes.

    Notes:
        - Best-effort: this function will not raise on cleanup errors, but will print/log them.
        - Ensures a distributed barrier at the end if torch.distributed is initialized.
    """
    # Run garbage collection to free CPU memory.
    _2dfbc3ebb3a1._41c949d8af60()

    if _d81d93427c1a._a6a57237a415._3b67608be895():
        # Clear CUDA memory cache.
        try:
            _d81d93427c1a._a6a57237a415._5ddf05f09616()
            _d81d93427c1a._a6a57237a415._a9d30f4a6db6()
        except _841ed8fed949:
            # Some CUDA versions might not have ipc_collect
            pass

        # Ensure all pending CUDA operations are finished.
        try:
            _d81d93427c1a._a6a57237a415._18eea9f87c70()
        except _841ed8fed949:
            pass

        # Print memory stats before reset (optional).
        try:
            _4ae6384f0edd = _d81d93427c1a._a6a57237a415._39aea3d1759c()
            _4f7cbcecc5a9 = _d81d93427c1a._a6a57237a415._c770f7665f6c()
            _f16c407b8ca5(f"Before reset: Reserved = {_4ae6384f0edd}, Allocated = {_4f7cbcecc5a9}")
        except _841ed8fed949:
            pass

        # Reset memory tracking (useful for debugging).
        try:
            _d81d93427c1a._a6a57237a415._a5d7f52bd593()
        except _841ed8fed949:
            pass

    # Print current process memory usage.
    try:
        _380732968728 = _87cbac691893._97133ac230c0(os._5275bc4e10d1())
        _69c723e428cb = _380732968728._58a2b4c6e6d0()
        _f16c407b8ca5(f"Cleared GPU and CPU memory. Current process memory usage: {_69c723e428cb._6f647f52f280 / 1024**2:.2f} MB")
    except _841ed8fed949:
        pass

    # Ensure all distributed processes are synchronized before proceeding.
    if _d81d93427c1a._667e2515994d._f30ad9eb4cdf():
        try:
            _d81d93427c1a._667e2515994d._30d07afc58e4()
        except _841ed8fed949:
            pass


def _ff36c1437c46(_922ce048d075):
    """Calculate approximate model size in gigabytes.

    Args:
        model (torch.nn.Module): The model to analyze.

    Returns:
        float: Total size in GB accounting for unique parameters.

    Raises:
        TypeError: If model does not implement `.parameters()`.
    """
    if not _a280dd497c77(_922ce048d075, "parameters"):
        raise _a5254fb06373("Provided object is not a model with parameters()")

    _c9820b99a999 = 0  # Size in bytes
    _e5d0fe730fc4 = _55adbb7b2241()  # Set to track counted parameters by their unique IDs

    # Recursive function to sum the size of parameters in all submodules
    def _90612e45bd7d(_5561becc68e9):
        nonlocal _c9820b99a999
        for _92c6d5a88c8b in _5561becc68e9._f1185fbda52e():
            _d871373fc3ef = _8dcdadb82b8e(_92c6d5a88c8b)  # Unique identifier for the parameter
            if _d871373fc3ef not in _e5d0fe730fc4:  # Ensure each parameter is counted only once
                _157d250cb36f = _92c6d5a88c8b._87619cec10f5()  # Size of one element in bytes
                _c9820b99a999 += _92c6d5a88c8b._38c0040bcf0f() * _157d250cb36f  # Total memory in bytes
                _e5d0fe730fc4._99b5f704e7a7(_d871373fc3ef)  # Mark parameter as counted

    # Loop through all submodules (including nested ones)
    try:
        _922ce048d075._c2cb48a35c7c(lambda _5561becc68e9: _d5bdad2ab22f(_5561becc68e9))
    except _841ed8fed949:
        # Fallback: iterate parameters directly
        for _92c6d5a88c8b in _922ce048d075._f1185fbda52e():
            _d871373fc3ef = _8dcdadb82b8e(_92c6d5a88c8b)
            if _d871373fc3ef not in _e5d0fe730fc4:
                _c9820b99a999 += _92c6d5a88c8b._38c0040bcf0f() * _92c6d5a88c8b._87619cec10f5()
                _e5d0fe730fc4._99b5f704e7a7(_d871373fc3ef)

    _3a72f48ccb74 = _6c0631dc0444(_c9820b99a999) / (1024 ** 3)  # Convert to GB
    return _3a72f48ccb74


def _1501a18069ac(_922ce048d075: _4bf225bad710._552339ab947b, _cc264015800f: _39496407e64d = 1):
    """Return a PrettyTable summary of the model architecture and parameter counts.

    Args:
        model (pl.LightningModule): Model to summarize.
        depth (int): How deep in module name hierarchy to report (default 1).

    Returns:
        str: Multi-line string summary. If PrettyTable is unavailable this will raise.

    Raises:
        TypeError: If model does not implement `named_modules`.
    """
    if not _a280dd497c77(_922ce048d075, "named_modules"):
        raise _a5254fb06373("Provided model does not implement named_modules()")

    _294df3790db6 = _e31f412b72d7()
    _294df3790db6._5f177426f9ab = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

    _f21acbe77ca9 = 0
    _84d41a54b578 = 0
    _6187f9cdc41d = 0

    _4d95aa889880 = _55adbb7b2241()  # Track parameters to prevent duplicate counting

    def _284cdd4ef011(_5561becc68e9):
        """Helper function to count trainable/non-trainable parameters uniquely."""
        _fe8330bc6b28 = _d0131183e828(_5561becc68e9._f1185fbda52e())
        _2356f8234731 = [_95f58f50e642 for _95f58f50e642 in _fe8330bc6b28 if _8dcdadb82b8e(_95f58f50e642) not in _4d95aa889880]

        _4d95aa889880._b465573f9a7a(_8dcdadb82b8e(_95f58f50e642) for _95f58f50e642 in _2356f8234731)  # Mark parameters as counted

        _964ed3d3f0a7 = _297f5e260780(_95f58f50e642._38c0040bcf0f() for _95f58f50e642 in _2356f8234731)
        _0c782a44ec6c = _297f5e260780(_95f58f50e642._38c0040bcf0f() for _95f58f50e642 in _2356f8234731 if _95f58f50e642._e785a1d5196d)
        _a94573fe84b2 = _964ed3d3f0a7 - _0c782a44ec6c

        return _964ed3d3f0a7, _0c782a44ec6c, _a94573fe84b2

    for _51cc92de1888, _5561becc68e9 in _922ce048d075._94f8a878a57b():
        if _51cc92de1888 == "" or _51cc92de1888._06f21fb39f7a('.') >= _cc264015800f:  # Skip root module and limit depth
            continue

        _fe8330bc6b28, _0c782a44ec6c, _a94573fe84b2 = _d01cb85e0006(_5561becc68e9)

        if _fe8330bc6b28 > 0:  # Only add layers with parameters
            _294df3790db6._33412c9a082c([_51cc92de1888, _5561becc68e9._6b5e0d33eddd.__name__, f"{_fe8330bc6b28:,}", f"{_0c782a44ec6c:,}", f"{_a94573fe84b2:,}"])

        _f21acbe77ca9 += _fe8330bc6b28
        _84d41a54b578 += _0c782a44ec6c
        _6187f9cdc41d += _a94573fe84b2

    _823a48d899a0 = _563437e94fe4(_922ce048d075)

    _9701e0f97a19 = "\n" + _294df3790db6._4c8d36f93118()
    _9701e0f97a19 += f"\nTotal params: {_f21acbe77ca9:,}\n"
    _9701e0f97a19 += f"Trainable params: {_84d41a54b578:,}\n"
    _9701e0f97a19 += f"Non-Trainable params: {_6187f9cdc41d:,}\n"
    _9701e0f97a19 += f"Model size: {_823a48d899a0:.2f} GB\n"

    return _9701e0f97a19


def _6a22ca35f890(_e991b28a4424):
    """Return a devices specification suitable for Lightning Trainer based on DEVICE.

    Args:
        DEVICE (str): 'gpu' or 'cpu'.

    Returns:
        int | list: devices argument for Trainer (e.g., 1, [0], list(range(n)) or -1 for distributed).

    Raises:
        ValueError: If DEVICE is unknown or LOCAL_RANK out of bounds.
    """
    if _e991b28a4424 == "cpu":
        return 1

    if _e991b28a4424 == "gpu":
        _0605ab3bb8fc = os._bc925bc75a0c._8671a70a6ed2("CUDA_VISIBLE_DEVICES")
        _36e3bb3da5de = _d81d93427c1a._667e2515994d._3b67608be895() and _d81d93427c1a._667e2515994d._f30ad9eb4cdf()

        if _36e3bb3da5de:
            return -1  # Let Lightning handle all

        # Inside non-distributed
        if _0605ab3bb8fc:
            _fc52df97b91a = [_39496407e64d(_e4f9979f5171._7de5cedd0988()) for _e4f9979f5171 in _0605ab3bb8fc._744a6185b985(",")]
            _477ec5f0eeaa = os._bc925bc75a0c._8671a70a6ed2('LOCAL_RANK') or os._bc925bc75a0c._8671a70a6ed2('RANK')

            if _477ec5f0eeaa is not _524ba2a05836:
                _f278307d8553 = _39496407e64d(_477ec5f0eeaa)
                if _f278307d8553 >= _8af34819c3df(_fc52df97b91a):
                    raise _2d3054eea56e(f"LOCAL_RANK {_f278307d8553} out of bounds for visible GPUs {_fc52df97b91a}")
                return [_f278307d8553]  # single target

            # No rank set, fallback to all visible
            return _d0131183e828(_5f8d214ba478(_8af34819c3df(_fc52df97b91a)))
        else:
            # No CUDA_VISIBLE_DEVICES → use all available
            return _d0131183e828(_5f8d214ba478(_d81d93427c1a._a6a57237a415._f67292492c82()))

    raise _2d3054eea56e(f"Unknown DEVICE {_e991b28a4424}")


def _d7ae5ba186cd():
    """Return the preferred compute dtype for current GPU capability.

    Returns:
        torch.dtype: Preferred compute dtype (torch.bfloat16, torch.float16, or torch.float32).
    """
    _d9b14096b34f = _d81d93427c1a._289b92445ceb
    if _d81d93427c1a._a6a57237a415._3b67608be895():
        try:
            _a18bd444f5e9, _168dcb7b3028 = _d81d93427c1a._a6a57237a415._b43e1974cce7()
            # Ampere (8.0+) supports bfloat16
            if _a18bd444f5e9 >= 8:
                _d9b14096b34f = _d81d93427c1a._26eeba0af805
            else:
                _d9b14096b34f = _d81d93427c1a._36ae5f2954e8
        except _841ed8fed949:
            _d9b14096b34f = _d81d93427c1a._289b92445ceb
    return _d9b14096b34f


def _d0e8856ea3f5(_0b62b21a87a8, _73b5f272db48):
    """Return True when `trial.params` equals parameters of any past trial.

    Args:
        trial (optuna.trial.Trial): Trial to check.
        study (optuna.Study): Study to check against.

    Returns:
        bool: True if duplicate found, False otherwise.

    Raises:
        TypeError: If `trial` or `study` is None or lacks expected attributes.
    """
    if _0b62b21a87a8 is _524ba2a05836 or _73b5f272db48 is _524ba2a05836:
        raise _a5254fb06373("trial and study must be provided")

    # Get the current trial parameters
    _7a415cde2242 = _e24a018c4da9(_0b62b21a87a8, "params", _524ba2a05836)
    if _7a415cde2242 is _524ba2a05836:
        raise _a5254fb06373("trial.params is not available")

    # Check all completed trials for duplicates
    for _f2d951eb58b1 in _73b5f272db48._99eff96aa902(_abd5b6c63599=(_5b04d2c831a6._0b62b21a87a8._0a22f2ada9ee._0673779d409c,
                                               _5b04d2c831a6._0b62b21a87a8._0a22f2ada9ee._ea21c04f556f,
                                               _5b04d2c831a6._0b62b21a87a8._0a22f2ada9ee._bd8268505c94)):
        if _e24a018c4da9(_f2d951eb58b1, "params", _524ba2a05836) == _7a415cde2242:
            return _36599a7dea7d
    return _41ec058a66df


class _ee8625dd969e(_5b04d2c831a6._53d3d3470d0e._51f5911b6a77):
    """Sampler wrapper that resamples a parameter when a duplicate trial would be created.

    Args:
        base_sampler (optuna.samplers.BaseSampler): Underlying sampler to delegate to.
    """

    def _ec0f058ef57a(self, _a468185118bd: _5b04d2c831a6._53d3d3470d0e._51f5911b6a77):
        self._a468185118bd = _a468185118bd  # Use TPESampler or any other sampler

    # Override and delegate infer_relative_search_space to the base sampler
    def _a0153eb5decc(self, _73b5f272db48, _0b62b21a87a8):
        return self._a468185118bd._109451ec5cee(_73b5f272db48, _0b62b21a87a8)

    # Override and delegate sample_relative to the base sampler
    def _1aaede5b9e5c(self, _73b5f272db48, _0b62b21a87a8, _e5581901094e):
        return self._a468185118bd._b4bbfde38eb1(_73b5f272db48, _0b62b21a87a8, _e5581901094e)

    # Override sample_independent to check for duplicates
    def _ef8541a76981(self, _73b5f272db48, _0b62b21a87a8, _cae65bf0ef3c, _24ccc8ca32b1):
        """
        Sample independently using the base sampler. If the proposed parameter
        would create a duplicate trial (all params equal to a past trial),
        resample until unique.

        Args:
            study (optuna.Study)
            trial (optuna.trial.Trial)
            param_name (str)
            param_distribution: distribution object passed by Optuna

        Returns:
            The sampled parameter value.

        Raises:
            RuntimeError: If underlying base_sampler repeatedly fails to produce a non-duplicate
                          after many attempts (guard not implemented here to preserve original behavior).
        """
        while _36599a7dea7d:
            # Sample a set of hyperparameters using the base sampler (TPESampler)
            _92c6d5a88c8b = self._a468185118bd._6f6b0ae482dd(_73b5f272db48, _0b62b21a87a8, _cae65bf0ef3c, _24ccc8ca32b1)

            # Temporarily assign the parameter to the trial for comparison
            _0b62b21a87a8._fe8330bc6b28[_cae65bf0ef3c] = _92c6d5a88c8b

            # Check if this parameter set (with the current params) is a duplicate
            if not _a5507b3383fc(_0b62b21a87a8, _73b5f272db48):
                return _92c6d5a88c8b  # If not duplicate, return the parameter


def _fcf156f3cba9(_969226122bb6):
    """Compute gamma parameter for TPESampler.

    Args:
        n (int): Number of completed trials.

    Returns:
        int: Top 10% of n, capped at 25.
    """
    # top 10% of n completed trials
    return _787e007e73ad(25, _39496407e64d(0.1 * _969226122bb6))

def _f82095f88354(_22bb55a5bf38, _51cc92de1888: _662df070d5b8, _c65aa0ce8bf1=_524ba2a05836, _02ef87df8aee: _5d45beca4bb4 = _36599a7dea7d, _de6fd0daede7=_524ba2a05836, _e7deaf302790: _662df070d5b8 = _524ba2a05836):
    """
    Retrieve and validate a property from a dot-separated path (e.g. 'app.random_seed', 'run_config.batch_size').

    Args:
        props: Loaded YAML properties object (attribute/dict hybrid).
        name: Dot-separated property name (string).
        dtype: Optional type enforcement (e.g. int, float, str, "list[int]", "list[str]", etc.).
        required: If True, raises error when missing. If False, returns default.
        default: Optional fallback value when required=False and key missing.
        help: Optional human-readable hint for fixing config.

    Raises:
        AttributeError: If key missing and required=True.
        ValueError: If key exists but value is None.
        TypeError: If dtype enforcement fails.

    Returns:
        The retrieved (and possibly cast) value, or default.
    """

    # --- Navigate dotted path ---
    _6e1fbd1608a0 = _51cc92de1888._744a6185b985(".")
    _256309a3466a = _22bb55a5bf38
    _43bceffad5e5 = []
    for _95f58f50e642 in _6e1fbd1608a0:
        _43bceffad5e5._a415455e6189(_95f58f50e642)
        if _256309a3466a is _524ba2a05836:
            if _02ef87df8aee:
                raise _1b7f411896ba(
                    f"Missing required property '{'.'._11b899e3a4c7(_43bceffad5e5)}' (intermediate value is None). {_e7deaf302790 or ''}"
                )
            return _de6fd0daede7

        if _a280dd497c77(_256309a3466a, _95f58f50e642):
            _256309a3466a = _e24a018c4da9(_256309a3466a, _95f58f50e642)
        elif _70694fd9bdfb(_256309a3466a, _89ef46fd6da5) and _95f58f50e642 in _256309a3466a:
            _256309a3466a = _256309a3466a[_95f58f50e642]
        else:
            if _02ef87df8aee:
                raise _1b7f411896ba(
                    f"Missing required property '{'.'._11b899e3a4c7(_43bceffad5e5)}'. {_e7deaf302790 or ''}"
                )
            return _de6fd0daede7

    _037f28a1c7ef = _256309a3466a

    # --- Explicit null check ---
    if _037f28a1c7ef is _524ba2a05836:
        raise _2d3054eea56e(
            f"Property '{_51cc92de1888}' is explicitly null/None. Please set a valid value or remove the key to use default. {_e7deaf302790 or ''}"
        )

    # --- Dtype enforcement ---
    if _c65aa0ce8bf1 is not _524ba2a05836:
        def _52d7c0a3e11b(_8631199ec329):
            raise _a5254fb06373(f"Property '{_51cc92de1888}' type validation failed: {_8631199ec329}. {_e7deaf302790 or ''}")

        if _70694fd9bdfb(_c65aa0ce8bf1, _662df070d5b8) and _c65aa0ce8bf1._9265b42330dd("list[") and _c65aa0ce8bf1._dc6e4fcdf462("]"):
            _3cbc9d0de37a = _c65aa0ce8bf1[5:-1]._7de5cedd0988()
            if not _70694fd9bdfb(_037f28a1c7ef, _d0131183e828):
                _51189a8ecb9d(f"expected list[{_3cbc9d0de37a}], got {_b3bf7db88f34(_037f28a1c7ef).__name__}")
            _01274cd79110 = {"int": _39496407e64d, "float": _6c0631dc0444, "str": _662df070d5b8, "bool": _5d45beca4bb4}
            _7c43fd4d0f45 = _01274cd79110._8671a70a6ed2(_3cbc9d0de37a)
            if _7c43fd4d0f45 is _524ba2a05836:
                _51189a8ecb9d(f"unsupported inner dtype '{_3cbc9d0de37a}'")
            try:
                _037f28a1c7ef = [_7c43fd4d0f45(_e4f9979f5171) for _e4f9979f5171 in _037f28a1c7ef]
            except _841ed8fed949 as _3fcb765587f9:
                _51189a8ecb9d(f"failed to cast elements to {_3cbc9d0de37a}: {_3fcb765587f9}")
        else:
            try:
                _037f28a1c7ef = _c65aa0ce8bf1(_037f28a1c7ef)
            except _841ed8fed949 as _3fcb765587f9:
                _51189a8ecb9d(f"cannot cast to {_e24a018c4da9(_c65aa0ce8bf1, '__name__', _c65aa0ce8bf1)}: {_3fcb765587f9}")

    return _037f28a1c7ef


def _f52ea8dc06c1(_0b62b21a87a8: _5b04d2c831a6._0b62b21a87a8._5117795fa16d, _ff532b9bd95d: _d0131183e828, _1062af1532e8: _7952803bd46e):
    """Construct a PEFT LoraConfig from an Optuna trial's suggested hyperparameters.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance to query for hyperparameters.
        target_modules (list): list of target modules (may be empty).
        lora_task_type (Any): TaskType enum or equivalent required by LoraConfig.

    Returns:
        LoraConfig: Instance configured according to trial suggestions.

    Raises:
        Exception: Propagates exceptions from the underlying LoraConfig constructor or trial queries.
    """
    # Define the range for rank
    _c5ec762fa6a3 = _0b62b21a87a8._6aadd5883186("lora_rank", 4, 16, _44a9a60a59be=4)

    # Dynamically calculate scaling factor based on rank
    _a1ac82bd77cf = _0b62b21a87a8._6aadd5883186("lora_alpha_scaling_factor", 8, 32, _44a9a60a59be=4)
    # Add dropout options for LoRA
    _c414f5778ffc = _0b62b21a87a8._c0f292ed8395("lora_dropout", [0.0, 0.1, 0.2])

    # Create and return LoraConfig. Keep as the project's expected LoraConfig API.
    return _222d4b01528c(
        _ba709bf21f05=_c5ec762fa6a3 if not _70694fd9bdfb(_c5ec762fa6a3, _58cea023b032) else _c5ec762fa6a3[0],
        _a1ac82bd77cf=_a1ac82bd77cf if not _70694fd9bdfb(_a1ac82bd77cf, _58cea023b032) else _a1ac82bd77cf[0],
        _c414f5778ffc=_c414f5778ffc if not _70694fd9bdfb(_c414f5778ffc, _58cea023b032) else _c414f5778ffc[0],
        _ff532b9bd95d=_ff532b9bd95d if _ff532b9bd95d else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj", "embed_tokens", "lm_head"],
        _d147a527652d=_1062af1532e8
    )

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Apply LoRA to model.embedding or equivalent embedding root for decoder models.
#     """
#     log.info(f"Model Structure before applying LoRA {model}")
#     log.info("Trainable params before LoRA: %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))

#     if not isinstance(target_embedding_modules, dict):
#         log.warning("Expected target_embedding_modules dict, got %s; skipping LoRA.", type(target_embedding_modules))
#         return model

#     root = getattr(model, "module", model)
#     model_name_to_mod = dict(root.named_modules())

#     # Resolve names (object identity, exact name, suffix)
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None
#         for nm, mm in model_name_to_mod.items():
#             if mm is emb_mod:
#                 found = nm; break
#         if found is None and emb_key in model_name_to_mod:
#             found = emb_key
#         if found is None:
#             short = emb_key.replace("embedding.", "").replace("module.", "").replace("embedding.module.", "")
#             for nm in model_name_to_mod:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in model", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # shallow clone config avoiding odict_keys issues
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # cleaned target module names relative to embedding
#     cleaned_targets = []
#     for full_nm in resolved:
#         t = full_nm.replace("model.embedding.", "").replace("embedding.", "").replace("module.", "").lstrip(".")
#         if t:
#             cleaned_targets.append(t)
#     # dedupe order-preserve
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     try:
#         cfg.target_modules = list(cleaned_targets)
#     except Exception:
#         setattr(cfg, "target_modules", list(cleaned_targets))

#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- UNWRAP WRAPPERS UNDER model.embedding (in-place) ---
#     def _resolve_embedding_root(obj):
#         """
#         Return tuple (embedding_module, path_key) where path_key indicates where to reattach:
#           - "embedding" -> model.embedding
#           - "model.model.embed_tokens" -> model.model.embed_tokens
#           - "transformer.wte" -> model.transformer.wte
#         Raises ValueError if none found.
#         """
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         # some wrappers: e.g., HF models that nest inside .base_model
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Try to unwrap common wrappers under the embedding subtree (in-place)
#     def _unwrap_candidate(obj):
#         if hasattr(obj, "module") and obj is not getattr(obj, "module"):
#             return getattr(obj, "module")
#         if hasattr(obj, "base_layer") and obj is not getattr(obj, "base_layer"):
#             return getattr(obj, "base_layer")
#         return None

#     for parent_name, parent in list(emb_unwrapped.named_modules()):
#         # use named_children on parent to replace attributes on parent
#         for child_name, child in list(parent.named_children()):
#             try:
#                 inner = _unwrap_candidate(child)
#                 if inner is not None:
#                     setattr(parent, child_name, inner)
#                     log.debug("Unwrapped %s.%s -> %s", parent_name or "embedding_root", child_name, inner.__class__.__name__)
#             except Exception:
#                 log.debug("Could not unwrap child %s of parent %s", child_name, parent_name)

#     # Recompute actual embedding root after unwrapping (in case we changed .module children)
#     emb_current = emb_current  # preserve original wrapper object reference (used for reattach)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Use small container exposing embedding so PEFT only touches embedding submodules
#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)
#     # attempt to move container to same device as embedding params to avoid device errors
#     try:
#         sample_dev = None
#         for p in emb_unwrapped.parameters():
#             sample_dev = p.device; break
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Call PEFT on the embedding container
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # Reinstall wrapped embedding back into the top-level model, preserving wrapper if present
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped_emb)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped_emb
#             else:
#                 model.embedding = wrapped_emb
#         elif emb_path == "model.model.embed_tokens":
#             model.model.embed_tokens = wrapped_emb
#         elif emb_path == "transformer.wte":
#             model.transformer.wte = wrapped_emb
#         elif emb_path == "base_model.model.embed_tokens":
#             model.base_model.model.embed_tokens = wrapped_emb
#         else:
#             # fallback, attempt best-effort attach by attribute traversal
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     log.info("Applied LoRA to model.embedding (PEFT-wrapped).")

#     # Freeze non-LoRA params inside embedding; keep LoRA params trainable
#     try:
#         for name, param in model.embedding.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside model.embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in model.embedding.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("LoRA enabled %d tensors, total %d params.", len(enabled), sum(v for _, v in enabled))
#     log.info("After LoRA: trainable params %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))
#     log.info(f"Model Structure after applying LoRA {model}")
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Unified LoRA application for both BERT-like and LLaMA-like models.
#     Works with quantized or non-quantized modules.

#     Returns the input `model` with LoRA adapters applied in-place.
#     """
#     # small local helper: resolve common embedding roots
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())
#     log.info("Root type: %s", type(root))
#     log.info("Named modules sample: %s", list(named_modules.keys())[:20])
#     log.info("Target embedding keys: %s", list(target_embedding_modules.keys()))

#     # --- resolve provided target_embedding_modules to names in root.named_modules() ---
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None

#         # identity match (object identity)
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 found = nm
#                 break
#         if found:
#             resolved.append(found); continue

#         # direct string variants (embedding. prefix / without)
#         if isinstance(emb_key, str):
#             variants = [emb_key]
#             if not emb_key.startswith("embedding."):
#                 variants.append("embedding." + emb_key)
#             else:
#                 variants.append(emb_key.replace("embedding.", "", 1))
#             for v in variants:
#                 if v in named_modules:
#                     found = v; break
#         if found:
#             resolved.append(found); continue

#         # suffix match (endswith)
#         if isinstance(emb_key, str):
#             short = emb_key.replace("embedding.", "").replace("module.", "").lstrip(".")
#             for nm in named_modules:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found); continue

#         # fallback: match by class name + first parameter shape
#         try:
#             if isinstance(emb_mod, torch.nn.Module):
#                 emb_cls = emb_mod.__class__.__name__
#                 ref_shape = None
#                 for p in emb_mod.parameters():
#                     ref_shape = tuple(p.shape); break
#                 if ref_shape is not None:
#                     for nm, mm in named_modules.items():
#                         if mm.__class__.__name__ != emb_cls:
#                             continue
#                         for p in mm.parameters():
#                             if tuple(p.shape) == ref_shape:
#                                 found = nm; break
#                         if found:
#                             break
#         except Exception:
#             pass
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in root.named_modules()", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")
#     log.info("Resolved LoRA targets: %s", resolved)

#     # --- clone & normalise LoRA config ---
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # Determine embedding root and path (for normalization)
#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Embedding root resolution failed: {e}")

#     # Normalize target module names to be *relative to the module we will pass to PEFT*
#     cleaned_targets = []
#     for full in resolved:
#         # If resolved name starts with the emb_path, strip that prefix
#         if isinstance(full, str) and full.startswith(emb_path + "."):
#             cleaned = full[len(emb_path) + 1 :]
#         else:
#             # also handle common alternatives
#             cleaned = full.replace("embedding.model.", "").replace("embedding.", "").replace("model.", "").lstrip(".")
#         if cleaned:
#             cleaned_targets.append(cleaned)
#     # dedupe preserve order
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     cfg.target_modules = list(cleaned_targets)
#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- if LLaMA-like (decoder) apply LoRA directly on decoder model to avoid embedding-wrapper issues ---
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         log.info("Detected LLaMA architecture — applying LoRA directly on decoder model.")
#         try:
#             # normalize: remove "model." prefix so PEFT matches internal names
#             cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]
#             # cfg.target_modules must be relative to model.embedding.model (we already normalized above)
#             wrapped_decoder = get_peft_model(model.embedding.model, cfg)
#             # replace decoder in-place
#             model.embedding.model = wrapped_decoder

#             # freeze everything except LoRA params inside the wrapped decoder
#             for n, p in model.embedding.model.named_parameters():
#                 p.requires_grad = ("lora" in n.lower())

#             log.info("Applied LoRA to LLaMA decoder; trainable params: %d",
#                      sum(1 for _, p in model.embedding.model.named_parameters() if p.requires_grad))
#             return model
#         except Exception as e:
#             log.error("Failed to apply LoRA directly on LLaMA decoder: %s", e)
#             raise

#     # --- otherwise: create container exposing 'embedding' so PEFT touches only embedding subtree ---
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # attach generation helper if root implements it (prevents PEFT complaining)
#     if hasattr(root, "prepare_inputs_for_generation"):
#         try:
#             setattr(emb_container, "prepare_inputs_for_generation", getattr(root, "prepare_inputs_for_generation"))
#         except Exception:
#             # non-fatal
#             pass

#     # move container to embedding device if known
#     try:
#         sample_dev = next((p.device for p in emb_unwrapped.parameters()), None)
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Wrap the container with PEFT
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # obtain wrapped embedding module and reattach into the model at emb_path
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         parts = emb_path.split(".")
#         tgt = model
#         for p in parts[:-1]:
#             tgt = getattr(tgt, p)
#         setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     # Freeze non-LoRA params inside the wrapped embedding; keep LoRA params trainable
#     try:
#         for name, param in wrapped_emb.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside wrapped embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in wrapped_emb.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("Applied LoRA successfully with %d trainable tensors.", len(enabled))
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     # ------------------------------------------------------------------
#     # Helper: ensure PEFT-required method exists
#     # ------------------------------------------------------------------
#     def _ensure_prepare_inputs_for_generation(obj, fallback):
#         if hasattr(obj, "prepare_inputs_for_generation"):
#             return
#         if hasattr(fallback, "prepare_inputs_for_generation"):
#             obj.prepare_inputs_for_generation = fallback.prepare_inputs_for_generation
#             return

#         def _noop_prepare_inputs_for_generation(*args, **kwargs):
#             return args[0] if args else None

#         obj.prepare_inputs_for_generation = _noop_prepare_inputs_for_generation

#     # ------------------------------------------------------------------
#     # Helper: resolve embedding root (unchanged logic)
#     # ------------------------------------------------------------------
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())

#     # ------------------------------------------------------------------
#     # Resolve target embedding modules (unchanged)
#     # ------------------------------------------------------------------
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 resolved.append(nm)
#                 break

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # ------------------------------------------------------------------
#     # Clone LoRA config
#     # ------------------------------------------------------------------
#     try:
#         cfg = lora_config.__class__(**vars(lora_config))
#     except Exception:
#         cfg = lora_config

#     # ------------------------------------------------------------------
#     # Normalize target module names
#     # ------------------------------------------------------------------
#     emb_current, emb_path = _resolve_embedding_root(model)

#     cleaned_targets = []
#     for full in resolved:
#         if full.startswith(emb_path + "."):
#             cleaned_targets.append(full[len(emb_path) + 1 :])

#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")

#     cfg.target_modules = cleaned_targets

#     # ------------------------------------------------------------------
#     # Detect LLaMA-style decoder (unchanged intent)
#     # ------------------------------------------------------------------
#     is_llama_decoder = (
#         hasattr(model, "embedding")
#         and hasattr(model.embedding, "model")
#         and hasattr(model.embedding.model, "layers")
#     )

#     is_gemma_decoder = (
#         hasattr(model, "model")
#         and hasattr(model.model, "model")
#         and hasattr(model.model.model, "layers")
#     )

#     # ------------------------------------------------------------------
#     # LLaMA decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_llama_decoder:
#         decoder = model.embedding.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.embedding.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model
    
#     # ------------------------------------------------------------------
#     # gemma decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_gemma_decoder:
#         decoder = model.model.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.model.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model

#     # ------------------------------------------------------------------
#     # Embedding-container path (PATCHED)
#     # ------------------------------------------------------------------
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # CRITICAL FIX: ensure hook exists UNCONDITIONALLY
#     _ensure_prepare_inputs_for_generation(emb_container, root)

#     wrapped_container = get_peft_model(emb_container, cfg)
#     wrapped_emb = wrapped_container.embedding

#     # Reattach wrapped embedding
#     parts = emb_path.split(".")
#     tgt = model
#     for p in parts[:-1]:
#         tgt = getattr(tgt, p)
#     setattr(tgt, parts[-1], wrapped_emb)

#     for name, param in wrapped_emb.named_parameters():
#         param.requires_grad = ("lora" in name.lower())

#     return model

def _852e0f9af709(
    _922ce048d075: "torch.nn.Module",
    _91cf3aab3d13: "Dict[str, torch.nn.Module]",
    _847877c0b185,
    _2e87d8ab8d7a: "Any"
) -> "torch.nn.Module":

    def _99f31d8c339d(_7e63a569aa7a, _6bbc1e291fb3):
        if _a280dd497c77(_7e63a569aa7a, "prepare_inputs_for_generation"):
            return
        if _a280dd497c77(_6bbc1e291fb3, "prepare_inputs_for_generation"):
            _7e63a569aa7a._a8103d92fdcf = _6bbc1e291fb3._a8103d92fdcf
            return

        def _67b8b07222aa(*_59adccf3a91b, **_f21802a8662e):
            return _59adccf3a91b[0] if _59adccf3a91b else _524ba2a05836

        _7e63a569aa7a._a8103d92fdcf = _0933ee7c8e3f

    def _9a1b8b48fd34(_7e63a569aa7a):
        if _a280dd497c77(_7e63a569aa7a, "embedding"):
            return _e24a018c4da9(_7e63a569aa7a, "embedding"), "embedding"
        if _a280dd497c77(_7e63a569aa7a, "model") and _a280dd497c77(_7e63a569aa7a._922ce048d075, "embed_tokens"):
            return _e24a018c4da9(_7e63a569aa7a._922ce048d075, "embed_tokens"), "model.embed_tokens"
        if _a280dd497c77(_7e63a569aa7a, "model") and _a280dd497c77(_7e63a569aa7a._922ce048d075, "model") and _a280dd497c77(_7e63a569aa7a._922ce048d075._922ce048d075, "embed_tokens"):
            return _e24a018c4da9(_7e63a569aa7a._922ce048d075._922ce048d075, "embed_tokens"), "model.model.embed_tokens"
        if _a280dd497c77(_7e63a569aa7a, "transformer") and _a280dd497c77(_7e63a569aa7a._8cd43b333fe8, "wte"):
            return _e24a018c4da9(_7e63a569aa7a._8cd43b333fe8, "wte"), "transformer.wte"
        if _a280dd497c77(_7e63a569aa7a, "base_model") and _a280dd497c77(_7e63a569aa7a._4182c420fd9c, "model") and _a280dd497c77(_7e63a569aa7a._4182c420fd9c._922ce048d075, "embed_tokens"):
            return _e24a018c4da9(_7e63a569aa7a._4182c420fd9c._922ce048d075, "embed_tokens"), "base_model.model.embed_tokens"
        raise _2d3054eea56e(f"Could not resolve embedding root for {_7e63a569aa7a._6b5e0d33eddd.__name__}")

    _7f2903d420c8 = _e24a018c4da9(_922ce048d075, "module", _922ce048d075)
    _94f8a878a57b = _89ef46fd6da5(_7f2903d420c8._94f8a878a57b())

    # --------------------------------------------------
    # Detect decoders FIRST (ONLY MOVED)
    # --------------------------------------------------
    _452af569f76f = (
        _a280dd497c77(_922ce048d075, "embedding")
        and _a280dd497c77(_922ce048d075._5bff2c7fa11b, "model")
        and _a280dd497c77(_922ce048d075._5bff2c7fa11b._922ce048d075, "layers")
    )

    _c0e2fb1b3e21 = (
        _a280dd497c77(_922ce048d075, "model")
        and _a280dd497c77(_922ce048d075._922ce048d075, "model")
        and _a280dd497c77(_922ce048d075._922ce048d075._922ce048d075, "layers")
    )

    _b50698dc1c76 = (
        _a280dd497c77(_922ce048d075, "model")
        and _a280dd497c77(_922ce048d075._922ce048d075, "layers")
    )

    # --------------------------------------------------
    # Resolve target embedding modules (UNCHANGED)
    # --------------------------------------------------
    _63340ff07e11 = []
    for _24c28ad3df52, _aa037a8d1cb8 in _91cf3aab3d13._75da506dae97():
        for _41ec49c2fa89, _010ad48d0dc5 in _94f8a878a57b._75da506dae97():
            if _010ad48d0dc5 is _aa037a8d1cb8:
                _63340ff07e11._a415455e6189(_41ec49c2fa89)
                break

    if not _63340ff07e11 and not _452af569f76f and not _c0e2fb1b3e21 and not _b50698dc1c76:
        raise _2d3054eea56e("No embedding submodules resolved for LoRA — skipping.")

    # --------------------------------------------------
    # Clone LoRA config (UNCHANGED)
    # --------------------------------------------------
    try:
        _782371dbdc78 = _847877c0b185._6b5e0d33eddd(**_0a674c89bd7a(_847877c0b185))
    except _841ed8fed949:
        _782371dbdc78 = _847877c0b185

    # --------------------------------------------------
    # Normalize target module names (UNCHANGED)
    # --------------------------------------------------
    _c429656d449a, _2993fa786e19 = _1bff962d968f(_922ce048d075)

    _5375134d3b1a = []
    for _a24419a502b8 in _63340ff07e11:
        if _a24419a502b8._9265b42330dd(_2993fa786e19 + "."):
            _5375134d3b1a._a415455e6189(_a24419a502b8[_8af34819c3df(_2993fa786e19) + 1 :])

    if _5375134d3b1a:
        _782371dbdc78._ff532b9bd95d = _5375134d3b1a

    # --------------------------------------------------
    # LLaMA decoder path (UNCHANGED)
    # --------------------------------------------------
    if _452af569f76f:
        _ee3079040e06 = _922ce048d075._5bff2c7fa11b._922ce048d075
        _8d0eaea34b6b(_ee3079040e06, _922ce048d075)
        _782371dbdc78._ff532b9bd95d = [_14b371b1f9eb._12525aa774aa("model.", "") for _14b371b1f9eb in _782371dbdc78._ff532b9bd95d]
        _179495412691 = _a76bf7f4a7b0(_ee3079040e06, _782371dbdc78)
        _922ce048d075._5bff2c7fa11b._922ce048d075 = _179495412691
        for _969226122bb6, _95f58f50e642 in _179495412691._f2aca8219ca9():
            _95f58f50e642._e785a1d5196d = ("lora" in _969226122bb6._df056d9bbcc7())
        return _922ce048d075

    # --------------------------------------------------
    # Gemma decoder path (UNCHANGED)
    # --------------------------------------------------
    if _c0e2fb1b3e21:
        _ee3079040e06 = _922ce048d075._922ce048d075._922ce048d075
        _8d0eaea34b6b(_ee3079040e06, _922ce048d075)
        _782371dbdc78._ff532b9bd95d = [_14b371b1f9eb._12525aa774aa("model.", "") for _14b371b1f9eb in _782371dbdc78._ff532b9bd95d]
        _179495412691 = _a76bf7f4a7b0(_ee3079040e06, _782371dbdc78)
        _922ce048d075._922ce048d075._922ce048d075 = _179495412691
        for _969226122bb6, _95f58f50e642 in _179495412691._f2aca8219ca9():
            _95f58f50e642._e785a1d5196d = ("lora" in _969226122bb6._df056d9bbcc7())
        return _922ce048d075
    
    # --------------------------------------------------
    # Qwen decoder path (UNCHANGED)
    # --------------------------------------------------
    if _b50698dc1c76:
        _ee3079040e06 = _922ce048d075._922ce048d075
        _8d0eaea34b6b(_ee3079040e06, _922ce048d075)
        _782371dbdc78._ff532b9bd95d = [_14b371b1f9eb._12525aa774aa("model.", "") for _14b371b1f9eb in _782371dbdc78._ff532b9bd95d]
        _179495412691 = _a76bf7f4a7b0(_ee3079040e06, _782371dbdc78)
        _922ce048d075._922ce048d075 = _179495412691
        for _969226122bb6, _95f58f50e642 in _179495412691._f2aca8219ca9():
            _95f58f50e642._e785a1d5196d = ("lora" in _969226122bb6._df056d9bbcc7())
        return _922ce048d075

    # --------------------------------------------------
    # Embedding path (UNCHANGED)
    # --------------------------------------------------
    _a4db38e172a5 = _e24a018c4da9(_c429656d449a, "module", _c429656d449a)

    class _33092ce207c8(_d81d93427c1a._c45278b00078._7a76288dde4d):
        def _ec0f058ef57a(self, _6ce7d7e1714d):
            _8c4b826f8b15()._7577560c19c4()
            self._5bff2c7fa11b = _6ce7d7e1714d

    _0ce889078f06 = _aac40c98847b(_a4db38e172a5)
    _8d0eaea34b6b(_0ce889078f06, _7f2903d420c8)

    _c15b50d70896 = _a76bf7f4a7b0(_0ce889078f06, _782371dbdc78)
    _93f688607f29 = _c15b50d70896._5bff2c7fa11b

    _6e1fbd1608a0 = _2993fa786e19._744a6185b985(".")
    _362db3dc41c9 = _922ce048d075
    for _95f58f50e642 in _6e1fbd1608a0[:-1]:
        _362db3dc41c9 = _e24a018c4da9(_362db3dc41c9, _95f58f50e642)
    _4b65c5713a91(_362db3dc41c9, _6e1fbd1608a0[-1], _93f688607f29)

    for _51cc92de1888, _92c6d5a88c8b in _93f688607f29._f2aca8219ca9():
        _92c6d5a88c8b._e785a1d5196d = ("lora" in _51cc92de1888._df056d9bbcc7())

    return _922ce048d075


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> "torch.nn.Module":
#     """
#     Reverse of apply_lora_to_model (focused on embedding subtree).
#     - Resolves the same embedding root as apply_lora_to_model.
#     - Prefers calling PEFT's merge API if present on the embedding wrapper.
#     - Otherwise performs a manual merge of inline lora wrappers (base_layer + lora_A/lora_B).
#     - Replaces wrapper modules with their base_layer so the final model contains plain nn.Modules.
#     - Works with ModuleDict(default=...), ParameterDict, and common lora_alpha container formats.
#     """
#     if log is None:
#         import logging
#         log = logging.getLogger(__name__)

#     import torch
#     from typing import Any, Dict

#     root = getattr(model, "module", model)

#     # --- Resolve embedding root using the same heuristics as apply_lora_to_model ---
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # --- Try PEFT merge if available (embedding-level) ---
#     try:
#         if hasattr(emb_current, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on embedding wrapper.")
#             merged = emb_current.merge_and_unload()
#             wrapped = merged if merged is not None else emb_current
#             # reattach to model according to emb_path (preserve wrapper if it exists)
#             try:
#                 if emb_path == "embedding":
#                     if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                         try:
#                             setattr(emb_current, "module", wrapped)
#                             model.embedding = emb_current
#                         except Exception:
#                             model.embedding = wrapped
#                     else:
#                         model.embedding = wrapped
#                 else:
#                     parts = emb_path.split(".")
#                     tgt = model
#                     for p in parts[:-1]:
#                         tgt = getattr(tgt, p)
#                     setattr(tgt, parts[-1], wrapped)
#                 log.info("PEFT embedding merge_and_unload() succeeded.")
#                 return model
#             except Exception:
#                 # if reattach fails, continue to manual merge
#                 log.warning("PEFT merge succeeded but reattach failed; continuing to manual merge.")
#         if hasattr(emb_unwrapped, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on emb_unwrapped.")
#             merged = emb_unwrapped.merge_and_unload()
#             wrapped = merged if merged is not None else emb_unwrapped
#             # try to reattach preserving wrapper
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped
#             else:
#                 parts = emb_path.split(".")
#                 tgt = model
#                 for p in parts[:-1]:
#                     tgt = getattr(tgt, p)
#                 setattr(tgt, parts[-1], wrapped)
#             log.info("PEFT emb_unwrapped merge_and_unload() succeeded.")
#             return model
#     except Exception as e:
#         log.warning("PEFT merge attempt raised: %s -- falling back to manual merge", e)

#     # --- Helpers for manual merge ---
#     def _normalize_alpha(alpha_raw):
#         # return float or None
#         try:
#             if alpha_raw is None:
#                 return None
#             if isinstance(alpha_raw, dict):
#                 # pick the first scalar-like value
#                 for v in alpha_raw.values():
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     # if v is a tensor scalar
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             continue
#                 # fallback: try first value cast
#                 try:
#                     return float(list(alpha_raw.values())[0])
#                 except Exception:
#                     return None
#             # ModuleDict or module with numeric attr/buffer
#             if hasattr(alpha_raw, "__class__") and "Module" in alpha_raw.__class__.__name__:
#                 # try attribute names
#                 for a in ("lora_alpha", "alpha"):
#                     v = getattr(alpha_raw, a, None)
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             pass
#                 # try parameters
#                 try:
#                     ps = list(alpha_raw.parameters())
#                     if ps:
#                         return float(ps[0].item())
#                 except Exception:
#                     pass
#                 return None
#             if isinstance(alpha_raw, (list, tuple)):
#                 if not alpha_raw:
#                     return None
#                 return float(alpha_raw[0])
#             if isinstance(alpha_raw, (int, float)):
#                 return float(alpha_raw)
#             # attempt cast
#             return float(alpha_raw)
#         except Exception:
#             return None

#     def _unwrap_map(obj) -> Dict[str, Any]:
#         """
#         Normalize lora_A / lora_B into a dict name->module/param object.
#         Accepts Module (single), ModuleDict/dict, ParameterDict-like.
#         """
#         out = {}
#         try:
#             # single module (not ModuleDict)
#             if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                 out[""] = obj
#                 return out
#         except Exception:
#             pass
#         # mapping-like
#         try:
#             items = list(obj.items())
#         except Exception:
#             items = []
#         for k, v in items:
#             out[k] = v
#         return out

#     def _tensor_from_obj(x):
#         # return a torch.Tensor (raw data) or None
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first param
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#             return None
#         if isinstance(x, torch.Tensor):
#             return x
#         return None

#     def _compute_delta(A_w, B_w, base):
#         """
#         Robustly compute delta for given A_w, B_w and base.weight shape.
#         Tries: B@A, A@B, inference from flattened tensors (reshape using base shape),
#         and chunked-sum heuristics. Raises RuntimeError if impossible.
#         """
#         # quick guards
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # common case: A 2D (r,in), B 2D (out,r) -> B@A
#         if A_w.dim() == 2 and B_w.dim() == 2 and B_w.shape[1] == A_w.shape[0]:
#             return B_w @ A_w

#         # if either is 1D (flattened), try to infer r using base shape
#         base_out = int(base.weight.shape[0])
#         base_in = int(base.weight.shape[1])
#         A_num = int(A_w.numel())
#         B_num = int(B_w.numel())

#         # attempt reshape inference: try r candidate derived from counts
#         # If B_num == base_out * r and A_num == r * base_in => reshape and B@A
#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat
#             # try candidate from A
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat

#         # try simple transpose fallbacks
#         try:
#             return B_w @ A_w
#         except Exception:
#             pass
#         try:
#             return A_w @ B_w
#         except Exception:
#             pass

#         # chunked heuristic: if one inner-dim is integer multiple of the other
#         try:
#             # promote to 2D (best-effort)
#             A_mat = A_w if A_w.dim() == 2 else A_w.view(A_w.shape[0], -1)
#             B_mat = B_w if B_w.dim() == 2 else B_w.view(-1, B_w.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)} for base {tuple(base.weight.shape)}")

#     # --- Manual merge walk under embedding subtree ---
#     merged = 0
#     replaced = 0
#     # iterate parents so we can setattr on them
#     for parent in list(emb_unwrapped.modules()):
#         for child_name, child in list(parent.named_children()):
#             # target wrappers: have base_layer and lora_A/lora_B
#             if not hasattr(child, "base_layer"):
#                 continue
#             if not (hasattr(child, "lora_A") and hasattr(child, "lora_B")):
#                 # attempt simple unwraps (module/base_layer) to remove wrapper objects
#                 try:
#                     if hasattr(child, "module") and child is not getattr(child, "module"):
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> module", type(parent).__name__, child_name)
#                         continue
#                     if hasattr(child, "base_layer"):
#                         setattr(parent, child_name, getattr(child, "base_layer"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> base_layer", type(parent).__name__, child_name)
#                         continue
#                 except Exception:
#                     pass
#                 continue

#             base = getattr(child, "base_layer", None)
#             if base is None or not hasattr(base, "weight"):
#                 log.warning("Skipping %s: no base_layer.weight", child_name)
#                 continue

#             # normalize maps
#             A_map = _unwrap_map(getattr(child, "lora_A", None))
#             B_map = _unwrap_map(getattr(child, "lora_B", None))
#             if not A_map or not B_map:
#                 # attempt remove wrapper if no A/B entries
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (empty A/B).", child_name)
#                 except Exception:
#                     log.warning("Could not replace empty wrapper %s", child_name)
#                 continue

#             # normalize alpha
#             alpha_raw = getattr(child, "lora_alpha", None)
#             alpha = _normalize_alpha(alpha_raw)

#             applied_here = 0
#             # iterate keys (broadcast single->many by using "" key)
#             keys = sorted(set(A_map.keys()) | set(B_map.keys()))
#             for k in keys:
#                 A_obj = A_map.get(k) or A_map.get("")
#                 B_obj = B_map.get(k) or B_map.get("")
#                 A_w = _tensor_from_obj(A_obj)
#                 B_w = _tensor_from_obj(B_obj)
#                 if A_w is None or B_w is None:
#                     log.debug("Skipping %s key=%s: A/B tensor not found", child_name, k)
#                     continue

#                 # handle zero-length adapters by removing wrapper aggressively (safe for plain model)
#                 if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                     log.warning("Empty/zero-dim A/B for %s key=%s — replacing wrapper with base.", child_name, k)
#                     try:
#                         setattr(parent, child_name, base)
#                         replaced += 1
#                         applied_here = 0
#                     except Exception as e:
#                         log.warning("Could not replace wrapper %s: %s", child_name, e)
#                     break  # move to next child

#                 try:
#                     # compute delta robustly
#                     delta = _compute_delta(A_w, B_w, base)
#                     # scale detection r and alpha
#                     r = A_w.shape[0] if A_w.dim() >= 1 else None
#                     scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0
#                     # apply under no_grad
#                     with torch.no_grad():
#                         base.weight.data += delta.to(base.weight.device, base.weight.dtype) * scale
#                     applied_here += 1
#                     merged += 1
#                     log.info("Merged LoRA into %s key=%s (scale=%s, delta_shape=%s)", child_name, k, scale, tuple(delta.shape))
#                 except Exception as e:
#                     log.warning("Failed computing LoRA delta for %s key=%s: %s", child_name, k, e)
#                     # continue trying other keys

#             # after keys processed, if any applied -> replace wrapper with base
#             if applied_here > 0:
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base after applying %d delta(s).", child_name, applied_here)
#                 except Exception as e:
#                     log.warning("Applied deltas but failed to replace wrapper %s: %s", child_name, e)
#             else:
#                 # no deltas applied; still try to remove wrapper for Lightning compatibility
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (no deltas applied).", child_name)
#                 except Exception as e:
#                     log.warning("Could not replace wrapper %s: %s", child_name, e)

#     # Reattach emb_unwrapped back to model if necessary (preserve wrapper object when possible)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # already mutated in-place for wrappers we replaced above; ignore attach errors
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers.", merged, replaced)
#     log.info(f"Model Structure after removing LoRA {model}")
#     return model


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> Tuple["torch.nn.Module", Dict[str, Any]]:
#     """
#     Reverse of apply_lora_to_model. Minimal-disruption strategy:
#       1) Try PEFT's merge APIs on high-level wrappers (safe).
#       2) If not available, do conservative manual merges:
#          - Only add computed LoRA delta into base.weight when base.weight.dtype is floating.
#          - If base.weight is quantized / non-floating (Byte/Int) or wrapper weight shapes mismatch,
#            skip numeric merge and replace wrapper with base_layer/module to avoid corrupting quant params.
#       3) Always replace wrapper modules with underlying base module to remove PEFT wrappers (so model is runnable).
#     Returns: (model, summary)
#       summary: {merged: int, replaced: int, skipped: int, warnings: [..], details: [..]}
#     """
#     if log is None:
#         log = logging.getLogger(__name__)

#     summary = {"merged": 0, "replaced": 0, "skipped": 0, "warnings": [], "details": []}

#     root = getattr(model, "module", model)

#     # same embedding resolver as apply_lora_to_model
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or a known embed_tokens ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # helper: attempt PEFT merge_and_unload on an object (safe)
#     def _try_peft_merge(obj, ctx_name: str) -> bool:
#         for attr in ("merge_and_unload", "merge_and_unload_legacy", "merge", "unload"):
#             fn = getattr(obj, attr, None)
#             if callable(fn):
#                 try:
#                     log.info("Calling %s() on %s", attr, ctx_name)
#                     res = fn()  # many APIs return None, some return the merged/base module
#                     summary["details"].append(f"Called {attr} on {ctx_name}")
#                     summary["merged"] += 1
#                     # if function returned a module, try to reattach above after caller handles
#                     return True
#                 except Exception as e:
#                     summary["warnings"].append(f"{ctx_name}.{attr}() raised: {e}")
#                     # continue trying other attrs
#         return False

#     # try high-level merges first (LLaMA decoder path)
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         # top-level peft wrapper might be model.embedding.model or model.embedding.model.* (PeftModelForCausalLM)
#         decoder = model.embedding.model
#         attached = False
#         # If decoder is a Peft wrapper, try calling merge_and_unload on it
#         if _try_peft_merge(decoder, "model.embedding.model"):
#             # after merge, try to reassign if merge returned something — some APIs inplace-change
#             # we still proceed to safer manual unwrapping pass later to catch nested wrappers
#             attached = True
#         # also try top-level embedding wrapper
#         if _try_peft_merge(model.embedding, "model.embedding"):
#             attached = True

#         # perform conservative unwrap / manual merge walk under decoder subtree
#         # We'll traverse decoder modules and apply manual merge only for floating base weights.
#         summary_walk = _manual_merge_walk(decoder, log, summary)  # function defined below
#         summary.update(summary_walk)
#         # ensure model.embedding.model remains set (if libra returned new module, it's usually already attached)
#         return model, summary

#     # Non-llama path: embedding container was created by apply -> there is an emb_unwrapped that got wrapped by PEFT.
#     # Try peft merge on emb_current (wrapper) and on emb_unwrapped
#     if _try_peft_merge(emb_current, f"{emb_path} (emb_current)"):
#         # PEFT merge done (or attempted). Still walk and clean wrappers to ensure no leftover fields.
#         pass
#     elif _try_peft_merge(emb_unwrapped, f"{emb_path} (emb_unwrapped)"):
#         pass

#     # if PEFT merge didn't exist/ succeed, fallback to conservative manual merging
#     summary_walk = _manual_merge_walk(emb_unwrapped, log, summary)
#     summary.update(summary_walk)

#     # Reattach candidate back to model (preserve wrapperless object)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             # try preserve wrapper object if existed
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # ignore reattach errors; model already mutated in place for replaced wrappers
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.",
#              summary.get("merged", 0), summary.get("replaced", 0), summary.get("skipped", 0))
#     return model


# Helper: manual merge walker (conservative)
# def _manual_merge_walk(root_module: "torch.nn.Module", log: Any, summary: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Walk modules under `root_module` and:
#       - For children that have .base_layer and lora_A/lora_B try to compute delta and add to base.weight
#         ONLY IF base.weight.dtype is floating (float32/float16/bfloat16).
#       - If base.weight is quantized/non-floating or shapes are incompatible, replace wrapper with base
#         (no numeric merge) to avoid corrupting quant metadata.
#       - If child has .module wrapper (PEFT/other), replace with child.module
#     Returns partial summary updates.
#     """
#     import torch
#     merged = summary.get("merged", 0)
#     replaced = summary.get("replaced", 0)
#     skipped = summary.get("skipped", 0)

#     def _is_floating_dtype(dt):
#         return dt in (torch.float32, torch.float16, torch.bfloat16)

#     def _tensor_from_obj(x):
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.Tensor):
#             return x
#         # Module: try weight param
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first parameter
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#         return None

#     def _compute_delta(A_w, B_w, base_w):
#         """
#         Robust compute similar to previous logic; returns tensor on CPU (float) if possible.
#         Will raise RuntimeError if impossible.
#         """
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # Bring tensors to float32 cpu for computation (do not change original module tensors)
#         A_f = A_w.detach().to(torch.float32).cpu()
#         B_f = B_w.detach().to(torch.float32).cpu()

#         # common: A (r, in), B (out, r) => B @ A
#         if A_f.dim() == 2 and B_f.dim() == 2 and B_f.shape[1] == A_f.shape[0]:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)

#         # try reshape inference using base shape
#         base_out = int(base_w.shape[0])
#         base_in = int(base_w.shape[1])
#         A_num = int(A_f.numel())
#         B_num = int(B_f.numel())

#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)

#         # fallbacks
#         try:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass
#         try:
#             return (A_f @ B_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass

#         # chunked heuristics (rare)
#         try:
#             A_mat = A_f if A_f.dim() == 2 else A_f.view(A_f.shape[0], -1)
#             B_mat = B_f if B_f.dim() == 2 else B_f.view(-1, B_f.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)} for base {tuple(base_w.shape)}")

#     # iterate parents so we can setattr on them
#     for parent in list(root_module.modules()):
#         for child_name, child in list(parent.named_children()):
#             # 1) If wrapper exposes PEFT API, try merge_and_unload first
#             try:
#                 if hasattr(child, "merge_and_unload") and callable(getattr(child, "merge_and_unload")):
#                     try:
#                         log.info("Calling merge_and_unload() on %s.%s", type(parent).__name__, child_name)
#                         child.merge_and_unload()
#                         # After PEFT merge, if child has module/base_layer then replace
#                         repl = getattr(child, "module", None) or getattr(child, "base_layer", None) or getattr(child, "base_model", None)
#                         if repl is not None and repl is not child:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"PEFT merged & replaced {type(parent).__name__}.{child_name}")
#                             continue
#                         else:
#                             # if merge_and_unload didn't return module, try to just remove wrapper by replacing with base if exists
#                             base = getattr(child, "base_layer", None) or getattr(child, "module", None)
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"PEFT merged (no return) and replaced {type(parent).__name__}.{child_name}")
#                                 continue
#                     except Exception as e:
#                         summary["warnings"].append(f"child.merge_and_unload failed {type(parent).__name__}.{child_name}: {e}")
#                         # fallthrough to manual strategies
#                 # 2) If there is a 'module' wrapper, unwrap it (safe)
#                 if hasattr(child, "module") and child is not getattr(child, "module"):
#                     try:
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         summary["details"].append(f"Unwrapped module {type(parent).__name__}.{child_name} -> module")
#                         continue
#                     except Exception:
#                         pass

#                 # 3) If base_layer + lora_A/lora_B perform conservative numeric merge only if base is floating dtype
#                 if hasattr(child, "base_layer") and (hasattr(child, "lora_A") or hasattr(child, "lora_B")):
#                     base = getattr(child, "base_layer", None)
#                     if base is None or not hasattr(base, "weight"):
#                         # can't merge numerically; just replace wrapper with base if possible
#                         try:
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no weight to merge)")
#                                 continue
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base")
#                             skipped += 1
#                             continue

#                     # get A/B tensors (may be ModuleDict / dict / Parameter)
#                     A_obj = getattr(child, "lora_A", None)
#                     B_obj = getattr(child, "lora_B", None)

#                     # support mappinglike or direct module
#                     def _unwrap_map(obj):
#                         out = {}
#                         if obj is None:
#                             return out
#                         if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                             out[""] = obj
#                             return out
#                         # mapping-like
#                         try:
#                             items = list(obj.items())
#                         except Exception:
#                             items = []
#                         for k, v in items:
#                             out[k] = v
#                         return out

#                     A_map = _unwrap_map(A_obj)
#                     B_map = _unwrap_map(B_obj)
#                     if not A_map or not B_map:
#                         # nothing numeric to merge; replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (empty A/B)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace empty wrapper {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # check dtype of base weight -> only attempt numeric merge for floating dtypes
#                     base_w = base.weight if hasattr(base, "weight") else None
#                     if base_w is None:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                             skipped += 1
#                         continue

#                     if not _is_floating_dtype(base_w.dtype):
#                         # quantized or non-floating base: avoid numeric merge; simply replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Skipped numeric merge for quantized base {type(parent).__name__}.{child_name}; replaced wrapper with base")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper for quantized base {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # attempt per-key merge
#                     applied_here = 0
#                     for k in sorted(set(A_map.keys()) | set(B_map.keys())):
#                         A_obj_k = A_map.get(k) or A_map.get("")
#                         B_obj_k = B_map.get(k) or B_map.get("")
#                         A_w = _tensor_from_obj(A_obj_k)
#                         B_w = _tensor_from_obj(B_obj_k)
#                         if A_w is None or B_w is None:
#                             summary["details"].append(f"Skipping key={k} for {type(parent).__name__}.{child_name}: A/B tensor not found")
#                             continue

#                         # check empty shapes
#                         if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                             # unsafe to compute; replace wrapper
#                             try:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Empty/zero-dim A/B for {type(parent).__name__}.{child_name} key={k}; replaced with base")
#                             except Exception as e:
#                                 summary["warnings"].append(f"Could not replace wrapper after empty A/B {type(parent).__name__}.{child_name}: {e}")
#                                 skipped += 1
#                             applied_here = 0
#                             break

#                         try:
#                             delta = _compute_delta(A_w, B_w, base_w)
#                             # detect r for scaling; fallback scale 1.0 if unknown
#                             r = None
#                             try:
#                                 r = int(A_w.shape[0]) if getattr(A_w, "dim", None) and A_w.dim() >= 1 else None
#                             except Exception:
#                                 r = None
#                             alpha_raw = getattr(child, "lora_alpha", None)
#                             alpha = None
#                             # attempt to normalize alpha scalar
#                             try:
#                                 if alpha_raw is None:
#                                     alpha = None
#                                 elif isinstance(alpha_raw, (int, float)):
#                                     alpha = float(alpha_raw)
#                                 elif isinstance(alpha_raw, dict):
#                                     # pick first numeric
#                                     for vv in alpha_raw.values():
#                                         if isinstance(vv, (int, float)):
#                                             alpha = float(vv)
#                                             break
#                                 elif hasattr(alpha_raw, "item"):
#                                     alpha = float(alpha_raw.item())
#                             except Exception:
#                                 alpha = None
#                             scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0

#                             with torch.no_grad():
#                                 base_w.data += delta.to(base_w.device, base_w.dtype) * float(scale)
#                             applied_here += 1
#                             merged += 1
#                             summary["details"].append(f"Merged LoRA into {type(parent).__name__}.{child_name} key={k} (scale={scale}, delta={tuple(delta.shape)})")
#                         except Exception as e:
#                             summary["warnings"].append(f"Failed computing LoRA delta for {type(parent).__name__}.{child_name} key={k}: {e}")
#                             # do not abort — try other keys

#                     # after keys processed: if we applied any merges, replace wrapper with base
#                     if applied_here > 0:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base after applying {applied_here} deltas")
#                         except Exception as e:
#                             summary["warnings"].append(f"Applied deltas but failed to replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1
#                     else:
#                         # no deltas applied -> replace wrapper anyway
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no deltas applied)")
#                         except Exception as e:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1

#                     continue  # next child

#                 # 4) base_model / model attribute replacement (PeftModel wrappers)
#                 if hasattr(child, "base_model") and getattr(child, "base_model") is not None and getattr(child, "base_model") is not child:
#                     try:
#                         setattr(parent, child_name, getattr(child, "base_model"))
#                         replaced += 1
#                         summary["details"].append(f"Replaced {type(parent).__name__}.{child_name} with base_model")
#                         continue
#                     except Exception:
#                         pass

#                 # 5) SafeModuleWrapper unwrapping
#                 cname = child.__class__.__name__.lower()
#                 if "safemodulewrapper" in cname or cname.startswith("_safemodulewrapper"):
#                     repl = getattr(child, "module", None)
#                     if repl is not None:
#                         try:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"Unwrapped SafeModuleWrapper {type(parent).__name__}.{child_name}")
#                             continue
#                         except Exception:
#                             pass

#                 # If none matched — skip safely
#                 skipped += 1
#                 summary["details"].append(f"Skipped {type(parent).__name__}.{child_name} (no wrapper/base_layer found)")
#             except Exception as e_parent_child:
#                 summary["warnings"].append(f"Error while inspecting {type(parent).__name__}.{child_name}: {e_parent_child}")
#                 skipped += 1
#                 continue

#     # update and return summary diffs
#     summary["merged"] = merged
#     summary["replaced"] = replaced
#     summary["skipped"] = skipped
#     return summary

# def merge_lora_into_base(model, log=None):
#     if log is None:
#         log = logging.getLogger(__name__)

#     # Find the PEFT-wrapped decoder (your custom path)
#     if hasattr(model, "embedding") and hasattr(model.embedding, "model"):
#         decoder = model.embedding.model

#         # Check if it's a PEFT model
#         if hasattr(decoder, "merge_and_unload"):
#             try:
#                 log.info("Merging LoRA using PEFT's native merge (this works)")
#                 merged_decoder = decoder.merge_and_unload()
#                 model.embedding.model = merged_decoder
#                 del decoder  # frees the old PEFT model + all LoRA tensors
#                 if torch.cuda.is_available():
#                     torch.cuda.empty_cache()
#                 log.info("LoRA merged successfully — no warnings, no errors")
#                 return model
#             except Exception as e:
#                 log.error(f"PEFT merge failed: {e}")

#     # Fallback: manual merge (your old code) — but now it will find nothing, so skip
#     log.info("No PEFT wrapper found — skipping manual merge (already clean or not needed)")
#     return model

def _c4022108464a(_922ce048d075, _2e87d8ab8d7a=_524ba2a05836):
    if _2e87d8ab8d7a is _524ba2a05836:
        _2e87d8ab8d7a = _5cf4a704967f._5a28c4043ece(__name__)

    _7f2903d420c8 = _e24a018c4da9(_922ce048d075, "module", _922ce048d075)

    def _f18a8222f70e(_7e63a569aa7a, _a5fa0f15aa89):
        if _a280dd497c77(_7e63a569aa7a, "merge_and_unload"):
            _2e87d8ab8d7a._74c5cd2722f0("Merging LoRA via PEFT merge_and_unload")
            _214499e76f63 = _7e63a569aa7a._092e9b95d277()
            _a5fa0f15aa89(_214499e76f63)
            if _d81d93427c1a._a6a57237a415._3b67608be895():
                _d81d93427c1a._a6a57237a415._5ddf05f09616()
            _2e87d8ab8d7a._74c5cd2722f0("LoRA merged successfully")
            return _36599a7dea7d
        return _41ec058a66df

    # Decoder path (Lightning-safe)
    if _a280dd497c77(_7f2903d420c8, "embedding") and _a280dd497c77(_7f2903d420c8._5bff2c7fa11b, "model"):
        if _4166e8edf791(
            _7f2903d420c8._5bff2c7fa11b._922ce048d075,
            lambda _70c1b1837a49: _4b65c5713a91(_7f2903d420c8._5bff2c7fa11b, "model", _70c1b1837a49),
        ):
            return _922ce048d075

    # Embedding path
    if _a280dd497c77(_7f2903d420c8, "embedding"):
        if _4166e8edf791(
            _7f2903d420c8._5bff2c7fa11b,
            lambda _70c1b1837a49: _4b65c5713a91(_7f2903d420c8, "embedding", _70c1b1837a49),
        ):
            return _922ce048d075

    _2e87d8ab8d7a._74c5cd2722f0("No PEFT LoRA adapters found — nothing to merge")
    return _922ce048d075


def _6b467ce1cea1(_922ce048d075: "torch.nn.Module") -> "torch.nn.Module":
    """
    Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
    Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
    Leaves LoRA and trainable modules untouched.
    Safe: skips missing weights or broken layers automatically.
    """
    import _2dfbc3ebb3a1
    import _d81d93427c1a
    import _c53169b2a439 as _2a16287f21e3

    _e88c3235a0b9 = _d0131183e828(_922ce048d075._94f8a878a57b())[::-1]  # bottom-up traversal

    for _51cc92de1888, _5561becc68e9 in _e88c3235a0b9:
        if _70694fd9bdfb(_5561becc68e9, (_d81d93427c1a._c45278b00078._003d0748fd95, _d81d93427c1a._c45278b00078._4dcd5fbfcdff)):
            # Skip LoRA or trainable layers
            if "lora" in _51cc92de1888._df056d9bbcc7() or _390490555b5d(_95f58f50e642._e785a1d5196d for _95f58f50e642 in _5561becc68e9._f1185fbda52e()):
                continue

            try:
                _aec19beb456d = "nf4" if _70694fd9bdfb(_5561becc68e9, _d81d93427c1a._c45278b00078._003d0748fd95) else "fp4"

                _97bd5e7070cd = _e24a018c4da9(_5561becc68e9, "in_features", _5561becc68e9._59102c4df393._b4615764ea5d[1])
                _b2068bd9fd05 = _e24a018c4da9(_5561becc68e9, "out_features", _5561becc68e9._59102c4df393._b4615764ea5d[0])

                _f14679d45cc7 = _2a16287f21e3._c45278b00078._ee90303c9014(
                    _97bd5e7070cd, _b2068bd9fd05,
                    _ed43a77bc6e8=_5561becc68e9._ed43a77bc6e8 is not _524ba2a05836,
                    _d838d7c5b6f5=_c78117e2e1b2(),
                    _aec19beb456d=_aec19beb456d
                )

                if _5561becc68e9._59102c4df393 is _524ba2a05836 or not _a280dd497c77(_5561becc68e9._59102c4df393, "data"):
                    continue

                _f14679d45cc7._59102c4df393._0d47d5f7443a._35612054130e(_5561becc68e9._59102c4df393._0d47d5f7443a)
                if _5561becc68e9._ed43a77bc6e8 is not _524ba2a05836:
                    _f14679d45cc7._ed43a77bc6e8._0d47d5f7443a._35612054130e(_5561becc68e9._ed43a77bc6e8._0d47d5f7443a)

                # Replace in parent
                _24fc54c82f9a = _922ce048d075
                _6e1fbd1608a0 = _51cc92de1888._744a6185b985(".")
                for _95f58f50e642 in _6e1fbd1608a0[:-1]:
                    _24fc54c82f9a = _e24a018c4da9(_24fc54c82f9a, _95f58f50e642)
                _4b65c5713a91(_24fc54c82f9a, _6e1fbd1608a0[-1], _f14679d45cc7)

                del _5561becc68e9
                _2dfbc3ebb3a1._41c949d8af60()
                if _d81d93427c1a._a6a57237a415._3b67608be895():
                    _d81d93427c1a._a6a57237a415._5ddf05f09616()

            except _841ed8fed949 as _3fcb765587f9:
                _f16c407b8ca5(f"[WARN] Skipped quantizing {_51cc92de1888}: {_3fcb765587f9}")

    return _922ce048d075


# def quantize_frozen_linear_layers(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Manually quantize all frozen torch.nn.Linear layers in the given model to 4-bit precision using bitsandbytes.
#     Leaves all LoRA or trainable modules untouched (those containing 'lora' in name or requiring gradients).

#     Args:
#         model (torch.nn.Module): The model instance to quantize (after LoRA is applied).

#     Returns:
#         torch.nn.Module: The same model instance with frozen Linear layers replaced by 4-bit quantized versions.
#     """
#     import bitsandbytes as bnb
#     from bitsandbytes.nn import Params4bit

#     modules = list(model.named_modules())  # snapshot to avoid OrderedDict mutation

#     for name, module in modules:
#         # Quantize only standard Linear layers that are frozen
#         if isinstance(module, torch.nn.Linear):
#             if "lora" in name.lower() or any(param.requires_grad for param in module.parameters()):
#                 continue  # skip LoRA or active trainable layers

#             # Create quantized Linear4bit replacement
#             quantized = bnb.nn.Linear4bit(
#                 module.in_features,
#                 module.out_features,
#                 bias=module.bias is not None,
#                 compute_dtype=get_supported_compute_dtype(),
#                 compress_statistics=True,
#                 quant_type="nf4"
#             )

#             # Properly quantize and assign weight
#             quantized.weight = Params4bit(
#                 module.weight.data,
#                 compress_statistics=True,
#                 quant_type="nf4",
#                 quant_storage=torch.uint8
#             )

#             # Copy bias if exists
#             if module.bias is not None:
#                 quantized.bias = module.bias.clone()

#             # Replace the original module in its parent container
#             parent = model
#             parts = name.split(".")
#             for p in parts[:-1]:
#                 parent = getattr(parent, p)
#             setattr(parent, parts[-1], quantized)

#     return model

def _c4022108464a(_922ce048d075: "torch.nn.Module", _2e87d8ab8d7a: "Any" = _524ba2a05836) -> "torch.nn.Module":
    """
    Merge LoRA adapters into base layers (robust heuristics) and then aggressively
    remove/unwrap PEFT/LoRA wrapper objects so the final model no longer reports
    "LoRA present" / "PEFT present".
    """
    if _2e87d8ab8d7a is _524ba2a05836:
        _2e87d8ab8d7a = _5cf4a704967f._5a28c4043ece(__name__)

    _214499e76f63 = 0
    _86048c2d3db0 = 0
    _142d37638658 = []

    # helper to get first tensor-like from many container types
    def _946107e6f5e5(_e4f9979f5171):
        if _e4f9979f5171 is _524ba2a05836:
            return _524ba2a05836
        if _70694fd9bdfb(_e4f9979f5171, _d81d93427c1a._c45278b00078._58f0cc754be8):
            return _e4f9979f5171._0d47d5f7443a
        if _70694fd9bdfb(_e4f9979f5171, _d81d93427c1a._4d242564a685):
            return _e4f9979f5171
        if _70694fd9bdfb(_e4f9979f5171, _d81d93427c1a._c45278b00078._7a76288dde4d):
            _22d2977ec20c = _e24a018c4da9(_e4f9979f5171, "weight", _524ba2a05836)
            if _70694fd9bdfb(_22d2977ec20c, _d81d93427c1a._c45278b00078._58f0cc754be8):
                return _22d2977ec20c._0d47d5f7443a
            try:
                _95f58f50e642 = _cd1457884d83(_e4f9979f5171._f1185fbda52e())
                return _95f58f50e642._0d47d5f7443a
            except _841ed8fed949:
                pass
            try:
                _9928def044ec = _cd1457884d83(_e4f9979f5171._4c44335ba65c())
                return _9928def044ec
            except _841ed8fed949:
                pass
            return _524ba2a05836
        # dict-like or ModuleDict-like: return first tensor we can
        try:
            for _869f9593928d in _e24a018c4da9(_e4f9979f5171, "values", lambda: [])():
                _14b371b1f9eb = _78f44090014c(_869f9593928d)
                if _14b371b1f9eb is not _524ba2a05836:
                    return _14b371b1f9eb
        except _841ed8fed949:
            pass
        try:
            for _, _869f9593928d in _e24a018c4da9(_e4f9979f5171, "items", lambda: [])():
                _14b371b1f9eb = _78f44090014c(_869f9593928d)
                if _14b371b1f9eb is not _524ba2a05836:
                    return _14b371b1f9eb
        except _841ed8fed949:
            pass
        return _524ba2a05836

    def _554640f099b6(_2e6d5ddf532b: _d81d93427c1a._4d242564a685, _cdb910261eb1: _d81d93427c1a._4d242564a685, _ebf06e67c8e7: _d81d93427c1a._4d242564a685):
        _34c5cee20a0f = _2e6d5ddf532b._cf67119e33db()._6c0631dc0444()
        _0ab0949e3f40 = _cdb910261eb1._cf67119e33db()._6c0631dc0444()
        # common 2D case
        if _34c5cee20a0f._6b72112d4d0e() == 2 and _0ab0949e3f40._6b72112d4d0e() == 2 and _0ab0949e3f40._b4615764ea5d[1] == _34c5cee20a0f._b4615764ea5d[0]:
            return _0ab0949e3f40 @ _34c5cee20a0f
        # try reshape inference based on base shape
        _7d600608bffa = _39496407e64d(_ebf06e67c8e7._b4615764ea5d[0])
        _9b7bcf6d4150 = _39496407e64d(_ebf06e67c8e7._b4615764ea5d[1]) if _ebf06e67c8e7._6b72112d4d0e() > 1 else 1
        _0ae7cba348a4 = _34c5cee20a0f._38c0040bcf0f()
        _7bafeffe7cb2 = _0ab0949e3f40._38c0040bcf0f()
        if _7d600608bffa > 0 and _9b7bcf6d4150 > 0:
            if (_7bafeffe7cb2 % _7d600608bffa == 0):
                _ba709bf21f05 = _7bafeffe7cb2 // _7d600608bffa
                if _ba709bf21f05 > 0 and (_0ae7cba348a4 == _ba709bf21f05 * _9b7bcf6d4150):
                    _bc2b9fab568a = _34c5cee20a0f._fa7137b63569(_ba709bf21f05, _9b7bcf6d4150) if _34c5cee20a0f._6b72112d4d0e() == 1 else _34c5cee20a0f
                    _818a69ace899 = _0ab0949e3f40._fa7137b63569(_7d600608bffa, _ba709bf21f05) if _0ab0949e3f40._6b72112d4d0e() == 1 else _0ab0949e3f40
                    if _818a69ace899._b4615764ea5d[1] == _bc2b9fab568a._b4615764ea5d[0]:
                        return _818a69ace899 @ _bc2b9fab568a
            if (_0ae7cba348a4 % _9b7bcf6d4150 == 0):
                _ba709bf21f05 = _0ae7cba348a4 // _9b7bcf6d4150
                if _ba709bf21f05 > 0 and (_7bafeffe7cb2 == _7d600608bffa * _ba709bf21f05):
                    _bc2b9fab568a = _34c5cee20a0f._fa7137b63569(_ba709bf21f05, _9b7bcf6d4150) if _34c5cee20a0f._6b72112d4d0e() == 1 else _34c5cee20a0f
                    _818a69ace899 = _0ab0949e3f40._fa7137b63569(_7d600608bffa, _ba709bf21f05) if _0ab0949e3f40._6b72112d4d0e() == 1 else _0ab0949e3f40
                    if _818a69ace899._b4615764ea5d[1] == _bc2b9fab568a._b4615764ea5d[0]:
                        return _818a69ace899 @ _bc2b9fab568a
        # fallback tries
        try:
            return _0ab0949e3f40 @ _34c5cee20a0f
        except _841ed8fed949:
            pass
        # chunked heuristics
        try:
            _bc2b9fab568a = _34c5cee20a0f if _34c5cee20a0f._6b72112d4d0e() == 2 else _34c5cee20a0f._fa7137b63569(_34c5cee20a0f._b4615764ea5d[0], -1)
            _818a69ace899 = _0ab0949e3f40 if _0ab0949e3f40._6b72112d4d0e() == 2 else _0ab0949e3f40._fa7137b63569(-1, _0ab0949e3f40._b4615764ea5d[0])
        except _841ed8fed949 as _3fcb765587f9:
            raise _8cca644149a1(f"cannot promote A/B to 2D: {_3fcb765587f9}")
        _aebb15530791 = _bc2b9fab568a._b4615764ea5d[0]
        _d662addb8fae = _818a69ace899._b4615764ea5d[1]
        if _aebb15530791 and _d662addb8fae and (_d662addb8fae % _aebb15530791 == 0):
            _ec8eff1e78a0 = _d662addb8fae // _aebb15530791
            _5f75f71f7386 = _818a69ace899._b4615764ea5d[0]
            _fa124b457bf5 = _818a69ace899._fa7137b63569(_5f75f71f7386, _ec8eff1e78a0, _aebb15530791)
            _c4129fca391e = _524ba2a05836
            for _9143da251771 in _5f8d214ba478(_ec8eff1e78a0):
                _772d52cc3a25 = _fa124b457bf5[:, _9143da251771, :] @ _bc2b9fab568a
                _c4129fca391e = _772d52cc3a25 if _c4129fca391e is _524ba2a05836 else (_c4129fca391e + _772d52cc3a25)
            return _c4129fca391e
        if _aebb15530791 and _d662addb8fae and (_aebb15530791 % _d662addb8fae == 0):
            _ec8eff1e78a0 = _aebb15530791 // _d662addb8fae
            _ab1977dd0b88 = _bc2b9fab568a._b4615764ea5d[1]
            _4bcb226b92d5 = _bc2b9fab568a._fa7137b63569(_ec8eff1e78a0, _d662addb8fae, _ab1977dd0b88)
            _c4129fca391e = _524ba2a05836
            for _9143da251771 in _5f8d214ba478(_ec8eff1e78a0):
                _772d52cc3a25 = _818a69ace899 @ _4bcb226b92d5[_9143da251771]
                _c4129fca391e = _772d52cc3a25 if _c4129fca391e is _524ba2a05836 else (_c4129fca391e + _772d52cc3a25)
            return _c4129fca391e
        raise _8cca644149a1(f"unsupported A/B shapes A={_58cea023b032(_2e6d5ddf532b._b4615764ea5d)} B={_58cea023b032(_cdb910261eb1._b4615764ea5d)} for base {_58cea023b032(_ebf06e67c8e7._b4615764ea5d)}")

    # gather parents to allow setattr replacements
    _1a09e2e71f9d = []
    for _24fc54c82f9a in _922ce048d075._e88c3235a0b9():
        try:
            for _5bb5d5d603fe, _78647699975a in _d0131183e828(_24fc54c82f9a._2b11f00ab3a7()):
                _1a09e2e71f9d._a415455e6189((_24fc54c82f9a, _5bb5d5d603fe, _78647699975a))
        except _841ed8fed949:
            continue

    # --- manual merge (robust attempts) ---
    for _24fc54c82f9a, _5bb5d5d603fe, _78647699975a in _1a09e2e71f9d:
        try:
            # identify base candidate under wrapper
            _bf2466d806c8 = _e24a018c4da9(_78647699975a, "base_layer", _524ba2a05836) or _e24a018c4da9(_78647699975a, "module", _524ba2a05836) or _e24a018c4da9(_78647699975a, "model", _524ba2a05836)
            if _bf2466d806c8 is _524ba2a05836 or not _a280dd497c77(_bf2466d806c8, "weight"):
                # if child itself is base-like with .weight, skip (nothing to merge)
                if _a280dd497c77(_78647699975a, "weight") and _70694fd9bdfb(_e24a018c4da9(_78647699975a, "weight"), _d81d93427c1a._c45278b00078._58f0cc754be8):
                    continue
                # otherwise there's nothing we can merge here
                continue

            # locate A/B containers in child or nested attrs
            _161925a2d14a = {}
            _ac0c749b1d55 = {}
            _674b53858430 = {}
            # candidate holders
            _a82fd78ed579 = [_78647699975a]
            for _19b04f4be3c0 in ("module", "base_layer", "lora_adapter", "adapter", "model", "base_model"):
                _869f9593928d = _e24a018c4da9(_78647699975a, _19b04f4be3c0, _524ba2a05836)
                if _869f9593928d is not _524ba2a05836 and _869f9593928d is not _78647699975a:
                    _a82fd78ed579._a415455e6189(_869f9593928d)

            for _de39241a4031 in _a82fd78ed579:
                if _a280dd497c77(_de39241a4031, "lora_A"):
                    _4ed8b7d5febc = _e24a018c4da9(_de39241a4031, "lora_A")
                    if _70694fd9bdfb(_4ed8b7d5febc, _89ef46fd6da5):
                        for _fc92d963ec28, _869f9593928d in _4ed8b7d5febc._75da506dae97():
                            _161925a2d14a[_fc92d963ec28] = _869f9593928d
                    else:
                        _161925a2d14a["default"] = _4ed8b7d5febc
                if _a280dd497c77(_de39241a4031, "lora_B"):
                    _aaca2bc1abcf = _e24a018c4da9(_de39241a4031, "lora_B")
                    if _70694fd9bdfb(_aaca2bc1abcf, _89ef46fd6da5):
                        for _fc92d963ec28, _869f9593928d in _aaca2bc1abcf._75da506dae97():
                            _ac0c749b1d55[_fc92d963ec28] = _869f9593928d
                    else:
                        _ac0c749b1d55["default"] = _aaca2bc1abcf
                if _a280dd497c77(_de39241a4031, "adapters") and _70694fd9bdfb(_e24a018c4da9(_de39241a4031, "adapters"), _89ef46fd6da5):
                    for _fc92d963ec28, _869f9593928d in _e24a018c4da9(_de39241a4031, "adapters")._75da506dae97():
                        if _a280dd497c77(_869f9593928d, "lora_A"):
                            _161925a2d14a[_fc92d963ec28] = _e24a018c4da9(_869f9593928d, "lora_A")
                        if _a280dd497c77(_869f9593928d, "lora_B"):
                            _ac0c749b1d55[_fc92d963ec28] = _e24a018c4da9(_869f9593928d, "lora_B")
                if _a280dd497c77(_de39241a4031, "lora_alpha"):
                    _674b53858430["default"] = _e24a018c4da9(_de39241a4031, "lora_alpha")
                if _a280dd497c77(_de39241a4031, "alpha"):
                    # some libs store alpha under alpha
                    _674b53858430["default"] = _e24a018c4da9(_de39241a4031, "alpha")

            if not _161925a2d14a and not _ac0c749b1d55:
                _142d37638658._a415455e6189(f"{_24fc54c82f9a._6b5e0d33eddd.__name__}.{_5bb5d5d603fe}")
                continue

            _3ae75e8d68da = _a8547a9ac5c5(_55adbb7b2241(_d0131183e828(_161925a2d14a._3ae75e8d68da()) + _d0131183e828(_ac0c749b1d55._3ae75e8d68da()) + ["default"]))
            _02d80eda03d5 = 0
            for _fc92d963ec28 in _3ae75e8d68da:
                _dfa1434d12a5 = _161925a2d14a._8671a70a6ed2(_fc92d963ec28) or _161925a2d14a._8671a70a6ed2("default")
                _1b7b1cbf341f = _ac0c749b1d55._8671a70a6ed2(_fc92d963ec28) or _ac0c749b1d55._8671a70a6ed2("default")
                _2e6d5ddf532b = _78f44090014c(_dfa1434d12a5)
                _cdb910261eb1 = _78f44090014c(_1b7b1cbf341f)
                if _2e6d5ddf532b is _524ba2a05836 or _cdb910261eb1 is _524ba2a05836:
                    _2e87d8ab8d7a._f2ed651d1b61("Skipping %s.%s key=%s (no tensor)", _24fc54c82f9a._6b5e0d33eddd.__name__, _5bb5d5d603fe, _fc92d963ec28)
                    continue
                if _2e6d5ddf532b._38c0040bcf0f() == 0 or _cdb910261eb1._38c0040bcf0f() == 0:
                    _2e87d8ab8d7a._38f6f6e98c7d("Empty/zero-dim A/B for %s.%s key=%s — replacing wrapper with base.", _24fc54c82f9a._6b5e0d33eddd.__name__, _5bb5d5d603fe, _fc92d963ec28)
                    try:
                        _4b65c5713a91(_24fc54c82f9a, _5bb5d5d603fe, _bf2466d806c8)
                        _86048c2d3db0 += 1
                    except _841ed8fed949 as _3fcb765587f9:
                        _2e87d8ab8d7a._38f6f6e98c7d("Could not replace wrapper %s.%s: %s", _24fc54c82f9a._6b5e0d33eddd.__name__, _5bb5d5d603fe, _3fcb765587f9)
                    _02d80eda03d5 = 0
                    break

                try:
                    _c4129fca391e = _d2aa3f55b988(_2e6d5ddf532b, _cdb910261eb1, _bf2466d806c8._59102c4df393)
                except _841ed8fed949 as _3fcb765587f9:
                    _2e87d8ab8d7a._38f6f6e98c7d("Failed computing LoRA delta for %s.%s key=%s: %s", _24fc54c82f9a._6b5e0d33eddd.__name__, _5bb5d5d603fe, _fc92d963ec28, _3fcb765587f9)
                    _c4129fca391e = _524ba2a05836

                if _c4129fca391e is _524ba2a05836:
                    continue

                # alpha scaling
                _d0b4613d46b0 = _674b53858430._8671a70a6ed2(_fc92d963ec28) or _674b53858430._8671a70a6ed2("default")
                _c48553424f5e = 1.0
                try:
                    if _d0b4613d46b0 is not _524ba2a05836:
                        _76c3ca8f63b0 = _6c0631dc0444(_d0b4613d46b0._f0d067107fa0()) if _70694fd9bdfb(_d0b4613d46b0, _d81d93427c1a._c45278b00078._58f0cc754be8) else _6c0631dc0444(_d0b4613d46b0)
                        _ba709bf21f05 = _2e6d5ddf532b._b4615764ea5d[0] if _e24a018c4da9(_2e6d5ddf532b, "dim", lambda: 0)() > 0 else _524ba2a05836
                        if _ba709bf21f05:
                            _c48553424f5e = _76c3ca8f63b0 / _6c0631dc0444(_ba709bf21f05)
                except _841ed8fed949:
                    _c48553424f5e = 1.0

                # apply
                try:
                    with _d81d93427c1a._dfaf15fcfd51():
                        _bf2466d806c8._59102c4df393._0d47d5f7443a = _bf2466d806c8._59102c4df393._0d47d5f7443a + (_c4129fca391e._91366dfaf637(_bf2466d806c8._59102c4df393._6083938910b3, _d81d93427c1a._289b92445ceb) * _c48553424f5e)._91366dfaf637(_bf2466d806c8._59102c4df393._c65aa0ce8bf1)
                    _214499e76f63 += 1
                    _02d80eda03d5 += 1
                    _2e87d8ab8d7a._74c5cd2722f0("Merged LoRA into %s.%s key=%s (scale=%s, delta_shape=%s)", _24fc54c82f9a._6b5e0d33eddd.__name__, _5bb5d5d603fe, _fc92d963ec28, _c48553424f5e, _58cea023b032(_c4129fca391e._b4615764ea5d) if _a280dd497c77(_c4129fca391e, "shape") else ())
                except _841ed8fed949 as _3fcb765587f9:
                    _2e87d8ab8d7a._38f6f6e98c7d("Failed applying delta into base for %s.%s key=%s: %s", _24fc54c82f9a._6b5e0d33eddd.__name__, _5bb5d5d603fe, _fc92d963ec28, _3fcb765587f9)
                    continue

            # after processing keys, attempt to replace wrapper with base
            try:
                _4b65c5713a91(_24fc54c82f9a, _5bb5d5d603fe, _bf2466d806c8)
                _86048c2d3db0 += 1
            except _841ed8fed949 as _3fcb765587f9:
                _2e87d8ab8d7a._38f6f6e98c7d("Applied deltas but failed to replace wrapper %s.%s: %s", _24fc54c82f9a._6b5e0d33eddd.__name__, _5bb5d5d603fe, _3fcb765587f9)

        except _841ed8fed949 as _3fcb765587f9:
            _2e87d8ab8d7a._38f6f6e98c7d("Unexpected failure merging %s.%s: %s", _24fc54c82f9a._6b5e0d33eddd.__name__, _e24a018c4da9(_78647699975a, "__class__", _b3bf7db88f34(_78647699975a)).__name__, _3fcb765587f9)
            continue

    # --- FINAL CLEANUP PASS: unwrap any remaining PEFT/Lora wrappers and remove LoRA attrs ---
    def _d4b2a442288b(_7f2903d420c8):
        nonlocal _86048c2d3db0
        for _24fc54c82f9a in _d0131183e828(_7f2903d420c8._e88c3235a0b9()):
            try:
                for _51cc92de1888, _78647699975a in _d0131183e828(_24fc54c82f9a._2b11f00ab3a7()):
                    try:
                        _348d2d2d5c32 = _78647699975a._6b5e0d33eddd.__name__
                        # 1) If wrapper has merge_and_unload or merge_and_unload() try it
                        try:
                            if _a280dd497c77(_78647699975a, "merge_and_unload"):
                                try:
                                    _54a8bda96f68 = _78647699975a._092e9b95d277()
                                    # merge_and_unload sometimes returns a replacement module
                                    if _54a8bda96f68 is not _524ba2a05836 and _54a8bda96f68 is not _78647699975a:
                                        _4b65c5713a91(_24fc54c82f9a, _51cc92de1888, _54a8bda96f68)
                                        _86048c2d3db0 += 1
                                        continue
                                except _841ed8fed949:
                                    # ignore failing merge_and_unload
                                    pass
                            # sometimes wrapper is PeftModelForCausalLM or LoraModel
                            if "Peft" in _348d2d2d5c32 or "Lora" in _348d2d2d5c32 or "PeftModel" in _348d2d2d5c32:
                                _d7b33260eca1 = _e24a018c4da9(_78647699975a, "base_model", _524ba2a05836) or _e24a018c4da9(_78647699975a, "module", _524ba2a05836) or _e24a018c4da9(_78647699975a, "model", _524ba2a05836)
                                if _d7b33260eca1 is not _524ba2a05836 and _d7b33260eca1 is not _78647699975a:
                                    _4b65c5713a91(_24fc54c82f9a, _51cc92de1888, _d7b33260eca1)
                                    _86048c2d3db0 += 1
                                    continue
                        except _841ed8fed949:
                            pass

                        # 2) Remove lora attrs if present on child (making it plain)
                        for _5403f84e15c8 in ("lora_A", "lora_B", "lora_alpha", "adapters", "peft_config", "lora_dropout", "base_layer"):
                            if _a280dd497c77(_78647699975a, _5403f84e15c8):
                                try:
                                    _79eff990a048(_78647699975a, _5403f84e15c8)
                                except _841ed8fed949:
                                    try:
                                        _4b65c5713a91(_78647699975a, _5403f84e15c8, _524ba2a05836)
                                    except _841ed8fed949:
                                        pass
                        # 3) If child has nested wrappers, try to reattach its inner module
                        if _a280dd497c77(_78647699975a, "module") and _78647699975a is not _e24a018c4da9(_78647699975a, "module"):
                            try:
                                _4b65c5713a91(_24fc54c82f9a, _51cc92de1888, _e24a018c4da9(_78647699975a, "module"))
                                _86048c2d3db0 += 1
                                continue
                            except _841ed8fed949:
                                pass
                    except _841ed8fed949:
                        continue
            except _841ed8fed949:
                continue

    _29c847f4df58(_922ce048d075)

    # final parameter freezing: ensure LoRA params (if any) are not left trainable and normal params are frozen unless explicitly lora
    try:
        for _969226122bb6, _95f58f50e642 in _922ce048d075._f2aca8219ca9():
            if "lora" in _969226122bb6._df056d9bbcc7():
                _95f58f50e642._e785a1d5196d = _36599a7dea7d
            else:
                _95f58f50e642._e785a1d5196d = _41ec058a66df
    except _841ed8fed949:
        pass

    _2e87d8ab8d7a._74c5cd2722f0("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.", _214499e76f63, _86048c2d3db0, _8af34819c3df(_142d37638658))
    if _d81d93427c1a._a6a57237a415._3b67608be895():
        _d81d93427c1a._a6a57237a415._5ddf05f09616()
        _d81d93427c1a._a6a57237a415._a5d7f52bd593()
    _2dfbc3ebb3a1._41c949d8af60()
    if _142d37638658:
        _2e87d8ab8d7a._f2ed651d1b61("Skipped modules (no A/B found): %s", _142d37638658[:200])
    return _922ce048d075

_6d9851c199f9 = [
    'CustomFSDPStrategy',
    'OptunaLoggingCallback',
    'GPUUsagePruneCallback',
    'adjust_local_gpu_rank',
    'get_device_info',
    'remove_files_except',
    'load_checkpoint_with_fsdp',
    'dequantize_bnb_model',
    'manual_dequantize',
    'get_trainable_parameters',
    'get_target_modules',
    'clear_gpu_and_cpu_resources',
    'calculate_model_size_in_gb',
    'get_model_summary',
    'get_devices_for_trainer',
    'get_supported_compute_dtype',
    'is_duplicate',
    'NoDuplicateSampler',
    'gamma_for_tpe_sampler',
    'property_validation',
    'get_lora_config',
    'apply_lora_to_model',
    'merge_lora_into_base',
    'quantize_model_using_bnb',
]