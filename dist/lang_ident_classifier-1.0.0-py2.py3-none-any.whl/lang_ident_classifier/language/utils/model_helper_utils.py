# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_helper_utils.py
# @Time             : 2025-10-27 12:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _c7672e215fc0
from _1079fed1f9cc import _1079fed1f9cc, _f7660d88bdca
from functools import _21eca3592165
import copy
import _e15a7dbd7de8
from _374575ef488d import _374575ef488d
import inspect
import json
from _d5bdcce1288d import _9adf526bee97
import _d5bdcce1288d
import _00149ceddd7e
import random
import re
import _6dd64207cdeb
import _ac7b287bd53d
import _b019159bb882
import sys
import threading
import time
import _410688acbb47
import _50a953f9468f
import _c956a722ed60
from collections import _ee2037a50a5b
import os
import _8ac715f37b54 as _34c64620c0fb
from _333d2e9b04a2 import _aa721be0cb77
from typing import _81d9e8da0874, _95a55f604c9a, _e30c4af0a8e3, _0ca3dad47f04, _1faedb834221, _1a0aecb06dcf
from _2e969e38ce05 import _9ae349e6a18d, _fdf605a5dce9
from _780c90ea289a import _f2c8d860fb79
import _bafeca63c0e6._11ab65c62aa8._d8bd9e09bb38
import _8d0704043299
from _679c040b8247._951b775c0073 import _a25e5e469623
import _fb5870f47c15
_5ac1a4def90c = _fb5870f47c15._d1110d0f6b31._ca8b29be3601()
if _5ac1a4def90c:
    import _6c4101b635e3 as _0fb27b6f9a6b
import _fb5870f47c15._a73cebedeab1
import _fb5870f47c15._a73cebedeab1._1240a7421540
from _fb5870f47c15._a73cebedeab1._1240a7421540 import _24fa80c85507, _621d4209d7ea, _520d70827cd8
from _fb5870f47c15._a73cebedeab1._1240a7421540._447da725a948 import _7819aa72acfa
from _fb5870f47c15._a73cebedeab1._1240a7421540._447da725a948 import _e8dac82bbffb
import _a2bd92b5cf73 as _6c8505fc30ce
import _db006210f426 as _77d9a88619a5
from _4396af5ee576 import _aa34cac3dc59, _c729d4017e77, _615f357041a7, _dc3996487a0f, _53f750db59a3
from _4396af5ee576 import _6123cc49bb82
import _bafeca63c0e6
from _bafeca63c0e6._9a04e6d5c1e8 import _77f51fe46ba2
from _fb5870f47c15 import _1ac58c7c6f80, _e13ea03e9908
from _a2bd92b5cf73 import _3b557aef9036
from _a2bd92b5cf73._e33ad9b7a7bc import _72ad5641224b
from _3ef780b5422d import _37db0b7bfd3f, _48662adee615, _fd2633b606d3
from _3ef780b5422d import _2da57a7dd16f, _5d6d9dbfd56b
from _a2bd92b5cf73._e33ad9b7a7bc._b9855085d680 import _24e276e1c941
from _fb5870f47c15._a73cebedeab1._1240a7421540 import _3f3dd9c26779
from _fb5870f47c15._a73cebedeab1._1240a7421540 import _2840fe509fe7, _c8b78ae000df
from _fb5870f47c15._a73cebedeab1._1240a7421540._dceabff1c13b import _3bfa1ce36e7a
from _fb5870f47c15._93cb047b1e70 import _acc590567898
from _a2bd92b5cf73._e33ad9b7a7bc._b1f90c9a1f46._051b01171b7a import _e7d87c776aea
from _79ab043f0293._1d4592cf4f5b._31832e9b8964._a0b2aa6a7bd5 import _782db8a87424
from _79ab043f0293._1d4592cf4f5b._31832e9b8964._240a09b568bb import _2d6c66af06dd


# Helper functions/classes extracted from original module
# class CustomFSDPStrategy(FSDPStrategy):
#     def __init__(self, ig_params, ig_modules=None):
#         super().__init__(sharding_strategy="FULL_SHARD",
#                          cpu_offload=CPUOffload(offload_params=False),  # Explicit CPU offload  # Move non-trainable parameters to CPU
#                         #  mixed_precision=MixedPrecision(param_dtype=torch.float16,   # Use bfloat16 for parameters
#                         #                                 reduce_dtype=torch.float16,   # Keep reduction in float32 for stability
#                         #                                 buffer_dtype=torch.float16,  # Buffers in bfloat16
#                         #                                 ),
#                          auto_wrap_policy="TRANSFORMER_BASED_WRAP",  # Auto-wrap transformer layers
#                         #  auto_wrap_policy=transformer_auto_wrap_policy,
#                         #  auto_wrap_policy=custom_wrap_policy(min_num_params=100_000),
#                         #  state_dict_type="sharded" if torch.cuda.device_count() > 1 else "full",
#                         **{"static_graph": False, # Lightning optimization hint
#                            "forward_prefetch": False # Helps overlap compute/comm
#                         }
#                         )
#         # self.cpu_offload = False
#         # fsdp_args = {"use_orig_params": True, "ignored_parameters": ig_params}
#         # fsdp_args = {"use_orig_params": True, "ignored_states": ig_params}
#         fsdp_args = {
#             "use_orig_params": True,  # Maintain original parameter references
#             "ignored_states": ig_params,  # Ignore specific states (if defined)
#         }
#         if ig_modules:
#             fsdp_args.update({"ignored_modules": ig_modules})
#         self.kwargs = fsdp_args
# # class CustomFSDPStrategy(FSDPStrategy):
# #     def __init__(self, ig_params, ig_modules=None):
# #         super().__init__(
# #             sharding_strategy="FULL_SHARD",
# #             cpu_offload=None,  # Turn CPU offload OFF for speed on PCIe
# #             mixed_precision=MixedPrecision(
# #                 param_dtype=torch.bfloat16,
# #                 reduce_dtype=torch.bfloat16,
# #                 buffer_dtype=torch.bfloat16,
# #             ),
# #             auto_wrap_policy="TRANSFORMER_BASED_WRAP",
# #             forward_prefetch=True,  # Overlap comm and compute
# #         )
# #         fsdp_args = {
# #             "use_orig_params": True,
# #             "ignored_states": ig_params,
# #         }
# #         if ig_modules:
# #             fsdp_args["ignored_modules"] = ig_modules
# #         self.kwargs = fsdp_args

#     @property
#     def lightning_restore_optimizer(self) -> bool:
#         """Override to disable Lightning restoring optimizers/schedulers.

#         This is useful for plugins which manage restoring optimizers/schedulers.
#         """
#         return False

#     def lightning_module_state_dict(self) -> Dict[str, Any]:
#         assert self.model is not None

#         with FullyShardedDataParallel.state_dict_type(
#                 module=self.model,
#                 state_dict_type=StateDictType.FULL_STATE_DICT,
#                 state_dict_config=FullStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#                 optim_state_dict_config=FullOptimStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#         ):
#             # state_dict = self.model.state_dict()
#             state_dict = OrderedDict([(k.replace("_forward_module.",""), v) if k.__contains__('_forward_module') else (k, v)
#                                       for k, v in self.model.state_dict().items()])

#             # for key in state_dict:
#             #     print(f"state dict {key} :: {state_dict[key].shape}")
#             return state_dict

#     def setup_module(self, module: torch.nn.Module) -> torch.nn.Module:
#         """Override setup to ensure reshard_after_forward is set for all FSDP-wrapped submodules."""
#         module = super().setup_module(module)

#         for m in module.modules():
#             if isinstance(m, FullyShardedDataParallel):
#                 m._reshard_after_forward = True
#                 m._use_sharded_views = False  # optional, helps release memory immediately

#         return module

#     def optimizer_state(self, optimizer: Optimizer) -> Dict[str, Tensor]:
#         # old return FullyShardedDataParallel.full_optim_state_dict(self.model, optim=optimizer, rank0_only=True)
#         """ Manually gathers the full optimizer state across all ranks in FullyShardedDataParallel. """
#         # Get local (sharded) optimizer state using FullyShardedDataParallel
#         optim_state = FullyShardedDataParallel.optim_state_dict(self.model, optim=optimizer)

#         if torch.distributed.is_initialized():
#             # Gather optimizer states from all ranks
#             full_optim_state = [None] * torch.distributed.get_world_size()
#             torch.distributed.all_gather_object(full_optim_state, optim_state)

#             if torch.distributed.get_rank() == 0:
#                 # Merge optimizer states into a full dictionary
#                 merged_state = {"state": {}, "param_groups": full_optim_state[0]["param_groups"]}

#                 for state in full_optim_state:
#                     for param_id, param_state in state["state"].items():
#                         if param_id not in merged_state["state"]:
#                             merged_state["state"][param_id] = param_state
#                         else:
#                             # Merge optimizer state parameters (e.g., momentum buffers)
#                             for key in param_state:
#                                 if isinstance(param_state[key], list):
#                                     merged_state["state"][param_id][key].extend(param_state[key])
#                                 else:
#                                     merged_state["state"][param_id][key] = param_state[key]  # Overwrite

#                 return merged_state  # Full optimizer state for checkpointing
#             else:
#                 return {}  # Empty dictionary for non-rank 0
#         else:
#             return optim_state  # Single-process training, return directly


class _c77852f70a39(_24e276e1c941):
    """
    Unified FSDP strategy for BERT-family and LLaMA-family models.
    Skips FSDP wrapping of BNB 4bit/8bit layers to avoid FP32 shard bloat.
    """

    def _3bb2857a2e54(self, _a02afb204b8c=_1eb1ca52a992, _5c54a7098a52=_1eb1ca52a992, _4f37d64602e0: _287eda70c7fe = "", _ba8cfcaa4817: _5ad1768dd268 = _28c5c554b16d):
        from _fb5870f47c15._a73cebedeab1._1240a7421540._447da725a948 import _7819aa72acfa
        from functools import _21eca3592165

        # --- Detect model family ---
        _beced1fa85eb = _4f37d64602e0._14548be4df14()
        if _07241d1df407(_4694416eb005 in _beced1fa85eb for _4694416eb005 in ["llama", "mistral"]):
            try:
                from _3ef780b5422d._960a2d96e4ce._9102e44d0fb9._7e3ce859405f import _965bebc17d3d
                from _3ef780b5422d._960a2d96e4ce._eece22657c52._14a3a680c31f import _5a8295281ee7
                _0a7974981fa1 = (_965bebc17d3d, _5a8295281ee7)
            except _7e6af5044a3b:
                _0a7974981fa1 = ()
        else:
            try:
                from _3ef780b5422d._960a2d96e4ce._b21bdf86561b._8f0d3f82f8e4 import _10734a535786
                from _3ef780b5422d._960a2d96e4ce._119247dc8e25._cb5498b597fb import _ef4aa5bb2b51
                from _3ef780b5422d._960a2d96e4ce._de4f6ff03e08._cbe313518594 import _12184cf54518
                from _3ef780b5422d._960a2d96e4ce._ab76b23d8d37._12413162bbd1 import _dd8e49611bdf
                from _3ef780b5422d._960a2d96e4ce._1b4f07a6018c._c6fe267c341b import _610f742847d6 as _28c222ca2a99
                _0a7974981fa1 = (_10734a535786, _ef4aa5bb2b51, _12184cf54518, _dd8e49611bdf, _28c222ca2a99)
            except _7e6af5044a3b:
                _0a7974981fa1 = ()

        # # --- Auto-wrap policy ---
        # if not layer_cls:
        #     print(f"[WARN] Could not infer transformer layer class for {model_name}. FSDP will wrap nothing.")
        #     auto_wrap_policy = None
        # else:
        #     auto_wrap_policy = partial(transformer_auto_wrap_policy, transformer_layer_cls=layer_cls)

        # # --- Skip BNB 4bit/8bit layers from FSDP wrapping ---
        # if auto_wrap_policy is not None:
        #     try:
        #         from bitsandbytes.nn import Linear4bit, Linear8bitLt
        #         def _bnb_filter(module):
        #             return not isinstance(module, (Linear4bit, Linear8bitLt))
        #         original_policy = auto_wrap_policy
        #         auto_wrap_policy = lambda m: original_policy(m) and _bnb_filter(m)
        #     except Exception as e:
        #         print(f"[WARN] Could not import BNB layers for FSDP filter: {e}")
    
        def _863476be9456(_f5b49c898d15):
            return _f5b49c898d15._cf07d1dcfd18 if _546f67745193(_f5b49c898d15, "module") else _f5b49c898d15

        if not _0a7974981fa1:
            _ceb0df860d85(f"[WARN] Could not infer transformer layer class for {_4f37d64602e0}. FSDP will wrap nothing.")
            _dacf44cac0db = _1eb1ca52a992
        else:
            # base policy: match actual transformer layers
            def _f45bd186944a(_f5b49c898d15):
                _5d87cd7ec005 = _85c41380750c(_f5b49c898d15)
                return _1fbd91ba88e2(_5d87cd7ec005, _0a7974981fa1)

            # add BNB skip
            try:
                from _6c4101b635e3._ca6d5a9821a8 import _bcb6a25be600, _37052cc70d4c

                def _45c4242ee1af(_f5b49c898d15):
                    _5d87cd7ec005 = _85c41380750c(_f5b49c898d15)
                    return not _1fbd91ba88e2(_5d87cd7ec005, (_bcb6a25be600, _37052cc70d4c))
            except _7e6af5044a3b:
                def _45c4242ee1af(_f5b49c898d15):
                    return _fd58f229f8e3

            # final combined policy
            def _8b9763fefee2(_f5b49c898d15):
                return _198763294507(_f5b49c898d15) and _dfbb0df59b3a(_f5b49c898d15)

        _d0f57cbb98f7()._92c7349babdb(
            # sharding_strategy="FULL_SHARD" if is_training else "NO_SHARD", # NO_SHARD DECPRICATED
            _5c2a72f230ef="FULL_SHARD",
            _a2747e6018d7=_24fa80c85507(_389bb7cf5828=_fd58f229f8e3) if _ba8cfcaa4817 else _28c5c554b16d,
            _dacf44cac0db=_dacf44cac0db,
            _df881c6b38bb=_fd58f229f8e3,
            _ab703d553890=_28c5c554b16d,  # Safe for dynamic LoRA + quantized
        )

        # FSDP kwargs
        _de84c4ee4708 = {
            "use_orig_params": _fd58f229f8e3,
            "ignored_states": _a02afb204b8c,
        }
        if _5c54a7098a52:
            _de84c4ee4708["ignored_modules"] = _5c54a7098a52
        self._f432233bb05b = _de84c4ee4708

    @_8e65d1f537d4
    def _75942dc7c972(self) -> _5ad1768dd268:
        return _28c5c554b16d

    def _94934260aff8(self, _cf07d1dcfd18: _fb5870f47c15._ca6d5a9821a8._6ff3a2fd07a5) -> _fb5870f47c15._ca6d5a9821a8._6ff3a2fd07a5:
        _cf07d1dcfd18 = _d0f57cbb98f7()._099c418f34ef(_cf07d1dcfd18)
        for _7ef3a9c5cad7 in _cf07d1dcfd18._abc3b48499da():
            if _1fbd91ba88e2(_7ef3a9c5cad7, _3f3dd9c26779):
                _7ef3a9c5cad7._7db26d97927e = _fd58f229f8e3
                _7ef3a9c5cad7._40f1645896c2 = _28c5c554b16d
        return _cf07d1dcfd18

    def _17e5d26f89ce(self) -> _95a55f604c9a[_287eda70c7fe, _81d9e8da0874]:
        assert self._441927423503 is not _1eb1ca52a992
        with _3f3dd9c26779._f6e1d232c74e(
            _cf07d1dcfd18=self._441927423503,
            _f6e1d232c74e=_2840fe509fe7._85c734221826,
            _8c4a10c5d9bb=_c8b78ae000df(_42267eec57df=(self._c623b75c7027 > 1), _5b1b7c008003=_fd58f229f8e3),
            _f08f82ffd192=_3bfa1ce36e7a(_42267eec57df=(self._c623b75c7027 > 1), _5b1b7c008003=_fd58f229f8e3),
        ):
            _b8a6f8ffacd5 = _ee2037a50a5b([
                (_840ead97c0fd._ce00126fa1af("_forward_module.", ""), _0aa4dc356c36) if "_forward_module" in _840ead97c0fd else (_840ead97c0fd, _0aa4dc356c36)
                for _840ead97c0fd, _0aa4dc356c36 in self._441927423503._b8a6f8ffacd5()._c5a306e5fdc6()
            ])
            return _b8a6f8ffacd5

    def _077eac6f9ed7(self, _1208cd6b4627: _acc590567898) -> _95a55f604c9a[_287eda70c7fe, _fb5870f47c15._1ac58c7c6f80]:
        _e12e7b042fc4 = _3f3dd9c26779._0f07d5c3a152(self._441927423503, _93cb047b1e70=_1208cd6b4627)
        if _fb5870f47c15._a73cebedeab1._cc2a962bc0c4():
            _bdb7c7c505b7 = [_1eb1ca52a992] * _fb5870f47c15._a73cebedeab1._7d0c36563876()
            _fb5870f47c15._a73cebedeab1._9691e4523df1(_bdb7c7c505b7, _e12e7b042fc4)
            if _fb5870f47c15._a73cebedeab1._840a436ae102() == 0:
                _fee5e4a4e3b1 = {"state": {}, "param_groups": _bdb7c7c505b7[0]["param_groups"]}
                for _4d7dc0c52edd in _bdb7c7c505b7:
                    for _78ce7dc5b78a, _15d9e000e0c3 in _4d7dc0c52edd["state"]._c5a306e5fdc6():
                        if _78ce7dc5b78a not in _fee5e4a4e3b1["state"]:
                            _fee5e4a4e3b1["state"][_78ce7dc5b78a] = _15d9e000e0c3
                        else:
                            for _840ead97c0fd, _0aa4dc356c36 in _15d9e000e0c3._c5a306e5fdc6():
                                if _1fbd91ba88e2(_0aa4dc356c36, _f323bbd8f778):
                                    _fee5e4a4e3b1["state"][_78ce7dc5b78a][_840ead97c0fd]._9d60efbf74b8(_0aa4dc356c36)
                                else:
                                    _fee5e4a4e3b1["state"][_78ce7dc5b78a][_840ead97c0fd] = _0aa4dc356c36
                return _fee5e4a4e3b1
            else:
                return {}
        else:
            return _e12e7b042fc4
        
class _12c374f06b37(_6c8505fc30ce._9caa907f2e9c):
    """Lightning callback that writes trial number to trainer.callback_metrics.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance.

    Behavior:
        On training start it will attempt to add a "trial_number" entry to the
        trainer.callback_metrics mapping. This is best-effort and will not raise
        if metrics are not writable.
    """

    def _3bb2857a2e54(self, _9a04e6d5c1e8: _bafeca63c0e6._9a04e6d5c1e8._bbd33648489f):
        self._9a04e6d5c1e8 = _9a04e6d5c1e8

    def _567b6e2285fa(self, _0f514183f393: _6c8505fc30ce._3b557aef9036, _345fdf701080: _6c8505fc30ce._0b9217ed8846):
        # Add custom key-value pair
        _0f514183f393._a063516cc58e["trial_number"] = _e13ea03e9908(self._9a04e6d5c1e8._1b1b14779df8)


class _2691104831b0(_6c8505fc30ce._9caa907f2e9c):
    """Callback that monitors GPU usage and prunes an Optuna trial when usage is high.

    Args:
        trial (optuna.trial.Trial): Optuna trial object to prune.
        threshold (float): Fraction of GPU memory usage above which pruning should occur.

    Notes:
        - This callback is conservative: if CUDA is not available it is a no-op.
        - In distributed training it uses a broadcast so all ranks agree.
    """

    def _3bb2857a2e54(self, _9a04e6d5c1e8, _97dbf27aac1a=0.90):
        """
        Args:
            trial (optuna.trial.Trial): Optuna trial object to prune.
            threshold (float): Fraction of GPU memory usage to trigger pruning.
        """
        self._9a04e6d5c1e8 = _9a04e6d5c1e8
        self._97dbf27aac1a = _97dbf27aac1a

    def _83c6eddd16ad(self, _0f514183f393):
        """Return True if GPU reserved memory fraction >= threshold.

        Args:
            trainer: Lightning trainer object. Required for `is_global_zero` check.

        Returns:
            bool: True if usage >= threshold, False otherwise.

        Raises:
            None
        """
        # Only rank 0 checks and decides
        if not _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
            return _28c5c554b16d

        if _0f514183f393._43cb59e0e228:
            for _01ad2e69f727 in _2c7dc1e5859c(_fb5870f47c15._d1110d0f6b31._f1726d253bd3()):
                _22d9394f6327 = _fb5870f47c15._d1110d0f6b31._1d3939ba1f81(_01ad2e69f727)._ecca122f7328
                _625de65b5adb = _fb5870f47c15._d1110d0f6b31._437f7d0f17bd(_01ad2e69f727)
                _4e87544ac7b9 = _625de65b5adb / _22d9394f6327

                if _4e87544ac7b9 >= self._97dbf27aac1a:
                    _ceb0df860d85(f"[GPU Monitor] GPU {_01ad2e69f727} usage excceded: {_4e87544ac7b9*100:.1f}%")
                    return _fd58f229f8e3
        return _28c5c554b16d

    def _c34cbf37fbbe(self, _9d4a5ae5c9ad):
        """Broadcast the boolean prune decision to all ranks.

        Args:
            flag (bool): Local prune decision.

        Returns:
            bool: Agreed prune decision across ranks.

        Raises:
            RuntimeError: If CUDA is expected but not available on broadcast.
        """
        if not _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
            # Nothing to broadcast; return local decision
            return _9d4a5ae5c9ad
        _87a7ba06aae7 = _fb5870f47c15._e13ea03e9908([_56b12ba7f4cb(_9d4a5ae5c9ad)], _c7fcd6a7cea2='cuda')
        if _fb5870f47c15._a73cebedeab1._cc2a962bc0c4():
            _fb5870f47c15._a73cebedeab1._97646cac24a7(_87a7ba06aae7, _6465464ff7d0=0)
        return _87a7ba06aae7._fa61283b3f8d() == 1

    def _cba0ce39683b(self, _0f514183f393, _345fdf701080, _7abc50be077f, _98498a9b56ee, _46c575ca9f07=0):
        """Lightning hook executed at start of each training batch.

        Raises:
            optuna.TrialPruned: when GPU usage threshold is exceeded.
        """
        if not _5ac1a4def90c:
            return  # for cpu alone
        _7cc35dbe65a6 = self._ccc12a98e308(_0f514183f393)
        # Broadcast decision so all ranks agree
        _7cc35dbe65a6 = self._b33f8cfab57e(_7cc35dbe65a6)

        if _7cc35dbe65a6:
            if _0f514183f393._43cb59e0e228:
                _ceb0df860d85("[GPUUsagePruneCallback] GPU memory exceeded threshold. Pruning trial.")
            raise _bafeca63c0e6._9a706bf457e9("GPU memory exceeded threshold")


def _539fc9d94b69() -> _56b12ba7f4cb:
    """Compute local GPU rank based on environment variables.

    The function inspects `CUDA_VISIBLE_DEVICES`, `LOCAL_RANK` and `RANK` and
    returns an integer representing the local GPU index.

    Returns:
        int: local GPU rank (0-based). Returns -1 when CUDA is not available.

    Raises:
        ValueError: if computed local_rank is out of bounds for visible GPUs.
    """
    if not _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
        _ceb0df860d85("[adjust_local_gpu_rank] CUDA not available, using CPU (-1)", _30c959e84b87=_fd58f229f8e3)
        return -1  # CPU fallback

    _836d764ac107 = os._3a778ef1764c._9c05549e7554("CUDA_VISIBLE_DEVICES", "")
    if _836d764ac107 == "":
        # No filtering: all GPUs visible
        _de54b4975269 = [_287eda70c7fe(_d3491f36321a) for _d3491f36321a in _2c7dc1e5859c(_fb5870f47c15._d1110d0f6b31._f1726d253bd3())]
    else:
        # For MIG UUIDs or indices, keep as string list (don't cast to int)
        _de54b4975269 = [_4694416eb005._c49151d61676() for _4694416eb005 in _836d764ac107._84be22a27629(",") if _4694416eb005._c49151d61676() != ""]

    _07ab6e0f30ff = os._3a778ef1764c._9c05549e7554("LOCAL_RANK")
    _84ab39540e87 = os._3a778ef1764c._9c05549e7554("RANK")

    if _07ab6e0f30ff is not _1eb1ca52a992:
        _e2f639d48d3c = _56b12ba7f4cb(_07ab6e0f30ff)
        _ceb0df860d85(f"[adjust_local_gpu_rank] Using LOCAL_RANK={_e2f639d48d3c}", _30c959e84b87=_fd58f229f8e3)
    elif _84ab39540e87 is not _1eb1ca52a992:
        _e2f639d48d3c = _56b12ba7f4cb(_84ab39540e87)
        _ceb0df860d85(f"[adjust_local_gpu_rank] LOCAL_RANK not set, using RANK={_e2f639d48d3c}", _30c959e84b87=_fd58f229f8e3)
    else:
        _e2f639d48d3c = 0
        _ceb0df860d85("[adjust_local_gpu_rank] LOCAL_RANK and RANK not set, defaulting to 0", _30c959e84b87=_fd58f229f8e3)

    if _e2f639d48d3c >= _1d2bfb977975(_de54b4975269):
        raise _9c1a748b85d8(
            f"[adjust_local_gpu_rank] local_rank ({_e2f639d48d3c}) >= number of visible GPUs ({_1d2bfb977975(_de54b4975269)}).")

    # Returning integer index for compatibility with how calling code uses it.
    _35ccd7752714 = _e2f639d48d3c
    _ceb0df860d85(f"[adjust_local_gpu_rank] CUDA_VISIBLE_DEVICES={_de54b4975269}, selected device={_35ccd7752714}", _30c959e84b87=_fd58f229f8e3)

    return _35ccd7752714


def _c54b305ecf6f() -> _4358b0daa422:
    """Collect basic device and host information for logging.

    Returns:
        dict: keys include 'gpu_world_size', 'gpu_global_rank', 'gpu_local_rank',
              'node_name', and 'cpu_info'.

    Notes:
        - If CUDA is unavailable and SLURM is not detected, gpu_* keys are populated with -1.
    """
    _827ecaf0faf9 = _4358b0daa422()
    if _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
        _827ecaf0faf9['gpu_world_size'] = _287eda70c7fe(os._3a778ef1764c._9c05549e7554('WORLD_SIZE', '1'))  # get WORLD_SIZE or set default 1
        _827ecaf0faf9['gpu_global_rank'] = _287eda70c7fe(os._3a778ef1764c._9c05549e7554('RANK', '0'))
        _827ecaf0faf9['gpu_local_rank'] = _287eda70c7fe(_ef689b22f3ed())
    elif _e7d87c776aea._29d46921ddd3() and _fb5870f47c15._d1110d0f6b31._ca8b29be3601() is _28c5c554b16d:
        _827ecaf0faf9['gpu_world_size'] = _287eda70c7fe(_e7d87c776aea._c623b75c7027(_6c8505fc30ce))
        _827ecaf0faf9['gpu_global_rank'] = _287eda70c7fe(_e7d87c776aea._7a6f029b999c(_6c8505fc30ce))
        _827ecaf0faf9['gpu_local_rank'] = -1
    else:
        _827ecaf0faf9['gpu_world_size'] = -1
        _827ecaf0faf9['gpu_global_rank'] = -1
        _827ecaf0faf9['gpu_local_rank'] = -1
    _827ecaf0faf9['node_name'] = _ac7b287bd53d._abafaa60d9fd()
    try:
        _827ecaf0faf9['cpu_info'] = "CPU :: {} COUNT :: {}"._85bec3853520(_50a953f9468f._2764941ffedc()['brand_raw'], os._51ca7017c57e())
    except _7e6af5044a3b:
        _827ecaf0faf9['cpu_info'] = f"CPU COUNT :: {os._51ca7017c57e()}"
    return _827ecaf0faf9


def _1682158f9cf1(_404a4aa398a8: _287eda70c7fe, _eb64974efc5b: _287eda70c7fe, _8a3daed9957b: _9adf526bee97):
    """Remove all files in a directory except a single filename to keep.

    Args:
        directory (str): Directory to clean.
        file_to_keep (str): Basename of file to retain.
        log (Logger): Logger instance for informational messages.

    Raises:
        FileNotFoundError: If `directory` does not exist.
        PermissionError: If file removal fails due to permissions (propagates underlying OSError).
    """
    if not os._678e9b2308c5._5b027a7a0468(_404a4aa398a8):
        raise _bfe5ac03a9c8(f"Directory not found: {_404a4aa398a8}")

    for _bfad17421656 in os._691a5e0f7ec7(_404a4aa398a8):
        _4f68c0af1fed = os._678e9b2308c5._8de610c0934b(_404a4aa398a8, _bfad17421656)
        if os._678e9b2308c5._291d716ef980(_4f68c0af1fed) and _bfad17421656 != _eb64974efc5b:
            _8a3daed9957b._dc2915897a0a(f"Removing checkpoint: {_4f68c0af1fed}")
            os._be9f9cea8913(_4f68c0af1fed)


def _20d28bd17ee7(_8a3daed9957b: _9adf526bee97, _fe3a9c2489fb: _287eda70c7fe, _c0046cd37b9a: _bafeca63c0e6._25d50c409a2a, _9a04e6d5c1e8: _bafeca63c0e6._9a04e6d5c1e8._bbd33648489f):
    """Clear outdated checkpoint directories for the given model config.

    Args:
        log (Logger): Logger instance.
        model_config_name (str): Model configuration name used to build checkpoint root path.
        study (optuna.Study): Optuna study object (kept in signature for compatibility).
        trial (optuna.trial.Trial): Current trial; its number is preserved.

    Notes:
        - This function removes directories for older trials (non-current).
        - It will not raise if directories are missing; failures to remove are logged.
    """
    _1f50a4008c41 = f"checkpoints/{_fe3a9c2489fb}/trial_{_9a04e6d5c1e8._1b1b14779df8}"
    _09c19219671f = f"{_1f50a4008c41}/last-v{_9a04e6d5c1e8._1b1b14779df8}.ckpt"

    # If the directory is empty, we can remove it
    if os._678e9b2308c5._5b027a7a0468(_1f50a4008c41):
        if not os._691a5e0f7ec7(_1f50a4008c41):  # Check if empty
            try:
                os._375ff5a01507(_1f50a4008c41)  # Remove only if empty
                _8a3daed9957b._dc2915897a0a(f"Removed empty directory: {_1f50a4008c41}")
            except _7e6af5044a3b:
                _8a3daed9957b._4b1f44eab5ac(f"Failed to remove directory: {_1f50a4008c41}")
        else:
            # Check if the directory does not belong to the current trial and remove it
            _f9162e9d7ffc = f"checkpoints/{_fe3a9c2489fb}"
            if os._678e9b2308c5._5b027a7a0468(_f9162e9d7ffc):
                _0d5f37afd376 = os._691a5e0f7ec7(_f9162e9d7ffc)
                for _929864e5c295 in _0d5f37afd376:
                    _899dd8f2cdfa = re._899dd8f2cdfa(r"trial_(\d+)", _929864e5c295)
                    if _899dd8f2cdfa:
                        _32a71f16a36c = _56b12ba7f4cb(_899dd8f2cdfa._2d0f230d5b39(1))
                        if _32a71f16a36c != _9a04e6d5c1e8._1b1b14779df8:
                            _66a43ce685c3 = f"{_f9162e9d7ffc}/{_929864e5c295}"
                            if os._678e9b2308c5._3ae0b843d222(_66a43ce685c3):
                                try:
                                    _8a3daed9957b._dc2915897a0a(f"Removing outdated trial directory: {_66a43ce685c3}")
                                    _6dd64207cdeb._28047d4333f9(_66a43ce685c3)
                                except _7e6af5044a3b:
                                    _8a3daed9957b._4b1f44eab5ac(f"Failed to remove dir {_66a43ce685c3}")


def _617d7c88156a(_441927423503, _7092e596169a, _81031bf870a6):
    """Load a checkpoint into the original (unwrapped) model when FSDP was used.

    Args:
        model: Original (unwrapped) model instance (kept for signature compatibility).
        fsdp_model: FSDP-wrapped model instance that contains `.module`.
        checkpoint_path (str): Path to checkpoint file.

    Returns:
        torch.nn.Module: original model with loaded state dict.

    Raises:
        FileNotFoundError: If the checkpoint file does not exist.
        AttributeError: If `fsdp_model` does not expose `.module`.
        RuntimeError: If loading state dict fails.
    """
    if not os._678e9b2308c5._3ae0b843d222(_81031bf870a6):
        raise _bfe5ac03a9c8(f"Checkpoint not found: {_81031bf870a6}")

    # Access the original model (best-effort)
    if not _546f67745193(_7092e596169a, "module"):
        raise _c4ecf6ecd39c("fsdp_model does not expose .module (not an FSDP-wrapped model)")

    _115057d758ab = _7092e596169a._cf07d1dcfd18

    # Load the checkpoint
    _00c2c4617529 = _fb5870f47c15._f1510d91ac31(_81031bf870a6)

    # Attempt to load state dict into original model
    try:
        # Note: original script used FSDP full-state helpers; preserve call but guard errors
        with _fb5870f47c15._a73cebedeab1._1240a7421540._c8b78ae000df(_7092e596169a):
            _115057d758ab._6d3bab69b36c(_00c2c4617529, _43f065b548e7=_fd58f229f8e3)
    except _7e6af5044a3b:
        # Try fallback strict=False
        try:
            _115057d758ab._6d3bab69b36c(_00c2c4617529, _43f065b548e7=_28c5c554b16d)
        except _7e6af5044a3b as _1794af0bb024:
            raise _2b3944116c45(f"Failed to load checkpoint into original model: {_1794af0bb024}") from _1794af0bb024
    return _115057d758ab

# def dequantize_bnb_model(model):
#     """
#     Replace bitsandbytes quantized linear layers in a model with standard torch.nn.Linear layers.

#     This function traverses the given model and converts all quantized linear
#     layers (Linear4bit, Linear8bitLt) into torch.nn.Linear equivalents with
#     dequantized float32 weights and bias. The conversion is done in-place.

#     Args:
#         model (torch.nn.Module):
#             Model instance that may contain bitsandbytes quantized linear layers.

#     Returns:
#         torch.nn.Module:
#             The same model with quantized linear layers replaced by dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If layer weights or bias cannot be converted to float32 or fail to copy into a new layer.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for module in list(model.modules()):
#         for name, child in list(module.named_children()):
#             if getattr(child, "_is_dequantized", False):
#                 continue
#             if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#                 try:
#                     try:
#                         w = child.weight.dequantize()
#                     except Exception:
#                         w = child.weight.data.to(torch.float32)
#                     b = None
#                     if getattr(child, "bias", None) is not None:
#                         b = child.bias.data.to(torch.float32)
#                     out_f, in_f = w.shape
#                     new_linear = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                     new_linear.weight.data.copy_(w)
#                     if b is not None:
#                         new_linear.bias.data.copy_(b)
#                     new_linear._is_dequantized = True
#                     setattr(module, name, new_linear)
#                 except Exception as e:
#                     raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#     return model


# def manual_dequantize(module):
#     """
#     Recursively replace bitsandbytes quantized linear layers in a module with torch.nn.Linear layers.

#     This function walks all children of the given module recursively and converts
#     quantized linear layers (Linear4bit, Linear8bitLt) to standard torch.nn.Linear
#     layers containing float32 weights and bias. Layers already marked as
#     dequantized are skipped.

#     Args:
#         module (torch.nn.Module):
#             Root module or submodule to process recursively.

#     Returns:
#         torch.nn.Module:
#             The same module with all quantized linear layers replaced by
#             dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If a quantized layer fails to convert or copy its weights to float32.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for name, child in list(module.named_children()):
#         if getattr(child, "_is_dequantized", False):
#             continue
#         if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#             try:
#                 try:
#                     w = child.weight.dequantize()
#                 except Exception:
#                     w = child.weight.data.to(torch.float32)
#                 b = None
#                 if getattr(child, "bias", None) is not None:
#                     b = child.bias.data.to(torch.float32)
#                 out_f, in_f = w.shape
#                 new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                 new_layer.weight.data.copy_(w)
#                 if b is not None:
#                     new_layer.bias.data.copy_(b)
#                 new_layer._is_dequantized = True
#                 setattr(module, name, new_layer)
#             except Exception as e:
#                 raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#         else:
#             manual_dequantize(child)
#     return module

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32) — no CPU moves, preserves device, removes ALL quantized layers.
#     Works even under PEFT, _SafeModuleWrapper, PeftModel, LoraModel, etc.

#     Bulletproof: detection by class name, not isinstance.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",        # some bnb builds use this
#     }

#     # Traverse parents so we can do setattr
#     for parent in list(model.modules()):
#         # Use raw _modules dict so we replace correct child
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # Skip non-BnB quantized layers
#             if cls not in QUANT_CLASS_NAMES:
#                 # Check nested wrapper: _SafeModuleWrapper, etc.
#                 inner = getattr(child, "module", None)
#                 if inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                     child = inner
#                     cls = child.__class__.__name__
#                 else:
#                     continue

#             # --------------------------------------------------------
#             # At this point, child is DEFINITELY a quantized Linear*
#             # --------------------------------------------------------

#             # Device
#             try:
#                 device = next(child.parameters()).device
#             except StopIteration:
#                 device = torch.device("cpu")

#             # ---- read weight ----
#             if hasattr(child, "weight") and hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---- read bias ----
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---- infer dims ----
#             # out_f, in_f = w.shape
#             # If weight is 1-D (flattened), infer dims from child attributes
#             if w.dim() == 1:
#                 out_f = child.out_features
#                 in_f = child.in_features
#             else:
#                 out_f, in_f = w.shape

#             # ---- create replacement ----
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---- REPLACE ----
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32). Preserves device. Never reshapes incorrectly.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",
#     }

#     for parent in list(model.modules()):
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # ---------- WRAPPER DETECTION ----------
#             wrapper = child                     # always keep wrapper
#             inner = getattr(child, "module", None)
#             is_quant = False

#             # direct quantized
#             if cls in QUANT_CLASS_NAMES:
#                 is_quant = True

#             # wrapped quantized
#             elif inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                 is_quant = True
#                 child = inner                    # but we still use wrapper for dims

#             if not is_quant:
#                 continue

#             # ---------- DEVICE ----------
#             try:
#                 device = next(child.parameters()).device
#             except Exception:
#                 device = torch.device("cpu")

#             # ---------- READ WEIGHTS ----------
#             if hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---------- READ BIAS ----------
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---------- TRUE DIMENSIONS FROM WRAPPER ----------
#             in_f = getattr(wrapper, "in_features", None)
#             out_f = getattr(wrapper, "out_features", None)

#             if in_f is None or out_f is None:
#                 # fallback to weight dims only if both missing
#                 print(f"FALLING BACK shape {w.shape}")
#                 out_f, in_f = w.shape

#             # ---------- CREATE NEW LINEAR ----------
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---------- REPLACE ----------
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
#     Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
#     Leaves LoRA and trainable modules untouched.
#     Safe: skips missing weights or broken layers automatically.
#     """
#     modules = list(model.named_modules())[::-1]  # bottom-up traversal

#     for name, module in modules:
#         if isinstance(module, (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)):
#             try:
#                 in_features = getattr(module, "in_features", module.weight.shape[1])
#                 out_features = getattr(module, "out_features", module.weight.shape[0])
#                 module_device = next(module.parameters(), None).device if module is not None else torch.device('cpu')
#                 print(f"dequant {module} on {module_device}")
#                 dequantized = torch.nn.Linear(
#                     in_features, out_features,
#                     bias=module.bias is not None,
#                     dtype=torch.float32,
#                     device=module_device
#                 )

#                 if module.weight is None or not hasattr(module.weight, "data"):
#                     continue

#                 dequantized.weight.data = module.weight.to(torch.float32)
#                 if module.bias is not None:
#                     dequantized.bias.data.copy_(module.bias.data)

#                 # Replace in parent
#                 parent = model
#                 parts = name.split(".")
#                 for p in parts[:-1]:
#                     parent = getattr(parent, p)
#                 setattr(parent, parts[-1], dequantized)

#                 del module
#                 gc.collect()
#                 torch.cuda.empty_cache()

#             except Exception as e:
#                 print(f"[WARN] Skipped dequantizing {name}: {e}")

#     return model

def _8ed9d60843fc(_441927423503: _fb5870f47c15._ca6d5a9821a8._6ff3a2fd07a5) -> _fb5870f47c15._ca6d5a9821a8._6ff3a2fd07a5:
    _f621f9e2371e = 0
    for _9114d7f95987, _cf07d1dcfd18 in _f323bbd8f778(_441927423503._2bec8b623180()):
        if not _1fbd91ba88e2(_cf07d1dcfd18, (_0fb27b6f9a6b._ca6d5a9821a8._bcb6a25be600, _0fb27b6f9a6b._ca6d5a9821a8._37052cc70d4c)):
            continue

        # print(f"Dequantizing {name} | {module.__class__.__name__} -> torch.nn.Linear")

        try:
            # 1. Force full dequantization using bnb internals (works on every model)
            if _1fbd91ba88e2(_cf07d1dcfd18, _0fb27b6f9a6b._ca6d5a9821a8._bcb6a25be600):
                # Handles NF4/FP4 + grouped QKV perfectly
                _33a49ddb5cda = _0fb27b6f9a6b._2e389d016aa2._759710f4f2eb(
                    _cf07d1dcfd18._33a49ddb5cda._5c81e5ce4e03,
                    _cf07d1dcfd18._33a49ddb5cda._687bede18b1a
                )._01476ff72e24(_9b74d612cb7b())
            else:  # Linear8bitLt
                _33a49ddb5cda = _cf07d1dcfd18._33a49ddb5cda._5c81e5ce4e03._01476ff72e24(_9b74d612cb7b())

            _bebe4beb9b31 = _cf07d1dcfd18._bebe4beb9b31._01476ff72e24(_9b74d612cb7b()) if _cf07d1dcfd18._bebe4beb9b31 is not _1eb1ca52a992 else _1eb1ca52a992

            # 2. Create clean fp32 Linear with correct shapes
            _ec2d08fe098f = _fb5870f47c15._ca6d5a9821a8._5d41a83850b6(
                _02e3ac9b6ffb=_cf07d1dcfd18._02e3ac9b6ffb,
                _1caaccb84176=_cf07d1dcfd18._1caaccb84176,
                _bebe4beb9b31=_bebe4beb9b31 is not _1eb1ca52a992,
                _c7fcd6a7cea2=_cf07d1dcfd18._33a49ddb5cda._5c81e5ce4e03._c7fcd6a7cea2,
                _6a5f05e64309=_9b74d612cb7b()
            )
            _ec2d08fe098f._33a49ddb5cda._5c81e5ce4e03._b3202f940147(_33a49ddb5cda)
            if _bebe4beb9b31 is not _1eb1ca52a992:
                _ec2d08fe098f._bebe4beb9b31._5c81e5ce4e03._b3202f940147(_bebe4beb9b31)

            # 3. Replace in parent (safe even with wrappers)
            _bd60f0dbf49d = _4358b0daa422(_441927423503._2bec8b623180())
            _33aa2294ef4c = "."._8de610c0934b(_9114d7f95987._84be22a27629(".")[:-1])
            _34cc37a69872 = _bd60f0dbf49d[_33aa2294ef4c] if _33aa2294ef4c else _441927423503
            _1e4324c82206(_34cc37a69872, _9114d7f95987._84be22a27629(".")[-1], _ec2d08fe098f)
            del _cf07d1dcfd18._33a49ddb5cda   # instantly frees the 4bit/8bit buffer
            _f621f9e2371e += 1

        except _7e6af5044a3b as _1794af0bb024:
            _ceb0df860d85(f"[FATAL] Failed on {_9114d7f95987}: {_1794af0bb024}")
            raise

    _ceb0df860d85(f"Successfully dequantized {_f621f9e2371e} bnb layers")
    _e15a7dbd7de8._4d6ee915c13d()
    if _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
        _fb5870f47c15._d1110d0f6b31._20ff46a0fb6b()
    return _441927423503

# def dequantize_bnb_model(model: torch.nn.Module) -> torch.nn.Module:
#     import torch
#     from bitsandbytes.nn import Linear4bit

#     for name, module in list(model.named_modules()):
#         if not isinstance(module, Linear4bit):
#             continue

#         # THIS IS THE KEY LINE FOR NEW BITSANDBYTES
#         if hasattr(module.weight, "quant_state"):
#             # New format: packed bits + quant_state
#             weight = module.weight.dequantize(module.weight.quant_state)
#         else:
#             # Old format (rare now)
#             weight = module.weight.dequantize()

#         bias = module.bias if module.bias is not None else None

#         linear = torch.nn.Linear(
#             module.in_features,
#             module.out_features,
#             bias=bias is not None,
#             device=module.weight.device,
#             dtype=torch.float32
#         )
#         linear.weight.data = weight.to(torch.float32)
#         if bias is not None:
#             linear.bias.data = bias.data.to(torch.float32)

#         # Replace
#         parent = model
#         for part in name.split(".")[:-1]:
#             parent = getattr(parent, part)
#         setattr(parent, name.split(".")[-1], linear)

#     return model

def _6e3ac3c66579(_441927423503):
    """
    Convert any remaining uint8 weights to fp32, in-place.
    No reshaping, no heuristics — only dtype fix.
    """
    import _fb5870f47c15

    for _cf07d1dcfd18 in _441927423503._abc3b48499da():
        for _9114d7f95987, _a135a602a2b0 in _cf07d1dcfd18._1147d1da7ce2(_3ed022c10ba2=_28c5c554b16d):
            if _a135a602a2b0._6a5f05e64309 == _fb5870f47c15._d6bec84462e0:
                _a135a602a2b0._5c81e5ce4e03 = _a135a602a2b0._5c81e5ce4e03._730356a95764()

    return _441927423503


def _f0e38c9a263e(_441927423503):
    """Return the number of trainable parameters in a model.

    Args:
        model (torch.nn.Module): Model to inspect.

    Returns:
        int: Count of trainable parameters.
    """
    _6c843e34cc1c = _f4c475ff7913(_2d8c33bb574b._0073930ef8f6() for _2d8c33bb574b in _441927423503._c5153882545c() if _2d8c33bb574b._d483977a22b9)
    return _56b12ba7f4cb(_6c843e34cc1c)  # Ensure this returns an integer


# def get_target_modules(model, attribute_filter=None, name_filter=None, custom_filter=None):
#     """Collect submodules of `model` that satisfy the provided filters.

#     Args:
#         model (nn.Module or LightningModule): The model to analyze.
#         attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
#         name_filter (callable, optional): Function(name) -> bool to filter by module name.
#         custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.

#     Returns:
#         dict: Mapping from module name to module instance for modules that matched filters.

#     Raises:
#         TypeError: If `model` does not implement `named_modules`.
#     """
#     if not hasattr(model, "named_modules"):
#         raise TypeError("Provided model does not implement named_modules()")

#     target_modules = {}
#     for name, module in model.named_modules():
#         # Exclude LayerNorm and other unsupported layers
#         if "Norm" in module.__class__.__name__:
#             continue

#         # Skip frozen layers (requires_grad=False)
#         try:
#             if not any(param.requires_grad for param in module.parameters()):
#                 continue  # Skip this module if all its parameters are frozen
#         except Exception:
#             # If module.parameters() raises, skip it as not applicable
#             continue

#         if (
#             (attribute_filter is None or attribute_filter(module)) and
#             (name_filter is None or name_filter(name)) and
#             (custom_filter is None or custom_filter(name, module))
#         ):
#             target_modules[name] = module  # Store the module in the dictionary with its name as key
#     return target_modules

def _2c1ee075721f(_441927423503, _bb868344c274=_1eb1ca52a992, _8162829a2ca3=_1eb1ca52a992, _0cc764a246b8=_1eb1ca52a992, _149385f900ba="embedding"):
    """Collect submodules of `model` that satisfy the provided filters.

    - Keeps modules that expose a weight Tensor even when that weight is not a Parameter
      (this allows detecting bitsandbytes wrappers like Linear4bit/Linear8bit).
    - Skips normalization modules by class-name ("Norm").
    - If a module has actual torch.nn.Parameters and all are requires_grad==False, it is skipped.
    - Returns dict mapping full dotted module path (prefixed by `prefix` if provided) -> module.

    Args:
        model (nn.Module or LightningModule): The model to analyze.
        attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
        name_filter (callable, optional): Function(name) -> bool to filter by module name.
        custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.
        prefix (str, optional): Base name of model path (default: "embedding").

    Returns:
        dict: Mapping from *full dotted module path* to module instance for matched modules.

    Raises:
        TypeError: If `model` does not implement named_modules().
    """
    import _fb5870f47c15

    if not _546f67745193(_441927423503, "named_modules"):
        raise _589fbe7fea7f("Provided model does not implement named_modules()")

    _642de2d626f9 = {}
    for _9114d7f95987, _cf07d1dcfd18 in _441927423503._2bec8b623180():
        # Exclude normalization layers (class name contains "Norm")
        if "Norm" in _cf07d1dcfd18._917f0b408327.__name__:
            continue

        # Determine if module has torch.nn.Parameters
        _a74748a79fc3 = _28c5c554b16d
        _5bada3a1920c = []
        try:
            _5bada3a1920c = _f323bbd8f778(_cf07d1dcfd18._c5153882545c())
            _a74748a79fc3 = _1d2bfb977975(_5bada3a1920c) > 0
        except _7e6af5044a3b:
            _a74748a79fc3 = _28c5c554b16d

        # If module has Parameters and none require grad -> skip (frozen)
        if _a74748a79fc3:
            try:
                if not _07241d1df407(_2d8c33bb574b._d483977a22b9 for _2d8c33bb574b in _5bada3a1920c):
                    continue
            except _7e6af5044a3b:
                # conservative: don't skip if we can't determine requires_grad
                pass

        # Allow modules that have a 'weight' attribute that's a Tensor (covers bnb wrappers)
        _af57b96c414f = _28c5c554b16d
        try:
            _b69a58f66889 = _238196d2b572(_cf07d1dcfd18, "weight", _1eb1ca52a992)
            if _1fbd91ba88e2(_b69a58f66889, _fb5870f47c15._1ac58c7c6f80):
                # accept even if it's not a Parameter
                _af57b96c414f = _fd58f229f8e3
        except _7e6af5044a3b:
            _af57b96c414f = _28c5c554b16d

        # Apply attribute/name/custom filters (attribute_filter should expect module)
        try:
            _bf8f82485557 = (_bb868344c274 is _1eb1ca52a992) or _bb868344c274(_cf07d1dcfd18)
        except _7e6af5044a3b:
            _bf8f82485557 = _28c5c554b16d

        try:
            _79fe0e1a9f80 = (_8162829a2ca3 is _1eb1ca52a992) or _8162829a2ca3(_9114d7f95987)
        except _7e6af5044a3b:
            _79fe0e1a9f80 = _28c5c554b16d

        try:
            _d65632a38b16 = (_0cc764a246b8 is _1eb1ca52a992) or _0cc764a246b8(_9114d7f95987, _cf07d1dcfd18)
        except _7e6af5044a3b:
            _d65632a38b16 = _28c5c554b16d

        # Decide acceptance:
        # - If attribute_filter/name_filter/custom_filter pass -> accept
        # - Otherwise, fall back to accepting if module has a weight tensor (bnb)
        if (_bf8f82485557 and _79fe0e1a9f80 and _d65632a38b16) or (not _a74748a79fc3 and _af57b96c414f):
            _4b4fa5383219 = f"{_149385f900ba}.{_9114d7f95987}" if _149385f900ba else _9114d7f95987
            _642de2d626f9[_4b4fa5383219] = _cf07d1dcfd18

    return _642de2d626f9


def _cd55e131dbff():
    """Safely clears GPU and CPU memory without disrupting distributed processes.

    Notes:
        - Best-effort: this function will not raise on cleanup errors, but will print/log them.
        - Ensures a distributed barrier at the end if torch.distributed is initialized.
    """
    # Run garbage collection to free CPU memory.
    _e15a7dbd7de8._4d6ee915c13d()

    if _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
        # Clear CUDA memory cache.
        try:
            _fb5870f47c15._d1110d0f6b31._20ff46a0fb6b()
            _fb5870f47c15._d1110d0f6b31._9c16e4d83673()
        except _7e6af5044a3b:
            # Some CUDA versions might not have ipc_collect
            pass

        # Ensure all pending CUDA operations are finished.
        try:
            _fb5870f47c15._d1110d0f6b31._e25791111f42()
        except _7e6af5044a3b:
            pass

        # Print memory stats before reset (optional).
        try:
            _8d9e97b0a266 = _fb5870f47c15._d1110d0f6b31._437f7d0f17bd()
            _b904dca5f64c = _fb5870f47c15._d1110d0f6b31._4a00940fb02f()
            _ceb0df860d85(f"Before reset: Reserved = {_8d9e97b0a266}, Allocated = {_b904dca5f64c}")
        except _7e6af5044a3b:
            pass

        # Reset memory tracking (useful for debugging).
        try:
            _fb5870f47c15._d1110d0f6b31._f424a4c354b2()
        except _7e6af5044a3b:
            pass

    # Print current process memory usage.
    try:
        _e251e501a020 = _8d0704043299._8e90f2d9aa3c(os._1e5156b50c43())
        _7a1e0912497b = _e251e501a020._2f15bebf8b87()
        _ceb0df860d85(f"Cleared GPU and CPU memory. Current process memory usage: {_7a1e0912497b._e8316884882f / 1024**2:.2f} MB")
    except _7e6af5044a3b:
        pass

    # Ensure all distributed processes are synchronized before proceeding.
    if _fb5870f47c15._a73cebedeab1._cc2a962bc0c4():
        try:
            _fb5870f47c15._a73cebedeab1._89ac2005f2de()
        except _7e6af5044a3b:
            pass


def _18db71820b59(_441927423503):
    """Calculate approximate model size in gigabytes.

    Args:
        model (torch.nn.Module): The model to analyze.

    Returns:
        float: Total size in GB accounting for unique parameters.

    Raises:
        TypeError: If model does not implement `.parameters()`.
    """
    if not _546f67745193(_441927423503, "parameters"):
        raise _589fbe7fea7f("Provided object is not a model with parameters()")

    _ef7c7dea5596 = 0  # Size in bytes
    _d6720d63a224 = _9530e8dd7e97()  # Set to track counted parameters by their unique IDs

    # Recursive function to sum the size of parameters in all submodules
    def _fae8b1d3d6ee(_cf07d1dcfd18):
        nonlocal _ef7c7dea5596
        for _a135a602a2b0 in _cf07d1dcfd18._c5153882545c():
            _b31886cbd6c8 = _2784864c0b03(_a135a602a2b0)  # Unique identifier for the parameter
            if _b31886cbd6c8 not in _d6720d63a224:  # Ensure each parameter is counted only once
                _1fd4a9e95b4e = _a135a602a2b0._169a43074871()  # Size of one element in bytes
                _ef7c7dea5596 += _a135a602a2b0._0073930ef8f6() * _1fd4a9e95b4e  # Total memory in bytes
                _d6720d63a224._6a1c17d284a1(_b31886cbd6c8)  # Mark parameter as counted

    # Loop through all submodules (including nested ones)
    try:
        _441927423503._055c79b9a479(lambda _cf07d1dcfd18: _79b98442d5d0(_cf07d1dcfd18))
    except _7e6af5044a3b:
        # Fallback: iterate parameters directly
        for _a135a602a2b0 in _441927423503._c5153882545c():
            _b31886cbd6c8 = _2784864c0b03(_a135a602a2b0)
            if _b31886cbd6c8 not in _d6720d63a224:
                _ef7c7dea5596 += _a135a602a2b0._0073930ef8f6() * _a135a602a2b0._169a43074871()
                _d6720d63a224._6a1c17d284a1(_b31886cbd6c8)

    _460d534a8f34 = _730356a95764(_ef7c7dea5596) / (1024 ** 3)  # Convert to GB
    return _460d534a8f34


def _5a0dd5f31e70(_441927423503: _6c8505fc30ce._0b9217ed8846, _31edee377b50: _56b12ba7f4cb = 1):
    """Return a PrettyTable summary of the model architecture and parameter counts.

    Args:
        model (pl.LightningModule): Model to summarize.
        depth (int): How deep in module name hierarchy to report (default 1).

    Returns:
        str: Multi-line string summary. If PrettyTable is unavailable this will raise.

    Raises:
        TypeError: If model does not implement `named_modules`.
    """
    if not _546f67745193(_441927423503, "named_modules"):
        raise _589fbe7fea7f("Provided model does not implement named_modules()")

    _c62a6dcc9583 = _aa721be0cb77()
    _c62a6dcc9583._619079de020f = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

    _ffc309925b5e = 0
    _6c843e34cc1c = 0
    _5e1fe1ab1d03 = 0

    _e7727a344496 = _9530e8dd7e97()  # Track parameters to prevent duplicate counting

    def _583bae9f8582(_cf07d1dcfd18):
        """Helper function to count trainable/non-trainable parameters uniquely."""
        _5bada3a1920c = _f323bbd8f778(_cf07d1dcfd18._c5153882545c())
        _32fb180a2454 = [_2d8c33bb574b for _2d8c33bb574b in _5bada3a1920c if _2784864c0b03(_2d8c33bb574b) not in _e7727a344496]

        _e7727a344496._01944bb5d27c(_2784864c0b03(_2d8c33bb574b) for _2d8c33bb574b in _32fb180a2454)  # Mark parameters as counted

        _22d9394f6327 = _f4c475ff7913(_2d8c33bb574b._0073930ef8f6() for _2d8c33bb574b in _32fb180a2454)
        _98f0adf48a04 = _f4c475ff7913(_2d8c33bb574b._0073930ef8f6() for _2d8c33bb574b in _32fb180a2454 if _2d8c33bb574b._d483977a22b9)
        _3369bfe097c5 = _22d9394f6327 - _98f0adf48a04

        return _22d9394f6327, _98f0adf48a04, _3369bfe097c5

    for _9114d7f95987, _cf07d1dcfd18 in _441927423503._2bec8b623180():
        if _9114d7f95987 == "" or _9114d7f95987._9252f79ff0e9('.') >= _31edee377b50:  # Skip root module and limit depth
            continue

        _5bada3a1920c, _98f0adf48a04, _3369bfe097c5 = _b48f8bb282db(_cf07d1dcfd18)

        if _5bada3a1920c > 0:  # Only add layers with parameters
            _c62a6dcc9583._889cb2ca88bd([_9114d7f95987, _cf07d1dcfd18._917f0b408327.__name__, f"{_5bada3a1920c:,}", f"{_98f0adf48a04:,}", f"{_3369bfe097c5:,}"])

        _ffc309925b5e += _5bada3a1920c
        _6c843e34cc1c += _98f0adf48a04
        _5e1fe1ab1d03 += _3369bfe097c5

    _c019d589225a = _9495bd49d73e(_441927423503)

    _4691eb08db53 = "\n" + _c62a6dcc9583._57ac28cc9859()
    _4691eb08db53 += f"\nTotal params: {_ffc309925b5e:,}\n"
    _4691eb08db53 += f"Trainable params: {_6c843e34cc1c:,}\n"
    _4691eb08db53 += f"Non-Trainable params: {_5e1fe1ab1d03:,}\n"
    _4691eb08db53 += f"Model size: {_c019d589225a:.2f} GB\n"

    return _4691eb08db53


def _09537828146a(_24b9b5e9ab24):
    """Return a devices specification suitable for Lightning Trainer based on DEVICE.

    Args:
        DEVICE (str): 'gpu' or 'cpu'.

    Returns:
        int | list: devices argument for Trainer (e.g., 1, [0], list(range(n)) or -1 for distributed).

    Raises:
        ValueError: If DEVICE is unknown or LOCAL_RANK out of bounds.
    """
    if _24b9b5e9ab24 == "cpu":
        return 1

    if _24b9b5e9ab24 == "gpu":
        _538940d098cc = os._3a778ef1764c._9c05549e7554("CUDA_VISIBLE_DEVICES")
        _bd29e7ef4a06 = _fb5870f47c15._a73cebedeab1._ca8b29be3601() and _fb5870f47c15._a73cebedeab1._cc2a962bc0c4()

        if _bd29e7ef4a06:
            return -1  # Let Lightning handle all

        # Inside non-distributed
        if _538940d098cc:
            _53dfbd2021eb = [_56b12ba7f4cb(_4694416eb005._c49151d61676()) for _4694416eb005 in _538940d098cc._84be22a27629(",")]
            _07ab6e0f30ff = os._3a778ef1764c._9c05549e7554('LOCAL_RANK') or os._3a778ef1764c._9c05549e7554('RANK')

            if _07ab6e0f30ff is not _1eb1ca52a992:
                _e2f639d48d3c = _56b12ba7f4cb(_07ab6e0f30ff)
                if _e2f639d48d3c >= _1d2bfb977975(_53dfbd2021eb):
                    raise _9c1a748b85d8(f"LOCAL_RANK {_e2f639d48d3c} out of bounds for visible GPUs {_53dfbd2021eb}")
                return [_e2f639d48d3c]  # single target

            # No rank set, fallback to all visible
            return _f323bbd8f778(_2c7dc1e5859c(_1d2bfb977975(_53dfbd2021eb)))
        else:
            # No CUDA_VISIBLE_DEVICES → use all available
            return _f323bbd8f778(_2c7dc1e5859c(_fb5870f47c15._d1110d0f6b31._f1726d253bd3()))

    raise _9c1a748b85d8(f"Unknown DEVICE {_24b9b5e9ab24}")


def _2a21c1d43ef7():
    """Return the preferred compute dtype for current GPU capability.

    Returns:
        torch.dtype: Preferred compute dtype (torch.bfloat16, torch.float16, or torch.float32).
    """
    _3fc6fa9a8764 = _fb5870f47c15._8eb6ff503ea2
    if _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
        try:
            _14eb0f2cd869, _8d8c90af2b8f = _fb5870f47c15._d1110d0f6b31._1eef99337028()
            # Ampere (8.0+) supports bfloat16
            if _14eb0f2cd869 >= 8:
                _3fc6fa9a8764 = _fb5870f47c15._f1b8430664f0
            else:
                _3fc6fa9a8764 = _fb5870f47c15._708c3fa4d5cc
        except _7e6af5044a3b:
            _3fc6fa9a8764 = _fb5870f47c15._8eb6ff503ea2
    return _3fc6fa9a8764


def _06ce78acd396(_9a04e6d5c1e8, _c0046cd37b9a):
    """Return True when `trial.params` equals parameters of any past trial.

    Args:
        trial (optuna.trial.Trial): Trial to check.
        study (optuna.Study): Study to check against.

    Returns:
        bool: True if duplicate found, False otherwise.

    Raises:
        TypeError: If `trial` or `study` is None or lacks expected attributes.
    """
    if _9a04e6d5c1e8 is _1eb1ca52a992 or _c0046cd37b9a is _1eb1ca52a992:
        raise _589fbe7fea7f("trial and study must be provided")

    # Get the current trial parameters
    _80400f9e9fcc = _238196d2b572(_9a04e6d5c1e8, "params", _1eb1ca52a992)
    if _80400f9e9fcc is _1eb1ca52a992:
        raise _589fbe7fea7f("trial.params is not available")

    # Check all completed trials for duplicates
    for _261f620bfe4a in _c0046cd37b9a._7f2cdf16ac35(_48ba4d5384ca=(_bafeca63c0e6._9a04e6d5c1e8._77f51fe46ba2._b1159d47cda6,
                                               _bafeca63c0e6._9a04e6d5c1e8._77f51fe46ba2._96d97ad0e6fe,
                                               _bafeca63c0e6._9a04e6d5c1e8._77f51fe46ba2._dff63ee860ed)):
        if _238196d2b572(_261f620bfe4a, "params", _1eb1ca52a992) == _80400f9e9fcc:
            return _fd58f229f8e3
    return _28c5c554b16d


class _73cbe9b4042d(_bafeca63c0e6._3ebc27b88595._77f4e34586c3):
    """Sampler wrapper that resamples a parameter when a duplicate trial would be created.

    Args:
        base_sampler (optuna.samplers.BaseSampler): Underlying sampler to delegate to.
    """

    def _3bb2857a2e54(self, _0fb2c2d4581b: _bafeca63c0e6._3ebc27b88595._77f4e34586c3):
        self._0fb2c2d4581b = _0fb2c2d4581b  # Use TPESampler or any other sampler

    # Override and delegate infer_relative_search_space to the base sampler
    def _da2009d7d10e(self, _c0046cd37b9a, _9a04e6d5c1e8):
        return self._0fb2c2d4581b._15a9598972a2(_c0046cd37b9a, _9a04e6d5c1e8)

    # Override and delegate sample_relative to the base sampler
    def _7035263b8ceb(self, _c0046cd37b9a, _9a04e6d5c1e8, _c818d0aad382):
        return self._0fb2c2d4581b._793186cfe6b3(_c0046cd37b9a, _9a04e6d5c1e8, _c818d0aad382)

    # Override sample_independent to check for duplicates
    def _ef976fc43e08(self, _c0046cd37b9a, _9a04e6d5c1e8, _031aa039eb3e, _e68a2295553c):
        """
        Sample independently using the base sampler. If the proposed parameter
        would create a duplicate trial (all params equal to a past trial),
        resample until unique.

        Args:
            study (optuna.Study)
            trial (optuna.trial.Trial)
            param_name (str)
            param_distribution: distribution object passed by Optuna

        Returns:
            The sampled parameter value.

        Raises:
            RuntimeError: If underlying base_sampler repeatedly fails to produce a non-duplicate
                          after many attempts (guard not implemented here to preserve original behavior).
        """
        while _fd58f229f8e3:
            # Sample a set of hyperparameters using the base sampler (TPESampler)
            _a135a602a2b0 = self._0fb2c2d4581b._9e55d17981d3(_c0046cd37b9a, _9a04e6d5c1e8, _031aa039eb3e, _e68a2295553c)

            # Temporarily assign the parameter to the trial for comparison
            _9a04e6d5c1e8._5bada3a1920c[_031aa039eb3e] = _a135a602a2b0

            # Check if this parameter set (with the current params) is a duplicate
            if not _f4591fee8035(_9a04e6d5c1e8, _c0046cd37b9a):
                return _a135a602a2b0  # If not duplicate, return the parameter


def _ed4569a83362(_8d004ced5fec):
    """Compute gamma parameter for TPESampler.

    Args:
        n (int): Number of completed trials.

    Returns:
        int: Top 10% of n, capped at 25.
    """
    # top 10% of n completed trials
    return _4e0cd8efe909(25, _56b12ba7f4cb(0.1 * _8d004ced5fec))

def _f9517dec5dee(_f145d5ca9ebd, _9114d7f95987: _287eda70c7fe, _6a5f05e64309=_1eb1ca52a992, _e5ccc68b2a03: _5ad1768dd268 = _fd58f229f8e3, _92fde116aa1d=_1eb1ca52a992, _6092e8093c4a: _287eda70c7fe = _1eb1ca52a992):
    """
    Retrieve and validate a property from a dot-separated path (e.g. 'app.random_seed', 'run_config.batch_size').

    Args:
        props: Loaded YAML properties object (attribute/dict hybrid).
        name: Dot-separated property name (string).
        dtype: Optional type enforcement (e.g. int, float, str, "list[int]", "list[str]", etc.).
        required: If True, raises error when missing. If False, returns default.
        default: Optional fallback value when required=False and key missing.
        help: Optional human-readable hint for fixing config.

    Raises:
        AttributeError: If key missing and required=True.
        ValueError: If key exists but value is None.
        TypeError: If dtype enforcement fails.

    Returns:
        The retrieved (and possibly cast) value, or default.
    """

    # --- Navigate dotted path ---
    _df0b19e49c24 = _9114d7f95987._84be22a27629(".")
    _6208c91956d5 = _f145d5ca9ebd
    _05e48ebb510a = []
    for _2d8c33bb574b in _df0b19e49c24:
        _05e48ebb510a._62dfc8e82812(_2d8c33bb574b)
        if _6208c91956d5 is _1eb1ca52a992:
            if _e5ccc68b2a03:
                raise _c4ecf6ecd39c(
                    f"Missing required property '{'.'._8de610c0934b(_05e48ebb510a)}' (intermediate value is None). {_6092e8093c4a or ''}"
                )
            return _92fde116aa1d

        if _546f67745193(_6208c91956d5, _2d8c33bb574b):
            _6208c91956d5 = _238196d2b572(_6208c91956d5, _2d8c33bb574b)
        elif _1fbd91ba88e2(_6208c91956d5, _4358b0daa422) and _2d8c33bb574b in _6208c91956d5:
            _6208c91956d5 = _6208c91956d5[_2d8c33bb574b]
        else:
            if _e5ccc68b2a03:
                raise _c4ecf6ecd39c(
                    f"Missing required property '{'.'._8de610c0934b(_05e48ebb510a)}'. {_6092e8093c4a or ''}"
                )
            return _92fde116aa1d

    _5aa2ba1ef64f = _6208c91956d5

    # --- Explicit null check ---
    if _5aa2ba1ef64f is _1eb1ca52a992:
        raise _9c1a748b85d8(
            f"Property '{_9114d7f95987}' is explicitly null/None. Please set a valid value or remove the key to use default. {_6092e8093c4a or ''}"
        )

    # --- Dtype enforcement ---
    if _6a5f05e64309 is not _1eb1ca52a992:
        def _3cd88133527a(_ff4d48973ddb):
            raise _589fbe7fea7f(f"Property '{_9114d7f95987}' type validation failed: {_ff4d48973ddb}. {_6092e8093c4a or ''}")

        if _1fbd91ba88e2(_6a5f05e64309, _287eda70c7fe) and _6a5f05e64309._d06c9429c0a7("list[") and _6a5f05e64309._7eae09a32ee0("]"):
            _a62c309880a6 = _6a5f05e64309[5:-1]._c49151d61676()
            if not _1fbd91ba88e2(_5aa2ba1ef64f, _f323bbd8f778):
                _bd3edc314a53(f"expected list[{_a62c309880a6}], got {_85305f4166b8(_5aa2ba1ef64f).__name__}")
            _3d2267ee40bb = {"int": _56b12ba7f4cb, "float": _730356a95764, "str": _287eda70c7fe, "bool": _5ad1768dd268}
            _a39e631068ec = _3d2267ee40bb._9c05549e7554(_a62c309880a6)
            if _a39e631068ec is _1eb1ca52a992:
                _bd3edc314a53(f"unsupported inner dtype '{_a62c309880a6}'")
            try:
                _5aa2ba1ef64f = [_a39e631068ec(_4694416eb005) for _4694416eb005 in _5aa2ba1ef64f]
            except _7e6af5044a3b as _1794af0bb024:
                _bd3edc314a53(f"failed to cast elements to {_a62c309880a6}: {_1794af0bb024}")
        else:
            try:
                _5aa2ba1ef64f = _6a5f05e64309(_5aa2ba1ef64f)
            except _7e6af5044a3b as _1794af0bb024:
                _bd3edc314a53(f"cannot cast to {_238196d2b572(_6a5f05e64309, '__name__', _6a5f05e64309)}: {_1794af0bb024}")

    return _5aa2ba1ef64f


def _52c23ed935ce(_9a04e6d5c1e8: _bafeca63c0e6._9a04e6d5c1e8._bbd33648489f, _642de2d626f9: _f323bbd8f778, _b3ec171c435b: _81d9e8da0874):
    """Construct a PEFT LoraConfig from an Optuna trial's suggested hyperparameters.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance to query for hyperparameters.
        target_modules (list): list of target modules (may be empty).
        lora_task_type (Any): TaskType enum or equivalent required by LoraConfig.

    Returns:
        LoraConfig: Instance configured according to trial suggestions.

    Raises:
        Exception: Propagates exceptions from the underlying LoraConfig constructor or trial queries.
    """
    # Define the range for rank
    _dd12f77cb593 = _9a04e6d5c1e8._e2a069ba72cc("lora_rank", 4, 16, _5dff03721e08=4)

    # Dynamically calculate scaling factor based on rank
    _593081fa6662 = _9a04e6d5c1e8._e2a069ba72cc("lora_alpha_scaling_factor", 8, 32, _5dff03721e08=4)
    # Add dropout options for LoRA
    _76c87ec9c060 = _9a04e6d5c1e8._a86309d1450d("lora_dropout", [0.0, 0.1, 0.2])

    # Create and return LoraConfig. Keep as the project's expected LoraConfig API.
    return _aa34cac3dc59(
        _bc391b1bf0d7=_dd12f77cb593 if not _1fbd91ba88e2(_dd12f77cb593, _00cff7de19ed) else _dd12f77cb593[0],
        _593081fa6662=_593081fa6662 if not _1fbd91ba88e2(_593081fa6662, _00cff7de19ed) else _593081fa6662[0],
        _76c87ec9c060=_76c87ec9c060 if not _1fbd91ba88e2(_76c87ec9c060, _00cff7de19ed) else _76c87ec9c060[0],
        _642de2d626f9=_642de2d626f9 if _642de2d626f9 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj", "embed_tokens", "lm_head"],
        _3f0b065c07e5=_b3ec171c435b
    )

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Apply LoRA to model.embedding or equivalent embedding root for decoder models.
#     """
#     log.info(f"Model Structure before applying LoRA {model}")
#     log.info("Trainable params before LoRA: %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))

#     if not isinstance(target_embedding_modules, dict):
#         log.warning("Expected target_embedding_modules dict, got %s; skipping LoRA.", type(target_embedding_modules))
#         return model

#     root = getattr(model, "module", model)
#     model_name_to_mod = dict(root.named_modules())

#     # Resolve names (object identity, exact name, suffix)
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None
#         for nm, mm in model_name_to_mod.items():
#             if mm is emb_mod:
#                 found = nm; break
#         if found is None and emb_key in model_name_to_mod:
#             found = emb_key
#         if found is None:
#             short = emb_key.replace("embedding.", "").replace("module.", "").replace("embedding.module.", "")
#             for nm in model_name_to_mod:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in model", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # shallow clone config avoiding odict_keys issues
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # cleaned target module names relative to embedding
#     cleaned_targets = []
#     for full_nm in resolved:
#         t = full_nm.replace("model.embedding.", "").replace("embedding.", "").replace("module.", "").lstrip(".")
#         if t:
#             cleaned_targets.append(t)
#     # dedupe order-preserve
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     try:
#         cfg.target_modules = list(cleaned_targets)
#     except Exception:
#         setattr(cfg, "target_modules", list(cleaned_targets))

#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- UNWRAP WRAPPERS UNDER model.embedding (in-place) ---
#     def _resolve_embedding_root(obj):
#         """
#         Return tuple (embedding_module, path_key) where path_key indicates where to reattach:
#           - "embedding" -> model.embedding
#           - "model.model.embed_tokens" -> model.model.embed_tokens
#           - "transformer.wte" -> model.transformer.wte
#         Raises ValueError if none found.
#         """
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         # some wrappers: e.g., HF models that nest inside .base_model
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Try to unwrap common wrappers under the embedding subtree (in-place)
#     def _unwrap_candidate(obj):
#         if hasattr(obj, "module") and obj is not getattr(obj, "module"):
#             return getattr(obj, "module")
#         if hasattr(obj, "base_layer") and obj is not getattr(obj, "base_layer"):
#             return getattr(obj, "base_layer")
#         return None

#     for parent_name, parent in list(emb_unwrapped.named_modules()):
#         # use named_children on parent to replace attributes on parent
#         for child_name, child in list(parent.named_children()):
#             try:
#                 inner = _unwrap_candidate(child)
#                 if inner is not None:
#                     setattr(parent, child_name, inner)
#                     log.debug("Unwrapped %s.%s -> %s", parent_name or "embedding_root", child_name, inner.__class__.__name__)
#             except Exception:
#                 log.debug("Could not unwrap child %s of parent %s", child_name, parent_name)

#     # Recompute actual embedding root after unwrapping (in case we changed .module children)
#     emb_current = emb_current  # preserve original wrapper object reference (used for reattach)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Use small container exposing embedding so PEFT only touches embedding submodules
#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)
#     # attempt to move container to same device as embedding params to avoid device errors
#     try:
#         sample_dev = None
#         for p in emb_unwrapped.parameters():
#             sample_dev = p.device; break
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Call PEFT on the embedding container
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # Reinstall wrapped embedding back into the top-level model, preserving wrapper if present
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped_emb)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped_emb
#             else:
#                 model.embedding = wrapped_emb
#         elif emb_path == "model.model.embed_tokens":
#             model.model.embed_tokens = wrapped_emb
#         elif emb_path == "transformer.wte":
#             model.transformer.wte = wrapped_emb
#         elif emb_path == "base_model.model.embed_tokens":
#             model.base_model.model.embed_tokens = wrapped_emb
#         else:
#             # fallback, attempt best-effort attach by attribute traversal
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     log.info("Applied LoRA to model.embedding (PEFT-wrapped).")

#     # Freeze non-LoRA params inside embedding; keep LoRA params trainable
#     try:
#         for name, param in model.embedding.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside model.embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in model.embedding.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("LoRA enabled %d tensors, total %d params.", len(enabled), sum(v for _, v in enabled))
#     log.info("After LoRA: trainable params %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))
#     log.info(f"Model Structure after applying LoRA {model}")
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Unified LoRA application for both BERT-like and LLaMA-like models.
#     Works with quantized or non-quantized modules.

#     Returns the input `model` with LoRA adapters applied in-place.
#     """
#     # small local helper: resolve common embedding roots
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())
#     log.info("Root type: %s", type(root))
#     log.info("Named modules sample: %s", list(named_modules.keys())[:20])
#     log.info("Target embedding keys: %s", list(target_embedding_modules.keys()))

#     # --- resolve provided target_embedding_modules to names in root.named_modules() ---
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None

#         # identity match (object identity)
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 found = nm
#                 break
#         if found:
#             resolved.append(found); continue

#         # direct string variants (embedding. prefix / without)
#         if isinstance(emb_key, str):
#             variants = [emb_key]
#             if not emb_key.startswith("embedding."):
#                 variants.append("embedding." + emb_key)
#             else:
#                 variants.append(emb_key.replace("embedding.", "", 1))
#             for v in variants:
#                 if v in named_modules:
#                     found = v; break
#         if found:
#             resolved.append(found); continue

#         # suffix match (endswith)
#         if isinstance(emb_key, str):
#             short = emb_key.replace("embedding.", "").replace("module.", "").lstrip(".")
#             for nm in named_modules:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found); continue

#         # fallback: match by class name + first parameter shape
#         try:
#             if isinstance(emb_mod, torch.nn.Module):
#                 emb_cls = emb_mod.__class__.__name__
#                 ref_shape = None
#                 for p in emb_mod.parameters():
#                     ref_shape = tuple(p.shape); break
#                 if ref_shape is not None:
#                     for nm, mm in named_modules.items():
#                         if mm.__class__.__name__ != emb_cls:
#                             continue
#                         for p in mm.parameters():
#                             if tuple(p.shape) == ref_shape:
#                                 found = nm; break
#                         if found:
#                             break
#         except Exception:
#             pass
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in root.named_modules()", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")
#     log.info("Resolved LoRA targets: %s", resolved)

#     # --- clone & normalise LoRA config ---
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # Determine embedding root and path (for normalization)
#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Embedding root resolution failed: {e}")

#     # Normalize target module names to be *relative to the module we will pass to PEFT*
#     cleaned_targets = []
#     for full in resolved:
#         # If resolved name starts with the emb_path, strip that prefix
#         if isinstance(full, str) and full.startswith(emb_path + "."):
#             cleaned = full[len(emb_path) + 1 :]
#         else:
#             # also handle common alternatives
#             cleaned = full.replace("embedding.model.", "").replace("embedding.", "").replace("model.", "").lstrip(".")
#         if cleaned:
#             cleaned_targets.append(cleaned)
#     # dedupe preserve order
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     cfg.target_modules = list(cleaned_targets)
#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- if LLaMA-like (decoder) apply LoRA directly on decoder model to avoid embedding-wrapper issues ---
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         log.info("Detected LLaMA architecture — applying LoRA directly on decoder model.")
#         try:
#             # normalize: remove "model." prefix so PEFT matches internal names
#             cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]
#             # cfg.target_modules must be relative to model.embedding.model (we already normalized above)
#             wrapped_decoder = get_peft_model(model.embedding.model, cfg)
#             # replace decoder in-place
#             model.embedding.model = wrapped_decoder

#             # freeze everything except LoRA params inside the wrapped decoder
#             for n, p in model.embedding.model.named_parameters():
#                 p.requires_grad = ("lora" in n.lower())

#             log.info("Applied LoRA to LLaMA decoder; trainable params: %d",
#                      sum(1 for _, p in model.embedding.model.named_parameters() if p.requires_grad))
#             return model
#         except Exception as e:
#             log.error("Failed to apply LoRA directly on LLaMA decoder: %s", e)
#             raise

#     # --- otherwise: create container exposing 'embedding' so PEFT touches only embedding subtree ---
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # attach generation helper if root implements it (prevents PEFT complaining)
#     if hasattr(root, "prepare_inputs_for_generation"):
#         try:
#             setattr(emb_container, "prepare_inputs_for_generation", getattr(root, "prepare_inputs_for_generation"))
#         except Exception:
#             # non-fatal
#             pass

#     # move container to embedding device if known
#     try:
#         sample_dev = next((p.device for p in emb_unwrapped.parameters()), None)
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Wrap the container with PEFT
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # obtain wrapped embedding module and reattach into the model at emb_path
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         parts = emb_path.split(".")
#         tgt = model
#         for p in parts[:-1]:
#             tgt = getattr(tgt, p)
#         setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     # Freeze non-LoRA params inside the wrapped embedding; keep LoRA params trainable
#     try:
#         for name, param in wrapped_emb.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside wrapped embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in wrapped_emb.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("Applied LoRA successfully with %d trainable tensors.", len(enabled))
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     # ------------------------------------------------------------------
#     # Helper: ensure PEFT-required method exists
#     # ------------------------------------------------------------------
#     def _ensure_prepare_inputs_for_generation(obj, fallback):
#         if hasattr(obj, "prepare_inputs_for_generation"):
#             return
#         if hasattr(fallback, "prepare_inputs_for_generation"):
#             obj.prepare_inputs_for_generation = fallback.prepare_inputs_for_generation
#             return

#         def _noop_prepare_inputs_for_generation(*args, **kwargs):
#             return args[0] if args else None

#         obj.prepare_inputs_for_generation = _noop_prepare_inputs_for_generation

#     # ------------------------------------------------------------------
#     # Helper: resolve embedding root (unchanged logic)
#     # ------------------------------------------------------------------
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())

#     # ------------------------------------------------------------------
#     # Resolve target embedding modules (unchanged)
#     # ------------------------------------------------------------------
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 resolved.append(nm)
#                 break

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # ------------------------------------------------------------------
#     # Clone LoRA config
#     # ------------------------------------------------------------------
#     try:
#         cfg = lora_config.__class__(**vars(lora_config))
#     except Exception:
#         cfg = lora_config

#     # ------------------------------------------------------------------
#     # Normalize target module names
#     # ------------------------------------------------------------------
#     emb_current, emb_path = _resolve_embedding_root(model)

#     cleaned_targets = []
#     for full in resolved:
#         if full.startswith(emb_path + "."):
#             cleaned_targets.append(full[len(emb_path) + 1 :])

#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")

#     cfg.target_modules = cleaned_targets

#     # ------------------------------------------------------------------
#     # Detect LLaMA-style decoder (unchanged intent)
#     # ------------------------------------------------------------------
#     is_llama_decoder = (
#         hasattr(model, "embedding")
#         and hasattr(model.embedding, "model")
#         and hasattr(model.embedding.model, "layers")
#     )

#     is_gemma_decoder = (
#         hasattr(model, "model")
#         and hasattr(model.model, "model")
#         and hasattr(model.model.model, "layers")
#     )

#     # ------------------------------------------------------------------
#     # LLaMA decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_llama_decoder:
#         decoder = model.embedding.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.embedding.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model
    
#     # ------------------------------------------------------------------
#     # gemma decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_gemma_decoder:
#         decoder = model.model.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.model.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model

#     # ------------------------------------------------------------------
#     # Embedding-container path (PATCHED)
#     # ------------------------------------------------------------------
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # CRITICAL FIX: ensure hook exists UNCONDITIONALLY
#     _ensure_prepare_inputs_for_generation(emb_container, root)

#     wrapped_container = get_peft_model(emb_container, cfg)
#     wrapped_emb = wrapped_container.embedding

#     # Reattach wrapped embedding
#     parts = emb_path.split(".")
#     tgt = model
#     for p in parts[:-1]:
#         tgt = getattr(tgt, p)
#     setattr(tgt, parts[-1], wrapped_emb)

#     for name, param in wrapped_emb.named_parameters():
#         param.requires_grad = ("lora" in name.lower())

#     return model

def _8ee0734e1e54(
    _441927423503: "torch.nn.Module",
    _aefbc75fd956: "Dict[str, torch.nn.Module]",
    _d382dd42ba13,
    _8a3daed9957b: "Any"
) -> "torch.nn.Module":

    def _3d9750fc5d8d(_f53fcceaf200, _117301ece538):
        if _546f67745193(_f53fcceaf200, "prepare_inputs_for_generation"):
            return
        if _546f67745193(_117301ece538, "prepare_inputs_for_generation"):
            _f53fcceaf200._68daad7b4503 = _117301ece538._68daad7b4503
            return

        def _a60c29383de0(*_5d7bb0158177, **_f432233bb05b):
            return _5d7bb0158177[0] if _5d7bb0158177 else _1eb1ca52a992

        _f53fcceaf200._68daad7b4503 = _114644d4130c

    def _050cd87a70f5(_f53fcceaf200):
        if _546f67745193(_f53fcceaf200, "embedding"):
            return _238196d2b572(_f53fcceaf200, "embedding"), "embedding"
        if _546f67745193(_f53fcceaf200, "model") and _546f67745193(_f53fcceaf200._441927423503, "embed_tokens"):
            return _238196d2b572(_f53fcceaf200._441927423503, "embed_tokens"), "model.embed_tokens"
        if _546f67745193(_f53fcceaf200, "model") and _546f67745193(_f53fcceaf200._441927423503, "model") and _546f67745193(_f53fcceaf200._441927423503._441927423503, "embed_tokens"):
            return _238196d2b572(_f53fcceaf200._441927423503._441927423503, "embed_tokens"), "model.model.embed_tokens"
        if _546f67745193(_f53fcceaf200, "transformer") and _546f67745193(_f53fcceaf200._334e24769b29, "wte"):
            return _238196d2b572(_f53fcceaf200._334e24769b29, "wte"), "transformer.wte"
        if _546f67745193(_f53fcceaf200, "base_model") and _546f67745193(_f53fcceaf200._5d6f41af3288, "model") and _546f67745193(_f53fcceaf200._5d6f41af3288._441927423503, "embed_tokens"):
            return _238196d2b572(_f53fcceaf200._5d6f41af3288._441927423503, "embed_tokens"), "base_model.model.embed_tokens"
        raise _9c1a748b85d8(f"Could not resolve embedding root for {_f53fcceaf200._917f0b408327.__name__}")

    _f9162e9d7ffc = _238196d2b572(_441927423503, "module", _441927423503)
    _2bec8b623180 = _4358b0daa422(_f9162e9d7ffc._2bec8b623180())

    # --------------------------------------------------
    # Detect decoders FIRST (ONLY MOVED)
    # --------------------------------------------------
    _0bba32936b60 = (
        _546f67745193(_441927423503, "embedding")
        and _546f67745193(_441927423503._a8056a4082cc, "model")
        and _546f67745193(_441927423503._a8056a4082cc._441927423503, "layers")
    )

    _29a4ce9a6a35 = (
        _546f67745193(_441927423503, "model")
        and _546f67745193(_441927423503._441927423503, "model")
        and _546f67745193(_441927423503._441927423503._441927423503, "layers")
    )

    _7377813e745b = (
        _546f67745193(_441927423503, "model")
        and _546f67745193(_441927423503._441927423503, "layers")
    )

    # --------------------------------------------------
    # Resolve target embedding modules (UNCHANGED)
    # --------------------------------------------------
    _cb5a0fa90fc5 = []
    for _029d5efe4404, _5c7bb1b5b8a3 in _aefbc75fd956._c5a306e5fdc6():
        for _a33d0eb4b7d7, _f35308d85839 in _2bec8b623180._c5a306e5fdc6():
            if _f35308d85839 is _5c7bb1b5b8a3:
                _cb5a0fa90fc5._62dfc8e82812(_a33d0eb4b7d7)
                break

    if not _cb5a0fa90fc5 and not _0bba32936b60 and not _29a4ce9a6a35 and not _7377813e745b:
        raise _9c1a748b85d8("No embedding submodules resolved for LoRA — skipping.")

    # --------------------------------------------------
    # Clone LoRA config (UNCHANGED)
    # --------------------------------------------------
    try:
        _3891be6532bb = _d382dd42ba13._917f0b408327(**_67e9f349e94d(_d382dd42ba13))
    except _7e6af5044a3b:
        _3891be6532bb = _d382dd42ba13

    # --------------------------------------------------
    # Normalize target module names (UNCHANGED)
    # --------------------------------------------------
    _822523ae8463, _5f2faed7dec5 = _52eb008319e1(_441927423503)

    _360fff26a11d = []
    for _a7ea637a450c in _cb5a0fa90fc5:
        if _a7ea637a450c._d06c9429c0a7(_5f2faed7dec5 + "."):
            _360fff26a11d._62dfc8e82812(_a7ea637a450c[_1d2bfb977975(_5f2faed7dec5) + 1 :])

    if _360fff26a11d:
        _3891be6532bb._642de2d626f9 = _360fff26a11d

    # --------------------------------------------------
    # LLaMA decoder path (UNCHANGED)
    # --------------------------------------------------
    if _0bba32936b60:
        _a67388441828 = _441927423503._a8056a4082cc._441927423503
        _e7132366765c(_a67388441828, _441927423503)
        _3891be6532bb._642de2d626f9 = [_84fcd0034f95._ce00126fa1af("model.", "") for _84fcd0034f95 in _3891be6532bb._642de2d626f9]
        _97dc7d1be78b = _615f357041a7(_a67388441828, _3891be6532bb)
        _441927423503._a8056a4082cc._441927423503 = _97dc7d1be78b
        for _8d004ced5fec, _2d8c33bb574b in _97dc7d1be78b._1147d1da7ce2():
            _2d8c33bb574b._d483977a22b9 = ("lora" in _8d004ced5fec._14548be4df14())
        return _441927423503

    # --------------------------------------------------
    # Gemma decoder path (UNCHANGED)
    # --------------------------------------------------
    if _29a4ce9a6a35:
        _a67388441828 = _441927423503._441927423503._441927423503
        _e7132366765c(_a67388441828, _441927423503)
        _3891be6532bb._642de2d626f9 = [_84fcd0034f95._ce00126fa1af("model.", "") for _84fcd0034f95 in _3891be6532bb._642de2d626f9]
        _97dc7d1be78b = _615f357041a7(_a67388441828, _3891be6532bb)
        _441927423503._441927423503._441927423503 = _97dc7d1be78b
        for _8d004ced5fec, _2d8c33bb574b in _97dc7d1be78b._1147d1da7ce2():
            _2d8c33bb574b._d483977a22b9 = ("lora" in _8d004ced5fec._14548be4df14())
        return _441927423503
    
    # --------------------------------------------------
    # Qwen decoder path (UNCHANGED)
    # --------------------------------------------------
    if _7377813e745b:
        _a67388441828 = _441927423503._441927423503
        _e7132366765c(_a67388441828, _441927423503)
        _3891be6532bb._642de2d626f9 = [_84fcd0034f95._ce00126fa1af("model.", "") for _84fcd0034f95 in _3891be6532bb._642de2d626f9]
        _97dc7d1be78b = _615f357041a7(_a67388441828, _3891be6532bb)
        _441927423503._441927423503 = _97dc7d1be78b
        for _8d004ced5fec, _2d8c33bb574b in _97dc7d1be78b._1147d1da7ce2():
            _2d8c33bb574b._d483977a22b9 = ("lora" in _8d004ced5fec._14548be4df14())
        return _441927423503

    # --------------------------------------------------
    # Embedding path (UNCHANGED)
    # --------------------------------------------------
    _2f15eeecc6e5 = _238196d2b572(_822523ae8463, "module", _822523ae8463)

    class _96edb47d9ecf(_fb5870f47c15._ca6d5a9821a8._6ff3a2fd07a5):
        def _3bb2857a2e54(self, _b9931d6de4cd):
            _d0f57cbb98f7()._92c7349babdb()
            self._a8056a4082cc = _b9931d6de4cd

    _ce91916fec6f = _5c3b6d949954(_2f15eeecc6e5)
    _e7132366765c(_ce91916fec6f, _f9162e9d7ffc)

    _ff6b008989dc = _615f357041a7(_ce91916fec6f, _3891be6532bb)
    _1ffa2023e09c = _ff6b008989dc._a8056a4082cc

    _df0b19e49c24 = _5f2faed7dec5._84be22a27629(".")
    _40220d825d02 = _441927423503
    for _2d8c33bb574b in _df0b19e49c24[:-1]:
        _40220d825d02 = _238196d2b572(_40220d825d02, _2d8c33bb574b)
    _1e4324c82206(_40220d825d02, _df0b19e49c24[-1], _1ffa2023e09c)

    for _9114d7f95987, _a135a602a2b0 in _1ffa2023e09c._1147d1da7ce2():
        _a135a602a2b0._d483977a22b9 = ("lora" in _9114d7f95987._14548be4df14())

    return _441927423503


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> "torch.nn.Module":
#     """
#     Reverse of apply_lora_to_model (focused on embedding subtree).
#     - Resolves the same embedding root as apply_lora_to_model.
#     - Prefers calling PEFT's merge API if present on the embedding wrapper.
#     - Otherwise performs a manual merge of inline lora wrappers (base_layer + lora_A/lora_B).
#     - Replaces wrapper modules with their base_layer so the final model contains plain nn.Modules.
#     - Works with ModuleDict(default=...), ParameterDict, and common lora_alpha container formats.
#     """
#     if log is None:
#         import logging
#         log = logging.getLogger(__name__)

#     import torch
#     from typing import Any, Dict

#     root = getattr(model, "module", model)

#     # --- Resolve embedding root using the same heuristics as apply_lora_to_model ---
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # --- Try PEFT merge if available (embedding-level) ---
#     try:
#         if hasattr(emb_current, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on embedding wrapper.")
#             merged = emb_current.merge_and_unload()
#             wrapped = merged if merged is not None else emb_current
#             # reattach to model according to emb_path (preserve wrapper if it exists)
#             try:
#                 if emb_path == "embedding":
#                     if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                         try:
#                             setattr(emb_current, "module", wrapped)
#                             model.embedding = emb_current
#                         except Exception:
#                             model.embedding = wrapped
#                     else:
#                         model.embedding = wrapped
#                 else:
#                     parts = emb_path.split(".")
#                     tgt = model
#                     for p in parts[:-1]:
#                         tgt = getattr(tgt, p)
#                     setattr(tgt, parts[-1], wrapped)
#                 log.info("PEFT embedding merge_and_unload() succeeded.")
#                 return model
#             except Exception:
#                 # if reattach fails, continue to manual merge
#                 log.warning("PEFT merge succeeded but reattach failed; continuing to manual merge.")
#         if hasattr(emb_unwrapped, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on emb_unwrapped.")
#             merged = emb_unwrapped.merge_and_unload()
#             wrapped = merged if merged is not None else emb_unwrapped
#             # try to reattach preserving wrapper
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped
#             else:
#                 parts = emb_path.split(".")
#                 tgt = model
#                 for p in parts[:-1]:
#                     tgt = getattr(tgt, p)
#                 setattr(tgt, parts[-1], wrapped)
#             log.info("PEFT emb_unwrapped merge_and_unload() succeeded.")
#             return model
#     except Exception as e:
#         log.warning("PEFT merge attempt raised: %s -- falling back to manual merge", e)

#     # --- Helpers for manual merge ---
#     def _normalize_alpha(alpha_raw):
#         # return float or None
#         try:
#             if alpha_raw is None:
#                 return None
#             if isinstance(alpha_raw, dict):
#                 # pick the first scalar-like value
#                 for v in alpha_raw.values():
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     # if v is a tensor scalar
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             continue
#                 # fallback: try first value cast
#                 try:
#                     return float(list(alpha_raw.values())[0])
#                 except Exception:
#                     return None
#             # ModuleDict or module with numeric attr/buffer
#             if hasattr(alpha_raw, "__class__") and "Module" in alpha_raw.__class__.__name__:
#                 # try attribute names
#                 for a in ("lora_alpha", "alpha"):
#                     v = getattr(alpha_raw, a, None)
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             pass
#                 # try parameters
#                 try:
#                     ps = list(alpha_raw.parameters())
#                     if ps:
#                         return float(ps[0].item())
#                 except Exception:
#                     pass
#                 return None
#             if isinstance(alpha_raw, (list, tuple)):
#                 if not alpha_raw:
#                     return None
#                 return float(alpha_raw[0])
#             if isinstance(alpha_raw, (int, float)):
#                 return float(alpha_raw)
#             # attempt cast
#             return float(alpha_raw)
#         except Exception:
#             return None

#     def _unwrap_map(obj) -> Dict[str, Any]:
#         """
#         Normalize lora_A / lora_B into a dict name->module/param object.
#         Accepts Module (single), ModuleDict/dict, ParameterDict-like.
#         """
#         out = {}
#         try:
#             # single module (not ModuleDict)
#             if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                 out[""] = obj
#                 return out
#         except Exception:
#             pass
#         # mapping-like
#         try:
#             items = list(obj.items())
#         except Exception:
#             items = []
#         for k, v in items:
#             out[k] = v
#         return out

#     def _tensor_from_obj(x):
#         # return a torch.Tensor (raw data) or None
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first param
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#             return None
#         if isinstance(x, torch.Tensor):
#             return x
#         return None

#     def _compute_delta(A_w, B_w, base):
#         """
#         Robustly compute delta for given A_w, B_w and base.weight shape.
#         Tries: B@A, A@B, inference from flattened tensors (reshape using base shape),
#         and chunked-sum heuristics. Raises RuntimeError if impossible.
#         """
#         # quick guards
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # common case: A 2D (r,in), B 2D (out,r) -> B@A
#         if A_w.dim() == 2 and B_w.dim() == 2 and B_w.shape[1] == A_w.shape[0]:
#             return B_w @ A_w

#         # if either is 1D (flattened), try to infer r using base shape
#         base_out = int(base.weight.shape[0])
#         base_in = int(base.weight.shape[1])
#         A_num = int(A_w.numel())
#         B_num = int(B_w.numel())

#         # attempt reshape inference: try r candidate derived from counts
#         # If B_num == base_out * r and A_num == r * base_in => reshape and B@A
#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat
#             # try candidate from A
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat

#         # try simple transpose fallbacks
#         try:
#             return B_w @ A_w
#         except Exception:
#             pass
#         try:
#             return A_w @ B_w
#         except Exception:
#             pass

#         # chunked heuristic: if one inner-dim is integer multiple of the other
#         try:
#             # promote to 2D (best-effort)
#             A_mat = A_w if A_w.dim() == 2 else A_w.view(A_w.shape[0], -1)
#             B_mat = B_w if B_w.dim() == 2 else B_w.view(-1, B_w.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)} for base {tuple(base.weight.shape)}")

#     # --- Manual merge walk under embedding subtree ---
#     merged = 0
#     replaced = 0
#     # iterate parents so we can setattr on them
#     for parent in list(emb_unwrapped.modules()):
#         for child_name, child in list(parent.named_children()):
#             # target wrappers: have base_layer and lora_A/lora_B
#             if not hasattr(child, "base_layer"):
#                 continue
#             if not (hasattr(child, "lora_A") and hasattr(child, "lora_B")):
#                 # attempt simple unwraps (module/base_layer) to remove wrapper objects
#                 try:
#                     if hasattr(child, "module") and child is not getattr(child, "module"):
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> module", type(parent).__name__, child_name)
#                         continue
#                     if hasattr(child, "base_layer"):
#                         setattr(parent, child_name, getattr(child, "base_layer"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> base_layer", type(parent).__name__, child_name)
#                         continue
#                 except Exception:
#                     pass
#                 continue

#             base = getattr(child, "base_layer", None)
#             if base is None or not hasattr(base, "weight"):
#                 log.warning("Skipping %s: no base_layer.weight", child_name)
#                 continue

#             # normalize maps
#             A_map = _unwrap_map(getattr(child, "lora_A", None))
#             B_map = _unwrap_map(getattr(child, "lora_B", None))
#             if not A_map or not B_map:
#                 # attempt remove wrapper if no A/B entries
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (empty A/B).", child_name)
#                 except Exception:
#                     log.warning("Could not replace empty wrapper %s", child_name)
#                 continue

#             # normalize alpha
#             alpha_raw = getattr(child, "lora_alpha", None)
#             alpha = _normalize_alpha(alpha_raw)

#             applied_here = 0
#             # iterate keys (broadcast single->many by using "" key)
#             keys = sorted(set(A_map.keys()) | set(B_map.keys()))
#             for k in keys:
#                 A_obj = A_map.get(k) or A_map.get("")
#                 B_obj = B_map.get(k) or B_map.get("")
#                 A_w = _tensor_from_obj(A_obj)
#                 B_w = _tensor_from_obj(B_obj)
#                 if A_w is None or B_w is None:
#                     log.debug("Skipping %s key=%s: A/B tensor not found", child_name, k)
#                     continue

#                 # handle zero-length adapters by removing wrapper aggressively (safe for plain model)
#                 if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                     log.warning("Empty/zero-dim A/B for %s key=%s — replacing wrapper with base.", child_name, k)
#                     try:
#                         setattr(parent, child_name, base)
#                         replaced += 1
#                         applied_here = 0
#                     except Exception as e:
#                         log.warning("Could not replace wrapper %s: %s", child_name, e)
#                     break  # move to next child

#                 try:
#                     # compute delta robustly
#                     delta = _compute_delta(A_w, B_w, base)
#                     # scale detection r and alpha
#                     r = A_w.shape[0] if A_w.dim() >= 1 else None
#                     scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0
#                     # apply under no_grad
#                     with torch.no_grad():
#                         base.weight.data += delta.to(base.weight.device, base.weight.dtype) * scale
#                     applied_here += 1
#                     merged += 1
#                     log.info("Merged LoRA into %s key=%s (scale=%s, delta_shape=%s)", child_name, k, scale, tuple(delta.shape))
#                 except Exception as e:
#                     log.warning("Failed computing LoRA delta for %s key=%s: %s", child_name, k, e)
#                     # continue trying other keys

#             # after keys processed, if any applied -> replace wrapper with base
#             if applied_here > 0:
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base after applying %d delta(s).", child_name, applied_here)
#                 except Exception as e:
#                     log.warning("Applied deltas but failed to replace wrapper %s: %s", child_name, e)
#             else:
#                 # no deltas applied; still try to remove wrapper for Lightning compatibility
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (no deltas applied).", child_name)
#                 except Exception as e:
#                     log.warning("Could not replace wrapper %s: %s", child_name, e)

#     # Reattach emb_unwrapped back to model if necessary (preserve wrapper object when possible)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # already mutated in-place for wrappers we replaced above; ignore attach errors
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers.", merged, replaced)
#     log.info(f"Model Structure after removing LoRA {model}")
#     return model


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> Tuple["torch.nn.Module", Dict[str, Any]]:
#     """
#     Reverse of apply_lora_to_model. Minimal-disruption strategy:
#       1) Try PEFT's merge APIs on high-level wrappers (safe).
#       2) If not available, do conservative manual merges:
#          - Only add computed LoRA delta into base.weight when base.weight.dtype is floating.
#          - If base.weight is quantized / non-floating (Byte/Int) or wrapper weight shapes mismatch,
#            skip numeric merge and replace wrapper with base_layer/module to avoid corrupting quant params.
#       3) Always replace wrapper modules with underlying base module to remove PEFT wrappers (so model is runnable).
#     Returns: (model, summary)
#       summary: {merged: int, replaced: int, skipped: int, warnings: [..], details: [..]}
#     """
#     if log is None:
#         log = logging.getLogger(__name__)

#     summary = {"merged": 0, "replaced": 0, "skipped": 0, "warnings": [], "details": []}

#     root = getattr(model, "module", model)

#     # same embedding resolver as apply_lora_to_model
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or a known embed_tokens ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # helper: attempt PEFT merge_and_unload on an object (safe)
#     def _try_peft_merge(obj, ctx_name: str) -> bool:
#         for attr in ("merge_and_unload", "merge_and_unload_legacy", "merge", "unload"):
#             fn = getattr(obj, attr, None)
#             if callable(fn):
#                 try:
#                     log.info("Calling %s() on %s", attr, ctx_name)
#                     res = fn()  # many APIs return None, some return the merged/base module
#                     summary["details"].append(f"Called {attr} on {ctx_name}")
#                     summary["merged"] += 1
#                     # if function returned a module, try to reattach above after caller handles
#                     return True
#                 except Exception as e:
#                     summary["warnings"].append(f"{ctx_name}.{attr}() raised: {e}")
#                     # continue trying other attrs
#         return False

#     # try high-level merges first (LLaMA decoder path)
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         # top-level peft wrapper might be model.embedding.model or model.embedding.model.* (PeftModelForCausalLM)
#         decoder = model.embedding.model
#         attached = False
#         # If decoder is a Peft wrapper, try calling merge_and_unload on it
#         if _try_peft_merge(decoder, "model.embedding.model"):
#             # after merge, try to reassign if merge returned something — some APIs inplace-change
#             # we still proceed to safer manual unwrapping pass later to catch nested wrappers
#             attached = True
#         # also try top-level embedding wrapper
#         if _try_peft_merge(model.embedding, "model.embedding"):
#             attached = True

#         # perform conservative unwrap / manual merge walk under decoder subtree
#         # We'll traverse decoder modules and apply manual merge only for floating base weights.
#         summary_walk = _manual_merge_walk(decoder, log, summary)  # function defined below
#         summary.update(summary_walk)
#         # ensure model.embedding.model remains set (if libra returned new module, it's usually already attached)
#         return model, summary

#     # Non-llama path: embedding container was created by apply -> there is an emb_unwrapped that got wrapped by PEFT.
#     # Try peft merge on emb_current (wrapper) and on emb_unwrapped
#     if _try_peft_merge(emb_current, f"{emb_path} (emb_current)"):
#         # PEFT merge done (or attempted). Still walk and clean wrappers to ensure no leftover fields.
#         pass
#     elif _try_peft_merge(emb_unwrapped, f"{emb_path} (emb_unwrapped)"):
#         pass

#     # if PEFT merge didn't exist/ succeed, fallback to conservative manual merging
#     summary_walk = _manual_merge_walk(emb_unwrapped, log, summary)
#     summary.update(summary_walk)

#     # Reattach candidate back to model (preserve wrapperless object)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             # try preserve wrapper object if existed
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # ignore reattach errors; model already mutated in place for replaced wrappers
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.",
#              summary.get("merged", 0), summary.get("replaced", 0), summary.get("skipped", 0))
#     return model


# Helper: manual merge walker (conservative)
# def _manual_merge_walk(root_module: "torch.nn.Module", log: Any, summary: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Walk modules under `root_module` and:
#       - For children that have .base_layer and lora_A/lora_B try to compute delta and add to base.weight
#         ONLY IF base.weight.dtype is floating (float32/float16/bfloat16).
#       - If base.weight is quantized/non-floating or shapes are incompatible, replace wrapper with base
#         (no numeric merge) to avoid corrupting quant metadata.
#       - If child has .module wrapper (PEFT/other), replace with child.module
#     Returns partial summary updates.
#     """
#     import torch
#     merged = summary.get("merged", 0)
#     replaced = summary.get("replaced", 0)
#     skipped = summary.get("skipped", 0)

#     def _is_floating_dtype(dt):
#         return dt in (torch.float32, torch.float16, torch.bfloat16)

#     def _tensor_from_obj(x):
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.Tensor):
#             return x
#         # Module: try weight param
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first parameter
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#         return None

#     def _compute_delta(A_w, B_w, base_w):
#         """
#         Robust compute similar to previous logic; returns tensor on CPU (float) if possible.
#         Will raise RuntimeError if impossible.
#         """
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # Bring tensors to float32 cpu for computation (do not change original module tensors)
#         A_f = A_w.detach().to(torch.float32).cpu()
#         B_f = B_w.detach().to(torch.float32).cpu()

#         # common: A (r, in), B (out, r) => B @ A
#         if A_f.dim() == 2 and B_f.dim() == 2 and B_f.shape[1] == A_f.shape[0]:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)

#         # try reshape inference using base shape
#         base_out = int(base_w.shape[0])
#         base_in = int(base_w.shape[1])
#         A_num = int(A_f.numel())
#         B_num = int(B_f.numel())

#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)

#         # fallbacks
#         try:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass
#         try:
#             return (A_f @ B_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass

#         # chunked heuristics (rare)
#         try:
#             A_mat = A_f if A_f.dim() == 2 else A_f.view(A_f.shape[0], -1)
#             B_mat = B_f if B_f.dim() == 2 else B_f.view(-1, B_f.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)} for base {tuple(base_w.shape)}")

#     # iterate parents so we can setattr on them
#     for parent in list(root_module.modules()):
#         for child_name, child in list(parent.named_children()):
#             # 1) If wrapper exposes PEFT API, try merge_and_unload first
#             try:
#                 if hasattr(child, "merge_and_unload") and callable(getattr(child, "merge_and_unload")):
#                     try:
#                         log.info("Calling merge_and_unload() on %s.%s", type(parent).__name__, child_name)
#                         child.merge_and_unload()
#                         # After PEFT merge, if child has module/base_layer then replace
#                         repl = getattr(child, "module", None) or getattr(child, "base_layer", None) or getattr(child, "base_model", None)
#                         if repl is not None and repl is not child:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"PEFT merged & replaced {type(parent).__name__}.{child_name}")
#                             continue
#                         else:
#                             # if merge_and_unload didn't return module, try to just remove wrapper by replacing with base if exists
#                             base = getattr(child, "base_layer", None) or getattr(child, "module", None)
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"PEFT merged (no return) and replaced {type(parent).__name__}.{child_name}")
#                                 continue
#                     except Exception as e:
#                         summary["warnings"].append(f"child.merge_and_unload failed {type(parent).__name__}.{child_name}: {e}")
#                         # fallthrough to manual strategies
#                 # 2) If there is a 'module' wrapper, unwrap it (safe)
#                 if hasattr(child, "module") and child is not getattr(child, "module"):
#                     try:
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         summary["details"].append(f"Unwrapped module {type(parent).__name__}.{child_name} -> module")
#                         continue
#                     except Exception:
#                         pass

#                 # 3) If base_layer + lora_A/lora_B perform conservative numeric merge only if base is floating dtype
#                 if hasattr(child, "base_layer") and (hasattr(child, "lora_A") or hasattr(child, "lora_B")):
#                     base = getattr(child, "base_layer", None)
#                     if base is None or not hasattr(base, "weight"):
#                         # can't merge numerically; just replace wrapper with base if possible
#                         try:
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no weight to merge)")
#                                 continue
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base")
#                             skipped += 1
#                             continue

#                     # get A/B tensors (may be ModuleDict / dict / Parameter)
#                     A_obj = getattr(child, "lora_A", None)
#                     B_obj = getattr(child, "lora_B", None)

#                     # support mappinglike or direct module
#                     def _unwrap_map(obj):
#                         out = {}
#                         if obj is None:
#                             return out
#                         if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                             out[""] = obj
#                             return out
#                         # mapping-like
#                         try:
#                             items = list(obj.items())
#                         except Exception:
#                             items = []
#                         for k, v in items:
#                             out[k] = v
#                         return out

#                     A_map = _unwrap_map(A_obj)
#                     B_map = _unwrap_map(B_obj)
#                     if not A_map or not B_map:
#                         # nothing numeric to merge; replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (empty A/B)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace empty wrapper {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # check dtype of base weight -> only attempt numeric merge for floating dtypes
#                     base_w = base.weight if hasattr(base, "weight") else None
#                     if base_w is None:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                             skipped += 1
#                         continue

#                     if not _is_floating_dtype(base_w.dtype):
#                         # quantized or non-floating base: avoid numeric merge; simply replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Skipped numeric merge for quantized base {type(parent).__name__}.{child_name}; replaced wrapper with base")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper for quantized base {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # attempt per-key merge
#                     applied_here = 0
#                     for k in sorted(set(A_map.keys()) | set(B_map.keys())):
#                         A_obj_k = A_map.get(k) or A_map.get("")
#                         B_obj_k = B_map.get(k) or B_map.get("")
#                         A_w = _tensor_from_obj(A_obj_k)
#                         B_w = _tensor_from_obj(B_obj_k)
#                         if A_w is None or B_w is None:
#                             summary["details"].append(f"Skipping key={k} for {type(parent).__name__}.{child_name}: A/B tensor not found")
#                             continue

#                         # check empty shapes
#                         if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                             # unsafe to compute; replace wrapper
#                             try:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Empty/zero-dim A/B for {type(parent).__name__}.{child_name} key={k}; replaced with base")
#                             except Exception as e:
#                                 summary["warnings"].append(f"Could not replace wrapper after empty A/B {type(parent).__name__}.{child_name}: {e}")
#                                 skipped += 1
#                             applied_here = 0
#                             break

#                         try:
#                             delta = _compute_delta(A_w, B_w, base_w)
#                             # detect r for scaling; fallback scale 1.0 if unknown
#                             r = None
#                             try:
#                                 r = int(A_w.shape[0]) if getattr(A_w, "dim", None) and A_w.dim() >= 1 else None
#                             except Exception:
#                                 r = None
#                             alpha_raw = getattr(child, "lora_alpha", None)
#                             alpha = None
#                             # attempt to normalize alpha scalar
#                             try:
#                                 if alpha_raw is None:
#                                     alpha = None
#                                 elif isinstance(alpha_raw, (int, float)):
#                                     alpha = float(alpha_raw)
#                                 elif isinstance(alpha_raw, dict):
#                                     # pick first numeric
#                                     for vv in alpha_raw.values():
#                                         if isinstance(vv, (int, float)):
#                                             alpha = float(vv)
#                                             break
#                                 elif hasattr(alpha_raw, "item"):
#                                     alpha = float(alpha_raw.item())
#                             except Exception:
#                                 alpha = None
#                             scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0

#                             with torch.no_grad():
#                                 base_w.data += delta.to(base_w.device, base_w.dtype) * float(scale)
#                             applied_here += 1
#                             merged += 1
#                             summary["details"].append(f"Merged LoRA into {type(parent).__name__}.{child_name} key={k} (scale={scale}, delta={tuple(delta.shape)})")
#                         except Exception as e:
#                             summary["warnings"].append(f"Failed computing LoRA delta for {type(parent).__name__}.{child_name} key={k}: {e}")
#                             # do not abort — try other keys

#                     # after keys processed: if we applied any merges, replace wrapper with base
#                     if applied_here > 0:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base after applying {applied_here} deltas")
#                         except Exception as e:
#                             summary["warnings"].append(f"Applied deltas but failed to replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1
#                     else:
#                         # no deltas applied -> replace wrapper anyway
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no deltas applied)")
#                         except Exception as e:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1

#                     continue  # next child

#                 # 4) base_model / model attribute replacement (PeftModel wrappers)
#                 if hasattr(child, "base_model") and getattr(child, "base_model") is not None and getattr(child, "base_model") is not child:
#                     try:
#                         setattr(parent, child_name, getattr(child, "base_model"))
#                         replaced += 1
#                         summary["details"].append(f"Replaced {type(parent).__name__}.{child_name} with base_model")
#                         continue
#                     except Exception:
#                         pass

#                 # 5) SafeModuleWrapper unwrapping
#                 cname = child.__class__.__name__.lower()
#                 if "safemodulewrapper" in cname or cname.startswith("_safemodulewrapper"):
#                     repl = getattr(child, "module", None)
#                     if repl is not None:
#                         try:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"Unwrapped SafeModuleWrapper {type(parent).__name__}.{child_name}")
#                             continue
#                         except Exception:
#                             pass

#                 # If none matched — skip safely
#                 skipped += 1
#                 summary["details"].append(f"Skipped {type(parent).__name__}.{child_name} (no wrapper/base_layer found)")
#             except Exception as e_parent_child:
#                 summary["warnings"].append(f"Error while inspecting {type(parent).__name__}.{child_name}: {e_parent_child}")
#                 skipped += 1
#                 continue

#     # update and return summary diffs
#     summary["merged"] = merged
#     summary["replaced"] = replaced
#     summary["skipped"] = skipped
#     return summary

# def merge_lora_into_base(model, log=None):
#     if log is None:
#         log = logging.getLogger(__name__)

#     # Find the PEFT-wrapped decoder (your custom path)
#     if hasattr(model, "embedding") and hasattr(model.embedding, "model"):
#         decoder = model.embedding.model

#         # Check if it's a PEFT model
#         if hasattr(decoder, "merge_and_unload"):
#             try:
#                 log.info("Merging LoRA using PEFT's native merge (this works)")
#                 merged_decoder = decoder.merge_and_unload()
#                 model.embedding.model = merged_decoder
#                 del decoder  # frees the old PEFT model + all LoRA tensors
#                 if torch.cuda.is_available():
#                     torch.cuda.empty_cache()
#                 log.info("LoRA merged successfully — no warnings, no errors")
#                 return model
#             except Exception as e:
#                 log.error(f"PEFT merge failed: {e}")

#     # Fallback: manual merge (your old code) — but now it will find nothing, so skip
#     log.info("No PEFT wrapper found — skipping manual merge (already clean or not needed)")
#     return model

def _e31cf9510e1d(_441927423503, _8a3daed9957b=_1eb1ca52a992):
    if _8a3daed9957b is _1eb1ca52a992:
        _8a3daed9957b = _d5bdcce1288d._0bddc3088fb8(__name__)

    _f9162e9d7ffc = _238196d2b572(_441927423503, "module", _441927423503)

    def _10475a5fd9fc(_f53fcceaf200, _7c2fdf82fb6f):
        if _546f67745193(_f53fcceaf200, "merge_and_unload"):
            _8a3daed9957b._dc2915897a0a("Merging LoRA via PEFT merge_and_unload")
            _fee5e4a4e3b1 = _f53fcceaf200._dea504a4bfa3()
            _7c2fdf82fb6f(_fee5e4a4e3b1)
            if _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
                _fb5870f47c15._d1110d0f6b31._20ff46a0fb6b()
            _8a3daed9957b._dc2915897a0a("LoRA merged successfully")
            return _fd58f229f8e3
        return _28c5c554b16d

    # Decoder path (Lightning-safe)
    if _546f67745193(_f9162e9d7ffc, "embedding") and _546f67745193(_f9162e9d7ffc._a8056a4082cc, "model"):
        if _a9c8b8a521c7(
            _f9162e9d7ffc._a8056a4082cc._441927423503,
            lambda _7ef3a9c5cad7: _1e4324c82206(_f9162e9d7ffc._a8056a4082cc, "model", _7ef3a9c5cad7),
        ):
            return _441927423503

    # Embedding path
    if _546f67745193(_f9162e9d7ffc, "embedding"):
        if _a9c8b8a521c7(
            _f9162e9d7ffc._a8056a4082cc,
            lambda _7ef3a9c5cad7: _1e4324c82206(_f9162e9d7ffc, "embedding", _7ef3a9c5cad7),
        ):
            return _441927423503

    _8a3daed9957b._dc2915897a0a("No PEFT LoRA adapters found — nothing to merge")
    return _441927423503


def _32f4e33fad96(_441927423503: "torch.nn.Module") -> "torch.nn.Module":
    """
    Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
    Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
    Leaves LoRA and trainable modules untouched.
    Safe: skips missing weights or broken layers automatically.
    """
    import _e15a7dbd7de8
    import _fb5870f47c15
    import _6c4101b635e3 as _0fb27b6f9a6b

    _abc3b48499da = _f323bbd8f778(_441927423503._2bec8b623180())[::-1]  # bottom-up traversal

    for _9114d7f95987, _cf07d1dcfd18 in _abc3b48499da:
        if _1fbd91ba88e2(_cf07d1dcfd18, (_fb5870f47c15._ca6d5a9821a8._5d41a83850b6, _fb5870f47c15._ca6d5a9821a8._6c103bfc4ff7)):
            # Skip LoRA or trainable layers
            if "lora" in _9114d7f95987._14548be4df14() or _07241d1df407(_2d8c33bb574b._d483977a22b9 for _2d8c33bb574b in _cf07d1dcfd18._c5153882545c()):
                continue

            try:
                _132fc6729119 = "nf4" if _1fbd91ba88e2(_cf07d1dcfd18, _fb5870f47c15._ca6d5a9821a8._5d41a83850b6) else "fp4"

                _02e3ac9b6ffb = _238196d2b572(_cf07d1dcfd18, "in_features", _cf07d1dcfd18._33a49ddb5cda._31afb235181b[1])
                _1caaccb84176 = _238196d2b572(_cf07d1dcfd18, "out_features", _cf07d1dcfd18._33a49ddb5cda._31afb235181b[0])

                _ddaeb0d871e0 = _0fb27b6f9a6b._ca6d5a9821a8._bcb6a25be600(
                    _02e3ac9b6ffb, _1caaccb84176,
                    _bebe4beb9b31=_cf07d1dcfd18._bebe4beb9b31 is not _1eb1ca52a992,
                    _01e9207695c1=_9b74d612cb7b(),
                    _132fc6729119=_132fc6729119
                )

                if _cf07d1dcfd18._33a49ddb5cda is _1eb1ca52a992 or not _546f67745193(_cf07d1dcfd18._33a49ddb5cda, "data"):
                    continue

                _ddaeb0d871e0._33a49ddb5cda._5c81e5ce4e03._b3202f940147(_cf07d1dcfd18._33a49ddb5cda._5c81e5ce4e03)
                if _cf07d1dcfd18._bebe4beb9b31 is not _1eb1ca52a992:
                    _ddaeb0d871e0._bebe4beb9b31._5c81e5ce4e03._b3202f940147(_cf07d1dcfd18._bebe4beb9b31._5c81e5ce4e03)

                # Replace in parent
                _34cc37a69872 = _441927423503
                _df0b19e49c24 = _9114d7f95987._84be22a27629(".")
                for _2d8c33bb574b in _df0b19e49c24[:-1]:
                    _34cc37a69872 = _238196d2b572(_34cc37a69872, _2d8c33bb574b)
                _1e4324c82206(_34cc37a69872, _df0b19e49c24[-1], _ddaeb0d871e0)

                del _cf07d1dcfd18
                _e15a7dbd7de8._4d6ee915c13d()
                if _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
                    _fb5870f47c15._d1110d0f6b31._20ff46a0fb6b()

            except _7e6af5044a3b as _1794af0bb024:
                _ceb0df860d85(f"[WARN] Skipped quantizing {_9114d7f95987}: {_1794af0bb024}")

    return _441927423503


# def quantize_frozen_linear_layers(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Manually quantize all frozen torch.nn.Linear layers in the given model to 4-bit precision using bitsandbytes.
#     Leaves all LoRA or trainable modules untouched (those containing 'lora' in name or requiring gradients).

#     Args:
#         model (torch.nn.Module): The model instance to quantize (after LoRA is applied).

#     Returns:
#         torch.nn.Module: The same model instance with frozen Linear layers replaced by 4-bit quantized versions.
#     """
#     import bitsandbytes as bnb
#     from bitsandbytes.nn import Params4bit

#     modules = list(model.named_modules())  # snapshot to avoid OrderedDict mutation

#     for name, module in modules:
#         # Quantize only standard Linear layers that are frozen
#         if isinstance(module, torch.nn.Linear):
#             if "lora" in name.lower() or any(param.requires_grad for param in module.parameters()):
#                 continue  # skip LoRA or active trainable layers

#             # Create quantized Linear4bit replacement
#             quantized = bnb.nn.Linear4bit(
#                 module.in_features,
#                 module.out_features,
#                 bias=module.bias is not None,
#                 compute_dtype=get_supported_compute_dtype(),
#                 compress_statistics=True,
#                 quant_type="nf4"
#             )

#             # Properly quantize and assign weight
#             quantized.weight = Params4bit(
#                 module.weight.data,
#                 compress_statistics=True,
#                 quant_type="nf4",
#                 quant_storage=torch.uint8
#             )

#             # Copy bias if exists
#             if module.bias is not None:
#                 quantized.bias = module.bias.clone()

#             # Replace the original module in its parent container
#             parent = model
#             parts = name.split(".")
#             for p in parts[:-1]:
#                 parent = getattr(parent, p)
#             setattr(parent, parts[-1], quantized)

#     return model

def _e31cf9510e1d(_441927423503: "torch.nn.Module", _8a3daed9957b: "Any" = _1eb1ca52a992) -> "torch.nn.Module":
    """
    Merge LoRA adapters into base layers (robust heuristics) and then aggressively
    remove/unwrap PEFT/LoRA wrapper objects so the final model no longer reports
    "LoRA present" / "PEFT present".
    """
    if _8a3daed9957b is _1eb1ca52a992:
        _8a3daed9957b = _d5bdcce1288d._0bddc3088fb8(__name__)

    _fee5e4a4e3b1 = 0
    _f621f9e2371e = 0
    _0088856c99e1 = []

    # helper to get first tensor-like from many container types
    def _76bddf590864(_4694416eb005):
        if _4694416eb005 is _1eb1ca52a992:
            return _1eb1ca52a992
        if _1fbd91ba88e2(_4694416eb005, _fb5870f47c15._ca6d5a9821a8._478f0e90166d):
            return _4694416eb005._5c81e5ce4e03
        if _1fbd91ba88e2(_4694416eb005, _fb5870f47c15._1ac58c7c6f80):
            return _4694416eb005
        if _1fbd91ba88e2(_4694416eb005, _fb5870f47c15._ca6d5a9821a8._6ff3a2fd07a5):
            _b69a58f66889 = _238196d2b572(_4694416eb005, "weight", _1eb1ca52a992)
            if _1fbd91ba88e2(_b69a58f66889, _fb5870f47c15._ca6d5a9821a8._478f0e90166d):
                return _b69a58f66889._5c81e5ce4e03
            try:
                _2d8c33bb574b = _b467f369d2b1(_4694416eb005._c5153882545c())
                return _2d8c33bb574b._5c81e5ce4e03
            except _7e6af5044a3b:
                pass
            try:
                _29f54dcfdb49 = _b467f369d2b1(_4694416eb005._d91149631d35())
                return _29f54dcfdb49
            except _7e6af5044a3b:
                pass
            return _1eb1ca52a992
        # dict-like or ModuleDict-like: return first tensor we can
        try:
            for _0aa4dc356c36 in _238196d2b572(_4694416eb005, "values", lambda: [])():
                _84fcd0034f95 = _281e02322ac1(_0aa4dc356c36)
                if _84fcd0034f95 is not _1eb1ca52a992:
                    return _84fcd0034f95
        except _7e6af5044a3b:
            pass
        try:
            for _, _0aa4dc356c36 in _238196d2b572(_4694416eb005, "items", lambda: [])():
                _84fcd0034f95 = _281e02322ac1(_0aa4dc356c36)
                if _84fcd0034f95 is not _1eb1ca52a992:
                    return _84fcd0034f95
        except _7e6af5044a3b:
            pass
        return _1eb1ca52a992

    def _2ed766747e40(_017f6b873626: _fb5870f47c15._1ac58c7c6f80, _4e07bb65b10c: _fb5870f47c15._1ac58c7c6f80, _7eecaf9c9cea: _fb5870f47c15._1ac58c7c6f80):
        _14154833eb40 = _017f6b873626._d0e4aefb25c3()._730356a95764()
        _d181815a6079 = _4e07bb65b10c._d0e4aefb25c3()._730356a95764()
        # common 2D case
        if _14154833eb40._fc24301cd6ba() == 2 and _d181815a6079._fc24301cd6ba() == 2 and _d181815a6079._31afb235181b[1] == _14154833eb40._31afb235181b[0]:
            return _d181815a6079 @ _14154833eb40
        # try reshape inference based on base shape
        _c72bd6d68e7d = _56b12ba7f4cb(_7eecaf9c9cea._31afb235181b[0])
        _67cf8b1b3207 = _56b12ba7f4cb(_7eecaf9c9cea._31afb235181b[1]) if _7eecaf9c9cea._fc24301cd6ba() > 1 else 1
        _b1aaa66ba695 = _14154833eb40._0073930ef8f6()
        _4d0ae4d6eaf0 = _d181815a6079._0073930ef8f6()
        if _c72bd6d68e7d > 0 and _67cf8b1b3207 > 0:
            if (_4d0ae4d6eaf0 % _c72bd6d68e7d == 0):
                _bc391b1bf0d7 = _4d0ae4d6eaf0 // _c72bd6d68e7d
                if _bc391b1bf0d7 > 0 and (_b1aaa66ba695 == _bc391b1bf0d7 * _67cf8b1b3207):
                    _28b394326703 = _14154833eb40._69a1967dfc6c(_bc391b1bf0d7, _67cf8b1b3207) if _14154833eb40._fc24301cd6ba() == 1 else _14154833eb40
                    _37ae0d173b93 = _d181815a6079._69a1967dfc6c(_c72bd6d68e7d, _bc391b1bf0d7) if _d181815a6079._fc24301cd6ba() == 1 else _d181815a6079
                    if _37ae0d173b93._31afb235181b[1] == _28b394326703._31afb235181b[0]:
                        return _37ae0d173b93 @ _28b394326703
            if (_b1aaa66ba695 % _67cf8b1b3207 == 0):
                _bc391b1bf0d7 = _b1aaa66ba695 // _67cf8b1b3207
                if _bc391b1bf0d7 > 0 and (_4d0ae4d6eaf0 == _c72bd6d68e7d * _bc391b1bf0d7):
                    _28b394326703 = _14154833eb40._69a1967dfc6c(_bc391b1bf0d7, _67cf8b1b3207) if _14154833eb40._fc24301cd6ba() == 1 else _14154833eb40
                    _37ae0d173b93 = _d181815a6079._69a1967dfc6c(_c72bd6d68e7d, _bc391b1bf0d7) if _d181815a6079._fc24301cd6ba() == 1 else _d181815a6079
                    if _37ae0d173b93._31afb235181b[1] == _28b394326703._31afb235181b[0]:
                        return _37ae0d173b93 @ _28b394326703
        # fallback tries
        try:
            return _d181815a6079 @ _14154833eb40
        except _7e6af5044a3b:
            pass
        # chunked heuristics
        try:
            _28b394326703 = _14154833eb40 if _14154833eb40._fc24301cd6ba() == 2 else _14154833eb40._69a1967dfc6c(_14154833eb40._31afb235181b[0], -1)
            _37ae0d173b93 = _d181815a6079 if _d181815a6079._fc24301cd6ba() == 2 else _d181815a6079._69a1967dfc6c(-1, _d181815a6079._31afb235181b[0])
        except _7e6af5044a3b as _1794af0bb024:
            raise _2b3944116c45(f"cannot promote A/B to 2D: {_1794af0bb024}")
        _29cf4c243554 = _28b394326703._31afb235181b[0]
        _40f023cd6583 = _37ae0d173b93._31afb235181b[1]
        if _29cf4c243554 and _40f023cd6583 and (_40f023cd6583 % _29cf4c243554 == 0):
            _83fa0ffe85d9 = _40f023cd6583 // _29cf4c243554
            _c164302229ed = _37ae0d173b93._31afb235181b[0]
            _5b2f03ec6975 = _37ae0d173b93._69a1967dfc6c(_c164302229ed, _83fa0ffe85d9, _29cf4c243554)
            _2d8ae0a4447b = _1eb1ca52a992
            for _d3491f36321a in _2c7dc1e5859c(_83fa0ffe85d9):
                _900d5e42fae0 = _5b2f03ec6975[:, _d3491f36321a, :] @ _28b394326703
                _2d8ae0a4447b = _900d5e42fae0 if _2d8ae0a4447b is _1eb1ca52a992 else (_2d8ae0a4447b + _900d5e42fae0)
            return _2d8ae0a4447b
        if _29cf4c243554 and _40f023cd6583 and (_29cf4c243554 % _40f023cd6583 == 0):
            _83fa0ffe85d9 = _29cf4c243554 // _40f023cd6583
            _0259c341f232 = _28b394326703._31afb235181b[1]
            _1815321ddf42 = _28b394326703._69a1967dfc6c(_83fa0ffe85d9, _40f023cd6583, _0259c341f232)
            _2d8ae0a4447b = _1eb1ca52a992
            for _d3491f36321a in _2c7dc1e5859c(_83fa0ffe85d9):
                _900d5e42fae0 = _37ae0d173b93 @ _1815321ddf42[_d3491f36321a]
                _2d8ae0a4447b = _900d5e42fae0 if _2d8ae0a4447b is _1eb1ca52a992 else (_2d8ae0a4447b + _900d5e42fae0)
            return _2d8ae0a4447b
        raise _2b3944116c45(f"unsupported A/B shapes A={_00cff7de19ed(_017f6b873626._31afb235181b)} B={_00cff7de19ed(_4e07bb65b10c._31afb235181b)} for base {_00cff7de19ed(_7eecaf9c9cea._31afb235181b)}")

    # gather parents to allow setattr replacements
    _e7128fd18892 = []
    for _34cc37a69872 in _441927423503._abc3b48499da():
        try:
            for _4a3299351cc2, _b69500ad0e4d in _f323bbd8f778(_34cc37a69872._8f1e73366d34()):
                _e7128fd18892._62dfc8e82812((_34cc37a69872, _4a3299351cc2, _b69500ad0e4d))
        except _7e6af5044a3b:
            continue

    # --- manual merge (robust attempts) ---
    for _34cc37a69872, _4a3299351cc2, _b69500ad0e4d in _e7128fd18892:
        try:
            # identify base candidate under wrapper
            _967b7469604a = _238196d2b572(_b69500ad0e4d, "base_layer", _1eb1ca52a992) or _238196d2b572(_b69500ad0e4d, "module", _1eb1ca52a992) or _238196d2b572(_b69500ad0e4d, "model", _1eb1ca52a992)
            if _967b7469604a is _1eb1ca52a992 or not _546f67745193(_967b7469604a, "weight"):
                # if child itself is base-like with .weight, skip (nothing to merge)
                if _546f67745193(_b69500ad0e4d, "weight") and _1fbd91ba88e2(_238196d2b572(_b69500ad0e4d, "weight"), _fb5870f47c15._ca6d5a9821a8._478f0e90166d):
                    continue
                # otherwise there's nothing we can merge here
                continue

            # locate A/B containers in child or nested attrs
            _bb4ec71e974e = {}
            _466b701765b9 = {}
            _ad964f766dc9 = {}
            # candidate holders
            _773481622d75 = [_b69500ad0e4d]
            for _8f5fe3366964 in ("module", "base_layer", "lora_adapter", "adapter", "model", "base_model"):
                _0aa4dc356c36 = _238196d2b572(_b69500ad0e4d, _8f5fe3366964, _1eb1ca52a992)
                if _0aa4dc356c36 is not _1eb1ca52a992 and _0aa4dc356c36 is not _b69500ad0e4d:
                    _773481622d75._62dfc8e82812(_0aa4dc356c36)

            for _6465464ff7d0 in _773481622d75:
                if _546f67745193(_6465464ff7d0, "lora_A"):
                    _b967d1210813 = _238196d2b572(_6465464ff7d0, "lora_A")
                    if _1fbd91ba88e2(_b967d1210813, _4358b0daa422):
                        for _840ead97c0fd, _0aa4dc356c36 in _b967d1210813._c5a306e5fdc6():
                            _bb4ec71e974e[_840ead97c0fd] = _0aa4dc356c36
                    else:
                        _bb4ec71e974e["default"] = _b967d1210813
                if _546f67745193(_6465464ff7d0, "lora_B"):
                    _c60913ef4fb1 = _238196d2b572(_6465464ff7d0, "lora_B")
                    if _1fbd91ba88e2(_c60913ef4fb1, _4358b0daa422):
                        for _840ead97c0fd, _0aa4dc356c36 in _c60913ef4fb1._c5a306e5fdc6():
                            _466b701765b9[_840ead97c0fd] = _0aa4dc356c36
                    else:
                        _466b701765b9["default"] = _c60913ef4fb1
                if _546f67745193(_6465464ff7d0, "adapters") and _1fbd91ba88e2(_238196d2b572(_6465464ff7d0, "adapters"), _4358b0daa422):
                    for _840ead97c0fd, _0aa4dc356c36 in _238196d2b572(_6465464ff7d0, "adapters")._c5a306e5fdc6():
                        if _546f67745193(_0aa4dc356c36, "lora_A"):
                            _bb4ec71e974e[_840ead97c0fd] = _238196d2b572(_0aa4dc356c36, "lora_A")
                        if _546f67745193(_0aa4dc356c36, "lora_B"):
                            _466b701765b9[_840ead97c0fd] = _238196d2b572(_0aa4dc356c36, "lora_B")
                if _546f67745193(_6465464ff7d0, "lora_alpha"):
                    _ad964f766dc9["default"] = _238196d2b572(_6465464ff7d0, "lora_alpha")
                if _546f67745193(_6465464ff7d0, "alpha"):
                    # some libs store alpha under alpha
                    _ad964f766dc9["default"] = _238196d2b572(_6465464ff7d0, "alpha")

            if not _bb4ec71e974e and not _466b701765b9:
                _0088856c99e1._62dfc8e82812(f"{_34cc37a69872._917f0b408327.__name__}.{_4a3299351cc2}")
                continue

            _2b96d9b6d043 = _ec3a3fd897e2(_9530e8dd7e97(_f323bbd8f778(_bb4ec71e974e._2b96d9b6d043()) + _f323bbd8f778(_466b701765b9._2b96d9b6d043()) + ["default"]))
            _06b2901895b0 = 0
            for _840ead97c0fd in _2b96d9b6d043:
                _0b245e158312 = _bb4ec71e974e._9c05549e7554(_840ead97c0fd) or _bb4ec71e974e._9c05549e7554("default")
                _f5f26ac386cc = _466b701765b9._9c05549e7554(_840ead97c0fd) or _466b701765b9._9c05549e7554("default")
                _017f6b873626 = _281e02322ac1(_0b245e158312)
                _4e07bb65b10c = _281e02322ac1(_f5f26ac386cc)
                if _017f6b873626 is _1eb1ca52a992 or _4e07bb65b10c is _1eb1ca52a992:
                    _8a3daed9957b._cc616963c874("Skipping %s.%s key=%s (no tensor)", _34cc37a69872._917f0b408327.__name__, _4a3299351cc2, _840ead97c0fd)
                    continue
                if _017f6b873626._0073930ef8f6() == 0 or _4e07bb65b10c._0073930ef8f6() == 0:
                    _8a3daed9957b._f91ea78f1aa5("Empty/zero-dim A/B for %s.%s key=%s — replacing wrapper with base.", _34cc37a69872._917f0b408327.__name__, _4a3299351cc2, _840ead97c0fd)
                    try:
                        _1e4324c82206(_34cc37a69872, _4a3299351cc2, _967b7469604a)
                        _f621f9e2371e += 1
                    except _7e6af5044a3b as _1794af0bb024:
                        _8a3daed9957b._f91ea78f1aa5("Could not replace wrapper %s.%s: %s", _34cc37a69872._917f0b408327.__name__, _4a3299351cc2, _1794af0bb024)
                    _06b2901895b0 = 0
                    break

                try:
                    _2d8ae0a4447b = _89736451f7a6(_017f6b873626, _4e07bb65b10c, _967b7469604a._33a49ddb5cda)
                except _7e6af5044a3b as _1794af0bb024:
                    _8a3daed9957b._f91ea78f1aa5("Failed computing LoRA delta for %s.%s key=%s: %s", _34cc37a69872._917f0b408327.__name__, _4a3299351cc2, _840ead97c0fd, _1794af0bb024)
                    _2d8ae0a4447b = _1eb1ca52a992

                if _2d8ae0a4447b is _1eb1ca52a992:
                    continue

                # alpha scaling
                _798ae10de29b = _ad964f766dc9._9c05549e7554(_840ead97c0fd) or _ad964f766dc9._9c05549e7554("default")
                _27c2d3b71a4a = 1.0
                try:
                    if _798ae10de29b is not _1eb1ca52a992:
                        _0d96928cd6d4 = _730356a95764(_798ae10de29b._fa61283b3f8d()) if _1fbd91ba88e2(_798ae10de29b, _fb5870f47c15._ca6d5a9821a8._478f0e90166d) else _730356a95764(_798ae10de29b)
                        _bc391b1bf0d7 = _017f6b873626._31afb235181b[0] if _238196d2b572(_017f6b873626, "dim", lambda: 0)() > 0 else _1eb1ca52a992
                        if _bc391b1bf0d7:
                            _27c2d3b71a4a = _0d96928cd6d4 / _730356a95764(_bc391b1bf0d7)
                except _7e6af5044a3b:
                    _27c2d3b71a4a = 1.0

                # apply
                try:
                    with _fb5870f47c15._9a6ca8da46f5():
                        _967b7469604a._33a49ddb5cda._5c81e5ce4e03 = _967b7469604a._33a49ddb5cda._5c81e5ce4e03 + (_2d8ae0a4447b._01476ff72e24(_967b7469604a._33a49ddb5cda._c7fcd6a7cea2, _fb5870f47c15._8eb6ff503ea2) * _27c2d3b71a4a)._01476ff72e24(_967b7469604a._33a49ddb5cda._6a5f05e64309)
                    _fee5e4a4e3b1 += 1
                    _06b2901895b0 += 1
                    _8a3daed9957b._dc2915897a0a("Merged LoRA into %s.%s key=%s (scale=%s, delta_shape=%s)", _34cc37a69872._917f0b408327.__name__, _4a3299351cc2, _840ead97c0fd, _27c2d3b71a4a, _00cff7de19ed(_2d8ae0a4447b._31afb235181b) if _546f67745193(_2d8ae0a4447b, "shape") else ())
                except _7e6af5044a3b as _1794af0bb024:
                    _8a3daed9957b._f91ea78f1aa5("Failed applying delta into base for %s.%s key=%s: %s", _34cc37a69872._917f0b408327.__name__, _4a3299351cc2, _840ead97c0fd, _1794af0bb024)
                    continue

            # after processing keys, attempt to replace wrapper with base
            try:
                _1e4324c82206(_34cc37a69872, _4a3299351cc2, _967b7469604a)
                _f621f9e2371e += 1
            except _7e6af5044a3b as _1794af0bb024:
                _8a3daed9957b._f91ea78f1aa5("Applied deltas but failed to replace wrapper %s.%s: %s", _34cc37a69872._917f0b408327.__name__, _4a3299351cc2, _1794af0bb024)

        except _7e6af5044a3b as _1794af0bb024:
            _8a3daed9957b._f91ea78f1aa5("Unexpected failure merging %s.%s: %s", _34cc37a69872._917f0b408327.__name__, _238196d2b572(_b69500ad0e4d, "__class__", _85305f4166b8(_b69500ad0e4d)).__name__, _1794af0bb024)
            continue

    # --- FINAL CLEANUP PASS: unwrap any remaining PEFT/Lora wrappers and remove LoRA attrs ---
    def _9fb682e0cbaa(_f9162e9d7ffc):
        nonlocal _f621f9e2371e
        for _34cc37a69872 in _f323bbd8f778(_f9162e9d7ffc._abc3b48499da()):
            try:
                for _9114d7f95987, _b69500ad0e4d in _f323bbd8f778(_34cc37a69872._8f1e73366d34()):
                    try:
                        _30028b8b8c2e = _b69500ad0e4d._917f0b408327.__name__
                        # 1) If wrapper has merge_and_unload or merge_and_unload() try it
                        try:
                            if _546f67745193(_b69500ad0e4d, "merge_and_unload"):
                                try:
                                    _a63cf1339b24 = _b69500ad0e4d._dea504a4bfa3()
                                    # merge_and_unload sometimes returns a replacement module
                                    if _a63cf1339b24 is not _1eb1ca52a992 and _a63cf1339b24 is not _b69500ad0e4d:
                                        _1e4324c82206(_34cc37a69872, _9114d7f95987, _a63cf1339b24)
                                        _f621f9e2371e += 1
                                        continue
                                except _7e6af5044a3b:
                                    # ignore failing merge_and_unload
                                    pass
                            # sometimes wrapper is PeftModelForCausalLM or LoraModel
                            if "Peft" in _30028b8b8c2e or "Lora" in _30028b8b8c2e or "PeftModel" in _30028b8b8c2e:
                                _616ac9402e6b = _238196d2b572(_b69500ad0e4d, "base_model", _1eb1ca52a992) or _238196d2b572(_b69500ad0e4d, "module", _1eb1ca52a992) or _238196d2b572(_b69500ad0e4d, "model", _1eb1ca52a992)
                                if _616ac9402e6b is not _1eb1ca52a992 and _616ac9402e6b is not _b69500ad0e4d:
                                    _1e4324c82206(_34cc37a69872, _9114d7f95987, _616ac9402e6b)
                                    _f621f9e2371e += 1
                                    continue
                        except _7e6af5044a3b:
                            pass

                        # 2) Remove lora attrs if present on child (making it plain)
                        for _cf04d21c20d5 in ("lora_A", "lora_B", "lora_alpha", "adapters", "peft_config", "lora_dropout", "base_layer"):
                            if _546f67745193(_b69500ad0e4d, _cf04d21c20d5):
                                try:
                                    _0fe44b9dc1da(_b69500ad0e4d, _cf04d21c20d5)
                                except _7e6af5044a3b:
                                    try:
                                        _1e4324c82206(_b69500ad0e4d, _cf04d21c20d5, _1eb1ca52a992)
                                    except _7e6af5044a3b:
                                        pass
                        # 3) If child has nested wrappers, try to reattach its inner module
                        if _546f67745193(_b69500ad0e4d, "module") and _b69500ad0e4d is not _238196d2b572(_b69500ad0e4d, "module"):
                            try:
                                _1e4324c82206(_34cc37a69872, _9114d7f95987, _238196d2b572(_b69500ad0e4d, "module"))
                                _f621f9e2371e += 1
                                continue
                            except _7e6af5044a3b:
                                pass
                    except _7e6af5044a3b:
                        continue
            except _7e6af5044a3b:
                continue

    _a7400a36b4fc(_441927423503)

    # final parameter freezing: ensure LoRA params (if any) are not left trainable and normal params are frozen unless explicitly lora
    try:
        for _8d004ced5fec, _2d8c33bb574b in _441927423503._1147d1da7ce2():
            if "lora" in _8d004ced5fec._14548be4df14():
                _2d8c33bb574b._d483977a22b9 = _fd58f229f8e3
            else:
                _2d8c33bb574b._d483977a22b9 = _28c5c554b16d
    except _7e6af5044a3b:
        pass

    _8a3daed9957b._dc2915897a0a("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.", _fee5e4a4e3b1, _f621f9e2371e, _1d2bfb977975(_0088856c99e1))
    if _fb5870f47c15._d1110d0f6b31._ca8b29be3601():
        _fb5870f47c15._d1110d0f6b31._20ff46a0fb6b()
        _fb5870f47c15._d1110d0f6b31._f424a4c354b2()
    _e15a7dbd7de8._4d6ee915c13d()
    if _0088856c99e1:
        _8a3daed9957b._cc616963c874("Skipped modules (no A/B found): %s", _0088856c99e1[:200])
    return _441927423503

_3ab60546da6b = [
    'CustomFSDPStrategy',
    'OptunaLoggingCallback',
    'GPUUsagePruneCallback',
    'adjust_local_gpu_rank',
    'get_device_info',
    'remove_files_except',
    'load_checkpoint_with_fsdp',
    'dequantize_bnb_model',
    'manual_dequantize',
    'get_trainable_parameters',
    'get_target_modules',
    'clear_gpu_and_cpu_resources',
    'calculate_model_size_in_gb',
    'get_model_summary',
    'get_devices_for_trainer',
    'get_supported_compute_dtype',
    'is_duplicate',
    'NoDuplicateSampler',
    'gamma_for_tpe_sampler',
    'property_validation',
    'get_lora_config',
    'apply_lora_to_model',
    'merge_lora_into_base',
    'quantize_model_using_bnb',
]