# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_helper_utils.py
# @Time             : 2025-10-27 12:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _68ef575c64bf
from _397e0d2ade4c import _397e0d2ade4c, _4582a141c597
from functools import _810ca20841fc
import copy
import _5f47154b5791
from _4d1b1c7b9527 import _4d1b1c7b9527
import inspect
import json
from _c8c2cc9b9935 import _8e2fc40ae8c9
import _c8c2cc9b9935
import _23024e8d6f1a
import random
import re
import _6f19b031e4bd
import _42ac3771d355
import _c62846803f35
import sys
import threading
import time
import _a1320d2c68f7
import _612d3c31bf21
import _ed2ad7937a51
from collections import _d19ff99e457a
import os
import _3480ad57ac46 as _bd570bdccf05
from _119806b155ba import _0e7d2544fb9c
from typing import _aaa63b1d4bb0, _a9e53190d689, _16ff160b273c, _145d5c9f194d, _1980063eeb14, _3536ba24ea34
from _8b95cb154d6e import _e9efacf06318, _54a716b5faeb
from _0e2e881fe479 import _214b808524bb
import _04fee85b0dfb._6bfc5adf5ec3._63c81af4debf
import _58ff33a6fa85
from _c512e2ce8879._11da0e9ce73f import _ccc8a0ef9821
import _00e247c22632
_59d4676aa6ab = _00e247c22632._8b2a182fd222._6ad7116d3a22()
if _59d4676aa6ab:
    import _46067c4ed288 as _3dfbbd95c519
import _00e247c22632._7c5cd78421f1
import _00e247c22632._7c5cd78421f1._6c8a7b4660b6
from _00e247c22632._7c5cd78421f1._6c8a7b4660b6 import _583624e0c154, _bed5206e3cf5, _2f118ec3bca3
from _00e247c22632._7c5cd78421f1._6c8a7b4660b6._5ab3595ee711 import _c278e46b1fbe
from _00e247c22632._7c5cd78421f1._6c8a7b4660b6._5ab3595ee711 import _cf2ad47f3bf2
import _05ac695f4915 as _f83cf6b96aea
import _e8edd92ca1a8 as _1b9750059e32
from _b603aaa2c879 import _b25ef08a3090, _b460c57360da, _daa4734124f0, _948aed292421, _f7adcb5faffd
from _b603aaa2c879 import _32b885716039
import _04fee85b0dfb
from _04fee85b0dfb._3b3992e3b967 import _3a66a0b7d742
from _00e247c22632 import _8ebfa8cab825, _7dc510526aac
from _05ac695f4915 import _8a71cab1a1e1
from _05ac695f4915._eaba4d10b1b5 import _d4352e9b60b8
from _0753f45b3fdd import _d59c60d92fd4, _6891cfcc0dd9, _08180934211c
from _0753f45b3fdd import _fd3ccc44625a, _3acc4fa2f418
from _05ac695f4915._eaba4d10b1b5._a7eb43af0167 import _f24b6db24ef8
from _00e247c22632._7c5cd78421f1._6c8a7b4660b6 import _62e1bb9418bd
from _00e247c22632._7c5cd78421f1._6c8a7b4660b6 import _af189c73df91, _3909e8592a7b
from _00e247c22632._7c5cd78421f1._6c8a7b4660b6._9a2c12ed278d import _7e2254601669
from _00e247c22632._af25b220cc73 import _e7186b93fe08
from _05ac695f4915._eaba4d10b1b5._456d69146d99._45bd9986bb00 import _83fb7c9e8e81
from _5cf15002fe06._316c636c7b74._2023e768eb49._5497d9baf0d3 import _421835ccc70a
from _5cf15002fe06._316c636c7b74._2023e768eb49._08b778a81cfa import _e97308feb69b


# Helper functions/classes extracted from original module
# class CustomFSDPStrategy(FSDPStrategy):
#     def __init__(self, ig_params, ig_modules=None):
#         super().__init__(sharding_strategy="FULL_SHARD",
#                          cpu_offload=CPUOffload(offload_params=False),  # Explicit CPU offload  # Move non-trainable parameters to CPU
#                         #  mixed_precision=MixedPrecision(param_dtype=torch.float16,   # Use bfloat16 for parameters
#                         #                                 reduce_dtype=torch.float16,   # Keep reduction in float32 for stability
#                         #                                 buffer_dtype=torch.float16,  # Buffers in bfloat16
#                         #                                 ),
#                          auto_wrap_policy="TRANSFORMER_BASED_WRAP",  # Auto-wrap transformer layers
#                         #  auto_wrap_policy=transformer_auto_wrap_policy,
#                         #  auto_wrap_policy=custom_wrap_policy(min_num_params=100_000),
#                         #  state_dict_type="sharded" if torch.cuda.device_count() > 1 else "full",
#                         **{"static_graph": False, # Lightning optimization hint
#                            "forward_prefetch": False # Helps overlap compute/comm
#                         }
#                         )
#         # self.cpu_offload = False
#         # fsdp_args = {"use_orig_params": True, "ignored_parameters": ig_params}
#         # fsdp_args = {"use_orig_params": True, "ignored_states": ig_params}
#         fsdp_args = {
#             "use_orig_params": True,  # Maintain original parameter references
#             "ignored_states": ig_params,  # Ignore specific states (if defined)
#         }
#         if ig_modules:
#             fsdp_args.update({"ignored_modules": ig_modules})
#         self.kwargs = fsdp_args
# # class CustomFSDPStrategy(FSDPStrategy):
# #     def __init__(self, ig_params, ig_modules=None):
# #         super().__init__(
# #             sharding_strategy="FULL_SHARD",
# #             cpu_offload=None,  # Turn CPU offload OFF for speed on PCIe
# #             mixed_precision=MixedPrecision(
# #                 param_dtype=torch.bfloat16,
# #                 reduce_dtype=torch.bfloat16,
# #                 buffer_dtype=torch.bfloat16,
# #             ),
# #             auto_wrap_policy="TRANSFORMER_BASED_WRAP",
# #             forward_prefetch=True,  # Overlap comm and compute
# #         )
# #         fsdp_args = {
# #             "use_orig_params": True,
# #             "ignored_states": ig_params,
# #         }
# #         if ig_modules:
# #             fsdp_args["ignored_modules"] = ig_modules
# #         self.kwargs = fsdp_args

#     @property
#     def lightning_restore_optimizer(self) -> bool:
#         """Override to disable Lightning restoring optimizers/schedulers.

#         This is useful for plugins which manage restoring optimizers/schedulers.
#         """
#         return False

#     def lightning_module_state_dict(self) -> Dict[str, Any]:
#         assert self.model is not None

#         with FullyShardedDataParallel.state_dict_type(
#                 module=self.model,
#                 state_dict_type=StateDictType.FULL_STATE_DICT,
#                 state_dict_config=FullStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#                 optim_state_dict_config=FullOptimStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
#         ):
#             # state_dict = self.model.state_dict()
#             state_dict = OrderedDict([(k.replace("_forward_module.",""), v) if k.__contains__('_forward_module') else (k, v)
#                                       for k, v in self.model.state_dict().items()])

#             # for key in state_dict:
#             #     print(f"state dict {key} :: {state_dict[key].shape}")
#             return state_dict

#     def setup_module(self, module: torch.nn.Module) -> torch.nn.Module:
#         """Override setup to ensure reshard_after_forward is set for all FSDP-wrapped submodules."""
#         module = super().setup_module(module)

#         for m in module.modules():
#             if isinstance(m, FullyShardedDataParallel):
#                 m._reshard_after_forward = True
#                 m._use_sharded_views = False  # optional, helps release memory immediately

#         return module

#     def optimizer_state(self, optimizer: Optimizer) -> Dict[str, Tensor]:
#         # old return FullyShardedDataParallel.full_optim_state_dict(self.model, optim=optimizer, rank0_only=True)
#         """ Manually gathers the full optimizer state across all ranks in FullyShardedDataParallel. """
#         # Get local (sharded) optimizer state using FullyShardedDataParallel
#         optim_state = FullyShardedDataParallel.optim_state_dict(self.model, optim=optimizer)

#         if torch.distributed.is_initialized():
#             # Gather optimizer states from all ranks
#             full_optim_state = [None] * torch.distributed.get_world_size()
#             torch.distributed.all_gather_object(full_optim_state, optim_state)

#             if torch.distributed.get_rank() == 0:
#                 # Merge optimizer states into a full dictionary
#                 merged_state = {"state": {}, "param_groups": full_optim_state[0]["param_groups"]}

#                 for state in full_optim_state:
#                     for param_id, param_state in state["state"].items():
#                         if param_id not in merged_state["state"]:
#                             merged_state["state"][param_id] = param_state
#                         else:
#                             # Merge optimizer state parameters (e.g., momentum buffers)
#                             for key in param_state:
#                                 if isinstance(param_state[key], list):
#                                     merged_state["state"][param_id][key].extend(param_state[key])
#                                 else:
#                                     merged_state["state"][param_id][key] = param_state[key]  # Overwrite

#                 return merged_state  # Full optimizer state for checkpointing
#             else:
#                 return {}  # Empty dictionary for non-rank 0
#         else:
#             return optim_state  # Single-process training, return directly


class _c1782cf35489(_f24b6db24ef8):
    """
    Unified FSDP strategy for BERT-family and LLaMA-family models.
    Skips FSDP wrapping of BNB 4bit/8bit layers to avoid FP32 shard bloat.
    """

    def _2b5b43b4fa73(self, _60b3586d3b8d=_b876a71f50d0, _a877d1c27b33=_b876a71f50d0, _a7a8537f4df3: _c4692100770c = "", _a5be9844da95: _96983f251f49 = _5391a231e8c1):
        from _00e247c22632._7c5cd78421f1._6c8a7b4660b6._5ab3595ee711 import _c278e46b1fbe
        from functools import _810ca20841fc

        # --- Detect model family ---
        _3595ddd878da = _a7a8537f4df3._55fb8a49e0c5()
        if _4cdec87f57ce(_14341d9c5b92 in _3595ddd878da for _14341d9c5b92 in ["llama", "mistral"]):
            try:
                from _0753f45b3fdd._1550047fe5bf._c654defa2469._92cb15136a03 import _464af2d4b8da
                from _0753f45b3fdd._1550047fe5bf._7d091cd4e4ab._2b3eef6c504a import _26882ae4e26e
                _dad207406611 = (_464af2d4b8da, _26882ae4e26e)
            except _ef4342e2a44a:
                _dad207406611 = ()
        else:
            try:
                from _0753f45b3fdd._1550047fe5bf._0df016cf88b4._7d52657a8684 import _4d888932b5bf
                from _0753f45b3fdd._1550047fe5bf._0d753b203cfb._7e003bf4b78c import _9e647c13038b
                from _0753f45b3fdd._1550047fe5bf._01450c939d77._414cab6b4639 import _5796c1033b16
                from _0753f45b3fdd._1550047fe5bf._8cf773c07e8f._ba4d8d82f596 import _be6c900d74a3
                from _0753f45b3fdd._1550047fe5bf._013d13d02f15._c6e64451ac8a import _ddf7e9127030 as _8536014b2d97
                _dad207406611 = (_4d888932b5bf, _9e647c13038b, _5796c1033b16, _be6c900d74a3, _8536014b2d97)
            except _ef4342e2a44a:
                _dad207406611 = ()

        # # --- Auto-wrap policy ---
        # if not layer_cls:
        #     print(f"[WARN] Could not infer transformer layer class for {model_name}. FSDP will wrap nothing.")
        #     auto_wrap_policy = None
        # else:
        #     auto_wrap_policy = partial(transformer_auto_wrap_policy, transformer_layer_cls=layer_cls)

        # # --- Skip BNB 4bit/8bit layers from FSDP wrapping ---
        # if auto_wrap_policy is not None:
        #     try:
        #         from bitsandbytes.nn import Linear4bit, Linear8bitLt
        #         def _bnb_filter(module):
        #             return not isinstance(module, (Linear4bit, Linear8bitLt))
        #         original_policy = auto_wrap_policy
        #         auto_wrap_policy = lambda m: original_policy(m) and _bnb_filter(m)
        #     except Exception as e:
        #         print(f"[WARN] Could not import BNB layers for FSDP filter: {e}")
    
        def _1f0dd97a78b4(_f4e9d93eb1f8):
            return _f4e9d93eb1f8._2384cc3c79d8 if _4c094ac0ff32(_f4e9d93eb1f8, "module") else _f4e9d93eb1f8

        if not _dad207406611:
            _1ce48d625e58(f"[WARN] Could not infer transformer layer class for {_a7a8537f4df3}. FSDP will wrap nothing.")
            _7f97c0fd0807 = _b876a71f50d0
        else:
            # base policy: match actual transformer layers
            def _12f2c67a316c(_f4e9d93eb1f8):
                _7b96e3a0eaf1 = _cfbc4c3aaa4b(_f4e9d93eb1f8)
                return _7d468eab525d(_7b96e3a0eaf1, _dad207406611)

            # add BNB skip
            try:
                from _46067c4ed288._18bb3a400db6 import _ea0729e3a7cc, _4fcc5d6b62f3

                def _f2aca636206a(_f4e9d93eb1f8):
                    _7b96e3a0eaf1 = _cfbc4c3aaa4b(_f4e9d93eb1f8)
                    return not _7d468eab525d(_7b96e3a0eaf1, (_ea0729e3a7cc, _4fcc5d6b62f3))
            except _ef4342e2a44a:
                def _f2aca636206a(_f4e9d93eb1f8):
                    return _e683ba20d11f

            # final combined policy
            def _afbf50f1a427(_f4e9d93eb1f8):
                return _85bdc8f80698(_f4e9d93eb1f8) and _a4a464ee784d(_f4e9d93eb1f8)

        _c0f6c00582c3()._6c916315e8b6(
            # sharding_strategy="FULL_SHARD" if is_training else "NO_SHARD", # NO_SHARD DECPRICATED
            _e502756285b6="FULL_SHARD",
            _b40da150434e=_583624e0c154(_9cb2b02256c7=_e683ba20d11f) if _a5be9844da95 else _5391a231e8c1,
            _7f97c0fd0807=_7f97c0fd0807,
            _1a160ce30cec=_e683ba20d11f,
            _022a159587b9=_5391a231e8c1,  # Safe for dynamic LoRA + quantized
        )

        # FSDP kwargs
        _0d85409593b5 = {
            "use_orig_params": _e683ba20d11f,
            "ignored_states": _60b3586d3b8d,
        }
        if _a877d1c27b33:
            _0d85409593b5["ignored_modules"] = _a877d1c27b33
        self._d8a04e01e9bf = _0d85409593b5

    @_611686141537
    def _e6ca615a3d97(self) -> _96983f251f49:
        return _5391a231e8c1

    def _6dba530f4c05(self, _2384cc3c79d8: _00e247c22632._18bb3a400db6._e72fe0f4642c) -> _00e247c22632._18bb3a400db6._e72fe0f4642c:
        _2384cc3c79d8 = _c0f6c00582c3()._3e719270ec72(_2384cc3c79d8)
        for _b0c20907d06e in _2384cc3c79d8._adbee513002b():
            if _7d468eab525d(_b0c20907d06e, _62e1bb9418bd):
                _b0c20907d06e._9850849a4594 = _e683ba20d11f
                _b0c20907d06e._807ceb2152e0 = _5391a231e8c1
        return _2384cc3c79d8

    def _860f3519604e(self) -> _a9e53190d689[_c4692100770c, _aaa63b1d4bb0]:
        assert self._44f54f98fdc7 is not _b876a71f50d0
        with _62e1bb9418bd._969cb777d44c(
            _2384cc3c79d8=self._44f54f98fdc7,
            _969cb777d44c=_af189c73df91._05bf8109cfb6,
            _4e45257764bb=_3909e8592a7b(_9751e2713b37=(self._93498a5e4a4e > 1), _22f7bdd010b9=_e683ba20d11f),
            _d765deef9b51=_7e2254601669(_9751e2713b37=(self._93498a5e4a4e > 1), _22f7bdd010b9=_e683ba20d11f),
        ):
            _19d3dbb8bdd5 = _d19ff99e457a([
                (_e769648ad51b._7741041f59ea("_forward_module.", ""), _6e7364d94da7) if "_forward_module" in _e769648ad51b else (_e769648ad51b, _6e7364d94da7)
                for _e769648ad51b, _6e7364d94da7 in self._44f54f98fdc7._19d3dbb8bdd5()._b992948b5171()
            ])
            return _19d3dbb8bdd5

    def _4b8f7881227d(self, _27dbb8d971c7: _e7186b93fe08) -> _a9e53190d689[_c4692100770c, _00e247c22632._8ebfa8cab825]:
        _0810531d1c32 = _62e1bb9418bd._1102840fad2f(self._44f54f98fdc7, _af25b220cc73=_27dbb8d971c7)
        if _00e247c22632._7c5cd78421f1._39e19c423dff():
            _6041fc2ea3df = [_b876a71f50d0] * _00e247c22632._7c5cd78421f1._672c6fefcc49()
            _00e247c22632._7c5cd78421f1._c4f073b71bdd(_6041fc2ea3df, _0810531d1c32)
            if _00e247c22632._7c5cd78421f1._63d4d6d6e87d() == 0:
                _1ef8d01a7437 = {"state": {}, "param_groups": _6041fc2ea3df[0]["param_groups"]}
                for _8a9ff6c49170 in _6041fc2ea3df:
                    for _8ce3c05f9399, _d238505368a5 in _8a9ff6c49170["state"]._b992948b5171():
                        if _8ce3c05f9399 not in _1ef8d01a7437["state"]:
                            _1ef8d01a7437["state"][_8ce3c05f9399] = _d238505368a5
                        else:
                            for _e769648ad51b, _6e7364d94da7 in _d238505368a5._b992948b5171():
                                if _7d468eab525d(_6e7364d94da7, _d8fb8268e714):
                                    _1ef8d01a7437["state"][_8ce3c05f9399][_e769648ad51b]._9b7f3e8be319(_6e7364d94da7)
                                else:
                                    _1ef8d01a7437["state"][_8ce3c05f9399][_e769648ad51b] = _6e7364d94da7
                return _1ef8d01a7437
            else:
                return {}
        else:
            return _0810531d1c32
        
class _b9888042d347(_f83cf6b96aea._8d1411263937):
    """Lightning callback that writes trial number to trainer.callback_metrics.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance.

    Behavior:
        On training start it will attempt to add a "trial_number" entry to the
        trainer.callback_metrics mapping. This is best-effort and will not raise
        if metrics are not writable.
    """

    def _2b5b43b4fa73(self, _3b3992e3b967: _04fee85b0dfb._3b3992e3b967._b349cfd43892):
        self._3b3992e3b967 = _3b3992e3b967

    def _5409b10e138c(self, _20d17c9b3cc8: _f83cf6b96aea._8a71cab1a1e1, _6a040e9322e5: _f83cf6b96aea._ac9cb5a801d6):
        # Add custom key-value pair
        _20d17c9b3cc8._5da390d415d5["trial_number"] = _7dc510526aac(self._3b3992e3b967._b90feca813f8)


class _00807eb61bac(_f83cf6b96aea._8d1411263937):
    """Callback that monitors GPU usage and prunes an Optuna trial when usage is high.

    Args:
        trial (optuna.trial.Trial): Optuna trial object to prune.
        threshold (float): Fraction of GPU memory usage above which pruning should occur.

    Notes:
        - This callback is conservative: if CUDA is not available it is a no-op.
        - In distributed training it uses a broadcast so all ranks agree.
    """

    def _2b5b43b4fa73(self, _3b3992e3b967, _152c3406719c=0.90):
        """
        Args:
            trial (optuna.trial.Trial): Optuna trial object to prune.
            threshold (float): Fraction of GPU memory usage to trigger pruning.
        """
        self._3b3992e3b967 = _3b3992e3b967
        self._152c3406719c = _152c3406719c

    def _c6f9d86535ab(self, _20d17c9b3cc8):
        """Return True if GPU reserved memory fraction >= threshold.

        Args:
            trainer: Lightning trainer object. Required for `is_global_zero` check.

        Returns:
            bool: True if usage >= threshold, False otherwise.

        Raises:
            None
        """
        # Only rank 0 checks and decides
        if not _00e247c22632._8b2a182fd222._6ad7116d3a22():
            return _5391a231e8c1

        if _20d17c9b3cc8._496c8ecba4ea:
            for _b037bcc4c237 in _167b45c629f6(_00e247c22632._8b2a182fd222._64e97a1fa566()):
                _2b61f29c94a6 = _00e247c22632._8b2a182fd222._611c4662c6e6(_b037bcc4c237)._9b8ce15f9513
                _6fde8e324b1e = _00e247c22632._8b2a182fd222._e0a81433badf(_b037bcc4c237)
                _86d79ed8eb5f = _6fde8e324b1e / _2b61f29c94a6

                if _86d79ed8eb5f >= self._152c3406719c:
                    _1ce48d625e58(f"[GPU Monitor] GPU {_b037bcc4c237} usage excceded: {_86d79ed8eb5f*100:.1f}%")
                    return _e683ba20d11f
        return _5391a231e8c1

    def _0569743e3705(self, _7132cebc0dfc):
        """Broadcast the boolean prune decision to all ranks.

        Args:
            flag (bool): Local prune decision.

        Returns:
            bool: Agreed prune decision across ranks.

        Raises:
            RuntimeError: If CUDA is expected but not available on broadcast.
        """
        if not _00e247c22632._8b2a182fd222._6ad7116d3a22():
            # Nothing to broadcast; return local decision
            return _7132cebc0dfc
        _e0e1754591c9 = _00e247c22632._7dc510526aac([_2a2f511f2602(_7132cebc0dfc)], _dff7d7afed3b='cuda')
        if _00e247c22632._7c5cd78421f1._39e19c423dff():
            _00e247c22632._7c5cd78421f1._cc1aaa5ce75d(_e0e1754591c9, _6099dce78c26=0)
        return _e0e1754591c9._87817d8802cd() == 1

    def _1e9336850bb9(self, _20d17c9b3cc8, _6a040e9322e5, _b034b3c023f0, _329aa3515ebb, _32358b65919e=0):
        """Lightning hook executed at start of each training batch.

        Raises:
            optuna.TrialPruned: when GPU usage threshold is exceeded.
        """
        if not _59d4676aa6ab:
            return  # for cpu alone
        _51addd31d3e0 = self._e6e8ba44313a(_20d17c9b3cc8)
        # Broadcast decision so all ranks agree
        _51addd31d3e0 = self._a8de05250945(_51addd31d3e0)

        if _51addd31d3e0:
            if _20d17c9b3cc8._496c8ecba4ea:
                _1ce48d625e58("[GPUUsagePruneCallback] GPU memory exceeded threshold. Pruning trial.")
            raise _04fee85b0dfb._03266d17a80a("GPU memory exceeded threshold")


def _803af26375b2() -> _2a2f511f2602:
    """Compute local GPU rank based on environment variables.

    The function inspects `CUDA_VISIBLE_DEVICES`, `LOCAL_RANK` and `RANK` and
    returns an integer representing the local GPU index.

    Returns:
        int: local GPU rank (0-based). Returns -1 when CUDA is not available.

    Raises:
        ValueError: if computed local_rank is out of bounds for visible GPUs.
    """
    if not _00e247c22632._8b2a182fd222._6ad7116d3a22():
        _1ce48d625e58("[adjust_local_gpu_rank] CUDA not available, using CPU (-1)", _b0ee1261a7c9=_e683ba20d11f)
        return -1  # CPU fallback

    _026d3bd2e97b = os._b398d1c8b26f._4add7fcb188b("CUDA_VISIBLE_DEVICES", "")
    if _026d3bd2e97b == "":
        # No filtering: all GPUs visible
        _9cb4eb8452d1 = [_c4692100770c(_b516ce173392) for _b516ce173392 in _167b45c629f6(_00e247c22632._8b2a182fd222._64e97a1fa566())]
    else:
        # For MIG UUIDs or indices, keep as string list (don't cast to int)
        _9cb4eb8452d1 = [_14341d9c5b92._0c14bfc3bec4() for _14341d9c5b92 in _026d3bd2e97b._99badefb3614(",") if _14341d9c5b92._0c14bfc3bec4() != ""]

    _52a1e43d2711 = os._b398d1c8b26f._4add7fcb188b("LOCAL_RANK")
    _f6ae7514f8a9 = os._b398d1c8b26f._4add7fcb188b("RANK")

    if _52a1e43d2711 is not _b876a71f50d0:
        _043c3124e442 = _2a2f511f2602(_52a1e43d2711)
        _1ce48d625e58(f"[adjust_local_gpu_rank] Using LOCAL_RANK={_043c3124e442}", _b0ee1261a7c9=_e683ba20d11f)
    elif _f6ae7514f8a9 is not _b876a71f50d0:
        _043c3124e442 = _2a2f511f2602(_f6ae7514f8a9)
        _1ce48d625e58(f"[adjust_local_gpu_rank] LOCAL_RANK not set, using RANK={_043c3124e442}", _b0ee1261a7c9=_e683ba20d11f)
    else:
        _043c3124e442 = 0
        _1ce48d625e58("[adjust_local_gpu_rank] LOCAL_RANK and RANK not set, defaulting to 0", _b0ee1261a7c9=_e683ba20d11f)

    if _043c3124e442 >= _766c177734a2(_9cb4eb8452d1):
        raise _b47caaec66d3(
            f"[adjust_local_gpu_rank] local_rank ({_043c3124e442}) >= number of visible GPUs ({_766c177734a2(_9cb4eb8452d1)}).")

    # Returning integer index for compatibility with how calling code uses it.
    _07e202c60e74 = _043c3124e442
    _1ce48d625e58(f"[adjust_local_gpu_rank] CUDA_VISIBLE_DEVICES={_9cb4eb8452d1}, selected device={_07e202c60e74}", _b0ee1261a7c9=_e683ba20d11f)

    return _07e202c60e74


def _d254fb0c3ce6() -> _61e6551336e1:
    """Collect basic device and host information for logging.

    Returns:
        dict: keys include 'gpu_world_size', 'gpu_global_rank', 'gpu_local_rank',
              'node_name', and 'cpu_info'.

    Notes:
        - If CUDA is unavailable and SLURM is not detected, gpu_* keys are populated with -1.
    """
    _2df465efdafc = _61e6551336e1()
    if _00e247c22632._8b2a182fd222._6ad7116d3a22():
        _2df465efdafc['gpu_world_size'] = _c4692100770c(os._b398d1c8b26f._4add7fcb188b('WORLD_SIZE', '1'))  # get WORLD_SIZE or set default 1
        _2df465efdafc['gpu_global_rank'] = _c4692100770c(os._b398d1c8b26f._4add7fcb188b('RANK', '0'))
        _2df465efdafc['gpu_local_rank'] = _c4692100770c(_04a5768f0d26())
    elif _83fb7c9e8e81._04f7ec10db8d() and _00e247c22632._8b2a182fd222._6ad7116d3a22() is _5391a231e8c1:
        _2df465efdafc['gpu_world_size'] = _c4692100770c(_83fb7c9e8e81._93498a5e4a4e(_f83cf6b96aea))
        _2df465efdafc['gpu_global_rank'] = _c4692100770c(_83fb7c9e8e81._bcaa5e76c303(_f83cf6b96aea))
        _2df465efdafc['gpu_local_rank'] = -1
    else:
        _2df465efdafc['gpu_world_size'] = -1
        _2df465efdafc['gpu_global_rank'] = -1
        _2df465efdafc['gpu_local_rank'] = -1
    _2df465efdafc['node_name'] = _42ac3771d355._7455f64b3a49()
    try:
        _2df465efdafc['cpu_info'] = "CPU :: {} COUNT :: {}"._93b7664bb390(_612d3c31bf21._b5ae1ca7478c()['brand_raw'], os._946665297486())
    except _ef4342e2a44a:
        _2df465efdafc['cpu_info'] = f"CPU COUNT :: {os._946665297486()}"
    return _2df465efdafc


def _b8f44f0b355f(_f7ea46ee66b6: _c4692100770c, _0ee120757546: _c4692100770c, _42f22744a6db: _8e2fc40ae8c9):
    """Remove all files in a directory except a single filename to keep.

    Args:
        directory (str): Directory to clean.
        file_to_keep (str): Basename of file to retain.
        log (Logger): Logger instance for informational messages.

    Raises:
        FileNotFoundError: If `directory` does not exist.
        PermissionError: If file removal fails due to permissions (propagates underlying OSError).
    """
    if not os._067225377de6._c3b43178141a(_f7ea46ee66b6):
        raise _ade05f7ab0d8(f"Directory not found: {_f7ea46ee66b6}")

    for _d78aa519a0e4 in os._5e0114e3dc8c(_f7ea46ee66b6):
        _43b0f6a3ac08 = os._067225377de6._d1a5278f6d6c(_f7ea46ee66b6, _d78aa519a0e4)
        if os._067225377de6._baec619d90a6(_43b0f6a3ac08) and _d78aa519a0e4 != _0ee120757546:
            _42f22744a6db._00afa095dbb3(f"Removing checkpoint: {_43b0f6a3ac08}")
            os._1380f0e27271(_43b0f6a3ac08)


def _f9c92af0242e(_42f22744a6db: _8e2fc40ae8c9, _f1578885d884: _c4692100770c, _562bb4670d7d: _04fee85b0dfb._354e8c82e89e, _3b3992e3b967: _04fee85b0dfb._3b3992e3b967._b349cfd43892):
    """Clear outdated checkpoint directories for the given model config.

    Args:
        log (Logger): Logger instance.
        model_config_name (str): Model configuration name used to build checkpoint root path.
        study (optuna.Study): Optuna study object (kept in signature for compatibility).
        trial (optuna.trial.Trial): Current trial; its number is preserved.

    Notes:
        - This function removes directories for older trials (non-current).
        - It will not raise if directories are missing; failures to remove are logged.
    """
    _febc062c27ae = f"checkpoints/{_f1578885d884}/trial_{_3b3992e3b967._b90feca813f8}"
    _97f238257829 = f"{_febc062c27ae}/last-v{_3b3992e3b967._b90feca813f8}.ckpt"

    # If the directory is empty, we can remove it
    if os._067225377de6._c3b43178141a(_febc062c27ae):
        if not os._5e0114e3dc8c(_febc062c27ae):  # Check if empty
            try:
                os._de46eebf4490(_febc062c27ae)  # Remove only if empty
                _42f22744a6db._00afa095dbb3(f"Removed empty directory: {_febc062c27ae}")
            except _ef4342e2a44a:
                _42f22744a6db._ece658208ea0(f"Failed to remove directory: {_febc062c27ae}")
        else:
            # Check if the directory does not belong to the current trial and remove it
            _20d1eb2d7240 = f"checkpoints/{_f1578885d884}"
            if os._067225377de6._c3b43178141a(_20d1eb2d7240):
                _4856d91bba13 = os._5e0114e3dc8c(_20d1eb2d7240)
                for _d3555a1d6a02 in _4856d91bba13:
                    _a0f360629c09 = re._a0f360629c09(r"trial_(\d+)", _d3555a1d6a02)
                    if _a0f360629c09:
                        _000bcc1afa6a = _2a2f511f2602(_a0f360629c09._dd7b514ff3a3(1))
                        if _000bcc1afa6a != _3b3992e3b967._b90feca813f8:
                            _76f6c2766a6c = f"{_20d1eb2d7240}/{_d3555a1d6a02}"
                            if os._067225377de6._b8bb97a70001(_76f6c2766a6c):
                                try:
                                    _42f22744a6db._00afa095dbb3(f"Removing outdated trial directory: {_76f6c2766a6c}")
                                    _6f19b031e4bd._65990d30a180(_76f6c2766a6c)
                                except _ef4342e2a44a:
                                    _42f22744a6db._ece658208ea0(f"Failed to remove dir {_76f6c2766a6c}")


def _75ed88d72312(_44f54f98fdc7, _158c4cc8e4b5, _d975534f128a):
    """Load a checkpoint into the original (unwrapped) model when FSDP was used.

    Args:
        model: Original (unwrapped) model instance (kept for signature compatibility).
        fsdp_model: FSDP-wrapped model instance that contains `.module`.
        checkpoint_path (str): Path to checkpoint file.

    Returns:
        torch.nn.Module: original model with loaded state dict.

    Raises:
        FileNotFoundError: If the checkpoint file does not exist.
        AttributeError: If `fsdp_model` does not expose `.module`.
        RuntimeError: If loading state dict fails.
    """
    if not os._067225377de6._b8bb97a70001(_d975534f128a):
        raise _ade05f7ab0d8(f"Checkpoint not found: {_d975534f128a}")

    # Access the original model (best-effort)
    if not _4c094ac0ff32(_158c4cc8e4b5, "module"):
        raise _e1c444a8a0b9("fsdp_model does not expose .module (not an FSDP-wrapped model)")

    _dd4164b3e4d7 = _158c4cc8e4b5._2384cc3c79d8

    # Load the checkpoint
    _f356e930b6ad = _00e247c22632._a87503fed9b3(_d975534f128a)

    # Attempt to load state dict into original model
    try:
        # Note: original script used FSDP full-state helpers; preserve call but guard errors
        with _00e247c22632._7c5cd78421f1._6c8a7b4660b6._3909e8592a7b(_158c4cc8e4b5):
            _dd4164b3e4d7._ee1a4b768ef6(_f356e930b6ad, _85fa42d074c6=_e683ba20d11f)
    except _ef4342e2a44a:
        # Try fallback strict=False
        try:
            _dd4164b3e4d7._ee1a4b768ef6(_f356e930b6ad, _85fa42d074c6=_5391a231e8c1)
        except _ef4342e2a44a as _0e61792e875a:
            raise _27943ad7dfc8(f"Failed to load checkpoint into original model: {_0e61792e875a}") from _0e61792e875a
    return _dd4164b3e4d7

# def dequantize_bnb_model(model):
#     """
#     Replace bitsandbytes quantized linear layers in a model with standard torch.nn.Linear layers.

#     This function traverses the given model and converts all quantized linear
#     layers (Linear4bit, Linear8bitLt) into torch.nn.Linear equivalents with
#     dequantized float32 weights and bias. The conversion is done in-place.

#     Args:
#         model (torch.nn.Module):
#             Model instance that may contain bitsandbytes quantized linear layers.

#     Returns:
#         torch.nn.Module:
#             The same model with quantized linear layers replaced by dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If layer weights or bias cannot be converted to float32 or fail to copy into a new layer.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for module in list(model.modules()):
#         for name, child in list(module.named_children()):
#             if getattr(child, "_is_dequantized", False):
#                 continue
#             if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#                 try:
#                     try:
#                         w = child.weight.dequantize()
#                     except Exception:
#                         w = child.weight.data.to(torch.float32)
#                     b = None
#                     if getattr(child, "bias", None) is not None:
#                         b = child.bias.data.to(torch.float32)
#                     out_f, in_f = w.shape
#                     new_linear = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                     new_linear.weight.data.copy_(w)
#                     if b is not None:
#                         new_linear.bias.data.copy_(b)
#                     new_linear._is_dequantized = True
#                     setattr(module, name, new_linear)
#                 except Exception as e:
#                     raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#     return model


# def manual_dequantize(module):
#     """
#     Recursively replace bitsandbytes quantized linear layers in a module with torch.nn.Linear layers.

#     This function walks all children of the given module recursively and converts
#     quantized linear layers (Linear4bit, Linear8bitLt) to standard torch.nn.Linear
#     layers containing float32 weights and bias. Layers already marked as
#     dequantized are skipped.

#     Args:
#         module (torch.nn.Module):
#             Root module or submodule to process recursively.

#     Returns:
#         torch.nn.Module:
#             The same module with all quantized linear layers replaced by
#             dequantized torch.nn.Linear layers.

#     Raises:
#         RuntimeError:
#             If a quantized layer fails to convert or copy its weights to float32.
#     """
#     try:
#         import bitsandbytes as bnb
#         quant_classes = (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)
#     except Exception:
#         quant_classes = ()

#     for name, child in list(module.named_children()):
#         if getattr(child, "_is_dequantized", False):
#             continue
#         if isinstance(child, quant_classes) or child.__class__.__name__ in ("Linear4bit", "Linear8bitLt"):
#             try:
#                 try:
#                     w = child.weight.dequantize()
#                 except Exception:
#                     w = child.weight.data.to(torch.float32)
#                 b = None
#                 if getattr(child, "bias", None) is not None:
#                     b = child.bias.data.to(torch.float32)
#                 out_f, in_f = w.shape
#                 new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None)
#                 new_layer.weight.data.copy_(w)
#                 if b is not None:
#                     new_layer.bias.data.copy_(b)
#                 new_layer._is_dequantized = True
#                 setattr(module, name, new_layer)
#             except Exception as e:
#                 raise RuntimeError(f"Failed to dequantize layer '{name}': {e}")
#         else:
#             manual_dequantize(child)
#     return module

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32) — no CPU moves, preserves device, removes ALL quantized layers.
#     Works even under PEFT, _SafeModuleWrapper, PeftModel, LoraModel, etc.

#     Bulletproof: detection by class name, not isinstance.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",        # some bnb builds use this
#     }

#     # Traverse parents so we can do setattr
#     for parent in list(model.modules()):
#         # Use raw _modules dict so we replace correct child
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # Skip non-BnB quantized layers
#             if cls not in QUANT_CLASS_NAMES:
#                 # Check nested wrapper: _SafeModuleWrapper, etc.
#                 inner = getattr(child, "module", None)
#                 if inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                     child = inner
#                     cls = child.__class__.__name__
#                 else:
#                     continue

#             # --------------------------------------------------------
#             # At this point, child is DEFINITELY a quantized Linear*
#             # --------------------------------------------------------

#             # Device
#             try:
#                 device = next(child.parameters()).device
#             except StopIteration:
#                 device = torch.device("cpu")

#             # ---- read weight ----
#             if hasattr(child, "weight") and hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---- read bias ----
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---- infer dims ----
#             # out_f, in_f = w.shape
#             # If weight is 1-D (flattened), infer dims from child attributes
#             if w.dim() == 1:
#                 out_f = child.out_features
#                 in_f = child.in_features
#             else:
#                 out_f, in_f = w.shape

#             # ---- create replacement ----
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---- REPLACE ----
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model):
#     """
#     Replace ALL bitsandbytes quantized linear layers (Linear4bit, Linear8bitLt, Linear8bit, LinearNF4)
#     with torch.nn.Linear(fp32). Preserves device. Never reshapes incorrectly.
#     """
#     import torch

#     QUANT_CLASS_NAMES = {
#         "Linear4bit",
#         "Linear8bitLt",
#         "Linear8bit",
#         "LinearNF4",
#         "QuantLinear",
#     }

#     for parent in list(model.modules()):
#         for name, child in list(parent._modules.items()):

#             if child is None:
#                 continue

#             cls = child.__class__.__name__

#             # ---------- WRAPPER DETECTION ----------
#             wrapper = child                     # always keep wrapper
#             inner = getattr(child, "module", None)
#             is_quant = False

#             # direct quantized
#             if cls in QUANT_CLASS_NAMES:
#                 is_quant = True

#             # wrapped quantized
#             elif inner is not None and inner.__class__.__name__ in QUANT_CLASS_NAMES:
#                 is_quant = True
#                 child = inner                    # but we still use wrapper for dims

#             if not is_quant:
#                 continue

#             # ---------- DEVICE ----------
#             try:
#                 device = next(child.parameters()).device
#             except Exception:
#                 device = torch.device("cpu")

#             # ---------- READ WEIGHTS ----------
#             if hasattr(child.weight, "dequantize"):
#                 w = child.weight.dequantize().to(device)
#             else:
#                 w = child.weight.float().to(device)

#             # ---------- READ BIAS ----------
#             if getattr(child, "bias", None) is not None:
#                 b = child.bias.float().to(device)
#             else:
#                 b = None

#             # ---------- TRUE DIMENSIONS FROM WRAPPER ----------
#             in_f = getattr(wrapper, "in_features", None)
#             out_f = getattr(wrapper, "out_features", None)

#             if in_f is None or out_f is None:
#                 # fallback to weight dims only if both missing
#                 print(f"FALLING BACK shape {w.shape}")
#                 out_f, in_f = w.shape

#             # ---------- CREATE NEW LINEAR ----------
#             new_layer = torch.nn.Linear(in_f, out_f, bias=b is not None).to(device)
#             new_layer.weight.data.copy_(w)

#             if b is not None:
#                 new_layer.bias.data.copy_(b)

#             # ---------- REPLACE ----------
#             parent._modules[name] = new_layer

#     return model

# def dequantize_bnb_model(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
#     Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
#     Leaves LoRA and trainable modules untouched.
#     Safe: skips missing weights or broken layers automatically.
#     """
#     modules = list(model.named_modules())[::-1]  # bottom-up traversal

#     for name, module in modules:
#         if isinstance(module, (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)):
#             try:
#                 in_features = getattr(module, "in_features", module.weight.shape[1])
#                 out_features = getattr(module, "out_features", module.weight.shape[0])
#                 module_device = next(module.parameters(), None).device if module is not None else torch.device('cpu')
#                 print(f"dequant {module} on {module_device}")
#                 dequantized = torch.nn.Linear(
#                     in_features, out_features,
#                     bias=module.bias is not None,
#                     dtype=torch.float32,
#                     device=module_device
#                 )

#                 if module.weight is None or not hasattr(module.weight, "data"):
#                     continue

#                 dequantized.weight.data = module.weight.to(torch.float32)
#                 if module.bias is not None:
#                     dequantized.bias.data.copy_(module.bias.data)

#                 # Replace in parent
#                 parent = model
#                 parts = name.split(".")
#                 for p in parts[:-1]:
#                     parent = getattr(parent, p)
#                 setattr(parent, parts[-1], dequantized)

#                 del module
#                 gc.collect()
#                 torch.cuda.empty_cache()

#             except Exception as e:
#                 print(f"[WARN] Skipped dequantizing {name}: {e}")

#     return model

def _873a411cd910(_44f54f98fdc7: _00e247c22632._18bb3a400db6._e72fe0f4642c) -> _00e247c22632._18bb3a400db6._e72fe0f4642c:
    _d8812092fe26 = 0
    for _79be0e066d15, _2384cc3c79d8 in _d8fb8268e714(_44f54f98fdc7._daccf771899e()):
        if not _7d468eab525d(_2384cc3c79d8, (_3dfbbd95c519._18bb3a400db6._ea0729e3a7cc, _3dfbbd95c519._18bb3a400db6._4fcc5d6b62f3)):
            continue

        # print(f"Dequantizing {name} | {module.__class__.__name__} -> torch.nn.Linear")

        try:
            # 1. Force full dequantization using bnb internals (works on every model)
            if _7d468eab525d(_2384cc3c79d8, _3dfbbd95c519._18bb3a400db6._ea0729e3a7cc):
                # Handles NF4/FP4 + grouped QKV perfectly
                _33c92757a541 = _3dfbbd95c519._c6714ceeb2cd._8a7909733be2(
                    _2384cc3c79d8._33c92757a541._0ea2642c3b08,
                    _2384cc3c79d8._33c92757a541._dede837ae44c
                )._2d733ab94b9f(_d62f26344c57())
            else:  # Linear8bitLt
                _33c92757a541 = _2384cc3c79d8._33c92757a541._0ea2642c3b08._2d733ab94b9f(_d62f26344c57())

            _e6d546f8d718 = _2384cc3c79d8._e6d546f8d718._2d733ab94b9f(_d62f26344c57()) if _2384cc3c79d8._e6d546f8d718 is not _b876a71f50d0 else _b876a71f50d0

            # 2. Create clean fp32 Linear with correct shapes
            _aef62c8e65a7 = _00e247c22632._18bb3a400db6._8945a0d8b000(
                _74de9763dff9=_2384cc3c79d8._74de9763dff9,
                _5dc60f8b20e0=_2384cc3c79d8._5dc60f8b20e0,
                _e6d546f8d718=_e6d546f8d718 is not _b876a71f50d0,
                _dff7d7afed3b=_2384cc3c79d8._33c92757a541._0ea2642c3b08._dff7d7afed3b,
                _aeb5cef32604=_d62f26344c57()
            )
            _aef62c8e65a7._33c92757a541._0ea2642c3b08._c6ef006387a7(_33c92757a541)
            if _e6d546f8d718 is not _b876a71f50d0:
                _aef62c8e65a7._e6d546f8d718._0ea2642c3b08._c6ef006387a7(_e6d546f8d718)

            # 3. Replace in parent (safe even with wrappers)
            _bde6a3a76f43 = _61e6551336e1(_44f54f98fdc7._daccf771899e())
            _1d34d0f3061a = "."._d1a5278f6d6c(_79be0e066d15._99badefb3614(".")[:-1])
            _c5c5bc376857 = _bde6a3a76f43[_1d34d0f3061a] if _1d34d0f3061a else _44f54f98fdc7
            _203a1b22dc86(_c5c5bc376857, _79be0e066d15._99badefb3614(".")[-1], _aef62c8e65a7)
            del _2384cc3c79d8._33c92757a541   # instantly frees the 4bit/8bit buffer
            _d8812092fe26 += 1

        except _ef4342e2a44a as _0e61792e875a:
            _1ce48d625e58(f"[FATAL] Failed on {_79be0e066d15}: {_0e61792e875a}")
            raise

    _1ce48d625e58(f"Successfully dequantized {_d8812092fe26} bnb layers")
    _5f47154b5791._f98626c15d3e()
    if _00e247c22632._8b2a182fd222._6ad7116d3a22():
        _00e247c22632._8b2a182fd222._04bd08059fe0()
    return _44f54f98fdc7

# def dequantize_bnb_model(model: torch.nn.Module) -> torch.nn.Module:
#     import torch
#     from bitsandbytes.nn import Linear4bit

#     for name, module in list(model.named_modules()):
#         if not isinstance(module, Linear4bit):
#             continue

#         # THIS IS THE KEY LINE FOR NEW BITSANDBYTES
#         if hasattr(module.weight, "quant_state"):
#             # New format: packed bits + quant_state
#             weight = module.weight.dequantize(module.weight.quant_state)
#         else:
#             # Old format (rare now)
#             weight = module.weight.dequantize()

#         bias = module.bias if module.bias is not None else None

#         linear = torch.nn.Linear(
#             module.in_features,
#             module.out_features,
#             bias=bias is not None,
#             device=module.weight.device,
#             dtype=torch.float32
#         )
#         linear.weight.data = weight.to(torch.float32)
#         if bias is not None:
#             linear.bias.data = bias.data.to(torch.float32)

#         # Replace
#         parent = model
#         for part in name.split(".")[:-1]:
#             parent = getattr(parent, part)
#         setattr(parent, name.split(".")[-1], linear)

#     return model

def _723c2c86dd58(_44f54f98fdc7):
    """
    Convert any remaining uint8 weights to fp32, in-place.
    No reshaping, no heuristics — only dtype fix.
    """
    import _00e247c22632

    for _2384cc3c79d8 in _44f54f98fdc7._adbee513002b():
        for _79be0e066d15, _4f3c4ec33c1f in _2384cc3c79d8._283f2fbe9348(_4966b429c6e9=_5391a231e8c1):
            if _4f3c4ec33c1f._aeb5cef32604 == _00e247c22632._23f7c43ae13e:
                _4f3c4ec33c1f._0ea2642c3b08 = _4f3c4ec33c1f._0ea2642c3b08._50896461db26()

    return _44f54f98fdc7


def _bc94bb421371(_44f54f98fdc7):
    """Return the number of trainable parameters in a model.

    Args:
        model (torch.nn.Module): Model to inspect.

    Returns:
        int: Count of trainable parameters.
    """
    _bf5175da3612 = _39758a6b8c9d(_c779e9565205._6d3a0db41b1c() for _c779e9565205 in _44f54f98fdc7._27ed244b4e2c() if _c779e9565205._a4262b00ccf9)
    return _2a2f511f2602(_bf5175da3612)  # Ensure this returns an integer


# def get_target_modules(model, attribute_filter=None, name_filter=None, custom_filter=None):
#     """Collect submodules of `model` that satisfy the provided filters.

#     Args:
#         model (nn.Module or LightningModule): The model to analyze.
#         attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
#         name_filter (callable, optional): Function(name) -> bool to filter by module name.
#         custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.

#     Returns:
#         dict: Mapping from module name to module instance for modules that matched filters.

#     Raises:
#         TypeError: If `model` does not implement `named_modules`.
#     """
#     if not hasattr(model, "named_modules"):
#         raise TypeError("Provided model does not implement named_modules()")

#     target_modules = {}
#     for name, module in model.named_modules():
#         # Exclude LayerNorm and other unsupported layers
#         if "Norm" in module.__class__.__name__:
#             continue

#         # Skip frozen layers (requires_grad=False)
#         try:
#             if not any(param.requires_grad for param in module.parameters()):
#                 continue  # Skip this module if all its parameters are frozen
#         except Exception:
#             # If module.parameters() raises, skip it as not applicable
#             continue

#         if (
#             (attribute_filter is None or attribute_filter(module)) and
#             (name_filter is None or name_filter(name)) and
#             (custom_filter is None or custom_filter(name, module))
#         ):
#             target_modules[name] = module  # Store the module in the dictionary with its name as key
#     return target_modules

def _c4beeb86fd52(_44f54f98fdc7, _c1175c64c4ba=_b876a71f50d0, _29fc36ef172e=_b876a71f50d0, _48bbfda1cdb3=_b876a71f50d0, _9278ef0769e8="embedding"):
    """Collect submodules of `model` that satisfy the provided filters.

    - Keeps modules that expose a weight Tensor even when that weight is not a Parameter
      (this allows detecting bitsandbytes wrappers like Linear4bit/Linear8bit).
    - Skips normalization modules by class-name ("Norm").
    - If a module has actual torch.nn.Parameters and all are requires_grad==False, it is skipped.
    - Returns dict mapping full dotted module path (prefixed by `prefix` if provided) -> module.

    Args:
        model (nn.Module or LightningModule): The model to analyze.
        attribute_filter (callable, optional): Function(module) -> bool to filter by attributes.
        name_filter (callable, optional): Function(name) -> bool to filter by module name.
        custom_filter (callable, optional): Function(name, module) -> bool for arbitrary filtering.
        prefix (str, optional): Base name of model path (default: "embedding").

    Returns:
        dict: Mapping from *full dotted module path* to module instance for matched modules.

    Raises:
        TypeError: If `model` does not implement named_modules().
    """
    import _00e247c22632

    if not _4c094ac0ff32(_44f54f98fdc7, "named_modules"):
        raise _49c7daccfa2e("Provided model does not implement named_modules()")

    _ec9f32dff200 = {}
    for _79be0e066d15, _2384cc3c79d8 in _44f54f98fdc7._daccf771899e():
        # Exclude normalization layers (class name contains "Norm")
        if "Norm" in _2384cc3c79d8._2ed1f994d123.__name__:
            continue

        # Determine if module has torch.nn.Parameters
        _52d292c2fe26 = _5391a231e8c1
        _a962e2601f5b = []
        try:
            _a962e2601f5b = _d8fb8268e714(_2384cc3c79d8._27ed244b4e2c())
            _52d292c2fe26 = _766c177734a2(_a962e2601f5b) > 0
        except _ef4342e2a44a:
            _52d292c2fe26 = _5391a231e8c1

        # If module has Parameters and none require grad -> skip (frozen)
        if _52d292c2fe26:
            try:
                if not _4cdec87f57ce(_c779e9565205._a4262b00ccf9 for _c779e9565205 in _a962e2601f5b):
                    continue
            except _ef4342e2a44a:
                # conservative: don't skip if we can't determine requires_grad
                pass

        # Allow modules that have a 'weight' attribute that's a Tensor (covers bnb wrappers)
        _eaaf752cba81 = _5391a231e8c1
        try:
            _cfa941c9a2b9 = _5070722bc2c3(_2384cc3c79d8, "weight", _b876a71f50d0)
            if _7d468eab525d(_cfa941c9a2b9, _00e247c22632._8ebfa8cab825):
                # accept even if it's not a Parameter
                _eaaf752cba81 = _e683ba20d11f
        except _ef4342e2a44a:
            _eaaf752cba81 = _5391a231e8c1

        # Apply attribute/name/custom filters (attribute_filter should expect module)
        try:
            _5da31a7847dd = (_c1175c64c4ba is _b876a71f50d0) or _c1175c64c4ba(_2384cc3c79d8)
        except _ef4342e2a44a:
            _5da31a7847dd = _5391a231e8c1

        try:
            _a4b53fef831a = (_29fc36ef172e is _b876a71f50d0) or _29fc36ef172e(_79be0e066d15)
        except _ef4342e2a44a:
            _a4b53fef831a = _5391a231e8c1

        try:
            _867ab162ba1f = (_48bbfda1cdb3 is _b876a71f50d0) or _48bbfda1cdb3(_79be0e066d15, _2384cc3c79d8)
        except _ef4342e2a44a:
            _867ab162ba1f = _5391a231e8c1

        # Decide acceptance:
        # - If attribute_filter/name_filter/custom_filter pass -> accept
        # - Otherwise, fall back to accepting if module has a weight tensor (bnb)
        if (_5da31a7847dd and _a4b53fef831a and _867ab162ba1f) or (not _52d292c2fe26 and _eaaf752cba81):
            _864b8df2deac = f"{_9278ef0769e8}.{_79be0e066d15}" if _9278ef0769e8 else _79be0e066d15
            _ec9f32dff200[_864b8df2deac] = _2384cc3c79d8

    return _ec9f32dff200


def _16f840661798():
    """Safely clears GPU and CPU memory without disrupting distributed processes.

    Notes:
        - Best-effort: this function will not raise on cleanup errors, but will print/log them.
        - Ensures a distributed barrier at the end if torch.distributed is initialized.
    """
    # Run garbage collection to free CPU memory.
    _5f47154b5791._f98626c15d3e()

    if _00e247c22632._8b2a182fd222._6ad7116d3a22():
        # Clear CUDA memory cache.
        try:
            _00e247c22632._8b2a182fd222._04bd08059fe0()
            _00e247c22632._8b2a182fd222._1a462ba61cd8()
        except _ef4342e2a44a:
            # Some CUDA versions might not have ipc_collect
            pass

        # Ensure all pending CUDA operations are finished.
        try:
            _00e247c22632._8b2a182fd222._5fd65e6120f0()
        except _ef4342e2a44a:
            pass

        # Print memory stats before reset (optional).
        try:
            _e114e0803515 = _00e247c22632._8b2a182fd222._e0a81433badf()
            _926fd4ec837e = _00e247c22632._8b2a182fd222._79b8b0f28b2a()
            _1ce48d625e58(f"Before reset: Reserved = {_e114e0803515}, Allocated = {_926fd4ec837e}")
        except _ef4342e2a44a:
            pass

        # Reset memory tracking (useful for debugging).
        try:
            _00e247c22632._8b2a182fd222._251c9634c625()
        except _ef4342e2a44a:
            pass

    # Print current process memory usage.
    try:
        _1c4e10dfbae5 = _58ff33a6fa85._d764d4898dc4(os._b0c5cac7e497())
        _efdc55ab35ea = _1c4e10dfbae5._35b0b52de72e()
        _1ce48d625e58(f"Cleared GPU and CPU memory. Current process memory usage: {_efdc55ab35ea._1e659c3604d1 / 1024**2:.2f} MB")
    except _ef4342e2a44a:
        pass

    # Ensure all distributed processes are synchronized before proceeding.
    if _00e247c22632._7c5cd78421f1._39e19c423dff():
        try:
            _00e247c22632._7c5cd78421f1._65b2a35a976a()
        except _ef4342e2a44a:
            pass


def _61437c516281(_44f54f98fdc7):
    """Calculate approximate model size in gigabytes.

    Args:
        model (torch.nn.Module): The model to analyze.

    Returns:
        float: Total size in GB accounting for unique parameters.

    Raises:
        TypeError: If model does not implement `.parameters()`.
    """
    if not _4c094ac0ff32(_44f54f98fdc7, "parameters"):
        raise _49c7daccfa2e("Provided object is not a model with parameters()")

    _6b430a40d42f = 0  # Size in bytes
    _ada8adeff0a5 = _5971a8bc3c30()  # Set to track counted parameters by their unique IDs

    # Recursive function to sum the size of parameters in all submodules
    def _e110eb840966(_2384cc3c79d8):
        nonlocal _6b430a40d42f
        for _4f3c4ec33c1f in _2384cc3c79d8._27ed244b4e2c():
            _6075ea45e0bf = _7555af9ada2d(_4f3c4ec33c1f)  # Unique identifier for the parameter
            if _6075ea45e0bf not in _ada8adeff0a5:  # Ensure each parameter is counted only once
                _b9a577f91661 = _4f3c4ec33c1f._8161f745e33a()  # Size of one element in bytes
                _6b430a40d42f += _4f3c4ec33c1f._6d3a0db41b1c() * _b9a577f91661  # Total memory in bytes
                _ada8adeff0a5._c67bf38824c7(_6075ea45e0bf)  # Mark parameter as counted

    # Loop through all submodules (including nested ones)
    try:
        _44f54f98fdc7._ababc7f06b85(lambda _2384cc3c79d8: _622c89e57ab2(_2384cc3c79d8))
    except _ef4342e2a44a:
        # Fallback: iterate parameters directly
        for _4f3c4ec33c1f in _44f54f98fdc7._27ed244b4e2c():
            _6075ea45e0bf = _7555af9ada2d(_4f3c4ec33c1f)
            if _6075ea45e0bf not in _ada8adeff0a5:
                _6b430a40d42f += _4f3c4ec33c1f._6d3a0db41b1c() * _4f3c4ec33c1f._8161f745e33a()
                _ada8adeff0a5._c67bf38824c7(_6075ea45e0bf)

    _c6f8bc078d0d = _50896461db26(_6b430a40d42f) / (1024 ** 3)  # Convert to GB
    return _c6f8bc078d0d


def _e34b9743b529(_44f54f98fdc7: _f83cf6b96aea._ac9cb5a801d6, _097ce7d6aca9: _2a2f511f2602 = 1):
    """Return a PrettyTable summary of the model architecture and parameter counts.

    Args:
        model (pl.LightningModule): Model to summarize.
        depth (int): How deep in module name hierarchy to report (default 1).

    Returns:
        str: Multi-line string summary. If PrettyTable is unavailable this will raise.

    Raises:
        TypeError: If model does not implement `named_modules`.
    """
    if not _4c094ac0ff32(_44f54f98fdc7, "named_modules"):
        raise _49c7daccfa2e("Provided model does not implement named_modules()")

    _8b61a80f4bee = _0e7d2544fb9c()
    _8b61a80f4bee._5841de40f425 = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

    _b71eeba58eff = 0
    _bf5175da3612 = 0
    _539b8ef3a981 = 0

    _cf8a8d3c9b95 = _5971a8bc3c30()  # Track parameters to prevent duplicate counting

    def _18ac1930a07e(_2384cc3c79d8):
        """Helper function to count trainable/non-trainable parameters uniquely."""
        _a962e2601f5b = _d8fb8268e714(_2384cc3c79d8._27ed244b4e2c())
        _66fa9490a66f = [_c779e9565205 for _c779e9565205 in _a962e2601f5b if _7555af9ada2d(_c779e9565205) not in _cf8a8d3c9b95]

        _cf8a8d3c9b95._b5a9ceb51ba6(_7555af9ada2d(_c779e9565205) for _c779e9565205 in _66fa9490a66f)  # Mark parameters as counted

        _2b61f29c94a6 = _39758a6b8c9d(_c779e9565205._6d3a0db41b1c() for _c779e9565205 in _66fa9490a66f)
        _9a04ec99fd1f = _39758a6b8c9d(_c779e9565205._6d3a0db41b1c() for _c779e9565205 in _66fa9490a66f if _c779e9565205._a4262b00ccf9)
        _033c2e22447f = _2b61f29c94a6 - _9a04ec99fd1f

        return _2b61f29c94a6, _9a04ec99fd1f, _033c2e22447f

    for _79be0e066d15, _2384cc3c79d8 in _44f54f98fdc7._daccf771899e():
        if _79be0e066d15 == "" or _79be0e066d15._58c099b4f3f6('.') >= _097ce7d6aca9:  # Skip root module and limit depth
            continue

        _a962e2601f5b, _9a04ec99fd1f, _033c2e22447f = _afdd6d06d01a(_2384cc3c79d8)

        if _a962e2601f5b > 0:  # Only add layers with parameters
            _8b61a80f4bee._b64b2cc900fb([_79be0e066d15, _2384cc3c79d8._2ed1f994d123.__name__, f"{_a962e2601f5b:,}", f"{_9a04ec99fd1f:,}", f"{_033c2e22447f:,}"])

        _b71eeba58eff += _a962e2601f5b
        _bf5175da3612 += _9a04ec99fd1f
        _539b8ef3a981 += _033c2e22447f

    _d9a2ac568c74 = _b584f7d8b6ca(_44f54f98fdc7)

    _fa66e3369931 = "\n" + _8b61a80f4bee._98be3da51a72()
    _fa66e3369931 += f"\nTotal params: {_b71eeba58eff:,}\n"
    _fa66e3369931 += f"Trainable params: {_bf5175da3612:,}\n"
    _fa66e3369931 += f"Non-Trainable params: {_539b8ef3a981:,}\n"
    _fa66e3369931 += f"Model size: {_d9a2ac568c74:.2f} GB\n"

    return _fa66e3369931


def _a456ff791ff2(_0ce722285a6e):
    """Return a devices specification suitable for Lightning Trainer based on DEVICE.

    Args:
        DEVICE (str): 'gpu' or 'cpu'.

    Returns:
        int | list: devices argument for Trainer (e.g., 1, [0], list(range(n)) or -1 for distributed).

    Raises:
        ValueError: If DEVICE is unknown or LOCAL_RANK out of bounds.
    """
    if _0ce722285a6e == "cpu":
        return 1

    if _0ce722285a6e == "gpu":
        _fbbba5f52e8e = os._b398d1c8b26f._4add7fcb188b("CUDA_VISIBLE_DEVICES")
        _da69638c68bd = _00e247c22632._7c5cd78421f1._6ad7116d3a22() and _00e247c22632._7c5cd78421f1._39e19c423dff()

        if _da69638c68bd:
            return -1  # Let Lightning handle all

        # Inside non-distributed
        if _fbbba5f52e8e:
            _72961a6c5af4 = [_2a2f511f2602(_14341d9c5b92._0c14bfc3bec4()) for _14341d9c5b92 in _fbbba5f52e8e._99badefb3614(",")]
            _52a1e43d2711 = os._b398d1c8b26f._4add7fcb188b('LOCAL_RANK') or os._b398d1c8b26f._4add7fcb188b('RANK')

            if _52a1e43d2711 is not _b876a71f50d0:
                _043c3124e442 = _2a2f511f2602(_52a1e43d2711)
                if _043c3124e442 >= _766c177734a2(_72961a6c5af4):
                    raise _b47caaec66d3(f"LOCAL_RANK {_043c3124e442} out of bounds for visible GPUs {_72961a6c5af4}")
                return [_043c3124e442]  # single target

            # No rank set, fallback to all visible
            return _d8fb8268e714(_167b45c629f6(_766c177734a2(_72961a6c5af4)))
        else:
            # No CUDA_VISIBLE_DEVICES → use all available
            return _d8fb8268e714(_167b45c629f6(_00e247c22632._8b2a182fd222._64e97a1fa566()))

    raise _b47caaec66d3(f"Unknown DEVICE {_0ce722285a6e}")


def _dc4a3cde2f3f():
    """Return the preferred compute dtype for current GPU capability.

    Returns:
        torch.dtype: Preferred compute dtype (torch.bfloat16, torch.float16, or torch.float32).
    """
    _7b1f4c176272 = _00e247c22632._d0e23426f495
    if _00e247c22632._8b2a182fd222._6ad7116d3a22():
        try:
            _42e010797dc9, _c5732582c704 = _00e247c22632._8b2a182fd222._4133a50788a9()
            # Ampere (8.0+) supports bfloat16
            if _42e010797dc9 >= 8:
                _7b1f4c176272 = _00e247c22632._9dd7cbd2891c
            else:
                _7b1f4c176272 = _00e247c22632._4c56d57ec43b
        except _ef4342e2a44a:
            _7b1f4c176272 = _00e247c22632._d0e23426f495
    return _7b1f4c176272


def _a6b8b6551e9e(_3b3992e3b967, _562bb4670d7d):
    """Return True when `trial.params` equals parameters of any past trial.

    Args:
        trial (optuna.trial.Trial): Trial to check.
        study (optuna.Study): Study to check against.

    Returns:
        bool: True if duplicate found, False otherwise.

    Raises:
        TypeError: If `trial` or `study` is None or lacks expected attributes.
    """
    if _3b3992e3b967 is _b876a71f50d0 or _562bb4670d7d is _b876a71f50d0:
        raise _49c7daccfa2e("trial and study must be provided")

    # Get the current trial parameters
    _ae22f02c4ecd = _5070722bc2c3(_3b3992e3b967, "params", _b876a71f50d0)
    if _ae22f02c4ecd is _b876a71f50d0:
        raise _49c7daccfa2e("trial.params is not available")

    # Check all completed trials for duplicates
    for _7b74dc2365d1 in _562bb4670d7d._ca7c3e5c0576(_142171146936=(_04fee85b0dfb._3b3992e3b967._3a66a0b7d742._e338d18548e7,
                                               _04fee85b0dfb._3b3992e3b967._3a66a0b7d742._7fa5ac57be19,
                                               _04fee85b0dfb._3b3992e3b967._3a66a0b7d742._bac28d5793bb)):
        if _5070722bc2c3(_7b74dc2365d1, "params", _b876a71f50d0) == _ae22f02c4ecd:
            return _e683ba20d11f
    return _5391a231e8c1


class _d1ab04c2ecf8(_04fee85b0dfb._7f1ea510b8ca._f422ff91cfd8):
    """Sampler wrapper that resamples a parameter when a duplicate trial would be created.

    Args:
        base_sampler (optuna.samplers.BaseSampler): Underlying sampler to delegate to.
    """

    def _2b5b43b4fa73(self, _cafe8d1ff33f: _04fee85b0dfb._7f1ea510b8ca._f422ff91cfd8):
        self._cafe8d1ff33f = _cafe8d1ff33f  # Use TPESampler or any other sampler

    # Override and delegate infer_relative_search_space to the base sampler
    def _5ad8c8181be4(self, _562bb4670d7d, _3b3992e3b967):
        return self._cafe8d1ff33f._e21abd82f4a1(_562bb4670d7d, _3b3992e3b967)

    # Override and delegate sample_relative to the base sampler
    def _6d6e269f61af(self, _562bb4670d7d, _3b3992e3b967, _32a175657078):
        return self._cafe8d1ff33f._c5ca6532e169(_562bb4670d7d, _3b3992e3b967, _32a175657078)

    # Override sample_independent to check for duplicates
    def _adbf78000ea7(self, _562bb4670d7d, _3b3992e3b967, _daeca08fd5a6, _324953476e35):
        """
        Sample independently using the base sampler. If the proposed parameter
        would create a duplicate trial (all params equal to a past trial),
        resample until unique.

        Args:
            study (optuna.Study)
            trial (optuna.trial.Trial)
            param_name (str)
            param_distribution: distribution object passed by Optuna

        Returns:
            The sampled parameter value.

        Raises:
            RuntimeError: If underlying base_sampler repeatedly fails to produce a non-duplicate
                          after many attempts (guard not implemented here to preserve original behavior).
        """
        while _e683ba20d11f:
            # Sample a set of hyperparameters using the base sampler (TPESampler)
            _4f3c4ec33c1f = self._cafe8d1ff33f._5fc15639243e(_562bb4670d7d, _3b3992e3b967, _daeca08fd5a6, _324953476e35)

            # Temporarily assign the parameter to the trial for comparison
            _3b3992e3b967._a962e2601f5b[_daeca08fd5a6] = _4f3c4ec33c1f

            # Check if this parameter set (with the current params) is a duplicate
            if not _828da875e910(_3b3992e3b967, _562bb4670d7d):
                return _4f3c4ec33c1f  # If not duplicate, return the parameter


def _dbfb3ec4c329(_5a0b0709d326):
    """Compute gamma parameter for TPESampler.

    Args:
        n (int): Number of completed trials.

    Returns:
        int: Top 10% of n, capped at 25.
    """
    # top 10% of n completed trials
    return _cef9fe4f2d84(25, _2a2f511f2602(0.1 * _5a0b0709d326))

def _483222b3a097(_2c98226cb21e, _79be0e066d15: _c4692100770c, _aeb5cef32604=_b876a71f50d0, _30e60ad88d78: _96983f251f49 = _e683ba20d11f, _adb2ad5501ea=_b876a71f50d0, _98b79ba76ae8: _c4692100770c = _b876a71f50d0):
    """
    Retrieve and validate a property from a dot-separated path (e.g. 'app.random_seed', 'run_config.batch_size').

    Args:
        props: Loaded YAML properties object (attribute/dict hybrid).
        name: Dot-separated property name (string).
        dtype: Optional type enforcement (e.g. int, float, str, "list[int]", "list[str]", etc.).
        required: If True, raises error when missing. If False, returns default.
        default: Optional fallback value when required=False and key missing.
        help: Optional human-readable hint for fixing config.

    Raises:
        AttributeError: If key missing and required=True.
        ValueError: If key exists but value is None.
        TypeError: If dtype enforcement fails.

    Returns:
        The retrieved (and possibly cast) value, or default.
    """

    # --- Navigate dotted path ---
    _588fcf28ebc9 = _79be0e066d15._99badefb3614(".")
    _cd36042577b7 = _2c98226cb21e
    _51a761704d26 = []
    for _c779e9565205 in _588fcf28ebc9:
        _51a761704d26._293f448373bf(_c779e9565205)
        if _cd36042577b7 is _b876a71f50d0:
            if _30e60ad88d78:
                raise _e1c444a8a0b9(
                    f"Missing required property '{'.'._d1a5278f6d6c(_51a761704d26)}' (intermediate value is None). {_98b79ba76ae8 or ''}"
                )
            return _adb2ad5501ea

        if _4c094ac0ff32(_cd36042577b7, _c779e9565205):
            _cd36042577b7 = _5070722bc2c3(_cd36042577b7, _c779e9565205)
        elif _7d468eab525d(_cd36042577b7, _61e6551336e1) and _c779e9565205 in _cd36042577b7:
            _cd36042577b7 = _cd36042577b7[_c779e9565205]
        else:
            if _30e60ad88d78:
                raise _e1c444a8a0b9(
                    f"Missing required property '{'.'._d1a5278f6d6c(_51a761704d26)}'. {_98b79ba76ae8 or ''}"
                )
            return _adb2ad5501ea

    _4a9bd4912420 = _cd36042577b7

    # --- Explicit null check ---
    if _4a9bd4912420 is _b876a71f50d0:
        raise _b47caaec66d3(
            f"Property '{_79be0e066d15}' is explicitly null/None. Please set a valid value or remove the key to use default. {_98b79ba76ae8 or ''}"
        )

    # --- Dtype enforcement ---
    if _aeb5cef32604 is not _b876a71f50d0:
        def _7afced54147c(_32003fec0976):
            raise _49c7daccfa2e(f"Property '{_79be0e066d15}' type validation failed: {_32003fec0976}. {_98b79ba76ae8 or ''}")

        if _7d468eab525d(_aeb5cef32604, _c4692100770c) and _aeb5cef32604._ba0e74f3d3ce("list[") and _aeb5cef32604._8ba82a40a5fe("]"):
            _a44022fcbf55 = _aeb5cef32604[5:-1]._0c14bfc3bec4()
            if not _7d468eab525d(_4a9bd4912420, _d8fb8268e714):
                _ee39e6810160(f"expected list[{_a44022fcbf55}], got {_784aa5475553(_4a9bd4912420).__name__}")
            _f769e8f5c575 = {"int": _2a2f511f2602, "float": _50896461db26, "str": _c4692100770c, "bool": _96983f251f49}
            _fc1541e61345 = _f769e8f5c575._4add7fcb188b(_a44022fcbf55)
            if _fc1541e61345 is _b876a71f50d0:
                _ee39e6810160(f"unsupported inner dtype '{_a44022fcbf55}'")
            try:
                _4a9bd4912420 = [_fc1541e61345(_14341d9c5b92) for _14341d9c5b92 in _4a9bd4912420]
            except _ef4342e2a44a as _0e61792e875a:
                _ee39e6810160(f"failed to cast elements to {_a44022fcbf55}: {_0e61792e875a}")
        else:
            try:
                _4a9bd4912420 = _aeb5cef32604(_4a9bd4912420)
            except _ef4342e2a44a as _0e61792e875a:
                _ee39e6810160(f"cannot cast to {_5070722bc2c3(_aeb5cef32604, '__name__', _aeb5cef32604)}: {_0e61792e875a}")

    return _4a9bd4912420


def _e4d0b6129d57(_3b3992e3b967: _04fee85b0dfb._3b3992e3b967._b349cfd43892, _ec9f32dff200: _d8fb8268e714, _d76f4b99aaf4: _aaa63b1d4bb0):
    """Construct a PEFT LoraConfig from an Optuna trial's suggested hyperparameters.

    Args:
        trial (optuna.trial.Trial): Optuna trial instance to query for hyperparameters.
        target_modules (list): list of target modules (may be empty).
        lora_task_type (Any): TaskType enum or equivalent required by LoraConfig.

    Returns:
        LoraConfig: Instance configured according to trial suggestions.

    Raises:
        Exception: Propagates exceptions from the underlying LoraConfig constructor or trial queries.
    """
    # Define the range for rank
    _944b201eb7b1 = _3b3992e3b967._1cf892126808("lora_rank", 4, 16, _c4078c4aac4e=4)

    # Dynamically calculate scaling factor based on rank
    _f5ed4b2f6ce3 = _3b3992e3b967._1cf892126808("lora_alpha_scaling_factor", 8, 32, _c4078c4aac4e=4)
    # Add dropout options for LoRA
    _81e0d0d36974 = _3b3992e3b967._5aaaf6501ec5("lora_dropout", [0.0, 0.1, 0.2])

    # Create and return LoraConfig. Keep as the project's expected LoraConfig API.
    return _b25ef08a3090(
        _e2b6f35f65dc=_944b201eb7b1 if not _7d468eab525d(_944b201eb7b1, _361872833368) else _944b201eb7b1[0],
        _f5ed4b2f6ce3=_f5ed4b2f6ce3 if not _7d468eab525d(_f5ed4b2f6ce3, _361872833368) else _f5ed4b2f6ce3[0],
        _81e0d0d36974=_81e0d0d36974 if not _7d468eab525d(_81e0d0d36974, _361872833368) else _81e0d0d36974[0],
        _ec9f32dff200=_ec9f32dff200 if _ec9f32dff200 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj", "embed_tokens", "lm_head"],
        _c66c3f0c70a8=_d76f4b99aaf4
    )

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Apply LoRA to model.embedding or equivalent embedding root for decoder models.
#     """
#     log.info(f"Model Structure before applying LoRA {model}")
#     log.info("Trainable params before LoRA: %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))

#     if not isinstance(target_embedding_modules, dict):
#         log.warning("Expected target_embedding_modules dict, got %s; skipping LoRA.", type(target_embedding_modules))
#         return model

#     root = getattr(model, "module", model)
#     model_name_to_mod = dict(root.named_modules())

#     # Resolve names (object identity, exact name, suffix)
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None
#         for nm, mm in model_name_to_mod.items():
#             if mm is emb_mod:
#                 found = nm; break
#         if found is None and emb_key in model_name_to_mod:
#             found = emb_key
#         if found is None:
#             short = emb_key.replace("embedding.", "").replace("module.", "").replace("embedding.module.", "")
#             for nm in model_name_to_mod:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in model", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # shallow clone config avoiding odict_keys issues
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # cleaned target module names relative to embedding
#     cleaned_targets = []
#     for full_nm in resolved:
#         t = full_nm.replace("model.embedding.", "").replace("embedding.", "").replace("module.", "").lstrip(".")
#         if t:
#             cleaned_targets.append(t)
#     # dedupe order-preserve
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     try:
#         cfg.target_modules = list(cleaned_targets)
#     except Exception:
#         setattr(cfg, "target_modules", list(cleaned_targets))

#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- UNWRAP WRAPPERS UNDER model.embedding (in-place) ---
#     def _resolve_embedding_root(obj):
#         """
#         Return tuple (embedding_module, path_key) where path_key indicates where to reattach:
#           - "embedding" -> model.embedding
#           - "model.model.embed_tokens" -> model.model.embed_tokens
#           - "transformer.wte" -> model.transformer.wte
#         Raises ValueError if none found.
#         """
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         # some wrappers: e.g., HF models that nest inside .base_model
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Try to unwrap common wrappers under the embedding subtree (in-place)
#     def _unwrap_candidate(obj):
#         if hasattr(obj, "module") and obj is not getattr(obj, "module"):
#             return getattr(obj, "module")
#         if hasattr(obj, "base_layer") and obj is not getattr(obj, "base_layer"):
#             return getattr(obj, "base_layer")
#         return None

#     for parent_name, parent in list(emb_unwrapped.named_modules()):
#         # use named_children on parent to replace attributes on parent
#         for child_name, child in list(parent.named_children()):
#             try:
#                 inner = _unwrap_candidate(child)
#                 if inner is not None:
#                     setattr(parent, child_name, inner)
#                     log.debug("Unwrapped %s.%s -> %s", parent_name or "embedding_root", child_name, inner.__class__.__name__)
#             except Exception:
#                 log.debug("Could not unwrap child %s of parent %s", child_name, parent_name)

#     # Recompute actual embedding root after unwrapping (in case we changed .module children)
#     emb_current = emb_current  # preserve original wrapper object reference (used for reattach)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # Use small container exposing embedding so PEFT only touches embedding submodules
#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)
#     # attempt to move container to same device as embedding params to avoid device errors
#     try:
#         sample_dev = None
#         for p in emb_unwrapped.parameters():
#             sample_dev = p.device; break
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Call PEFT on the embedding container
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # Reinstall wrapped embedding back into the top-level model, preserving wrapper if present
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped_emb)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped_emb
#             else:
#                 model.embedding = wrapped_emb
#         elif emb_path == "model.model.embed_tokens":
#             model.model.embed_tokens = wrapped_emb
#         elif emb_path == "transformer.wte":
#             model.transformer.wte = wrapped_emb
#         elif emb_path == "base_model.model.embed_tokens":
#             model.base_model.model.embed_tokens = wrapped_emb
#         else:
#             # fallback, attempt best-effort attach by attribute traversal
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     log.info("Applied LoRA to model.embedding (PEFT-wrapped).")

#     # Freeze non-LoRA params inside embedding; keep LoRA params trainable
#     try:
#         for name, param in model.embedding.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside model.embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in model.embedding.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("LoRA enabled %d tensors, total %d params.", len(enabled), sum(v for _, v in enabled))
#     log.info("After LoRA: trainable params %s | size: %.3f GB",
#              get_trainable_parameters(model), calculate_model_size_in_gb(model))
#     log.info(f"Model Structure after applying LoRA {model}")
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     """
#     Unified LoRA application for both BERT-like and LLaMA-like models.
#     Works with quantized or non-quantized modules.

#     Returns the input `model` with LoRA adapters applied in-place.
#     """
#     # small local helper: resolve common embedding roots
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())
#     log.info("Root type: %s", type(root))
#     log.info("Named modules sample: %s", list(named_modules.keys())[:20])
#     log.info("Target embedding keys: %s", list(target_embedding_modules.keys()))

#     # --- resolve provided target_embedding_modules to names in root.named_modules() ---
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         found = None

#         # identity match (object identity)
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 found = nm
#                 break
#         if found:
#             resolved.append(found); continue

#         # direct string variants (embedding. prefix / without)
#         if isinstance(emb_key, str):
#             variants = [emb_key]
#             if not emb_key.startswith("embedding."):
#                 variants.append("embedding." + emb_key)
#             else:
#                 variants.append(emb_key.replace("embedding.", "", 1))
#             for v in variants:
#                 if v in named_modules:
#                     found = v; break
#         if found:
#             resolved.append(found); continue

#         # suffix match (endswith)
#         if isinstance(emb_key, str):
#             short = emb_key.replace("embedding.", "").replace("module.", "").lstrip(".")
#             for nm in named_modules:
#                 if nm.endswith(short):
#                     found = nm; break
#         if found:
#             resolved.append(found); continue

#         # fallback: match by class name + first parameter shape
#         try:
#             if isinstance(emb_mod, torch.nn.Module):
#                 emb_cls = emb_mod.__class__.__name__
#                 ref_shape = None
#                 for p in emb_mod.parameters():
#                     ref_shape = tuple(p.shape); break
#                 if ref_shape is not None:
#                     for nm, mm in named_modules.items():
#                         if mm.__class__.__name__ != emb_cls:
#                             continue
#                         for p in mm.parameters():
#                             if tuple(p.shape) == ref_shape:
#                                 found = nm; break
#                         if found:
#                             break
#         except Exception:
#             pass
#         if found:
#             resolved.append(found)
#         else:
#             log.warning("Could not resolve embedding key '%s' in root.named_modules()", emb_key)

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")
#     log.info("Resolved LoRA targets: %s", resolved)

#     # --- clone & normalise LoRA config ---
#     try:
#         cfg_kwargs = {k: v for k, v in vars(lora_config).items() if not isinstance(v, (type({}.keys()),))}
#         cfg = lora_config.__class__(**cfg_kwargs)
#     except Exception:
#         cfg = lora_config

#     # Determine embedding root and path (for normalization)
#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Embedding root resolution failed: {e}")

#     # Normalize target module names to be *relative to the module we will pass to PEFT*
#     cleaned_targets = []
#     for full in resolved:
#         # If resolved name starts with the emb_path, strip that prefix
#         if isinstance(full, str) and full.startswith(emb_path + "."):
#             cleaned = full[len(emb_path) + 1 :]
#         else:
#             # also handle common alternatives
#             cleaned = full.replace("embedding.model.", "").replace("embedding.", "").replace("model.", "").lstrip(".")
#         if cleaned:
#             cleaned_targets.append(cleaned)
#     # dedupe preserve order
#     seen = set(); cleaned_targets = [x for x in cleaned_targets if not (x in seen or seen.add(x))]
#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")
#     cfg.target_modules = list(cleaned_targets)
#     log.info("Using normalized LoRA target modules: %s", cfg.target_modules)

#     # --- if LLaMA-like (decoder) apply LoRA directly on decoder model to avoid embedding-wrapper issues ---
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         log.info("Detected LLaMA architecture — applying LoRA directly on decoder model.")
#         try:
#             # normalize: remove "model." prefix so PEFT matches internal names
#             cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]
#             # cfg.target_modules must be relative to model.embedding.model (we already normalized above)
#             wrapped_decoder = get_peft_model(model.embedding.model, cfg)
#             # replace decoder in-place
#             model.embedding.model = wrapped_decoder

#             # freeze everything except LoRA params inside the wrapped decoder
#             for n, p in model.embedding.model.named_parameters():
#                 p.requires_grad = ("lora" in n.lower())

#             log.info("Applied LoRA to LLaMA decoder; trainable params: %d",
#                      sum(1 for _, p in model.embedding.model.named_parameters() if p.requires_grad))
#             return model
#         except Exception as e:
#             log.error("Failed to apply LoRA directly on LLaMA decoder: %s", e)
#             raise

#     # --- otherwise: create container exposing 'embedding' so PEFT touches only embedding subtree ---
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # attach generation helper if root implements it (prevents PEFT complaining)
#     if hasattr(root, "prepare_inputs_for_generation"):
#         try:
#             setattr(emb_container, "prepare_inputs_for_generation", getattr(root, "prepare_inputs_for_generation"))
#         except Exception:
#             # non-fatal
#             pass

#     # move container to embedding device if known
#     try:
#         sample_dev = next((p.device for p in emb_unwrapped.parameters()), None)
#         if sample_dev is not None:
#             emb_container.to(sample_dev)
#     except Exception:
#         pass

#     # Wrap the container with PEFT
#     try:
#         wrapped_container = get_peft_model(emb_container, cfg)
#     except Exception as e:
#         log.error("Failed to wrap embedding with PEFT: %s", e)
#         log.error("Cleaned targets given to PEFT: %s", cfg.target_modules)
#         raise

#     # obtain wrapped embedding module and reattach into the model at emb_path
#     wrapped_emb = getattr(wrapped_container, "embedding")
#     try:
#         parts = emb_path.split(".")
#         tgt = model
#         for p in parts[:-1]:
#             tgt = getattr(tgt, p)
#         setattr(tgt, parts[-1], wrapped_emb)
#     except Exception as e:
#         log.error("Error reattaching wrapped embedding: %s", e)
#         raise ValueError(f"Cannot reattach wrapped embedding to model at path {emb_path}: {e}")

#     # Freeze non-LoRA params inside the wrapped embedding; keep LoRA params trainable
#     try:
#         for name, param in wrapped_emb.named_parameters():
#             param.requires_grad = ("lora" in name.lower())
#     except Exception as e:
#         log.error("Error while freezing parameters inside wrapped embedding: %s", e)
#         raise

#     enabled = [(n, p.numel()) for n, p in wrapped_emb.named_parameters() if p.requires_grad]
#     if not enabled:
#         log.error("No LoRA parameters found trainable inside embedding — aborting.")
#         raise RuntimeError("LoRA produced no trainable params in embedding.")

#     log.info("Applied LoRA successfully with %d trainable tensors.", len(enabled))
#     return model

# def apply_lora_to_model(
#     model: "torch.nn.Module",
#     target_embedding_modules: "Dict[str, torch.nn.Module]",
#     lora_config,
#     log: "Any"
# ) -> "torch.nn.Module":
#     # ------------------------------------------------------------------
#     # Helper: ensure PEFT-required method exists
#     # ------------------------------------------------------------------
#     def _ensure_prepare_inputs_for_generation(obj, fallback):
#         if hasattr(obj, "prepare_inputs_for_generation"):
#             return
#         if hasattr(fallback, "prepare_inputs_for_generation"):
#             obj.prepare_inputs_for_generation = fallback.prepare_inputs_for_generation
#             return

#         def _noop_prepare_inputs_for_generation(*args, **kwargs):
#             return args[0] if args else None

#         obj.prepare_inputs_for_generation = _noop_prepare_inputs_for_generation

#     # ------------------------------------------------------------------
#     # Helper: resolve embedding root (unchanged logic)
#     # ------------------------------------------------------------------
#     def _resolve_embedding_root(obj) -> Tuple["torch.nn.Module", str]:
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Could not resolve embedding root for {obj.__class__.__name__}")

#     root = getattr(model, "module", model)
#     named_modules = dict(root.named_modules())

#     # ------------------------------------------------------------------
#     # Resolve target embedding modules (unchanged)
#     # ------------------------------------------------------------------
#     resolved = []
#     for emb_key, emb_mod in target_embedding_modules.items():
#         for nm, mm in named_modules.items():
#             if mm is emb_mod:
#                 resolved.append(nm)
#                 break

#     if not resolved:
#         raise ValueError("No embedding submodules resolved for LoRA — skipping.")

#     # ------------------------------------------------------------------
#     # Clone LoRA config
#     # ------------------------------------------------------------------
#     try:
#         cfg = lora_config.__class__(**vars(lora_config))
#     except Exception:
#         cfg = lora_config

#     # ------------------------------------------------------------------
#     # Normalize target module names
#     # ------------------------------------------------------------------
#     emb_current, emb_path = _resolve_embedding_root(model)

#     cleaned_targets = []
#     for full in resolved:
#         if full.startswith(emb_path + "."):
#             cleaned_targets.append(full[len(emb_path) + 1 :])

#     if not cleaned_targets:
#         raise ValueError("After normalization no target module names remain for LoRA.")

#     cfg.target_modules = cleaned_targets

#     # ------------------------------------------------------------------
#     # Detect LLaMA-style decoder (unchanged intent)
#     # ------------------------------------------------------------------
#     is_llama_decoder = (
#         hasattr(model, "embedding")
#         and hasattr(model.embedding, "model")
#         and hasattr(model.embedding.model, "layers")
#     )

#     is_gemma_decoder = (
#         hasattr(model, "model")
#         and hasattr(model.model, "model")
#         and hasattr(model.model.model, "layers")
#     )

#     # ------------------------------------------------------------------
#     # LLaMA decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_llama_decoder:
#         decoder = model.embedding.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.embedding.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model
    
#     # ------------------------------------------------------------------
#     # gemma decoder path (PATCHED)
#     # ------------------------------------------------------------------
#     if is_gemma_decoder:
#         decoder = model.model.model

#         # CRITICAL FIX: ensure generation hook BEFORE PEFT
#         _ensure_prepare_inputs_for_generation(decoder, model)

#         cfg.target_modules = [t.replace("model.", "") for t in cfg.target_modules]

#         wrapped_decoder = get_peft_model(decoder, cfg)

#         # CRITICAL FIX: reattach, do NOT replace LightningModule
#         model.model.model = wrapped_decoder

#         for n, p in wrapped_decoder.named_parameters():
#             p.requires_grad = ("lora" in n.lower())

#         return model

#     # ------------------------------------------------------------------
#     # Embedding-container path (PATCHED)
#     # ------------------------------------------------------------------
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     class _EmbContainer(torch.nn.Module):
#         def __init__(self, embedding_mod):
#             super().__init__()
#             self.embedding = embedding_mod

#     emb_container = _EmbContainer(emb_unwrapped)

#     # CRITICAL FIX: ensure hook exists UNCONDITIONALLY
#     _ensure_prepare_inputs_for_generation(emb_container, root)

#     wrapped_container = get_peft_model(emb_container, cfg)
#     wrapped_emb = wrapped_container.embedding

#     # Reattach wrapped embedding
#     parts = emb_path.split(".")
#     tgt = model
#     for p in parts[:-1]:
#         tgt = getattr(tgt, p)
#     setattr(tgt, parts[-1], wrapped_emb)

#     for name, param in wrapped_emb.named_parameters():
#         param.requires_grad = ("lora" in name.lower())

#     return model

def _5c2d84fa3954(
    _44f54f98fdc7: "torch.nn.Module",
    _70c929ab30d7: "Dict[str, torch.nn.Module]",
    _7ffb968b2919,
    _42f22744a6db: "Any"
) -> "torch.nn.Module":

    def _0a511944bf54(_1e62e4e952d8, _e5d8c575e691):
        if _4c094ac0ff32(_1e62e4e952d8, "prepare_inputs_for_generation"):
            return
        if _4c094ac0ff32(_e5d8c575e691, "prepare_inputs_for_generation"):
            _1e62e4e952d8._02d9be16f0fe = _e5d8c575e691._02d9be16f0fe
            return

        def _3880251ead67(*_db23281feb8f, **_d8a04e01e9bf):
            return _db23281feb8f[0] if _db23281feb8f else _b876a71f50d0

        _1e62e4e952d8._02d9be16f0fe = _18cb064225fc

    def _5d05441a2547(_1e62e4e952d8):
        if _4c094ac0ff32(_1e62e4e952d8, "embedding"):
            return _5070722bc2c3(_1e62e4e952d8, "embedding"), "embedding"
        if _4c094ac0ff32(_1e62e4e952d8, "model") and _4c094ac0ff32(_1e62e4e952d8._44f54f98fdc7, "embed_tokens"):
            return _5070722bc2c3(_1e62e4e952d8._44f54f98fdc7, "embed_tokens"), "model.embed_tokens"
        if _4c094ac0ff32(_1e62e4e952d8, "model") and _4c094ac0ff32(_1e62e4e952d8._44f54f98fdc7, "model") and _4c094ac0ff32(_1e62e4e952d8._44f54f98fdc7._44f54f98fdc7, "embed_tokens"):
            return _5070722bc2c3(_1e62e4e952d8._44f54f98fdc7._44f54f98fdc7, "embed_tokens"), "model.model.embed_tokens"
        if _4c094ac0ff32(_1e62e4e952d8, "transformer") and _4c094ac0ff32(_1e62e4e952d8._7d3e0b88528c, "wte"):
            return _5070722bc2c3(_1e62e4e952d8._7d3e0b88528c, "wte"), "transformer.wte"
        if _4c094ac0ff32(_1e62e4e952d8, "base_model") and _4c094ac0ff32(_1e62e4e952d8._8d75f33068d0, "model") and _4c094ac0ff32(_1e62e4e952d8._8d75f33068d0._44f54f98fdc7, "embed_tokens"):
            return _5070722bc2c3(_1e62e4e952d8._8d75f33068d0._44f54f98fdc7, "embed_tokens"), "base_model.model.embed_tokens"
        raise _b47caaec66d3(f"Could not resolve embedding root for {_1e62e4e952d8._2ed1f994d123.__name__}")

    _20d1eb2d7240 = _5070722bc2c3(_44f54f98fdc7, "module", _44f54f98fdc7)
    _daccf771899e = _61e6551336e1(_20d1eb2d7240._daccf771899e())

    # --------------------------------------------------
    # Detect decoders FIRST (ONLY MOVED)
    # --------------------------------------------------
    _36e7c119d091 = (
        _4c094ac0ff32(_44f54f98fdc7, "embedding")
        and _4c094ac0ff32(_44f54f98fdc7._9aeace538655, "model")
        and _4c094ac0ff32(_44f54f98fdc7._9aeace538655._44f54f98fdc7, "layers")
    )

    _1939071b3c25 = (
        _4c094ac0ff32(_44f54f98fdc7, "model")
        and _4c094ac0ff32(_44f54f98fdc7._44f54f98fdc7, "model")
        and _4c094ac0ff32(_44f54f98fdc7._44f54f98fdc7._44f54f98fdc7, "layers")
    )

    _2ee43a1d5b59 = (
        _4c094ac0ff32(_44f54f98fdc7, "model")
        and _4c094ac0ff32(_44f54f98fdc7._44f54f98fdc7, "layers")
    )

    # --------------------------------------------------
    # Resolve target embedding modules (UNCHANGED)
    # --------------------------------------------------
    _67e23b47d0a8 = []
    for _49f145935fb9, _43d7fd1e9641 in _70c929ab30d7._b992948b5171():
        for _b70dc35dd84e, _40cf24c68313 in _daccf771899e._b992948b5171():
            if _40cf24c68313 is _43d7fd1e9641:
                _67e23b47d0a8._293f448373bf(_b70dc35dd84e)
                break

    if not _67e23b47d0a8 and not _36e7c119d091 and not _1939071b3c25 and not _2ee43a1d5b59:
        raise _b47caaec66d3("No embedding submodules resolved for LoRA — skipping.")

    # --------------------------------------------------
    # Clone LoRA config (UNCHANGED)
    # --------------------------------------------------
    try:
        _960348adc560 = _7ffb968b2919._2ed1f994d123(**_d66581903c1b(_7ffb968b2919))
    except _ef4342e2a44a:
        _960348adc560 = _7ffb968b2919

    # --------------------------------------------------
    # Normalize target module names (UNCHANGED)
    # --------------------------------------------------
    _328458b48142, _9f158d083259 = _07afccbe15e4(_44f54f98fdc7)

    _18b340c42a0d = []
    for _909c829003fb in _67e23b47d0a8:
        if _909c829003fb._ba0e74f3d3ce(_9f158d083259 + "."):
            _18b340c42a0d._293f448373bf(_909c829003fb[_766c177734a2(_9f158d083259) + 1 :])

    if _18b340c42a0d:
        _960348adc560._ec9f32dff200 = _18b340c42a0d

    # --------------------------------------------------
    # LLaMA decoder path (UNCHANGED)
    # --------------------------------------------------
    if _36e7c119d091:
        _091500a9009c = _44f54f98fdc7._9aeace538655._44f54f98fdc7
        _6f952873c3a7(_091500a9009c, _44f54f98fdc7)
        _960348adc560._ec9f32dff200 = [_1cef8af46565._7741041f59ea("model.", "") for _1cef8af46565 in _960348adc560._ec9f32dff200]
        _ab0fc6094cd1 = _daa4734124f0(_091500a9009c, _960348adc560)
        _44f54f98fdc7._9aeace538655._44f54f98fdc7 = _ab0fc6094cd1
        for _5a0b0709d326, _c779e9565205 in _ab0fc6094cd1._283f2fbe9348():
            _c779e9565205._a4262b00ccf9 = ("lora" in _5a0b0709d326._55fb8a49e0c5())
        return _44f54f98fdc7

    # --------------------------------------------------
    # Gemma decoder path (UNCHANGED)
    # --------------------------------------------------
    if _1939071b3c25:
        _091500a9009c = _44f54f98fdc7._44f54f98fdc7._44f54f98fdc7
        _6f952873c3a7(_091500a9009c, _44f54f98fdc7)
        _960348adc560._ec9f32dff200 = [_1cef8af46565._7741041f59ea("model.", "") for _1cef8af46565 in _960348adc560._ec9f32dff200]
        _ab0fc6094cd1 = _daa4734124f0(_091500a9009c, _960348adc560)
        _44f54f98fdc7._44f54f98fdc7._44f54f98fdc7 = _ab0fc6094cd1
        for _5a0b0709d326, _c779e9565205 in _ab0fc6094cd1._283f2fbe9348():
            _c779e9565205._a4262b00ccf9 = ("lora" in _5a0b0709d326._55fb8a49e0c5())
        return _44f54f98fdc7
    
    # --------------------------------------------------
    # Qwen decoder path (UNCHANGED)
    # --------------------------------------------------
    if _2ee43a1d5b59:
        _091500a9009c = _44f54f98fdc7._44f54f98fdc7
        _6f952873c3a7(_091500a9009c, _44f54f98fdc7)
        _960348adc560._ec9f32dff200 = [_1cef8af46565._7741041f59ea("model.", "") for _1cef8af46565 in _960348adc560._ec9f32dff200]
        _ab0fc6094cd1 = _daa4734124f0(_091500a9009c, _960348adc560)
        _44f54f98fdc7._44f54f98fdc7 = _ab0fc6094cd1
        for _5a0b0709d326, _c779e9565205 in _ab0fc6094cd1._283f2fbe9348():
            _c779e9565205._a4262b00ccf9 = ("lora" in _5a0b0709d326._55fb8a49e0c5())
        return _44f54f98fdc7

    # --------------------------------------------------
    # Embedding path (UNCHANGED)
    # --------------------------------------------------
    _decae5cdc334 = _5070722bc2c3(_328458b48142, "module", _328458b48142)

    class _6ecdd0cceb7b(_00e247c22632._18bb3a400db6._e72fe0f4642c):
        def _2b5b43b4fa73(self, _8e4f631545a9):
            _c0f6c00582c3()._6c916315e8b6()
            self._9aeace538655 = _8e4f631545a9

    _67a476a9d0f3 = _4d173276a29d(_decae5cdc334)
    _6f952873c3a7(_67a476a9d0f3, _20d1eb2d7240)

    _882fa9040314 = _daa4734124f0(_67a476a9d0f3, _960348adc560)
    _8d9ba5cf1668 = _882fa9040314._9aeace538655

    _588fcf28ebc9 = _9f158d083259._99badefb3614(".")
    _cdf18ae403d6 = _44f54f98fdc7
    for _c779e9565205 in _588fcf28ebc9[:-1]:
        _cdf18ae403d6 = _5070722bc2c3(_cdf18ae403d6, _c779e9565205)
    _203a1b22dc86(_cdf18ae403d6, _588fcf28ebc9[-1], _8d9ba5cf1668)

    for _79be0e066d15, _4f3c4ec33c1f in _8d9ba5cf1668._283f2fbe9348():
        _4f3c4ec33c1f._a4262b00ccf9 = ("lora" in _79be0e066d15._55fb8a49e0c5())

    return _44f54f98fdc7


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> "torch.nn.Module":
#     """
#     Reverse of apply_lora_to_model (focused on embedding subtree).
#     - Resolves the same embedding root as apply_lora_to_model.
#     - Prefers calling PEFT's merge API if present on the embedding wrapper.
#     - Otherwise performs a manual merge of inline lora wrappers (base_layer + lora_A/lora_B).
#     - Replaces wrapper modules with their base_layer so the final model contains plain nn.Modules.
#     - Works with ModuleDict(default=...), ParameterDict, and common lora_alpha container formats.
#     """
#     if log is None:
#         import logging
#         log = logging.getLogger(__name__)

#     import torch
#     from typing import Any, Dict

#     root = getattr(model, "module", model)

#     # --- Resolve embedding root using the same heuristics as apply_lora_to_model ---
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or known embed_tokens to apply LoRA to ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # --- Try PEFT merge if available (embedding-level) ---
#     try:
#         if hasattr(emb_current, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on embedding wrapper.")
#             merged = emb_current.merge_and_unload()
#             wrapped = merged if merged is not None else emb_current
#             # reattach to model according to emb_path (preserve wrapper if it exists)
#             try:
#                 if emb_path == "embedding":
#                     if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                         try:
#                             setattr(emb_current, "module", wrapped)
#                             model.embedding = emb_current
#                         except Exception:
#                             model.embedding = wrapped
#                     else:
#                         model.embedding = wrapped
#                 else:
#                     parts = emb_path.split(".")
#                     tgt = model
#                     for p in parts[:-1]:
#                         tgt = getattr(tgt, p)
#                     setattr(tgt, parts[-1], wrapped)
#                 log.info("PEFT embedding merge_and_unload() succeeded.")
#                 return model
#             except Exception:
#                 # if reattach fails, continue to manual merge
#                 log.warning("PEFT merge succeeded but reattach failed; continuing to manual merge.")
#         if hasattr(emb_unwrapped, "merge_and_unload"):
#             log.info("Calling merge_and_unload() on emb_unwrapped.")
#             merged = emb_unwrapped.merge_and_unload()
#             wrapped = merged if merged is not None else emb_unwrapped
#             # try to reattach preserving wrapper
#             if hasattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", wrapped)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = wrapped
#             else:
#                 parts = emb_path.split(".")
#                 tgt = model
#                 for p in parts[:-1]:
#                     tgt = getattr(tgt, p)
#                 setattr(tgt, parts[-1], wrapped)
#             log.info("PEFT emb_unwrapped merge_and_unload() succeeded.")
#             return model
#     except Exception as e:
#         log.warning("PEFT merge attempt raised: %s -- falling back to manual merge", e)

#     # --- Helpers for manual merge ---
#     def _normalize_alpha(alpha_raw):
#         # return float or None
#         try:
#             if alpha_raw is None:
#                 return None
#             if isinstance(alpha_raw, dict):
#                 # pick the first scalar-like value
#                 for v in alpha_raw.values():
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     # if v is a tensor scalar
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             continue
#                 # fallback: try first value cast
#                 try:
#                     return float(list(alpha_raw.values())[0])
#                 except Exception:
#                     return None
#             # ModuleDict or module with numeric attr/buffer
#             if hasattr(alpha_raw, "__class__") and "Module" in alpha_raw.__class__.__name__:
#                 # try attribute names
#                 for a in ("lora_alpha", "alpha"):
#                     v = getattr(alpha_raw, a, None)
#                     if isinstance(v, (int, float)):
#                         return float(v)
#                     if hasattr(v, "item"):
#                         try:
#                             return float(v.item())
#                         except Exception:
#                             pass
#                 # try parameters
#                 try:
#                     ps = list(alpha_raw.parameters())
#                     if ps:
#                         return float(ps[0].item())
#                 except Exception:
#                     pass
#                 return None
#             if isinstance(alpha_raw, (list, tuple)):
#                 if not alpha_raw:
#                     return None
#                 return float(alpha_raw[0])
#             if isinstance(alpha_raw, (int, float)):
#                 return float(alpha_raw)
#             # attempt cast
#             return float(alpha_raw)
#         except Exception:
#             return None

#     def _unwrap_map(obj) -> Dict[str, Any]:
#         """
#         Normalize lora_A / lora_B into a dict name->module/param object.
#         Accepts Module (single), ModuleDict/dict, ParameterDict-like.
#         """
#         out = {}
#         try:
#             # single module (not ModuleDict)
#             if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                 out[""] = obj
#                 return out
#         except Exception:
#             pass
#         # mapping-like
#         try:
#             items = list(obj.items())
#         except Exception:
#             items = []
#         for k, v in items:
#             out[k] = v
#         return out

#     def _tensor_from_obj(x):
#         # return a torch.Tensor (raw data) or None
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first param
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#             return None
#         if isinstance(x, torch.Tensor):
#             return x
#         return None

#     def _compute_delta(A_w, B_w, base):
#         """
#         Robustly compute delta for given A_w, B_w and base.weight shape.
#         Tries: B@A, A@B, inference from flattened tensors (reshape using base shape),
#         and chunked-sum heuristics. Raises RuntimeError if impossible.
#         """
#         # quick guards
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # common case: A 2D (r,in), B 2D (out,r) -> B@A
#         if A_w.dim() == 2 and B_w.dim() == 2 and B_w.shape[1] == A_w.shape[0]:
#             return B_w @ A_w

#         # if either is 1D (flattened), try to infer r using base shape
#         base_out = int(base.weight.shape[0])
#         base_in = int(base.weight.shape[1])
#         A_num = int(A_w.numel())
#         B_num = int(B_w.numel())

#         # attempt reshape inference: try r candidate derived from counts
#         # If B_num == base_out * r and A_num == r * base_in => reshape and B@A
#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat
#             # try candidate from A
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_w.view(r, base_in) if A_w.dim() == 1 else A_w
#                     B_mat = B_w.view(base_out, r) if B_w.dim() == 1 else B_w
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return B_mat @ A_mat

#         # try simple transpose fallbacks
#         try:
#             return B_w @ A_w
#         except Exception:
#             pass
#         try:
#             return A_w @ B_w
#         except Exception:
#             pass

#         # chunked heuristic: if one inner-dim is integer multiple of the other
#         try:
#             # promote to 2D (best-effort)
#             A_mat = A_w if A_w.dim() == 2 else A_w.view(A_w.shape[0], -1)
#             B_mat = B_w if B_w.dim() == 2 else B_w.view(-1, B_w.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_w.shape)} B={tuple(B_w.shape)} for base {tuple(base.weight.shape)}")

#     # --- Manual merge walk under embedding subtree ---
#     merged = 0
#     replaced = 0
#     # iterate parents so we can setattr on them
#     for parent in list(emb_unwrapped.modules()):
#         for child_name, child in list(parent.named_children()):
#             # target wrappers: have base_layer and lora_A/lora_B
#             if not hasattr(child, "base_layer"):
#                 continue
#             if not (hasattr(child, "lora_A") and hasattr(child, "lora_B")):
#                 # attempt simple unwraps (module/base_layer) to remove wrapper objects
#                 try:
#                     if hasattr(child, "module") and child is not getattr(child, "module"):
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> module", type(parent).__name__, child_name)
#                         continue
#                     if hasattr(child, "base_layer"):
#                         setattr(parent, child_name, getattr(child, "base_layer"))
#                         replaced += 1
#                         log.info("Unwrapped %s.%s -> base_layer", type(parent).__name__, child_name)
#                         continue
#                 except Exception:
#                     pass
#                 continue

#             base = getattr(child, "base_layer", None)
#             if base is None or not hasattr(base, "weight"):
#                 log.warning("Skipping %s: no base_layer.weight", child_name)
#                 continue

#             # normalize maps
#             A_map = _unwrap_map(getattr(child, "lora_A", None))
#             B_map = _unwrap_map(getattr(child, "lora_B", None))
#             if not A_map or not B_map:
#                 # attempt remove wrapper if no A/B entries
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (empty A/B).", child_name)
#                 except Exception:
#                     log.warning("Could not replace empty wrapper %s", child_name)
#                 continue

#             # normalize alpha
#             alpha_raw = getattr(child, "lora_alpha", None)
#             alpha = _normalize_alpha(alpha_raw)

#             applied_here = 0
#             # iterate keys (broadcast single->many by using "" key)
#             keys = sorted(set(A_map.keys()) | set(B_map.keys()))
#             for k in keys:
#                 A_obj = A_map.get(k) or A_map.get("")
#                 B_obj = B_map.get(k) or B_map.get("")
#                 A_w = _tensor_from_obj(A_obj)
#                 B_w = _tensor_from_obj(B_obj)
#                 if A_w is None or B_w is None:
#                     log.debug("Skipping %s key=%s: A/B tensor not found", child_name, k)
#                     continue

#                 # handle zero-length adapters by removing wrapper aggressively (safe for plain model)
#                 if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                     log.warning("Empty/zero-dim A/B for %s key=%s — replacing wrapper with base.", child_name, k)
#                     try:
#                         setattr(parent, child_name, base)
#                         replaced += 1
#                         applied_here = 0
#                     except Exception as e:
#                         log.warning("Could not replace wrapper %s: %s", child_name, e)
#                     break  # move to next child

#                 try:
#                     # compute delta robustly
#                     delta = _compute_delta(A_w, B_w, base)
#                     # scale detection r and alpha
#                     r = A_w.shape[0] if A_w.dim() >= 1 else None
#                     scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0
#                     # apply under no_grad
#                     with torch.no_grad():
#                         base.weight.data += delta.to(base.weight.device, base.weight.dtype) * scale
#                     applied_here += 1
#                     merged += 1
#                     log.info("Merged LoRA into %s key=%s (scale=%s, delta_shape=%s)", child_name, k, scale, tuple(delta.shape))
#                 except Exception as e:
#                     log.warning("Failed computing LoRA delta for %s key=%s: %s", child_name, k, e)
#                     # continue trying other keys

#             # after keys processed, if any applied -> replace wrapper with base
#             if applied_here > 0:
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base after applying %d delta(s).", child_name, applied_here)
#                 except Exception as e:
#                     log.warning("Applied deltas but failed to replace wrapper %s: %s", child_name, e)
#             else:
#                 # no deltas applied; still try to remove wrapper for Lightning compatibility
#                 try:
#                     setattr(parent, child_name, base)
#                     replaced += 1
#                     log.info("Replaced wrapper %s with base (no deltas applied).", child_name)
#                 except Exception as e:
#                     log.warning("Could not replace wrapper %s: %s", child_name, e)

#     # Reattach emb_unwrapped back to model if necessary (preserve wrapper object when possible)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # already mutated in-place for wrappers we replaced above; ignore attach errors
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers.", merged, replaced)
#     log.info(f"Model Structure after removing LoRA {model}")
#     return model


# def merge_lora_into_base(
#     model: "torch.nn.Module",
#     log: "Any" = None
# ) -> Tuple["torch.nn.Module", Dict[str, Any]]:
#     """
#     Reverse of apply_lora_to_model. Minimal-disruption strategy:
#       1) Try PEFT's merge APIs on high-level wrappers (safe).
#       2) If not available, do conservative manual merges:
#          - Only add computed LoRA delta into base.weight when base.weight.dtype is floating.
#          - If base.weight is quantized / non-floating (Byte/Int) or wrapper weight shapes mismatch,
#            skip numeric merge and replace wrapper with base_layer/module to avoid corrupting quant params.
#       3) Always replace wrapper modules with underlying base module to remove PEFT wrappers (so model is runnable).
#     Returns: (model, summary)
#       summary: {merged: int, replaced: int, skipped: int, warnings: [..], details: [..]}
#     """
#     if log is None:
#         log = logging.getLogger(__name__)

#     summary = {"merged": 0, "replaced": 0, "skipped": 0, "warnings": [], "details": []}

#     root = getattr(model, "module", model)

#     # same embedding resolver as apply_lora_to_model
#     def _resolve_embedding_root(obj):
#         if hasattr(obj, "embedding"):
#             return getattr(obj, "embedding"), "embedding"
#         if hasattr(obj, "model") and hasattr(obj.model, "embed_tokens"):
#             return getattr(obj.model, "embed_tokens"), "model.embed_tokens"
#         if hasattr(obj, "model") and hasattr(obj.model, "model") and hasattr(obj.model.model, "embed_tokens"):
#             return getattr(obj.model.model, "embed_tokens"), "model.model.embed_tokens"
#         if hasattr(obj, "transformer") and hasattr(obj.transformer, "wte"):
#             return getattr(obj.transformer, "wte"), "transformer.wte"
#         if hasattr(obj, "base_model") and hasattr(obj.base_model, "model") and hasattr(obj.base_model.model, "embed_tokens"):
#             return getattr(obj.base_model.model, "embed_tokens"), "base_model.model.embed_tokens"
#         raise ValueError(f"Top-level model has no attribute 'embedding' or a known embed_tokens ({obj.__class__.__name__})")

#     try:
#         emb_current, emb_path = _resolve_embedding_root(model)
#     except Exception as e:
#         raise ValueError(f"Could not resolve embedding root: {e}")

#     # operate on the unwrapped module (embedding.module if present)
#     emb_unwrapped = getattr(emb_current, "module", emb_current)

#     # helper: attempt PEFT merge_and_unload on an object (safe)
#     def _try_peft_merge(obj, ctx_name: str) -> bool:
#         for attr in ("merge_and_unload", "merge_and_unload_legacy", "merge", "unload"):
#             fn = getattr(obj, attr, None)
#             if callable(fn):
#                 try:
#                     log.info("Calling %s() on %s", attr, ctx_name)
#                     res = fn()  # many APIs return None, some return the merged/base module
#                     summary["details"].append(f"Called {attr} on {ctx_name}")
#                     summary["merged"] += 1
#                     # if function returned a module, try to reattach above after caller handles
#                     return True
#                 except Exception as e:
#                     summary["warnings"].append(f"{ctx_name}.{attr}() raised: {e}")
#                     # continue trying other attrs
#         return False

#     # try high-level merges first (LLaMA decoder path)
#     try:
#         is_llama_decoder = (
#             hasattr(model, "embedding")
#             and hasattr(model.embedding, "model")
#             and hasattr(model.embedding.model, "layers")
#         )
#     except Exception:
#         is_llama_decoder = False

#     if is_llama_decoder:
#         # top-level peft wrapper might be model.embedding.model or model.embedding.model.* (PeftModelForCausalLM)
#         decoder = model.embedding.model
#         attached = False
#         # If decoder is a Peft wrapper, try calling merge_and_unload on it
#         if _try_peft_merge(decoder, "model.embedding.model"):
#             # after merge, try to reassign if merge returned something — some APIs inplace-change
#             # we still proceed to safer manual unwrapping pass later to catch nested wrappers
#             attached = True
#         # also try top-level embedding wrapper
#         if _try_peft_merge(model.embedding, "model.embedding"):
#             attached = True

#         # perform conservative unwrap / manual merge walk under decoder subtree
#         # We'll traverse decoder modules and apply manual merge only for floating base weights.
#         summary_walk = _manual_merge_walk(decoder, log, summary)  # function defined below
#         summary.update(summary_walk)
#         # ensure model.embedding.model remains set (if libra returned new module, it's usually already attached)
#         return model, summary

#     # Non-llama path: embedding container was created by apply -> there is an emb_unwrapped that got wrapped by PEFT.
#     # Try peft merge on emb_current (wrapper) and on emb_unwrapped
#     if _try_peft_merge(emb_current, f"{emb_path} (emb_current)"):
#         # PEFT merge done (or attempted). Still walk and clean wrappers to ensure no leftover fields.
#         pass
#     elif _try_peft_merge(emb_unwrapped, f"{emb_path} (emb_unwrapped)"):
#         pass

#     # if PEFT merge didn't exist/ succeed, fallback to conservative manual merging
#     summary_walk = _manual_merge_walk(emb_unwrapped, log, summary)
#     summary.update(summary_walk)

#     # Reattach candidate back to model (preserve wrapperless object)
#     try:
#         candidate = getattr(emb_unwrapped, "module", emb_unwrapped)
#         if emb_path == "embedding":
#             # try preserve wrapper object if existed
#             if hasattr(emb_current, "module") and emb_current is not getattr(emb_current, "module"):
#                 try:
#                     setattr(emb_current, "module", candidate)
#                     model.embedding = emb_current
#                 except Exception:
#                     model.embedding = candidate
#             else:
#                 model.embedding = candidate
#         else:
#             parts = emb_path.split(".")
#             tgt = model
#             for p in parts[:-1]:
#                 tgt = getattr(tgt, p)
#             setattr(tgt, parts[-1], candidate)
#     except Exception:
#         # ignore reattach errors; model already mutated in place for replaced wrappers
#         pass

#     log.info("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.",
#              summary.get("merged", 0), summary.get("replaced", 0), summary.get("skipped", 0))
#     return model


# Helper: manual merge walker (conservative)
# def _manual_merge_walk(root_module: "torch.nn.Module", log: Any, summary: Dict[str, Any]) -> Dict[str, Any]:
#     """
#     Walk modules under `root_module` and:
#       - For children that have .base_layer and lora_A/lora_B try to compute delta and add to base.weight
#         ONLY IF base.weight.dtype is floating (float32/float16/bfloat16).
#       - If base.weight is quantized/non-floating or shapes are incompatible, replace wrapper with base
#         (no numeric merge) to avoid corrupting quant metadata.
#       - If child has .module wrapper (PEFT/other), replace with child.module
#     Returns partial summary updates.
#     """
#     import torch
#     merged = summary.get("merged", 0)
#     replaced = summary.get("replaced", 0)
#     skipped = summary.get("skipped", 0)

#     def _is_floating_dtype(dt):
#         return dt in (torch.float32, torch.float16, torch.bfloat16)

#     def _tensor_from_obj(x):
#         if x is None:
#             return None
#         if isinstance(x, torch.nn.Parameter):
#             return x.data
#         if isinstance(x, torch.Tensor):
#             return x
#         # Module: try weight param
#         if isinstance(x, torch.nn.Module):
#             w = getattr(x, "weight", None)
#             if isinstance(w, torch.nn.Parameter):
#                 return w.data
#             # try first parameter
#             try:
#                 p = next(x.parameters())
#                 return p.data
#             except Exception:
#                 pass
#             # try first buffer
#             try:
#                 b = next(x.buffers())
#                 return b
#             except Exception:
#                 pass
#         return None

#     def _compute_delta(A_w, B_w, base_w):
#         """
#         Robust compute similar to previous logic; returns tensor on CPU (float) if possible.
#         Will raise RuntimeError if impossible.
#         """
#         if A_w is None or B_w is None:
#             raise RuntimeError("A_w or B_w is None")
#         if A_w.numel() == 0 or B_w.numel() == 0:
#             raise RuntimeError("empty A/B")

#         # Bring tensors to float32 cpu for computation (do not change original module tensors)
#         A_f = A_w.detach().to(torch.float32).cpu()
#         B_f = B_w.detach().to(torch.float32).cpu()

#         # common: A (r, in), B (out, r) => B @ A
#         if A_f.dim() == 2 and B_f.dim() == 2 and B_f.shape[1] == A_f.shape[0]:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)

#         # try reshape inference using base shape
#         base_out = int(base_w.shape[0])
#         base_in = int(base_w.shape[1])
#         A_num = int(A_f.numel())
#         B_num = int(B_f.numel())

#         if base_out > 0 and base_in > 0:
#             if (B_num % base_out == 0):
#                 r = B_num // base_out
#                 if r > 0 and (A_num == r * base_in):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)
#             if (A_num % base_in == 0):
#                 r = A_num // base_in
#                 if r > 0 and (B_num == base_out * r):
#                     A_mat = A_f.view(r, base_in) if A_f.dim() == 1 else A_f
#                     B_mat = B_f.view(base_out, r) if B_f.dim() == 1 else B_f
#                     if B_mat.shape[1] == A_mat.shape[0]:
#                         return (B_mat @ A_mat).to(base_w.device, dtype=base_w.dtype)

#         # fallbacks
#         try:
#             return (B_f @ A_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass
#         try:
#             return (A_f @ B_f).to(base_w.device, dtype=base_w.dtype)
#         except Exception:
#             pass

#         # chunked heuristics (rare)
#         try:
#             A_mat = A_f if A_f.dim() == 2 else A_f.view(A_f.shape[0], -1)
#             B_mat = B_f if B_f.dim() == 2 else B_f.view(-1, B_f.shape[0])
#         except Exception:
#             raise RuntimeError(f"cannot promote A/B to 2D for shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)}")

#         b_inner = B_mat.shape[1]
#         a_rows = A_mat.shape[0]
#         if a_rows and b_inner and (b_inner % a_rows == 0):
#             n_chunks = b_inner // a_rows
#             out_dim = B_mat.shape[0]
#             B_chunks = B_mat.view(out_dim, n_chunks, a_rows)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_chunks[:, i, :] @ A_mat
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)
#         if a_rows and b_inner and (a_rows % b_inner == 0):
#             n_chunks = a_rows // b_inner
#             in_dim = A_mat.shape[1]
#             A_chunks = A_mat.view(n_chunks, b_inner, in_dim)
#             delta = None
#             for i in range(n_chunks):
#                 part = B_mat @ A_chunks[i]
#                 delta = part if delta is None else (delta + part)
#             return delta.to(base_w.device, dtype=base_w.dtype)

#         raise RuntimeError(f"unsupported A/B shapes A={tuple(A_f.shape)} B={tuple(B_f.shape)} for base {tuple(base_w.shape)}")

#     # iterate parents so we can setattr on them
#     for parent in list(root_module.modules()):
#         for child_name, child in list(parent.named_children()):
#             # 1) If wrapper exposes PEFT API, try merge_and_unload first
#             try:
#                 if hasattr(child, "merge_and_unload") and callable(getattr(child, "merge_and_unload")):
#                     try:
#                         log.info("Calling merge_and_unload() on %s.%s", type(parent).__name__, child_name)
#                         child.merge_and_unload()
#                         # After PEFT merge, if child has module/base_layer then replace
#                         repl = getattr(child, "module", None) or getattr(child, "base_layer", None) or getattr(child, "base_model", None)
#                         if repl is not None and repl is not child:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"PEFT merged & replaced {type(parent).__name__}.{child_name}")
#                             continue
#                         else:
#                             # if merge_and_unload didn't return module, try to just remove wrapper by replacing with base if exists
#                             base = getattr(child, "base_layer", None) or getattr(child, "module", None)
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"PEFT merged (no return) and replaced {type(parent).__name__}.{child_name}")
#                                 continue
#                     except Exception as e:
#                         summary["warnings"].append(f"child.merge_and_unload failed {type(parent).__name__}.{child_name}: {e}")
#                         # fallthrough to manual strategies
#                 # 2) If there is a 'module' wrapper, unwrap it (safe)
#                 if hasattr(child, "module") and child is not getattr(child, "module"):
#                     try:
#                         setattr(parent, child_name, getattr(child, "module"))
#                         replaced += 1
#                         summary["details"].append(f"Unwrapped module {type(parent).__name__}.{child_name} -> module")
#                         continue
#                     except Exception:
#                         pass

#                 # 3) If base_layer + lora_A/lora_B perform conservative numeric merge only if base is floating dtype
#                 if hasattr(child, "base_layer") and (hasattr(child, "lora_A") or hasattr(child, "lora_B")):
#                     base = getattr(child, "base_layer", None)
#                     if base is None or not hasattr(base, "weight"):
#                         # can't merge numerically; just replace wrapper with base if possible
#                         try:
#                             if base is not None:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no weight to merge)")
#                                 continue
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base")
#                             skipped += 1
#                             continue

#                     # get A/B tensors (may be ModuleDict / dict / Parameter)
#                     A_obj = getattr(child, "lora_A", None)
#                     B_obj = getattr(child, "lora_B", None)

#                     # support mappinglike or direct module
#                     def _unwrap_map(obj):
#                         out = {}
#                         if obj is None:
#                             return out
#                         if isinstance(obj, torch.nn.Module) and not isinstance(obj, torch.nn.ModuleDict):
#                             out[""] = obj
#                             return out
#                         # mapping-like
#                         try:
#                             items = list(obj.items())
#                         except Exception:
#                             items = []
#                         for k, v in items:
#                             out[k] = v
#                         return out

#                     A_map = _unwrap_map(A_obj)
#                     B_map = _unwrap_map(B_obj)
#                     if not A_map or not B_map:
#                         # nothing numeric to merge; replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (empty A/B)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace empty wrapper {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # check dtype of base weight -> only attempt numeric merge for floating dtypes
#                     base_w = base.weight if hasattr(base, "weight") else None
#                     if base_w is None:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name} with base (no base.weight)")
#                             skipped += 1
#                         continue

#                     if not _is_floating_dtype(base_w.dtype):
#                         # quantized or non-floating base: avoid numeric merge; simply replace wrapper with base
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Skipped numeric merge for quantized base {type(parent).__name__}.{child_name}; replaced wrapper with base")
#                         except Exception:
#                             summary["warnings"].append(f"Could not replace wrapper for quantized base {type(parent).__name__}.{child_name}")
#                             skipped += 1
#                         continue

#                     # attempt per-key merge
#                     applied_here = 0
#                     for k in sorted(set(A_map.keys()) | set(B_map.keys())):
#                         A_obj_k = A_map.get(k) or A_map.get("")
#                         B_obj_k = B_map.get(k) or B_map.get("")
#                         A_w = _tensor_from_obj(A_obj_k)
#                         B_w = _tensor_from_obj(B_obj_k)
#                         if A_w is None or B_w is None:
#                             summary["details"].append(f"Skipping key={k} for {type(parent).__name__}.{child_name}: A/B tensor not found")
#                             continue

#                         # check empty shapes
#                         if A_w.numel() == 0 or B_w.numel() == 0 or (0 in getattr(A_w, "shape", ())) or (0 in getattr(B_w, "shape", ())):
#                             # unsafe to compute; replace wrapper
#                             try:
#                                 setattr(parent, child_name, base)
#                                 replaced += 1
#                                 summary["details"].append(f"Empty/zero-dim A/B for {type(parent).__name__}.{child_name} key={k}; replaced with base")
#                             except Exception as e:
#                                 summary["warnings"].append(f"Could not replace wrapper after empty A/B {type(parent).__name__}.{child_name}: {e}")
#                                 skipped += 1
#                             applied_here = 0
#                             break

#                         try:
#                             delta = _compute_delta(A_w, B_w, base_w)
#                             # detect r for scaling; fallback scale 1.0 if unknown
#                             r = None
#                             try:
#                                 r = int(A_w.shape[0]) if getattr(A_w, "dim", None) and A_w.dim() >= 1 else None
#                             except Exception:
#                                 r = None
#                             alpha_raw = getattr(child, "lora_alpha", None)
#                             alpha = None
#                             # attempt to normalize alpha scalar
#                             try:
#                                 if alpha_raw is None:
#                                     alpha = None
#                                 elif isinstance(alpha_raw, (int, float)):
#                                     alpha = float(alpha_raw)
#                                 elif isinstance(alpha_raw, dict):
#                                     # pick first numeric
#                                     for vv in alpha_raw.values():
#                                         if isinstance(vv, (int, float)):
#                                             alpha = float(vv)
#                                             break
#                                 elif hasattr(alpha_raw, "item"):
#                                     alpha = float(alpha_raw.item())
#                             except Exception:
#                                 alpha = None
#                             scale = (float(alpha) / float(r)) if (alpha is not None and r) else 1.0

#                             with torch.no_grad():
#                                 base_w.data += delta.to(base_w.device, base_w.dtype) * float(scale)
#                             applied_here += 1
#                             merged += 1
#                             summary["details"].append(f"Merged LoRA into {type(parent).__name__}.{child_name} key={k} (scale={scale}, delta={tuple(delta.shape)})")
#                         except Exception as e:
#                             summary["warnings"].append(f"Failed computing LoRA delta for {type(parent).__name__}.{child_name} key={k}: {e}")
#                             # do not abort — try other keys

#                     # after keys processed: if we applied any merges, replace wrapper with base
#                     if applied_here > 0:
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base after applying {applied_here} deltas")
#                         except Exception as e:
#                             summary["warnings"].append(f"Applied deltas but failed to replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1
#                     else:
#                         # no deltas applied -> replace wrapper anyway
#                         try:
#                             setattr(parent, child_name, base)
#                             replaced += 1
#                             summary["details"].append(f"Replaced wrapper {type(parent).__name__}.{child_name} with base (no deltas applied)")
#                         except Exception as e:
#                             summary["warnings"].append(f"Could not replace wrapper {type(parent).__name__}.{child_name}: {e}")
#                             skipped += 1

#                     continue  # next child

#                 # 4) base_model / model attribute replacement (PeftModel wrappers)
#                 if hasattr(child, "base_model") and getattr(child, "base_model") is not None and getattr(child, "base_model") is not child:
#                     try:
#                         setattr(parent, child_name, getattr(child, "base_model"))
#                         replaced += 1
#                         summary["details"].append(f"Replaced {type(parent).__name__}.{child_name} with base_model")
#                         continue
#                     except Exception:
#                         pass

#                 # 5) SafeModuleWrapper unwrapping
#                 cname = child.__class__.__name__.lower()
#                 if "safemodulewrapper" in cname or cname.startswith("_safemodulewrapper"):
#                     repl = getattr(child, "module", None)
#                     if repl is not None:
#                         try:
#                             setattr(parent, child_name, repl)
#                             replaced += 1
#                             summary["details"].append(f"Unwrapped SafeModuleWrapper {type(parent).__name__}.{child_name}")
#                             continue
#                         except Exception:
#                             pass

#                 # If none matched — skip safely
#                 skipped += 1
#                 summary["details"].append(f"Skipped {type(parent).__name__}.{child_name} (no wrapper/base_layer found)")
#             except Exception as e_parent_child:
#                 summary["warnings"].append(f"Error while inspecting {type(parent).__name__}.{child_name}: {e_parent_child}")
#                 skipped += 1
#                 continue

#     # update and return summary diffs
#     summary["merged"] = merged
#     summary["replaced"] = replaced
#     summary["skipped"] = skipped
#     return summary

# def merge_lora_into_base(model, log=None):
#     if log is None:
#         log = logging.getLogger(__name__)

#     # Find the PEFT-wrapped decoder (your custom path)
#     if hasattr(model, "embedding") and hasattr(model.embedding, "model"):
#         decoder = model.embedding.model

#         # Check if it's a PEFT model
#         if hasattr(decoder, "merge_and_unload"):
#             try:
#                 log.info("Merging LoRA using PEFT's native merge (this works)")
#                 merged_decoder = decoder.merge_and_unload()
#                 model.embedding.model = merged_decoder
#                 del decoder  # frees the old PEFT model + all LoRA tensors
#                 if torch.cuda.is_available():
#                     torch.cuda.empty_cache()
#                 log.info("LoRA merged successfully — no warnings, no errors")
#                 return model
#             except Exception as e:
#                 log.error(f"PEFT merge failed: {e}")

#     # Fallback: manual merge (your old code) — but now it will find nothing, so skip
#     log.info("No PEFT wrapper found — skipping manual merge (already clean or not needed)")
#     return model

def _c2883670c0de(_44f54f98fdc7, _42f22744a6db=_b876a71f50d0):
    if _42f22744a6db is _b876a71f50d0:
        _42f22744a6db = _c8c2cc9b9935._4403048d4f25(__name__)

    _20d1eb2d7240 = _5070722bc2c3(_44f54f98fdc7, "module", _44f54f98fdc7)

    def _06b6d9d505f3(_1e62e4e952d8, _24d74a8e18a8):
        if _4c094ac0ff32(_1e62e4e952d8, "merge_and_unload"):
            _42f22744a6db._00afa095dbb3("Merging LoRA via PEFT merge_and_unload")
            _1ef8d01a7437 = _1e62e4e952d8._7831ea637366()
            _24d74a8e18a8(_1ef8d01a7437)
            if _00e247c22632._8b2a182fd222._6ad7116d3a22():
                _00e247c22632._8b2a182fd222._04bd08059fe0()
            _42f22744a6db._00afa095dbb3("LoRA merged successfully")
            return _e683ba20d11f
        return _5391a231e8c1

    # Decoder path (Lightning-safe)
    if _4c094ac0ff32(_20d1eb2d7240, "embedding") and _4c094ac0ff32(_20d1eb2d7240._9aeace538655, "model"):
        if _2a864bbc1bc8(
            _20d1eb2d7240._9aeace538655._44f54f98fdc7,
            lambda _b0c20907d06e: _203a1b22dc86(_20d1eb2d7240._9aeace538655, "model", _b0c20907d06e),
        ):
            return _44f54f98fdc7

    # Embedding path
    if _4c094ac0ff32(_20d1eb2d7240, "embedding"):
        if _2a864bbc1bc8(
            _20d1eb2d7240._9aeace538655,
            lambda _b0c20907d06e: _203a1b22dc86(_20d1eb2d7240, "embedding", _b0c20907d06e),
        ):
            return _44f54f98fdc7

    _42f22744a6db._00afa095dbb3("No PEFT LoRA adapters found — nothing to merge")
    return _44f54f98fdc7


def _fc6df135eb1b(_44f54f98fdc7: "torch.nn.Module") -> "torch.nn.Module":
    """
    Quantize all frozen Linear and Conv1d layers in the given model using bitsandbytes.
    Uses NF4 for Linear (text models) and FP4 for Conv1d (image/audio models).
    Leaves LoRA and trainable modules untouched.
    Safe: skips missing weights or broken layers automatically.
    """
    import _5f47154b5791
    import _00e247c22632
    import _46067c4ed288 as _3dfbbd95c519

    _adbee513002b = _d8fb8268e714(_44f54f98fdc7._daccf771899e())[::-1]  # bottom-up traversal

    for _79be0e066d15, _2384cc3c79d8 in _adbee513002b:
        if _7d468eab525d(_2384cc3c79d8, (_00e247c22632._18bb3a400db6._8945a0d8b000, _00e247c22632._18bb3a400db6._48cc91be63f4)):
            # Skip LoRA or trainable layers
            if "lora" in _79be0e066d15._55fb8a49e0c5() or _4cdec87f57ce(_c779e9565205._a4262b00ccf9 for _c779e9565205 in _2384cc3c79d8._27ed244b4e2c()):
                continue

            try:
                _1dcd2ea8d951 = "nf4" if _7d468eab525d(_2384cc3c79d8, _00e247c22632._18bb3a400db6._8945a0d8b000) else "fp4"

                _74de9763dff9 = _5070722bc2c3(_2384cc3c79d8, "in_features", _2384cc3c79d8._33c92757a541._19ce19392eba[1])
                _5dc60f8b20e0 = _5070722bc2c3(_2384cc3c79d8, "out_features", _2384cc3c79d8._33c92757a541._19ce19392eba[0])

                _363222b3325b = _3dfbbd95c519._18bb3a400db6._ea0729e3a7cc(
                    _74de9763dff9, _5dc60f8b20e0,
                    _e6d546f8d718=_2384cc3c79d8._e6d546f8d718 is not _b876a71f50d0,
                    _a54d8f5a4e15=_d62f26344c57(),
                    _1dcd2ea8d951=_1dcd2ea8d951
                )

                if _2384cc3c79d8._33c92757a541 is _b876a71f50d0 or not _4c094ac0ff32(_2384cc3c79d8._33c92757a541, "data"):
                    continue

                _363222b3325b._33c92757a541._0ea2642c3b08._c6ef006387a7(_2384cc3c79d8._33c92757a541._0ea2642c3b08)
                if _2384cc3c79d8._e6d546f8d718 is not _b876a71f50d0:
                    _363222b3325b._e6d546f8d718._0ea2642c3b08._c6ef006387a7(_2384cc3c79d8._e6d546f8d718._0ea2642c3b08)

                # Replace in parent
                _c5c5bc376857 = _44f54f98fdc7
                _588fcf28ebc9 = _79be0e066d15._99badefb3614(".")
                for _c779e9565205 in _588fcf28ebc9[:-1]:
                    _c5c5bc376857 = _5070722bc2c3(_c5c5bc376857, _c779e9565205)
                _203a1b22dc86(_c5c5bc376857, _588fcf28ebc9[-1], _363222b3325b)

                del _2384cc3c79d8
                _5f47154b5791._f98626c15d3e()
                if _00e247c22632._8b2a182fd222._6ad7116d3a22():
                    _00e247c22632._8b2a182fd222._04bd08059fe0()

            except _ef4342e2a44a as _0e61792e875a:
                _1ce48d625e58(f"[WARN] Skipped quantizing {_79be0e066d15}: {_0e61792e875a}")

    return _44f54f98fdc7


# def quantize_frozen_linear_layers(model: "torch.nn.Module") -> "torch.nn.Module":
#     """
#     Manually quantize all frozen torch.nn.Linear layers in the given model to 4-bit precision using bitsandbytes.
#     Leaves all LoRA or trainable modules untouched (those containing 'lora' in name or requiring gradients).

#     Args:
#         model (torch.nn.Module): The model instance to quantize (after LoRA is applied).

#     Returns:
#         torch.nn.Module: The same model instance with frozen Linear layers replaced by 4-bit quantized versions.
#     """
#     import bitsandbytes as bnb
#     from bitsandbytes.nn import Params4bit

#     modules = list(model.named_modules())  # snapshot to avoid OrderedDict mutation

#     for name, module in modules:
#         # Quantize only standard Linear layers that are frozen
#         if isinstance(module, torch.nn.Linear):
#             if "lora" in name.lower() or any(param.requires_grad for param in module.parameters()):
#                 continue  # skip LoRA or active trainable layers

#             # Create quantized Linear4bit replacement
#             quantized = bnb.nn.Linear4bit(
#                 module.in_features,
#                 module.out_features,
#                 bias=module.bias is not None,
#                 compute_dtype=get_supported_compute_dtype(),
#                 compress_statistics=True,
#                 quant_type="nf4"
#             )

#             # Properly quantize and assign weight
#             quantized.weight = Params4bit(
#                 module.weight.data,
#                 compress_statistics=True,
#                 quant_type="nf4",
#                 quant_storage=torch.uint8
#             )

#             # Copy bias if exists
#             if module.bias is not None:
#                 quantized.bias = module.bias.clone()

#             # Replace the original module in its parent container
#             parent = model
#             parts = name.split(".")
#             for p in parts[:-1]:
#                 parent = getattr(parent, p)
#             setattr(parent, parts[-1], quantized)

#     return model

def _c2883670c0de(_44f54f98fdc7: "torch.nn.Module", _42f22744a6db: "Any" = _b876a71f50d0) -> "torch.nn.Module":
    """
    Merge LoRA adapters into base layers (robust heuristics) and then aggressively
    remove/unwrap PEFT/LoRA wrapper objects so the final model no longer reports
    "LoRA present" / "PEFT present".
    """
    if _42f22744a6db is _b876a71f50d0:
        _42f22744a6db = _c8c2cc9b9935._4403048d4f25(__name__)

    _1ef8d01a7437 = 0
    _d8812092fe26 = 0
    _f1f1440fcd04 = []

    # helper to get first tensor-like from many container types
    def _f5f95c0fe3e2(_14341d9c5b92):
        if _14341d9c5b92 is _b876a71f50d0:
            return _b876a71f50d0
        if _7d468eab525d(_14341d9c5b92, _00e247c22632._18bb3a400db6._b923b6951d7a):
            return _14341d9c5b92._0ea2642c3b08
        if _7d468eab525d(_14341d9c5b92, _00e247c22632._8ebfa8cab825):
            return _14341d9c5b92
        if _7d468eab525d(_14341d9c5b92, _00e247c22632._18bb3a400db6._e72fe0f4642c):
            _cfa941c9a2b9 = _5070722bc2c3(_14341d9c5b92, "weight", _b876a71f50d0)
            if _7d468eab525d(_cfa941c9a2b9, _00e247c22632._18bb3a400db6._b923b6951d7a):
                return _cfa941c9a2b9._0ea2642c3b08
            try:
                _c779e9565205 = _a240feac9f36(_14341d9c5b92._27ed244b4e2c())
                return _c779e9565205._0ea2642c3b08
            except _ef4342e2a44a:
                pass
            try:
                _ec4f26c33fdf = _a240feac9f36(_14341d9c5b92._99e9740bf744())
                return _ec4f26c33fdf
            except _ef4342e2a44a:
                pass
            return _b876a71f50d0
        # dict-like or ModuleDict-like: return first tensor we can
        try:
            for _6e7364d94da7 in _5070722bc2c3(_14341d9c5b92, "values", lambda: [])():
                _1cef8af46565 = _2ec413cfc398(_6e7364d94da7)
                if _1cef8af46565 is not _b876a71f50d0:
                    return _1cef8af46565
        except _ef4342e2a44a:
            pass
        try:
            for _, _6e7364d94da7 in _5070722bc2c3(_14341d9c5b92, "items", lambda: [])():
                _1cef8af46565 = _2ec413cfc398(_6e7364d94da7)
                if _1cef8af46565 is not _b876a71f50d0:
                    return _1cef8af46565
        except _ef4342e2a44a:
            pass
        return _b876a71f50d0

    def _98d8483a04e8(_8cd5e66f0390: _00e247c22632._8ebfa8cab825, _879f35d4b45c: _00e247c22632._8ebfa8cab825, _88e9c596d595: _00e247c22632._8ebfa8cab825):
        _c4138b9dd446 = _8cd5e66f0390._caa8517a63ca()._50896461db26()
        _6a11f81a1fe7 = _879f35d4b45c._caa8517a63ca()._50896461db26()
        # common 2D case
        if _c4138b9dd446._2ff02c1d78f5() == 2 and _6a11f81a1fe7._2ff02c1d78f5() == 2 and _6a11f81a1fe7._19ce19392eba[1] == _c4138b9dd446._19ce19392eba[0]:
            return _6a11f81a1fe7 @ _c4138b9dd446
        # try reshape inference based on base shape
        _37ea61cace6c = _2a2f511f2602(_88e9c596d595._19ce19392eba[0])
        _77911692cc52 = _2a2f511f2602(_88e9c596d595._19ce19392eba[1]) if _88e9c596d595._2ff02c1d78f5() > 1 else 1
        _70c5ca9edada = _c4138b9dd446._6d3a0db41b1c()
        _e17243e85595 = _6a11f81a1fe7._6d3a0db41b1c()
        if _37ea61cace6c > 0 and _77911692cc52 > 0:
            if (_e17243e85595 % _37ea61cace6c == 0):
                _e2b6f35f65dc = _e17243e85595 // _37ea61cace6c
                if _e2b6f35f65dc > 0 and (_70c5ca9edada == _e2b6f35f65dc * _77911692cc52):
                    _d18b39bd18b2 = _c4138b9dd446._33d4effa84ed(_e2b6f35f65dc, _77911692cc52) if _c4138b9dd446._2ff02c1d78f5() == 1 else _c4138b9dd446
                    _46bf76727572 = _6a11f81a1fe7._33d4effa84ed(_37ea61cace6c, _e2b6f35f65dc) if _6a11f81a1fe7._2ff02c1d78f5() == 1 else _6a11f81a1fe7
                    if _46bf76727572._19ce19392eba[1] == _d18b39bd18b2._19ce19392eba[0]:
                        return _46bf76727572 @ _d18b39bd18b2
            if (_70c5ca9edada % _77911692cc52 == 0):
                _e2b6f35f65dc = _70c5ca9edada // _77911692cc52
                if _e2b6f35f65dc > 0 and (_e17243e85595 == _37ea61cace6c * _e2b6f35f65dc):
                    _d18b39bd18b2 = _c4138b9dd446._33d4effa84ed(_e2b6f35f65dc, _77911692cc52) if _c4138b9dd446._2ff02c1d78f5() == 1 else _c4138b9dd446
                    _46bf76727572 = _6a11f81a1fe7._33d4effa84ed(_37ea61cace6c, _e2b6f35f65dc) if _6a11f81a1fe7._2ff02c1d78f5() == 1 else _6a11f81a1fe7
                    if _46bf76727572._19ce19392eba[1] == _d18b39bd18b2._19ce19392eba[0]:
                        return _46bf76727572 @ _d18b39bd18b2
        # fallback tries
        try:
            return _6a11f81a1fe7 @ _c4138b9dd446
        except _ef4342e2a44a:
            pass
        # chunked heuristics
        try:
            _d18b39bd18b2 = _c4138b9dd446 if _c4138b9dd446._2ff02c1d78f5() == 2 else _c4138b9dd446._33d4effa84ed(_c4138b9dd446._19ce19392eba[0], -1)
            _46bf76727572 = _6a11f81a1fe7 if _6a11f81a1fe7._2ff02c1d78f5() == 2 else _6a11f81a1fe7._33d4effa84ed(-1, _6a11f81a1fe7._19ce19392eba[0])
        except _ef4342e2a44a as _0e61792e875a:
            raise _27943ad7dfc8(f"cannot promote A/B to 2D: {_0e61792e875a}")
        _ff5afa649881 = _d18b39bd18b2._19ce19392eba[0]
        _56185b63a7ca = _46bf76727572._19ce19392eba[1]
        if _ff5afa649881 and _56185b63a7ca and (_56185b63a7ca % _ff5afa649881 == 0):
            _281a1b847ea0 = _56185b63a7ca // _ff5afa649881
            _62b58db489c8 = _46bf76727572._19ce19392eba[0]
            _9c8796f8994d = _46bf76727572._33d4effa84ed(_62b58db489c8, _281a1b847ea0, _ff5afa649881)
            _b46c7aae8c15 = _b876a71f50d0
            for _b516ce173392 in _167b45c629f6(_281a1b847ea0):
                _9c53cc5e38d9 = _9c8796f8994d[:, _b516ce173392, :] @ _d18b39bd18b2
                _b46c7aae8c15 = _9c53cc5e38d9 if _b46c7aae8c15 is _b876a71f50d0 else (_b46c7aae8c15 + _9c53cc5e38d9)
            return _b46c7aae8c15
        if _ff5afa649881 and _56185b63a7ca and (_ff5afa649881 % _56185b63a7ca == 0):
            _281a1b847ea0 = _ff5afa649881 // _56185b63a7ca
            _0db6849ce70e = _d18b39bd18b2._19ce19392eba[1]
            _ead07b11099c = _d18b39bd18b2._33d4effa84ed(_281a1b847ea0, _56185b63a7ca, _0db6849ce70e)
            _b46c7aae8c15 = _b876a71f50d0
            for _b516ce173392 in _167b45c629f6(_281a1b847ea0):
                _9c53cc5e38d9 = _46bf76727572 @ _ead07b11099c[_b516ce173392]
                _b46c7aae8c15 = _9c53cc5e38d9 if _b46c7aae8c15 is _b876a71f50d0 else (_b46c7aae8c15 + _9c53cc5e38d9)
            return _b46c7aae8c15
        raise _27943ad7dfc8(f"unsupported A/B shapes A={_361872833368(_8cd5e66f0390._19ce19392eba)} B={_361872833368(_879f35d4b45c._19ce19392eba)} for base {_361872833368(_88e9c596d595._19ce19392eba)}")

    # gather parents to allow setattr replacements
    _30b586d85792 = []
    for _c5c5bc376857 in _44f54f98fdc7._adbee513002b():
        try:
            for _85ad4bad969c, _b2ddac670327 in _d8fb8268e714(_c5c5bc376857._ea7735a80e58()):
                _30b586d85792._293f448373bf((_c5c5bc376857, _85ad4bad969c, _b2ddac670327))
        except _ef4342e2a44a:
            continue

    # --- manual merge (robust attempts) ---
    for _c5c5bc376857, _85ad4bad969c, _b2ddac670327 in _30b586d85792:
        try:
            # identify base candidate under wrapper
            _b5b243a2e566 = _5070722bc2c3(_b2ddac670327, "base_layer", _b876a71f50d0) or _5070722bc2c3(_b2ddac670327, "module", _b876a71f50d0) or _5070722bc2c3(_b2ddac670327, "model", _b876a71f50d0)
            if _b5b243a2e566 is _b876a71f50d0 or not _4c094ac0ff32(_b5b243a2e566, "weight"):
                # if child itself is base-like with .weight, skip (nothing to merge)
                if _4c094ac0ff32(_b2ddac670327, "weight") and _7d468eab525d(_5070722bc2c3(_b2ddac670327, "weight"), _00e247c22632._18bb3a400db6._b923b6951d7a):
                    continue
                # otherwise there's nothing we can merge here
                continue

            # locate A/B containers in child or nested attrs
            _9e7c73e07373 = {}
            _57bbffaa026e = {}
            _855e49a4b666 = {}
            # candidate holders
            _56e196ce5031 = [_b2ddac670327]
            for _20d28cd246ca in ("module", "base_layer", "lora_adapter", "adapter", "model", "base_model"):
                _6e7364d94da7 = _5070722bc2c3(_b2ddac670327, _20d28cd246ca, _b876a71f50d0)
                if _6e7364d94da7 is not _b876a71f50d0 and _6e7364d94da7 is not _b2ddac670327:
                    _56e196ce5031._293f448373bf(_6e7364d94da7)

            for _6099dce78c26 in _56e196ce5031:
                if _4c094ac0ff32(_6099dce78c26, "lora_A"):
                    _77a3f5984b85 = _5070722bc2c3(_6099dce78c26, "lora_A")
                    if _7d468eab525d(_77a3f5984b85, _61e6551336e1):
                        for _e769648ad51b, _6e7364d94da7 in _77a3f5984b85._b992948b5171():
                            _9e7c73e07373[_e769648ad51b] = _6e7364d94da7
                    else:
                        _9e7c73e07373["default"] = _77a3f5984b85
                if _4c094ac0ff32(_6099dce78c26, "lora_B"):
                    _2493d1ec8fc9 = _5070722bc2c3(_6099dce78c26, "lora_B")
                    if _7d468eab525d(_2493d1ec8fc9, _61e6551336e1):
                        for _e769648ad51b, _6e7364d94da7 in _2493d1ec8fc9._b992948b5171():
                            _57bbffaa026e[_e769648ad51b] = _6e7364d94da7
                    else:
                        _57bbffaa026e["default"] = _2493d1ec8fc9
                if _4c094ac0ff32(_6099dce78c26, "adapters") and _7d468eab525d(_5070722bc2c3(_6099dce78c26, "adapters"), _61e6551336e1):
                    for _e769648ad51b, _6e7364d94da7 in _5070722bc2c3(_6099dce78c26, "adapters")._b992948b5171():
                        if _4c094ac0ff32(_6e7364d94da7, "lora_A"):
                            _9e7c73e07373[_e769648ad51b] = _5070722bc2c3(_6e7364d94da7, "lora_A")
                        if _4c094ac0ff32(_6e7364d94da7, "lora_B"):
                            _57bbffaa026e[_e769648ad51b] = _5070722bc2c3(_6e7364d94da7, "lora_B")
                if _4c094ac0ff32(_6099dce78c26, "lora_alpha"):
                    _855e49a4b666["default"] = _5070722bc2c3(_6099dce78c26, "lora_alpha")
                if _4c094ac0ff32(_6099dce78c26, "alpha"):
                    # some libs store alpha under alpha
                    _855e49a4b666["default"] = _5070722bc2c3(_6099dce78c26, "alpha")

            if not _9e7c73e07373 and not _57bbffaa026e:
                _f1f1440fcd04._293f448373bf(f"{_c5c5bc376857._2ed1f994d123.__name__}.{_85ad4bad969c}")
                continue

            _2695d8a0fbc1 = _e2fdc9b3a11a(_5971a8bc3c30(_d8fb8268e714(_9e7c73e07373._2695d8a0fbc1()) + _d8fb8268e714(_57bbffaa026e._2695d8a0fbc1()) + ["default"]))
            _92942140a5ca = 0
            for _e769648ad51b in _2695d8a0fbc1:
                _b737bd76c57f = _9e7c73e07373._4add7fcb188b(_e769648ad51b) or _9e7c73e07373._4add7fcb188b("default")
                _7dc3eeec9d61 = _57bbffaa026e._4add7fcb188b(_e769648ad51b) or _57bbffaa026e._4add7fcb188b("default")
                _8cd5e66f0390 = _2ec413cfc398(_b737bd76c57f)
                _879f35d4b45c = _2ec413cfc398(_7dc3eeec9d61)
                if _8cd5e66f0390 is _b876a71f50d0 or _879f35d4b45c is _b876a71f50d0:
                    _42f22744a6db._440828889437("Skipping %s.%s key=%s (no tensor)", _c5c5bc376857._2ed1f994d123.__name__, _85ad4bad969c, _e769648ad51b)
                    continue
                if _8cd5e66f0390._6d3a0db41b1c() == 0 or _879f35d4b45c._6d3a0db41b1c() == 0:
                    _42f22744a6db._c7c23effb315("Empty/zero-dim A/B for %s.%s key=%s — replacing wrapper with base.", _c5c5bc376857._2ed1f994d123.__name__, _85ad4bad969c, _e769648ad51b)
                    try:
                        _203a1b22dc86(_c5c5bc376857, _85ad4bad969c, _b5b243a2e566)
                        _d8812092fe26 += 1
                    except _ef4342e2a44a as _0e61792e875a:
                        _42f22744a6db._c7c23effb315("Could not replace wrapper %s.%s: %s", _c5c5bc376857._2ed1f994d123.__name__, _85ad4bad969c, _0e61792e875a)
                    _92942140a5ca = 0
                    break

                try:
                    _b46c7aae8c15 = _aa5908104b1d(_8cd5e66f0390, _879f35d4b45c, _b5b243a2e566._33c92757a541)
                except _ef4342e2a44a as _0e61792e875a:
                    _42f22744a6db._c7c23effb315("Failed computing LoRA delta for %s.%s key=%s: %s", _c5c5bc376857._2ed1f994d123.__name__, _85ad4bad969c, _e769648ad51b, _0e61792e875a)
                    _b46c7aae8c15 = _b876a71f50d0

                if _b46c7aae8c15 is _b876a71f50d0:
                    continue

                # alpha scaling
                _5076c9dc4186 = _855e49a4b666._4add7fcb188b(_e769648ad51b) or _855e49a4b666._4add7fcb188b("default")
                _067e9ff15d46 = 1.0
                try:
                    if _5076c9dc4186 is not _b876a71f50d0:
                        _5f83f0fbbea9 = _50896461db26(_5076c9dc4186._87817d8802cd()) if _7d468eab525d(_5076c9dc4186, _00e247c22632._18bb3a400db6._b923b6951d7a) else _50896461db26(_5076c9dc4186)
                        _e2b6f35f65dc = _8cd5e66f0390._19ce19392eba[0] if _5070722bc2c3(_8cd5e66f0390, "dim", lambda: 0)() > 0 else _b876a71f50d0
                        if _e2b6f35f65dc:
                            _067e9ff15d46 = _5f83f0fbbea9 / _50896461db26(_e2b6f35f65dc)
                except _ef4342e2a44a:
                    _067e9ff15d46 = 1.0

                # apply
                try:
                    with _00e247c22632._8082ea496b1b():
                        _b5b243a2e566._33c92757a541._0ea2642c3b08 = _b5b243a2e566._33c92757a541._0ea2642c3b08 + (_b46c7aae8c15._2d733ab94b9f(_b5b243a2e566._33c92757a541._dff7d7afed3b, _00e247c22632._d0e23426f495) * _067e9ff15d46)._2d733ab94b9f(_b5b243a2e566._33c92757a541._aeb5cef32604)
                    _1ef8d01a7437 += 1
                    _92942140a5ca += 1
                    _42f22744a6db._00afa095dbb3("Merged LoRA into %s.%s key=%s (scale=%s, delta_shape=%s)", _c5c5bc376857._2ed1f994d123.__name__, _85ad4bad969c, _e769648ad51b, _067e9ff15d46, _361872833368(_b46c7aae8c15._19ce19392eba) if _4c094ac0ff32(_b46c7aae8c15, "shape") else ())
                except _ef4342e2a44a as _0e61792e875a:
                    _42f22744a6db._c7c23effb315("Failed applying delta into base for %s.%s key=%s: %s", _c5c5bc376857._2ed1f994d123.__name__, _85ad4bad969c, _e769648ad51b, _0e61792e875a)
                    continue

            # after processing keys, attempt to replace wrapper with base
            try:
                _203a1b22dc86(_c5c5bc376857, _85ad4bad969c, _b5b243a2e566)
                _d8812092fe26 += 1
            except _ef4342e2a44a as _0e61792e875a:
                _42f22744a6db._c7c23effb315("Applied deltas but failed to replace wrapper %s.%s: %s", _c5c5bc376857._2ed1f994d123.__name__, _85ad4bad969c, _0e61792e875a)

        except _ef4342e2a44a as _0e61792e875a:
            _42f22744a6db._c7c23effb315("Unexpected failure merging %s.%s: %s", _c5c5bc376857._2ed1f994d123.__name__, _5070722bc2c3(_b2ddac670327, "__class__", _784aa5475553(_b2ddac670327)).__name__, _0e61792e875a)
            continue

    # --- FINAL CLEANUP PASS: unwrap any remaining PEFT/Lora wrappers and remove LoRA attrs ---
    def _b0ffb449b744(_20d1eb2d7240):
        nonlocal _d8812092fe26
        for _c5c5bc376857 in _d8fb8268e714(_20d1eb2d7240._adbee513002b()):
            try:
                for _79be0e066d15, _b2ddac670327 in _d8fb8268e714(_c5c5bc376857._ea7735a80e58()):
                    try:
                        _7cae373e9352 = _b2ddac670327._2ed1f994d123.__name__
                        # 1) If wrapper has merge_and_unload or merge_and_unload() try it
                        try:
                            if _4c094ac0ff32(_b2ddac670327, "merge_and_unload"):
                                try:
                                    _71e1202bdeb8 = _b2ddac670327._7831ea637366()
                                    # merge_and_unload sometimes returns a replacement module
                                    if _71e1202bdeb8 is not _b876a71f50d0 and _71e1202bdeb8 is not _b2ddac670327:
                                        _203a1b22dc86(_c5c5bc376857, _79be0e066d15, _71e1202bdeb8)
                                        _d8812092fe26 += 1
                                        continue
                                except _ef4342e2a44a:
                                    # ignore failing merge_and_unload
                                    pass
                            # sometimes wrapper is PeftModelForCausalLM or LoraModel
                            if "Peft" in _7cae373e9352 or "Lora" in _7cae373e9352 or "PeftModel" in _7cae373e9352:
                                _510c61a421b5 = _5070722bc2c3(_b2ddac670327, "base_model", _b876a71f50d0) or _5070722bc2c3(_b2ddac670327, "module", _b876a71f50d0) or _5070722bc2c3(_b2ddac670327, "model", _b876a71f50d0)
                                if _510c61a421b5 is not _b876a71f50d0 and _510c61a421b5 is not _b2ddac670327:
                                    _203a1b22dc86(_c5c5bc376857, _79be0e066d15, _510c61a421b5)
                                    _d8812092fe26 += 1
                                    continue
                        except _ef4342e2a44a:
                            pass

                        # 2) Remove lora attrs if present on child (making it plain)
                        for _668bafeab282 in ("lora_A", "lora_B", "lora_alpha", "adapters", "peft_config", "lora_dropout", "base_layer"):
                            if _4c094ac0ff32(_b2ddac670327, _668bafeab282):
                                try:
                                    _309191f6f5f8(_b2ddac670327, _668bafeab282)
                                except _ef4342e2a44a:
                                    try:
                                        _203a1b22dc86(_b2ddac670327, _668bafeab282, _b876a71f50d0)
                                    except _ef4342e2a44a:
                                        pass
                        # 3) If child has nested wrappers, try to reattach its inner module
                        if _4c094ac0ff32(_b2ddac670327, "module") and _b2ddac670327 is not _5070722bc2c3(_b2ddac670327, "module"):
                            try:
                                _203a1b22dc86(_c5c5bc376857, _79be0e066d15, _5070722bc2c3(_b2ddac670327, "module"))
                                _d8812092fe26 += 1
                                continue
                            except _ef4342e2a44a:
                                pass
                    except _ef4342e2a44a:
                        continue
            except _ef4342e2a44a:
                continue

    _bca2a4079c9e(_44f54f98fdc7)

    # final parameter freezing: ensure LoRA params (if any) are not left trainable and normal params are frozen unless explicitly lora
    try:
        for _5a0b0709d326, _c779e9565205 in _44f54f98fdc7._283f2fbe9348():
            if "lora" in _5a0b0709d326._55fb8a49e0c5():
                _c779e9565205._a4262b00ccf9 = _e683ba20d11f
            else:
                _c779e9565205._a4262b00ccf9 = _5391a231e8c1
    except _ef4342e2a44a:
        pass

    _42f22744a6db._00afa095dbb3("merge_lora_into_base: merged %d deltas, replaced %d wrappers, skipped %d modules.", _1ef8d01a7437, _d8812092fe26, _766c177734a2(_f1f1440fcd04))
    if _00e247c22632._8b2a182fd222._6ad7116d3a22():
        _00e247c22632._8b2a182fd222._04bd08059fe0()
        _00e247c22632._8b2a182fd222._251c9634c625()
    _5f47154b5791._f98626c15d3e()
    if _f1f1440fcd04:
        _42f22744a6db._440828889437("Skipped modules (no A/B found): %s", _f1f1440fcd04[:200])
    return _44f54f98fdc7

_2499906e6b5c = [
    'CustomFSDPStrategy',
    'OptunaLoggingCallback',
    'GPUUsagePruneCallback',
    'adjust_local_gpu_rank',
    'get_device_info',
    'remove_files_except',
    'load_checkpoint_with_fsdp',
    'dequantize_bnb_model',
    'manual_dequantize',
    'get_trainable_parameters',
    'get_target_modules',
    'clear_gpu_and_cpu_resources',
    'calculate_model_size_in_gb',
    'get_model_summary',
    'get_devices_for_trainer',
    'get_supported_compute_dtype',
    'is_duplicate',
    'NoDuplicateSampler',
    'gamma_for_tpe_sampler',
    'property_validation',
    'get_lora_config',
    'apply_lora_to_model',
    'merge_lora_into_base',
    'quantize_model_using_bnb',
]