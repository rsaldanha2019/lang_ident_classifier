# Pyarmor 9.1.0 (basic), 009596, 2025-10-20T18:52:41.478718
from .pyarmor_runtime import __pyarmor__
