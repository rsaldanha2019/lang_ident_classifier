# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : file_dir_utils.py
# @Time             : 2025-10-23 13:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
from pathlib import _3cf4f18068b4
import _9007b06f6c89
from typing import _adfdcaa91303


class _59e8136e8512:
    """
    Utility class for common filesystem operations such as existence checks,
    directory creation, and emptiness validation.

    These helpers wrap standard library calls (os, pathlib, shutil)
    with consistent interfaces and error handling suitable for pipeline utilities.

    Example
    -------
    >>> futil = FileDirUtils()
    >>> futil.check_file_or_dir_exists("/tmp")  
    True
    >>> futil.create_dir("/tmp/example_dir", force_write=True)
    >>> futil.is_dir_empty("/tmp/example_dir")
    True
    """

    def _6f42da369b70(self, _f18362a9dd6a: _63a8bdf56298) -> _1f899d6f06a8:
        """
        Check whether a given file or directory path exists.

        Parameters
        ----------
        file_dir_path : str
            Absolute or relative path to a file or directory.

        Returns
        -------
        bool
            True if the path exists on disk, False otherwise.

        Raises
        ------
        TypeError
            If `file_dir_path` is not a string or path-like object.
        """
        if not _416e3c045cde(_f18362a9dd6a, (_63a8bdf56298, os._e6f6f82e076f)):
            raise _685546f8ac0e("file_dir_path must be a string or path-like object.")

        _eda2dbd76724 = _3cf4f18068b4(_f18362a9dd6a)
        return _eda2dbd76724._ce2d520e0ffd()

    def _5d59c96db4a1(self, _6b758987b294: _63a8bdf56298, _d50ca409f8be: _1f899d6f06a8 = _3ddb6d8200c5) -> _1776cdf877f8:
        """
        Create a directory (and all intermediate parent directories) if it does not exist.
        Optionally remove an existing directory first if `force_write` is True.

        Parameters
        ----------
        dir_path : str
            Path of the directory to create.
        force_write : bool, optional
            If True, removes the existing directory (and its contents)
            before recreating it. Default is False.

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If parent directories cannot be created due to missing permissions.
        PermissionError
            If the process lacks permissions to modify or create the directory.
        OSError
            For any other OS-level failure during directory creation or deletion.

        Notes
        -----
        - When `force_write=True`, the entire directory tree is deleted
          using `shutil.rmtree()`. Use with care.
        """
        if not _416e3c045cde(_6b758987b294, (_63a8bdf56298, os._e6f6f82e076f)):
            raise _685546f8ac0e("dir_path must be a string or path-like object.")

        try:
            if _d50ca409f8be and os._f0dad7c40693._ce2d520e0ffd(_6b758987b294):
                _9007b06f6c89._2f9883a8c664(_6b758987b294)
            os._170c614c548e(_6b758987b294, _2dbd791153a3=_8bc6b1429498)
        except (_079471f6384a, _c0da23c41c60, _1f08fe0807eb) as _8de6db385815:
            raise _8de6db385815  # allow caller to handle appropriately

    def _5dbb3aacd40d(self, _6b758987b294: _63a8bdf56298) -> _1f899d6f06a8:
        """
        Check whether a given directory exists and is empty.

        Parameters
        ----------
        dir_path : str
            Path to the directory to inspect.

        Returns
        -------
        bool
            True if the directory exists and is empty, False otherwise.

        Raises
        ------
        FileNotFoundError
            If the directory does not exist.
        NotADirectoryError
            If the provided path exists but is not a directory.
        PermissionError
            If the directory contents cannot be listed due to permission restrictions.
        """
        if not os._f0dad7c40693._ce2d520e0ffd(_6b758987b294):
            raise _079471f6384a(f"Directory not found: '{_6b758987b294}'")
        if not os._f0dad7c40693._11fa917c8d28(_6b758987b294):
            raise _cac9c5c9efe7(f"Path is not a directory: '{_6b758987b294}'")

        try:
            return _39c75e8f3e95(os._4f9ba4488dda(_6b758987b294)) == 0
        except _c0da23c41c60 as _8de6db385815:
            raise _c0da23c41c60(f"Cannot list contents of '{_6b758987b294}': {_8de6db385815}") from _8de6db385815
