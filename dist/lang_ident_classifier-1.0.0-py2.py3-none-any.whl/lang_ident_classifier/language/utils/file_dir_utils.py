# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : file_dir_utils.py
# @Time             : 2025-10-23 13:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
from pathlib import _675242ed5e13
import _bfec163299cd
from typing import _be6e95328e1b


class _20aaa2d67a5f:
    """
    Utility class for common filesystem operations such as existence checks,
    directory creation, and emptiness validation.

    These helpers wrap standard library calls (os, pathlib, shutil)
    with consistent interfaces and error handling suitable for pipeline utilities.

    Example
    -------
    >>> futil = FileDirUtils()
    >>> futil.check_file_or_dir_exists("/tmp")  
    True
    >>> futil.create_dir("/tmp/example_dir", force_write=True)
    >>> futil.is_dir_empty("/tmp/example_dir")
    True
    """

    def _62b736d9084c(self, _bb59f481c405: _6e9f76224273) -> _496bf73e6652:
        """
        Check whether a given file or directory path exists.

        Parameters
        ----------
        file_dir_path : str
            Absolute or relative path to a file or directory.

        Returns
        -------
        bool
            True if the path exists on disk, False otherwise.

        Raises
        ------
        TypeError
            If `file_dir_path` is not a string or path-like object.
        """
        if not _6133ad887386(_bb59f481c405, (_6e9f76224273, os._56313158d26a)):
            raise _cfebd387ecd7("file_dir_path must be a string or path-like object.")

        _1820509f5c60 = _675242ed5e13(_bb59f481c405)
        return _1820509f5c60._950bb9751c72()

    def _7bbb30caccf5(self, _ee7ab205ac4f: _6e9f76224273, _fb77d2af3ce8: _496bf73e6652 = _db20dd40f571) -> _2b8b2cebe730:
        """
        Create a directory (and all intermediate parent directories) if it does not exist.
        Optionally remove an existing directory first if `force_write` is True.

        Parameters
        ----------
        dir_path : str
            Path of the directory to create.
        force_write : bool, optional
            If True, removes the existing directory (and its contents)
            before recreating it. Default is False.

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If parent directories cannot be created due to missing permissions.
        PermissionError
            If the process lacks permissions to modify or create the directory.
        OSError
            For any other OS-level failure during directory creation or deletion.

        Notes
        -----
        - When `force_write=True`, the entire directory tree is deleted
          using `shutil.rmtree()`. Use with care.
        """
        if not _6133ad887386(_ee7ab205ac4f, (_6e9f76224273, os._56313158d26a)):
            raise _cfebd387ecd7("dir_path must be a string or path-like object.")

        try:
            if _fb77d2af3ce8 and os._bfad993ca743._950bb9751c72(_ee7ab205ac4f):
                _bfec163299cd._a3d8c5a1d854(_ee7ab205ac4f)
            os._a77eb7ee63de(_ee7ab205ac4f, _4502f6f8d5cb=_f4c05070599a)
        except (_9b240551104f, _733a4536119d, _633859c80d6d) as _391de75c14eb:
            raise _391de75c14eb  # allow caller to handle appropriately

    def _a94ecbf4f77a(self, _ee7ab205ac4f: _6e9f76224273) -> _496bf73e6652:
        """
        Check whether a given directory exists and is empty.

        Parameters
        ----------
        dir_path : str
            Path to the directory to inspect.

        Returns
        -------
        bool
            True if the directory exists and is empty, False otherwise.

        Raises
        ------
        FileNotFoundError
            If the directory does not exist.
        NotADirectoryError
            If the provided path exists but is not a directory.
        PermissionError
            If the directory contents cannot be listed due to permission restrictions.
        """
        if not os._bfad993ca743._950bb9751c72(_ee7ab205ac4f):
            raise _9b240551104f(f"Directory not found: '{_ee7ab205ac4f}'")
        if not os._bfad993ca743._cf4c1754d8ae(_ee7ab205ac4f):
            raise _f4bd4b850d80(f"Path is not a directory: '{_ee7ab205ac4f}'")

        try:
            return _f18f0133161c(os._fbd4ce140e79(_ee7ab205ac4f)) == 0
        except _733a4536119d as _391de75c14eb:
            raise _733a4536119d(f"Cannot list contents of '{_ee7ab205ac4f}': {_391de75c14eb}") from _391de75c14eb
