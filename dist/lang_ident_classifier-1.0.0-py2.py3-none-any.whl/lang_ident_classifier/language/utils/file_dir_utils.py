# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : file_dir_utils.py
# @Time             : 2025-10-23 13:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
from pathlib import _b09b9e352325
import _2326bf988607
from typing import _bb3d4de07eb6


class _2d5aea86071b:
    """
    Utility class for common filesystem operations such as existence checks,
    directory creation, and emptiness validation.

    These helpers wrap standard library calls (os, pathlib, shutil)
    with consistent interfaces and error handling suitable for pipeline utilities.

    Example
    -------
    >>> futil = FileDirUtils()
    >>> futil.check_file_or_dir_exists("/tmp")  
    True
    >>> futil.create_dir("/tmp/example_dir", force_write=True)
    >>> futil.is_dir_empty("/tmp/example_dir")
    True
    """

    def _53a57ec0239e(self, _87b433183a8a: _60cd88c0c0b8) -> _6ebb193d1c91:
        """
        Check whether a given file or directory path exists.

        Parameters
        ----------
        file_dir_path : str
            Absolute or relative path to a file or directory.

        Returns
        -------
        bool
            True if the path exists on disk, False otherwise.

        Raises
        ------
        TypeError
            If `file_dir_path` is not a string or path-like object.
        """
        if not _a301240612eb(_87b433183a8a, (_60cd88c0c0b8, os._c372369b84f9)):
            raise _a6204c9ddcb3("file_dir_path must be a string or path-like object.")

        _fbbc4090f6ff = _b09b9e352325(_87b433183a8a)
        return _fbbc4090f6ff._3a2e55d5748d()

    def _54f05aaa1674(self, _740f1c0cc003: _60cd88c0c0b8, _0f3f178efb55: _6ebb193d1c91 = _4693c11f88c1) -> _64889aa7e60d:
        """
        Create a directory (and all intermediate parent directories) if it does not exist.
        Optionally remove an existing directory first if `force_write` is True.

        Parameters
        ----------
        dir_path : str
            Path of the directory to create.
        force_write : bool, optional
            If True, removes the existing directory (and its contents)
            before recreating it. Default is False.

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If parent directories cannot be created due to missing permissions.
        PermissionError
            If the process lacks permissions to modify or create the directory.
        OSError
            For any other OS-level failure during directory creation or deletion.

        Notes
        -----
        - When `force_write=True`, the entire directory tree is deleted
          using `shutil.rmtree()`. Use with care.
        """
        if not _a301240612eb(_740f1c0cc003, (_60cd88c0c0b8, os._c372369b84f9)):
            raise _a6204c9ddcb3("dir_path must be a string or path-like object.")

        try:
            if _0f3f178efb55 and os._11d4b50b8587._3a2e55d5748d(_740f1c0cc003):
                _2326bf988607._dbfbd844e060(_740f1c0cc003)
            os._0d268597c555(_740f1c0cc003, _4b4323778607=_a415a21323cd)
        except (_cf2250de11aa, _377795d2c897, _234d2ffd9276) as _bea5c2d20960:
            raise _bea5c2d20960  # allow caller to handle appropriately

    def _1186df8e1601(self, _740f1c0cc003: _60cd88c0c0b8) -> _6ebb193d1c91:
        """
        Check whether a given directory exists and is empty.

        Parameters
        ----------
        dir_path : str
            Path to the directory to inspect.

        Returns
        -------
        bool
            True if the directory exists and is empty, False otherwise.

        Raises
        ------
        FileNotFoundError
            If the directory does not exist.
        NotADirectoryError
            If the provided path exists but is not a directory.
        PermissionError
            If the directory contents cannot be listed due to permission restrictions.
        """
        if not os._11d4b50b8587._3a2e55d5748d(_740f1c0cc003):
            raise _cf2250de11aa(f"Directory not found: '{_740f1c0cc003}'")
        if not os._11d4b50b8587._0fa1ebd159a2(_740f1c0cc003):
            raise _74534e62afe2(f"Path is not a directory: '{_740f1c0cc003}'")

        try:
            return _fb0964939275(os._2b26755e47f7(_740f1c0cc003)) == 0
        except _377795d2c897 as _bea5c2d20960:
            raise _377795d2c897(f"Cannot list contents of '{_740f1c0cc003}': {_bea5c2d20960}") from _bea5c2d20960
