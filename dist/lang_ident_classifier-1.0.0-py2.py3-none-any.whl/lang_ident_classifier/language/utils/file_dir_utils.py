# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : file_dir_utils
# @Time             : 18/12/23 9:11 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import os
from pathlib import Path
import shutil
from typing import Any


class FileDirUtils:
    """
    Class for file and directory related operations
    """
    def check_file_or_dir_exists(self, file_dir_path: str) -> bool:
        """
        Takes a file or directory path and
        returns a flag for existence of path
        :param file_dir_path: path of directory or file
        :return: flag for path existence
        """
        file_dir = Path(file_dir_path)
        file_dir_exists = file_dir.exists()
        return file_dir_exists

    def create_dir(self, dir_path: str, force_write: bool = False) -> Any:
        """
        Takes a directory path, recursively creates directories
        or raises an OS error if directory creation not possible
        :param dir_path: path of the directory/ directories
        :return: OSError in case of directory creation failure
        """
        try:
            if force_write and os.path.exists(dir_path):
                shutil.rmtree(dir_path)
            os.makedirs(dir_path, exist_ok=True)
        except OSError as ose:
            raise ose

    def is_dir_empty(self, pretrained_embedding_model_dir_path: str) -> bool:
        return not len(os.listdir(pretrained_embedding_model_dir_path)) > 0
