# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : file_dir_utils.py
# @Time             : 2025-10-23 13:53 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _6329a237e3de
from _40481ae6d649 import _53177353fd35
import _7b901752ed16
from _9c628583822b import _68a50a00dca8


class _bacfcb170228:
    """
    Utility class for common filesystem operations such as existence checks,
    directory creation, and emptiness validation.

    These helpers wrap standard library calls (os, pathlib, shutil)
    with consistent interfaces and error handling suitable for pipeline utilities.

    Example
    -------
    >>> futil = FileDirUtils()
    >>> futil.check_file_or_dir_exists("/tmp")  
    True
    >>> futil.create_dir("/tmp/example_dir", force_write=True)
    >>> futil.is_dir_empty("/tmp/example_dir")
    True
    """

    def _9de6d9334b4a(self, _a6f2cac31bb3: _10a299be51c5) -> _3bc1cb5319e4:
        """
        Check whether a given file or directory path exists.

        Parameters
        ----------
        file_dir_path : str
            Absolute or relative path to a file or directory.

        Returns
        -------
        bool
            True if the path exists on disk, False otherwise.

        Raises
        ------
        TypeError
            If `file_dir_path` is not a string or path-like object.
        """
        if not _6cd6475b9282(_a6f2cac31bb3, (_10a299be51c5, _6329a237e3de._e3dc94324244)):
            raise _7867e50dc512("file_dir_path must be a string or path-like object.")

        _8bec07d478fe = _53177353fd35(_a6f2cac31bb3)
        return _8bec07d478fe._113c67015d36()

    def _6ad6c44d8255(self, _b668a70687a9: _10a299be51c5, _6bf9663aae9a: _3bc1cb5319e4 = _cea173684b59) -> _1e8ba40c842d:
        """
        Create a directory (and all intermediate parent directories) if it does not exist.
        Optionally remove an existing directory first if `force_write` is True.

        Parameters
        ----------
        dir_path : str
            Path of the directory to create.
        force_write : bool, optional
            If True, removes the existing directory (and its contents)
            before recreating it. Default is False.

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If parent directories cannot be created due to missing permissions.
        PermissionError
            If the process lacks permissions to modify or create the directory.
        OSError
            For any other OS-level failure during directory creation or deletion.

        Notes
        -----
        - When `force_write=True`, the entire directory tree is deleted
          using `shutil.rmtree()`. Use with care.
        """
        if not _6cd6475b9282(_b668a70687a9, (_10a299be51c5, _6329a237e3de._e3dc94324244)):
            raise _7867e50dc512("dir_path must be a string or path-like object.")

        try:
            if _6bf9663aae9a and _6329a237e3de._3d023956eeef._113c67015d36(_b668a70687a9):
                _7b901752ed16._39032be6c62e(_b668a70687a9)
            _6329a237e3de._500db1c2ab65(_b668a70687a9, _2090c886e444=_ca8ef6eb6953)
        except (_215e3f34075c, _f3d5445f4564, _35fecf2fcc2c) as _5eed394ee7dd:
            raise _5eed394ee7dd  # allow caller to handle appropriately

    def _8bc9443a602f(self, _b668a70687a9: _10a299be51c5) -> _3bc1cb5319e4:
        """
        Check whether a given directory exists and is empty.

        Parameters
        ----------
        dir_path : str
            Path to the directory to inspect.

        Returns
        -------
        bool
            True if the directory exists and is empty, False otherwise.

        Raises
        ------
        FileNotFoundError
            If the directory does not exist.
        NotADirectoryError
            If the provided path exists but is not a directory.
        PermissionError
            If the directory contents cannot be listed due to permission restrictions.
        """
        if not _6329a237e3de._3d023956eeef._113c67015d36(_b668a70687a9):
            raise _215e3f34075c(f"Directory not found: '{_b668a70687a9}'")
        if not _6329a237e3de._3d023956eeef._17ee11ea6684(_b668a70687a9):
            raise _7432185d3b61(f"Path is not a directory: '{_b668a70687a9}'")

        try:
            return _74e047f22257(_6329a237e3de._79b3ee6828d8(_b668a70687a9)) == 0
        except _f3d5445f4564 as _5eed394ee7dd:
            raise _f3d5445f4564(f"Cannot list contents of '{_b668a70687a9}': {_5eed394ee7dd}") from _5eed394ee7dd
