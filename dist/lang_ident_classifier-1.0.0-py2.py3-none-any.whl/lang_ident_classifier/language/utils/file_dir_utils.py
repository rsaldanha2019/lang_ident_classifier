
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(6319, 21745, 2), (30083, 51906, 2), (13678, 61466, 2), (42162, 42040, 2), (26730, 27683, 2), (16990, 35155, 2), (17784, 28221, 2), (25567, 52592, 2), (18586, 8457, 2), (36576, 59211, 2), (370, 51978, 2), (39977, 23755, 2), (45224, 64257, 2), (30239, 12419, 2), (64133, 20793, 2), (2546, 38290, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('TF6/QQ==')
_nonce = base64.b64decode('n+8VUMwhNOZRHRU0')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('XFtYj5IHFKruCM00Bn0TXOtRWYpMPBXPmQiBcgTA+gB7qKTiPVJ79SUQffZ3qQY9xPrNF//O5HOx+12zFU6+WXF7QbQwA6Df1oUZVb3pcg78Ai1w6EYTZiPkaYtepcI96CKjm01c4o2Hs/rKaIYkv/++8mFxyawiSmh6ySyXgIGtrRbfQv9yhOn4+7sTLKU4KwpxIMWiQNZfmwDejX2DZYWlk90AEmsToQRNWReR1AMtaJOe2mvefIuL/ws7wJpj2newJ0frcsRImw+A5CqsuuNhdbiww32LSpXaQrj9eDfxoWh6AXjWkL26ER5/5jFEaWcz1uCUciDyP7cvtBJXpak11lNHJ8nymmCNIAUSYAPjD5RlzlcExHfe93VeL6telccVaGj4zFJUdg/bU8rnZcHQXxaCKV1tNAErJ6H7bCqfm6MONKOevR9PqqiUmV8LPxIwnbFjD0CnyQp3SbOSM2lJ7nGxY1QaAtwE8tsLZjLg+qMlztuYh0MEZZATUs+3QeOBwyQfidDxaqJy5quVPXnDIlsAlD/+CgRKQBnkKhq4dcsaPTQmEwU67L1xJAXfIqEXkQahiiQK/eNvILyeKvM79ye0NtPB6yUGPIQ45cDgxZS2MrnTnyJIGoaaJbzPsfAFn/Qm8Q5wP3ZZsJz1mL2cbKoLkC9fg3AU8zpQGB5XTZxPC/7gdcdSGoWXEYWbih4IwlWFvt/9GnRC54jIQPNkri9VbmFdEYXWLCbSin6yV68FeSzb0Fb6ywH+To7SWUNp6zdxZfbkebVKU0EsNHIScDbwhGwAqcj7xqDWK7UeJBy+9DndkViMrBZmqL3pQM7suqXJqKkj9OogUCXrSbpF8rFZaWtwzy00e9ar+FaiMTLN8Gj5MjnVsgCjHeXKVAmKwdPlqDbCSuVeAWoEdUbJzxRy07R+yqCTafdMpSrk3dOJo7JAo8lkoZzwq8vfBtxRDYT8mfBRmuXh57NIzFnLz6ncQNCNkVGl+NFMLAaOgY85myIRIVEJSDgz09X0sqorDUaJ8rNwk5GpxtpgeU0AvoRY9iANT9GEFcZSF2nHvRZ5J5i9Bq3uW4aQguhtsS3OZ2yJCXnmcZMR79e9O4B8h5WB9n10r7upeUKV4LOo2yI7I65beaAy9rpJjlGzU8yhkVoiT2/ugomcsw5Yhv+n348KdLHNEjluC0qw/EGVa+QQ8sMi5J/HEGIjiTzHuGneuL0VAvxqezvlVWM7KC/ihQvkYO2z4ZC9pcLBvaTE7slIgaeg6gaxnyMuwnGSsg5g703Po7NVZG+5RJb/8GYYYLsTjAUYdl/esC7KOnyA5Inv3hfQwNGfjSHI1G3TSha8AcCjdAVn2to5BaC6Y40iqV+8M1lKV7ksQ91X+d8zqNd6w/2pHYc83RqwFYFnux1c/DKWJrmaZs+Aa2ZxOPZGTpARtKThA3ehJ9nt6bSOleRNkfGpTBn97b4Qh2wMoeH0VIfaitfxkQOFnhvfu68zlP6hhV0FruA6QNTSEtCXa173OgUK8V0RNPCQeHWW/MctJrOngxqhW4y0Umv9y+gwKSPaBPFOd6E54wlp/ekAMiiqUF4KF4T/1oJL/X1Mh0fLl1FmRRbepOr8YD6qe6cSWe5mLVL8xYWUSZ1LMP70SxpkpoTecCQWzFJb/LNahyMUJTRX0/b6nyfceKvBXONB6YV25pcjsic70KqP6PiD3regnjoM7h/hIm2sQGFyT99rS+m4/EakW4JqyDilBfIuzV5Kvd0qSZ55JGp7j5lrZP6xkeL0sE2ZvPXgX65VUxvEkj1ZhPBZ1pJkxW+Nt/yHoPWo/dyZ3L1tIAudMBXMftpuJGZoIMJx20IZrkiRlG1RBE2Yp513MFH62B8Y91r/rwsPZW8G77Y4lIhnbSnmSoHGv5koJcfONDcNue3p0CSmz1kRTziJD63Gp5BuElNbJPa31vQt/VfAAmKEicfWFJyVVEqNgZ3kIz8TEpPb++0CoLuxxtO/NNiJajB55jr3uw3XlNFnvSk61gm60ChzeZvxcRb8wzlqqaJxWwJ14ToUHF+3tHedXMNd6VQvTVT6Uw/1Y4cPaafakeZUO9jXEWAggn1NVGT48AD8x5vXXV7SKE70eT7VxhfcC5oA40iXROq9acbsC8u4hN5+OMgzXwY+vmer0lygwFI9UpYRldyySD3GOhYV6TmlQ6Ha8ei3nGgKrgKro5woGaC/ZfEDZFX3b2L29+Q/km22Se2TCGYD5040d/izuWmaucU3BE2eYU/7dUA9QeiRbLYigaWsjcRijUdnf2PM8ShX8swr5tfyd/M9yiJi5s1AOoxFbRwLClW89z8J2xYLtkrsZX2G2OmKLN8UyLF0Cd6UxH8cH+D12rprKBDThvoYtu3cEwkQBxw1vBgGrGoJP4d/4kC0M5jcNts0Y2gBJIZNAvB6kDy+ISERqKu0zpjUh3CpVnYb9QmWlLAqaVX9riT/O1lzJ4e7ic9VcT5heYda9zZeQ0HF5bHhRWx41HsBTD2daDJzTFZXNCNDe2688S2EOjiUFHBC1+kNyNzgnCJtsbR+6HyV53Qdpjsg5xGj5na3yYdTl/8wbYvv5H23uOfVe5W8FMqx9qg91GDaYIYmASeiAeD5G4uohVQ+Cqp5ebfQm0VXIu+ASfCejELVdry5Vq3/I+rKYatRexOoc9XgJZ5Ba/kawvEL1I5K7I39Ipv2irhQsKPrM8DibwZiGM/keN9Qn6Ib6gH4mTJMPiIPsliKkn3Ipw4Wmo5kcbUi7KHo2maBp79L6J+YkaeZeI5s/cyOymFyyeHb9bb3gFjLSxzqZTrHIJryZwepi5zLa+2943wJl7rLFLqfOKTs88M8RxaXuoW04Vdv1MNsqnSmtB570d6NhSX2EnSGLaGW3tnsDGZ9S1Q2DH/oJmKTMGQHPEv9vGX+XNrqK67ihEQq/v0p0PT+yG99bfSYRJsjNuP7cZ9gNFyv6+UkzREXGwjZSEhw+q7aoCJNPnn7aEmf57t2iRKVs2m0e3Q6hIUQWoAncQr5HDz9NfbO2t93cLIHBqQFzFtbHdNtaHIStkGItMHoWNUNMTE4bd6seV5rtlsj76wzKMhyYtTygdGLMuLJUGKGKIDS+gEPOC6xzEbSWt7D54cUy18V43YzqRtpV8I0Yh4no9UGnu/EICibr0W9StjrRk1nTmWIEwjhWA0rulILAopkml0jK0va/PMvaM8+ycbjJqlJAaeFuD3wut28sLfiUk+epC0f2vA2jsmYJGrE0E0DapV1nb4EGtjtagyMNoXyBOwJYfEqWkBHHY+s/HXJ/WgMeL/Gt2v0EkGm93kHZF3/s+TbfszdtEx9l+qeEdQyyDBvNUDHGoPlFgZTXpxSI4VF+woKqBQUlGbO/Pfv9tJJSyQCCbUrmKzos6OD3QwKB9Ei/u+Q6q/tODWuz4QsgyDi+YAiPIDwQ/H7TmWW39oHM/Qieel5Uij7Kqxmp5CqQ0GGbiOhOmKb3LT5SSs+rE/gnUc0MuS3E7T8813VLcuFctL+d3JQ92GAIiXFtPn04xtUnD8SQYcqh2QuGh1uoruK9kGppuyZC0GMNdPusKzdURw1orKpDDGokR9hUQYx7o83ulQDwXQGwW0RJxsqUhqnF+9xHy1N72nL24arhm5SIjp9IpXHBDiBTjKAdBMamxi1aUfH+QcAO/+PYLyhkIyNj1Ny6VIEjyku7KRiyrzNv59jgkcpblgmGoc2hm2+niS5IBHIPNA/jZNUdT9Z4imn4refEJk57bS4dw5UedBRx+B8JkAE2Uk85DOBuZit6SFdj7PJLQVE9coEn/5/ho9WfwZDYy5Q1/geadye+VbPQhocWI2Rvu+u1zqZr0MxKs5E+8bFl2/u0uO3xJw9e5MPkIb5T5f6Plfdjo4izwHifYQhdQMv0svj6k9ZlmNK+QyJQILu/Z5lUvc/VYdJ0xIRBT9XwZW4zkzfzB/Uec36TZjBQlzvMDv2Q9H+Pgsruh8ofWcNtM+rHqnHNdK4RbO0J5ZYRGM12P9QbrL3zOp7tCJBlsHFwJxndwo8wH5N9o8PYhAzo9uMtsVvBAPOLpL+fOZkGtheqLO14IwW/SQoF0HZjFZFa6zen+viNNQzYTCzeBQVOpuAJhQocDR0hVFG/HpCU8+l8c/rcUpYT/4qK09KQeM1mZZ8T9xj0VX+nt+HOIUM1WzGyAc8lGnbo95ZAhAJ2J68T/h7sYWkjsb/CA/1apmFlJFvSmVTIPQ8HMA7EfkhN9hOa+gDFmg8QrEVvzKxvE7Fekuzweu7K81ZxOfXnIn96YKtNOxFpGncmlZhLQ+a8X2UMdh+E3me8oQFDNhm4/CFesv3Njrj8zx+0YFWEuxJepTzE9D4+I8sPo4Z/8cIDzMgXxy6cGpQMyUFbp/+A1O1cFOEjIDgznU6T3bsBJ6Lo8fwdXZvH+RrID9cf7FMgOX9Unu/JzgEzS1YzxDAr1mcc3Hz+cJ9gomiBs5a/9ETmlhdmJil/+p9jayBnqYCtdh9A4OVRRRuwqJVV8IoCEelmF+hq0Bc2rKwzakJ05Mv0Jkz1SRT/+5zYaL0YjKeEm4CQ7WGw2jVTX4nhVzFeEtBBx98ao7hRsgq8uko4283fT5/1BMvLzrYZ64lsa6IFywyXd4FmsPpXuuia6NaX7FRQ2/JA6acRET8jPjYvWAtMOsxNU2bSdG32ah9KHfgzymkos+7bI6YtRa6FH9RCoYyMRjWXW316OP9RcJ04yhwEPGu8RaNud4sU3D1ydI8dQRW/TH7GNiAJUGg8R1x7bMs3lJrX8SCLHbHMwCPdWprXQk5ykaXSoH1bKmlwFBs/QQuPYVkMylYyO4qfzPEhWPRe8wSXTvvqkjb6Iofne37eCU/f7AtW4Iy+5b+2qSC1W7oyikdE+UyG6fZi//vz8YfwGZ7OQN5js1i1Cuw1kn/4Gdz/JrrExT11u1GHJB7x5OfQW+qtKC1gjfSf6SV8s47CtUiCE6DY5z4aIBy9GrBgwFS1MgRH2joomW7YY4C7V59xfBetzYErvNFg6JPi6EOXtZjNNaWNg+EpUg1tquKNHf6/EEHEpEmb6G5zhXxe0+Gq7gNhK9bAZtg4JsW/V3dajUSpF+92l/t7QR8lZoG845oSQz6bkWbp32A25G9FwtM/zzSO2v8zWrIRCjSaqyUCYCwOpQdMPjAdWXlD232G0RLWGbqxSDsQv470VJG5i3TjfkAceFbJCF8Y7g7VXXdDosmdDlarw3RHFc0IMGxG53UhdNU99w5UH3V80oFXzoB/kPj5fodSsNNXlTnZez602S6+qxFN1d4BHa6oLQ4ti0kOTRcKV95gadQgRdva8IycvdnMqyK8l7zktmxdN57y4KbTPkc8ykMOrnPlIwRa/nL8ovqMwwjQysC0obxz7OfC+qJ8T8gX1i+nbcJBLr8re58UiWi89eizJe5vXE55CT7X8/Kp1qg2i4xe9VbdsAhxu3X9pBvf+t5neRg3i96DhNQzul7mD9Mb52KYnC1j3eB/tcPlcjx2CbjW9KbVlAp1JsFWbOJKtK7eiBJNg1AilGGe7jpBTjtjyieDqJJSEpxleqpBiP5yVshcvZoWpf2xdlTU45DA08FhlIF8W3nyWkoNnhde7d+zjfsDmoY7QDk8a+FB9HR7gWlj4Tj6xJDgYg0MkGQj19jumw=')
_tag = base64.b64decode('5UawSdwhX5lWF1KYhw5Nbw==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
