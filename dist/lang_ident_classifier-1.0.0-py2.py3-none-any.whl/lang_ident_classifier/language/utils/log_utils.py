# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : log_utils.py
# @Time             : 2025-10-23 13:54 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
import _95ae3409230d as _4bb4d3d7e0a1
import time
import _4d9b13b6e69f
from _95ae3409230d import _495bfd6e9e4f
from _95ae3409230d._02294486f72e import _3cd488fddd16
from _b8ac22245584._eb13f874444e._6344e0b00e5f._fd45e5927d46 import _f2d619cde303
from _b8ac22245584._eb13f874444e._6344e0b00e5f._5bcb483ce300 import _cd04f50b7d0e
from _b8ac22245584._eb13f874444e._6344e0b00e5f._0daa7b932941 import _e0600f5a15aa


class _b6c7885d451b:
    """
    Utility class for application logging configuration and maintenance.

    Provides:
    ----------
    - Creation of a UTC time-based rotating file logger using project properties.
    - Automatic log directory creation under the application's log root.
    - Support for archiving old logs into zip files based on filename prefixes.

    This class ensures consistent logging configuration across distributed components.

    Example
    -------
    >>> props = Properties("/path/to/config.yaml")
    >>> log_util = LogUtils()
    >>> logger = log_util.get_time_rotated_log(props)
    >>> logger.info("Training started successfully.")
    """

    def _311b8c9ffcfc(self) -> _2537142e5c13:
        """
        Initialize the LogUtils class by preparing reusable utility instances.

        Raises
        ------
        RuntimeError
            If dependent utility initialization fails (extremely rare).
        """
        try:
            self._e3ebf465ac3c = _cd04f50b7d0e()
            self._de723d016297 = _e0600f5a15aa()
        except _76105fa34e69 as _78b9835228e8:
            raise _0883e68ec9af("Failed to initialize LogUtils dependencies.") from _78b9835228e8

    def _6d1e3225a8bf(self, _3a1c73d6b0f9: _f2d619cde303) -> _495bfd6e9e4f:
        """
        Configure and return a time-rotated logger instance based on application properties.

        This logger writes to a timestamped log file inside a model-specific directory
        under `props.app.logs_dir`. It uses a UTC-based `TimedRotatingFileHandler`
        that rotates daily at midnight (UTC).

        Parameters
        ----------
        props : Properties
            Application configuration object with structured fields:
            - `props.app.model_config_name` : str — name of the current model/config context.
            - `props.app.logs_dir` : str — base directory for logs.
            - `props.logs.prefix` : str — timestamp prefix format (strftime-compatible).
            - `props.logs.suffix` : str — filename suffix (e.g., "run.log").

        Returns
        -------
        logging.Logger
            Configured logger instance with file and stream handlers attached.

        Raises
        ------
        RuntimeError
            If `props` is missing required fields or if log directory cannot be created.
        ValueError
            If the provided prefix format string is invalid.
        OSError
            For underlying OS-level issues during directory or file handler setup.
        """
        # --- Validate props object and required nested attributes ---
        if not _3a1c73d6b0f9 or not _ccb465c19a78(_3a1c73d6b0f9, "app") or not _ccb465c19a78(_3a1c73d6b0f9, "logs"):
            raise _0883e68ec9af("Invalid Properties object: missing app/logs sections.")

        _7803eeab9ad5 = ["model_config_name", "logs_dir"]
        for _b7de2adcf87a in _7803eeab9ad5:
            if not _ccb465c19a78(_3a1c73d6b0f9._97ce33cf0469, _b7de2adcf87a):
                raise _0883e68ec9af(f"Missing required app property: '{_b7de2adcf87a}' in props.app.")

        _1bff5d1fbc6d = ["prefix", "suffix"]
        for _b7de2adcf87a in _1bff5d1fbc6d:
            if not _ccb465c19a78(_3a1c73d6b0f9._aea7f37126af, _b7de2adcf87a):
                raise _0883e68ec9af(f"Missing required log property: '{_b7de2adcf87a}' in props.logs.")

        _23b339c80bde = _3a1c73d6b0f9._97ce33cf0469._67e756f0dc45
        _740b128fa11b = os._5624b4bd8b82._bd8f716ee4dd(_3a1c73d6b0f9._97ce33cf0469._124c1a1accb0, _23b339c80bde)

        # --- Ensure log directory exists ---
        try:
            os._caae293cc583(_740b128fa11b, _baadacbea1f5=_ce4b7c8f9bf9)
        except _ee172cd3b94f as _78b9835228e8:
            raise _0883e68ec9af(f"Failed to create log directory: {_740b128fa11b}") from _78b9835228e8

        # --- Construct log filename ---
        _c8c0eb5b0e34 = _3a1c73d6b0f9._aea7f37126af._f8c11916ed1a
        _7c80a071c69d = self._de723d016297._15bdfffeca5b(_15bc390c5077=_c8c0eb5b0e34)
        _5ae6cef6d6ad = _3a1c73d6b0f9._aea7f37126af._2c0846a58c27
        _89c2704f390f = "_"._bd8f716ee4dd([_7c80a071c69d, _5ae6cef6d6ad])
        _ca1b30e67ea2 = os._5624b4bd8b82._bd8f716ee4dd(_740b128fa11b, _89c2704f390f)

        # --- Set formatter with UTC timestamps ---
        _0aaa6705ddfe = _4bb4d3d7e0a1._e0468b833240('%(asctime)s UTC %(module)s %(levelname)s: %(message)s')
        _0aaa6705ddfe._4d05beb61bb8 = time._0a132aeb3bb9  # ensure UTC timestamps

        # --- Create or fetch named logger ---
        _5ef704863127 = _4bb4d3d7e0a1._732f2f7c5f2a(_23b339c80bde)
        _5ef704863127._875cb97e82ce(_4bb4d3d7e0a1._32c882207b76)
        _5ef704863127._ca41ff97537c = _f7807a9108bb  # prevent double logging from root

        # --- Attach handlers only if not already configured ---
        if not _5ef704863127._02294486f72e:
            try:
                # File handler (rotates at midnight UTC)
                _c5db0d57538e = _3cd488fddd16(
                    _ca1b30e67ea2, _e332a0e517da='midnight', _f728882d7db5=0, _e7da3acafe15=_ce4b7c8f9bf9, _ab299c0045a4='utf-8'
                )
                _c5db0d57538e._a18b2d163dd1(_0aaa6705ddfe)
                _5ef704863127._1b21c23543eb(_c5db0d57538e)

                # Console handler (optional stream to stdout)
                _089f1100241f = _4bb4d3d7e0a1._619b532e0b92()
                _089f1100241f._a18b2d163dd1(_0aaa6705ddfe)
                _5ef704863127._1b21c23543eb(_089f1100241f)

            except _76105fa34e69 as _78b9835228e8:
                raise _0883e68ec9af("Failed to configure logger handlers.") from _78b9835228e8

        return _5ef704863127

    def _49366ed9338c(self, _cebfe99b6136: _75c0a7adb550, _f8c11916ed1a: _75c0a7adb550) -> _2537142e5c13:
        """
        Archive and remove log files with a specific prefix inside a directory.

        This method scans the specified directory for log files that:
        - Start with the given `prefix`
        - End with `.log`

        It writes all matching files into a new zip archive named `{prefix}_archive.zip`,
        stored in the same directory, then deletes the original `.log` files.

        Parameters
        ----------
        archive_log_path : str
            Path to the directory containing log files.
        prefix : str
            Log filename prefix (typically date-based, e.g., "2025-10-23").

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If the provided archive_log_path does not exist or is not a directory.
        PermissionError
            If read/write access to the directory or files is denied.
        OSError
            For unexpected I/O errors during zipping or deletion.
        """
        if not os._5624b4bd8b82._8c58a2170dd1(_cebfe99b6136):
            raise _1c30a0cce989(f"Log archive path does not exist or is not a directory: '{_cebfe99b6136}'")

        _8bd7f2780396 = os._5624b4bd8b82._bd8f716ee4dd(_cebfe99b6136, f"{_f8c11916ed1a}_archive.zip")

        try:
            with _4d9b13b6e69f._0228980efeba(_8bd7f2780396, 'w', _c7f078e35d4f=_4d9b13b6e69f._bfddbe4f16da) as _677e41f69af1:
                for _e11f05f167b8 in os._81dd80f00917(_cebfe99b6136):
                    if _e11f05f167b8._5b247bfab619(_f8c11916ed1a) and _e11f05f167b8._35172fca68e5('.log'):
                        _95cf142a43a0 = os._5624b4bd8b82._bd8f716ee4dd(_cebfe99b6136, _e11f05f167b8)
                        _677e41f69af1._518e4f32bcc5(_95cf142a43a0, _b25a24adf251=_e11f05f167b8)
                        os._ded73cb04f73(_95cf142a43a0)
        except _1ebcb09ad435 as _78b9835228e8:
            raise _1ebcb09ad435(f"Permission denied while archiving logs in '{_cebfe99b6136}'.") from _78b9835228e8
        except _ee172cd3b94f as _78b9835228e8:
            raise _ee172cd3b94f(f"Failed to create or write zip archive: {_78b9835228e8}") from _78b9835228e8
