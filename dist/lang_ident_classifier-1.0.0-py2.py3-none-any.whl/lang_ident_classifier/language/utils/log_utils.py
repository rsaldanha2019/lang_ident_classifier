# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : log_utils.py
# @Time             : 2025-10-23 13:54 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
import _fd5c88937124 as _a307fe926ae2
import time
import _bd4d04ecba01
from _fd5c88937124 import _d340bb649115
from _fd5c88937124._74305e26f09f import _6caec048c0cd
from _a600107cabeb._24085a21e1b0._15fab841969a._5b7db6bd72e9 import _de35fffd3a55
from _a600107cabeb._24085a21e1b0._15fab841969a._6c76b594dd7a import _5411d19d532a
from _a600107cabeb._24085a21e1b0._15fab841969a._b9ae8c4d7ae9 import _68c230a1dd44


class _55f3a479bfd2:
    """
    Utility class for application logging configuration and maintenance.

    Provides:
    ----------
    - Creation of a UTC time-based rotating file logger using project properties.
    - Automatic log directory creation under the application's log root.
    - Support for archiving old logs into zip files based on filename prefixes.

    This class ensures consistent logging configuration across distributed components.

    Example
    -------
    >>> props = Properties("/path/to/config.yaml")
    >>> log_util = LogUtils()
    >>> logger = log_util.get_time_rotated_log(props)
    >>> logger.info("Training started successfully.")
    """

    def _3fc22561d8a1(self) -> _ed7c33617985:
        """
        Initialize the LogUtils class by preparing reusable utility instances.

        Raises
        ------
        RuntimeError
            If dependent utility initialization fails (extremely rare).
        """
        try:
            self._6291806ad99e = _5411d19d532a()
            self._560b743a5411 = _68c230a1dd44()
        except _a72761e37063 as _b2f18c96d5d4:
            raise _63161edb88be("Failed to initialize LogUtils dependencies.") from _b2f18c96d5d4

    def _82c692830664(self, _d7c79d4b6789: _de35fffd3a55) -> _d340bb649115:
        """
        Configure and return a time-rotated logger instance based on application properties.

        This logger writes to a timestamped log file inside a model-specific directory
        under `props.app.logs_dir`. It uses a UTC-based `TimedRotatingFileHandler`
        that rotates daily at midnight (UTC).

        Parameters
        ----------
        props : Properties
            Application configuration object with structured fields:
            - `props.app.model_config_name` : str — name of the current model/config context.
            - `props.app.logs_dir` : str — base directory for logs.
            - `props.logs.prefix` : str — timestamp prefix format (strftime-compatible).
            - `props.logs.suffix` : str — filename suffix (e.g., "run.log").

        Returns
        -------
        logging.Logger
            Configured logger instance with file and stream handlers attached.

        Raises
        ------
        RuntimeError
            If `props` is missing required fields or if log directory cannot be created.
        ValueError
            If the provided prefix format string is invalid.
        OSError
            For underlying OS-level issues during directory or file handler setup.
        """
        # --- Validate props object and required nested attributes ---
        if not _d7c79d4b6789 or not _6b915c769d0e(_d7c79d4b6789, "app") or not _6b915c769d0e(_d7c79d4b6789, "logs"):
            raise _63161edb88be("Invalid Properties object: missing app/logs sections.")

        _6e1a2df5f1de = ["model_config_name", "logs_dir"]
        for _fec2b6324e64 in _6e1a2df5f1de:
            if not _6b915c769d0e(_d7c79d4b6789._e57d94fca8f0, _fec2b6324e64):
                raise _63161edb88be(f"Missing required app property: '{_fec2b6324e64}' in props.app.")

        _1906f13d1959 = ["prefix", "suffix"]
        for _fec2b6324e64 in _1906f13d1959:
            if not _6b915c769d0e(_d7c79d4b6789._dbfbf0f6e331, _fec2b6324e64):
                raise _63161edb88be(f"Missing required log property: '{_fec2b6324e64}' in props.logs.")

        _77f822fdc2f9 = _d7c79d4b6789._e57d94fca8f0._27e8845ce218
        _f66e488ed714 = os._32f3c440b1e1._6ab66c644bf5(_d7c79d4b6789._e57d94fca8f0._d41e32d2b5ce, _77f822fdc2f9)

        # --- Ensure log directory exists ---
        try:
            os._80d4283a39cc(_f66e488ed714, _922d4412154f=_bb516d2e9d57)
        except _47ce2f68a6a7 as _b2f18c96d5d4:
            raise _63161edb88be(f"Failed to create log directory: {_f66e488ed714}") from _b2f18c96d5d4

        # --- Construct log filename ---
        _6966f88fdeb2 = _d7c79d4b6789._dbfbf0f6e331._90a1e49c6b81
        _0caa9eb80d09 = self._560b743a5411._4ead4c042dc0(_6c26291d0467=_6966f88fdeb2)
        _03235a730ebd = _d7c79d4b6789._dbfbf0f6e331._e14352f3d595
        _4a3051c10cf8 = "_"._6ab66c644bf5([_0caa9eb80d09, _03235a730ebd])
        _7bcb51906a7d = os._32f3c440b1e1._6ab66c644bf5(_f66e488ed714, _4a3051c10cf8)

        # --- Set formatter with UTC timestamps ---
        _53591dcbc8d5 = _a307fe926ae2._5520059a78ee('%(asctime)s UTC %(module)s %(levelname)s: %(message)s')
        _53591dcbc8d5._3d1084720cc3 = time._4db5e114dd32  # ensure UTC timestamps

        # --- Create or fetch named logger ---
        _48405256b182 = _a307fe926ae2._fe08e9d512c5(_77f822fdc2f9)
        _48405256b182._f1ff6ccf7cd6(_a307fe926ae2._3cc5e56a1875)
        _48405256b182._d98b0bd5786d = _6414fb6cd2ba  # prevent double logging from root

        # --- Attach handlers only if not already configured ---
        if not _48405256b182._74305e26f09f:
            try:
                # File handler (rotates at midnight UTC)
                _f58ea7604ef9 = _6caec048c0cd(
                    _7bcb51906a7d, _883156aa332f='midnight', _90292611403f=0, _9c018c924550=_bb516d2e9d57, _fc6ceef0cd26='utf-8'
                )
                _f58ea7604ef9._ab6532d343c2(_53591dcbc8d5)
                _48405256b182._2081ffe975dd(_f58ea7604ef9)

                # Console handler (optional stream to stdout)
                _1413555ea0a3 = _a307fe926ae2._efcf733f5c5f()
                _1413555ea0a3._ab6532d343c2(_53591dcbc8d5)
                _48405256b182._2081ffe975dd(_1413555ea0a3)

            except _a72761e37063 as _b2f18c96d5d4:
                raise _63161edb88be("Failed to configure logger handlers.") from _b2f18c96d5d4

        return _48405256b182

    def _d44d3b81e410(self, _e781eccac49e: _7f861234c4a7, _90a1e49c6b81: _7f861234c4a7) -> _ed7c33617985:
        """
        Archive and remove log files with a specific prefix inside a directory.

        This method scans the specified directory for log files that:
        - Start with the given `prefix`
        - End with `.log`

        It writes all matching files into a new zip archive named `{prefix}_archive.zip`,
        stored in the same directory, then deletes the original `.log` files.

        Parameters
        ----------
        archive_log_path : str
            Path to the directory containing log files.
        prefix : str
            Log filename prefix (typically date-based, e.g., "2025-10-23").

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If the provided archive_log_path does not exist or is not a directory.
        PermissionError
            If read/write access to the directory or files is denied.
        OSError
            For unexpected I/O errors during zipping or deletion.
        """
        if not os._32f3c440b1e1._ebb159f79d2d(_e781eccac49e):
            raise _07d7dc4f894d(f"Log archive path does not exist or is not a directory: '{_e781eccac49e}'")

        _dd29c745b1a3 = os._32f3c440b1e1._6ab66c644bf5(_e781eccac49e, f"{_90a1e49c6b81}_archive.zip")

        try:
            with _bd4d04ecba01._65977e2af51f(_dd29c745b1a3, 'w', _8a82d107ba58=_bd4d04ecba01._63b5863dc2f8) as _88c98927cbfd:
                for _18a865c5209f in os._af562f685b3f(_e781eccac49e):
                    if _18a865c5209f._bcc5b821ddd0(_90a1e49c6b81) and _18a865c5209f._7056660ff725('.log'):
                        _f42d98dfe35b = os._32f3c440b1e1._6ab66c644bf5(_e781eccac49e, _18a865c5209f)
                        _88c98927cbfd._b6b03dc3d746(_f42d98dfe35b, _15c48897753a=_18a865c5209f)
                        os._81d256a3ba3c(_f42d98dfe35b)
        except _4b83adb32c84 as _b2f18c96d5d4:
            raise _4b83adb32c84(f"Permission denied while archiving logs in '{_e781eccac49e}'.") from _b2f18c96d5d4
        except _47ce2f68a6a7 as _b2f18c96d5d4:
            raise _47ce2f68a6a7(f"Failed to create or write zip archive: {_b2f18c96d5d4}") from _b2f18c96d5d4
