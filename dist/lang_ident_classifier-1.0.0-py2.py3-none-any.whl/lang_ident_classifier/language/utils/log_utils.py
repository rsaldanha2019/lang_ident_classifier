# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : log_utils.py
# @Time             : 2025-10-23 13:54 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
import _92466c78385a as _c45df80a2263
import time
import _d4173a031c5f
from _92466c78385a import _412bcb111afa
from _92466c78385a._e7eacad27173 import _ff4d1e3f9c84
from _9c4173d0ee3f._c8c5dc45139d._6c1e5cc3385f._166e5f9a7bfc import _de877b3c2d87
from _9c4173d0ee3f._c8c5dc45139d._6c1e5cc3385f._c27c42f841ef import _2139af41f408
from _9c4173d0ee3f._c8c5dc45139d._6c1e5cc3385f._d9a3aae6bafe import _c9e6d6f745f2


class _bf4a7f01c5a9:
    """
    Utility class for application logging configuration and maintenance.

    Provides:
    ----------
    - Creation of a UTC time-based rotating file logger using project properties.
    - Automatic log directory creation under the application's log root.
    - Support for archiving old logs into zip files based on filename prefixes.

    This class ensures consistent logging configuration across distributed components.

    Example
    -------
    >>> props = Properties("/path/to/config.yaml")
    >>> log_util = LogUtils()
    >>> logger = log_util.get_time_rotated_log(props)
    >>> logger.info("Training started successfully.")
    """

    def _25010d4efa5d(self) -> _bf0ac4fad311:
        """
        Initialize the LogUtils class by preparing reusable utility instances.

        Raises
        ------
        RuntimeError
            If dependent utility initialization fails (extremely rare).
        """
        try:
            self._9ba5eb44b1c6 = _2139af41f408()
            self._9bde6160f8cd = _c9e6d6f745f2()
        except _6bef4cc60097 as _db276c0a815c:
            raise _619a3657fcd6("Failed to initialize LogUtils dependencies.") from _db276c0a815c

    def _d9051fda75a5(self, _4a2f9784abba: _de877b3c2d87) -> _412bcb111afa:
        """
        Configure and return a time-rotated logger instance based on application properties.

        This logger writes to a timestamped log file inside a model-specific directory
        under `props.app.logs_dir`. It uses a UTC-based `TimedRotatingFileHandler`
        that rotates daily at midnight (UTC).

        Parameters
        ----------
        props : Properties
            Application configuration object with structured fields:
            - `props.app.model_config_name` : str — name of the current model/config context.
            - `props.app.logs_dir` : str — base directory for logs.
            - `props.logs.prefix` : str — timestamp prefix format (strftime-compatible).
            - `props.logs.suffix` : str — filename suffix (e.g., "run.log").

        Returns
        -------
        logging.Logger
            Configured logger instance with file and stream handlers attached.

        Raises
        ------
        RuntimeError
            If `props` is missing required fields or if log directory cannot be created.
        ValueError
            If the provided prefix format string is invalid.
        OSError
            For underlying OS-level issues during directory or file handler setup.
        """
        # --- Validate props object and required nested attributes ---
        if not _4a2f9784abba or not _e778b4d14564(_4a2f9784abba, "app") or not _e778b4d14564(_4a2f9784abba, "logs"):
            raise _619a3657fcd6("Invalid Properties object: missing app/logs sections.")

        _6bb1b987ebd0 = ["model_config_name", "logs_dir"]
        for _4813824eef00 in _6bb1b987ebd0:
            if not _e778b4d14564(_4a2f9784abba._da70788446af, _4813824eef00):
                raise _619a3657fcd6(f"Missing required app property: '{_4813824eef00}' in props.app.")

        _bab529d68fcd = ["prefix", "suffix"]
        for _4813824eef00 in _bab529d68fcd:
            if not _e778b4d14564(_4a2f9784abba._36b2bf365c9a, _4813824eef00):
                raise _619a3657fcd6(f"Missing required log property: '{_4813824eef00}' in props.logs.")

        _26817f5332c0 = _4a2f9784abba._da70788446af._055d21801869
        _b3aff996be20 = os._7c799063f1fa._b0f11b6614d7(_4a2f9784abba._da70788446af._fcd54088212c, _26817f5332c0)

        # --- Ensure log directory exists ---
        try:
            os._5745fc20658a(_b3aff996be20, _9455443f06d2=_8c8526afc305)
        except _1b0b7e5920eb as _db276c0a815c:
            raise _619a3657fcd6(f"Failed to create log directory: {_b3aff996be20}") from _db276c0a815c

        # --- Construct log filename ---
        _1542bc4c9819 = _4a2f9784abba._36b2bf365c9a._20d50f5225c0
        _04ec07d8193f = self._9bde6160f8cd._82188ad91f44(_599b87f27b8e=_1542bc4c9819)
        _359d42602a46 = _4a2f9784abba._36b2bf365c9a._68cf483cb31f
        _581b74048c31 = "_"._b0f11b6614d7([_04ec07d8193f, _359d42602a46])
        _ca80239a7388 = os._7c799063f1fa._b0f11b6614d7(_b3aff996be20, _581b74048c31)

        # --- Set formatter with UTC timestamps ---
        _88a19bd5d5c5 = _c45df80a2263._017ff6147c98('%(asctime)s UTC %(module)s %(levelname)s: %(message)s')
        _88a19bd5d5c5._07d855919512 = time._d2323c0bc05c  # ensure UTC timestamps

        # --- Create or fetch named logger ---
        _289553790fc4 = _c45df80a2263._39bef068851b(_26817f5332c0)
        _289553790fc4._936ab67336c1(_c45df80a2263._885dbda479b6)
        _289553790fc4._fc1474ae6b00 = _bea0f4182675  # prevent double logging from root

        # --- Attach handlers only if not already configured ---
        if not _289553790fc4._e7eacad27173:
            try:
                # File handler (rotates at midnight UTC)
                _574401ff68fd = _ff4d1e3f9c84(
                    _ca80239a7388, _291f389751ef='midnight', _517795078611=0, _f588cb02bcc7=_8c8526afc305, _1042da8c07be='utf-8'
                )
                _574401ff68fd._70cf9b9941de(_88a19bd5d5c5)
                _289553790fc4._82048efc0abc(_574401ff68fd)

                # Console handler (optional stream to stdout)
                _56e6b23a30ff = _c45df80a2263._442ccdb22e29()
                _56e6b23a30ff._70cf9b9941de(_88a19bd5d5c5)
                _289553790fc4._82048efc0abc(_56e6b23a30ff)

            except _6bef4cc60097 as _db276c0a815c:
                raise _619a3657fcd6("Failed to configure logger handlers.") from _db276c0a815c

        return _289553790fc4

    def _9fe4ba37fe65(self, _1d215ee6428e: _a5d2317111f1, _20d50f5225c0: _a5d2317111f1) -> _bf0ac4fad311:
        """
        Archive and remove log files with a specific prefix inside a directory.

        This method scans the specified directory for log files that:
        - Start with the given `prefix`
        - End with `.log`

        It writes all matching files into a new zip archive named `{prefix}_archive.zip`,
        stored in the same directory, then deletes the original `.log` files.

        Parameters
        ----------
        archive_log_path : str
            Path to the directory containing log files.
        prefix : str
            Log filename prefix (typically date-based, e.g., "2025-10-23").

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If the provided archive_log_path does not exist or is not a directory.
        PermissionError
            If read/write access to the directory or files is denied.
        OSError
            For unexpected I/O errors during zipping or deletion.
        """
        if not os._7c799063f1fa._6c44aa9f159f(_1d215ee6428e):
            raise _be011f4cd4e6(f"Log archive path does not exist or is not a directory: '{_1d215ee6428e}'")

        _100372e4adbf = os._7c799063f1fa._b0f11b6614d7(_1d215ee6428e, f"{_20d50f5225c0}_archive.zip")

        try:
            with _d4173a031c5f._51aa10af7dd3(_100372e4adbf, 'w', _6200f3e84e0c=_d4173a031c5f._4ef157ee83b5) as _a12e7ca203be:
                for _bb8863ed3e8b in os._e04dcf269c00(_1d215ee6428e):
                    if _bb8863ed3e8b._aa5e671499d2(_20d50f5225c0) and _bb8863ed3e8b._2ad122408e72('.log'):
                        _47ccbd7be33c = os._7c799063f1fa._b0f11b6614d7(_1d215ee6428e, _bb8863ed3e8b)
                        _a12e7ca203be._388d03c3cbb1(_47ccbd7be33c, _df3ccbfc27f0=_bb8863ed3e8b)
                        os._da63432b10ac(_47ccbd7be33c)
        except _68be1aa22735 as _db276c0a815c:
            raise _68be1aa22735(f"Permission denied while archiving logs in '{_1d215ee6428e}'.") from _db276c0a815c
        except _1b0b7e5920eb as _db276c0a815c:
            raise _1b0b7e5920eb(f"Failed to create or write zip archive: {_db276c0a815c}") from _db276c0a815c
