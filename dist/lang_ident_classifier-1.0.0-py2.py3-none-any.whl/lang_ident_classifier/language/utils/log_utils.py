# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : log_utils.py
# @Time             : 2025-10-23 13:54 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _080aef156b89
import _89d28706d7ab as _dfc580dcca10
import _aa10760da538
import _6fb4eccb49a8
from _89d28706d7ab import _fd75a080f43b
from _89d28706d7ab._9c650ecdc71d import _fe4f03148b14
from _2dd4fe2aad5f._4649f44b2229._ddbdd7f13232._253ffa3d83a4 import _ff243559f7ab
from _2dd4fe2aad5f._4649f44b2229._ddbdd7f13232._553d698e38df import _a3e7dfba3aaf
from _2dd4fe2aad5f._4649f44b2229._ddbdd7f13232._dc6924155f67 import _6dd618abbcce


class _2bc93c93c48e:
    """
    Utility class for application logging configuration and maintenance.

    Provides:
    ----------
    - Creation of a UTC time-based rotating file logger using project properties.
    - Automatic log directory creation under the application's log root.
    - Support for archiving old logs into zip files based on filename prefixes.

    This class ensures consistent logging configuration across distributed components.

    Example
    -------
    >>> props = Properties("/path/to/config.yaml")
    >>> log_util = LogUtils()
    >>> logger = log_util.get_time_rotated_log(props)
    >>> logger.info("Training started successfully.")
    """

    def _12f5a2d8dc1a(self) -> _2416ed11daf7:
        """
        Initialize the LogUtils class by preparing reusable utility instances.

        Raises
        ------
        RuntimeError
            If dependent utility initialization fails (extremely rare).
        """
        try:
            self._0a452d7c9d96 = _a3e7dfba3aaf()
            self._d85b35c7e9b8 = _6dd618abbcce()
        except _95f0b87a735b as _19a82680ddbe:
            raise _6d56e863c6b1("Failed to initialize LogUtils dependencies.") from _19a82680ddbe

    def _d18055a2965a(self, _6ed28baa1804: _ff243559f7ab) -> _fd75a080f43b:
        """
        Configure and return a time-rotated logger instance based on application properties.

        This logger writes to a timestamped log file inside a model-specific directory
        under `props.app.logs_dir`. It uses a UTC-based `TimedRotatingFileHandler`
        that rotates daily at midnight (UTC).

        Parameters
        ----------
        props : Properties
            Application configuration object with structured fields:
            - `props.app.model_config_name` : str — name of the current model/config context.
            - `props.app.logs_dir` : str — base directory for logs.
            - `props.logs.prefix` : str — timestamp prefix format (strftime-compatible).
            - `props.logs.suffix` : str — filename suffix (e.g., "run.log").

        Returns
        -------
        logging.Logger
            Configured logger instance with file and stream handlers attached.

        Raises
        ------
        RuntimeError
            If `props` is missing required fields or if log directory cannot be created.
        ValueError
            If the provided prefix format string is invalid.
        OSError
            For underlying OS-level issues during directory or file handler setup.
        """
        # --- Validate props object and required nested attributes ---
        if not _6ed28baa1804 or not _5aa5d3babe80(_6ed28baa1804, "app") or not _5aa5d3babe80(_6ed28baa1804, "logs"):
            raise _6d56e863c6b1("Invalid Properties object: missing app/logs sections.")

        _6bf8403525eb = ["model_config_name", "logs_dir"]
        for _cbd699d07b8a in _6bf8403525eb:
            if not _5aa5d3babe80(_6ed28baa1804._5f1d321f9a20, _cbd699d07b8a):
                raise _6d56e863c6b1(f"Missing required app property: '{_cbd699d07b8a}' in props.app.")

        _633ee608eab9 = ["prefix", "suffix"]
        for _cbd699d07b8a in _633ee608eab9:
            if not _5aa5d3babe80(_6ed28baa1804._c8458d3bc62c, _cbd699d07b8a):
                raise _6d56e863c6b1(f"Missing required log property: '{_cbd699d07b8a}' in props.logs.")

        _434013660303 = _6ed28baa1804._5f1d321f9a20._00ddf1855957
        _7b1637553871 = _080aef156b89._a9e2a19cae73._e1b90dc3313d(_6ed28baa1804._5f1d321f9a20._e10f87403558, _434013660303)

        # --- Ensure log directory exists ---
        try:
            _080aef156b89._752bf6d293ec(_7b1637553871, _e941ada753c8=_24e8124702da)
        except _b5258ddbba42 as _19a82680ddbe:
            raise _6d56e863c6b1(f"Failed to create log directory: {_7b1637553871}") from _19a82680ddbe

        # --- Construct log filename ---
        _6494bf34b40b = _6ed28baa1804._c8458d3bc62c._6d7f127bc419
        _cb05ba9168ab = self._d85b35c7e9b8._f470f5852bd3(_b9a07fb224a0=_6494bf34b40b)
        _1b5504b91d9a = _6ed28baa1804._c8458d3bc62c._c8186e726b68
        _8462df865e78 = "_"._e1b90dc3313d([_cb05ba9168ab, _1b5504b91d9a])
        _56dad6b91220 = _080aef156b89._a9e2a19cae73._e1b90dc3313d(_7b1637553871, _8462df865e78)

        # --- Set formatter with UTC timestamps ---
        _94e47721b619 = _dfc580dcca10._de04453adc86('%(asctime)s UTC %(module)s %(levelname)s: %(message)s')
        _94e47721b619._fa21539186ad = _aa10760da538._0d2658b12f77  # ensure UTC timestamps

        # --- Create or fetch named logger ---
        _6714e4fd564b = _dfc580dcca10._2e42abbb9afb(_434013660303)
        _6714e4fd564b._63c8748e8ead(_dfc580dcca10._4c4f056a7a14)
        _6714e4fd564b._3eeadac6a549 = _2998fe3fde0d  # prevent double logging from root

        # --- Attach handlers only if not already configured ---
        if not _6714e4fd564b._9c650ecdc71d:
            try:
                # File handler (rotates at midnight UTC)
                _bf5736b9b26b = _fe4f03148b14(
                    _56dad6b91220, _7a06e62367a9='midnight', _1623bc0bdb0e=0, _200c770a5e25=_24e8124702da, _b22a32a04463='utf-8'
                )
                _bf5736b9b26b._70477dfcf540(_94e47721b619)
                _6714e4fd564b._d6d8508d6629(_bf5736b9b26b)

                # Console handler (optional stream to stdout)
                _3796701b0763 = _dfc580dcca10._6334c6624f0e()
                _3796701b0763._70477dfcf540(_94e47721b619)
                _6714e4fd564b._d6d8508d6629(_3796701b0763)

            except _95f0b87a735b as _19a82680ddbe:
                raise _6d56e863c6b1("Failed to configure logger handlers.") from _19a82680ddbe

        return _6714e4fd564b

    def _9b324319facb(self, _cfd48be3ae59: _ec6c28985b6c, _6d7f127bc419: _ec6c28985b6c) -> _2416ed11daf7:
        """
        Archive and remove log files with a specific prefix inside a directory.

        This method scans the specified directory for log files that:
        - Start with the given `prefix`
        - End with `.log`

        It writes all matching files into a new zip archive named `{prefix}_archive.zip`,
        stored in the same directory, then deletes the original `.log` files.

        Parameters
        ----------
        archive_log_path : str
            Path to the directory containing log files.
        prefix : str
            Log filename prefix (typically date-based, e.g., "2025-10-23").

        Returns
        -------
        None

        Raises
        ------
        FileNotFoundError
            If the provided archive_log_path does not exist or is not a directory.
        PermissionError
            If read/write access to the directory or files is denied.
        OSError
            For unexpected I/O errors during zipping or deletion.
        """
        if not _080aef156b89._a9e2a19cae73._19ae830dc2e5(_cfd48be3ae59):
            raise _4503502e43d4(f"Log archive path does not exist or is not a directory: '{_cfd48be3ae59}'")

        _5259757600d8 = _080aef156b89._a9e2a19cae73._e1b90dc3313d(_cfd48be3ae59, f"{_6d7f127bc419}_archive.zip")

        try:
            with _6fb4eccb49a8._f67295af2ff7(_5259757600d8, 'w', _1da3cb791f22=_6fb4eccb49a8._fc74727b3c8f) as _c50d34c72051:
                for _6516911c511f in _080aef156b89._b989309b63ef(_cfd48be3ae59):
                    if _6516911c511f._fc2458c796fa(_6d7f127bc419) and _6516911c511f._07173e3fc19e('.log'):
                        _e23be30daba4 = _080aef156b89._a9e2a19cae73._e1b90dc3313d(_cfd48be3ae59, _6516911c511f)
                        _c50d34c72051._46cbbace3eb2(_e23be30daba4, _7d70c73edb69=_6516911c511f)
                        _080aef156b89._f76b276b6893(_e23be30daba4)
        except _70fef81990f5 as _19a82680ddbe:
            raise _70fef81990f5(f"Permission denied while archiving logs in '{_cfd48be3ae59}'.") from _19a82680ddbe
        except _b5258ddbba42 as _19a82680ddbe:
            raise _b5258ddbba42(f"Failed to create or write zip archive: {_19a82680ddbe}") from _19a82680ddbe
