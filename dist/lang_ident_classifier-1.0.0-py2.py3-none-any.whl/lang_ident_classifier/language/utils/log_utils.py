# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : log_utils
# @Time             : 18/12/23 9:04 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import os
import logging as lg
import time
import zipfile
from logging import Logger
from logging.handlers import TimedRotatingFileHandler
from lang_ident_classifier.language.utils.property_utils import Properties
from lang_ident_classifier.language.utils.file_dir_utils import FileDirUtils
from lang_ident_classifier.language.utils.date_time_utils import DateTimeUtils


class LogUtils:
    """
    Operations for Logging.
    """

    def __init__(self):
        self.fdu = FileDirUtils()
        self.dtu = DateTimeUtils()

    def get_time_rotated_log(self, props: Properties) -> Logger:
        """
        Returns a configured logger with TimedRotatingFileHandler.
        :param props: properties file object
        :return: logger object
        """
        log_config_name = props.app.model_config_name
        log_dir_path = os.path.join(props.app.logs_dir, log_config_name)

        # Ensure log directory exists
        os.makedirs(log_dir_path, exist_ok=True)

        # Construct log filename
        log_datetime_prefix_format = props.logs.prefix
        log_prefix = self.dtu.get_utc_datetime_timestamp_string(datetime_format=log_datetime_prefix_format)
        log_suffix = props.logs.suffix
        log_file_name = "_".join([log_prefix, log_suffix])
        log_file_path = os.path.join(log_dir_path, log_file_name)

        # Set formatter
        formatter = lg.Formatter('%(asctime)s UTC %(module)s %(levelname)s: %(message)s')
        formatter.converter = time.gmtime

        # Create logger instance (avoid global root logger)
        logger = lg.getLogger(log_config_name)
        logger.setLevel(lg.INFO)
        logger.propagate = False  # Prevent double logging

        # Clear previous handlers (only if not already configured)
        if not logger.handlers:
            # File handler with rotation
            file_handler = TimedRotatingFileHandler(
                log_file_path, when='midnight', backupCount=0, utc=True, encoding='utf-8'
            )
            file_handler.setFormatter(formatter)
            logger.addHandler(file_handler)

            # Optional: Console output
            stream_handler = lg.StreamHandler()
            stream_handler.setFormatter(formatter)
            logger.addHandler(stream_handler)

        return logger

    def zip_logs_with_prefix(self, archive_log_path: str, prefix: str) -> None:
        """
        Takes in archive log path and prefix and archives log with same prefix.
        :param archive_log_path: location of archive for logs
        :param prefix: prefix of the log files
        :return:
        """
        with zipfile.ZipFile(f'{prefix}_archive.zip', 'w') as zipf:
            for filename in os.listdir(archive_log_path):
                if filename.startswith(prefix) and filename.endswith('.log'):
                    file_path = os.path.join(archive_log_path, filename)
                    zipf.write(file_path, arcname=filename)
                    os.remove(file_path)
