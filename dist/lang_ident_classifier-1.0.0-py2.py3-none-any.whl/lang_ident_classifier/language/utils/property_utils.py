# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : property_utils.py
# @Time             : 2025-10-23 13:56 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from _66d14501f7ca import _5d39adf635c2, _6651904c1dc6
import _c217d7117587
from _c217d7117587 import _7453b874b285
from _9638c58bee13._c09e34c874b9._050a5d35682e._f0dce2cd38ca import _e2543f962ead


class _c7951a613fd3:
    """
    A lightweight container for hierarchical configuration attributes.

    This class allows dynamic assignment of attributes from dictionaries or YAML files,
    supporting nested structures by recursively setting sub-objects as `Properties`.

    Example
    -------
    >>> p = Properties()
    >>> p.set_attribute("model_name", "BERT")
    >>> p.model_name
    'BERT'
    """

    def _c9d01bd5f2a2(self, _b2fc0540a8fd: _69deb571824f, _ffbbcd058c81: _5d39adf635c2) -> _e9d04aca17ba:
        """
        Dynamically set an attribute on the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to assign.
        value : Any
            The value to be stored in the attribute.

        Returns
        -------
        None

        Raises
        ------
        TypeError
            If `attr_name` is not a string.
        """
        if not _f68e3dc55e5d(_b2fc0540a8fd, _69deb571824f):
            raise _963e4285c5c3("Attribute name must be a string.")
        _67f2db154fd3(self, _b2fc0540a8fd, _ffbbcd058c81)

    def _0e043f6ca547(self, _b2fc0540a8fd: _69deb571824f) -> _5d39adf635c2:
        """
        Retrieve the value of a given attribute from the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to retrieve.

        Returns
        -------
        Any
            The value of the specified attribute.

        Raises
        ------
        AttributeError
            If the specified attribute does not exist.
        TypeError
            If `attr_name` is not a string.
        """
        if not _f68e3dc55e5d(_b2fc0540a8fd, _69deb571824f):
            raise _963e4285c5c3("Attribute name must be a string.")
        if not _ce3bebd61ce4(self, _b2fc0540a8fd):
            raise _6b2531ffdffe(f"Property '{_b2fc0540a8fd}' not found.")
        return _1bcc3a643fb5(self, _b2fc0540a8fd)


class _5fb64a2780db:
    """
    Utility class for reading, parsing, and converting configuration properties
    between YAML files, dictionaries, and `Properties` objects.

    Example
    -------
    >>> putils = PropertyUtils()
    >>> props = putils.get_yaml_config_properties("config.yaml")
    >>> props.app.model_name
    'bert-base-tamil'
    """

    def _82d1c7ab957e(self, _ac9debcb2882: _6651904c1dc6[_69deb571824f, _5d39adf635c2]) -> _5cf07f11098c:
        """
        Convert a dictionary of properties into a nested `Properties` object.

        Parameters
        ----------
        props_dict : dict
            A dictionary containing key-value pairs to convert into attributes.

        Returns
        -------
        Properties
            A `Properties` object mirroring the structure of `props_dict`.

        Raises
        ------
        ValueError
            If the input dictionary is empty.
        TypeError
            If `props_dict` is not a dictionary.
        """
        if not _f68e3dc55e5d(_ac9debcb2882, _1793c340d952):
            raise _963e4285c5c3("props_dict must be a dictionary.")
        if not _ac9debcb2882:
            raise _bc76a16d2a87("Properties dictionary is empty.")

        _88244703067c = _5cf07f11098c()
        for _0f88b08de559, _ffbbcd058c81 in _ac9debcb2882._79918da84fcb():
            if _f68e3dc55e5d(_ffbbcd058c81, _1793c340d952):
                _f19e7ed57d24 = self._c3f088a5c426(_ffbbcd058c81)
                _88244703067c._fd952fc16809(_b2fc0540a8fd=_0f88b08de559, _ffbbcd058c81=_f19e7ed57d24)
            else:
                _88244703067c._fd952fc16809(_b2fc0540a8fd=_0f88b08de559, _ffbbcd058c81=_ffbbcd058c81)
        return _88244703067c

    def _35c0c7cd6cdc(self, _88244703067c: _5cf07f11098c) -> _6651904c1dc6[_69deb571824f, _5d39adf635c2]:
        """
        Convert a `Properties` object back into a dictionary recursively.

        Parameters
        ----------
        props : Properties
            The Properties object to convert.

        Returns
        -------
        dict
            A dictionary representation of the Properties object.

        Raises
        ------
        ValueError
            If the Properties object is None or empty.
        TypeError
            If the provided `props` is not an instance of Properties.
        """
        if not _f68e3dc55e5d(_88244703067c, _5cf07f11098c):
            raise _963e4285c5c3("Expected a Properties object.")
        if not _88244703067c._7c35ff599be4:
            raise _bc76a16d2a87("Properties object is empty.")

        _ac9debcb2882: _6651904c1dc6[_69deb571824f, _5d39adf635c2] = {}
        for _0f88b08de559, _ffbbcd058c81 in _88244703067c._7c35ff599be4._79918da84fcb():
            if _f68e3dc55e5d(_ffbbcd058c81, _5cf07f11098c):
                _ac9debcb2882[_0f88b08de559] = self._30f925c20968(_ffbbcd058c81)
            else:
                _ac9debcb2882[_0f88b08de559] = _ffbbcd058c81
        return _ac9debcb2882

    def _da38698c48cf(self, _a61ceb246c8d: _69deb571824f) -> _5cf07f11098c:
        """
        Load a YAML configuration file and return it as a `Properties` object.

        Parameters
        ----------
        config_file : str
            Path to the YAML configuration file.

        Returns
        -------
        Properties
            A `Properties` object containing all fields from the YAML file.

        Raises
        ------
        FileNotFoundError
            If the specified YAML file does not exist.
        YAMLError
            If there is an error parsing the YAML file.
        ValueError
            If the loaded YAML file is empty or invalid.
        RuntimeError
            If an unexpected error occurs during property conversion.
        """
        _f51bd1fd2785 = _e2543f962ead()
        if not _f51bd1fd2785._81d8552bced5(_3b9e94355598=_a61ceb246c8d):
            raise _f6d4c88690d4(f"YAML configuration file not found: '{_a61ceb246c8d}'")

        try:
            with _5c2699b096fb(_a61ceb246c8d, "r", _a6e2ee6ed8fa="utf-8") as _d164fa1315e5:
                _ac9debcb2882 = _c217d7117587._06c86ec37b5c(_d164fa1315e5)
                if not _ac9debcb2882:
                    raise _bc76a16d2a87(f"Configuration file '{_a61ceb246c8d}' is empty or invalid.")
                _88244703067c = self._c3f088a5c426(_ac9debcb2882)
                return _88244703067c
        except _7453b874b285 as _fc4f86b5c19a:
            raise _7453b874b285(f"YAML parsing failed for '{_a61ceb246c8d}': {_fc4f86b5c19a}") from _fc4f86b5c19a
        except _e397a157dba9 as _5cb82b2d84aa:
            raise _0d65687ff062(f"Failed to load configuration from '{_a61ceb246c8d}': {_5cb82b2d84aa}") from _5cb82b2d84aa
