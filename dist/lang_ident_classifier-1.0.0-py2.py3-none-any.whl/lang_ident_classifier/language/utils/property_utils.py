# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : property_utils.py
# @Time             : 2025-10-23 13:56 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from typing import _9a535d29c0c0, _f2592413d1b5
import _ac2f561b906d
from _ac2f561b906d import _e0a311c35401
from _df82ea91e356._5307363e47c9._7b19bf4b8fa8._abedb361e6d3 import _57038c8fde8a


class _e35be2b05114:
    """
    A lightweight container for hierarchical configuration attributes.

    This class allows dynamic assignment of attributes from dictionaries or YAML files,
    supporting nested structures by recursively setting sub-objects as `Properties`.

    Example
    -------
    >>> p = Properties()
    >>> p.set_attribute("model_name", "BERT")
    >>> p.model_name
    'BERT'
    """

    def _f282f872f51b(self, _6ee7ccacaf8d: _a1b4f5859cc5, _fa99b8b30b28: _9a535d29c0c0) -> _efa5489da9a2:
        """
        Dynamically set an attribute on the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to assign.
        value : Any
            The value to be stored in the attribute.

        Returns
        -------
        None

        Raises
        ------
        TypeError
            If `attr_name` is not a string.
        """
        if not _28988e609647(_6ee7ccacaf8d, _a1b4f5859cc5):
            raise _6102337215ed("Attribute name must be a string.")
        _22ad4fdfb4c1(self, _6ee7ccacaf8d, _fa99b8b30b28)

    def _9a7fe1adee72(self, _6ee7ccacaf8d: _a1b4f5859cc5) -> _9a535d29c0c0:
        """
        Retrieve the value of a given attribute from the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to retrieve.

        Returns
        -------
        Any
            The value of the specified attribute.

        Raises
        ------
        AttributeError
            If the specified attribute does not exist.
        TypeError
            If `attr_name` is not a string.
        """
        if not _28988e609647(_6ee7ccacaf8d, _a1b4f5859cc5):
            raise _6102337215ed("Attribute name must be a string.")
        if not _02aae90010fb(self, _6ee7ccacaf8d):
            raise _9b633fca8b3c(f"Property '{_6ee7ccacaf8d}' not found.")
        return _1327e289e954(self, _6ee7ccacaf8d)


class _626ffe3c5207:
    """
    Utility class for reading, parsing, and converting configuration properties
    between YAML files, dictionaries, and `Properties` objects.

    Example
    -------
    >>> putils = PropertyUtils()
    >>> props = putils.get_yaml_config_properties("config.yaml")
    >>> props.app.model_name
    'bert-base-tamil'
    """

    def _7ea323a3fc1d(self, _02b7f2c2f826: _f2592413d1b5[_a1b4f5859cc5, _9a535d29c0c0]) -> _e4d747b3be9b:
        """
        Convert a dictionary of properties into a nested `Properties` object.

        Parameters
        ----------
        props_dict : dict
            A dictionary containing key-value pairs to convert into attributes.

        Returns
        -------
        Properties
            A `Properties` object mirroring the structure of `props_dict`.

        Raises
        ------
        ValueError
            If the input dictionary is empty.
        TypeError
            If `props_dict` is not a dictionary.
        """
        if not _28988e609647(_02b7f2c2f826, _2d4f7cfdc20c):
            raise _6102337215ed("props_dict must be a dictionary.")
        if not _02b7f2c2f826:
            raise _761933943a91("Properties dictionary is empty.")

        _a0a027ced932 = _e4d747b3be9b()
        for _f2724e515820, _fa99b8b30b28 in _02b7f2c2f826._95bbddfeb519():
            if _28988e609647(_fa99b8b30b28, _2d4f7cfdc20c):
                _c79c5388a1a5 = self._91bda8effc01(_fa99b8b30b28)
                _a0a027ced932._a93adf6a3f66(_6ee7ccacaf8d=_f2724e515820, _fa99b8b30b28=_c79c5388a1a5)
            else:
                _a0a027ced932._a93adf6a3f66(_6ee7ccacaf8d=_f2724e515820, _fa99b8b30b28=_fa99b8b30b28)
        return _a0a027ced932

    def _96665a0ec5fb(self, _a0a027ced932: _e4d747b3be9b) -> _f2592413d1b5[_a1b4f5859cc5, _9a535d29c0c0]:
        """
        Convert a `Properties` object back into a dictionary recursively.

        Parameters
        ----------
        props : Properties
            The Properties object to convert.

        Returns
        -------
        dict
            A dictionary representation of the Properties object.

        Raises
        ------
        ValueError
            If the Properties object is None or empty.
        TypeError
            If the provided `props` is not an instance of Properties.
        """
        if not _28988e609647(_a0a027ced932, _e4d747b3be9b):
            raise _6102337215ed("Expected a Properties object.")
        if not _a0a027ced932._dd868445d8d5:
            raise _761933943a91("Properties object is empty.")

        _02b7f2c2f826: _f2592413d1b5[_a1b4f5859cc5, _9a535d29c0c0] = {}
        for _f2724e515820, _fa99b8b30b28 in _a0a027ced932._dd868445d8d5._95bbddfeb519():
            if _28988e609647(_fa99b8b30b28, _e4d747b3be9b):
                _02b7f2c2f826[_f2724e515820] = self._0618ee0df95b(_fa99b8b30b28)
            else:
                _02b7f2c2f826[_f2724e515820] = _fa99b8b30b28
        return _02b7f2c2f826

    def _1ed1edb7520f(self, _bae416e0f1a9: _a1b4f5859cc5) -> _e4d747b3be9b:
        """
        Load a YAML configuration file and return it as a `Properties` object.

        Parameters
        ----------
        config_file : str
            Path to the YAML configuration file.

        Returns
        -------
        Properties
            A `Properties` object containing all fields from the YAML file.

        Raises
        ------
        FileNotFoundError
            If the specified YAML file does not exist.
        YAMLError
            If there is an error parsing the YAML file.
        ValueError
            If the loaded YAML file is empty or invalid.
        RuntimeError
            If an unexpected error occurs during property conversion.
        """
        _a3e2153565e8 = _57038c8fde8a()
        if not _a3e2153565e8._9bd6a208f8ee(_2deebe8cb3a8=_bae416e0f1a9):
            raise _b30cbd032774(f"YAML configuration file not found: '{_bae416e0f1a9}'")

        try:
            with _4dfb89fbf1a7(_bae416e0f1a9, "r", _67df8ded74d5="utf-8") as _37870629f7b6:
                _02b7f2c2f826 = _ac2f561b906d._bd3d610e511d(_37870629f7b6)
                if not _02b7f2c2f826:
                    raise _761933943a91(f"Configuration file '{_bae416e0f1a9}' is empty or invalid.")
                _a0a027ced932 = self._91bda8effc01(_02b7f2c2f826)
                return _a0a027ced932
        except _e0a311c35401 as _afa0dcc6ecb1:
            raise _e0a311c35401(f"YAML parsing failed for '{_bae416e0f1a9}': {_afa0dcc6ecb1}") from _afa0dcc6ecb1
        except _8bd1d0e6d57f as _608b43b7cdc8:
            raise _a0c4b09038d2(f"Failed to load configuration from '{_bae416e0f1a9}': {_608b43b7cdc8}") from _608b43b7cdc8
