# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : property_utils.py
# @Time             : 2025-10-23 13:56 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from typing import _b0d7b6857496, _63045e7e2e82
import _e0f610f68f66
from _e0f610f68f66 import _fc5a475b2aeb
from _d6c858873a11._ddcb797bb968._8314fede6cf1._2881556390f3 import _2f5133f3c9f1


class _41a1110afe14:
    """
    A lightweight container for hierarchical configuration attributes.

    This class allows dynamic assignment of attributes from dictionaries or YAML files,
    supporting nested structures by recursively setting sub-objects as `Properties`.

    Example
    -------
    >>> p = Properties()
    >>> p.set_attribute("model_name", "BERT")
    >>> p.model_name
    'BERT'
    """

    def _2a632554b7fe(self, _28d08ce73461: _425456dbcc95, _039ab2c71ea8: _b0d7b6857496) -> _70677e9f1c95:
        """
        Dynamically set an attribute on the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to assign.
        value : Any
            The value to be stored in the attribute.

        Returns
        -------
        None

        Raises
        ------
        TypeError
            If `attr_name` is not a string.
        """
        if not _2aa0ecbd5693(_28d08ce73461, _425456dbcc95):
            raise _cc1b37498779("Attribute name must be a string.")
        _bf6b32f0c87f(self, _28d08ce73461, _039ab2c71ea8)

    def _239ab2b4bc5c(self, _28d08ce73461: _425456dbcc95) -> _b0d7b6857496:
        """
        Retrieve the value of a given attribute from the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to retrieve.

        Returns
        -------
        Any
            The value of the specified attribute.

        Raises
        ------
        AttributeError
            If the specified attribute does not exist.
        TypeError
            If `attr_name` is not a string.
        """
        if not _2aa0ecbd5693(_28d08ce73461, _425456dbcc95):
            raise _cc1b37498779("Attribute name must be a string.")
        if not _c3bbd393d9bc(self, _28d08ce73461):
            raise _f4efea978a06(f"Property '{_28d08ce73461}' not found.")
        return _72cda33248d0(self, _28d08ce73461)


class _98b40c3ed01e:
    """
    Utility class for reading, parsing, and converting configuration properties
    between YAML files, dictionaries, and `Properties` objects.

    Example
    -------
    >>> putils = PropertyUtils()
    >>> props = putils.get_yaml_config_properties("config.yaml")
    >>> props.app.model_name
    'bert-base-tamil'
    """

    def _5af22fdd5c85(self, _d28b293ebbcf: _63045e7e2e82[_425456dbcc95, _b0d7b6857496]) -> _60bfbcccfc56:
        """
        Convert a dictionary of properties into a nested `Properties` object.

        Parameters
        ----------
        props_dict : dict
            A dictionary containing key-value pairs to convert into attributes.

        Returns
        -------
        Properties
            A `Properties` object mirroring the structure of `props_dict`.

        Raises
        ------
        ValueError
            If the input dictionary is empty.
        TypeError
            If `props_dict` is not a dictionary.
        """
        if not _2aa0ecbd5693(_d28b293ebbcf, _b5ad65f79d2c):
            raise _cc1b37498779("props_dict must be a dictionary.")
        if not _d28b293ebbcf:
            raise _ab365efb522d("Properties dictionary is empty.")

        _1f219bbc411c = _60bfbcccfc56()
        for _85a58060184a, _039ab2c71ea8 in _d28b293ebbcf._a2b29ccae977():
            if _2aa0ecbd5693(_039ab2c71ea8, _b5ad65f79d2c):
                _5b244f07ce9a = self._9667d589c29a(_039ab2c71ea8)
                _1f219bbc411c._e990f79e034a(_28d08ce73461=_85a58060184a, _039ab2c71ea8=_5b244f07ce9a)
            else:
                _1f219bbc411c._e990f79e034a(_28d08ce73461=_85a58060184a, _039ab2c71ea8=_039ab2c71ea8)
        return _1f219bbc411c

    def _0ecaa0460d5e(self, _1f219bbc411c: _60bfbcccfc56) -> _63045e7e2e82[_425456dbcc95, _b0d7b6857496]:
        """
        Convert a `Properties` object back into a dictionary recursively.

        Parameters
        ----------
        props : Properties
            The Properties object to convert.

        Returns
        -------
        dict
            A dictionary representation of the Properties object.

        Raises
        ------
        ValueError
            If the Properties object is None or empty.
        TypeError
            If the provided `props` is not an instance of Properties.
        """
        if not _2aa0ecbd5693(_1f219bbc411c, _60bfbcccfc56):
            raise _cc1b37498779("Expected a Properties object.")
        if not _1f219bbc411c._af119a1a6543:
            raise _ab365efb522d("Properties object is empty.")

        _d28b293ebbcf: _63045e7e2e82[_425456dbcc95, _b0d7b6857496] = {}
        for _85a58060184a, _039ab2c71ea8 in _1f219bbc411c._af119a1a6543._a2b29ccae977():
            if _2aa0ecbd5693(_039ab2c71ea8, _60bfbcccfc56):
                _d28b293ebbcf[_85a58060184a] = self._b2ffb86bc092(_039ab2c71ea8)
            else:
                _d28b293ebbcf[_85a58060184a] = _039ab2c71ea8
        return _d28b293ebbcf

    def _9847ba6d677d(self, _7eb029c18306: _425456dbcc95) -> _60bfbcccfc56:
        """
        Load a YAML configuration file and return it as a `Properties` object.

        Parameters
        ----------
        config_file : str
            Path to the YAML configuration file.

        Returns
        -------
        Properties
            A `Properties` object containing all fields from the YAML file.

        Raises
        ------
        FileNotFoundError
            If the specified YAML file does not exist.
        YAMLError
            If there is an error parsing the YAML file.
        ValueError
            If the loaded YAML file is empty or invalid.
        RuntimeError
            If an unexpected error occurs during property conversion.
        """
        _0c848fff532c = _2f5133f3c9f1()
        if not _0c848fff532c._642b4ca55914(_a26854317b1d=_7eb029c18306):
            raise _28ceaa605efb(f"YAML configuration file not found: '{_7eb029c18306}'")

        try:
            with _e065de2199a4(_7eb029c18306, "r", _139cb4493a48="utf-8") as _9ba8a501d3a8:
                _d28b293ebbcf = _e0f610f68f66._e842c0a36306(_9ba8a501d3a8)
                if not _d28b293ebbcf:
                    raise _ab365efb522d(f"Configuration file '{_7eb029c18306}' is empty or invalid.")
                _1f219bbc411c = self._9667d589c29a(_d28b293ebbcf)
                return _1f219bbc411c
        except _fc5a475b2aeb as _9462a36c7793:
            raise _fc5a475b2aeb(f"YAML parsing failed for '{_7eb029c18306}': {_9462a36c7793}") from _9462a36c7793
        except _914343e98435 as _588e9069465e:
            raise _a623fdbcf6b6(f"Failed to load configuration from '{_7eb029c18306}': {_588e9069465e}") from _588e9069465e
