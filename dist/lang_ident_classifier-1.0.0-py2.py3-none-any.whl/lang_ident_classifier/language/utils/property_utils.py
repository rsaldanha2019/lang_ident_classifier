# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : property_utils.py
# @Time             : 2025-10-23 13:56 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from typing import _7d88027887f5, _33b4350314c8
import _b89282ba4bfb
from _b89282ba4bfb import _0a71c4e5f826
from _a6286a656b4e._43f9b0ab3172._8eb28b3d3067._a1b99f0cf9eb import _fd3e41967432


class _54d9344618f6:
    """
    A lightweight container for hierarchical configuration attributes.

    This class allows dynamic assignment of attributes from dictionaries or YAML files,
    supporting nested structures by recursively setting sub-objects as `Properties`.

    Example
    -------
    >>> p = Properties()
    >>> p.set_attribute("model_name", "BERT")
    >>> p.model_name
    'BERT'
    """

    def _d83ddfde0182(self, _820785cd3908: _057fd04134b9, _2929e67cc845: _7d88027887f5) -> _1a81eb7094b3:
        """
        Dynamically set an attribute on the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to assign.
        value : Any
            The value to be stored in the attribute.

        Returns
        -------
        None

        Raises
        ------
        TypeError
            If `attr_name` is not a string.
        """
        if not _d039e53fcb3d(_820785cd3908, _057fd04134b9):
            raise _d16df7acb28b("Attribute name must be a string.")
        _94933dddff7f(self, _820785cd3908, _2929e67cc845)

    def _3e77c0322ecb(self, _820785cd3908: _057fd04134b9) -> _7d88027887f5:
        """
        Retrieve the value of a given attribute from the Properties object.

        Parameters
        ----------
        attr_name : str
            The name of the attribute to retrieve.

        Returns
        -------
        Any
            The value of the specified attribute.

        Raises
        ------
        AttributeError
            If the specified attribute does not exist.
        TypeError
            If `attr_name` is not a string.
        """
        if not _d039e53fcb3d(_820785cd3908, _057fd04134b9):
            raise _d16df7acb28b("Attribute name must be a string.")
        if not _7966c8d76435(self, _820785cd3908):
            raise _95c9d2793834(f"Property '{_820785cd3908}' not found.")
        return _0f2ac446a5ca(self, _820785cd3908)


class _a1ec11383d3e:
    """
    Utility class for reading, parsing, and converting configuration properties
    between YAML files, dictionaries, and `Properties` objects.

    Example
    -------
    >>> putils = PropertyUtils()
    >>> props = putils.get_yaml_config_properties("config.yaml")
    >>> props.app.model_name
    'bert-base-tamil'
    """

    def _a02974225bba(self, _72bdba02cd75: _33b4350314c8[_057fd04134b9, _7d88027887f5]) -> _a0e88f5b8ceb:
        """
        Convert a dictionary of properties into a nested `Properties` object.

        Parameters
        ----------
        props_dict : dict
            A dictionary containing key-value pairs to convert into attributes.

        Returns
        -------
        Properties
            A `Properties` object mirroring the structure of `props_dict`.

        Raises
        ------
        ValueError
            If the input dictionary is empty.
        TypeError
            If `props_dict` is not a dictionary.
        """
        if not _d039e53fcb3d(_72bdba02cd75, _dba633a399c3):
            raise _d16df7acb28b("props_dict must be a dictionary.")
        if not _72bdba02cd75:
            raise _9d02e7cbee5f("Properties dictionary is empty.")

        _eb114fbce6d4 = _a0e88f5b8ceb()
        for _43432b7f91b6, _2929e67cc845 in _72bdba02cd75._a71706d4c3c1():
            if _d039e53fcb3d(_2929e67cc845, _dba633a399c3):
                _45d84f598033 = self._f426ea329898(_2929e67cc845)
                _eb114fbce6d4._37bf70a6983d(_820785cd3908=_43432b7f91b6, _2929e67cc845=_45d84f598033)
            else:
                _eb114fbce6d4._37bf70a6983d(_820785cd3908=_43432b7f91b6, _2929e67cc845=_2929e67cc845)
        return _eb114fbce6d4

    def _c5fcf1a73d09(self, _eb114fbce6d4: _a0e88f5b8ceb) -> _33b4350314c8[_057fd04134b9, _7d88027887f5]:
        """
        Convert a `Properties` object back into a dictionary recursively.

        Parameters
        ----------
        props : Properties
            The Properties object to convert.

        Returns
        -------
        dict
            A dictionary representation of the Properties object.

        Raises
        ------
        ValueError
            If the Properties object is None or empty.
        TypeError
            If the provided `props` is not an instance of Properties.
        """
        if not _d039e53fcb3d(_eb114fbce6d4, _a0e88f5b8ceb):
            raise _d16df7acb28b("Expected a Properties object.")
        if not _eb114fbce6d4._3a0ffdda86dd:
            raise _9d02e7cbee5f("Properties object is empty.")

        _72bdba02cd75: _33b4350314c8[_057fd04134b9, _7d88027887f5] = {}
        for _43432b7f91b6, _2929e67cc845 in _eb114fbce6d4._3a0ffdda86dd._a71706d4c3c1():
            if _d039e53fcb3d(_2929e67cc845, _a0e88f5b8ceb):
                _72bdba02cd75[_43432b7f91b6] = self._626b09677676(_2929e67cc845)
            else:
                _72bdba02cd75[_43432b7f91b6] = _2929e67cc845
        return _72bdba02cd75

    def _0b91a67a0c91(self, _385830b5b1c2: _057fd04134b9) -> _a0e88f5b8ceb:
        """
        Load a YAML configuration file and return it as a `Properties` object.

        Parameters
        ----------
        config_file : str
            Path to the YAML configuration file.

        Returns
        -------
        Properties
            A `Properties` object containing all fields from the YAML file.

        Raises
        ------
        FileNotFoundError
            If the specified YAML file does not exist.
        YAMLError
            If there is an error parsing the YAML file.
        ValueError
            If the loaded YAML file is empty or invalid.
        RuntimeError
            If an unexpected error occurs during property conversion.
        """
        _5a6a88e88bf2 = _fd3e41967432()
        if not _5a6a88e88bf2._9d34713dd511(_4659f33fcb84=_385830b5b1c2):
            raise _348b470d08b1(f"YAML configuration file not found: '{_385830b5b1c2}'")

        try:
            with _80a6b839182a(_385830b5b1c2, "r", _e254ae987780="utf-8") as _5663d40e6f35:
                _72bdba02cd75 = _b89282ba4bfb._3fca8001a5e1(_5663d40e6f35)
                if not _72bdba02cd75:
                    raise _9d02e7cbee5f(f"Configuration file '{_385830b5b1c2}' is empty or invalid.")
                _eb114fbce6d4 = self._f426ea329898(_72bdba02cd75)
                return _eb114fbce6d4
        except _0a71c4e5f826 as _fdad8997856c:
            raise _0a71c4e5f826(f"YAML parsing failed for '{_385830b5b1c2}': {_fdad8997856c}") from _fdad8997856c
        except _b664d949de26 as _75d1e8106a6f:
            raise _da29f505981e(f"Failed to load configuration from '{_385830b5b1c2}': {_75d1e8106a6f}") from _75d1e8106a6f
