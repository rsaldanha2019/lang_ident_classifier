# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : property_utils
# @Time             : 18/12/23 9:07 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from typing import Any

import yaml
from yaml import YAMLError
from lang_ident_classifier.language.utils.file_dir_utils import FileDirUtils


class Properties:
    """
    Class for storing properties from yaml file as attributes
    """

    def set_attribute(self, attr_name, value)->None:
        """
        Takes the attribute name and value,
        sets these as attribute in properties object
        :param attr_name: name of the property
        :param value: value associated with property
        :return: None
        """
        setattr(self, attr_name, value)

    def get_attribute(self, attr_name)->Any:
        """
        Takes an attribute name and returns
        the value stored in properties
        :param attr_name: name of the attribute
        :return:  value stored in properties
        """
        return self.get_attribute(attr_name)


class PropertyUtils:
    """
    Class for loading properties from config files
    """

    def get_props_from_dict(self, props_dict: dict)-> Properties:
        """
        Takes a dictionary of properties and returns Python object properties
        :param props_dict: properties dictionary
        :return: properties object
        """
        if not props_dict:
            raise ValueError("Properties dictionary is empty")
        props = Properties()
        for key, value in props_dict.items():
            if isinstance(value, dict):
                props.set_attribute(attr_name=key, value=self.get_props_from_dict(value))
                # props.__setattr__(key, self.get_props_from_dict(value))
            else:
                props.set_attribute(attr_name=key, value=value)
        return props

    def get_dict_from_props(self, props: Properties) -> dict:
        """

        :param props:
        :return:
        """
        if not props:
            raise ValueError("Properties object is empty")
        props_dict = {}
        for key, value in props.__dict__.items():
            if isinstance(value, Properties):
                props_dict[key] = self.get_dict_from_props(value)
            else:
                props_dict[key] = value
        return props_dict

    def get_yaml_config_properties(self, config_file: str) -> Properties:
        """
        Takes path of a yaml config file and returns a corresponding python object
        :param config_file: a yaml config files
        :return: a python object with properties from yaml as the attributes
        """
        try:
            fdu = FileDirUtils()
            if fdu.check_file_or_dir_exists(file_dir_path=config_file):
                with open(config_file, "r", encoding='utf-8') as cfile:
                    props_dict = yaml.safe_load(cfile)
                    props = self.get_props_from_dict(props_dict)
                    return props
            else:
                raise FileNotFoundError(f"File {config_file} not found.")
        except YAMLError as ye:
            raise ye
