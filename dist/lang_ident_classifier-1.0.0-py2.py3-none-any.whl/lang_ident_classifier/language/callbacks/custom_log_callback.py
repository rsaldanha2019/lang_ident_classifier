import csv
from decimal import ROUND_HALF_UP, Decimal
import os.path
import re
import subprocess
import socket
import numpy as np
from prettytable import PrettyTable
import torch
import torch.distributed
from torch.distributed.fsdp import FullyShardedDataParallel as FSDP
from torch.distributed.fsdp.fully_sharded_data_parallel import TrainingState
from lang_ident_classifier.language.utils import date_time_utils as dtu
# import pytorch_lightning as pl
# from pytorch_lightning.utilities.rank_zero import rank_zero_only
# from pytorch_lightning.strategies import SingleDeviceStrategy
import lightning as pl
from lightning.pytorch.utilities.rank_zero import rank_zero_only
from lightning.pytorch.strategies import SingleDeviceStrategy
import optuna

class LoggingCallback(pl.Callback):
    def __init__(self, log, model_summary_callback, metrics_summary_dict, metrics_dir, model_epoch_metrics_file,
                 model_metrics_summary_file, random_seed: int = 20, trial: optuna.trial.Trial = None):
        self.metrics_dict = None
        self.logger = log
        self.trial = trial
        self.model_summary_callback = model_summary_callback
        self.model_epoch_metrics_file = model_epoch_metrics_file
        self.metrics_dir = metrics_dir
        self.model_metrics_summary_file = model_metrics_summary_file
        self.metrics_summary_dict = metrics_summary_dict
        self.start_epoch = None
        self.dtu = dtu.DateTimeUtils()
        self.collection = []
        self.interrupt_flag = False
        self.random_seed = random_seed
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 

    def on_train_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        msg = ""
        if torch.cuda.is_available():
            from pynvml import nvmlInit, nvmlDeviceGetHandleByIndex, nvmlDeviceGetName
            nvmlInit()
            gpu_name = nvmlDeviceGetName(nvmlDeviceGetHandleByIndex(trainer.local_rank)).decode('utf-8')
            msg += "World Size {} Global Rank {} Local Rank {}\n".format(trainer.world_size, trainer.global_rank,
                                                                         trainer.local_rank)
            # msg += "Running on {} with {}\n".format(socket.gethostname(),
            #                                         subprocess.check_output(["nvidia-smi", "-L"]).decode("utf8").split(
            #                                             "\n")[trainer.local_rank])
            msg += "Running on {} with {}\n".format(socket.gethostname(), gpu_name)
            if not isinstance(trainer.strategy, SingleDeviceStrategy):
                train_dataset = getattr(trainer.datamodule, "train_dataset", None) or getattr(trainer.datamodule.train_dataloader(), "dataset", None)
                if isinstance(train_dataset, torch.utils.data.IterableDataset):
                    msg += "Sampler :: {} created {} number of training samples on node out of {} total samples \n".format(
                        type(trainer.train_dataloader.sampler), train_dataset.num_samples,
                        train_dataset.total_size)
                elif isinstance(train_dataset, torch.utils.data.Dataset):
                    msg += "Sampler :: {} created {} number of training samples on node out of {} total samples \n".format(
                        type(trainer.train_dataloader.sampler), trainer.train_dataloader.sampler.num_samples,
                        trainer.train_dataloader.sampler.total_size)
        else:
            msg += "No GPU available using cpu as accelerator\n"

        self.logger.info(msg)

    def _fixed_float(self, val, precision=3):
        """Round float using Decimal to avoid precision issues."""
        return float(Decimal(str(val)).quantize(Decimal(f'1.{"0"*precision}'), rounding=ROUND_HALF_UP))

    @rank_zero_only
    def on_train_epoch_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        self.metrics_dict = trainer.callback_metrics
        if self.start_epoch is None:
            start_epoch = self.metrics_dict['epoch'].item()
            self.metrics_summary_dict['start_epoch'] = start_epoch
            self.start_epoch = start_epoch

        metrics_info = ""
        sorted_metrics_dict = dict()
        for key in sorted(self.metrics_dict):
            raw_val = self.metrics_dict[key].item()

            # Only apply precise rounding to keys with the λ symbol
            if "λ" in key:
                val = self._fixed_float(val=raw_val, precision=3)
            else:
                val = raw_val

            metrics_info += " {}:{},".format(key, val)
            sorted_metrics_dict[key] = val

        self.logger.info(metrics_info)
        if not os.path.exists(self.metrics_dir):
            os.makedirs(self.metrics_dir, exist_ok=True)  # exists_ok used for distributed scenario
        metrics_file_path = os.path.join(self.metrics_dir, self.model_epoch_metrics_file)
        # with open(metrics_file_path, 'a+', encoding="utf8") as mdl_metrics_file:
        #     writer = csv.DictWriter(mdl_metrics_file, fieldnames=sorted_metrics_dict.keys())
        #     if os.path.getsize(metrics_file_path) == 0:  # File is empty
        #         writer.writeheader()
        #     writer.writerows([sorted_metrics_dict])
        def as_float(x):
            if isinstance(x, torch.Tensor):
                return float(x.detach().cpu().item())
            if isinstance(x, (np.generic,)):
                return float(np.asarray(x))
            return float(x)

        # sanitize sorted_metrics_dict in-place for lambda values display
        for k in list(sorted_metrics_dict.keys()):
            if "lambda" in k.lower():
                v = sorted_metrics_dict[k]
                try:
                    v_f = as_float(v)
                except Exception:
                    # fallback: leave unchanged if it cannot be coerced
                    continue
                # store as fixed two-decimal string so CSV shows exactly "0.45"
                sorted_metrics_dict[k] = f"{v_f:.2f}"

        # then write as you already do
        with open(metrics_file_path, "a+", encoding="utf8", newline="") as mdl_metrics_file:
            writer = csv.DictWriter(mdl_metrics_file, fieldnames=sorted_metrics_dict.keys())
            if os.path.getsize(metrics_file_path) == 0:
                writer.writeheader()
            writer.writerows([sorted_metrics_dict])
        
        # Example: Early stopping message
        if trainer.should_stop:
            self.logger.info("Early stopping activated.")

        # Example: Learning rate change message
        for optimizer in trainer.optimizers:
            for param_group in optimizer.param_groups:
                lr = param_group['lr']
                self.logger.info(f"Current learning rate: {lr}")

    # def _filter_summary(self, model_summary):
    #     model_summary = str(model_summary)
    #     # List of attributes to exclude from the summary
    #     exclude = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

    #     # Split into lines for better processing
    #     lines = model_summary.splitlines()
    #     filtered_lines = []
        
    #     for line in lines:
    #         # Check if any of the excluded names are in the current line
    #         if any(name in line for name in exclude):
    #             continue  # Skip this line entirely

    #         filtered_lines.append(line)

    #     # Reconstruct the summary after removing excluded lines
    #     return "\n".join(filtered_lines)

    # def _filter_summary(self, trainer, model_summary):
    #     model_summary = str(model_summary)
    #     return model_summary

    # def _filter_summary(self, trainer, model_summary):
    #     model_summary = str(model_summary)
    #     exclude = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

    #     # Split summary into lines
    #     lines = model_summary.splitlines()
    #     filtered_lines = []
        
    #     trainable_params = None
    #     non_trainable_params = None

    #     def parse_param_count(param_str):
    #         """ Convert human-readable params (e.g., '414 K', '1.2 B') into integers """
    #         param_str = param_str.replace(",", "").strip()
    #         match = re.search(r"([\d\.]+)\s*([KMGTB]?)", param_str)
    #         if match:
    #             num, suffix = match.groups()
    #             num = float(num)
    #             multiplier = {"K": 1e3, "M": 1e6, "B": 1e9, "T": 1e12}.get(suffix, 1)
    #             return int(num * multiplier)
    #         return None  # Ensure None is returned for missing values

    #     for line in lines:
    #         if any(name in line for name in exclude):
    #             continue  # Remove metric and criterion lines
            
    #         if "Trainable params" in line:
    #             trainable_params = parse_param_count(line)
    #         elif "Non-trainable params" in line:
    #             non_trainable_params = parse_param_count(line)

    #         filtered_lines.append(line)

    #     # Compute corrected total params only if both values exist
    #     if trainable_params is not None and non_trainable_params is not None:
    #         total_params = trainable_params + non_trainable_params
    #         total_params_str = f"{total_params:,} Total params"  # Format with commas

    #         # Update total params line
    #         for i, line in enumerate(filtered_lines):
    #             if "Total params" in line:
    #                 filtered_lines[i] = total_params_str
    #                 break  

    #     return "\n".join(filtered_lines)

    def calculate_model_size_in_gb(self, model):
        """
        Calculate model size in GB by including all unique parameters.
        Skips calculation if FSDP is not in IDLE state to avoid runtime errors.
        """
        # Check if model is using FSDP and is not in IDLE state
        if isinstance(model, FSDP) and model.training_state != TrainingState.IDLE:
            print("Skipping model size calculation: FSDP model is not in IDLE state.")
            return 0

        total_size = 0  # in bytes
        counted_params = set()

        def get_parameters_size(module):
            nonlocal total_size
            for param in module.parameters(recurse=False):  # prevent double counting
                param_id = id(param)
                if param_id not in counted_params:
                    dtype_size = param.element_size()
                    total_size += param.numel() * dtype_size
                    counted_params.add(param_id)

        model.apply(lambda m: get_parameters_size(m))
        size_in_gb = total_size / (1024 ** 3)
        return size_in_gb


    def _filter_summary(self, trainer, depth: int = 1, exclude=None):
        """
        Generate a clean model summary table using PrettyTable.
        Dynamically reports total and estimated per-device shard size.
        Shows total params and actual FSDP shard param count if available.
        """
        import torch
        from prettytable import PrettyTable

        if exclude is None:
            exclude = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

        model = trainer.model

        # === Unwrap FSDP core model for param inspection ===
        if hasattr(model, "_fsdp_wrapped_module") and hasattr(model._fsdp_wrapped_module, "module"):
            core_model = model._fsdp_wrapped_module.module
            fsdp_module = model._fsdp_wrapped_module
        else:
            core_model = model
            fsdp_module = None

        table = PrettyTable()
        table.field_names = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

        total_params = 0
        trainable_params = 0
        non_trainable_params = 0

        visited_params = set()

        def count_unique_params(module):
            params = list(module.parameters())
            unique_params = [p for p in params if id(p) not in visited_params]
            visited_params.update(id(p) for p in unique_params)

            total = sum(p.numel() for p in unique_params)
            trainable = sum(p.numel() for p in unique_params if p.requires_grad)
            non_trainable = total - trainable

            return total, trainable, non_trainable

        for name, module in core_model.named_modules():
            if name == "" or name.count(".") >= depth:
                continue
            if any(skip in name for skip in exclude):
                continue

            layer_total, layer_trainable, layer_non_trainable = count_unique_params(module)

            if layer_total > 0:
                table.add_row([
                    name,
                    module.__class__.__name__,
                    f"{layer_total:,}",
                    f"{layer_trainable:,}",
                    f"{layer_non_trainable:,}"
                ])

                total_params += layer_total
                trainable_params += layer_trainable
                non_trainable_params += layer_non_trainable

        # Calculate full model size from core model
        full_model_size_gb = self.calculate_model_size_in_gb(core_model)

        # Get shard parameter count from FSDP internals if available
        shard_param_count = None
        if fsdp_module is not None:
            if hasattr(fsdp_module, "_fsdp_flat_param") and fsdp_module._fsdp_flat_param is not None:
                shard_param_count = fsdp_module._fsdp_flat_param.numel()
            elif hasattr(fsdp_module, "_flat_param") and fsdp_module._flat_param is not None:
                # Fallback for older FSDP versions
                shard_param_count = fsdp_module._flat_param.numel()

        # Determine parallel strategy and device count
        strategy = getattr(trainer, "strategy", None)
        num_devices = getattr(trainer, "num_devices", torch.cuda.device_count())

        strategy_str = str(strategy).lower() if strategy else ""
        is_fsdp = "fsdp" in strategy_str
        is_ddp = "ddp" in strategy_str

        if is_fsdp and num_devices > 0:
            estimated_shard_size_gb = full_model_size_gb / num_devices
        else:
            estimated_shard_size_gb = full_model_size_gb  # no sharding

        # Format sizes for display
        model_size_mb = full_model_size_gb * 1024
        size_str = f"{full_model_size_gb:.2f} GB" if full_model_size_gb >= 1 else f"{model_size_mb:.2f} MB"
        shard_size_str = f"{estimated_shard_size_gb:.2f} GB" if estimated_shard_size_gb >= 1 else f"{estimated_shard_size_gb * 1024:.2f} MB"

        summary_table = PrettyTable()
        summary_table.field_names = ["Metric", "Value"]
        summary_table.add_row(["Total params (full model)", f"{total_params:,}"])
        summary_table.add_row(["Trainable params", f"{trainable_params:,}"])
        summary_table.add_row(["Non-trainable params", f"{non_trainable_params:,}"])
        summary_table.add_row(["Full model size (unsharded)", size_str])

        if shard_param_count is not None:
            summary_table.add_row(["Actual per-device shard params (FSDP)", f"{shard_param_count:,}"])

        if is_fsdp:
            summary_table.add_row([f"Estimated per-device shard size (FSDP x{num_devices})", shard_size_str])
        elif is_ddp:
            summary_table.add_row([f"Per-device copy size (DDP x{num_devices})", size_str])
        else:
            summary_table.add_row(["Parallel strategy", "Single-device or unknown"])

        summary = f"\n{table}\n\n{summary_table}\n"
        return summary

    # @rank_zero_only
    def on_fit_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        # self.metrics_dict = trainer.callback_metrics
        training_start_time = self.dtu.get_current_time_in_milliseconds()
        training_start_date_time = self.dtu.get_utc_date_time()
        self.logger.info("Model Training started at {}".format(training_start_date_time))
        if trainer.global_rank == 0:
            self.metrics_dict = trainer.callback_metrics
            self.metrics_summary_dict['training_start_time'] = training_start_time
            self.metrics_summary_dict['training_start_date_time'] = training_start_date_time
        # print model summary trainable params
        model_summary = self.model_summary_callback._summary(trainer, pl_module)
        # Exclude unnecessary attributes like metrics and criterion
        model_summary = self._filter_summary(trainer)
        self.logger.info(f"Model Training Parameters Summary on Rank {trainer.global_rank} \n{model_summary}")

        # === Condition: Exit if model has no trainable parameters ===
        has_trainable_params = any(p.requires_grad for p in trainer.model.parameters())
        if not has_trainable_params:
            self.logger.info("No trainable parameters found. Skipping training...")
            trainer.should_stop = True
    
    @rank_zero_only
    def on_test_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        # print model summary trainable params
        model_summary = self.model_summary_callback._summary(trainer, pl_module)
        # Exclude unnecessary attributes like metrics and criterion
        model_summary = self._filter_summary(trainer)
        self.logger.info("Model Training Parameters Summary \n{}".format(
            # self.model_summary_callback._summary(trainer=trainer, pl_module=pl_module)))
            model_summary))
    
    @rank_zero_only
    def on_exception(self, trainer: pl.Trainer, pl_module: pl.LightningModule, exception: BaseException) -> None:
        self._log_model_training_info(trainer=trainer, pl_module=pl_module, 
                                      message="Abnormal Termination due to Exception or an explicit interruption in program")
    
    @rank_zero_only
    def on_fit_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        self.logger.info(f"After Fit Model Summary")
        self._log_model_training_info(trainer, pl_module, message="Training Completed Normally ")

    def _log_model_training_info(self, trainer: pl.Trainer, pl_module: pl.LightningModule, message: str):
        if self.trial:
            self.metrics_summary_dict['trial_number'] = self.trial.number
        if self.start_epoch is None:
            self.metrics_summary_dict['start_epoch'] = float(trainer.current_epoch)
        end_epoch = trainer.callback_metrics['epoch'] if 'epoch' in trainer.callback_metrics else trainer.current_epoch
        self.metrics_summary_dict["end_epoch"] = float(end_epoch) if isinstance(end_epoch, int) else end_epoch.item()
        training_end_time = self.dtu.get_current_time_in_milliseconds()
        self.metrics_summary_dict["training_end_time"] = training_end_time
        training_end_date_time = self.dtu.get_utc_date_time()
        self.logger.info("Training completed at {}".format(training_end_date_time))
        self.metrics_summary_dict["training_end_date_time"] = training_end_date_time
        model_training_time = training_end_time - self.metrics_summary_dict.get("training_start_time", training_end_time)
        self.metrics_summary_dict["model_training_time"] = model_training_time
        # Example: Early stopping message
        if trainer.should_stop:
            # self.logger.info(f"Early stopping activated. {trainer.callback_metrics['epoch']+1} epochs have been completed.")
            self.logger.info(f"Early stopping activated. {(trainer.callback_metrics.get('epoch') or trainer.current_epoch) + 1} epochs have been completed.")
            message += " Early Stopping Implemented."
        self.logger.info(
            "Total Training Time {} hours {} minutes {} seconds".format(
                *self.dtu.get_hms_from_milliseconds(model_training_time)))
        self.metrics_summary_dict["model_training_time_details"] = "{} hours {} minutes {} seconds".format(
            *self.dtu.get_hms_from_milliseconds(model_training_time))
        self.metrics_summary_dict["model_training_status"] = message
        if not os.path.exists(self.metrics_dir):
            os.makedirs(self.metrics_dir, exist_ok=True)
            
        metrics_file_path = os.path.join(self.metrics_dir, self.model_metrics_summary_file)
        with open(metrics_file_path, 'a+', encoding="utf8") as mdl_metrics_file:
            writer = csv.DictWriter(mdl_metrics_file, fieldnames=self.metrics_summary_dict.keys())
            if os.path.getsize(metrics_file_path) == 0:  # File is empty
                writer.writeheader()
            writer.writerows([self.metrics_summary_dict])

        # print model summary trainable params
        model_summary = self.model_summary_callback._summary(trainer, pl_module)
        # Exclude unnecessary attributes like metrics and criterion
        model_summary = self._filter_summary(trainer)
        self.logger.info(f"Model Training Parameters Summary on Rank {trainer.global_rank} \n{model_summary}")
