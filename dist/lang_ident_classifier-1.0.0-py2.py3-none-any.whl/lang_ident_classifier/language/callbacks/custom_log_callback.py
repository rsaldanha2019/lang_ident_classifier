# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : custom_log_callback.py
# @Time             : 2025-10-23 13:45 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _1f324180cf01
from _72b079e18f00 import _963e8d561ac3, _7dbef5e05acb
import _53b11b229fcd._dfc0664b7b4e
import _c9ddf234beb7
import _5a338c1b77c4 as _0dd0c2f84530
from _eeefcd2c32c6 import _72a06f5c0e3b
import _bf9b268f95ff
from _bf9b268f95ff._ff66e97aaca7._aa97576ec2d9 import _dadcfdded484 as _b30daccae431
from _bf9b268f95ff._ff66e97aaca7._aa97576ec2d9._3ce263814760 import _abd6bc249886
from _6ea0dfeccc7e._9abdd3ac9b14._b778318783a8 import _198cf7bb9974 as _3cf2c0a30e7c
import _eac94757fd7b as _2de80215e250
from _eac94757fd7b._216e86553b9a._ca161ff6bc38._3448feb446b5 import _c9ad4f590adb
from _eac94757fd7b._216e86553b9a._6badac0b48c4 import _94b34546cb56
import _86a911461f7e
from _b99941705178 import _19b84baa138c, _e7ffe95553b2, _9ca1387a100f


class _b7a29168fa93(_2de80215e250._15f04f825a0a):
    """
    Callback that centralizes logging and metrics summary creation for training runs.

    Purpose
    -------
    - Log environment and trainer startup information.
    - Persist per-epoch metric rows to CSV (human-readable, deterministic formatting).
    - Produce a concise model summary table with parameter counts and estimated shard sizes
      for FSDP/DDP scenarios.
    - Emit informational messages on fit/test lifecycle events and on exceptions.

    Design goals
    ------------
    - Fail early for clearly invalid initialization inputs.
    - Keep all runtime behaviors unchanged from original implementation (no algorithmic changes).
    - Use `rank_zero_only` for actions that should only run on the primary process.
    - Provide clear docstrings and explicit `RuntimeError` on invalid usage.

    Parameters
    ----------
    log : logging.Logger
        Logger instance used for writing human-readable logs.
    model_summary_callback : object
        Object providing `_summary(trainer, pl_module)` (used to obtain model summary text).
    metrics_summary_dict : dict
        Mutable dictionary which will be updated with run-level summary metrics (start/end times, trial).
    metrics_dir : str
        Directory where per-epoch metrics CSV and summary file will be written.
    model_epoch_metrics_file : str
        Filename for per-epoch metrics CSV (written inside metrics_dir).
    model_metrics_summary_file : str
        Filename for aggregated model metrics summary CSV (written inside metrics_dir).
    random_seed : int, optional
        RNG seed used to produce reproducible logging and rounding behavior (default: 20).
    trial : optuna.trial.Trial, optional
        Optional Optuna trial object; if given, `trial.number` will be recorded in summary.

    Raises
    ------
    RuntimeError
        If required arguments are missing or invalid (e.g., `log` is None or metrics paths are invalid).
    """

    def _3f0016dcf6c5(
        self,
        _d8953dbf6cbe,
        _f8d0e2e363d5,
        _3ad86877e3a3: _e7ffe95553b2[_b75b42c141c4, _9ca1387a100f],
        _1ad1ea3fd645: _b75b42c141c4,
        _31b83bee95d1: _b75b42c141c4,
        _d2475d54a972: _b75b42c141c4,
        _ccd450ea5019: _71872b268596 = 20,
        _55290618d792: _19b84baa138c[_86a911461f7e._55290618d792._396d99a1420e] = _148c55bce7f0,
    ):
        # Validate required constructor arguments to fail fast and loudly
        if _d8953dbf6cbe is _148c55bce7f0:
            raise _af3b842c5f0b("LoggingCallback requires a logger instance (log).")
        if _f8d0e2e363d5 is _148c55bce7f0:
            raise _af3b842c5f0b("LoggingCallback requires a model_summary_callback object providing _summary().")
        if _3ad86877e3a3 is _148c55bce7f0 or not _68338c6cff74(_3ad86877e3a3, _78482eb28f23):
            raise _af3b842c5f0b("metrics_summary_dict must be a dict to collect run-level metrics.")
        if not _68338c6cff74(_31b83bee95d1, _b75b42c141c4) or not _31b83bee95d1:
            raise _af3b842c5f0b("model_epoch_metrics_file must be a non-empty filename string.")
        if not _68338c6cff74(_d2475d54a972, _b75b42c141c4) or not _d2475d54a972:
            raise _af3b842c5f0b("model_metrics_summary_file must be a non-empty filename string.")
        if not _68338c6cff74(_1ad1ea3fd645, _b75b42c141c4) or not _1ad1ea3fd645:
            raise _af3b842c5f0b("metrics_dir must be a non-empty directory path string.")

        # Store validated inputs
        self._b61b5ea040ac: _19b84baa138c[_e7ffe95553b2[_b75b42c141c4, _9ca1387a100f]] = _148c55bce7f0
        self._a5071afa39fe = _d8953dbf6cbe
        self._55290618d792 = _55290618d792
        self._f8d0e2e363d5 = _f8d0e2e363d5
        self._31b83bee95d1 = _31b83bee95d1
        self._1ad1ea3fd645 = _1ad1ea3fd645
        self._d2475d54a972 = _d2475d54a972
        self._3ad86877e3a3 = _3ad86877e3a3
        self._f735f73bbfbf: _19b84baa138c[_00b9102f8a03] = _148c55bce7f0
        self._3cf2c0a30e7c = _3cf2c0a30e7c._9a5ba2664b7a()
        self._849fcd6080ca = []
        self._f58d917480b4 = _75e8310cb6ee
        self._ccd450ea5019 = _71872b268596(_ccd450ea5019)

        # Seed deterministically for reproducible logging behavior where relevant.
        _2de80215e250._45094f5a62c3(self._ccd450ea5019, _f17941fa5391=_690296bd47e7)
        _bf9b268f95ff._229f3acedeb7(self._ccd450ea5019)
        if _bf9b268f95ff._933e52cdaf69._d843de3d0f54():
            _bf9b268f95ff._933e52cdaf69._25167ce5feb7(self._ccd450ea5019)

    def _782e16184537(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _c6af895ef27d: _2de80215e250._98844be2f3bb) -> _148c55bce7f0:
        """
        Called once at the beginning of training. Logs environment information such as GPU model,
        world size and rank, and dataset sampling summary for distributed runs.
        """
        _94e8a517b4a9 = ""
        if _bf9b268f95ff._933e52cdaf69._d843de3d0f54():
            try:
                # Lazy import for NVML to avoid failing when not available
                from _ebbd5b706b4b import _94e3de8cc9a0, _305be67af1d3, _534181da131f

                _94e3de8cc9a0()
                _c2055339bcc4 = _534181da131f(_305be67af1d3(_57a1f9815a4b._c994f5c1cc87))._ea2029494a9c("utf-8")
            except _0e6846a67c55:
                # fallback to a hostname-only message if NVML is not available
                _c2055339bcc4 = "unknown-gpu"

            _94e8a517b4a9 += "World Size {} Global Rank {} Local Rank {}\n"._cb741c9ea541(
                _57a1f9815a4b._47ef6516c98e, _57a1f9815a4b._76721d126338, _57a1f9815a4b._c994f5c1cc87
            )
            _94e8a517b4a9 += "Running on {} with {}\n"._cb741c9ea541(_c9ddf234beb7._0bef0a7ff8db(), _c2055339bcc4)

            # If not single-device strategy, attempt to report sampler info
            if not _68338c6cff74(_57a1f9815a4b._e31c54f9360c, _94b34546cb56):
                # Obtain train_dataset in a manner that works whether dataloader or datamodule is used
                _b634ef992a6e = _9a7127658aec(_57a1f9815a4b._6ab5fdf23892, "train_dataset", _148c55bce7f0) or _9a7127658aec(
                    _57a1f9815a4b._6ab5fdf23892._b0f5cdce0531(), "dataset", _148c55bce7f0
                )
                if _68338c6cff74(_b634ef992a6e, _bf9b268f95ff._b778318783a8._1adeb57e691d._24931ff94ac3):
                    _94e8a517b4a9 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._cb741c9ea541(
                        _287aa709c341(_57a1f9815a4b._b0f5cdce0531._32f28177eed2),
                        _9a7127658aec(_b634ef992a6e, "num_samples", "unknown"),
                        _9a7127658aec(_b634ef992a6e, "total_size", "unknown"),
                    )
                elif _68338c6cff74(_b634ef992a6e, _bf9b268f95ff._b778318783a8._1adeb57e691d._1870c0e1354b):
                    # sampler attributes expected by CustomGroupBySampleDistributedSampler
                    _32f28177eed2 = _9a7127658aec(_57a1f9815a4b._b0f5cdce0531, "sampler", _148c55bce7f0)
                    _24418fe24a90 = _9a7127658aec(_32f28177eed2, "num_samples", "unknown")
                    _9059111ffd90 = _9a7127658aec(_32f28177eed2, "total_size", "unknown")
                    _94e8a517b4a9 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._cb741c9ea541(
                        _287aa709c341(_32f28177eed2), _24418fe24a90, _9059111ffd90
                    )
        else:
            _94e8a517b4a9 += "No GPU available using cpu as accelerator\n"

        self._a5071afa39fe._48baf7878bf0(_94e8a517b4a9)

    def _3afe500b9d7e(self, _14dfc8014995: _00b9102f8a03, _70f810d9fc65: _71872b268596 = 3) -> _00b9102f8a03:
        """
        Deterministically round a float using Decimal with ROUND_HALF_UP semantics.

        Parameters
        ----------
        val : float
            Value to round.
        precision : int
            Number of decimal places.

        Returns
        -------
        float
            Rounded float.
        """
        return _00b9102f8a03(_7dbef5e05acb(_b75b42c141c4(_14dfc8014995))._dc77d83aae92(_7dbef5e05acb(f'1.{"0"*_70f810d9fc65}'), _91f78664efc6=_963e8d561ac3))

    @_c9ad4f590adb
    def _1a556bf17136(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _c6af895ef27d: _2de80215e250._98844be2f3bb) -> _148c55bce7f0:
        """
        At the end of each training epoch, capture metrics from the trainer, sanitize them,
        and append a row to the epoch metrics CSV. Also logs summary messages and LR info.

        Behavior
        --------
        - Writes a CSV line to `metrics_dir/model_epoch_metrics_file`.
        - Updates `metrics_summary_dict` start_epoch if not previously set.
        - Formats lambda values to two decimal string for consistent CSV representation.

        Exceptions
        ----------
        Raises RuntimeError if writing to the metrics CSV fails due to I/O errors.
        """
        self._b61b5ea040ac = _57a1f9815a4b._be047f178a82

        # Establish start epoch once
        if self._f735f73bbfbf is _148c55bce7f0:
            try:
                _f735f73bbfbf = _00b9102f8a03(self._b61b5ea040ac['epoch']._28a1050293b8())
            except _0e6846a67c55:
                _f735f73bbfbf = _00b9102f8a03(_57a1f9815a4b._4b2131685def)
            self._3ad86877e3a3['start_epoch'] = _f735f73bbfbf
            self._f735f73bbfbf = _f735f73bbfbf

        # Build a sanitized metrics dict for CSV writing and logging
        _4b64c2a70090 = ""
        _5f91b21d95df: _e7ffe95553b2[_b75b42c141c4, _9ca1387a100f] = {}
        for _933da11d1d34 in _af117f4cd4af(self._b61b5ea040ac):
            _c355806f96e3 = self._b61b5ea040ac[_933da11d1d34]._28a1050293b8() if _240ac39e62c9(self._b61b5ea040ac[_933da11d1d34], "item") else self._b61b5ea040ac[_933da11d1d34]

            # If the metric key contains greek letter lambda 'λ' prefer fixed rounding for readability
            if "λ" in _933da11d1d34:
                try:
                    _14dfc8014995 = self._378aaa002746(_14dfc8014995=_00b9102f8a03(_c355806f96e3), _70f810d9fc65=3)
                except _0e6846a67c55:
                    _14dfc8014995 = _c355806f96e3
            else:
                _14dfc8014995 = _c355806f96e3

            _4b64c2a70090 += f" {_933da11d1d34}:{_14dfc8014995},"
            _5f91b21d95df[_933da11d1d34] = _14dfc8014995

        self._a5071afa39fe._48baf7878bf0(_4b64c2a70090)

        # Ensure metrics directory exists (distributed-safe exists_ok)
        if not _53b11b229fcd._dfc0664b7b4e._bebfa042ff6d(self._1ad1ea3fd645):
            _53b11b229fcd._bc21efb56b80(self._1ad1ea3fd645, _a2d4aa92a010=_690296bd47e7)

        _c5a06e542f2a = _53b11b229fcd._dfc0664b7b4e._562be81ab493(self._1ad1ea3fd645, self._31b83bee95d1)

        # Helper: coerce torch/np scalars to python floats
        def _1fedce5148ce(_41fd75e115b7):
            if _68338c6cff74(_41fd75e115b7, _bf9b268f95ff._41e870ca6fc6):
                return _00b9102f8a03(_41fd75e115b7._0098c13a17cf()._885d382d88e5()._28a1050293b8())
            if _68338c6cff74(_41fd75e115b7, (_0dd0c2f84530._d9c2a23e796c,)):
                return _00b9102f8a03(_0dd0c2f84530._ca1f1574477f(_41fd75e115b7))
            return _00b9102f8a03(_41fd75e115b7)

        # For any lambda-like keys, store as fixed two-decimal strings for consistent CSV formatting
        for _bb30ea57f3b4 in _8b5759f7e4ee(_5f91b21d95df._b2f677cc6e6a()):
            if "lambda" in _bb30ea57f3b4._5131091d0761() or "λ" in _bb30ea57f3b4:
                _3669cd9c421d = _5f91b21d95df[_bb30ea57f3b4]
                try:
                    _48f55138228f = _fd397dce83e5(_3669cd9c421d)
                except _0e6846a67c55:
                    continue
                _5f91b21d95df[_bb30ea57f3b4] = f"{_48f55138228f:.2f}"

        # Write CSV row; raise if any I/O error occurs so the caller can handle it explicitly
        try:
            with _90ba108ed440(_c5a06e542f2a, "a+", _64d5ce47ecb8="utf8", _e1024c13eb68="") as _77403b3e8b9a:
                _8cf5755fc8e9 = _1f324180cf01._f87ae1c44e9d(_77403b3e8b9a, _c8b526db7fc1=_5f91b21d95df._b2f677cc6e6a())
                if _53b11b229fcd._dfc0664b7b4e._a41cdae9446b(_c5a06e542f2a) == 0:
                    _8cf5755fc8e9._481f26f9e7c2()
                _8cf5755fc8e9._18b139dc5dea([_5f91b21d95df])
        except _0e6846a67c55 as _1feb34a950fe:
            self._a5071afa39fe._53d1e9d02aab("Failed to write epoch metrics CSV: %s", _1feb34a950fe)
            raise _af3b842c5f0b("Failed to write epoch metrics CSV.") from _1feb34a950fe

        # Informational logs for early stopping and learning rate info
        if _57a1f9815a4b._6a6d9944f5bb:
            self._a5071afa39fe._48baf7878bf0("Early stopping activated.")

        for _ec8969518ebb in _57a1f9815a4b._e4a44ef39c3b:
            for _d7c783ab2969 in _ec8969518ebb._8441c2433406:
                _e1d8018f767f = _d7c783ab2969._0f4d9a4099d2("lr", _148c55bce7f0)
                self._a5071afa39fe._48baf7878bf0(f"Current learning rate: {_e1d8018f767f}")

    def _c0e6478d4686(self, _708651a47fcb: _bf9b268f95ff._fe47d865ba77._f1094e792ef8) -> _00b9102f8a03:
        """
        Calculate the approximate size of the model in GB by summing unique parameter storage.

        Notes
        -----
        - When model is wrapped by FSDP and not in IDLE state, skip to avoid accessing FSDP internals unsafely.
        - Avoid double-counting shared parameter objects by tracking `id(param)`.

        Returns
        -------
        float
            Total model size in GiB (approximate).
        """
        # Avoid inspecting FSDP internals during non-idle training state
        if _68338c6cff74(_708651a47fcb, _b30daccae431) and _9a7127658aec(_708651a47fcb, "training_state", _148c55bce7f0) != _abd6bc249886._88ea266c48c8:
            # Skipping is safe: caller expects a float; return 0 to indicate "unknown/skipped"
            _42656ee45c94("Skipping model size calculation: FSDP model is not in IDLE state.")
            return 0.0

        _8fdfd116d566 = 0  # in bytes
        _ec4a53be00ea = _98e5c4d28d7b()

        def _9cae0784d93a(_32fd068174f4):
            nonlocal _8fdfd116d566
            for _56fc1982eaf2 in _32fd068174f4._4fec101078a1(_448064bba377=_75e8310cb6ee):
                _262531c020d2 = _63e19fdf11d8(_56fc1982eaf2)
                if _262531c020d2 not in _ec4a53be00ea:
                    _75fcfc62c207 = _56fc1982eaf2._0bf463e5a6cb()
                    _8fdfd116d566 += _56fc1982eaf2._7608502ef940() * _75fcfc62c207
                    _ec4a53be00ea._782bf0bcc632(_262531c020d2)

        _708651a47fcb._44d3150dce8a(lambda _e03148b65905: _3c9a39122860(_e03148b65905))
        _c8861aafb7cb = _8fdfd116d566 / (1024 ** 3)
        return _c8861aafb7cb

    def _c054970ae5bd(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _6d5911bb009d: _71872b268596 = 1, _b99b97508c1d=_148c55bce7f0) -> _b75b42c141c4:
        """
        Produce a concise table-based model summary (layer name, type, params, trainable/non-trainable)
        and a small metrics table describing full model size vs shard estimates.

        Parameters
        ----------
        trainer : pl.Trainer
            Trainer used to determine strategy and unwrap FSDP if present.
        depth : int
            Depth of module naming to display; modules whose dotted name has depth >= this will be skipped.
        exclude : list[str] or None
            List of substrings; if a module's name contains any exclude token it will not be shown.

        Returns
        -------
        str
            Human-readable summary string including a PrettyTable of layers and summary metrics.
        """
        if _b99b97508c1d is _148c55bce7f0:
            _b99b97508c1d = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

        _708651a47fcb = _57a1f9815a4b._708651a47fcb

        # Attempt to unwrap an FSDP-wrapped core module for meaningful inspection
        if _240ac39e62c9(_708651a47fcb, "_fsdp_wrapped_module") and _240ac39e62c9(_708651a47fcb._ecf9e655dee0, "module"):
            _345b56af7ba8 = _708651a47fcb._ecf9e655dee0._32fd068174f4
            _2b0c0bfd3f51 = _708651a47fcb._ecf9e655dee0
        else:
            _345b56af7ba8 = _708651a47fcb
            _2b0c0bfd3f51 = _148c55bce7f0

        _82e84cea142e = _72a06f5c0e3b()
        _82e84cea142e._6361a21d458d = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

        _24ab26652238 = 0
        _3e1a6e95610c = 0
        _b6952f025c44 = 0
        _4ab30551d690 = _98e5c4d28d7b()

        def _a080095c3fd5(_32fd068174f4):
            _d781faed1fc7 = _8b5759f7e4ee(_32fd068174f4._4fec101078a1())
            _081e0d8154e1 = [_7ab66fa1155c for _7ab66fa1155c in _d781faed1fc7 if _63e19fdf11d8(_7ab66fa1155c) not in _4ab30551d690]
            _4ab30551d690._34099024cc5d(_63e19fdf11d8(_7ab66fa1155c) for _7ab66fa1155c in _081e0d8154e1)

            _7a2e6fa649b9 = _7771025ad3c8(_7ab66fa1155c._7608502ef940() for _7ab66fa1155c in _081e0d8154e1)
            _762b877ec1e4 = _7771025ad3c8(_7ab66fa1155c._7608502ef940() for _7ab66fa1155c in _081e0d8154e1 if _7ab66fa1155c._6ae0fb6361ea)
            _5a69a2f567c3 = _7a2e6fa649b9 - _762b877ec1e4
            return _7a2e6fa649b9, _762b877ec1e4, _5a69a2f567c3

        for _d6b0fd64b934, _32fd068174f4 in _345b56af7ba8._d8f57d1fc344():
            # Skip root module or modules deeper than `depth`
            if _d6b0fd64b934 == "" or _d6b0fd64b934._5b4f3fd37a35(".") >= _6d5911bb009d:
                continue
            if _05dd00379d61(_16edd05012db in _d6b0fd64b934 for _16edd05012db in _b99b97508c1d):
                continue

            _eaa9a1c80528, _177b61c66e65, _d59ef2e9cc06 = _af90da037daf(_32fd068174f4)
            if _eaa9a1c80528 > 0:
                _82e84cea142e._d001f25e99dd(
                    [
                        _d6b0fd64b934,
                        _32fd068174f4._f6e79f2e3168.__name__,
                        f"{_eaa9a1c80528:,}",
                        f"{_177b61c66e65:,}",
                        f"{_d59ef2e9cc06:,}",
                    ]
                )
                _24ab26652238 += _eaa9a1c80528
                _3e1a6e95610c += _177b61c66e65
                _b6952f025c44 += _d59ef2e9cc06

        # Full model size (unsharded) in GB
        _4ac5110db96d = self._c4125f154d7c(_345b56af7ba8)

        # Obtain shard param count from FSDP internals if available
        _c0523ea3fc57 = _148c55bce7f0
        if _2b0c0bfd3f51 is not _148c55bce7f0:
            if _240ac39e62c9(_2b0c0bfd3f51, "_fsdp_flat_param") and _2b0c0bfd3f51._094571a758aa is not _148c55bce7f0:
                _c0523ea3fc57 = _2b0c0bfd3f51._094571a758aa._7608502ef940()
            elif _240ac39e62c9(_2b0c0bfd3f51, "_flat_param") and _2b0c0bfd3f51._d96d58c83b6d is not _148c55bce7f0:
                _c0523ea3fc57 = _2b0c0bfd3f51._d96d58c83b6d._7608502ef940()

        # Determine device/strategy and estimated shard size
        _e31c54f9360c = _9a7127658aec(_57a1f9815a4b, "strategy", _148c55bce7f0)
        _d47e105798e7 = _9a7127658aec(_57a1f9815a4b, "num_devices", _bf9b268f95ff._933e52cdaf69._c4bf20ab03df())
        _c5dfe129e26d = _b75b42c141c4(_e31c54f9360c)._5131091d0761() if _e31c54f9360c else ""
        _24f210045114 = "fsdp" in _c5dfe129e26d
        _d66df29c7d4a = "ddp" in _c5dfe129e26d

        if _24f210045114 and _d47e105798e7 > 0:
            _9423d2e8a0c6 = _4ac5110db96d / _d47e105798e7
        else:
            _9423d2e8a0c6 = _4ac5110db96d

        # Format sizes for display
        _e7c312d22529 = _4ac5110db96d * 1024
        _54d56f1df371 = f"{_4ac5110db96d:.2f} GB" if _4ac5110db96d >= 1 else f"{_e7c312d22529:.2f} MB"
        _d4ad0510e078 = (
            f"{_9423d2e8a0c6:.2f} GB" if _9423d2e8a0c6 >= 1 else f"{_9423d2e8a0c6 * 1024:.2f} MB"
        )

        _1c2c7d4dd47b = _72a06f5c0e3b()
        _1c2c7d4dd47b._6361a21d458d = ["Metric", "Value"]
        _1c2c7d4dd47b._d001f25e99dd(["Total params (full model)", f"{_24ab26652238:,}"])
        _1c2c7d4dd47b._d001f25e99dd(["Trainable params", f"{_3e1a6e95610c:,}"])
        _1c2c7d4dd47b._d001f25e99dd(["Non-trainable params", f"{_b6952f025c44:,}"])
        _1c2c7d4dd47b._d001f25e99dd(["Full model size (unsharded)", _54d56f1df371])

        if _c0523ea3fc57 is not _148c55bce7f0:
            _1c2c7d4dd47b._d001f25e99dd(["Actual per-device shard params (FSDP)", f"{_c0523ea3fc57:,}"])

        if _24f210045114:
            _1c2c7d4dd47b._d001f25e99dd([f"Estimated per-device shard size (FSDP x{_d47e105798e7})", _d4ad0510e078])
        elif _d66df29c7d4a:
            _1c2c7d4dd47b._d001f25e99dd([f"Per-device copy size (DDP x{_d47e105798e7})", _54d56f1df371])
        else:
            _1c2c7d4dd47b._d001f25e99dd(["Parallel strategy", "Single-device or unknown"])

        _4c80711ad078 = f"\n{_82e84cea142e}\n\n{_1c2c7d4dd47b}\n"
        return _4c80711ad078

    def _09e807e1ebc5(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _c6af895ef27d: _2de80215e250._98844be2f3bb) -> _148c55bce7f0:
        """
        Called when fitting begins. Records training start time and logs a model summary.
        If the model has no trainable parameters, sets trainer.should_stop to True to avoid wasted compute.
        """
        _32b9de9c566a = self._3cf2c0a30e7c._07e3608c5c04()
        _5a6ee7e3b176 = self._3cf2c0a30e7c._f274ce8a290c()
        self._a5071afa39fe._48baf7878bf0("Model Training started at {}"._cb741c9ea541(_5a6ee7e3b176))

        if _57a1f9815a4b._76721d126338 == 0:
            self._b61b5ea040ac = _57a1f9815a4b._be047f178a82
            self._3ad86877e3a3["training_start_time"] = _32b9de9c566a
            self._3ad86877e3a3["training_start_date_time"] = _5a6ee7e3b176

        # Print model summary (filtered)
        _065461c80d0c = self._f8d0e2e363d5._0605599f91b7(_57a1f9815a4b, _c6af895ef27d)
        _065461c80d0c = self._2c30f2cfc778(_57a1f9815a4b)
        self._a5071afa39fe._48baf7878bf0(f"Model Training Parameters Summary on Rank {_57a1f9815a4b._76721d126338} \n{_065461c80d0c}")

        # If no trainable params, skip training gracefully
        _6cb818d55532 = _05dd00379d61(_7ab66fa1155c._6ae0fb6361ea for _7ab66fa1155c in _57a1f9815a4b._708651a47fcb._4fec101078a1())
        if not _6cb818d55532:
            self._a5071afa39fe._48baf7878bf0("No trainable parameters found. Skipping training...")
            _57a1f9815a4b._6a6d9944f5bb = _690296bd47e7

    @_c9ad4f590adb
    def _68cd09ff7d89(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _c6af895ef27d: _2de80215e250._98844be2f3bb) -> _148c55bce7f0:
        """
        Called at the start of testing. Logs a model summary for easier debugging.
        """
        _065461c80d0c = self._f8d0e2e363d5._0605599f91b7(_57a1f9815a4b, _c6af895ef27d)
        _065461c80d0c = self._2c30f2cfc778(_57a1f9815a4b)
        self._a5071afa39fe._48baf7878bf0("Model Training Parameters Summary \n{}"._cb741c9ea541(_065461c80d0c))

    @_c9ad4f590adb
    def _72fcb275a426(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _c6af895ef27d: _2de80215e250._98844be2f3bb, _d7546d969114: _c592f52ff82c) -> _148c55bce7f0:
        """
        Called when an exception bubbles up during training. Log final training info to disk for debugging.
        """
        self._0dfe4b0f469e(_57a1f9815a4b=_57a1f9815a4b, _c6af895ef27d=_c6af895ef27d, _89e145bb6bc0="Abnormal Termination due to Exception or an explicit interruption in program")

    @_c9ad4f590adb
    def _84964d04800b(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _c6af895ef27d: _2de80215e250._98844be2f3bb) -> _148c55bce7f0:
        """
        Called at normal completion of training. Finalizes and writes summary metrics.
        """
        self._a5071afa39fe._48baf7878bf0(f"After Fit Model Summary")
        self._0dfe4b0f469e(_57a1f9815a4b, _c6af895ef27d, _89e145bb6bc0="Training Completed Normally ")

    def _8d00c04cf9f2(self, _57a1f9815a4b: _2de80215e250._d6db1bc71c33, _c6af895ef27d: _2de80215e250._98844be2f3bb, _89e145bb6bc0: _b75b42c141c4) -> _148c55bce7f0:
        """
        Internal helper to persist final training summary information and write the metrics summary CSV.

        This aggregates start/end times, computes elapsed training time, persists summary to disk,
        and logs the same model summary computed earlier.
        """
        if self._55290618d792:
            self._3ad86877e3a3["trial_number"] = self._55290618d792._3417ec21ceab

        # Populate start_epoch if missing
        if self._f735f73bbfbf is _148c55bce7f0:
            try:
                self._3ad86877e3a3["start_epoch"] = _00b9102f8a03(_57a1f9815a4b._4b2131685def)
            except _0e6846a67c55:
                self._3ad86877e3a3["start_epoch"] = 0.0

        # Determine end epoch (favor callback metrics if present)
        _631884433dc9 = _57a1f9815a4b._be047f178a82._0f4d9a4099d2("epoch", _57a1f9815a4b._4b2131685def) if _68338c6cff74(_57a1f9815a4b._be047f178a82, _78482eb28f23) else _57a1f9815a4b._4b2131685def
        if _68338c6cff74(_631884433dc9, _bf9b268f95ff._41e870ca6fc6):
            _51b4677900de = _00b9102f8a03(_631884433dc9._28a1050293b8())
        else:
            try:
                _51b4677900de = _00b9102f8a03(_631884433dc9)
            except _0e6846a67c55:
                _51b4677900de = _00b9102f8a03(_57a1f9815a4b._4b2131685def)
        self._3ad86877e3a3["end_epoch"] = _51b4677900de

        _741c61466aad = self._3cf2c0a30e7c._07e3608c5c04()
        self._3ad86877e3a3["training_end_time"] = _741c61466aad
        _5d636dd4a32a = self._3cf2c0a30e7c._f274ce8a290c()
        self._a5071afa39fe._48baf7878bf0("Training completed at {}"._cb741c9ea541(_5d636dd4a32a))
        self._3ad86877e3a3["training_end_date_time"] = _5d636dd4a32a

        # compute model training time safely
        _a73038d2477b = _741c61466aad - self._3ad86877e3a3._0f4d9a4099d2("training_start_time", _741c61466aad)
        self._3ad86877e3a3["model_training_time"] = _a73038d2477b
        self._3ad86877e3a3["model_training_time_details"] = "{} hours {} minutes {} seconds"._cb741c9ea541(
            *self._3cf2c0a30e7c._6e7cea4579b0(_a73038d2477b)
        )

        # Mark training status in summary
        if _57a1f9815a4b._6a6d9944f5bb:
            _89e145bb6bc0 += " Early Stopping Implemented."
        self._3ad86877e3a3["model_training_status"] = _89e145bb6bc0

        # Ensure metrics_dir exists and write summary CSV
        if not _53b11b229fcd._dfc0664b7b4e._bebfa042ff6d(self._1ad1ea3fd645):
            _53b11b229fcd._bc21efb56b80(self._1ad1ea3fd645, _a2d4aa92a010=_690296bd47e7)

        _c5a06e542f2a = _53b11b229fcd._dfc0664b7b4e._562be81ab493(self._1ad1ea3fd645, self._d2475d54a972)
        try:
            with _90ba108ed440(_c5a06e542f2a, "a+", _64d5ce47ecb8="utf8") as _77403b3e8b9a:
                _8cf5755fc8e9 = _1f324180cf01._f87ae1c44e9d(_77403b3e8b9a, _c8b526db7fc1=self._3ad86877e3a3._b2f677cc6e6a())
                if _53b11b229fcd._dfc0664b7b4e._a41cdae9446b(_c5a06e542f2a) == 0:
                    _8cf5755fc8e9._481f26f9e7c2()
                _8cf5755fc8e9._18b139dc5dea([self._3ad86877e3a3])
        except _0e6846a67c55 as _1feb34a950fe:
            self._a5071afa39fe._53d1e9d02aab("Failed to write training summary CSV: %s", _1feb34a950fe)
            raise _af3b842c5f0b("Failed to write training summary CSV.") from _1feb34a950fe

        # Final model summary log
        _065461c80d0c = self._f8d0e2e363d5._0605599f91b7(_57a1f9815a4b, _c6af895ef27d)
        _065461c80d0c = self._2c30f2cfc778(_57a1f9815a4b)
        self._a5071afa39fe._48baf7878bf0(f"Model Training Parameters Summary on Rank {_57a1f9815a4b._76721d126338} \n{_065461c80d0c}")
