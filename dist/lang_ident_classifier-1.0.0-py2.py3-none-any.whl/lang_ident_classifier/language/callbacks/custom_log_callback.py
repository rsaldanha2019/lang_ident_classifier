# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : custom_log_callback.py
# @Time             : 2025-10-23 13:45 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _41ebce40baa0
from _f9ada7e42704 import _89f75c39c130, _8b76b3b653b1
import os._d181bec6a8ce
import _08710945c9d3
import _ce836c6a5da0 as _235f2d6f9eaf
from _d7fb7c44ff00 import _274481362017
import _4ab732575b6d
from _4ab732575b6d._a6493efe5c60._38190b745500 import _fe1f7df30d0e as _0a9b01fba1bd
from _4ab732575b6d._a6493efe5c60._38190b745500._32a0fb86f4cb import _40fa5c309378
from _537c725a6e1f._b68204e0997c._da4fbaeaf0b7 import _8b1dce8f28f4 as _aceb53736b78
import _0359e06471c0 as _262ac7777dd3
from _0359e06471c0._d1067fc35d47._33dca648aeba._1079ad968fda import _cac554f70b55
from _0359e06471c0._d1067fc35d47._715836ee6cfa import _14b9e2941fc5
import _2953f93417aa
from typing import _b6856bd47708, _154a05dc9f9c, _a54ea708df8d


class _2d45acff8954(_262ac7777dd3._80f93e23f134):
    """
    Callback that centralizes logging and metrics summary creation for training runs.

    Purpose
    -------
    - Log environment and trainer startup information.
    - Persist per-epoch metric rows to CSV (human-readable, deterministic formatting).
    - Produce a concise model summary table with parameter counts and estimated shard sizes
      for FSDP/DDP scenarios.
    - Emit informational messages on fit/test lifecycle events and on exceptions.

    Design goals
    ------------
    - Fail early for clearly invalid initialization inputs.
    - Keep all runtime behaviors unchanged from original implementation (no algorithmic changes).
    - Use `rank_zero_only` for actions that should only run on the primary process.
    - Provide clear docstrings and explicit `RuntimeError` on invalid usage.

    Parameters
    ----------
    log : logging.Logger
        Logger instance used for writing human-readable logs.
    model_summary_callback : object
        Object providing `_summary(trainer, pl_module)` (used to obtain model summary text).
    metrics_summary_dict : dict
        Mutable dictionary which will be updated with run-level summary metrics (start/end times, trial).
    metrics_dir : str
        Directory where per-epoch metrics CSV and summary file will be written.
    model_epoch_metrics_file : str
        Filename for per-epoch metrics CSV (written inside metrics_dir).
    model_metrics_summary_file : str
        Filename for aggregated model metrics summary CSV (written inside metrics_dir).
    random_seed : int, optional
        RNG seed used to produce reproducible logging and rounding behavior (default: 20).
    trial : optuna.trial.Trial, optional
        Optional Optuna trial object; if given, `trial.number` will be recorded in summary.

    Raises
    ------
    RuntimeError
        If required arguments are missing or invalid (e.g., `log` is None or metrics paths are invalid).
    """

    def _6819747ffdba(
        self,
        _17ddc9025c7e,
        _036238510ba3,
        _331504147454: _154a05dc9f9c[_fad9652647aa, _a54ea708df8d],
        _cdb7c608b329: _fad9652647aa,
        _23b5e7035556: _fad9652647aa,
        _072a8e32ad1d: _fad9652647aa,
        _7cfbbb3d28cc: _9d7407fd6c9b = 20,
        _3d59cdf42a6b: _b6856bd47708[_2953f93417aa._3d59cdf42a6b._22f708b30fee] = _a497b56ed5e8,
    ):
        # Validate required constructor arguments to fail fast and loudly
        if _17ddc9025c7e is _a497b56ed5e8:
            raise _6444dba28d06("LoggingCallback requires a logger instance (log).")
        if _036238510ba3 is _a497b56ed5e8:
            raise _6444dba28d06("LoggingCallback requires a model_summary_callback object providing _summary().")
        if _331504147454 is _a497b56ed5e8 or not _89d73190cdb4(_331504147454, _6c3d9ad545bc):
            raise _6444dba28d06("metrics_summary_dict must be a dict to collect run-level metrics.")
        if not _89d73190cdb4(_23b5e7035556, _fad9652647aa) or not _23b5e7035556:
            raise _6444dba28d06("model_epoch_metrics_file must be a non-empty filename string.")
        if not _89d73190cdb4(_072a8e32ad1d, _fad9652647aa) or not _072a8e32ad1d:
            raise _6444dba28d06("model_metrics_summary_file must be a non-empty filename string.")
        if not _89d73190cdb4(_cdb7c608b329, _fad9652647aa) or not _cdb7c608b329:
            raise _6444dba28d06("metrics_dir must be a non-empty directory path string.")

        # Store validated inputs
        self._d6d42c667473: _b6856bd47708[_154a05dc9f9c[_fad9652647aa, _a54ea708df8d]] = _a497b56ed5e8
        self._1f2a952a401f = _17ddc9025c7e
        self._3d59cdf42a6b = _3d59cdf42a6b
        self._036238510ba3 = _036238510ba3
        self._23b5e7035556 = _23b5e7035556
        self._cdb7c608b329 = _cdb7c608b329
        self._072a8e32ad1d = _072a8e32ad1d
        self._331504147454 = _331504147454
        self._97601834441b: _b6856bd47708[_ddee809cad67] = _a497b56ed5e8
        self._aceb53736b78 = _aceb53736b78._d6eba37042a8()
        self._2b721646b989 = []
        self._8104c7665543 = _549160f01654
        self._7cfbbb3d28cc = _9d7407fd6c9b(_7cfbbb3d28cc)

        # Seed deterministically for reproducible logging behavior where relevant.
        _262ac7777dd3._91c4061374fa(self._7cfbbb3d28cc, _c71dc65eda95=_92668e71dbed)
        _4ab732575b6d._bffdfeec3073(self._7cfbbb3d28cc)
        if _4ab732575b6d._1c92ce5a529f._dd7436f47886():
            _4ab732575b6d._1c92ce5a529f._f4f4ca8de677(self._7cfbbb3d28cc)

    def _c86ba116b8fe(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _7f1c4ac6e5a7: _262ac7777dd3._f0474c78a46d) -> _a497b56ed5e8:
        """
        Called once at the beginning of training. Logs environment information such as GPU model,
        world size and rank, and dataset sampling summary for distributed runs.
        """
        _1278b9c78833 = ""
        if _4ab732575b6d._1c92ce5a529f._dd7436f47886():
            try:
                # Lazy import for NVML to avoid failing when not available
                from _8d1596542bdc import _0491192f1591, _e3ef2b60ed60, _b83d0de52393

                _0491192f1591()
                _96cf9200b442 = _b83d0de52393(_e3ef2b60ed60(_ebf0986695c4._79ed9ea580e3))._8c824135331a("utf-8")
            except _37b18a6c8967:
                # fallback to a hostname-only message if NVML is not available
                _96cf9200b442 = "unknown-gpu"

            _1278b9c78833 += "World Size {} Global Rank {} Local Rank {}\n"._4362e72edcb8(
                _ebf0986695c4._646392006e4c, _ebf0986695c4._78b45d81131b, _ebf0986695c4._79ed9ea580e3
            )
            _1278b9c78833 += "Running on {} with {}\n"._4362e72edcb8(_08710945c9d3._1a9e2cfe1d08(), _96cf9200b442)

            # If not single-device strategy, attempt to report sampler info
            if not _89d73190cdb4(_ebf0986695c4._d7410e354930, _14b9e2941fc5):
                # Obtain train_dataset in a manner that works whether dataloader or datamodule is used
                _18de89f81072 = _3bdfd359bbac(_ebf0986695c4._8f98e1773012, "train_dataset", _a497b56ed5e8) or _3bdfd359bbac(
                    _ebf0986695c4._8f98e1773012._ffac1dd0ab99(), "dataset", _a497b56ed5e8
                )
                if _89d73190cdb4(_18de89f81072, _4ab732575b6d._da4fbaeaf0b7._cf45aea57704._6725b3e06797):
                    _1278b9c78833 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._4362e72edcb8(
                        _6093dbd711a8(_ebf0986695c4._ffac1dd0ab99._2008c8f70b74),
                        _3bdfd359bbac(_18de89f81072, "num_samples", "unknown"),
                        _3bdfd359bbac(_18de89f81072, "total_size", "unknown"),
                    )
                elif _89d73190cdb4(_18de89f81072, _4ab732575b6d._da4fbaeaf0b7._cf45aea57704._367284c7d435):
                    # sampler attributes expected by CustomGroupBySampleDistributedSampler
                    _2008c8f70b74 = _3bdfd359bbac(_ebf0986695c4._ffac1dd0ab99, "sampler", _a497b56ed5e8)
                    _6c8dd876fc6b = _3bdfd359bbac(_2008c8f70b74, "num_samples", "unknown")
                    _7949752c0307 = _3bdfd359bbac(_2008c8f70b74, "total_size", "unknown")
                    _1278b9c78833 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._4362e72edcb8(
                        _6093dbd711a8(_2008c8f70b74), _6c8dd876fc6b, _7949752c0307
                    )
        else:
            _1278b9c78833 += "No GPU available using cpu as accelerator\n"

        self._1f2a952a401f._ea43ddeca41e(_1278b9c78833)

    def _332b5c572e1a(self, _9979582b9326: _ddee809cad67, _01573edf7513: _9d7407fd6c9b = 3) -> _ddee809cad67:
        """
        Deterministically round a float using Decimal with ROUND_HALF_UP semantics.

        Parameters
        ----------
        val : float
            Value to round.
        precision : int
            Number of decimal places.

        Returns
        -------
        float
            Rounded float.
        """
        return _ddee809cad67(_8b76b3b653b1(_fad9652647aa(_9979582b9326))._b92062e1318b(_8b76b3b653b1(f'1.{"0"*_01573edf7513}'), _a26448c89ebe=_89f75c39c130))

    @_cac554f70b55
    def _f11c4cfda456(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _7f1c4ac6e5a7: _262ac7777dd3._f0474c78a46d) -> _a497b56ed5e8:
        """
        At the end of each training epoch, capture metrics from the trainer, sanitize them,
        and append a row to the epoch metrics CSV. Also logs summary messages and LR info.

        Behavior
        --------
        - Writes a CSV line to `metrics_dir/model_epoch_metrics_file`.
        - Updates `metrics_summary_dict` start_epoch if not previously set.
        - Formats lambda values to two decimal string for consistent CSV representation.

        Exceptions
        ----------
        Raises RuntimeError if writing to the metrics CSV fails due to I/O errors.
        """
        self._d6d42c667473 = _ebf0986695c4._ad7e3e9eaa57

        # Establish start epoch once
        if self._97601834441b is _a497b56ed5e8:
            try:
                _97601834441b = _ddee809cad67(self._d6d42c667473['epoch']._b51095934c5b())
            except _37b18a6c8967:
                _97601834441b = _ddee809cad67(_ebf0986695c4._79397feb34bb)
            self._331504147454['start_epoch'] = _97601834441b
            self._97601834441b = _97601834441b

        # Build a sanitized metrics dict for CSV writing and logging
        _4f24849e76a7 = ""
        _0b618090cdb6: _154a05dc9f9c[_fad9652647aa, _a54ea708df8d] = {}
        for _f035d9fb2ab0 in _e7c328d43b75(self._d6d42c667473):
            _7224c8e30d1e = self._d6d42c667473[_f035d9fb2ab0]._b51095934c5b() if _3affd51299cc(self._d6d42c667473[_f035d9fb2ab0], "item") else self._d6d42c667473[_f035d9fb2ab0]

            # If the metric key contains greek letter lambda 'λ' prefer fixed rounding for readability
            if "λ" in _f035d9fb2ab0:
                try:
                    _9979582b9326 = self._3710d36d73bd(_9979582b9326=_ddee809cad67(_7224c8e30d1e), _01573edf7513=3)
                except _37b18a6c8967:
                    _9979582b9326 = _7224c8e30d1e
            else:
                _9979582b9326 = _7224c8e30d1e

            _4f24849e76a7 += f" {_f035d9fb2ab0}:{_9979582b9326},"
            _0b618090cdb6[_f035d9fb2ab0] = _9979582b9326

        self._1f2a952a401f._ea43ddeca41e(_4f24849e76a7)

        # Ensure metrics directory exists (distributed-safe exists_ok)
        if not os._d181bec6a8ce._3f693eb9cff4(self._cdb7c608b329):
            os._92b9c27c7104(self._cdb7c608b329, _bd9b59476688=_92668e71dbed)

        _348b29761ac0 = os._d181bec6a8ce._92919884b189(self._cdb7c608b329, self._23b5e7035556)

        # Helper: coerce torch/np scalars to python floats
        def _76749dda402b(_d77bcfbe2a36):
            if _89d73190cdb4(_d77bcfbe2a36, _4ab732575b6d._757519ee5b60):
                return _ddee809cad67(_d77bcfbe2a36._25ab01660b99()._b79c16a2fc7c()._b51095934c5b())
            if _89d73190cdb4(_d77bcfbe2a36, (_235f2d6f9eaf._75f228202e94,)):
                return _ddee809cad67(_235f2d6f9eaf._522915379c87(_d77bcfbe2a36))
            return _ddee809cad67(_d77bcfbe2a36)

        # For any lambda-like keys, store as fixed two-decimal strings for consistent CSV formatting
        for _ccb288a88f27 in _93ec81c40317(_0b618090cdb6._7049a3ea02f4()):
            if "lambda" in _ccb288a88f27._304ed8c0a407() or "λ" in _ccb288a88f27:
                _04bd24f71f48 = _0b618090cdb6[_ccb288a88f27]
                try:
                    _72f7c4f22d60 = _5aadf19c350c(_04bd24f71f48)
                except _37b18a6c8967:
                    continue
                _0b618090cdb6[_ccb288a88f27] = f"{_72f7c4f22d60:.2f}"

        # Write CSV row; raise if any I/O error occurs so the caller can handle it explicitly
        try:
            with _de4e9d54b1d7(_348b29761ac0, "a+", _8628f8602fe6="utf8", _412c6072d6f2="") as _cb2b12c15695:
                _cd193e7eccd5 = _41ebce40baa0._e183f5038523(_cb2b12c15695, _fa97ad7443fc=_0b618090cdb6._7049a3ea02f4())
                if os._d181bec6a8ce._6422959d018b(_348b29761ac0) == 0:
                    _cd193e7eccd5._ba48a265cc1d()
                _cd193e7eccd5._063ff2106ec4([_0b618090cdb6])
        except _37b18a6c8967 as _e174d91963b6:
            self._1f2a952a401f._b5b0d97f493c("Failed to write epoch metrics CSV: %s", _e174d91963b6)
            raise _6444dba28d06("Failed to write epoch metrics CSV.") from _e174d91963b6

        # Informational logs for early stopping and learning rate info
        if _ebf0986695c4._db6cfa422e8d:
            self._1f2a952a401f._ea43ddeca41e("Early stopping activated.")

        for _b4d64e0640fe in _ebf0986695c4._3f5dfdb0b092:
            for _37b56888f5f5 in _b4d64e0640fe._46154617336b:
                _e5123f44e8ff = _37b56888f5f5._db7ef4c265cb("lr", _a497b56ed5e8)
                self._1f2a952a401f._ea43ddeca41e(f"Current learning rate: {_e5123f44e8ff}")

    def _5600c2ef3ed3(self, _093162d824b1: _4ab732575b6d._b42394c1c53d._5fb79bd5b145) -> _ddee809cad67:
        """
        Calculate the approximate size of the model in GB by summing unique parameter storage.

        Notes
        -----
        - When model is wrapped by FSDP and not in IDLE state, skip to avoid accessing FSDP internals unsafely.
        - Avoid double-counting shared parameter objects by tracking `id(param)`.

        Returns
        -------
        float
            Total model size in GiB (approximate).
        """
        # Avoid inspecting FSDP internals during non-idle training state
        if _89d73190cdb4(_093162d824b1, _0a9b01fba1bd) and _3bdfd359bbac(_093162d824b1, "training_state", _a497b56ed5e8) != _40fa5c309378._f567966b1d45:
            # Skipping is safe: caller expects a float; return 0 to indicate "unknown/skipped"
            _762dd0e90482("Skipping model size calculation: FSDP model is not in IDLE state.")
            return 0.0

        _cd88216d608d = 0  # in bytes
        _1e69856584a3 = _eac024a2b702()

        def _e779ffea63fe(_5388b927344f):
            nonlocal _cd88216d608d
            for _c7d7b19a73fd in _5388b927344f._2c80655c1e57(_b7d2a412feea=_549160f01654):
                _a89dc658b147 = _d357a353373a(_c7d7b19a73fd)
                if _a89dc658b147 not in _1e69856584a3:
                    _3b5189e7d96a = _c7d7b19a73fd._8e40a4775620()
                    _cd88216d608d += _c7d7b19a73fd._6846197703f2() * _3b5189e7d96a
                    _1e69856584a3._c043f94b6739(_a89dc658b147)

        _093162d824b1._18dd7a2b514d(lambda _f1ffe8773417: _561888d88512(_f1ffe8773417))
        _35d8d291ab6b = _cd88216d608d / (1024 ** 3)
        return _35d8d291ab6b

    def _276be4572fe8(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _b61308c655ea: _9d7407fd6c9b = 1, _8f535f2ecd62=_a497b56ed5e8) -> _fad9652647aa:
        """
        Produce a concise table-based model summary (layer name, type, params, trainable/non-trainable)
        and a small metrics table describing full model size vs shard estimates.

        Parameters
        ----------
        trainer : pl.Trainer
            Trainer used to determine strategy and unwrap FSDP if present.
        depth : int
            Depth of module naming to display; modules whose dotted name has depth >= this will be skipped.
        exclude : list[str] or None
            List of substrings; if a module's name contains any exclude token it will not be shown.

        Returns
        -------
        str
            Human-readable summary string including a PrettyTable of layers and summary metrics.
        """
        if _8f535f2ecd62 is _a497b56ed5e8:
            _8f535f2ecd62 = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

        _093162d824b1 = _ebf0986695c4._093162d824b1

        # Attempt to unwrap an FSDP-wrapped core module for meaningful inspection
        if _3affd51299cc(_093162d824b1, "_fsdp_wrapped_module") and _3affd51299cc(_093162d824b1._ad7ee36c9903, "module"):
            _d85c2a12c463 = _093162d824b1._ad7ee36c9903._5388b927344f
            _de8da379d580 = _093162d824b1._ad7ee36c9903
        else:
            _d85c2a12c463 = _093162d824b1
            _de8da379d580 = _a497b56ed5e8

        _e4c5cf1629af = _274481362017()
        _e4c5cf1629af._cdc46c75d060 = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

        _ad4a00b0c6a7 = 0
        _4c08ae71647c = 0
        _09e8166364c9 = 0
        _6b0038770043 = _eac024a2b702()

        def _91d0bae9ea9e(_5388b927344f):
            _2f708665076f = _93ec81c40317(_5388b927344f._2c80655c1e57())
            _30bfd9ad6011 = [_44edf0f8a3fe for _44edf0f8a3fe in _2f708665076f if _d357a353373a(_44edf0f8a3fe) not in _6b0038770043]
            _6b0038770043._5f8338969c64(_d357a353373a(_44edf0f8a3fe) for _44edf0f8a3fe in _30bfd9ad6011)

            _b12dba614455 = _9fff5757db38(_44edf0f8a3fe._6846197703f2() for _44edf0f8a3fe in _30bfd9ad6011)
            _e6df13215183 = _9fff5757db38(_44edf0f8a3fe._6846197703f2() for _44edf0f8a3fe in _30bfd9ad6011 if _44edf0f8a3fe._a0df4ea132f9)
            _fdc83da94aac = _b12dba614455 - _e6df13215183
            return _b12dba614455, _e6df13215183, _fdc83da94aac

        for _e62294f5dd1a, _5388b927344f in _d85c2a12c463._423f52d32aee():
            # Skip root module or modules deeper than `depth`
            if _e62294f5dd1a == "" or _e62294f5dd1a._bfbc03928279(".") >= _b61308c655ea:
                continue
            if _2a96ea32135c(_85cec28bd0b8 in _e62294f5dd1a for _85cec28bd0b8 in _8f535f2ecd62):
                continue

            _2bede10ab8eb, _8a8bb059ba12, _6e1e9740cfea = _7ff5791e7dbc(_5388b927344f)
            if _2bede10ab8eb > 0:
                _e4c5cf1629af._355843159362(
                    [
                        _e62294f5dd1a,
                        _5388b927344f._9f44a961f36e.__name__,
                        f"{_2bede10ab8eb:,}",
                        f"{_8a8bb059ba12:,}",
                        f"{_6e1e9740cfea:,}",
                    ]
                )
                _ad4a00b0c6a7 += _2bede10ab8eb
                _4c08ae71647c += _8a8bb059ba12
                _09e8166364c9 += _6e1e9740cfea

        # Full model size (unsharded) in GB
        _2a8877ff5586 = self._5d4dafe8e7fb(_d85c2a12c463)

        # Obtain shard param count from FSDP internals if available
        _2f6fe6cb0e1b = _a497b56ed5e8
        if _de8da379d580 is not _a497b56ed5e8:
            if _3affd51299cc(_de8da379d580, "_fsdp_flat_param") and _de8da379d580._cd77e7a10474 is not _a497b56ed5e8:
                _2f6fe6cb0e1b = _de8da379d580._cd77e7a10474._6846197703f2()
            elif _3affd51299cc(_de8da379d580, "_flat_param") and _de8da379d580._8a5310821ef0 is not _a497b56ed5e8:
                _2f6fe6cb0e1b = _de8da379d580._8a5310821ef0._6846197703f2()

        # Determine device/strategy and estimated shard size
        _d7410e354930 = _3bdfd359bbac(_ebf0986695c4, "strategy", _a497b56ed5e8)
        _e8065b669855 = _3bdfd359bbac(_ebf0986695c4, "num_devices", _4ab732575b6d._1c92ce5a529f._64fbe98f2f40())
        _37321edcfa91 = _fad9652647aa(_d7410e354930)._304ed8c0a407() if _d7410e354930 else ""
        _3f01e5b3943e = "fsdp" in _37321edcfa91
        _850391f31f4c = "ddp" in _37321edcfa91

        if _3f01e5b3943e and _e8065b669855 > 0:
            _e020edfeeb1e = _2a8877ff5586 / _e8065b669855
        else:
            _e020edfeeb1e = _2a8877ff5586

        # Format sizes for display
        _555f60ae557d = _2a8877ff5586 * 1024
        _d2c8de608e3a = f"{_2a8877ff5586:.2f} GB" if _2a8877ff5586 >= 1 else f"{_555f60ae557d:.2f} MB"
        _38cbcab32b8e = (
            f"{_e020edfeeb1e:.2f} GB" if _e020edfeeb1e >= 1 else f"{_e020edfeeb1e * 1024:.2f} MB"
        )

        _fab157b9cfee = _274481362017()
        _fab157b9cfee._cdc46c75d060 = ["Metric", "Value"]
        _fab157b9cfee._355843159362(["Total params (full model)", f"{_ad4a00b0c6a7:,}"])
        _fab157b9cfee._355843159362(["Trainable params", f"{_4c08ae71647c:,}"])
        _fab157b9cfee._355843159362(["Non-trainable params", f"{_09e8166364c9:,}"])
        _fab157b9cfee._355843159362(["Full model size (unsharded)", _d2c8de608e3a])

        if _2f6fe6cb0e1b is not _a497b56ed5e8:
            _fab157b9cfee._355843159362(["Actual per-device shard params (FSDP)", f"{_2f6fe6cb0e1b:,}"])

        if _3f01e5b3943e:
            _fab157b9cfee._355843159362([f"Estimated per-device shard size (FSDP x{_e8065b669855})", _38cbcab32b8e])
        elif _850391f31f4c:
            _fab157b9cfee._355843159362([f"Per-device copy size (DDP x{_e8065b669855})", _d2c8de608e3a])
        else:
            _fab157b9cfee._355843159362(["Parallel strategy", "Single-device or unknown"])

        _e0b66b48ef77 = f"\n{_e4c5cf1629af}\n\n{_fab157b9cfee}\n"
        return _e0b66b48ef77

    def _d246ec3f8271(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _7f1c4ac6e5a7: _262ac7777dd3._f0474c78a46d) -> _a497b56ed5e8:
        """
        Called when fitting begins. Records training start time and logs a model summary.
        If the model has no trainable parameters, sets trainer.should_stop to True to avoid wasted compute.
        """
        _f5ca419a19eb = self._aceb53736b78._053639c3f5b2()
        _f32d3ef9f64b = self._aceb53736b78._cdcb81a2d887()
        self._1f2a952a401f._ea43ddeca41e("Model Training started at {}"._4362e72edcb8(_f32d3ef9f64b))

        if _ebf0986695c4._78b45d81131b == 0:
            self._d6d42c667473 = _ebf0986695c4._ad7e3e9eaa57
            self._331504147454["training_start_time"] = _f5ca419a19eb
            self._331504147454["training_start_date_time"] = _f32d3ef9f64b

        # Print model summary (filtered)
        _5c23148e0a48 = self._036238510ba3._f6e1c96b4172(_ebf0986695c4, _7f1c4ac6e5a7)
        _5c23148e0a48 = self._fe49ec8ea3aa(_ebf0986695c4)
        self._1f2a952a401f._ea43ddeca41e(f"Model Training Parameters Summary on Rank {_ebf0986695c4._78b45d81131b} \n{_5c23148e0a48}")

        # If no trainable params, skip training gracefully
        _a2a8cf5ae81f = _2a96ea32135c(_44edf0f8a3fe._a0df4ea132f9 for _44edf0f8a3fe in _ebf0986695c4._093162d824b1._2c80655c1e57())
        if not _a2a8cf5ae81f:
            self._1f2a952a401f._ea43ddeca41e("No trainable parameters found. Skipping training...")
            _ebf0986695c4._db6cfa422e8d = _92668e71dbed

    @_cac554f70b55
    def _8238427ff36a(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _7f1c4ac6e5a7: _262ac7777dd3._f0474c78a46d) -> _a497b56ed5e8:
        """
        Called at the start of testing. Logs a model summary for easier debugging.
        """
        _5c23148e0a48 = self._036238510ba3._f6e1c96b4172(_ebf0986695c4, _7f1c4ac6e5a7)
        _5c23148e0a48 = self._fe49ec8ea3aa(_ebf0986695c4)
        self._1f2a952a401f._ea43ddeca41e("Model Training Parameters Summary \n{}"._4362e72edcb8(_5c23148e0a48))

    @_cac554f70b55
    def _5a3648533649(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _7f1c4ac6e5a7: _262ac7777dd3._f0474c78a46d, _e05c9496fdd7: _2e81da3e8084) -> _a497b56ed5e8:
        """
        Called when an exception bubbles up during training. Log final training info to disk for debugging.
        """
        self._c36c56996d81(_ebf0986695c4=_ebf0986695c4, _7f1c4ac6e5a7=_7f1c4ac6e5a7, _6eb02294c8f4="Abnormal Termination due to Exception or an explicit interruption in program")

    @_cac554f70b55
    def _1f3051ac07d2(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _7f1c4ac6e5a7: _262ac7777dd3._f0474c78a46d) -> _a497b56ed5e8:
        """
        Called at normal completion of training. Finalizes and writes summary metrics.
        """
        self._1f2a952a401f._ea43ddeca41e(f"After Fit Model Summary")
        self._c36c56996d81(_ebf0986695c4, _7f1c4ac6e5a7, _6eb02294c8f4="Training Completed Normally ")

    def _7b22bf72d03c(self, _ebf0986695c4: _262ac7777dd3._f15be84ad9f6, _7f1c4ac6e5a7: _262ac7777dd3._f0474c78a46d, _6eb02294c8f4: _fad9652647aa) -> _a497b56ed5e8:
        """
        Internal helper to persist final training summary information and write the metrics summary CSV.

        This aggregates start/end times, computes elapsed training time, persists summary to disk,
        and logs the same model summary computed earlier.
        """
        if self._3d59cdf42a6b:
            self._331504147454["trial_number"] = self._3d59cdf42a6b._036346d9b408

        # Populate start_epoch if missing
        if self._97601834441b is _a497b56ed5e8:
            try:
                self._331504147454["start_epoch"] = _ddee809cad67(_ebf0986695c4._79397feb34bb)
            except _37b18a6c8967:
                self._331504147454["start_epoch"] = 0.0

        # Determine end epoch (favor callback metrics if present)
        _18dc482c5e13 = _ebf0986695c4._ad7e3e9eaa57._db7ef4c265cb("epoch", _ebf0986695c4._79397feb34bb) if _89d73190cdb4(_ebf0986695c4._ad7e3e9eaa57, _6c3d9ad545bc) else _ebf0986695c4._79397feb34bb
        if _89d73190cdb4(_18dc482c5e13, _4ab732575b6d._757519ee5b60):
            _55b5470849b3 = _ddee809cad67(_18dc482c5e13._b51095934c5b())
        else:
            try:
                _55b5470849b3 = _ddee809cad67(_18dc482c5e13)
            except _37b18a6c8967:
                _55b5470849b3 = _ddee809cad67(_ebf0986695c4._79397feb34bb)
        self._331504147454["end_epoch"] = _55b5470849b3

        _f624209b0ba8 = self._aceb53736b78._053639c3f5b2()
        self._331504147454["training_end_time"] = _f624209b0ba8
        _fff1800a257c = self._aceb53736b78._cdcb81a2d887()
        self._1f2a952a401f._ea43ddeca41e("Training completed at {}"._4362e72edcb8(_fff1800a257c))
        self._331504147454["training_end_date_time"] = _fff1800a257c

        # compute model training time safely
        _85983a236c18 = _f624209b0ba8 - self._331504147454._db7ef4c265cb("training_start_time", _f624209b0ba8)
        self._331504147454["model_training_time"] = _85983a236c18
        self._331504147454["model_training_time_details"] = "{} hours {} minutes {} seconds"._4362e72edcb8(
            *self._aceb53736b78._d1b90a4c9142(_85983a236c18)
        )

        # Mark training status in summary
        if _ebf0986695c4._db6cfa422e8d:
            _6eb02294c8f4 += " Early Stopping Implemented."
        self._331504147454["model_training_status"] = _6eb02294c8f4

        # Ensure metrics_dir exists and write summary CSV
        if not os._d181bec6a8ce._3f693eb9cff4(self._cdb7c608b329):
            os._92b9c27c7104(self._cdb7c608b329, _bd9b59476688=_92668e71dbed)

        _348b29761ac0 = os._d181bec6a8ce._92919884b189(self._cdb7c608b329, self._072a8e32ad1d)
        try:
            with _de4e9d54b1d7(_348b29761ac0, "a+", _8628f8602fe6="utf8") as _cb2b12c15695:
                _cd193e7eccd5 = _41ebce40baa0._e183f5038523(_cb2b12c15695, _fa97ad7443fc=self._331504147454._7049a3ea02f4())
                if os._d181bec6a8ce._6422959d018b(_348b29761ac0) == 0:
                    _cd193e7eccd5._ba48a265cc1d()
                _cd193e7eccd5._063ff2106ec4([self._331504147454])
        except _37b18a6c8967 as _e174d91963b6:
            self._1f2a952a401f._b5b0d97f493c("Failed to write training summary CSV: %s", _e174d91963b6)
            raise _6444dba28d06("Failed to write training summary CSV.") from _e174d91963b6

        # Final model summary log
        _5c23148e0a48 = self._036238510ba3._f6e1c96b4172(_ebf0986695c4, _7f1c4ac6e5a7)
        _5c23148e0a48 = self._fe49ec8ea3aa(_ebf0986695c4)
        self._1f2a952a401f._ea43ddeca41e(f"Model Training Parameters Summary on Rank {_ebf0986695c4._78b45d81131b} \n{_5c23148e0a48}")
