# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : custom_log_callback.py
# @Time             : 2025-10-23 13:45 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _d823f7120295
from _b995beed1ef9 import _d931ef6b84f9, _fe4a716db25d
import os._30207762628c
import _71e8ba38ce8a
import _e0cc1f6f6fc6 as _ba80e1d2ad08
from _1268b314911d import _cc9175c1ea71
import _02127ade5a57
from _02127ade5a57._813e2243a0aa._c1ae0af564e1 import _e6854dc00cb8 as _c9e103036a51
from _02127ade5a57._813e2243a0aa._c1ae0af564e1._d19ed82ecc08 import _ac997f8bea7c
from _f5b9ddcb42bf._518089a81189._7c4a10bdb3a7 import _5e7010461823 as _e68129aa225c
import _42930add9660 as _e747e8cdc0fc
from _42930add9660._5f255c4bdb97._fdd04aa87a40._0096f7efff75 import _c8a1149f3829
from _42930add9660._5f255c4bdb97._93d13a0b1d9b import _5c1efd42edc2
import _5f0aacdf8b61
from typing import _819944a852b6, _4bb37ef24f6e, _767779893882


class _7e41379b8663(_e747e8cdc0fc._20c028701782):
    """
    Callback that centralizes logging and metrics summary creation for training runs.

    Purpose
    -------
    - Log environment and trainer startup information.
    - Persist per-epoch metric rows to CSV (human-readable, deterministic formatting).
    - Produce a concise model summary table with parameter counts and estimated shard sizes
      for FSDP/DDP scenarios.
    - Emit informational messages on fit/test lifecycle events and on exceptions.

    Design goals
    ------------
    - Fail early for clearly invalid initialization inputs.
    - Keep all runtime behaviors unchanged from original implementation (no algorithmic changes).
    - Use `rank_zero_only` for actions that should only run on the primary process.
    - Provide clear docstrings and explicit `RuntimeError` on invalid usage.

    Parameters
    ----------
    log : logging.Logger
        Logger instance used for writing human-readable logs.
    model_summary_callback : object
        Object providing `_summary(trainer, pl_module)` (used to obtain model summary text).
    metrics_summary_dict : dict
        Mutable dictionary which will be updated with run-level summary metrics (start/end times, trial).
    metrics_dir : str
        Directory where per-epoch metrics CSV and summary file will be written.
    model_epoch_metrics_file : str
        Filename for per-epoch metrics CSV (written inside metrics_dir).
    model_metrics_summary_file : str
        Filename for aggregated model metrics summary CSV (written inside metrics_dir).
    random_seed : int, optional
        RNG seed used to produce reproducible logging and rounding behavior (default: 20).
    trial : optuna.trial.Trial, optional
        Optional Optuna trial object; if given, `trial.number` will be recorded in summary.

    Raises
    ------
    RuntimeError
        If required arguments are missing or invalid (e.g., `log` is None or metrics paths are invalid).
    """

    def _218e7f54a418(
        self,
        _78f992c49c4e,
        _381bb235ec9f,
        _0914ba0899f8: _4bb37ef24f6e[_4cce2f6c3bba, _767779893882],
        _e616b6cf34cb: _4cce2f6c3bba,
        _dd139b65d5cb: _4cce2f6c3bba,
        _837cb3233f48: _4cce2f6c3bba,
        _63e93f9f7def: _e9e3399de7b8 = 20,
        _6493015466ad: _819944a852b6[_5f0aacdf8b61._6493015466ad._09a7f67290c4] = _8ac857bb9f17,
    ):
        # Validate required constructor arguments to fail fast and loudly
        if _78f992c49c4e is _8ac857bb9f17:
            raise _be80e8a4e2a4("LoggingCallback requires a logger instance (log).")
        if _381bb235ec9f is _8ac857bb9f17:
            raise _be80e8a4e2a4("LoggingCallback requires a model_summary_callback object providing _summary().")
        if _0914ba0899f8 is _8ac857bb9f17 or not _2df19dfc5069(_0914ba0899f8, _ed97d3aa470e):
            raise _be80e8a4e2a4("metrics_summary_dict must be a dict to collect run-level metrics.")
        if not _2df19dfc5069(_dd139b65d5cb, _4cce2f6c3bba) or not _dd139b65d5cb:
            raise _be80e8a4e2a4("model_epoch_metrics_file must be a non-empty filename string.")
        if not _2df19dfc5069(_837cb3233f48, _4cce2f6c3bba) or not _837cb3233f48:
            raise _be80e8a4e2a4("model_metrics_summary_file must be a non-empty filename string.")
        if not _2df19dfc5069(_e616b6cf34cb, _4cce2f6c3bba) or not _e616b6cf34cb:
            raise _be80e8a4e2a4("metrics_dir must be a non-empty directory path string.")

        # Store validated inputs
        self._6fd455540ba5: _819944a852b6[_4bb37ef24f6e[_4cce2f6c3bba, _767779893882]] = _8ac857bb9f17
        self._165dc91e6a23 = _78f992c49c4e
        self._6493015466ad = _6493015466ad
        self._381bb235ec9f = _381bb235ec9f
        self._dd139b65d5cb = _dd139b65d5cb
        self._e616b6cf34cb = _e616b6cf34cb
        self._837cb3233f48 = _837cb3233f48
        self._0914ba0899f8 = _0914ba0899f8
        self._45e0dce1f4e5: _819944a852b6[_157786be5058] = _8ac857bb9f17
        self._e68129aa225c = _e68129aa225c._b65a45bc4774()
        self._bcc834153d12 = []
        self._845bcdf63eda = _ec8ec07a1161
        self._63e93f9f7def = _e9e3399de7b8(_63e93f9f7def)

        # Seed deterministically for reproducible logging behavior where relevant.
        _e747e8cdc0fc._178cd6e488f1(self._63e93f9f7def, _2ad84ebc6ddf=_c2aa451d0f43)
        _02127ade5a57._4e296f42b54d(self._63e93f9f7def)
        if _02127ade5a57._c57d947f441c._8b0e8500db04():
            _02127ade5a57._c57d947f441c._8b9f1b9c6a06(self._63e93f9f7def)

    def _27c4239ced8e(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _35d0e6c70220: _e747e8cdc0fc._4191bdd15323) -> _8ac857bb9f17:
        """
        Called once at the beginning of training. Logs environment information such as GPU model,
        world size and rank, and dataset sampling summary for distributed runs.
        """
        _19042e1e8577 = ""
        if _02127ade5a57._c57d947f441c._8b0e8500db04():
            try:
                # Lazy import for NVML to avoid failing when not available
                from _dcb7d0b7284c import _a6a1b8b0db50, _1e2b8ebdf4e9, _1830c6c46c45

                _a6a1b8b0db50()
                _ae780ec40315 = _1830c6c46c45(_1e2b8ebdf4e9(_ae5460011e64._6772a6b457f5))._a91ac5126079("utf-8")
            except _ba4e4ffc71a7:
                # fallback to a hostname-only message if NVML is not available
                _ae780ec40315 = "unknown-gpu"

            _19042e1e8577 += "World Size {} Global Rank {} Local Rank {}\n"._37be876dd235(
                _ae5460011e64._557077c81ff7, _ae5460011e64._6edf6878bfa4, _ae5460011e64._6772a6b457f5
            )
            _19042e1e8577 += "Running on {} with {}\n"._37be876dd235(_71e8ba38ce8a._5922087960f8(), _ae780ec40315)

            # If not single-device strategy, attempt to report sampler info
            if not _2df19dfc5069(_ae5460011e64._95af14312f56, _5c1efd42edc2):
                # Obtain train_dataset in a manner that works whether dataloader or datamodule is used
                _d4ab78c33201 = _b0b8b5c7a25d(_ae5460011e64._741c401de84d, "train_dataset", _8ac857bb9f17) or _b0b8b5c7a25d(
                    _ae5460011e64._741c401de84d._9517d8333e40(), "dataset", _8ac857bb9f17
                )
                if _2df19dfc5069(_d4ab78c33201, _02127ade5a57._7c4a10bdb3a7._7efa1b2c7440._3c65491b3ae1):
                    _19042e1e8577 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._37be876dd235(
                        _83908ae5abd1(_ae5460011e64._9517d8333e40._6e66159b66f5),
                        _b0b8b5c7a25d(_d4ab78c33201, "num_samples", "unknown"),
                        _b0b8b5c7a25d(_d4ab78c33201, "total_size", "unknown"),
                    )
                elif _2df19dfc5069(_d4ab78c33201, _02127ade5a57._7c4a10bdb3a7._7efa1b2c7440._3981609594e0):
                    # sampler attributes expected by CustomGroupBySampleDistributedSampler
                    _6e66159b66f5 = _b0b8b5c7a25d(_ae5460011e64._9517d8333e40, "sampler", _8ac857bb9f17)
                    _8fbe1ddb7a4d = _b0b8b5c7a25d(_6e66159b66f5, "num_samples", "unknown")
                    _890543fa356e = _b0b8b5c7a25d(_6e66159b66f5, "total_size", "unknown")
                    _19042e1e8577 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._37be876dd235(
                        _83908ae5abd1(_6e66159b66f5), _8fbe1ddb7a4d, _890543fa356e
                    )
        else:
            _19042e1e8577 += "No GPU available using cpu as accelerator\n"

        self._165dc91e6a23._c16b58d80752(_19042e1e8577)

    def _900dd755a8f0(self, _62ec733f00dc: _157786be5058, _8784d553eac6: _e9e3399de7b8 = 3) -> _157786be5058:
        """
        Deterministically round a float using Decimal with ROUND_HALF_UP semantics.

        Parameters
        ----------
        val : float
            Value to round.
        precision : int
            Number of decimal places.

        Returns
        -------
        float
            Rounded float.
        """
        return _157786be5058(_fe4a716db25d(_4cce2f6c3bba(_62ec733f00dc))._87e177059f8c(_fe4a716db25d(f'1.{"0"*_8784d553eac6}'), _83245a848bee=_d931ef6b84f9))

    @_c8a1149f3829
    def _f8d97d32461b(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _35d0e6c70220: _e747e8cdc0fc._4191bdd15323) -> _8ac857bb9f17:
        """
        At the end of each training epoch, capture metrics from the trainer, sanitize them,
        and append a row to the epoch metrics CSV. Also logs summary messages and LR info.

        Behavior
        --------
        - Writes a CSV line to `metrics_dir/model_epoch_metrics_file`.
        - Updates `metrics_summary_dict` start_epoch if not previously set.
        - Formats lambda values to two decimal string for consistent CSV representation.

        Exceptions
        ----------
        Raises RuntimeError if writing to the metrics CSV fails due to I/O errors.
        """
        self._6fd455540ba5 = _ae5460011e64._b96aa61d359e

        # Establish start epoch once
        if self._45e0dce1f4e5 is _8ac857bb9f17:
            try:
                _45e0dce1f4e5 = _157786be5058(self._6fd455540ba5['epoch']._e60e94822363())
            except _ba4e4ffc71a7:
                _45e0dce1f4e5 = _157786be5058(_ae5460011e64._127f972a1ab7)
            self._0914ba0899f8['start_epoch'] = _45e0dce1f4e5
            self._45e0dce1f4e5 = _45e0dce1f4e5

        # Build a sanitized metrics dict for CSV writing and logging
        _3f4009cedcac = ""
        _f8ceff61e420: _4bb37ef24f6e[_4cce2f6c3bba, _767779893882] = {}
        for _924880caf13d in _669ca6551d2f(self._6fd455540ba5):
            _ac5ad9c0457b = self._6fd455540ba5[_924880caf13d]._e60e94822363() if _23625e222ffe(self._6fd455540ba5[_924880caf13d], "item") else self._6fd455540ba5[_924880caf13d]

            # If the metric key contains greek letter lambda 'λ' prefer fixed rounding for readability
            if "λ" in _924880caf13d:
                try:
                    _62ec733f00dc = self._78bd4019404e(_62ec733f00dc=_157786be5058(_ac5ad9c0457b), _8784d553eac6=3)
                except _ba4e4ffc71a7:
                    _62ec733f00dc = _ac5ad9c0457b
            else:
                _62ec733f00dc = _ac5ad9c0457b

            _3f4009cedcac += f" {_924880caf13d}:{_62ec733f00dc},"
            _f8ceff61e420[_924880caf13d] = _62ec733f00dc

        self._165dc91e6a23._c16b58d80752(_3f4009cedcac)

        # Ensure metrics directory exists (distributed-safe exists_ok)
        if not os._30207762628c._b5ee101c8e02(self._e616b6cf34cb):
            os._2c3ada526f7e(self._e616b6cf34cb, _1b58324387ac=_c2aa451d0f43)

        _4c2b5357ed1e = os._30207762628c._4a2d40afe6fb(self._e616b6cf34cb, self._dd139b65d5cb)

        # Helper: coerce torch/np scalars to python floats
        def _0a98694533e0(_4af1958a382d):
            if _2df19dfc5069(_4af1958a382d, _02127ade5a57._30928346e270):
                return _157786be5058(_4af1958a382d._34db0ca509cc()._d34553b09b22()._e60e94822363())
            if _2df19dfc5069(_4af1958a382d, (_ba80e1d2ad08._4d8cd05c2d61,)):
                return _157786be5058(_ba80e1d2ad08._36cb2433fd21(_4af1958a382d))
            return _157786be5058(_4af1958a382d)

        # For any lambda-like keys, store as fixed two-decimal strings for consistent CSV formatting
        for _730c981daa80 in _f931a3596410(_f8ceff61e420._6198a9546166()):
            if "lambda" in _730c981daa80._63ccc365233e() or "λ" in _730c981daa80:
                _2da0fb508ac5 = _f8ceff61e420[_730c981daa80]
                try:
                    _64ad4709cdce = _898564a2408f(_2da0fb508ac5)
                except _ba4e4ffc71a7:
                    continue
                _f8ceff61e420[_730c981daa80] = f"{_64ad4709cdce:.2f}"

        # Write CSV row; raise if any I/O error occurs so the caller can handle it explicitly
        try:
            with _1ddeb73cd14d(_4c2b5357ed1e, "a+", _888771c5daf8="utf8", _3f982a1cad3d="") as _367b9d7ba94e:
                _5504d1b37531 = _d823f7120295._8320c4a4b3d7(_367b9d7ba94e, _8fa283a93a50=_f8ceff61e420._6198a9546166())
                if os._30207762628c._ac19c14f3798(_4c2b5357ed1e) == 0:
                    _5504d1b37531._41c244f4ffad()
                _5504d1b37531._2d17227de6a1([_f8ceff61e420])
        except _ba4e4ffc71a7 as _02e7cfa76e4b:
            self._165dc91e6a23._b51722b39577("Failed to write epoch metrics CSV: %s", _02e7cfa76e4b)
            raise _be80e8a4e2a4("Failed to write epoch metrics CSV.") from _02e7cfa76e4b

        # Informational logs for early stopping and learning rate info
        if _ae5460011e64._bf43d090896d:
            self._165dc91e6a23._c16b58d80752("Early stopping activated.")

        for _15ff26560818 in _ae5460011e64._eec3f3c8f14d:
            for _1d3ce27f14f0 in _15ff26560818._5a20a561ce95:
                _0511db44ce06 = _1d3ce27f14f0._7dcc8d9b957e("lr", _8ac857bb9f17)
                self._165dc91e6a23._c16b58d80752(f"Current learning rate: {_0511db44ce06}")

    def _a04ab0555ffd(self, _f26942ec9f35: _02127ade5a57._50b1db7d5b4d._edb2261edc55) -> _157786be5058:
        """
        Calculate the approximate size of the model in GB by summing unique parameter storage.

        Notes
        -----
        - When model is wrapped by FSDP and not in IDLE state, skip to avoid accessing FSDP internals unsafely.
        - Avoid double-counting shared parameter objects by tracking `id(param)`.

        Returns
        -------
        float
            Total model size in GiB (approximate).
        """
        # Avoid inspecting FSDP internals during non-idle training state
        if _2df19dfc5069(_f26942ec9f35, _c9e103036a51) and _b0b8b5c7a25d(_f26942ec9f35, "training_state", _8ac857bb9f17) != _ac997f8bea7c._593296b9da9f:
            # Skipping is safe: caller expects a float; return 0 to indicate "unknown/skipped"
            _c1750163776d("Skipping model size calculation: FSDP model is not in IDLE state.")
            return 0.0

        _7910d3074a3e = 0  # in bytes
        _f4598049616e = _1e3e5c27c705()

        def _c0728bb73980(_5e7acee188d8):
            nonlocal _7910d3074a3e
            for _315a0d4e58a7 in _5e7acee188d8._14532f5dcd15(_42f39a365ca7=_ec8ec07a1161):
                _669fd0f887c3 = _2a36372abb6c(_315a0d4e58a7)
                if _669fd0f887c3 not in _f4598049616e:
                    _600f2c80fc10 = _315a0d4e58a7._0abfcfa3cda2()
                    _7910d3074a3e += _315a0d4e58a7._7f76bd0ec848() * _600f2c80fc10
                    _f4598049616e._ffbd934327b2(_669fd0f887c3)

        _f26942ec9f35._4dbc99a12328(lambda _39c3850fc5b2: _b126f5798dea(_39c3850fc5b2))
        _d8c6b6ebcf8b = _7910d3074a3e / (1024 ** 3)
        return _d8c6b6ebcf8b

    def _6fe284540219(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _a8cb5b09749a: _e9e3399de7b8 = 1, _0cf954ec0cca=_8ac857bb9f17) -> _4cce2f6c3bba:
        """
        Produce a concise table-based model summary (layer name, type, params, trainable/non-trainable)
        and a small metrics table describing full model size vs shard estimates.

        Parameters
        ----------
        trainer : pl.Trainer
            Trainer used to determine strategy and unwrap FSDP if present.
        depth : int
            Depth of module naming to display; modules whose dotted name has depth >= this will be skipped.
        exclude : list[str] or None
            List of substrings; if a module's name contains any exclude token it will not be shown.

        Returns
        -------
        str
            Human-readable summary string including a PrettyTable of layers and summary metrics.
        """
        if _0cf954ec0cca is _8ac857bb9f17:
            _0cf954ec0cca = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

        _f26942ec9f35 = _ae5460011e64._f26942ec9f35

        # Attempt to unwrap an FSDP-wrapped core module for meaningful inspection
        if _23625e222ffe(_f26942ec9f35, "_fsdp_wrapped_module") and _23625e222ffe(_f26942ec9f35._c74cdb9b9845, "module"):
            _b4036a3cf335 = _f26942ec9f35._c74cdb9b9845._5e7acee188d8
            _32c635a5252e = _f26942ec9f35._c74cdb9b9845
        else:
            _b4036a3cf335 = _f26942ec9f35
            _32c635a5252e = _8ac857bb9f17

        _604fcf38ac61 = _cc9175c1ea71()
        _604fcf38ac61._e6ca090f4d32 = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

        _899bf2df3673 = 0
        _e74ab7a433be = 0
        _35f4b9b8341f = 0
        _1b425526886f = _1e3e5c27c705()

        def _f33d0e931cef(_5e7acee188d8):
            _ecd7b395630f = _f931a3596410(_5e7acee188d8._14532f5dcd15())
            _a98648a6d1d7 = [_b5d17ffc26c3 for _b5d17ffc26c3 in _ecd7b395630f if _2a36372abb6c(_b5d17ffc26c3) not in _1b425526886f]
            _1b425526886f._df159b7e0efd(_2a36372abb6c(_b5d17ffc26c3) for _b5d17ffc26c3 in _a98648a6d1d7)

            _1e56aa832c86 = _a9b63a5774d2(_b5d17ffc26c3._7f76bd0ec848() for _b5d17ffc26c3 in _a98648a6d1d7)
            _fc7e1826162f = _a9b63a5774d2(_b5d17ffc26c3._7f76bd0ec848() for _b5d17ffc26c3 in _a98648a6d1d7 if _b5d17ffc26c3._17ae2ff70bff)
            _5f92b75b043b = _1e56aa832c86 - _fc7e1826162f
            return _1e56aa832c86, _fc7e1826162f, _5f92b75b043b

        for _ff01cdda0fc2, _5e7acee188d8 in _b4036a3cf335._51fd0d304324():
            # Skip root module or modules deeper than `depth`
            if _ff01cdda0fc2 == "" or _ff01cdda0fc2._ddee4b7f82c4(".") >= _a8cb5b09749a:
                continue
            if _0605d5cb017a(_e1b0a1675425 in _ff01cdda0fc2 for _e1b0a1675425 in _0cf954ec0cca):
                continue

            _7db394b7ec8f, _cd9221eb1f8e, _89346a5f8e3d = _80c8ea524200(_5e7acee188d8)
            if _7db394b7ec8f > 0:
                _604fcf38ac61._88de27045b4e(
                    [
                        _ff01cdda0fc2,
                        _5e7acee188d8._a6726aa93d58.__name__,
                        f"{_7db394b7ec8f:,}",
                        f"{_cd9221eb1f8e:,}",
                        f"{_89346a5f8e3d:,}",
                    ]
                )
                _899bf2df3673 += _7db394b7ec8f
                _e74ab7a433be += _cd9221eb1f8e
                _35f4b9b8341f += _89346a5f8e3d

        # Full model size (unsharded) in GB
        _c8fe12c10f88 = self._d3be23904e8e(_b4036a3cf335)

        # Obtain shard param count from FSDP internals if available
        _b3cb28695f7c = _8ac857bb9f17
        if _32c635a5252e is not _8ac857bb9f17:
            if _23625e222ffe(_32c635a5252e, "_fsdp_flat_param") and _32c635a5252e._d62bcb15f0f1 is not _8ac857bb9f17:
                _b3cb28695f7c = _32c635a5252e._d62bcb15f0f1._7f76bd0ec848()
            elif _23625e222ffe(_32c635a5252e, "_flat_param") and _32c635a5252e._aa9760066254 is not _8ac857bb9f17:
                _b3cb28695f7c = _32c635a5252e._aa9760066254._7f76bd0ec848()

        # Determine device/strategy and estimated shard size
        _95af14312f56 = _b0b8b5c7a25d(_ae5460011e64, "strategy", _8ac857bb9f17)
        _658a0636811c = _b0b8b5c7a25d(_ae5460011e64, "num_devices", _02127ade5a57._c57d947f441c._3bd89314a486())
        _6d3808ed0581 = _4cce2f6c3bba(_95af14312f56)._63ccc365233e() if _95af14312f56 else ""
        _a9c51632b99e = "fsdp" in _6d3808ed0581
        _7fd39c8d0282 = "ddp" in _6d3808ed0581

        if _a9c51632b99e and _658a0636811c > 0:
            _b4591f78e3f5 = _c8fe12c10f88 / _658a0636811c
        else:
            _b4591f78e3f5 = _c8fe12c10f88

        # Format sizes for display
        _1dcd42c233ed = _c8fe12c10f88 * 1024
        _8d4c251a1a9d = f"{_c8fe12c10f88:.2f} GB" if _c8fe12c10f88 >= 1 else f"{_1dcd42c233ed:.2f} MB"
        _a14b8220396d = (
            f"{_b4591f78e3f5:.2f} GB" if _b4591f78e3f5 >= 1 else f"{_b4591f78e3f5 * 1024:.2f} MB"
        )

        _9d2860472484 = _cc9175c1ea71()
        _9d2860472484._e6ca090f4d32 = ["Metric", "Value"]
        _9d2860472484._88de27045b4e(["Total params (full model)", f"{_899bf2df3673:,}"])
        _9d2860472484._88de27045b4e(["Trainable params", f"{_e74ab7a433be:,}"])
        _9d2860472484._88de27045b4e(["Non-trainable params", f"{_35f4b9b8341f:,}"])
        _9d2860472484._88de27045b4e(["Full model size (unsharded)", _8d4c251a1a9d])

        if _b3cb28695f7c is not _8ac857bb9f17:
            _9d2860472484._88de27045b4e(["Actual per-device shard params (FSDP)", f"{_b3cb28695f7c:,}"])

        if _a9c51632b99e:
            _9d2860472484._88de27045b4e([f"Estimated per-device shard size (FSDP x{_658a0636811c})", _a14b8220396d])
        elif _7fd39c8d0282:
            _9d2860472484._88de27045b4e([f"Per-device copy size (DDP x{_658a0636811c})", _8d4c251a1a9d])
        else:
            _9d2860472484._88de27045b4e(["Parallel strategy", "Single-device or unknown"])

        _c525e6a3cf0e = f"\n{_604fcf38ac61}\n\n{_9d2860472484}\n"
        return _c525e6a3cf0e

    def _509be113a813(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _35d0e6c70220: _e747e8cdc0fc._4191bdd15323) -> _8ac857bb9f17:
        """
        Called when fitting begins. Records training start time and logs a model summary.
        If the model has no trainable parameters, sets trainer.should_stop to True to avoid wasted compute.
        """
        _aef1ebfb98fa = self._e68129aa225c._8d8db997bc3d()
        _039333590f8e = self._e68129aa225c._f2a4292dcf4c()
        self._165dc91e6a23._c16b58d80752("Model Training started at {}"._37be876dd235(_039333590f8e))

        if _ae5460011e64._6edf6878bfa4 == 0:
            self._6fd455540ba5 = _ae5460011e64._b96aa61d359e
            self._0914ba0899f8["training_start_time"] = _aef1ebfb98fa
            self._0914ba0899f8["training_start_date_time"] = _039333590f8e

        # Print model summary (filtered)
        _4be419c129d0 = self._381bb235ec9f._af473d015c9d(_ae5460011e64, _35d0e6c70220)
        _4be419c129d0 = self._3027627c85df(_ae5460011e64)
        self._165dc91e6a23._c16b58d80752(f"Model Training Parameters Summary on Rank {_ae5460011e64._6edf6878bfa4} \n{_4be419c129d0}")

        # If no trainable params, skip training gracefully
        _741e7e94ea20 = _0605d5cb017a(_b5d17ffc26c3._17ae2ff70bff for _b5d17ffc26c3 in _ae5460011e64._f26942ec9f35._14532f5dcd15())
        if not _741e7e94ea20:
            self._165dc91e6a23._c16b58d80752("No trainable parameters found. Skipping training...")
            _ae5460011e64._bf43d090896d = _c2aa451d0f43

    @_c8a1149f3829
    def _27853a74975e(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _35d0e6c70220: _e747e8cdc0fc._4191bdd15323) -> _8ac857bb9f17:
        """
        Called at the start of testing. Logs a model summary for easier debugging.
        """
        _4be419c129d0 = self._381bb235ec9f._af473d015c9d(_ae5460011e64, _35d0e6c70220)
        _4be419c129d0 = self._3027627c85df(_ae5460011e64)
        self._165dc91e6a23._c16b58d80752("Model Training Parameters Summary \n{}"._37be876dd235(_4be419c129d0))

    @_c8a1149f3829
    def _9d7aceb82ee7(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _35d0e6c70220: _e747e8cdc0fc._4191bdd15323, _081b1cced9ed: _875659be53a6) -> _8ac857bb9f17:
        """
        Called when an exception bubbles up during training. Log final training info to disk for debugging.
        """
        self._b87095c55a3f(_ae5460011e64=_ae5460011e64, _35d0e6c70220=_35d0e6c70220, _0d5e2e289780="Abnormal Termination due to Exception or an explicit interruption in program")

    @_c8a1149f3829
    def _931f6088b844(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _35d0e6c70220: _e747e8cdc0fc._4191bdd15323) -> _8ac857bb9f17:
        """
        Called at normal completion of training. Finalizes and writes summary metrics.
        """
        self._165dc91e6a23._c16b58d80752(f"After Fit Model Summary")
        self._b87095c55a3f(_ae5460011e64, _35d0e6c70220, _0d5e2e289780="Training Completed Normally ")

    def _1f2936bc77b2(self, _ae5460011e64: _e747e8cdc0fc._6748e9ac981f, _35d0e6c70220: _e747e8cdc0fc._4191bdd15323, _0d5e2e289780: _4cce2f6c3bba) -> _8ac857bb9f17:
        """
        Internal helper to persist final training summary information and write the metrics summary CSV.

        This aggregates start/end times, computes elapsed training time, persists summary to disk,
        and logs the same model summary computed earlier.
        """
        if self._6493015466ad:
            self._0914ba0899f8["trial_number"] = self._6493015466ad._78fe456b7285

        # Populate start_epoch if missing
        if self._45e0dce1f4e5 is _8ac857bb9f17:
            try:
                self._0914ba0899f8["start_epoch"] = _157786be5058(_ae5460011e64._127f972a1ab7)
            except _ba4e4ffc71a7:
                self._0914ba0899f8["start_epoch"] = 0.0

        # Determine end epoch (favor callback metrics if present)
        _8150946c545b = _ae5460011e64._b96aa61d359e._7dcc8d9b957e("epoch", _ae5460011e64._127f972a1ab7) if _2df19dfc5069(_ae5460011e64._b96aa61d359e, _ed97d3aa470e) else _ae5460011e64._127f972a1ab7
        if _2df19dfc5069(_8150946c545b, _02127ade5a57._30928346e270):
            _5777aec5e7ac = _157786be5058(_8150946c545b._e60e94822363())
        else:
            try:
                _5777aec5e7ac = _157786be5058(_8150946c545b)
            except _ba4e4ffc71a7:
                _5777aec5e7ac = _157786be5058(_ae5460011e64._127f972a1ab7)
        self._0914ba0899f8["end_epoch"] = _5777aec5e7ac

        _f04bc6d2fe0f = self._e68129aa225c._8d8db997bc3d()
        self._0914ba0899f8["training_end_time"] = _f04bc6d2fe0f
        _fdced97bfd0d = self._e68129aa225c._f2a4292dcf4c()
        self._165dc91e6a23._c16b58d80752("Training completed at {}"._37be876dd235(_fdced97bfd0d))
        self._0914ba0899f8["training_end_date_time"] = _fdced97bfd0d

        # compute model training time safely
        _91d2fd2262d9 = _f04bc6d2fe0f - self._0914ba0899f8._7dcc8d9b957e("training_start_time", _f04bc6d2fe0f)
        self._0914ba0899f8["model_training_time"] = _91d2fd2262d9
        self._0914ba0899f8["model_training_time_details"] = "{} hours {} minutes {} seconds"._37be876dd235(
            *self._e68129aa225c._96f15b5614fa(_91d2fd2262d9)
        )

        # Mark training status in summary
        if _ae5460011e64._bf43d090896d:
            _0d5e2e289780 += " Early Stopping Implemented."
        self._0914ba0899f8["model_training_status"] = _0d5e2e289780

        # Ensure metrics_dir exists and write summary CSV
        if not os._30207762628c._b5ee101c8e02(self._e616b6cf34cb):
            os._2c3ada526f7e(self._e616b6cf34cb, _1b58324387ac=_c2aa451d0f43)

        _4c2b5357ed1e = os._30207762628c._4a2d40afe6fb(self._e616b6cf34cb, self._837cb3233f48)
        try:
            with _1ddeb73cd14d(_4c2b5357ed1e, "a+", _888771c5daf8="utf8") as _367b9d7ba94e:
                _5504d1b37531 = _d823f7120295._8320c4a4b3d7(_367b9d7ba94e, _8fa283a93a50=self._0914ba0899f8._6198a9546166())
                if os._30207762628c._ac19c14f3798(_4c2b5357ed1e) == 0:
                    _5504d1b37531._41c244f4ffad()
                _5504d1b37531._2d17227de6a1([self._0914ba0899f8])
        except _ba4e4ffc71a7 as _02e7cfa76e4b:
            self._165dc91e6a23._b51722b39577("Failed to write training summary CSV: %s", _02e7cfa76e4b)
            raise _be80e8a4e2a4("Failed to write training summary CSV.") from _02e7cfa76e4b

        # Final model summary log
        _4be419c129d0 = self._381bb235ec9f._af473d015c9d(_ae5460011e64, _35d0e6c70220)
        _4be419c129d0 = self._3027627c85df(_ae5460011e64)
        self._165dc91e6a23._c16b58d80752(f"Model Training Parameters Summary on Rank {_ae5460011e64._6edf6878bfa4} \n{_4be419c129d0}")
