# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : custom_log_callback.py
# @Time             : 2025-10-23 13:45 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _159bc7538460
from _e91d8b6a20b4 import _112123ba69df, _7b16f63fb85a
import os._9922d25998a5
import _0d184c5ad2fd
import _a3101519f834 as _cbc34a4d6f59
from _8a1a6659fa4b import _89071af83931
import _56497f1fb8d7
from _56497f1fb8d7._5acc225ae595._1cb526ddbbde import _ac8522ce1d96 as _6cc85019e021
from _56497f1fb8d7._5acc225ae595._1cb526ddbbde._063b372752f7 import _516d69167d19
from _2c77a4100bba._caeba4f4c2bc._f5ecf2149529 import _dc8b1489507c as _2cb859a8da88
import _24e3e79fb20f as _b725764385e2
from _24e3e79fb20f._5b6a0543cc1b._e9becf7b42af._35f97597e6e8 import _2e64de2ddaca
from _24e3e79fb20f._5b6a0543cc1b._2af1c1161baf import _bd9051bf40b6
import _1c69214bb7d7
from typing import _2f0acba1a78d, _3f96a7e52994, _8af163942ec3


class _9c1c5604ec17(_b725764385e2._32d09e80055c):
    """
    Callback that centralizes logging and metrics summary creation for training runs.

    Purpose
    -------
    - Log environment and trainer startup information.
    - Persist per-epoch metric rows to CSV (human-readable, deterministic formatting).
    - Produce a concise model summary table with parameter counts and estimated shard sizes
      for FSDP/DDP scenarios.
    - Emit informational messages on fit/test lifecycle events and on exceptions.

    Design goals
    ------------
    - Fail early for clearly invalid initialization inputs.
    - Keep all runtime behaviors unchanged from original implementation (no algorithmic changes).
    - Use `rank_zero_only` for actions that should only run on the primary process.
    - Provide clear docstrings and explicit `RuntimeError` on invalid usage.

    Parameters
    ----------
    log : logging.Logger
        Logger instance used for writing human-readable logs.
    model_summary_callback : object
        Object providing `_summary(trainer, pl_module)` (used to obtain model summary text).
    metrics_summary_dict : dict
        Mutable dictionary which will be updated with run-level summary metrics (start/end times, trial).
    metrics_dir : str
        Directory where per-epoch metrics CSV and summary file will be written.
    model_epoch_metrics_file : str
        Filename for per-epoch metrics CSV (written inside metrics_dir).
    model_metrics_summary_file : str
        Filename for aggregated model metrics summary CSV (written inside metrics_dir).
    random_seed : int, optional
        RNG seed used to produce reproducible logging and rounding behavior (default: 20).
    trial : optuna.trial.Trial, optional
        Optional Optuna trial object; if given, `trial.number` will be recorded in summary.

    Raises
    ------
    RuntimeError
        If required arguments are missing or invalid (e.g., `log` is None or metrics paths are invalid).
    """

    def _4a15d7e76069(
        self,
        _810492f8b71b,
        _2f2c51e77eee,
        _f957769b1243: _3f96a7e52994[_468b6bd71a4f, _8af163942ec3],
        _16d1f5f493be: _468b6bd71a4f,
        _55ee9517fe58: _468b6bd71a4f,
        _8f61032b25c2: _468b6bd71a4f,
        _7ee6723bdc3d: _917bab15bd12 = 20,
        _24cbd9315dc4: _2f0acba1a78d[_1c69214bb7d7._24cbd9315dc4._01cd6a894801] = _3bc71047e9cc,
    ):
        # Validate required constructor arguments to fail fast and loudly
        if _810492f8b71b is _3bc71047e9cc:
            raise _9158186a8282("LoggingCallback requires a logger instance (log).")
        if _2f2c51e77eee is _3bc71047e9cc:
            raise _9158186a8282("LoggingCallback requires a model_summary_callback object providing _summary().")
        if _f957769b1243 is _3bc71047e9cc or not _28e6fe633c17(_f957769b1243, _338f08b848b6):
            raise _9158186a8282("metrics_summary_dict must be a dict to collect run-level metrics.")
        if not _28e6fe633c17(_55ee9517fe58, _468b6bd71a4f) or not _55ee9517fe58:
            raise _9158186a8282("model_epoch_metrics_file must be a non-empty filename string.")
        if not _28e6fe633c17(_8f61032b25c2, _468b6bd71a4f) or not _8f61032b25c2:
            raise _9158186a8282("model_metrics_summary_file must be a non-empty filename string.")
        if not _28e6fe633c17(_16d1f5f493be, _468b6bd71a4f) or not _16d1f5f493be:
            raise _9158186a8282("metrics_dir must be a non-empty directory path string.")

        # Store validated inputs
        self._31d03b93ea2f: _2f0acba1a78d[_3f96a7e52994[_468b6bd71a4f, _8af163942ec3]] = _3bc71047e9cc
        self._d7f2f3066165 = _810492f8b71b
        self._24cbd9315dc4 = _24cbd9315dc4
        self._2f2c51e77eee = _2f2c51e77eee
        self._55ee9517fe58 = _55ee9517fe58
        self._16d1f5f493be = _16d1f5f493be
        self._8f61032b25c2 = _8f61032b25c2
        self._f957769b1243 = _f957769b1243
        self._cb9d9ef8543a: _2f0acba1a78d[_cda3a8af2cc7] = _3bc71047e9cc
        self._2cb859a8da88 = _2cb859a8da88._daab2fb7de05()
        self._d1c71d69ab07 = []
        self._07131dac59d7 = _4704c510883a
        self._7ee6723bdc3d = _917bab15bd12(_7ee6723bdc3d)

        # Seed deterministically for reproducible logging behavior where relevant.
        _b725764385e2._b4661dd9a67f(self._7ee6723bdc3d, _0f5c38d84e72=_bc8f80d2cb4f)
        _56497f1fb8d7._92f6a763f1d7(self._7ee6723bdc3d)
        if _56497f1fb8d7._2834bbd0a20d._53800a5221f4():
            _56497f1fb8d7._2834bbd0a20d._424332cddc02(self._7ee6723bdc3d)

    def _6d1bd9adb028(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _d49f62427826: _b725764385e2._b1c4a9378c9b) -> _3bc71047e9cc:
        """
        Called once at the beginning of training. Logs environment information such as GPU model,
        world size and rank, and dataset sampling summary for distributed runs.
        """
        _43b7a6af6bc1 = ""
        if _56497f1fb8d7._2834bbd0a20d._53800a5221f4():
            try:
                # Lazy import for NVML to avoid failing when not available
                from _0e364a288173 import _dc3b0bb661db, _73c21811d826, _20974277a3aa

                _dc3b0bb661db()
                _6795d6a30638 = _20974277a3aa(_73c21811d826(_be8916c2db0b._8b960b243470))._c9cb15ccb084("utf-8")
            except _84b137df1964:
                # fallback to a hostname-only message if NVML is not available
                _6795d6a30638 = "unknown-gpu"

            _43b7a6af6bc1 += "World Size {} Global Rank {} Local Rank {}\n"._397a8545f757(
                _be8916c2db0b._97d8d95740b1, _be8916c2db0b._c4732104d7d5, _be8916c2db0b._8b960b243470
            )
            _43b7a6af6bc1 += "Running on {} with {}\n"._397a8545f757(_0d184c5ad2fd._948f6c2c6a60(), _6795d6a30638)

            # If not single-device strategy, attempt to report sampler info
            if not _28e6fe633c17(_be8916c2db0b._7ab2fd8b9ca3, _bd9051bf40b6):
                # Obtain train_dataset in a manner that works whether dataloader or datamodule is used
                _20499ad06535 = _b235601b7542(_be8916c2db0b._95e63ed8577c, "train_dataset", _3bc71047e9cc) or _b235601b7542(
                    _be8916c2db0b._95e63ed8577c._307d4209fb82(), "dataset", _3bc71047e9cc
                )
                if _28e6fe633c17(_20499ad06535, _56497f1fb8d7._f5ecf2149529._574cb669a232._e68cc2f49ff5):
                    _43b7a6af6bc1 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._397a8545f757(
                        _5773333e882d(_be8916c2db0b._307d4209fb82._678887949169),
                        _b235601b7542(_20499ad06535, "num_samples", "unknown"),
                        _b235601b7542(_20499ad06535, "total_size", "unknown"),
                    )
                elif _28e6fe633c17(_20499ad06535, _56497f1fb8d7._f5ecf2149529._574cb669a232._eba757fd5a04):
                    # sampler attributes expected by CustomGroupBySampleDistributedSampler
                    _678887949169 = _b235601b7542(_be8916c2db0b._307d4209fb82, "sampler", _3bc71047e9cc)
                    _f4fcde2ccfcb = _b235601b7542(_678887949169, "num_samples", "unknown")
                    _42767d767185 = _b235601b7542(_678887949169, "total_size", "unknown")
                    _43b7a6af6bc1 += "Sampler :: {} created {} number of training samples on node out of {} total samples \n"._397a8545f757(
                        _5773333e882d(_678887949169), _f4fcde2ccfcb, _42767d767185
                    )
        else:
            _43b7a6af6bc1 += "No GPU available using cpu as accelerator\n"

        self._d7f2f3066165._7aba0e9e57e6(_43b7a6af6bc1)

    def _3a86f0ec4430(self, _9da5437e006c: _cda3a8af2cc7, _2daad13baac3: _917bab15bd12 = 3) -> _cda3a8af2cc7:
        """
        Deterministically round a float using Decimal with ROUND_HALF_UP semantics.

        Parameters
        ----------
        val : float
            Value to round.
        precision : int
            Number of decimal places.

        Returns
        -------
        float
            Rounded float.
        """
        return _cda3a8af2cc7(_7b16f63fb85a(_468b6bd71a4f(_9da5437e006c))._60ad571b0945(_7b16f63fb85a(f'1.{"0"*_2daad13baac3}'), _88e3dc111734=_112123ba69df))

    @_2e64de2ddaca
    def _fb72e63d1520(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _d49f62427826: _b725764385e2._b1c4a9378c9b) -> _3bc71047e9cc:
        """
        At the end of each training epoch, capture metrics from the trainer, sanitize them,
        and append a row to the epoch metrics CSV. Also logs summary messages and LR info.

        Behavior
        --------
        - Writes a CSV line to `metrics_dir/model_epoch_metrics_file`.
        - Updates `metrics_summary_dict` start_epoch if not previously set.
        - Formats lambda values to two decimal string for consistent CSV representation.

        Exceptions
        ----------
        Raises RuntimeError if writing to the metrics CSV fails due to I/O errors.
        """
        self._31d03b93ea2f = _be8916c2db0b._6e83d8df7334

        # Establish start epoch once
        if self._cb9d9ef8543a is _3bc71047e9cc:
            try:
                _cb9d9ef8543a = _cda3a8af2cc7(self._31d03b93ea2f['epoch']._bc68f423503a())
            except _84b137df1964:
                _cb9d9ef8543a = _cda3a8af2cc7(_be8916c2db0b._307658b864df)
            self._f957769b1243['start_epoch'] = _cb9d9ef8543a
            self._cb9d9ef8543a = _cb9d9ef8543a

        # Build a sanitized metrics dict for CSV writing and logging
        _1dafc30d5fb0 = ""
        _333f96f50d07: _3f96a7e52994[_468b6bd71a4f, _8af163942ec3] = {}
        for _35e13387e289 in _0c45f1c2b971(self._31d03b93ea2f):
            _b3653d846840 = self._31d03b93ea2f[_35e13387e289]._bc68f423503a() if _32eb38e36e0f(self._31d03b93ea2f[_35e13387e289], "item") else self._31d03b93ea2f[_35e13387e289]

            # If the metric key contains greek letter lambda 'λ' prefer fixed rounding for readability
            if "λ" in _35e13387e289:
                try:
                    _9da5437e006c = self._3fbc29dbcb93(_9da5437e006c=_cda3a8af2cc7(_b3653d846840), _2daad13baac3=3)
                except _84b137df1964:
                    _9da5437e006c = _b3653d846840
            else:
                _9da5437e006c = _b3653d846840

            _1dafc30d5fb0 += f" {_35e13387e289}:{_9da5437e006c},"
            _333f96f50d07[_35e13387e289] = _9da5437e006c

        self._d7f2f3066165._7aba0e9e57e6(_1dafc30d5fb0)

        # Ensure metrics directory exists (distributed-safe exists_ok)
        if not os._9922d25998a5._c1442bbbc66e(self._16d1f5f493be):
            os._2b76a1e7e880(self._16d1f5f493be, _ddb03d3d8c1d=_bc8f80d2cb4f)

        _40265ee1e8f3 = os._9922d25998a5._a992d7310e98(self._16d1f5f493be, self._55ee9517fe58)

        # Helper: coerce torch/np scalars to python floats
        def _4a1c41296664(_f4d026abacfb):
            if _28e6fe633c17(_f4d026abacfb, _56497f1fb8d7._117c8808ac37):
                return _cda3a8af2cc7(_f4d026abacfb._fa5a7d7f3e92()._f25261b2143e()._bc68f423503a())
            if _28e6fe633c17(_f4d026abacfb, (_cbc34a4d6f59._03334be37fdb,)):
                return _cda3a8af2cc7(_cbc34a4d6f59._42e0b36a70d0(_f4d026abacfb))
            return _cda3a8af2cc7(_f4d026abacfb)

        # For any lambda-like keys, store as fixed two-decimal strings for consistent CSV formatting
        for _5aa84a9e0051 in _2b9a9dde495a(_333f96f50d07._6be274bdb73a()):
            if "lambda" in _5aa84a9e0051._cbe4ded1cc2b() or "λ" in _5aa84a9e0051:
                _55b19c8ee185 = _333f96f50d07[_5aa84a9e0051]
                try:
                    _163d19e524ef = _a6a94780d20b(_55b19c8ee185)
                except _84b137df1964:
                    continue
                _333f96f50d07[_5aa84a9e0051] = f"{_163d19e524ef:.2f}"

        # Write CSV row; raise if any I/O error occurs so the caller can handle it explicitly
        try:
            with _6e8c730bf268(_40265ee1e8f3, "a+", _70f9d09eb0ff="utf8", _d494da5192e7="") as _74b3c3c90344:
                _fea9de8feebb = _159bc7538460._97ffaeb12d73(_74b3c3c90344, _eac4d7cf9818=_333f96f50d07._6be274bdb73a())
                if os._9922d25998a5._93fdfc9748e2(_40265ee1e8f3) == 0:
                    _fea9de8feebb._3faa824041c4()
                _fea9de8feebb._bff05e7847b0([_333f96f50d07])
        except _84b137df1964 as _96a7c7fd944a:
            self._d7f2f3066165._a64b89cd8c6e("Failed to write epoch metrics CSV: %s", _96a7c7fd944a)
            raise _9158186a8282("Failed to write epoch metrics CSV.") from _96a7c7fd944a

        # Informational logs for early stopping and learning rate info
        if _be8916c2db0b._d2ab006636c0:
            self._d7f2f3066165._7aba0e9e57e6("Early stopping activated.")

        for _63af6763212e in _be8916c2db0b._651f45cab965:
            for _d2f3e9b66136 in _63af6763212e._c20736f534fe:
                _ed25351fde03 = _d2f3e9b66136._ab7815c6be52("lr", _3bc71047e9cc)
                self._d7f2f3066165._7aba0e9e57e6(f"Current learning rate: {_ed25351fde03}")

    def _a9ad44039c1d(self, _5df88267b755: _56497f1fb8d7._e7f87f0578b0._a9fadd57f4f6) -> _cda3a8af2cc7:
        """
        Calculate the approximate size of the model in GB by summing unique parameter storage.

        Notes
        -----
        - When model is wrapped by FSDP and not in IDLE state, skip to avoid accessing FSDP internals unsafely.
        - Avoid double-counting shared parameter objects by tracking `id(param)`.

        Returns
        -------
        float
            Total model size in GiB (approximate).
        """
        # Avoid inspecting FSDP internals during non-idle training state
        if _28e6fe633c17(_5df88267b755, _6cc85019e021) and _b235601b7542(_5df88267b755, "training_state", _3bc71047e9cc) != _516d69167d19._9e9f151db7b6:
            # Skipping is safe: caller expects a float; return 0 to indicate "unknown/skipped"
            _8e13e1f76281("Skipping model size calculation: FSDP model is not in IDLE state.")
            return 0.0

        _788fcfcb91b4 = 0  # in bytes
        _7411de9a3d56 = _47008b509896()

        def _a2f10050f858(_bb87148d9622):
            nonlocal _788fcfcb91b4
            for _f1d3ebffcec7 in _bb87148d9622._5d66dc9b0c71(_03760e3c5327=_4704c510883a):
                _7b2fdfae44d1 = _14f87aea46c1(_f1d3ebffcec7)
                if _7b2fdfae44d1 not in _7411de9a3d56:
                    _081d002c871e = _f1d3ebffcec7._ee4a6b1e496a()
                    _788fcfcb91b4 += _f1d3ebffcec7._aac6721e2baa() * _081d002c871e
                    _7411de9a3d56._a3ed52ef86f6(_7b2fdfae44d1)

        _5df88267b755._cf736857f936(lambda _86adf1b6d651: _8175601ceb1c(_86adf1b6d651))
        _767087febaf0 = _788fcfcb91b4 / (1024 ** 3)
        return _767087febaf0

    def _23421d4da236(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _492578b93960: _917bab15bd12 = 1, _40ba122a0a07=_3bc71047e9cc) -> _468b6bd71a4f:
        """
        Produce a concise table-based model summary (layer name, type, params, trainable/non-trainable)
        and a small metrics table describing full model size vs shard estimates.

        Parameters
        ----------
        trainer : pl.Trainer
            Trainer used to determine strategy and unwrap FSDP if present.
        depth : int
            Depth of module naming to display; modules whose dotted name has depth >= this will be skipped.
        exclude : list[str] or None
            List of substrings; if a module's name contains any exclude token it will not be shown.

        Returns
        -------
        str
            Human-readable summary string including a PrettyTable of layers and summary metrics.
        """
        if _40ba122a0a07 is _3bc71047e9cc:
            _40ba122a0a07 = ["_accuracy", "_precision", "_recall", "_f1", "_criterion"]

        _5df88267b755 = _be8916c2db0b._5df88267b755

        # Attempt to unwrap an FSDP-wrapped core module for meaningful inspection
        if _32eb38e36e0f(_5df88267b755, "_fsdp_wrapped_module") and _32eb38e36e0f(_5df88267b755._ce69ad80c4ba, "module"):
            _96221f9362f6 = _5df88267b755._ce69ad80c4ba._bb87148d9622
            _525ae4213961 = _5df88267b755._ce69ad80c4ba
        else:
            _96221f9362f6 = _5df88267b755
            _525ae4213961 = _3bc71047e9cc

        _1b7c6728781a = _89071af83931()
        _1b7c6728781a._a026520f4351 = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

        _4a1ffbd5855d = 0
        _2a4c11cf0304 = 0
        _de2bdca71fa7 = 0
        _0ea9943ca5f5 = _47008b509896()

        def _eedb23875aee(_bb87148d9622):
            _8800b139b99c = _2b9a9dde495a(_bb87148d9622._5d66dc9b0c71())
            _9d6740c16bf3 = [_653f4760019d for _653f4760019d in _8800b139b99c if _14f87aea46c1(_653f4760019d) not in _0ea9943ca5f5]
            _0ea9943ca5f5._c06e2906f881(_14f87aea46c1(_653f4760019d) for _653f4760019d in _9d6740c16bf3)

            _eecfcee3138c = _a864e4073e1e(_653f4760019d._aac6721e2baa() for _653f4760019d in _9d6740c16bf3)
            _2e75be283511 = _a864e4073e1e(_653f4760019d._aac6721e2baa() for _653f4760019d in _9d6740c16bf3 if _653f4760019d._99a5229605bb)
            _db884a2ca378 = _eecfcee3138c - _2e75be283511
            return _eecfcee3138c, _2e75be283511, _db884a2ca378

        for _08e8ecf71605, _bb87148d9622 in _96221f9362f6._6385debbd2ba():
            # Skip root module or modules deeper than `depth`
            if _08e8ecf71605 == "" or _08e8ecf71605._25750fdaecda(".") >= _492578b93960:
                continue
            if _5c54924e0e4c(_205199d84450 in _08e8ecf71605 for _205199d84450 in _40ba122a0a07):
                continue

            _2f48492d83a5, _6bf1a50425a8, _2841ce63fd40 = _51588ddeacb1(_bb87148d9622)
            if _2f48492d83a5 > 0:
                _1b7c6728781a._8cba790e7647(
                    [
                        _08e8ecf71605,
                        _bb87148d9622._ce82deaca0b1.__name__,
                        f"{_2f48492d83a5:,}",
                        f"{_6bf1a50425a8:,}",
                        f"{_2841ce63fd40:,}",
                    ]
                )
                _4a1ffbd5855d += _2f48492d83a5
                _2a4c11cf0304 += _6bf1a50425a8
                _de2bdca71fa7 += _2841ce63fd40

        # Full model size (unsharded) in GB
        _d84b485bb77e = self._65ead11c4623(_96221f9362f6)

        # Obtain shard param count from FSDP internals if available
        _ab8b82ecd093 = _3bc71047e9cc
        if _525ae4213961 is not _3bc71047e9cc:
            if _32eb38e36e0f(_525ae4213961, "_fsdp_flat_param") and _525ae4213961._9169a3889a2b is not _3bc71047e9cc:
                _ab8b82ecd093 = _525ae4213961._9169a3889a2b._aac6721e2baa()
            elif _32eb38e36e0f(_525ae4213961, "_flat_param") and _525ae4213961._e77987b5b3ec is not _3bc71047e9cc:
                _ab8b82ecd093 = _525ae4213961._e77987b5b3ec._aac6721e2baa()

        # Determine device/strategy and estimated shard size
        _7ab2fd8b9ca3 = _b235601b7542(_be8916c2db0b, "strategy", _3bc71047e9cc)
        _cb31fdf5f0a6 = _b235601b7542(_be8916c2db0b, "num_devices", _56497f1fb8d7._2834bbd0a20d._dcce49147dbd())
        _8749058ca5a0 = _468b6bd71a4f(_7ab2fd8b9ca3)._cbe4ded1cc2b() if _7ab2fd8b9ca3 else ""
        _bc0442461dfc = "fsdp" in _8749058ca5a0
        _9027b801d0c0 = "ddp" in _8749058ca5a0

        if _bc0442461dfc and _cb31fdf5f0a6 > 0:
            _9da8af45d49d = _d84b485bb77e / _cb31fdf5f0a6
        else:
            _9da8af45d49d = _d84b485bb77e

        # Format sizes for display
        _becccf919b30 = _d84b485bb77e * 1024
        _1bb9136a2fff = f"{_d84b485bb77e:.2f} GB" if _d84b485bb77e >= 1 else f"{_becccf919b30:.2f} MB"
        _c40cae2009cf = (
            f"{_9da8af45d49d:.2f} GB" if _9da8af45d49d >= 1 else f"{_9da8af45d49d * 1024:.2f} MB"
        )

        _531d04a07585 = _89071af83931()
        _531d04a07585._a026520f4351 = ["Metric", "Value"]
        _531d04a07585._8cba790e7647(["Total params (full model)", f"{_4a1ffbd5855d:,}"])
        _531d04a07585._8cba790e7647(["Trainable params", f"{_2a4c11cf0304:,}"])
        _531d04a07585._8cba790e7647(["Non-trainable params", f"{_de2bdca71fa7:,}"])
        _531d04a07585._8cba790e7647(["Full model size (unsharded)", _1bb9136a2fff])

        if _ab8b82ecd093 is not _3bc71047e9cc:
            _531d04a07585._8cba790e7647(["Actual per-device shard params (FSDP)", f"{_ab8b82ecd093:,}"])

        if _bc0442461dfc:
            _531d04a07585._8cba790e7647([f"Estimated per-device shard size (FSDP x{_cb31fdf5f0a6})", _c40cae2009cf])
        elif _9027b801d0c0:
            _531d04a07585._8cba790e7647([f"Per-device copy size (DDP x{_cb31fdf5f0a6})", _1bb9136a2fff])
        else:
            _531d04a07585._8cba790e7647(["Parallel strategy", "Single-device or unknown"])

        _da4d1cc6a7fe = f"\n{_1b7c6728781a}\n\n{_531d04a07585}\n"
        return _da4d1cc6a7fe

    def _145dd55dc400(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _d49f62427826: _b725764385e2._b1c4a9378c9b) -> _3bc71047e9cc:
        """
        Called when fitting begins. Records training start time and logs a model summary.
        If the model has no trainable parameters, sets trainer.should_stop to True to avoid wasted compute.
        """
        _65cd04d1aabb = self._2cb859a8da88._5b1426ef4907()
        _e92c96fc0e26 = self._2cb859a8da88._ef451326c427()
        self._d7f2f3066165._7aba0e9e57e6("Model Training started at {}"._397a8545f757(_e92c96fc0e26))

        if _be8916c2db0b._c4732104d7d5 == 0:
            self._31d03b93ea2f = _be8916c2db0b._6e83d8df7334
            self._f957769b1243["training_start_time"] = _65cd04d1aabb
            self._f957769b1243["training_start_date_time"] = _e92c96fc0e26

        # Print model summary (filtered)
        _8d40aea4f337 = self._2f2c51e77eee._136eff5a08a5(_be8916c2db0b, _d49f62427826)
        _8d40aea4f337 = self._559d9c54dd5f(_be8916c2db0b)
        self._d7f2f3066165._7aba0e9e57e6(f"Model Training Parameters Summary on Rank {_be8916c2db0b._c4732104d7d5} \n{_8d40aea4f337}")

        # If no trainable params, skip training gracefully
        _ab5f59c02ffb = _5c54924e0e4c(_653f4760019d._99a5229605bb for _653f4760019d in _be8916c2db0b._5df88267b755._5d66dc9b0c71())
        if not _ab5f59c02ffb:
            self._d7f2f3066165._7aba0e9e57e6("No trainable parameters found. Skipping training...")
            _be8916c2db0b._d2ab006636c0 = _bc8f80d2cb4f

    @_2e64de2ddaca
    def _af9c814f671d(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _d49f62427826: _b725764385e2._b1c4a9378c9b) -> _3bc71047e9cc:
        """
        Called at the start of testing. Logs a model summary for easier debugging.
        """
        _8d40aea4f337 = self._2f2c51e77eee._136eff5a08a5(_be8916c2db0b, _d49f62427826)
        _8d40aea4f337 = self._559d9c54dd5f(_be8916c2db0b)
        self._d7f2f3066165._7aba0e9e57e6("Model Training Parameters Summary \n{}"._397a8545f757(_8d40aea4f337))

    @_2e64de2ddaca
    def _3f91e3974284(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _d49f62427826: _b725764385e2._b1c4a9378c9b, _ffe146a763e9: _326b62e4472c) -> _3bc71047e9cc:
        """
        Called when an exception bubbles up during training. Log final training info to disk for debugging.
        """
        self._003e6dc4244e(_be8916c2db0b=_be8916c2db0b, _d49f62427826=_d49f62427826, _cf8dca060e26="Abnormal Termination due to Exception or an explicit interruption in program")

    @_2e64de2ddaca
    def _b207fcfb4717(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _d49f62427826: _b725764385e2._b1c4a9378c9b) -> _3bc71047e9cc:
        """
        Called at normal completion of training. Finalizes and writes summary metrics.
        """
        self._d7f2f3066165._7aba0e9e57e6(f"After Fit Model Summary")
        self._003e6dc4244e(_be8916c2db0b, _d49f62427826, _cf8dca060e26="Training Completed Normally ")

    def _fb119a50878b(self, _be8916c2db0b: _b725764385e2._cb9f64bad04e, _d49f62427826: _b725764385e2._b1c4a9378c9b, _cf8dca060e26: _468b6bd71a4f) -> _3bc71047e9cc:
        """
        Internal helper to persist final training summary information and write the metrics summary CSV.

        This aggregates start/end times, computes elapsed training time, persists summary to disk,
        and logs the same model summary computed earlier.
        """
        if self._24cbd9315dc4:
            self._f957769b1243["trial_number"] = self._24cbd9315dc4._6b4d8b491125

        # Populate start_epoch if missing
        if self._cb9d9ef8543a is _3bc71047e9cc:
            try:
                self._f957769b1243["start_epoch"] = _cda3a8af2cc7(_be8916c2db0b._307658b864df)
            except _84b137df1964:
                self._f957769b1243["start_epoch"] = 0.0

        # Determine end epoch (favor callback metrics if present)
        _376ddff82cd3 = _be8916c2db0b._6e83d8df7334._ab7815c6be52("epoch", _be8916c2db0b._307658b864df) if _28e6fe633c17(_be8916c2db0b._6e83d8df7334, _338f08b848b6) else _be8916c2db0b._307658b864df
        if _28e6fe633c17(_376ddff82cd3, _56497f1fb8d7._117c8808ac37):
            _7ded1b70e508 = _cda3a8af2cc7(_376ddff82cd3._bc68f423503a())
        else:
            try:
                _7ded1b70e508 = _cda3a8af2cc7(_376ddff82cd3)
            except _84b137df1964:
                _7ded1b70e508 = _cda3a8af2cc7(_be8916c2db0b._307658b864df)
        self._f957769b1243["end_epoch"] = _7ded1b70e508

        _6d4745d51d42 = self._2cb859a8da88._5b1426ef4907()
        self._f957769b1243["training_end_time"] = _6d4745d51d42
        _4b03a2f0ac60 = self._2cb859a8da88._ef451326c427()
        self._d7f2f3066165._7aba0e9e57e6("Training completed at {}"._397a8545f757(_4b03a2f0ac60))
        self._f957769b1243["training_end_date_time"] = _4b03a2f0ac60

        # compute model training time safely
        _f7da78018e61 = _6d4745d51d42 - self._f957769b1243._ab7815c6be52("training_start_time", _6d4745d51d42)
        self._f957769b1243["model_training_time"] = _f7da78018e61
        self._f957769b1243["model_training_time_details"] = "{} hours {} minutes {} seconds"._397a8545f757(
            *self._2cb859a8da88._379caa5da696(_f7da78018e61)
        )

        # Mark training status in summary
        if _be8916c2db0b._d2ab006636c0:
            _cf8dca060e26 += " Early Stopping Implemented."
        self._f957769b1243["model_training_status"] = _cf8dca060e26

        # Ensure metrics_dir exists and write summary CSV
        if not os._9922d25998a5._c1442bbbc66e(self._16d1f5f493be):
            os._2b76a1e7e880(self._16d1f5f493be, _ddb03d3d8c1d=_bc8f80d2cb4f)

        _40265ee1e8f3 = os._9922d25998a5._a992d7310e98(self._16d1f5f493be, self._8f61032b25c2)
        try:
            with _6e8c730bf268(_40265ee1e8f3, "a+", _70f9d09eb0ff="utf8") as _74b3c3c90344:
                _fea9de8feebb = _159bc7538460._97ffaeb12d73(_74b3c3c90344, _eac4d7cf9818=self._f957769b1243._6be274bdb73a())
                if os._9922d25998a5._93fdfc9748e2(_40265ee1e8f3) == 0:
                    _fea9de8feebb._3faa824041c4()
                _fea9de8feebb._bff05e7847b0([self._f957769b1243])
        except _84b137df1964 as _96a7c7fd944a:
            self._d7f2f3066165._a64b89cd8c6e("Failed to write training summary CSV: %s", _96a7c7fd944a)
            raise _9158186a8282("Failed to write training summary CSV.") from _96a7c7fd944a

        # Final model summary log
        _8d40aea4f337 = self._2f2c51e77eee._136eff5a08a5(_be8916c2db0b, _d49f62427826)
        _8d40aea4f337 = self._559d9c54dd5f(_be8916c2db0b)
        self._d7f2f3066165._7aba0e9e57e6(f"Model Training Parameters Summary on Rank {_be8916c2db0b._c4732104d7d5} \n{_8d40aea4f337}")
