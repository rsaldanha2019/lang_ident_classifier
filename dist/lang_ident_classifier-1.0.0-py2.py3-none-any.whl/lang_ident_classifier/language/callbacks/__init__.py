#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(39128, 56852, 2), (57186, 55985, 2), (49168, 56307, 2), (7649, 38828, 2), (46728, 39224, 2), (47292, 65052, 2), (14310, 61009, 2), (24463, 3270, 2), (27929, 52786, 2), (30848, 6967, 2), (35212, 40093, 2), (44085, 28833, 2), (31560, 64818, 2), (60244, 58824, 2), (41848, 35721, 2), (3593, 64759, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('RswF0w==')
_nonce = base64.b64decode('TnqW0XOk0SkHhFL+')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('LgUcx8r+dU8uDkd3j5yCaiUKz2OQ9MxukJQjZFmh8CHG26+mQbyQNz7Gmiw51H+kzDb2DtGkfYaN7+/uIaYF69iLqJ1nmeWLEp9o8/TZSSGfiUGVOrsEoJTIMZpRYaFCG2HOzNBTCnskU2ckjrgfE6DIAhFJnuQz21rvj8mAPy85KslqgfvYhCsjKThkLOVbc3W9gfzBQwDXpw0JHlUJ7YUvNwP3iIHYY5t04ZxHjDrXKBCvQF0pPr6fHx4jkDMbsDyTdNZVnlOGXkCY6otQtsrt3037fQAjLu/kkhwjfdqFEbG5X9bKuXDrmv2ceqd/Am6oeMfJjdFgo1jN9wprsRO6IKpuaZkvA0OXGDji')
_tag = base64.b64decode('v8n5CQi5fh+sh1oC3/44DQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
