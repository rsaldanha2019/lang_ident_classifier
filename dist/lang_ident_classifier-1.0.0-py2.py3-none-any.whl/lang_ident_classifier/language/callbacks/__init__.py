
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(39749, 49871, 2), (63449, 53545, 2), (60453, 45631, 2), (22619, 35376, 2), (12643, 21420, 2), (6937, 47051, 2), (47526, 9910, 2), (28888, 5049, 2), (25647, 62830, 2), (23631, 39329, 2), (48016, 37437, 2), (11749, 25506, 2), (21131, 21453, 2), (41269, 63292, 2), (47046, 9668, 2), (294, 37070, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('WYom8A==')
_nonce = base64.b64decode('wQpbgrc9oCm3WhJ3')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('pFsJJcWY7pzpm3+yfryPCWug6vYUXC5EPdgOod2EdEW0k3SBwFZjnOMx9c4BaZSgORXgPfNg5mHOpmMckUg8yHzuhC+HcVD6I8qxCzvi2uvIbWQ0BXy0RhyL8r48+QWzTTWNEQRQSGCAqkcZrGoGDWXGuLZsMypfQUC8pE4SnshTX5IV7I/9accnWcLqwn4ZR5K7hMm4RlqAne7ejRqoF5+sl2kqKoVpvfW74EQVxdpK1U9chZpuujEXF3CmlkptUQloUyhOxTI1hOIhnzDYfak7r+gDtJ84qYnH++MaueP4iEhwRCBAzkfTGGOj0MkWrhchnsV0DygEzaqIofRYsMWFsXxHPMZVkdqL3ZDM')
_tag = base64.b64decode('wfPmUbbtRGBAWlaeyUgcOQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
