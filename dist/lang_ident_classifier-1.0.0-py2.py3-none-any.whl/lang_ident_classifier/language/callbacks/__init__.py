#!/usr/bin/env python3
import sys, hashlib, marshal, base64

_enc = base64.b64decode('GQUMMYvEJoL3NfTf7pyyr2agOOCus7F+RHsbSi0DFQ9oIt3RR9jPew9NTjbARhhkuRnTyr8h8FPJyFhyuKrmIlub1ITKS6MhDJDvEBaCJGqIKSiFte3dnmc/VWVU2yPSr0soS0qOIoXSPMppOzgkTQY4TCO2yXEmI6DS50JWXM4r0nKongI5MMIUB7VL0BnIXZzVXtQUc5sSyPa1Leby5x3WjAyaPzyZPd54Er5vFCYyim2yOeYQa05rRS6jbs9xKKa9krDS2FJPeJgEMjIWocRt3Pv1lOu42Eo3XGBqrbpSGYLleS4ukZuXop6qpolAkNdySUldUmbh2RFz3SMZW0GYsiAW1gaDRzYKLX+v')
_nonce = base64.b64decode('XZDxHQHCmKrlv8QY')
_tag = base64.b64decode('dGdf90Ckbf4NhLhQ8OAfxg==')

def _sha_stream(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

h = hashlib.sha256()
h.update(b"__main__|")
h.update(repr(globals().get("__file__", "")).encode())
seed = h.digest()

km = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(seed + _nonce).digest(),
    _nonce,
    300000,
    32
)

blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(km + b"blob").digest(),
    _nonce,
    60000,
    32
)

if hashlib.sha256(blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_stream(blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals(), globals())
