#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(26911, 16726, 2), (2959, 7237, 2), (61439, 16006, 2), (25546, 13869, 2), (18508, 60505, 2), (7837, 25636, 2), (51871, 22217, 2), (41305, 1957, 2), (12760, 59356, 2), (21430, 53270, 2), (38740, 16914, 2), (24765, 16569, 2), (4633, 44944, 2), (39304, 3990, 2), (48753, 38767, 2), (32121, 2613, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('KEkXyg==')
_nonce = base64.b64decode('3UiGNzaxRAgWJDB2')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('BSIYWB1kWtNldKgj1gGkZgw5bIOlVE57hKRcEUGNfrteCZVmRb5AAjFmnr3iuNRB1hzZHKEGr4WXZAfhgD12LnOkUgT/jejSkf0DWCasshrRfzSZSFWDujVMHt+soYknIwaScZDRIC0PdMxPeCEH7/vRgJ/4cs0AJl4/KIWlWcV+a9/22FoSm79i7a/nQ1dcwuS9SfWhmOKCZXRJhIIK597hrzZ0S7yIKAv7kefgfDmPvf8uDStmd/qBfUPfzIJCPJBHOV3Zz76/LoPsm2lPxO2zRnYiYTQzDUifHMMAsPNrRGSyXN9xozHYNsW7GCdEzr/O6N1oUivsjd5qW5e1kzaW5uFKbuVk8/6kpuvH')
_tag = base64.b64decode('WyTwFh4XKP+/78zI1T+BYQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
