#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(8472, 27854, 2), (12796, 31521, 2), (18206, 9424, 2), (17241, 15851, 2), (44722, 6090, 2), (61267, 29656, 2), (53688, 29778, 2), (26015, 60646, 2), (4012, 15596, 2), (26972, 23720, 2), (23954, 53830, 2), (15723, 9141, 2), (34442, 31229, 2), (9765, 57240, 2), (3073, 30370, 2), (49498, 55670, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('TdZK3Q==')
_nonce = base64.b64decode('+LGNI80WLNjmTUXL')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('8RlA6aH42y+zAdUfEBDDCn+CiZyMhrfagcsMmSFjWeMAG9wm7OsLpZNVmBTkG91SmCzrVHnAU7ranu38TbzsRTslgui9NEdd6rHTfedbXiGxA7IMPOMUFH9S5ves/fR0B4hfKHy5h36TRfvyMY2K4CX844EvxCfsCYZKWPoHZNOSOPW2q8Py9pYg2IPUckbY89G3MvR5AHCd99Sw0B9YQNhYkA/BfO0hqDU9DLjsA5wrTSoEU/E5mQpvgr+5gO7oKjEcO0LhUMlCIGQavt/nm76Fg0U+/BqhkEqgfd2DaqdXL7pdaMMhgXZXa/wtr0NKAs2koNY+dyxiY0v27WnJxYj8Eag=')
_tag = base64.b64decode('acacQg2G6aFsskaK2ZNroA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
