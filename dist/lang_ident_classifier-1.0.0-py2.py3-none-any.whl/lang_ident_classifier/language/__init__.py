#!/usr/bin/env python3
import sys, hashlib, marshal, base64

_enc = base64.b64decode('Nhe2eMzl6aVE0JYqrLYaDDm/cDZEabiERQtMvSpPUMl56EmQfat40+f3h4ERBWt4octaYv/5HMzyZ0G3kRW1bGfdI/i+2abtFpY8Aq1RwMlSZc9G73uzpTpDMrezbf3A35p0JlcR7LDuBlf7uLvh1Gqu1sDgiIgLfp36R9qQ63cXUHMbrtyFFM4WpOAWsizRUH9n8h+IZg2wYdJy1RsOolAVbE0YhxjoLC43rkmynQ4Rmqui1IyopqgZVR+RbByVPt4INc1pv8gYH+nvwi4SZSDhLDpBQscum19BnEIrrP5F3vpH98WCVVmpmNWpiWoZm2qvOiDQKXCv/FZMM3CfNVIib9s=')
_nonce = base64.b64decode('kWJfVLuLdHyqcr/Z')
_tag = base64.b64decode('89x2Z7JrVka+BzxE+uCBKQ==')

def _sha_stream(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

h = hashlib.sha256()
h.update(b"__main__|")
h.update(repr(globals().get("__file__", "")).encode())
seed = h.digest()

km = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(seed + _nonce).digest(),
    _nonce,
    300000,
    32
)

blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(km + b"blob").digest(),
    _nonce,
    60000,
    32
)

if hashlib.sha256(blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_stream(blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals(), globals())
