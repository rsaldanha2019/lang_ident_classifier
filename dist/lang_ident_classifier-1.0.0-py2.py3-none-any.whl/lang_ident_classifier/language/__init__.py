#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(1351, 4373, 2), (21443, 26238, 2), (14409, 37049, 2), (43028, 18348, 2), (36053, 37027, 2), (56158, 21589, 2), (5113, 62032, 2), (42128, 41232, 2), (25323, 52185, 2), (59699, 60487, 2), (37304, 8968, 2), (36039, 15443, 2), (31978, 50522, 2), (51303, 6170, 2), (19966, 61536, 2), (13069, 1106, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('FFI1vQ==')
_nonce = base64.b64decode('BqKa6GdwVMB95Nng')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('owzEiOpW0Um95l4cb5WNhyG/xbA+oLYq9APKuWUGbnZWXD+Jaiow+wYuk3M4fntpwO9uGIRiRsLoUgth/LyvcJ4PDywnbDOr8Emee6ntJa//ps201xSrv9/NBq+EvqbrcMK1DIOs8mvn7zSzwiqqK0RNkrQGPAxtwdj9nTSC25vVcHRkx1Dx5f6uPviW8oh1+9QDjBDNPnbwoqW9HhEFbYWxmz8PidYyIeTMJOza8QR3239Kv6XmKrnVY966GTU5VGsrf1VfC1/anuNZqQX0sTl19tzEmKScs3OrZoD+MY7c/fTKu3e1kln2fIjzB9h9WSOX2uNXrFuMuvh56BF24ToSHLU=')
_tag = base64.b64decode('Ua0Loz5wThDDxygXHDEdYQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
