
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(24250, 53247, 2), (36216, 3092, 2), (19041, 16372, 2), (36465, 58128, 2), (31262, 58885, 2), (10233, 27688, 2), (17567, 31291, 2), (3695, 41254, 2), (63042, 34322, 2), (55673, 38485, 2), (49124, 7294, 2), (29057, 34337, 2), (53208, 17942, 2), (42879, 61807, 2), (50617, 57129, 2), (55017, 46440, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('kUWBbA==')
_nonce = base64.b64decode('qcYM+d5RVMAigXxd')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('Jph3LWi9wytfKzWjvdcjJXfjPIktqPAB0LfZi7Z95Cpm61SFqC9c6LbFDs9tjw+UzofjR0IGYcwW36ZVuv+awsGpMS1FXNjCU8ROULphmDd575Rg+jdaQJed/Hg5Nm/PFNMNNPqCj0oY845DJEsemtBxdakKVtPaK8DBUu31ErBjp2NCOZAsEa+qr4W84KLzMA6lUpUrGEW6fxE52OVdyS2Qnjx9rTJsVk7Ypy3ow8luahwxq/3uA1nr1qBs7m2pWKhemeD7xdP/VlMJ63oksy3+qY4nGoOhMvKnXp8bPc+A6TLNx1mrkXm3aHBhj988sCO5Wl8QhiQWlijkOF1JkdvTbWM=')
_tag = base64.b64decode('FBbYDRu328t7YHK2Oy75iw==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
