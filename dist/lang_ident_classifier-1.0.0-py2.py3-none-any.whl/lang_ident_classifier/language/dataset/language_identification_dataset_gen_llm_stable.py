# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_dataset
# @Time             : 18/12/23 2:34 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import functools
from itertools import chain
import json
import math
from multiprocessing import Pool, cpu_count
import os
from difflib import SequenceMatcher
from logging import Logger
import random
import re
from typing import Any, List
import unicodedata
import numpy as np
import torch
from torch.utils.data import Dataset

class LanguageIdentificationDataset(Dataset):
    """
    contains methods for Dataset related operations
    """
    TOKENIZER = None  # Class-level tokenizer

    def __init__(self, data_dir: str, files_have__header: bool,
                 pretrained_embedding_tokenizer: Any, max_output_length: int,
                 classes_config_path: str, log: Logger,
                 is_train: bool, sample_dataset_share: float = 1.0,
                 num_workers: int = 2,
                 random_seed: int = 20, is_gen_llm: bool = False, prompt_template = None):
        """
        initializes the class instance with default parameters
        :param data_dir: path of the data directory
        :param files_have__header: if True, indicates that
        files have header and will skip 1 line
        :param log: instance of a Logger object for logging
        """
        super(LanguageIdentificationDataset, self).__init__()
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        random.seed(random_seed)
        np.random.seed(random_seed)
        self.log = log
        self.is_train = is_train
        self.is_gen_llm = is_gen_llm
        self.prompt_template = prompt_template
        self.files_have_header = files_have__header
        self.data_dir = data_dir
        self.max_seq_length = max_output_length
        LanguageIdentificationDataset.TOKENIZER = pretrained_embedding_tokenizer
        self.tokenizer = pretrained_embedding_tokenizer
        self.ignore_index = -100 if is_gen_llm else self.tokenizer.pad_token_id
        self.src_data = []
        self.attn_data = []
        self.tgt_data = []
        self.file_stats = {}
        self.sample_dataset_share = sample_dataset_share
        self.num_workers = num_workers
        self._validate_and_load_file_data()
        # self.validate_windowing_samples()
        self.classes, self.class_weights = self._get_classes_dict(classes_config_path, is_train)

    def __len__(self):
        """
        method to obtain number of samples in the dataset
        :return: length of the dataset
        """
        return len(self.tgt_data)

    def _get_class_id_from_lang_code(self, lang_code):
        for lang_id, lang_info in self.classes.items():
            if lang_info["lang_code"] == lang_code.strip():
                return lang_id
        return self.classes.get("unk", {}).get("id", -1)

    def _get_lang_code_from_class_id(self, class_id):
        return self.classes[class_id]["lang_code"]

    def get_num_classes(self):
        return len(self.classes)

    def _add_languages(self, lang_code_dict):
        # Count unique language occurrences per sample
        new_languages_dict = defaultdict(int)
        for lang in chain.from_iterable(
            set(label.strip() for label in entry if isinstance(label, str)) 
            for entry in self.tgt_data
        ):
            new_languages_dict[lang] += 1

        # Ensure dict is regular (optional)
        new_languages_dict = dict(new_languages_dict)

        # Add 'unk' language entry if not present
        if not any(value['lang_code'] == "unk" for value in lang_code_dict.values()):
            lang_code_dict[0] = {"lang_code": "unk", "lang_samples": 0, "lang_files": []}

        for lang, count in new_languages_dict.items():
            lang = lang.strip()
            file_list = self.file_stats.get(lang, [])

            existing_id = next(
                (key for key, value in lang_code_dict.items() if value['lang_code'] == lang),
                None
            )

            if existing_id is None:
                new_id = len(lang_code_dict)
                lang_code_dict[new_id] = {
                    "lang_code": lang,
                    "lang_samples": count,
                    "lang_files": file_list
                }
            else:
                # Update only if new data increases sample count
                existing = lang_code_dict[existing_id]
                if count > existing["lang_samples"]:
                    updated_files = list(set(existing["lang_files"] + file_list))
                    lang_code_dict[existing_id] = {
                        "lang_code": lang,
                        "lang_samples": existing["lang_samples"] + count,
                        "lang_files": updated_files
                    }

        return lang_code_dict
    
    def _normalize_class_weights(self, weights):
        total_weight = np.sum(weights)
        normalized_weights = weights / total_weight
        return normalized_weights

    def _get_class_weights(self, classes_dict):
        # Calculate class weights based on lang_samples
        total_samples = sum(entry['lang_samples'] for entry in classes_dict.values())

        class_weights = {}
        for lang_code, lang_data in classes_dict.items():
            class_samples = lang_data['lang_samples']
            if class_samples > 0:
                # weights are inversely proportional to number of samples
                class_weight = total_samples / (class_samples * len(classes_dict))
            else:
                class_weight = 0  # Set weight to 0 if there are no samples
            classes_dict[lang_code].update({"lang_weight":class_weight})
        class_weights = [entry['lang_weight'] for entry in classes_dict.values()]
        # class_weights = self._normalize_class_weights(class_weights)
        # Update the lang_weights with normalized class weights
        for i, (lang_code, lang_data) in enumerate(classes_dict.items()):
            lang_data["lang_weight"] = class_weights[i]
        return class_weights, classes_dict

    def _get_classes_dict(self, classes_config_path, is_train):
            classes_dict = {}
            class_weights = {}
            if os.path.exists(classes_config_path):
                with open(classes_config_path, mode='r+', encoding='utf8') as ccp:
                    # classes_dict = json.load(ccp)
                    raw_dict = json.load(ccp)  # Load JSON normally (keys are strings)
        
                    classes_dict = {
                        float(k) if "." in k else int(k): v  # Convert only top-level keys
                        for k, v in raw_dict.items()
                    }

            if is_train:
                classes_dict = self._add_languages(lang_code_dict=classes_dict)
                class_weights, classes_dict = self._get_class_weights(classes_dict=classes_dict)

                with open(classes_config_path, mode='w+', encoding='utf8') as ccp_w:
                    json.dump(classes_dict, ccp_w, indent=2)

            return classes_dict, class_weights
    
    def get_labels(self):
        return [self._get_class_id_from_lang_code(lang_code) for lang_code in self.tgt_data]

    # def __getitem__(self, idx: int) -> Any:
    #     input_ids = self.src_data[idx]  # assumed to be list[int]
    #     target_id = self._get_class_id_from_lang_code(self.tgt_data[idx])
    #     if target_id is None:
    #         print(f'Language not present at idx {idx}, value: {self.tgt_data[idx]}')
    #         target_id = 0  # fallback class

    #     # Safety check for tokenizer.pad_token_id
    #     pad_token_id = self.tokenizer.pad_token_id
    #     if pad_token_id is None:
    #         pad_token_id = self.tokenizer.eos_token_id  # fallback
    #         self.tokenizer.pad_token = self.tokenizer.eos_token  # ensure consistency

    #     max_len = self.max_seq_length
    #     seq_len = len(input_ids)

    #     # Pad input_ids
    #     input_ids = input_ids[:max_len]
    #     padding_length = max_len - len(input_ids)
    #     input_ids += [pad_token_id] * padding_length

    #     # Attention mask: 1s for real tokens, 0s for padding
    #     attention_mask = [1] * min(seq_len, max_len) + [0] * padding_length

    #     # For classification per token, repeat target_id; or return single class label
    #     target_ids = [target_id] * min(seq_len, max_len) + [-100] * padding_length  # -100 to ignore loss on pad

    #     return (
    #         torch.tensor(input_ids, dtype=torch.long),
    #         torch.tensor(attention_mask, dtype=torch.long),
    #         torch.tensor(target_ids, dtype=torch.long),
    #     )

    def __getitem__(self, idx):
        input_ids = self.src_data[idx]
        target_data = self.tgt_data[idx]

        # Replace None in target_data with self.ignore_index
        target_data = [
            self.ignore_index if t is None else t
            for t in target_data
        ]


        # Show only the *first* sample in val and test mode
        # if not hasattr(self, "_has_logged_sample"):
        #     self._has_logged_sample = {"val": False, "test": False}

        # if not self.is_train and not self._has_logged_sample["test"] and idx == 0:
        #     print(f"[TEST] Sample idx=0\nInput IDs: {input_ids}\nTarget: {target_data}")
        #     self._has_logged_sample["test"] = True
        # elif self.is_train is False and not self._has_logged_sample["val"] and idx == 0:
        #     print(f"[VAL] Sample idx=0\nInput IDs: {input_ids}\nTarget: {target_data}")
        #     self._has_logged_sample["val"] = True

        # Now apply class ID mapping
        target_ids = [
            self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
            for t in target_data
        ]

        return (
            torch.tensor(input_ids, dtype=torch.long),
            torch.tensor(target_ids, dtype=torch.long)
        )
    
    def validate_windowing_samples(self, num_samples: int = 5):
        """
        Validates windowed source text and label alignment on a random sample of the dataset.
        Useful for debugging tokenizer behavior and checking label correctness.
        """
        if not hasattr(self, 'src_data') or not hasattr(self, 'tgt_data'):
            self.log.warning("No src_data or tgt_data loaded. Cannot validate.")
            return

        from random import sample
        from transformers import PreTrainedTokenizer

        tokenizer = self.tokenizer
        if not isinstance(tokenizer, PreTrainedTokenizer):
            self.log.warning("Tokenizer does not support decode(). Skipping validation.")
            return

        indices = sample(range(len(self.src_data)), min(num_samples, len(self.src_data)))

        for idx in indices:
            input_ids = self.src_data[idx]
            tgt_label = self.tgt_data[idx]

            print(f"\n=== SAMPLE {idx} ===")
            decoded_text = tokenizer.decode(input_ids, skip_special_tokens=True)
            print(f"Decoded window text: {decoded_text}")
            print(f"Input IDs (len={len(input_ids)}): {input_ids}")
            print(f"Target label: {tgt_label}")

            if isinstance(tgt_label, list):
                print(f"Label list length: {len(tgt_label)}")
                print(f"Label values (truncated): {tgt_label[:10]}...")
                if len(input_ids) != len(tgt_label):
                    print("Length mismatch between input IDs and token-level labels.")
            else:
                print("Label is per-sequence, not per-token.")


    def _similar_name(self, name_1: str, name_2: str) -> float:
        """
        takes two filenames, compares and returns the match score
        :param name_1: file name of file 1
        :param name_2: file name of file 2
        :return: match score
        """
        return SequenceMatcher(None, name_1, name_2).ratio()

    # Function to calculate overlap length based on percentage
    def _calculate_overlap(self, overlap_percentage):
        return int(self.max_seq_length * overlap_percentage)
    
    @staticmethod
    def _split_into_token_windows(tokens, max_len, overlap_ratio=0.5):
        step = int(max_len * (1 - overlap_ratio))
        if step < 1: step = 1
        return [tokens[i:i + max_len] for i in range(0, len(tokens), step)]

    # Function to split line into overlapping windows
    @staticmethod
    def _split_into_windows(src_line, overlap_length, max_seq_length):
        windows = []
        for i in range(0, len(src_line), max_seq_length - overlap_length):
            windows.append(src_line[i:i + max_seq_length])
        return windows

    @staticmethod
    def tokenize_words_fast(text: str, tokenizer, add_special_tokens=True) -> List[List[int]]:
        """
        Tokenize text into per-word token IDs using a stateless encoder_ function.
        Assumes encoder_ is a callable configured with is_split_into_words=True.
        """
        words = text.split()
        encodings = tokenizer(words, is_split_into_words=True, add_special_tokens=add_special_tokens)  # encoder_ must be a lightweight tokenizer function

        word_ids = encodings.word_ids()
        input_ids = encodings.input_ids

        grouped_tokens = []
        current_word = -1
        current_tokens = []

        for token_id, word_id in zip(input_ids, word_ids):
            if word_id is None:
                continue
            if word_id != current_word:
                if current_tokens:
                    grouped_tokens.append(current_tokens)
                current_tokens = [token_id]
                current_word = word_id
            else:
                current_tokens.append(token_id)
        if current_tokens:
            grouped_tokens.append(current_tokens)

        return grouped_tokens


    @staticmethod
    def _split_into_windows_for_gen_llm(
        prompt_template: str,
        src_line: str,
        tgt_line: str,
        overlap_percentage: float,
        max_seq_length: int,
        tokenizer
    ):
        """
        Efficiently splits input into overlapping windows and tokenizes them in batch.
        - Uses {input_text} and {response} placeholders in the prompt_template
        - {response} is just space-separated labels
        """

        src_words = src_line.strip().split()
        tgt_labels = tgt_line.strip().split()
        single_label = len(tgt_labels) == 1

        # assert not (len(src_words) != len(tgt_labels) and not single_label), \
        #     "Mismatch between source words and target labels"

        # assert "{input_text}" in prompt_template and "{response}" in prompt_template, \
        #     "Prompt template must include {input_text} and {response}"

        # Estimate tokens per word
        test_src = src_words[:10]
        test_tgt = [tgt_labels[0]] * len(test_src) if single_label else tgt_labels[:10]
        test_prompt = prompt_template.replace("{input_text}", " ".join(test_src)).replace("{response}", " ".join(test_tgt))
        test_tokens = tokenizer.encode(test_prompt, add_special_tokens=True)
        avg_tokens_per_word = len(test_tokens) / max(1, len(test_src))

        est_words_per_window = int(max_seq_length / avg_tokens_per_word)
        if est_words_per_window < 1:
            raise ValueError("max_seq_length too small to fit even one word")

        overlap_words = int(overlap_percentage * est_words_per_window)

        # First, collect prompt strings for all windows
        prompt_texts = []
        start = 0
        last_end = 0
        window_spans = []

        while start < len(src_words):
            end = min(start + est_words_per_window, len(src_words))
            src_window = src_words[start:end]
            tgt_window = [tgt_labels[0]] * len(src_window) if single_label else tgt_labels[start:end]

            prompt_text = prompt_template.replace("{input_text}", " ".join(src_window)).replace("{response}", " ".join(tgt_window))
            prompt_texts.append(prompt_text)
            window_spans.append((start, end))  # for debugging or reference

            if end >= len(src_words):
                break
            start = max(end - overlap_words, last_end + 1)
            last_end = end

        # Tokenize all at once
        tokenized_outputs = tokenizer(
            prompt_texts,
            add_special_tokens=True,
            truncation=False,
            return_attention_mask=False
        )

        # Filter based on length
        windows = [
            tokens for tokens in tokenized_outputs["input_ids"]
            if len(tokens) <= max_seq_length
        ]

        # print(f"Original line {src_line} and ")
        # for win in windows:
        #     print(f"decoded window {LanguageIdentificationDataset.decode_text(win, tokenizer=tokenizer)}")

        return windows



    @staticmethod
    def _is_arabic(text):
        for char in text:
            if 'ARABIC' not in unicodedata.name(char, ''):
                return False
        return True

    @staticmethod
    def _reverse_arabic_sentence(sentence):
        if LanguageIdentificationDataset._is_arabic(sentence):
            # If the sentence is in Arabic script, reverse it
            # reversed_sentence = sentence[::-1]
            # Step 1: Split the sentence into words
            words = sentence.strip().split()

            # Step 2: Reverse the order of words (keeping characters in place)
            reversed_sentence = " ".join(reversed(words))
            # reversed_sentence = sentence
            return reversed_sentence
        else:
            return sentence
    
    @staticmethod
    def _is_english_string(input_string):
        # Function to check if a character is part of the English alphabet
        def is_english_char(char):
            return 'a' <= char.lower() <= 'z'

        # Convert the string to a list of characters
        characters = list(input_string)

        # Count the English alphabet characters
        english_chars_count = sum(1 for char in characters if is_english_char(char))

        # Calculate the percentage of English alphabet characters
        percentage_english = english_chars_count / len(characters)

        # Check if more than 50% of characters are from the English alphabet
        return percentage_english > 0.5
    
    @staticmethod
    def process_line(args):
        """
        Process a single line: clean, check language, tokenize, and split.
        Returns (src_tokens, tgt_line) if valid, else None.
        """
        (src_line, tgt_line, max_seq_length, overlap_percentage, pad_token_id, 
         is_english_func, split_windows_func, tokenizer_encode_func) = args

        tgt_line = tgt_line.strip()
        src_line = ' '.join(src_line.split())  # Remove extra spaces

        # Check language constraints
        is_english = is_english_func(src_line)
        if ("_en" in tgt_line and not is_english) or ("_en" not in tgt_line and is_english):
            return None  # Skip mismatched languages

        src_tokens = tokenizer_encode_func(src_line)

        # Handle long sequences
        if len(src_tokens) > max_seq_length:
            overlap_len = int(overlap_percentage * max_seq_length)
            windows = split_windows_func(src_tokens, overlap_len, max_seq_length)
            windows = [win + [pad_token_id] * (max_seq_length - len(win)) for win in windows]
            return [(win, tgt_line) for win in windows]
        else:
            # Pad shorter sequences to max_seq_length
            src_tokens += [pad_token_id] * (max_seq_length - len(src_tokens))
            return [(src_tokens, tgt_line)]

    @staticmethod
    def process_line_gen_llm(args):
        """
        Process a single line: clean, check language, tokenize, and split.
        Returns (src_tokens, tgt_line) if valid, else None.
        """
        (prompt_template, src_line, tgt_line, max_seq_length, overlap_percentage, pad_token_id, tokenizer,
        is_english_func, split_windows_func, tokenizer_encode_func) = args

        tgt_line = tgt_line.strip()
        org_tgt_line = tgt_line
        src_line = ' '.join(src_line.split())  # Normalize whitespace

        # Check language constraints
        is_english = is_english_func(src_line)
        if ("_en" in tgt_line and not is_english) or ("_en" not in tgt_line and is_english):
            return None  # Skip mismatched languages

        # Replace {input_text}
        filled_prompt = prompt_template.replace("{input_text}", src_line)

        # Trim at {response} if present
        if "{response}" in filled_prompt:
            filled_prompt = filled_prompt.split("{response}")[0]  # drop everything after {response}

        # Tokenize
        prompt_tokens = tokenizer_encode_func(filled_prompt, add_special_tokens=True)

        # Adjust tgt_line for label alignment
        tgt_line = " ".join([tgt_line] * len(src_line.strip().split())) if len(tgt_line.split()) == 1 and tgt_line.strip() else tgt_line
        if len(src_line.split()) != len(tgt_line.split()):
            raise ValueError(f"Source line and Target line tokens dont match for {src_line}")

        # src_tokens = tokenizer_encode_func(src_line, add_special_tokens=False)
        tgt_tokens = tokenizer_encode_func(tgt_line, add_special_tokens=False)

        total_prompt_tokens = prompt_tokens + tgt_tokens

        # print(f"Current Tokens {total_prompt_tokens}")
        # decoded_prompt = LanguageIdentificationDataset.decode_text(total_prompt_tokens, tokenizer)
        # print(f"Decoded prompt {decoded_prompt}")

        # Handle long sequences
        if len(total_prompt_tokens) > max_seq_length:
            # print(f"splitting {len(total_prompt_tokens)}")
            try:
                windows = split_windows_func(prompt_template, src_line, org_tgt_line,
                                            overlap_percentage, max_seq_length, tokenizer)
            except Exception as e:
                print(f"Windows exception {e}")
            return [(win, org_tgt_line) for win in windows]
        else:
            return [(total_prompt_tokens, org_tgt_line)]

    @staticmethod
    def process_batch(args):
        src_lines, tgt_lines, max_seq_len, overlap_ratio = args
        tokenizer = LanguageIdentificationDataset.TOKENIZER
        pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
        results = []

        for src, tgt in zip(src_lines, tgt_lines):
            src = src.strip()
            words = src.split()
            tgt_parts = tgt if isinstance(tgt, list) else tgt.strip().split()

            # Case 1: Single label
            if len(tgt_parts) == 1:
                word_labels = [tgt_parts[0]] * len(words)

            # Case 2: Word-level labels
            elif len(tgt_parts) == len(words):
                word_labels = tgt_parts

            else:
                continue  # skip badly aligned lines

            input_ids = []
            labels = []

            for word, label in zip(words, word_labels):
                tokens = tokenizer.encode(word, add_special_tokens=False)
                input_ids.extend(tokens)

                if len(tokens) > 0:
                    labels.append(label)  # Label the first token
                    labels.extend([tokenizer.pad_token_id] * (len(tokens) - 1))  # Ignore the rest

            step = int(max_seq_len * (1 - overlap_ratio))
            for i in range(0, len(input_ids), step):
                chunk_ids = input_ids[i:i + max_seq_len]
                chunk_labels = labels[i:i + max_seq_len]

                pad_len = max_seq_len - len(chunk_ids)
                results.append((
                    chunk_ids + [pad_id] * pad_len,
                    chunk_labels + [tokenizer.pad_token_id] * pad_len
                ))

        return results

    # @staticmethod
    # def process_batch_gen_llm(args):
    #     prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER

    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100  # Standard for loss masking
    #     response_prefix = "###Response:\n"
    #     results = []

    #     for src, tgt in zip(src_lines, tgt_lines):
    #         src = src.strip()
    #         src_words = src.split()
    #         tgt_words = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # Check alignment: one label per word
    #         if len(tgt_words) == 1:
    #             tgt_word_labels = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) == len(src_words):
    #             tgt_word_labels = tgt_words
    #         else:
    #             continue  # Skip misaligned

    #         # Step 1: Prompt with real input
    #         prompt = prompt_template.format(input_text=src)
    #         prompt_ids = tokenizer.encode(prompt, add_special_tokens=False)
            

    #         # Step 2: Tokenize words + assign label to first subtoken, ignore rest
    #         response_ids, response_labels = [], []

    #         for word, label in zip(src_words, tgt_word_labels):
    #             word_ids = tokenizer.encode(word, add_special_tokens=False)
    #             if not word_ids:
    #                 continue
                
    #             response_ids.extend(word_ids)
    #             response_labels.append(label)  # First token gets label
    #             response_labels.extend([ignore_index] * (len(word_ids) - 1))  # Rest ignored

    #         # Step 3: Final full input + label
    #         full_input_ids = prompt_ids + response_ids + [eos_id]
    #         full_labels = [ignore_index] * len(prompt_ids) + response_labels + [ignore_index]

    #         # Step 4: Sliding window
    #         step = int(max_seq_len * (1 - overlap_ratio))
    #         for i in range(0, len(full_input_ids), step):
    #             chunk_ids = full_input_ids[i:i + max_seq_len]
    #             chunk_labels = full_labels[i:i + max_seq_len]

    #             # Pad if needed
    #             pad_len = max_seq_len - len(chunk_ids)
    #             chunk_ids += [pad_id] * pad_len
    #             chunk_labels += [ignore_index] * pad_len

    #             results.append((chunk_ids, chunk_labels))

    #     return results

    # @staticmethod
    # def process_batch_gen_llm(args):
    #     prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER

    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100

    #     input_prefix = "\n### Input:\n"
    #     response_prefix = "\n### Response:\n"

    #     results = []

    #     for src, tgt in zip(src_lines, tgt_lines):
    #         src_words = src.strip().split()
    #         tgt_words = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # Alignment: one label per word
    #         if len(tgt_words) == 1:
    #             src_word_labels = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) == len(src_words):
    #             src_word_labels = tgt_words
    #         else:
    #             continue  # Skip misaligned

    #         instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
    #         input_ids = tokenizer.encode(input_prefix + src.strip(), add_special_tokens=False)
    #         response_ids = tokenizer.encode(response_prefix + " ".join(tgt_words), add_special_tokens=False)

    #         prompt_ids = instruction_ids + input_ids + response_ids + [eos_id]
    #         label_prefix_len = len(instruction_ids) + len(input_ids)
    #         labels = [ignore_index] * label_prefix_len + response_ids + [eos_id]

    #         if len(prompt_ids) <= max_seq_len:
    #             padded_input_ids = prompt_ids + [pad_id] * (max_seq_len - len(prompt_ids))
    #             padded_labels = labels + [ignore_index] * (max_seq_len - len(labels))
    #             results.append((padded_input_ids, padded_labels))
    #             continue

    #         # Word-aligned sliding window fallback
    #         window_size = len(src_words)
    #         step_size = max(1, int(window_size * (1 - overlap_ratio)))

    #         for i in range(0, len(src_words), step_size):
    #             chunk_src_words = src_words[i:i + window_size]
    #             chunk_tgt_words = src_word_labels[i:i + window_size]

    #             while len(chunk_src_words) > 0:
    #                 input_text = input_prefix + " ".join(chunk_src_words)
    #                 response_text = response_prefix + " ".join(chunk_tgt_words)

    #                 input_ids = tokenizer.encode(input_text, add_special_tokens=False)
    #                 response_ids = tokenizer.encode(response_text, add_special_tokens=False)

    #                 prompt_ids = instruction_ids + input_ids + response_ids + [eos_id]
    #                 label_prefix_len = len(instruction_ids) + len(input_ids)
    #                 labels = [ignore_index] * label_prefix_len + response_ids + [eos_id]

    #                 if len(prompt_ids) <= max_seq_len:
    #                     padded_input_ids = prompt_ids + [pad_id] * (max_seq_len - len(prompt_ids))
    #                     padded_labels = labels + [ignore_index] * (max_seq_len - len(labels))
    #                     results.append((padded_input_ids, padded_labels))
    #                     break

    #                 # Shrink the window
    #                 chunk_src_words = chunk_src_words[:-1]
    #                 chunk_tgt_words = chunk_tgt_words[:-1]

        # return results
    
    @staticmethod
    def process_batch_gen_llm(args):
        prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train = args
        tokenizer = LanguageIdentificationDataset.TOKENIZER

        pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
        eos_id = tokenizer.eos_token_id
        ignore_index = -100

        input_prefix = "\n### Input:\n"
        response_prefix = "\n### Response:\n"

        results = []

        for src, tgt in zip(src_lines, tgt_lines):
            src_words = src.strip().split()
            tgt_words = tgt if isinstance(tgt, list) else tgt.strip().split()

            # Alignment: one label per word
            if len(tgt_words) == 1:
                src_word_labels = [tgt_words[0]] * len(src_words)
            elif len(tgt_words) == len(src_words):
                src_word_labels = tgt_words
            else:
                continue  # Skip misaligned

            # instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
            # input_ids = tokenizer.encode(src.strip(), add_special_tokens=False)
            # input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
            # response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
            # response_ids = tokenizer.encode(" ".join(src_word_labels), add_special_tokens=False)

            # prefix_ids = instruction_ids + input_prefix_ids + input_ids + response_prefix_ids
            # prompt_ids = prefix_ids + response_ids + [eos_id]
            # pad_len = max_seq_len - len(prompt_ids)

            # labels = [ignore_index] * len(prefix_ids) + src_word_labels
            # labels_pad_len = max_seq_len - len(labels)

            # padded_input_ids = prompt_ids + [eos_id] * pad_len
            # padded_labels = labels + [ignore_index] * labels_pad_len

            # if len(padded_input_ids) <= max_seq_len:
            #     results.append((padded_input_ids, padded_labels))
            # else:
            #     input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
            #     response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
            #     prefix_ids = instruction_ids + input_prefix_ids
            #     suffix_ids = response_prefix_ids + [eos_id]

            #     chunk_input_ids = []
            #     chunk_response_ids = []
            #     chunk_labels = []

            #     for word, label in zip(src_words, src_word_labels):
            #         word_ids = tokenizer.encode(word, add_special_tokens=False)
            #         label_ids = tokenizer.encode(label, add_special_tokens=False)

            #         if not word_ids or not label_ids:
            #             continue

            #         chunk_input_ids.extend(word_ids)
            #         chunk_response_ids.extend(label_ids)
            #         chunk_labels.extend([label_ids[0]] + [ignore_index] * (len(label_ids) - 1))

            #     total_chunk_len = len(chunk_input_ids)
            #     stride = int(max_seq_len * (1 - overlap_ratio))
            #     max_core_len = max_seq_len - len(prefix_ids) - len(suffix_ids)

            #     for start in range(0, total_chunk_len, stride):
            #         end = start + max_core_len

            #         sub_input_chunk = chunk_input_ids[start:end]
            #         sub_response_chunk = chunk_response_ids[start:end]
            #         sub_label_chunk = chunk_labels[start:end]

            #         input_ids = prefix_ids + sub_input_chunk + response_prefix_ids + sub_response_chunk + [eos_id]
            #         labels = [ignore_index] * len(prefix_ids) + sub_label_chunk + [ignore_index] * (len(response_prefix_ids) + len(sub_response_chunk) + 1)

            #         if len(input_ids) > max_seq_len:
            #             # Safety check: truncate if over max_seq_len due to tokenization
            #             input_ids = input_ids[:max_seq_len]
            #             labels = labels[:max_seq_len]

            #         pad_len = max_seq_len - len(input_ids)
            #         padded_input_ids = input_ids + [pad_id] * pad_len
            #         padded_labels = labels + [ignore_index] * pad_len

            #         results.append((padded_input_ids, padded_labels))

            #         if end >= total_chunk_len:
            #             break
            instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
            input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
            response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)

            separator_token = tokenizer.encode(" ", add_special_tokens=False)

            chunk_input_ids = []
            chunk_input_word_ids = []
            chunk_response_label_ids = []
            chunk_labels = []
            chunk = []
            chunk_prefix = instruction_ids + input_prefix_ids
            chunk_suffix = response_prefix_ids
            chunk_len = len(chunk_prefix + chunk_suffix + [eos_id])
            new_chunk_len = chunk_len

            for word, label in zip(src_words, src_word_labels):
                word_ids = tokenizer.encode(word, add_special_tokens=False)
                label_ids = tokenizer.encode(label, add_special_tokens=False)
                word_ids_len = len(word_ids)
                label_ids_len = len(label_ids)
                new_chunk_len += word_ids_len + label_ids_len + 2 * len(separator_token)
                if new_chunk_len <= (max_seq_len-1):
                    chunk_input_word_ids.append(word_ids)
                    chunk_input_word_ids.append(separator_token)
                    chunk_response_label_ids.append(label_ids)
                    chunk_response_label_ids.append(separator_token)
                    chunk_labels.append(label)
                else:
                    chunk_input_word_ids = chunk_input_word_ids[:-2]
                    chunk_response_label_ids = chunk_response_label_ids[:-2]
                    chunk_labels = chunk_labels[:-1]
                    flat_chunk_input_word_ids = [
                        tok for item in chunk_input_word_ids for tok in (item if isinstance(item, list) else [item])
                    ]

                    flat_chunk_response_label_ids = [
                        tok for item in chunk_response_label_ids for tok in (item if isinstance(item, list) else [item])
                    ]

                    flat_chunk_labels = [
                        tok for item in chunk_labels for tok in (item if isinstance(item, list) else [item])
                    ]

                    chunk = chunk_prefix + flat_chunk_input_word_ids + chunk_suffix + flat_chunk_response_label_ids + [eos_id]
                    chunk_labels = flat_chunk_labels
                    if len(chunk)>0 and len(chunk_labels)>0:
                        input_pad_len = max_seq_len - len(chunk)
                        label_pad_len = max_seq_len - len(chunk_labels)
                        padded_input_ids = chunk + [pad_id] * input_pad_len
                        padded_labels = chunk_labels + [ignore_index] * label_pad_len
                        # print(f"padded_inputs {padded_input_ids} and length {len(padded_input_ids)} \
                        #       padded labels {padded_labels} length {len(padded_labels)} \
                        #       ")
                        results.append((padded_input_ids, padded_labels))
                    else:
                        break
                    next_chunk_index = math.ceil(overlap_ratio*len(chunk_input_word_ids))-1
                    chunk_input_word_ids = chunk_input_word_ids[next_chunk_index:] + [word_ids]
                    chunk_response_label_ids = chunk_response_label_ids[next_chunk_index:] + [label_ids]
                    chunk_labels = chunk_labels[next_chunk_index:] + [[label]]
        
        return results

    @staticmethod
    def decode_text(tokens, tokenizer):
        return tokenizer.decode(tokens)
    
    @staticmethod
    def encode_text(text, tokenizer, add_special_tokens=True):
        """Static method for tokenization to avoid pickling errors."""
        return tokenizer.encode_plus(text, truncation=False, return_tensors=None, add_special_tokens=add_special_tokens)["input_ids"]

    # def _process_file_data(self, src_file, tgt_file):
    #     with open(src_file, mode='r', encoding='utf8') as sfile, open(tgt_file, mode='r', encoding='utf8') as tfile:
    #         if self.files_have_header:
    #             src_file_lines = sfile.readlines()[1:]
    #             tgt_file_lines = tfile.readlines()[1:]
    #         else:
    #             src_file_lines = sfile.readlines()
    #             tgt_file_lines = tfile.readlines()

    #     lang_code = list(set(tgt_file_lines))[0].strip()
    #     num_of_samples_to_use = int(len(src_file_lines) * self.sample_dataset_share)

    #     # Randomly select some share of data from the list
    #     src_file_lines = random.sample(src_file_lines, num_of_samples_to_use)
    #     tgt_file_lines = random.sample(tgt_file_lines, num_of_samples_to_use)
    #     self.log.info(f"Sampled {self.sample_dataset_share*100} percent of {src_file} dataset with {len(src_file_lines)} samples.")

    #     # num_workers = max(1, int(cpu_count() * 0.4))  # Use 40% of available CPU cores
    #     num_workers = max(1, self.num_workers)

    #     # Prepare multiprocessing arguments
    #     args_list = [
    #         (src_line, tgt_line, self.max_seq_length, 0.5, self.tokenizer.pad_token_id,
    #          LanguageIdentificationDataset._is_english_string, 
    #          LanguageIdentificationDataset._split_into_windows,
    #          functools.partial(LanguageIdentificationDataset.encode_text, tokenizer=self.tokenizer))  # Pass method reference
    #         for src_line, tgt_line in zip(src_file_lines, tgt_file_lines)
    #     ]

    #     gen_llm_args_list = [
    #         (self.prompt_template, src_line, tgt_line, self.max_seq_length, 0.5, self.tokenizer.pad_token_id, self.tokenizer,
    #          LanguageIdentificationDataset._is_english_string, 
    #          LanguageIdentificationDataset._split_into_windows_for_gen_llm,
    #          functools.partial(LanguageIdentificationDataset.encode_text, tokenizer=self.tokenizer))  # Pass method reference
    #         for src_line, tgt_line in zip(src_file_lines, tgt_file_lines)
    #     ]

    #     # Use multiprocessing with safer settings
    #     if self.is_gen_llm:
    #         with Pool(processes=num_workers) as pool:
    #             results = pool.map(LanguageIdentificationDataset.process_line_gen_llm, gen_llm_args_list)
    #     else:
    #         with Pool(processes=num_workers) as pool:
    #             results = pool.map(LanguageIdentificationDataset.process_line, args_list)
    #     # results = []
    #     # with ThreadPoolExecutor(max_workers=num_workers) as executor:
    #     #     futures = [executor.submit(LanguageIdentificationDataset.process_line, args) for args in args_list]
    #     #     for future in as_completed(futures):
    #     #         result = future.result()
    #     #         results.append(result)


    #     # Flatten results and remove None values
    #     processed_pairs = [pair for sublist in results if sublist for pair in sublist]

    #     # Separate into source and target lists
    #     new_src_file_lines, new_tgt_file_lines = zip(*processed_pairs) if processed_pairs else ([], [])

    #     return lang_code, list(new_src_file_lines), list(new_tgt_file_lines)

    def _process_file_data(self, src_file, tgt_file):
        # Load source and target lines
        with open(src_file, 'r', encoding='utf8') as sfile, open(tgt_file, 'r', encoding='utf8') as tfile:
            src_lines = sfile.readlines()[1:] if self.files_have_header else sfile.readlines()
            tgt_lines = tfile.readlines()[1:] if self.files_have_header else tfile.readlines()

        # Ensure aligned sampling
        combined = list(zip(src_lines, tgt_lines))
        num_samples = int(len(combined) * self.sample_dataset_share)
        sampled = random.sample(combined, num_samples)
        src_lines, tgt_lines = zip(*sampled)
        src_lines, tgt_lines = list(src_lines), list(tgt_lines)
        

        # Extract representative language code for logging
        lang_code = list(set(t.strip() for t in tgt_lines))[0]
        self.log.info(f"Sampled {self.sample_dataset_share * 100:.1f}% of dataset: {num_samples} lines.")

        # Build batches
        batch_size = 1000
        if self.is_gen_llm:
            batches = [
                (self.prompt_template, src_lines[i:i + batch_size], tgt_lines[i:i + batch_size],
                self.max_seq_length, 0.5, self.is_train)
                for i in range(0, len(src_lines), batch_size)
            ]
            with Pool(self.num_workers) as pool:
                all_results = pool.map(LanguageIdentificationDataset.process_batch_gen_llm, batches)
            flat = [x for batch in all_results for x in batch]
            if flat:
                src_out, tgt_out = zip(*flat)
                self.src_data.extend(src_out)
                self.tgt_data.extend(tgt_out)
        else:
            class_id_fn = functools.partial(self._get_class_id_from_lang_code)
            batches = [
                (src_lines[i:i + batch_size], tgt_lines[i:i + batch_size],
                self.max_seq_length, 0.5)
                for i in range(0, len(src_lines), batch_size)
            ]
            with Pool(self.num_workers) as pool:
                all_results = pool.map(LanguageIdentificationDataset.process_batch, batches)
            flat = [x for batch in all_results for x in batch]
            if flat:
                src_out, tgt_out = zip(*flat)
                self.src_data.extend(src_out)
                self.tgt_data.extend(tgt_out)

        return lang_code, self.src_data, self.tgt_data


    def _validate_and_load_file_data(self):
        """
        validates, loads and processes data
        :return: None
        """
        # filename_match_threshold = 0.99
        src_files_list = []
        tgt_files_list = []

        for lang_dir in os.listdir(self.data_dir):
            self.log.info(f"Now processing {os.path.join(self.data_dir, lang_dir)} directory.")
            src_data_dir = os.path.join(self.data_dir, lang_dir, 'src')
            tgt_data_dir = os.path.join(self.data_dir, lang_dir, 'tgt')
            for src_file in os.listdir(src_data_dir):
                matched = False
                for tgt_file in os.listdir(tgt_data_dir):
                    # sim_score = self._similar_name(src_file, tgt_file)
                    # if sim_score >= filename_match_threshold:
                    if src_file.split(".")[0] == tgt_file.split(".")[0]:
                        src_files_list.append(src_file)
                        tgt_files_list.append(tgt_file)
                        matched = True
                        break
                if matched:
                    continue  # continue to next loop
                else:
                    self.log.info(f"Skipping file {src_file} since matching label file not found in {tgt_data_dir}.")
            # Validate files and content
            src_filtered_files = [os.path.join(src_data_dir, file) for file in src_files_list if
                                  os.path.isfile(os.path.join(src_data_dir, file))]
            tgt_filtered_files = [os.path.join(tgt_data_dir, file) for file in tgt_files_list if
                                  os.path.isfile(os.path.join(tgt_data_dir, file))]
            if len(src_filtered_files) != len(tgt_filtered_files):
                msg_err_num_files = f"Number of files in {src_data_dir} is {len(src_filtered_files)} does not match" \
                                    f"with {len(tgt_filtered_files)} files present in {tgt_data_dir}"
                raise ValueError(msg_err_num_files)
            else:
                for src_file, tgt_file in zip(src_filtered_files, tgt_filtered_files):
                    new_src_file_lines = []
                    new_tgt_file_lines = []
                    src_num_lines = sum(1 for _ in open(src_file))
                    tgt_num_lines = sum(1 for _ in open(tgt_file))
                    src_num_lines = src_num_lines - 1 if self.files_have_header else src_num_lines
                    tgt_num_lines = tgt_num_lines - 1 if self.files_have_header else tgt_num_lines
                    if src_num_lines != tgt_num_lines:
                        self.log.info(f"{src_num_lines} lines in {src_file} "
                                      f"do not match with {tgt_num_lines} in {tgt_file}, skipping processing these files")
                    else:
                        self.log.info(f"Processing {src_file} and {tgt_file} with {tgt_num_lines} samples.")
                        lang_code, new_src_file_lines , new_tgt_file_lines = self._process_file_data(src_file, tgt_file)
                            
                        # num_of_samples_to_use = int(len(new_src_file_lines) * self.sample_dataset_share)

                        # # Randomly select some share of data from the list
                        # new_src_file_lines = random.sample(new_src_file_lines, num_of_samples_to_use)
                        # new_tgt_file_lines = random.sample(new_tgt_file_lines, num_of_samples_to_use)
                        # self.log.info(f"Sampled {self.sample_dataset_share*100} percent of this dataset")

                        # any further preprocessing here and then append
                        self.src_data.extend(new_src_file_lines)
                        self.tgt_data.extend(new_tgt_file_lines)
                        
                        if self.is_train:
                            if lang_code not in self.file_stats:
                                self.file_stats.update({lang_code : [{"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)}]})
                            else:
                                self.file_stats[lang_code].append({"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)})
                        self.log.info(f"Files {src_file} and {tgt_file} have {len(new_tgt_file_lines)} samples after processing.")



