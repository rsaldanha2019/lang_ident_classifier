# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_data_module
# @Time             : 19/12/23 12:11 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import math
import os
import random
from typing import Any
import lightning as pl
import numpy as np
from lightning.pytorch.utilities.data import DataLoader
from lightning.pytorch.utilities.types import TRAIN_DATALOADERS, EVAL_DATALOADERS
from torch.utils.data import DistributedSampler, SequentialSampler
import torch
import torch.utils
import torch.utils.data
import torch.utils.data.distributed
from torch.nn.utils.rnn import pad_sequence
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset
from lang_ident_classifier.language.dataset.language_identification_custom_data_sampler import CustomGroupBySampleDistributedSampler

class LanguageIdentificationDataModule(pl.LightningDataModule):
    """
    contains methods for dataloader operations for
    the lightning data module
    """
    def __init__(self,
                 train_dataset: LanguageIdentificationDataset = None,
                 val_dataset: LanguageIdentificationDataset = None,
                 test_dataset: LanguageIdentificationDataset = None,
                 predict_dataset: LanguageIdentificationDataset = None,
                 is_gen_llm: bool = False,
                 batch_size: int = 8,
                 num_workers: int = 2,
                 tokenizer: Any = None,
                 train_data_shuffle: bool = True,
                 random_seed: int = 20):
        super(LanguageIdentificationDataModule, self).__init__()
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        np.random.seed(random_seed)
        self.random_seed = random_seed
        self.tokenizer = tokenizer
        self.is_gen_llm = is_gen_llm
        if self.is_gen_llm:
            #TODO: REMOVE THIS HARDCODING
            if not self.tokenizer.pad_token_id:
                self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|> 
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.test_dataset = test_dataset
        self.predict_dataset = predict_dataset
        self.batch_size = batch_size
        # self.num_workers = math.ceil(os.cpu_count()*0.4) # uses 40% of cpus available
        self.num_workers = num_workers
        self.train_data_shuffle = train_data_shuffle
        self.gen = torch.Generator()
        self.gen.manual_seed(random_seed)
    
    def worker_init_fn(self, worker_id):
        # np.random.seed(self.random_seed + worker_id)  # Use the global seed for initialization
        worker_seed = self.random_seed + worker_id
        np.random.seed(worker_seed)
        random.seed(worker_seed)
    
    def train_dataloader(self) -> TRAIN_DATALOADERS:
        """
        using the class instance params, creates a
        train dataloader instance
        :return: train dataloader instance
        """
        if self.train_dataset is None:
            return None

        if torch.distributed.is_initialized():
            sampler = CustomGroupBySampleDistributedSampler(
                            self.train_dataset,
                            shuffle=self.train_data_shuffle,     # keep validation deterministic
                            drop_last=False,
                            seed=self.random_seed,
                        )
            shuffle = None
        else:
            sampler = None
            shuffle = self.train_data_shuffle

        if self.train_dataset is not None:
            return DataLoader(self.train_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.num_workers,
                              persistent_workers=True if self.num_workers > 0 else False,
                              shuffle=shuffle,
                              sampler=sampler,
                              worker_init_fn=self.worker_init_fn,
                              collate_fn=self.collate_fn,
                              generator=self.gen,
                              prefetch_factor=self.num_workers*2,
                              pin_memory=True)

    def val_dataloader(self) -> EVAL_DATALOADERS:
        """
        using the class instance params, creates a
        validation dataloader instance
        :return: val dataloader instance
        """
        if torch.distributed.is_initialized():
            sampler = CustomGroupBySampleDistributedSampler(
                            self.val_dataset,
                            shuffle=False,     # keep validation deterministic
                            drop_last=False,
                            seed=self.random_seed,
                        )
        else:
            sampler = None
        # sampler = SequentialSampler(self.val_dataset)

        if self.val_dataset is not None:
            dataloader = DataLoader(
                self.val_dataset,
                batch_size=self.batch_size,
                num_workers=self.num_workers,
                persistent_workers=True if self.num_workers > 0 else False,
                shuffle=False,
                sampler=sampler,
                worker_init_fn=self.worker_init_fn,
                collate_fn=self.collate_fn,
                generator=self.gen,
                prefetch_factor=self.num_workers*2,
                pin_memory=True
            )
            return dataloader

    def test_dataloader(self) -> EVAL_DATALOADERS:
        """
        Creates a test DataLoader that handles both single-device and multi-device setups dynamically.
        """
        is_single_device = torch.cuda.device_count() <= 1 or not torch.distributed.is_initialized()
        
        sampler = None
        if torch.distributed.is_initialized():
            sampler = CustomGroupBySampleDistributedSampler(
                            self.test_dataset,
                            shuffle=False,     # keep validation deterministic
                            drop_last=False,
                            seed=self.random_seed,
            )
        
        if self.test_dataset is not None:
            dataloader = DataLoader(
                self.test_dataset,
                batch_size=self.batch_size,
                num_workers=self.num_workers,
                persistent_workers=True if self.num_workers > 0 else False,
                shuffle=False,
                sampler=sampler,
                worker_init_fn=self.worker_init_fn,
                collate_fn=self.collate_fn,
                generator=self.gen,
                prefetch_factor=self.num_workers*2,
                pin_memory=True
            )
            return dataloader
        else:
            return None

    def predict_dataloader(self) -> EVAL_DATALOADERS:
        """
        using the class instance params, creates a
        predict dataloader instance
        :return: predict data loader instance
        """
        if self.predict_dataset is not None:
            return DataLoader(self.predict_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.num_workers,
                              persistent_workers=True if self.num_workers > 0 else False,
                              shuffle=False,
                              collate_fn=self.collate_fn,
                              worker_init_fn=self.worker_init_fn,
                              generator=self.gen)


    def collate_fn(self, batch):
        lang_codes = [item["lang_code"] for item in batch]
        input_ids = [item["input_ids"] for item in batch]
        labels = [item["labels"] for item in batch]
        sample_ids = [item["sample_id"] for item in batch]
        chunk_ids = [item["chunk_id"] for item in batch]
        word_positions = [item["word_positions"] for item in batch]
        num_chunks = [item["num_chunks"] for item in batch]
        if "prompt_len" in batch[0]:
            prompt_len = [item["prompt_len"] for item in batch]
        else:
            prompt_len = None

        # Pad sequences to the max length in the batch
        if self.is_gen_llm:
            pad_token_id = self.tokenizer.pad_token_id or self.tokenizer.eos_token_id
            input_ids_padded = pad_sequence(input_ids, batch_first=True, padding_value=pad_token_id)
            labels_padded = pad_sequence(labels, batch_first=True, padding_value=-100)
        else:
            pad_token_id = self.tokenizer.pad_token_id
            input_ids_padded = pad_sequence(input_ids, batch_first=True, padding_value=pad_token_id)
            labels_padded = pad_sequence(labels, batch_first=True, padding_value=-100)

        return {
            "lang_codes": lang_codes,
            "input_ids": input_ids_padded,
            "labels": labels_padded,
            "sample_ids": sample_ids,
            "chunk_ids": chunk_ids,
            "word_positions": word_positions,
            "prompt_lens": prompt_len,
            "num_chunks": num_chunks,
        }