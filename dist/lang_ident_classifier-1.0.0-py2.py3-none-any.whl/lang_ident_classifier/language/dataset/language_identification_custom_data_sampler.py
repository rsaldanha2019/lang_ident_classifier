# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_custom_data_sampler.py
# @Time             : 2025-10-23 13:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _f052279a22cb
from _f052279a22cb._a43685f54e21._950dd9328858 import _24b5c03f6822
from typing import _e3e9d7b1d6ae, _0bba50a637ed, _98b3b700e346, _68520fa4e9c6


class _ce96ac351d06(_24b5c03f6822[_a5846a2d4d7e]):
    """
    Distributed sampler that assigns *all chunks* belonging to the same `sample_id`
    to the same rank. This avoids splitting a logical sample across multiple ranks
    and keeps chunk-group integrity during distributed training.

    Key guarantees:
      * All chunks for a single sample_id are yielded by the same rank.
      * Each rank receives roughly the same number of sample groups. If needed,
        groups are duplicated to ensure equal-length iterables across ranks
        (prevents starvation when using DistributedDataParallel).
      * Supports optional shuffling deterministic by (seed + epoch).

    Usage example
    -------------
    >>> sampler = CustomGroupBySampleDistributedSampler(dataset, shuffle=True, seed=42)
    >>> dataloader = torch.utils.data.DataLoader(dataset, sampler=sampler, ...)
    >>> for epoch in range(epochs):
    ...     sampler.set_epoch(epoch)
    ...     for batch in dataloader:
    ...         ...

    Notes
    -----
    - `dataset` is expected to be indexable (len(dataset) and dataset[i]) and each item
      must be a mapping that contains at least the keys: "sample_id" and "chunk_id".
    - The internal algorithm preserves your original final `__iter__` behavior.
    - This sampler returns an iterator of dataset indices (ints).

    Exceptions
    ----------
    RuntimeError
        Raised if `dataset` length is zero or items do not contain required keys.
    """

    def _f8a06962e641(
        self,
        _cb3b9aa0d83a,
        _4ca5f1af0e9c: _68520fa4e9c6[_a5846a2d4d7e] = _1b0d5fac3d9b,
        _659e35b5e081: _68520fa4e9c6[_a5846a2d4d7e] = _1b0d5fac3d9b,
        _f9e91126bc37: _bd75b8d1fbdc = _84cde4f636f5,
        _2b4c21ca1f7c: _a5846a2d4d7e = 0,
        _26adb9b2c2b9: _bd75b8d1fbdc = _84cde4f636f5,
    ) -> _1b0d5fac3d9b:
        """
        Initialize sampler.

        Parameters
        ----------
        dataset:
            Indexable dataset where each element is a mapping containing keys
            "sample_id" and "chunk_id". Example: dataset[i]["sample_id"] -> int.
        num_replicas:
            Number of distributed replicas (world size). If None and distributed
            is initialized, this will be read from torch.distributed.
        rank:
            The rank of the current process. If None and distributed is initialized,
            this will be read from torch.distributed.
        shuffle:
            Whether to shuffle sample groups each epoch (deterministic using seed+epoch).
        seed:
            Base seed for shuffling (combined with epoch).
        drop_last:
            Not used by the current algorithm, kept for API compatibility.
        """
        # Determine distributed configuration (or fallback to single-process)
        if _f052279a22cb._bb4561d85aba._3aa34ab5c177() and _f052279a22cb._bb4561d85aba._c4d2ae61f3b1():
            if _4ca5f1af0e9c is _1b0d5fac3d9b:
                _4ca5f1af0e9c = _f052279a22cb._bb4561d85aba._f4ab413e2647()
            if _659e35b5e081 is _1b0d5fac3d9b:
                _659e35b5e081 = _f052279a22cb._bb4561d85aba._7e553c28275d()
        else:
            _4ca5f1af0e9c = 1
            _659e35b5e081 = 0

        # Basic arg validation
        if _4ca5f1af0e9c is _1b0d5fac3d9b or _659e35b5e081 is _1b0d5fac3d9b:
            raise _d6b33c6d32fc("Failed to determine num_replicas/rank; please pass them explicitly when not using torch.distributed.")

        self._cb3b9aa0d83a = _cb3b9aa0d83a
        self._4ca5f1af0e9c = _a5846a2d4d7e(_4ca5f1af0e9c)
        self._659e35b5e081 = _a5846a2d4d7e(_659e35b5e081)
        self._f9e91126bc37 = _bd75b8d1fbdc(_f9e91126bc37)
        self._2b4c21ca1f7c = _a5846a2d4d7e(_2b4c21ca1f7c)
        self._26adb9b2c2b9 = _bd75b8d1fbdc(_26adb9b2c2b9)
        self._7f79e80e4e79 = 0

        # Validate dataset has length
        try:
            _0ee699dcdd51 = _3874271ad2bb(_cb3b9aa0d83a)
        except _19cbc9fbec35 as _666bd7d4972b:
            raise _d6b33c6d32fc("Dataset must be sized (implement __len__).") from _666bd7d4972b

        if _0ee699dcdd51 == 0:
            raise _d6b33c6d32fc("Dataset is empty; cannot create sampler for zero-length dataset.")

        # Group dataset indices by sample_id
        # Expected dataset[i] to be a mapping containing "sample_id" and "chunk_id"
        self._2f89ed9ac8f3: _e3e9d7b1d6ae[_a5846a2d4d7e, _98b3b700e346[_a5846a2d4d7e]] = {}
        for _1f89279e9b9c in _82d9443d7cf1(_0ee699dcdd51):
            try:
                _a7ad1565ff02 = _a5846a2d4d7e(_cb3b9aa0d83a[_1f89279e9b9c]["sample_id"])
            except _19cbc9fbec35 as _666bd7d4972b:
                raise _d6b33c6d32fc(
                    f"Dataset element at index {_1f89279e9b9c} must be a mapping with key 'sample_id'."
                ) from _666bd7d4972b
            self._2f89ed9ac8f3._13b54112fa41(_a7ad1565ff02, [])._b6379fd5c7f1(_1f89279e9b9c)

        # Sort chunk indices per sample by chunk_id when available (best-effort)
        for _a7ad1565ff02, _53ec337033a1 in self._2f89ed9ac8f3._8ea5cccafb16():
            try:
                # Sort using the dataset's chunk_id for stable ordering
                _53ec337033a1._3dccf4e77327(_6637fa39bd58=lambda _711c6b39c2a5: _cb3b9aa0d83a[_711c6b39c2a5]["chunk_id"])
            except _19cbc9fbec35:
                # Fallback: sort by index if dataset doesn't provide chunk_id or if an error occurs
                _53ec337033a1._3dccf4e77327()

        # Sorted sample id list (deterministic)
        self._e158c22a6eb0: _98b3b700e346[_a5846a2d4d7e] = _a676cab16f5b(self._2f89ed9ac8f3._b10a28edcce5())

        # total number of raw chunks in dataset
        self._2bd7c83e1eb2 = _0ee699dcdd51

        # Determine per-rank sample count target.
        # The original code computed num_samples as a max over partitions;
        # preserve that behavior to avoid changing runtime sampling proportions.
        # Defensive: ensure we don't divide by zero when computing partitions.
        _9d3fdd943531 = _3874271ad2bb(self._e158c22a6eb0)
        if _9d3fdd943531 == 0:
            raise _d6b33c6d32fc("No sample groups found in dataset (no sample_id values).")

        # Compute the maximum number of chunks any rank would receive when assigning
        # contiguous ranges of sample_ids to ranks. This becomes our `num_samples`.
        def _565bfb89ba1d(_fbc1c85860db: _a5846a2d4d7e) -> _a5846a2d4d7e:
            # Partition sample_ids evenly; remainder distributed to first (num_sids % num_replicas) ranks
            _b0995d22078d = _9d3fdd943531 // self._4ca5f1af0e9c
            _ba878a5dd292 = 1 if _fbc1c85860db < (_9d3fdd943531 % self._4ca5f1af0e9c) else 0
            _b920470b9bed = _fbc1c85860db * _b0995d22078d + _e9d7573eab75(_fbc1c85860db, _9d3fdd943531 % self._4ca5f1af0e9c)
            _3295cd4566a9 = _b920470b9bed + _b0995d22078d + _ba878a5dd292
            # sum chunk counts for that partition
            return _b11c3a9f83ec(_3874271ad2bb(self._2f89ed9ac8f3[self._e158c22a6eb0[_b57f701843be]]) for _b57f701843be in _82d9443d7cf1(_b920470b9bed, _e9d7573eab75(_3295cd4566a9, _9d3fdd943531)))

        _7a0167bc64b7 = _03fb4ce5b577(_12edad91dfd4(_fbc1c85860db) for _fbc1c85860db in _82d9443d7cf1(self._4ca5f1af0e9c))
        self._46c6c537e3e5 = _a5846a2d4d7e(_7a0167bc64b7)

    def _efbefce4179e(self) -> _0bba50a637ed[_a5846a2d4d7e]:
        """
        Produce an iterator of dataset indices for the current rank and epoch.

        Behavior (preserves original algorithm):
          - Build a list of sample_ids and optionally shuffle them using (seed + epoch).
          - Partition sample_ids by contiguous blocks to each rank.
          - For the current rank, collect all chunk indices for its sample groups.
          - If a rank has fewer chunks than the target `chunks_per_rank`, duplicate
            groups from its assigned set (round-robin) until the length reaches the target.
          - Return an iterator over the resulting list of indices.

        Returns
        -------
        Iterator[int]
            Iterator yielding dataset indices in the order chosen for the current rank.

        Raises
        ------
        RuntimeError
            If the sampler cannot construct a valid index list (e.g. no sample groups).
        """
        # Deterministic generator for shuffling per epoch
        _722236f75a78 = _f052279a22cb._405fe9ea49f7()
        _722236f75a78._043ffb9a18ca(self._2b4c21ca1f7c + self._7f79e80e4e79)

        # Prepare sequence of sample ids
        _55cf6bbfec71 = _99ee7c2fbc08(self._e158c22a6eb0)
        if self._f9e91126bc37:
            _09f1aad9e069 = _f052279a22cb._7226e8d1d4c5(_3874271ad2bb(_55cf6bbfec71), _f6ef66fa6d97=_722236f75a78)._03632c4b7615()
            _55cf6bbfec71 = [_55cf6bbfec71[_b57f701843be] for _b57f701843be in _09f1aad9e069]

        _af3f134d46a8 = _3874271ad2bb(_55cf6bbfec71)

        # Partition sample_ids among ranks by contiguous blocks.
        # This mirrors the partition logic used in num_samples calculation.
        _6f7a2beb79ea = _af3f134d46a8 // self._4ca5f1af0e9c
        _aa0058c2ba4c = _af3f134d46a8 % self._4ca5f1af0e9c
        _1454ddf862b1 = self._659e35b5e081 * _6f7a2beb79ea + _e9d7573eab75(self._659e35b5e081, _aa0058c2ba4c)
        _63513c465db3 = _1454ddf862b1 + _6f7a2beb79ea + (1 if self._659e35b5e081 < _aa0058c2ba4c else 0)

        _720860a441f9 = _55cf6bbfec71[_1454ddf862b1:_63513c465db3]

        # Ensure the last rank includes any tail (defensive; should be covered by above)
        if self._659e35b5e081 == self._4ca5f1af0e9c - 1 and _63513c465db3 < _af3f134d46a8:
            _720860a441f9._6ca9d1319a5b(_55cf6bbfec71[_63513c465db3:_af3f134d46a8])

        # Gather indices (all chunks for each assigned sample_id)
        _a4e958d42b83: _98b3b700e346[_a5846a2d4d7e] = []
        for _a7ad1565ff02 in _720860a441f9:
            _a4e958d42b83._6ca9d1319a5b(self._2f89ed9ac8f3[_a7ad1565ff02])

        # Determine the target number of chunks per rank (compute same way as earlier)
        # This chooses the maximum chunk count any rank would have over equal contiguous partitioning.
        def _6b9506503965(_fbc1c85860db: _a5846a2d4d7e) -> _a5846a2d4d7e:
            # reuse logic used during initialization
            _b0995d22078d = _af3f134d46a8 // self._4ca5f1af0e9c
            _ba878a5dd292 = 1 if _fbc1c85860db < (_af3f134d46a8 % self._4ca5f1af0e9c) else 0
            _b920470b9bed = _fbc1c85860db * _b0995d22078d + _e9d7573eab75(_fbc1c85860db, _af3f134d46a8 % self._4ca5f1af0e9c)
            _3295cd4566a9 = _b920470b9bed + _b0995d22078d + _ba878a5dd292
            return _b11c3a9f83ec(_3874271ad2bb(self._2f89ed9ac8f3[self._e158c22a6eb0[_b57f701843be]]) for _b57f701843be in _82d9443d7cf1(_b920470b9bed, _e9d7573eab75(_3295cd4566a9, _af3f134d46a8)))

        _5dc35128d1a7 = _03fb4ce5b577(_bef0bbd01481(_fbc1c85860db) for _fbc1c85860db in _82d9443d7cf1(self._4ca5f1af0e9c))

        # If current rank has fewer chunks than the computed chunks_per_rank, duplicate groups
        # from my_sids round-robin until we reach the target. This balances lengths across ranks.
        _c6f87e1bec72 = _3874271ad2bb(_a4e958d42b83)
        if _c6f87e1bec72 < _5dc35128d1a7:
            if not _720860a441f9:
                raise _d6b33c6d32fc("No sample groups assigned to this rank; cannot duplicate to reach target chunk count.")
            _b57f701843be = 0
            while _c6f87e1bec72 < _5dc35128d1a7:
                _a7ad1565ff02 = _720860a441f9[_b57f701843be % _3874271ad2bb(_720860a441f9)]
                _a4e958d42b83._6ca9d1319a5b(self._2f89ed9ac8f3[_a7ad1565ff02])
                _c6f87e1bec72 += _3874271ad2bb(self._2f89ed9ac8f3[_a7ad1565ff02])
                _b57f701843be += 1

        return _44ddaf79d5c0(_a4e958d42b83)

    def _213ab8acdc2c(self) -> _a5846a2d4d7e:
        """
        Return the target number of indices this sampler will yield for the rank.

        This value is computed during initialization as the maximum chunk-count that any
        rank would receive when partitioning sample groups contiguously. It is used by
        PyTorch internals and DataLoader to determine epoch length for the rank.

        Returns
        -------
        int
            Number of indices expected from this sampler for one epoch.
        """
        return _a5846a2d4d7e(self._46c6c537e3e5)

    def _762b2bb567e7(self, _7f79e80e4e79: _a5846a2d4d7e) -> _1b0d5fac3d9b:
        """
        Set the epoch for this sampler. When `shuffle=True`, this influences the RNG
        used for shuffling sample groups so different epochs see different permutations.

        Parameters
        ----------
        epoch : int
            Epoch number (non-negative).

        Raises
        ------
        RuntimeError
            If epoch is not an integer or is negative.
        """
        if not _8ed7264e6bc3(_7f79e80e4e79, _a5846a2d4d7e) or _7f79e80e4e79 < 0:
            raise _d6b33c6d32fc("epoch must be a non-negative integer.")
        self._7f79e80e4e79 = _a5846a2d4d7e(_7f79e80e4e79)
