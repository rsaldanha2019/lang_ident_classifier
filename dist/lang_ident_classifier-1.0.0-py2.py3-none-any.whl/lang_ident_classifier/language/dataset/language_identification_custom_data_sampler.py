# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_custom_data_sampler.py
# @Time             : 2025-10-23 13:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _cf33e009c7f9
from _cf33e009c7f9._3feeed7bbaab._f6432d4f192f import _061409893028
from typing import _a266d9bba7e5, _b03a3305ca0d, _0c199f025cab, _4951d14dd542


class _492edd1d890d(_061409893028[_71bdc5654066]):
    """
    Distributed sampler that assigns *all chunks* belonging to the same `sample_id`
    to the same rank. This avoids splitting a logical sample across multiple ranks
    and keeps chunk-group integrity during distributed training.

    Key guarantees:
      * All chunks for a single sample_id are yielded by the same rank.
      * Each rank receives roughly the same number of sample groups. If needed,
        groups are duplicated to ensure equal-length iterables across ranks
        (prevents starvation when using DistributedDataParallel).
      * Supports optional shuffling deterministic by (seed + epoch).

    Usage example
    -------------
    >>> sampler = CustomGroupBySampleDistributedSampler(dataset, shuffle=True, seed=42)
    >>> dataloader = torch.utils.data.DataLoader(dataset, sampler=sampler, ...)
    >>> for epoch in range(epochs):
    ...     sampler.set_epoch(epoch)
    ...     for batch in dataloader:
    ...         ...

    Notes
    -----
    - `dataset` is expected to be indexable (len(dataset) and dataset[i]) and each item
      must be a mapping that contains at least the keys: "sample_id" and "chunk_id".
    - The internal algorithm preserves your original final `__iter__` behavior.
    - This sampler returns an iterator of dataset indices (ints).

    Exceptions
    ----------
    RuntimeError
        Raised if `dataset` length is zero or items do not contain required keys.
    """

    def _2299c6f54db8(
        self,
        _97477ff9c735,
        _1d99188bc674: _4951d14dd542[_71bdc5654066] = _e41cbff30797,
        _421228a2651d: _4951d14dd542[_71bdc5654066] = _e41cbff30797,
        _234d9bf9b268: _ca6bede92db9 = _17583970812f,
        _55bd7b1f3281: _71bdc5654066 = 0,
        _32c57dfcb767: _ca6bede92db9 = _17583970812f,
    ) -> _e41cbff30797:
        """
        Initialize sampler.

        Parameters
        ----------
        dataset:
            Indexable dataset where each element is a mapping containing keys
            "sample_id" and "chunk_id". Example: dataset[i]["sample_id"] -> int.
        num_replicas:
            Number of distributed replicas (world size). If None and distributed
            is initialized, this will be read from torch.distributed.
        rank:
            The rank of the current process. If None and distributed is initialized,
            this will be read from torch.distributed.
        shuffle:
            Whether to shuffle sample groups each epoch (deterministic using seed+epoch).
        seed:
            Base seed for shuffling (combined with epoch).
        drop_last:
            Not used by the current algorithm, kept for API compatibility.
        """
        # Determine distributed configuration (or fallback to single-process)
        if _cf33e009c7f9._40fd8e5cc029._80caa4f44a02() and _cf33e009c7f9._40fd8e5cc029._cc3524b4efc7():
            if _1d99188bc674 is _e41cbff30797:
                _1d99188bc674 = _cf33e009c7f9._40fd8e5cc029._8226814a22dc()
            if _421228a2651d is _e41cbff30797:
                _421228a2651d = _cf33e009c7f9._40fd8e5cc029._3efe1b942759()
        else:
            _1d99188bc674 = 1
            _421228a2651d = 0

        # Basic arg validation
        if _1d99188bc674 is _e41cbff30797 or _421228a2651d is _e41cbff30797:
            raise _050a315ce534("Failed to determine num_replicas/rank; please pass them explicitly when not using torch.distributed.")

        self._97477ff9c735 = _97477ff9c735
        self._1d99188bc674 = _71bdc5654066(_1d99188bc674)
        self._421228a2651d = _71bdc5654066(_421228a2651d)
        self._234d9bf9b268 = _ca6bede92db9(_234d9bf9b268)
        self._55bd7b1f3281 = _71bdc5654066(_55bd7b1f3281)
        self._32c57dfcb767 = _ca6bede92db9(_32c57dfcb767)
        self._34e46a78f40b = 0

        # Validate dataset has length
        try:
            _b376a988152f = _34528fd35e27(_97477ff9c735)
        except _d063c34dab14 as _2fb8aa3113b9:
            raise _050a315ce534("Dataset must be sized (implement __len__).") from _2fb8aa3113b9

        if _b376a988152f == 0:
            raise _050a315ce534("Dataset is empty; cannot create sampler for zero-length dataset.")

        # Group dataset indices by sample_id
        # Expected dataset[i] to be a mapping containing "sample_id" and "chunk_id"
        self._df9b8dbd90f4: _a266d9bba7e5[_71bdc5654066, _0c199f025cab[_71bdc5654066]] = {}
        for _38adcf3ef904 in _6fdfd2448d1a(_b376a988152f):
            try:
                _32e9ff1ee45e = _71bdc5654066(_97477ff9c735[_38adcf3ef904]["sample_id"])
            except _d063c34dab14 as _2fb8aa3113b9:
                raise _050a315ce534(
                    f"Dataset element at index {_38adcf3ef904} must be a mapping with key 'sample_id'."
                ) from _2fb8aa3113b9
            self._df9b8dbd90f4._6cd7397eaff7(_32e9ff1ee45e, [])._c55696b2cce7(_38adcf3ef904)

        # Sort chunk indices per sample by chunk_id when available (best-effort)
        for _32e9ff1ee45e, _9eb77cbac10a in self._df9b8dbd90f4._68456ff4319c():
            try:
                # Sort using the dataset's chunk_id for stable ordering
                _9eb77cbac10a._989dd2138038(_f03a65669edc=lambda _07086b777395: _97477ff9c735[_07086b777395]["chunk_id"])
            except _d063c34dab14:
                # Fallback: sort by index if dataset doesn't provide chunk_id or if an error occurs
                _9eb77cbac10a._989dd2138038()

        # Sorted sample id list (deterministic)
        self._3232907fa3e0: _0c199f025cab[_71bdc5654066] = _c0b5c8968fa3(self._df9b8dbd90f4._2849412c7365())

        # total number of raw chunks in dataset
        self._1b76a1007112 = _b376a988152f

        # Determine per-rank sample count target.
        # The original code computed num_samples as a max over partitions;
        # preserve that behavior to avoid changing runtime sampling proportions.
        # Defensive: ensure we don't divide by zero when computing partitions.
        _dca3b46f014b = _34528fd35e27(self._3232907fa3e0)
        if _dca3b46f014b == 0:
            raise _050a315ce534("No sample groups found in dataset (no sample_id values).")

        # Compute the maximum number of chunks any rank would receive when assigning
        # contiguous ranges of sample_ids to ranks. This becomes our `num_samples`.
        def _bf7d16258700(_d037bd90af0a: _71bdc5654066) -> _71bdc5654066:
            # Partition sample_ids evenly; remainder distributed to first (num_sids % num_replicas) ranks
            _21c642b08a24 = _dca3b46f014b // self._1d99188bc674
            _cfdc55c6c309 = 1 if _d037bd90af0a < (_dca3b46f014b % self._1d99188bc674) else 0
            _f72f152d60bf = _d037bd90af0a * _21c642b08a24 + _ab622f1d943d(_d037bd90af0a, _dca3b46f014b % self._1d99188bc674)
            _98326a439d49 = _f72f152d60bf + _21c642b08a24 + _cfdc55c6c309
            # sum chunk counts for that partition
            return _d0230f3a2f37(_34528fd35e27(self._df9b8dbd90f4[self._3232907fa3e0[_db89179803dc]]) for _db89179803dc in _6fdfd2448d1a(_f72f152d60bf, _ab622f1d943d(_98326a439d49, _dca3b46f014b)))

        _db68d7a95ed1 = _357feea45ee1(_4c4c841f9d50(_d037bd90af0a) for _d037bd90af0a in _6fdfd2448d1a(self._1d99188bc674))
        self._5842e5f973a7 = _71bdc5654066(_db68d7a95ed1)

    def _17e921c2fdfd(self) -> _b03a3305ca0d[_71bdc5654066]:
        """
        Produce an iterator of dataset indices for the current rank and epoch.

        Behavior (preserves original algorithm):
          - Build a list of sample_ids and optionally shuffle them using (seed + epoch).
          - Partition sample_ids by contiguous blocks to each rank.
          - For the current rank, collect all chunk indices for its sample groups.
          - If a rank has fewer chunks than the target `chunks_per_rank`, duplicate
            groups from its assigned set (round-robin) until the length reaches the target.
          - Return an iterator over the resulting list of indices.

        Returns
        -------
        Iterator[int]
            Iterator yielding dataset indices in the order chosen for the current rank.

        Raises
        ------
        RuntimeError
            If the sampler cannot construct a valid index list (e.g. no sample groups).
        """
        # Deterministic generator for shuffling per epoch
        _0cdc0e5ce111 = _cf33e009c7f9._98c89b95129e()
        _0cdc0e5ce111._f6efc47e3cb5(self._55bd7b1f3281 + self._34e46a78f40b)

        # Prepare sequence of sample ids
        _6526a9517963 = _7160215dd5dc(self._3232907fa3e0)
        if self._234d9bf9b268:
            _70cb17eba0ef = _cf33e009c7f9._5362265d622b(_34528fd35e27(_6526a9517963), _b03b34b9eb86=_0cdc0e5ce111)._5d8343972adf()
            _6526a9517963 = [_6526a9517963[_db89179803dc] for _db89179803dc in _70cb17eba0ef]

        _74c170467312 = _34528fd35e27(_6526a9517963)

        # Partition sample_ids among ranks by contiguous blocks.
        # This mirrors the partition logic used in num_samples calculation.
        _9738caada5ae = _74c170467312 // self._1d99188bc674
        _3f00ce523205 = _74c170467312 % self._1d99188bc674
        _613cfbd9ac4d = self._421228a2651d * _9738caada5ae + _ab622f1d943d(self._421228a2651d, _3f00ce523205)
        _9edee309da86 = _613cfbd9ac4d + _9738caada5ae + (1 if self._421228a2651d < _3f00ce523205 else 0)

        _53f9c39c5509 = _6526a9517963[_613cfbd9ac4d:_9edee309da86]

        # Ensure the last rank includes any tail (defensive; should be covered by above)
        if self._421228a2651d == self._1d99188bc674 - 1 and _9edee309da86 < _74c170467312:
            _53f9c39c5509._0bf797df964b(_6526a9517963[_9edee309da86:_74c170467312])

        # Gather indices (all chunks for each assigned sample_id)
        _1d89b390876b: _0c199f025cab[_71bdc5654066] = []
        for _32e9ff1ee45e in _53f9c39c5509:
            _1d89b390876b._0bf797df964b(self._df9b8dbd90f4[_32e9ff1ee45e])

        # Determine the target number of chunks per rank (compute same way as earlier)
        # This chooses the maximum chunk count any rank would have over equal contiguous partitioning.
        def _2f62a0665768(_d037bd90af0a: _71bdc5654066) -> _71bdc5654066:
            # reuse logic used during initialization
            _21c642b08a24 = _74c170467312 // self._1d99188bc674
            _cfdc55c6c309 = 1 if _d037bd90af0a < (_74c170467312 % self._1d99188bc674) else 0
            _f72f152d60bf = _d037bd90af0a * _21c642b08a24 + _ab622f1d943d(_d037bd90af0a, _74c170467312 % self._1d99188bc674)
            _98326a439d49 = _f72f152d60bf + _21c642b08a24 + _cfdc55c6c309
            return _d0230f3a2f37(_34528fd35e27(self._df9b8dbd90f4[self._3232907fa3e0[_db89179803dc]]) for _db89179803dc in _6fdfd2448d1a(_f72f152d60bf, _ab622f1d943d(_98326a439d49, _74c170467312)))

        _6a3ad22c232d = _357feea45ee1(_abc60326ea07(_d037bd90af0a) for _d037bd90af0a in _6fdfd2448d1a(self._1d99188bc674))

        # If current rank has fewer chunks than the computed chunks_per_rank, duplicate groups
        # from my_sids round-robin until we reach the target. This balances lengths across ranks.
        _5d991e0040e5 = _34528fd35e27(_1d89b390876b)
        if _5d991e0040e5 < _6a3ad22c232d:
            if not _53f9c39c5509:
                raise _050a315ce534("No sample groups assigned to this rank; cannot duplicate to reach target chunk count.")
            _db89179803dc = 0
            while _5d991e0040e5 < _6a3ad22c232d:
                _32e9ff1ee45e = _53f9c39c5509[_db89179803dc % _34528fd35e27(_53f9c39c5509)]
                _1d89b390876b._0bf797df964b(self._df9b8dbd90f4[_32e9ff1ee45e])
                _5d991e0040e5 += _34528fd35e27(self._df9b8dbd90f4[_32e9ff1ee45e])
                _db89179803dc += 1

        return _abab4aa5f5e6(_1d89b390876b)

    def _6f5967f4510a(self) -> _71bdc5654066:
        """
        Return the target number of indices this sampler will yield for the rank.

        This value is computed during initialization as the maximum chunk-count that any
        rank would receive when partitioning sample groups contiguously. It is used by
        PyTorch internals and DataLoader to determine epoch length for the rank.

        Returns
        -------
        int
            Number of indices expected from this sampler for one epoch.
        """
        return _71bdc5654066(self._5842e5f973a7)

    def _e4b2574837af(self, _34e46a78f40b: _71bdc5654066) -> _e41cbff30797:
        """
        Set the epoch for this sampler. When `shuffle=True`, this influences the RNG
        used for shuffling sample groups so different epochs see different permutations.

        Parameters
        ----------
        epoch : int
            Epoch number (non-negative).

        Raises
        ------
        RuntimeError
            If epoch is not an integer or is negative.
        """
        if not _a021f971fa16(_34e46a78f40b, _71bdc5654066) or _34e46a78f40b < 0:
            raise _050a315ce534("epoch must be a non-negative integer.")
        self._34e46a78f40b = _71bdc5654066(_34e46a78f40b)
