# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_custom_data_sampler.py
# @Time             : 2025-10-23 13:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _155bd69c310e
from _155bd69c310e._1c0feb4edcc7._c3f0c6e7929f import _09e32645a8cb
from typing import _50e683286c7f, _4cbfd519b85d, _c6952e61ac20, _1aa92fe94476


class _075bc6917206(_09e32645a8cb[_093fc6761945]):
    """
    Distributed sampler that assigns *all chunks* belonging to the same `sample_id`
    to the same rank. This avoids splitting a logical sample across multiple ranks
    and keeps chunk-group integrity during distributed training.

    Key guarantees:
      * All chunks for a single sample_id are yielded by the same rank.
      * Each rank receives roughly the same number of sample groups. If needed,
        groups are duplicated to ensure equal-length iterables across ranks
        (prevents starvation when using DistributedDataParallel).
      * Supports optional shuffling deterministic by (seed + epoch).

    Usage example
    -------------
    >>> sampler = CustomGroupBySampleDistributedSampler(dataset, shuffle=True, seed=42)
    >>> dataloader = torch.utils.data.DataLoader(dataset, sampler=sampler, ...)
    >>> for epoch in range(epochs):
    ...     sampler.set_epoch(epoch)
    ...     for batch in dataloader:
    ...         ...

    Notes
    -----
    - `dataset` is expected to be indexable (len(dataset) and dataset[i]) and each item
      must be a mapping that contains at least the keys: "sample_id" and "chunk_id".
    - The internal algorithm preserves your original final `__iter__` behavior.
    - This sampler returns an iterator of dataset indices (ints).

    Exceptions
    ----------
    RuntimeError
        Raised if `dataset` length is zero or items do not contain required keys.
    """

    def _9bf768ff239a(
        self,
        _284b0b1f8cc1,
        _4797255abc64: _1aa92fe94476[_093fc6761945] = _023bb3ae4866,
        _1690b9c7c02f: _1aa92fe94476[_093fc6761945] = _023bb3ae4866,
        _fd5c312060f9: _4387ef1967e8 = _a719f1e75802,
        _132d34ad26a2: _093fc6761945 = 0,
        _114ac9aba85f: _4387ef1967e8 = _a719f1e75802,
    ) -> _023bb3ae4866:
        """
        Initialize sampler.

        Parameters
        ----------
        dataset:
            Indexable dataset where each element is a mapping containing keys
            "sample_id" and "chunk_id". Example: dataset[i]["sample_id"] -> int.
        num_replicas:
            Number of distributed replicas (world size). If None and distributed
            is initialized, this will be read from torch.distributed.
        rank:
            The rank of the current process. If None and distributed is initialized,
            this will be read from torch.distributed.
        shuffle:
            Whether to shuffle sample groups each epoch (deterministic using seed+epoch).
        seed:
            Base seed for shuffling (combined with epoch).
        drop_last:
            Not used by the current algorithm, kept for API compatibility.
        """
        # Determine distributed configuration (or fallback to single-process)
        if _155bd69c310e._b10a10303c98._af95da0548f6() and _155bd69c310e._b10a10303c98._0b3604444347():
            if _4797255abc64 is _023bb3ae4866:
                _4797255abc64 = _155bd69c310e._b10a10303c98._833cb1a70c12()
            if _1690b9c7c02f is _023bb3ae4866:
                _1690b9c7c02f = _155bd69c310e._b10a10303c98._23c697ff5450()
        else:
            _4797255abc64 = 1
            _1690b9c7c02f = 0

        # Basic arg validation
        if _4797255abc64 is _023bb3ae4866 or _1690b9c7c02f is _023bb3ae4866:
            raise _11945b3934ad("Failed to determine num_replicas/rank; please pass them explicitly when not using torch.distributed.")

        self._284b0b1f8cc1 = _284b0b1f8cc1
        self._4797255abc64 = _093fc6761945(_4797255abc64)
        self._1690b9c7c02f = _093fc6761945(_1690b9c7c02f)
        self._fd5c312060f9 = _4387ef1967e8(_fd5c312060f9)
        self._132d34ad26a2 = _093fc6761945(_132d34ad26a2)
        self._114ac9aba85f = _4387ef1967e8(_114ac9aba85f)
        self._09824cfe2100 = 0

        # Validate dataset has length
        try:
            _119ed36702c9 = _6fdd9b6763f5(_284b0b1f8cc1)
        except _185ed3a9d8b3 as _a9a34b130571:
            raise _11945b3934ad("Dataset must be sized (implement __len__).") from _a9a34b130571

        if _119ed36702c9 == 0:
            raise _11945b3934ad("Dataset is empty; cannot create sampler for zero-length dataset.")

        # Group dataset indices by sample_id
        # Expected dataset[i] to be a mapping containing "sample_id" and "chunk_id"
        self._6fa7b53a4231: _50e683286c7f[_093fc6761945, _c6952e61ac20[_093fc6761945]] = {}
        for _3f14ab9cc727 in _f39aaef2dd90(_119ed36702c9):
            try:
                _67f44e5dbf35 = _093fc6761945(_284b0b1f8cc1[_3f14ab9cc727]["sample_id"])
            except _185ed3a9d8b3 as _a9a34b130571:
                raise _11945b3934ad(
                    f"Dataset element at index {_3f14ab9cc727} must be a mapping with key 'sample_id'."
                ) from _a9a34b130571
            self._6fa7b53a4231._012aaa599f32(_67f44e5dbf35, [])._52df9594b85f(_3f14ab9cc727)

        # Sort chunk indices per sample by chunk_id when available (best-effort)
        for _67f44e5dbf35, _7126f22e8699 in self._6fa7b53a4231._d2b7c3a7840c():
            try:
                # Sort using the dataset's chunk_id for stable ordering
                _7126f22e8699._83bebd3d93f4(_1e8784d95c87=lambda _aa50850d13a4: _284b0b1f8cc1[_aa50850d13a4]["chunk_id"])
            except _185ed3a9d8b3:
                # Fallback: sort by index if dataset doesn't provide chunk_id or if an error occurs
                _7126f22e8699._83bebd3d93f4()

        # Sorted sample id list (deterministic)
        self._cc432601ae4d: _c6952e61ac20[_093fc6761945] = _cf39e610b184(self._6fa7b53a4231._0efaae230f32())

        # total number of raw chunks in dataset
        self._b266a275c7f2 = _119ed36702c9

        # Determine per-rank sample count target.
        # The original code computed num_samples as a max over partitions;
        # preserve that behavior to avoid changing runtime sampling proportions.
        # Defensive: ensure we don't divide by zero when computing partitions.
        _5148d15a7ded = _6fdd9b6763f5(self._cc432601ae4d)
        if _5148d15a7ded == 0:
            raise _11945b3934ad("No sample groups found in dataset (no sample_id values).")

        # Compute the maximum number of chunks any rank would receive when assigning
        # contiguous ranges of sample_ids to ranks. This becomes our `num_samples`.
        def _47a26b44ae41(_93dc0ba9d4e8: _093fc6761945) -> _093fc6761945:
            # Partition sample_ids evenly; remainder distributed to first (num_sids % num_replicas) ranks
            _7cda7f192697 = _5148d15a7ded // self._4797255abc64
            _23dd457af6b3 = 1 if _93dc0ba9d4e8 < (_5148d15a7ded % self._4797255abc64) else 0
            _fd38e34a31ff = _93dc0ba9d4e8 * _7cda7f192697 + _44acbd7b663c(_93dc0ba9d4e8, _5148d15a7ded % self._4797255abc64)
            _ee7d479f94a5 = _fd38e34a31ff + _7cda7f192697 + _23dd457af6b3
            # sum chunk counts for that partition
            return _a90c74511e49(_6fdd9b6763f5(self._6fa7b53a4231[self._cc432601ae4d[_378758ca8e5c]]) for _378758ca8e5c in _f39aaef2dd90(_fd38e34a31ff, _44acbd7b663c(_ee7d479f94a5, _5148d15a7ded)))

        _2a371344c088 = _6cbd26e368e8(_65b3e7bbc421(_93dc0ba9d4e8) for _93dc0ba9d4e8 in _f39aaef2dd90(self._4797255abc64))
        self._dbf99a65fe99 = _093fc6761945(_2a371344c088)

    def _2e02c77c7271(self) -> _4cbfd519b85d[_093fc6761945]:
        """
        Produce an iterator of dataset indices for the current rank and epoch.

        Behavior (preserves original algorithm):
          - Build a list of sample_ids and optionally shuffle them using (seed + epoch).
          - Partition sample_ids by contiguous blocks to each rank.
          - For the current rank, collect all chunk indices for its sample groups.
          - If a rank has fewer chunks than the target `chunks_per_rank`, duplicate
            groups from its assigned set (round-robin) until the length reaches the target.
          - Return an iterator over the resulting list of indices.

        Returns
        -------
        Iterator[int]
            Iterator yielding dataset indices in the order chosen for the current rank.

        Raises
        ------
        RuntimeError
            If the sampler cannot construct a valid index list (e.g. no sample groups).
        """
        # Deterministic generator for shuffling per epoch
        _5c7211f47243 = _155bd69c310e._b41fea4fa711()
        _5c7211f47243._2931c81fd4ef(self._132d34ad26a2 + self._09824cfe2100)

        # Prepare sequence of sample ids
        _19bf3dcef820 = _62f3c737eaef(self._cc432601ae4d)
        if self._fd5c312060f9:
            _5ccb985694f2 = _155bd69c310e._e64fed9e5606(_6fdd9b6763f5(_19bf3dcef820), _7e0c7649847b=_5c7211f47243)._f29c8cac0752()
            _19bf3dcef820 = [_19bf3dcef820[_378758ca8e5c] for _378758ca8e5c in _5ccb985694f2]

        _4ea9c7bde1c4 = _6fdd9b6763f5(_19bf3dcef820)

        # Partition sample_ids among ranks by contiguous blocks.
        # This mirrors the partition logic used in num_samples calculation.
        _eaa8c2760f25 = _4ea9c7bde1c4 // self._4797255abc64
        _ebfeb7620a84 = _4ea9c7bde1c4 % self._4797255abc64
        _858ac3431476 = self._1690b9c7c02f * _eaa8c2760f25 + _44acbd7b663c(self._1690b9c7c02f, _ebfeb7620a84)
        _a613fb0f1188 = _858ac3431476 + _eaa8c2760f25 + (1 if self._1690b9c7c02f < _ebfeb7620a84 else 0)

        _39dcb642744f = _19bf3dcef820[_858ac3431476:_a613fb0f1188]

        # Ensure the last rank includes any tail (defensive; should be covered by above)
        if self._1690b9c7c02f == self._4797255abc64 - 1 and _a613fb0f1188 < _4ea9c7bde1c4:
            _39dcb642744f._50b283d1fa47(_19bf3dcef820[_a613fb0f1188:_4ea9c7bde1c4])

        # Gather indices (all chunks for each assigned sample_id)
        _eae3d8a94a35: _c6952e61ac20[_093fc6761945] = []
        for _67f44e5dbf35 in _39dcb642744f:
            _eae3d8a94a35._50b283d1fa47(self._6fa7b53a4231[_67f44e5dbf35])

        # Determine the target number of chunks per rank (compute same way as earlier)
        # This chooses the maximum chunk count any rank would have over equal contiguous partitioning.
        def _c984a2c30d14(_93dc0ba9d4e8: _093fc6761945) -> _093fc6761945:
            # reuse logic used during initialization
            _7cda7f192697 = _4ea9c7bde1c4 // self._4797255abc64
            _23dd457af6b3 = 1 if _93dc0ba9d4e8 < (_4ea9c7bde1c4 % self._4797255abc64) else 0
            _fd38e34a31ff = _93dc0ba9d4e8 * _7cda7f192697 + _44acbd7b663c(_93dc0ba9d4e8, _4ea9c7bde1c4 % self._4797255abc64)
            _ee7d479f94a5 = _fd38e34a31ff + _7cda7f192697 + _23dd457af6b3
            return _a90c74511e49(_6fdd9b6763f5(self._6fa7b53a4231[self._cc432601ae4d[_378758ca8e5c]]) for _378758ca8e5c in _f39aaef2dd90(_fd38e34a31ff, _44acbd7b663c(_ee7d479f94a5, _4ea9c7bde1c4)))

        _d6393ce4fbfd = _6cbd26e368e8(_4a797456966d(_93dc0ba9d4e8) for _93dc0ba9d4e8 in _f39aaef2dd90(self._4797255abc64))

        # If current rank has fewer chunks than the computed chunks_per_rank, duplicate groups
        # from my_sids round-robin until we reach the target. This balances lengths across ranks.
        _0bd9c284ca44 = _6fdd9b6763f5(_eae3d8a94a35)
        if _0bd9c284ca44 < _d6393ce4fbfd:
            if not _39dcb642744f:
                raise _11945b3934ad("No sample groups assigned to this rank; cannot duplicate to reach target chunk count.")
            _378758ca8e5c = 0
            while _0bd9c284ca44 < _d6393ce4fbfd:
                _67f44e5dbf35 = _39dcb642744f[_378758ca8e5c % _6fdd9b6763f5(_39dcb642744f)]
                _eae3d8a94a35._50b283d1fa47(self._6fa7b53a4231[_67f44e5dbf35])
                _0bd9c284ca44 += _6fdd9b6763f5(self._6fa7b53a4231[_67f44e5dbf35])
                _378758ca8e5c += 1

        return _ad4c8f0049ac(_eae3d8a94a35)

    def _48b69ae6d8f8(self) -> _093fc6761945:
        """
        Return the target number of indices this sampler will yield for the rank.

        This value is computed during initialization as the maximum chunk-count that any
        rank would receive when partitioning sample groups contiguously. It is used by
        PyTorch internals and DataLoader to determine epoch length for the rank.

        Returns
        -------
        int
            Number of indices expected from this sampler for one epoch.
        """
        return _093fc6761945(self._dbf99a65fe99)

    def _572e47f64a7c(self, _09824cfe2100: _093fc6761945) -> _023bb3ae4866:
        """
        Set the epoch for this sampler. When `shuffle=True`, this influences the RNG
        used for shuffling sample groups so different epochs see different permutations.

        Parameters
        ----------
        epoch : int
            Epoch number (non-negative).

        Raises
        ------
        RuntimeError
            If epoch is not an integer or is negative.
        """
        if not _6ff10ada16d8(_09824cfe2100, _093fc6761945) or _09824cfe2100 < 0:
            raise _11945b3934ad("epoch must be a non-negative integer.")
        self._09824cfe2100 = _093fc6761945(_09824cfe2100)
