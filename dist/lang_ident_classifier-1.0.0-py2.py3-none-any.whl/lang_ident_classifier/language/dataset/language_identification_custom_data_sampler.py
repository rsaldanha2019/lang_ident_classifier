import math
import torch
from torch.utils.data import Sampler

class CustomGroupBySampleDistributedSampler(Sampler[int]):
    """
    DDP/FSDP-safe sampler that assigns all chunks of the same sample_id
    to the same rank. Ensures no sample_id is split across ranks.
    Each rank yields exactly the same number of indices (padding with
    repeated groups if needed), avoiding starvation.
    """

    def __init__(self, dataset, num_replicas=None, rank=None,
                 shuffle: bool = False, seed: int = 0, drop_last: bool = False):
        # --- determine replicas and rank ---
        if torch.distributed.is_available() and torch.distributed.is_initialized():
            if num_replicas is None:
                num_replicas = torch.distributed.get_world_size()
            if rank is None:
                rank = torch.distributed.get_rank()
        else:
            # pure single-process fallback
            num_replicas = 1
            rank = 0

        self.dataset = dataset
        self.num_replicas = num_replicas
        self.rank = rank
        self.shuffle = shuffle
        self.seed = seed
        self.drop_last = drop_last
        self.epoch = 0

        # group dataset indices by sample_id
        self.sample_to_idxs = {}
        for idx in range(len(dataset)):
            sid = int(dataset[idx]["sample_id"])
            self.sample_to_idxs.setdefault(sid, []).append(idx)

        for sid, idxs in self.sample_to_idxs.items():
            try:
                idxs.sort(key=lambda k: dataset[k]["chunk_id"])
            except Exception:
                idxs.sort()

        self.sample_ids = sorted(self.sample_to_idxs.keys())

        self.total_size = len(dataset)

        # if self.drop_last:
        #     self.num_samples = self.total_size // self.num_replicas
        # else:
        #     self.num_samples = math.ceil(self.total_size / self.num_replicas)
        max_samples = max(sum(len(self.sample_to_idxs[sid]) for sid in self.sample_ids[r * (len(self.sample_ids) // self.num_replicas):(r + 1) * (len(self.sample_ids) // self.num_replicas) + (1 if r < len(self.sample_ids) % self.num_replicas else 0)]) for r in range(self.num_replicas))
        self.num_samples = max_samples

    # def __iter__(self):
    #     g = torch.Generator()
    #     g.manual_seed(self.seed + self.epoch)

    #     sids = list(self.sample_ids)
    #     if self.shuffle:
    #         perm = torch.randperm(len(sids), generator=g).tolist()
    #         sids = [sids[i] for i in perm]

    #     partitions = [[] for _ in range(self.num_replicas)]
    #     for i, sid in enumerate(sids):
    #         partitions[i % self.num_replicas].append(sid)

    #     my_sids = partitions[self.rank]

    #     indices = []
    #     for sid in my_sids:
    #         indices.extend(self.sample_to_idxs[sid])

    #     if len(indices) < self.num_samples:
    #         i = 0
    #         while len(indices) < self.num_samples:
    #             sid = my_sids[i % len(my_sids)]
    #             indices.extend(self.sample_to_idxs[sid])
    #             i += 1
        
    #     # # DEBUG
    #     # with open(f"sampler_rank{self.rank}_epoch{self.epoch}.txt", "a+") as f:
    #     #     f.write(f"[Rank {self.rank}] {len(my_sids)} groups, {len(indices)} indices\n")
    #     #     f.write(f"Sample IDs: {my_sids}\n")

    #     return iter(indices)

    # def __iter__(self):
    #     g = torch.Generator()
    #     g.manual_seed(self.seed + self.epoch)
    #     sids = list(self.sample_ids)
    #     if self.shuffle:
    #         perm = torch.randperm(len(sids), generator=g).tolist()
    #         sids = [sids[i] for i in perm]
    #     total_chunks = sum(len(self.sample_to_idxs[sid]) for sid in sids)
    #     all_indices = []
    #     for sid in sids:
    #         all_indices.extend(self.sample_to_idxs[sid])
    #     # Distribute chunks across ranks
    #     chunks_per_rank = total_chunks // self.num_replicas + (1 if self.rank < total_chunks % self.num_replicas else 0)
    #     start_idx = sum(total_chunks // self.num_replicas + (1 if r < total_chunks % self.num_replicas else 0) for r in range(self.rank))
    #     end_idx = start_idx + chunks_per_rank
    #     indices = all_indices[start_idx:end_idx]
    #     if len(indices) < self.num_samples:
    #         remaining = self.num_samples - len(indices)
    #         indices.extend(all_indices[:remaining])
    #     indices = indices[:self.num_samples]
    #     return iter(indices)

    def __iter__(self):
        g = torch.Generator()
        g.manual_seed(self.seed + self.epoch)
        sids = list(self.sample_ids)  # 636 unique sample_ids
        if self.shuffle:
            perm = torch.randperm(len(sids), generator=g).tolist()
            sids = [sids[i] for i in perm]
        total_samples = len(sids)  # 636
        samples_per_rank = total_samples // self.num_replicas  # 318
        remainder = total_samples % self.num_replicas  # 0
        start_idx = self.rank * samples_per_rank
        end_idx = start_idx + samples_per_rank + (1 if self.rank < remainder else 0)
        my_sids = sids[start_idx:end_idx]
        # Ensure all samples are included
        if self.rank == self.num_replicas - 1:
            my_sids.extend(sids[end_idx:total_samples])  # Include remaining samples
        indices = []
        for sid in my_sids:
            indices.extend(self.sample_to_idxs[sid])  # All chunks for sample_id
        # Balance with duplicates
        # total_chunks = len(indices)
        # chunks_per_rank = self.total_size // self.num_replicas  # 1756
        # if total_chunks < chunks_per_rank:
        #     i = 0
        #     while total_chunks < chunks_per_rank:
        #         sid = my_sids[i % len(my_sids)]
        #         indices.extend(self.sample_to_idxs[sid])
        #         total_chunks += len(self.sample_to_idxs[sid])
        #         i += 1
        # indices = indices[:self.num_samples]

        total_chunks = len(indices)
        chunks_per_rank = max(sum(len(self.sample_to_idxs[sid]) for sid in self.sample_ids[r * (len(self.sample_ids) // self.num_replicas):(r + 1) * (len(self.sample_ids) // self.num_replicas)]) for r in range(self.num_replicas))
        if total_chunks < chunks_per_rank:
            i = 0
            while total_chunks < chunks_per_rank:
                sid = my_sids[i % len(my_sids)]
                indices.extend(self.sample_to_idxs[sid])
                total_chunks += len(self.sample_to_idxs[sid])
                i += 1
        # # DEBUG
        # with open(f"sampler_rank{self.rank}_epoch{self.epoch}.txt", "a+") as f:
        #     f.write(f"[Rank {self.rank}] {len(my_sids)} groups, {len(indices)} indices\n")
        #     f.write(f"Sample IDs: {my_sids}\n")
        
        return iter(indices)
    
    def __len__(self):
        return self.num_samples

    def set_epoch(self, epoch: int):
        self.epoch = epoch