# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_custom_data_sampler.py
# @Time             : 2025-10-23 13:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _74252b9d8abb
from _74252b9d8abb._9ad8c9cf12f2._70f817dd2261 import _e467a6c18d54
from _59cb7591bc51 import _d0e3c1a6b1a8, _c42be495e2a7, _c2c1b054eeba, _5e0b4bd964ee


class _38e6da6bcd58(_e467a6c18d54[_1ca86fc5843d]):
    """
    Distributed sampler that assigns *all chunks* belonging to the same `sample_id`
    to the same rank. This avoids splitting a logical sample across multiple ranks
    and keeps chunk-group integrity during distributed training.

    Key guarantees:
      * All chunks for a single sample_id are yielded by the same rank.
      * Each rank receives roughly the same number of sample groups. If needed,
        groups are duplicated to ensure equal-length iterables across ranks
        (prevents starvation when using DistributedDataParallel).
      * Supports optional shuffling deterministic by (seed + epoch).

    Usage example
    -------------
    >>> sampler = CustomGroupBySampleDistributedSampler(dataset, shuffle=True, seed=42)
    >>> dataloader = torch.utils.data.DataLoader(dataset, sampler=sampler, ...)
    >>> for epoch in range(epochs):
    ...     sampler.set_epoch(epoch)
    ...     for batch in dataloader:
    ...         ...

    Notes
    -----
    - `dataset` is expected to be indexable (len(dataset) and dataset[i]) and each item
      must be a mapping that contains at least the keys: "sample_id" and "chunk_id".
    - The internal algorithm preserves your original final `__iter__` behavior.
    - This sampler returns an iterator of dataset indices (ints).

    Exceptions
    ----------
    RuntimeError
        Raised if `dataset` length is zero or items do not contain required keys.
    """

    def _29d3fd4dc50b(
        self,
        _31c99b09dfe2,
        _124b69da5634: _5e0b4bd964ee[_1ca86fc5843d] = _a5b3071c1503,
        _d2f5afbf2661: _5e0b4bd964ee[_1ca86fc5843d] = _a5b3071c1503,
        _63c666ff0f41: _3697cc013cf9 = _9ce20172edb0,
        _e512ed6eaf86: _1ca86fc5843d = 0,
        _2aa67fc2ddb1: _3697cc013cf9 = _9ce20172edb0,
    ) -> _a5b3071c1503:
        """
        Initialize sampler.

        Parameters
        ----------
        dataset:
            Indexable dataset where each element is a mapping containing keys
            "sample_id" and "chunk_id". Example: dataset[i]["sample_id"] -> int.
        num_replicas:
            Number of distributed replicas (world size). If None and distributed
            is initialized, this will be read from torch.distributed.
        rank:
            The rank of the current process. If None and distributed is initialized,
            this will be read from torch.distributed.
        shuffle:
            Whether to shuffle sample groups each epoch (deterministic using seed+epoch).
        seed:
            Base seed for shuffling (combined with epoch).
        drop_last:
            Not used by the current algorithm, kept for API compatibility.
        """
        # Determine distributed configuration (or fallback to single-process)
        if _74252b9d8abb._f82a363e09e4._ba0d040005e1() and _74252b9d8abb._f82a363e09e4._893f7a16f58b():
            if _124b69da5634 is _a5b3071c1503:
                _124b69da5634 = _74252b9d8abb._f82a363e09e4._dc415c0f3c07()
            if _d2f5afbf2661 is _a5b3071c1503:
                _d2f5afbf2661 = _74252b9d8abb._f82a363e09e4._028f13b4d667()
        else:
            _124b69da5634 = 1
            _d2f5afbf2661 = 0

        # Basic arg validation
        if _124b69da5634 is _a5b3071c1503 or _d2f5afbf2661 is _a5b3071c1503:
            raise _40a0bca91739("Failed to determine num_replicas/rank; please pass them explicitly when not using torch.distributed.")

        self._31c99b09dfe2 = _31c99b09dfe2
        self._124b69da5634 = _1ca86fc5843d(_124b69da5634)
        self._d2f5afbf2661 = _1ca86fc5843d(_d2f5afbf2661)
        self._63c666ff0f41 = _3697cc013cf9(_63c666ff0f41)
        self._e512ed6eaf86 = _1ca86fc5843d(_e512ed6eaf86)
        self._2aa67fc2ddb1 = _3697cc013cf9(_2aa67fc2ddb1)
        self._688df324a381 = 0

        # Validate dataset has length
        try:
            _54f9e35c45a0 = _fc11d9301f46(_31c99b09dfe2)
        except _a21a93b19665 as _5697453af7c3:
            raise _40a0bca91739("Dataset must be sized (implement __len__).") from _5697453af7c3

        if _54f9e35c45a0 == 0:
            raise _40a0bca91739("Dataset is empty; cannot create sampler for zero-length dataset.")

        # Group dataset indices by sample_id
        # Expected dataset[i] to be a mapping containing "sample_id" and "chunk_id"
        self._8aea420c4c0c: _d0e3c1a6b1a8[_1ca86fc5843d, _c2c1b054eeba[_1ca86fc5843d]] = {}
        for _94a456de3acc in _a24cf80c8832(_54f9e35c45a0):
            try:
                _3ee65ecfe5f5 = _1ca86fc5843d(_31c99b09dfe2[_94a456de3acc]["sample_id"])
            except _a21a93b19665 as _5697453af7c3:
                raise _40a0bca91739(
                    f"Dataset element at index {_94a456de3acc} must be a mapping with key 'sample_id'."
                ) from _5697453af7c3
            self._8aea420c4c0c._3af67ab62d5c(_3ee65ecfe5f5, [])._8bf7ebe37f1f(_94a456de3acc)

        # Sort chunk indices per sample by chunk_id when available (best-effort)
        for _3ee65ecfe5f5, _7beb3cac13f3 in self._8aea420c4c0c._3a98f1b203ae():
            try:
                # Sort using the dataset's chunk_id for stable ordering
                _7beb3cac13f3._aee84fd587f1(_5706723f7edc=lambda _e24899f6f554: _31c99b09dfe2[_e24899f6f554]["chunk_id"])
            except _a21a93b19665:
                # Fallback: sort by index if dataset doesn't provide chunk_id or if an error occurs
                _7beb3cac13f3._aee84fd587f1()

        # Sorted sample id list (deterministic)
        self._2bedc29d8b8a: _c2c1b054eeba[_1ca86fc5843d] = _aee726b11177(self._8aea420c4c0c._df8b15850ff3())

        # total number of raw chunks in dataset
        self._c63f81f76c3d = _54f9e35c45a0

        # Determine per-rank sample count target.
        # The original code computed num_samples as a max over partitions;
        # preserve that behavior to avoid changing runtime sampling proportions.
        # Defensive: ensure we don't divide by zero when computing partitions.
        _86d01ece1a4d = _fc11d9301f46(self._2bedc29d8b8a)
        if _86d01ece1a4d == 0:
            raise _40a0bca91739("No sample groups found in dataset (no sample_id values).")

        # Compute the maximum number of chunks any rank would receive when assigning
        # contiguous ranges of sample_ids to ranks. This becomes our `num_samples`.
        def _461366c73579(_dc7470de62fc: _1ca86fc5843d) -> _1ca86fc5843d:
            # Partition sample_ids evenly; remainder distributed to first (num_sids % num_replicas) ranks
            _316a05b3722f = _86d01ece1a4d // self._124b69da5634
            _7a7564cc812f = 1 if _dc7470de62fc < (_86d01ece1a4d % self._124b69da5634) else 0
            _76c392e92adc = _dc7470de62fc * _316a05b3722f + _cca41a2bf1af(_dc7470de62fc, _86d01ece1a4d % self._124b69da5634)
            _bb44b434d3e5 = _76c392e92adc + _316a05b3722f + _7a7564cc812f
            # sum chunk counts for that partition
            return _5dd975347b77(_fc11d9301f46(self._8aea420c4c0c[self._2bedc29d8b8a[_9d6cedfedd7e]]) for _9d6cedfedd7e in _a24cf80c8832(_76c392e92adc, _cca41a2bf1af(_bb44b434d3e5, _86d01ece1a4d)))

        _46cb60088cf1 = _87c52ab50181(_adc6c4059e78(_dc7470de62fc) for _dc7470de62fc in _a24cf80c8832(self._124b69da5634))
        self._8195d0c02d39 = _1ca86fc5843d(_46cb60088cf1)

    def _3e6d94fcaede(self) -> _c42be495e2a7[_1ca86fc5843d]:
        """
        Produce an iterator of dataset indices for the current rank and epoch.

        Behavior (preserves original algorithm):
          - Build a list of sample_ids and optionally shuffle them using (seed + epoch).
          - Partition sample_ids by contiguous blocks to each rank.
          - For the current rank, collect all chunk indices for its sample groups.
          - If a rank has fewer chunks than the target `chunks_per_rank`, duplicate
            groups from its assigned set (round-robin) until the length reaches the target.
          - Return an iterator over the resulting list of indices.

        Returns
        -------
        Iterator[int]
            Iterator yielding dataset indices in the order chosen for the current rank.

        Raises
        ------
        RuntimeError
            If the sampler cannot construct a valid index list (e.g. no sample groups).
        """
        # Deterministic generator for shuffling per epoch
        _2ef43b2d62ae = _74252b9d8abb._dbda0d834ebe()
        _2ef43b2d62ae._7fc0652f865f(self._e512ed6eaf86 + self._688df324a381)

        # Prepare sequence of sample ids
        _5bb9b8f7fc9a = _6d8666b53aa5(self._2bedc29d8b8a)
        if self._63c666ff0f41:
            _3c02ff3395c7 = _74252b9d8abb._8987095faff9(_fc11d9301f46(_5bb9b8f7fc9a), _13bd3b88eb8e=_2ef43b2d62ae)._21a1129054b1()
            _5bb9b8f7fc9a = [_5bb9b8f7fc9a[_9d6cedfedd7e] for _9d6cedfedd7e in _3c02ff3395c7]

        _427a2e6f0a2f = _fc11d9301f46(_5bb9b8f7fc9a)

        # Partition sample_ids among ranks by contiguous blocks.
        # This mirrors the partition logic used in num_samples calculation.
        _6c25122cf5a9 = _427a2e6f0a2f // self._124b69da5634
        _e38b796b4acd = _427a2e6f0a2f % self._124b69da5634
        _0769da4a6a05 = self._d2f5afbf2661 * _6c25122cf5a9 + _cca41a2bf1af(self._d2f5afbf2661, _e38b796b4acd)
        _4e872d787249 = _0769da4a6a05 + _6c25122cf5a9 + (1 if self._d2f5afbf2661 < _e38b796b4acd else 0)

        _e87155fd5a92 = _5bb9b8f7fc9a[_0769da4a6a05:_4e872d787249]

        # Ensure the last rank includes any tail (defensive; should be covered by above)
        if self._d2f5afbf2661 == self._124b69da5634 - 1 and _4e872d787249 < _427a2e6f0a2f:
            _e87155fd5a92._b57931928a08(_5bb9b8f7fc9a[_4e872d787249:_427a2e6f0a2f])

        # Gather indices (all chunks for each assigned sample_id)
        _77bb86f46046: _c2c1b054eeba[_1ca86fc5843d] = []
        for _3ee65ecfe5f5 in _e87155fd5a92:
            _77bb86f46046._b57931928a08(self._8aea420c4c0c[_3ee65ecfe5f5])

        # Determine the target number of chunks per rank (compute same way as earlier)
        # This chooses the maximum chunk count any rank would have over equal contiguous partitioning.
        def _614c3d9f28a9(_dc7470de62fc: _1ca86fc5843d) -> _1ca86fc5843d:
            # reuse logic used during initialization
            _316a05b3722f = _427a2e6f0a2f // self._124b69da5634
            _7a7564cc812f = 1 if _dc7470de62fc < (_427a2e6f0a2f % self._124b69da5634) else 0
            _76c392e92adc = _dc7470de62fc * _316a05b3722f + _cca41a2bf1af(_dc7470de62fc, _427a2e6f0a2f % self._124b69da5634)
            _bb44b434d3e5 = _76c392e92adc + _316a05b3722f + _7a7564cc812f
            return _5dd975347b77(_fc11d9301f46(self._8aea420c4c0c[self._2bedc29d8b8a[_9d6cedfedd7e]]) for _9d6cedfedd7e in _a24cf80c8832(_76c392e92adc, _cca41a2bf1af(_bb44b434d3e5, _427a2e6f0a2f)))

        _998444881757 = _87c52ab50181(_0c14f7ffde8e(_dc7470de62fc) for _dc7470de62fc in _a24cf80c8832(self._124b69da5634))

        # If current rank has fewer chunks than the computed chunks_per_rank, duplicate groups
        # from my_sids round-robin until we reach the target. This balances lengths across ranks.
        _67fcedc0a978 = _fc11d9301f46(_77bb86f46046)
        if _67fcedc0a978 < _998444881757:
            if not _e87155fd5a92:
                raise _40a0bca91739("No sample groups assigned to this rank; cannot duplicate to reach target chunk count.")
            _9d6cedfedd7e = 0
            while _67fcedc0a978 < _998444881757:
                _3ee65ecfe5f5 = _e87155fd5a92[_9d6cedfedd7e % _fc11d9301f46(_e87155fd5a92)]
                _77bb86f46046._b57931928a08(self._8aea420c4c0c[_3ee65ecfe5f5])
                _67fcedc0a978 += _fc11d9301f46(self._8aea420c4c0c[_3ee65ecfe5f5])
                _9d6cedfedd7e += 1

        return _d2305b8365bb(_77bb86f46046)

    def _c864f8d983c6(self) -> _1ca86fc5843d:
        """
        Return the target number of indices this sampler will yield for the rank.

        This value is computed during initialization as the maximum chunk-count that any
        rank would receive when partitioning sample groups contiguously. It is used by
        PyTorch internals and DataLoader to determine epoch length for the rank.

        Returns
        -------
        int
            Number of indices expected from this sampler for one epoch.
        """
        return _1ca86fc5843d(self._8195d0c02d39)

    def _ee04162bfc0d(self, _688df324a381: _1ca86fc5843d) -> _a5b3071c1503:
        """
        Set the epoch for this sampler. When `shuffle=True`, this influences the RNG
        used for shuffling sample groups so different epochs see different permutations.

        Parameters
        ----------
        epoch : int
            Epoch number (non-negative).

        Raises
        ------
        RuntimeError
            If epoch is not an integer or is negative.
        """
        if not _b1214b7243f1(_688df324a381, _1ca86fc5843d) or _688df324a381 < 0:
            raise _40a0bca91739("epoch must be a non-negative integer.")
        self._688df324a381 = _1ca86fc5843d(_688df324a381)
