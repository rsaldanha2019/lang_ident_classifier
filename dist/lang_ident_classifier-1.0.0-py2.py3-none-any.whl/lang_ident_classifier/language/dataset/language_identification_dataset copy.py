# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_dataset
# @Time             : 18/12/23 2:34 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import functools
from itertools import chain
import json
from multiprocessing import Pool, cpu_count
import os
from difflib import SequenceMatcher
from logging import Logger
import random
import re
from typing import Any, List
import unicodedata
import numpy as np
import torch
from torch.utils.data import Dataset

class LanguageIdentificationDataset(Dataset):
    """
    contains methods for Dataset related operations
    """

    def __init__(self, data_dir: str, files_have__header: bool,
                 pretrained_embedding_tokenizer: Any, max_output_length: int,
                 classes_config_path: str, log: Logger,
                 is_train: bool, sample_dataset_share: float = 1.0,
                 random_seed: int = 20, is_gen_llm: bool = False, prompt_template = None):
        """
        initializes the class instance with default parameters
        :param data_dir: path of the data directory
        :param files_have__header: if True, indicates that
        files have header and will skip 1 line
        :param log: instance of a Logger object for logging
        """
        super(LanguageIdentificationDataset, self).__init__()
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        random.seed(random_seed)
        np.random.seed(random_seed)
        self.log = log
        self.is_train = is_train
        self.is_gen_llm = is_gen_llm
        self.prompt_template = prompt_template
        self.files_have_header = files_have__header
        self.data_dir = data_dir
        self.max_seq_length = max_output_length
        self.tokenizer = pretrained_embedding_tokenizer
        self.src_data = []
        self.tgt_data = []
        self.file_stats = {}
        self.sample_dataset_share = sample_dataset_share
        self._validate_and_load_file_data()
        self.classes, self.class_weights = self._get_classes_dict(classes_config_path, is_train)

    def __len__(self):
        """
        method to obtain number of samples in the dataset
        :return: length of the dataset
        """
        return len(self.tgt_data)

    def _get_class_id_from_lang_code(self, lang_code):
        for lang_id, lang_info in self.classes.items():
            if lang_info["lang_code"] == lang_code.strip():
                return lang_id

    def _get_lang_code_from_class_id(self, class_id):
        return self.classes[class_id]["lang_code"]

    def get_num_classes(self):
        return len(self.classes)

    def _add_languages(self, lang_code_dict):
        # Create dictionary with counts using dictionary comprehension
        # new_languages_dict = {value: self.tgt_data.count(value) for value in set(self.tgt_data)}
        # Count occurrences of unique languages per sample
        # new_languages_dict = dict(Counter(
        #     lang.strip()  # Remove extra spaces
        #     for entry in self.tgt_data 
        #     for lang in set(entry.split(","))  # Ensure unique languages per sample
        # ))
        # Optimized Counting
        new_languages_dict = defaultdict(int)

        for lang in map(str.strip, chain.from_iterable(entry.split(",") for entry in self.tgt_data)):
            new_languages_dict[lang] += 1  # Direct increment (avoids key checks)

        # Convert to a regular dict if needed
        new_languages_dict = dict(new_languages_dict)

        if next((key for key, value in lang_code_dict.items() if value['lang_code'] == "unk"), None) is None:
            new_lang_id = 0
            lang_code_dict[new_lang_id] = {"lang_code": "unk", "lang_samples": 0, "lang_files": []}

        for lang in new_languages_dict:
            lang = lang.strip()
            key_for_lang_code = next((key for key, value in lang_code_dict.items() if value['lang_code'] == lang), None)
            if key_for_lang_code is None:
                new_lang_id = len(lang_code_dict)
                lang_code_dict[new_lang_id] = {"lang_code": lang, "lang_samples": new_languages_dict[lang], "lang_files": self.file_stats[lang]}
            else:
                new_lang_id = key_for_lang_code
                samples_lang_code = lang_code_dict[key_for_lang_code]["lang_samples"]
                files_lang_code = lang_code_dict[key_for_lang_code]["lang_files"]
                if samples_lang_code < new_languages_dict[lang]:
                    new_samples = samples_lang_code + new_languages_dict[lang]
                    lang_code_dict[new_lang_id] = {"lang_code": lang, "lang_samples": new_samples, "lang_files": files_lang_code + self.file_stats[lang]}
        return lang_code_dict
    
    def _normalize_class_weights(self, weights):
        total_weight = np.sum(weights)
        normalized_weights = weights / total_weight
        return normalized_weights

    def _get_class_weights(self, classes_dict):
        # Calculate class weights based on lang_samples
        total_samples = sum(entry['lang_samples'] for entry in classes_dict.values())

        class_weights = {}
        for lang_code, lang_data in classes_dict.items():
            class_samples = lang_data['lang_samples']
            if class_samples > 0:
                # weights are inversely proportional to number of samples
                class_weight = total_samples / (class_samples * len(classes_dict))
            else:
                class_weight = 0  # Set weight to 0 if there are no samples
            classes_dict[lang_code].update({"lang_weight":class_weight})
        class_weights = [entry['lang_weight'] for entry in classes_dict.values()]
        # class_weights = self._normalize_class_weights(class_weights)
        # Update the lang_weights with normalized class weights
        for i, (lang_code, lang_data) in enumerate(classes_dict.items()):
            lang_data["lang_weight"] = class_weights[i]
        return class_weights, classes_dict

    def _get_classes_dict(self, classes_config_path, is_train):
        classes_dict = {}
        class_weights = {}
        if os.path.exists(classes_config_path):
            with open(classes_config_path, mode='r+', encoding='utf8') as ccp:
                # classes_dict = json.load(ccp)
                raw_dict = json.load(ccp)  # Load JSON normally (keys are strings)
    
                classes_dict = {
                    float(k) if "." in k else int(k): v  # Convert only top-level keys
                    for k, v in raw_dict.items()
                }

        if is_train:
            classes_dict = self._add_languages(lang_code_dict=classes_dict)
            class_weights, classes_dict = self._get_class_weights(classes_dict=classes_dict)

            with open(classes_config_path, mode='w+', encoding='utf8') as ccp_w:
                json.dump(classes_dict, ccp_w, indent=2)

        return classes_dict, class_weights
    
    def get_labels(self):
        return [self._get_class_id_from_lang_code(lang_code) for lang_code in self.tgt_data]

    def __getitem__(self, idx: int) -> Any:
        input_ids = self.src_data[idx]  # assumed to be list[int]
        target_id = self._get_class_id_from_lang_code(self.tgt_data[idx])
        if target_id is None:
            print(f'Language not present at idx {idx}, value: {self.tgt_data[idx]}')
            target_id = 0  # fallback class

        # Safety check for tokenizer.pad_token_id
        pad_token_id = self.tokenizer.pad_token_id
        if pad_token_id is None:
            pad_token_id = self.tokenizer.eos_token_id  # fallback
            self.tokenizer.pad_token = self.tokenizer.eos_token  # ensure consistency

        max_len = self.max_seq_length
        seq_len = len(input_ids)

        # Pad input_ids
        input_ids = input_ids[:max_len]
        padding_length = max_len - len(input_ids)
        input_ids += [pad_token_id] * padding_length

        # Attention mask: 1s for real tokens, 0s for padding
        attention_mask = [1] * min(seq_len, max_len) + [0] * padding_length

        # For classification per token, repeat target_id; or return single class label
        target_ids = [target_id] * min(seq_len, max_len) + [-100] * padding_length  # -100 to ignore loss on pad

        return (
            torch.tensor(input_ids, dtype=torch.long),
            torch.tensor(attention_mask, dtype=torch.long),
            torch.tensor(target_ids, dtype=torch.long),
        )



    def _similar_name(self, name_1: str, name_2: str) -> float:
        """
        takes two filenames, compares and returns the match score
        :param name_1: file name of file 1
        :param name_2: file name of file 2
        :return: match score
        """
        return SequenceMatcher(None, name_1, name_2).ratio()

    # Function to calculate overlap length based on percentage
    def _calculate_overlap(self, overlap_percentage):
        return int(self.max_seq_length * overlap_percentage)

    # Function to split line into overlapping windows
    @staticmethod
    def _split_into_windows(src_line, overlap_length, max_seq_length):
        windows = []
        for i in range(0, len(src_line), max_seq_length - overlap_length):
            windows.append(src_line[i:i + max_seq_length])
        return windows

    @staticmethod
    def tokenize_words_fast(text: str, tokenizer, add_special_tokens=True) -> List[List[int]]:
        """
        Tokenize text into per-word token IDs using a stateless encoder_ function.
        Assumes encoder_ is a callable configured with is_split_into_words=True.
        """
        words = text.split()
        encodings = tokenizer(words, is_split_into_words=True, add_special_tokens=add_special_tokens)  # encoder_ must be a lightweight tokenizer function

        word_ids = encodings.word_ids()
        input_ids = encodings.input_ids

        grouped_tokens = []
        current_word = -1
        current_tokens = []

        for token_id, word_id in zip(input_ids, word_ids):
            if word_id is None:
                continue
            if word_id != current_word:
                if current_tokens:
                    grouped_tokens.append(current_tokens)
                current_tokens = [token_id]
                current_word = word_id
            else:
                current_tokens.append(token_id)
        if current_tokens:
            grouped_tokens.append(current_tokens)

        return grouped_tokens


    @staticmethod
    def _split_into_windows_for_gen_llm(
        prompt_template: str,
        src_line: str,
        tgt_line: str,
        overlap_percentage: float,
        max_seq_length: int,
        tokenizer
    ):
        """
        Efficiently splits input into overlapping windows and tokenizes them in batch.
        - Uses {input_text} and {response} placeholders in the prompt_template
        - {response} is just space-separated labels
        """

        src_words = src_line.strip().split()
        tgt_labels = tgt_line.strip().split()
        single_label = len(tgt_labels) == 1

        # assert not (len(src_words) != len(tgt_labels) and not single_label), \
        #     "Mismatch between source words and target labels"

        # assert "{input_text}" in prompt_template and "{response}" in prompt_template, \
        #     "Prompt template must include {input_text} and {response}"

        # Estimate tokens per word
        test_src = src_words[:10]
        test_tgt = [tgt_labels[0]] * len(test_src) if single_label else tgt_labels[:10]
        test_prompt = prompt_template.replace("{input_text}", " ".join(test_src)).replace("{response}", " ".join(test_tgt))
        test_tokens = tokenizer.encode(test_prompt, add_special_tokens=True)
        avg_tokens_per_word = len(test_tokens) / max(1, len(test_src))

        est_words_per_window = int(max_seq_length / avg_tokens_per_word)
        if est_words_per_window < 1:
            raise ValueError("max_seq_length too small to fit even one word")

        overlap_words = int(overlap_percentage * est_words_per_window)

        # First, collect prompt strings for all windows
        prompt_texts = []
        start = 0
        last_end = 0
        window_spans = []

        while start < len(src_words):
            end = min(start + est_words_per_window, len(src_words))
            src_window = src_words[start:end]
            tgt_window = [tgt_labels[0]] * len(src_window) if single_label else tgt_labels[start:end]

            prompt_text = prompt_template.replace("{input_text}", " ".join(src_window)).replace("{response}", " ".join(tgt_window))
            prompt_texts.append(prompt_text)
            window_spans.append((start, end))  # for debugging or reference

            if end >= len(src_words):
                break
            start = max(end - overlap_words, last_end + 1)
            last_end = end

        # Tokenize all at once
        tokenized_outputs = tokenizer(
            prompt_texts,
            add_special_tokens=True,
            truncation=False,
            return_attention_mask=False
        )

        # Filter based on length
        windows = [
            tokens for tokens in tokenized_outputs["input_ids"]
            if len(tokens) <= max_seq_length
        ]

        # print(f"Original line {src_line} and ")
        # for win in windows:
        #     print(f"decoded window {LanguageIdentificationDataset.decode_text(win, tokenizer=tokenizer)}")

        return windows



    @staticmethod
    def _is_arabic(text):
        for char in text:
            if 'ARABIC' not in unicodedata.name(char, ''):
                return False
        return True

    @staticmethod
    def _reverse_arabic_sentence(sentence):
        if LanguageIdentificationDataset._is_arabic(sentence):
            # If the sentence is in Arabic script, reverse it
            # reversed_sentence = sentence[::-1]
            # Step 1: Split the sentence into words
            words = sentence.strip().split()

            # Step 2: Reverse the order of words (keeping characters in place)
            reversed_sentence = " ".join(reversed(words))
            # reversed_sentence = sentence
            return reversed_sentence
        else:
            return sentence
    
    @staticmethod
    def _is_english_string(input_string):
        # Function to check if a character is part of the English alphabet
        def is_english_char(char):
            return 'a' <= char.lower() <= 'z'

        # Convert the string to a list of characters
        characters = list(input_string)

        # Count the English alphabet characters
        english_chars_count = sum(1 for char in characters if is_english_char(char))

        # Calculate the percentage of English alphabet characters
        percentage_english = english_chars_count / len(characters)

        # Check if more than 50% of characters are from the English alphabet
        return percentage_english > 0.5
    
    @staticmethod
    def process_line(args):
        """
        Process a single line: clean, check language, tokenize, and split.
        Returns (src_tokens, tgt_line) if valid, else None.
        """
        (src_line, tgt_line, max_seq_length, overlap_percentage, pad_token_id, 
         is_english_func, split_windows_func, tokenizer_encode_func) = args

        tgt_line = tgt_line.strip()
        src_line = ' '.join(src_line.split())  # Remove extra spaces

        # Check language constraints
        is_english = is_english_func(src_line)
        if ("_en" in tgt_line and not is_english) or ("_en" not in tgt_line and is_english):
            return None  # Skip mismatched languages

        src_tokens = tokenizer_encode_func(src_line)

        # Handle long sequences
        if len(src_tokens) > max_seq_length:
            overlap_len = int(overlap_percentage * max_seq_length)
            windows = split_windows_func(src_tokens, overlap_len, max_seq_length)
            windows = [win + [pad_token_id] * (max_seq_length - len(win)) for win in windows]
            return [(win, tgt_line) for win in windows]
        else:
            # Pad shorter sequences to max_seq_length
            src_tokens += [pad_token_id] * (max_seq_length - len(src_tokens))
            return [(src_tokens, tgt_line)]

    @staticmethod
    def process_line_gen_llm(args):
        """
        Process a single line: clean, check language, tokenize, and split.
        Returns (src_tokens, tgt_line) if valid, else None.
        """
        (prompt_template, src_line, tgt_line, max_seq_length, overlap_percentage, pad_token_id, tokenizer,
        is_english_func, split_windows_func, tokenizer_encode_func) = args

        tgt_line = tgt_line.strip()
        org_tgt_line = tgt_line
        src_line = ' '.join(src_line.split())  # Normalize whitespace

        # Check language constraints
        is_english = is_english_func(src_line)
        if ("_en" in tgt_line and not is_english) or ("_en" not in tgt_line and is_english):
            return None  # Skip mismatched languages

        # Replace {input_text}
        filled_prompt = prompt_template.replace("{input_text}", src_line)

        # Trim at {response} if present
        if "{response}" in filled_prompt:
            filled_prompt = filled_prompt.split("{response}")[0]  # drop everything after {response}

        # Tokenize
        prompt_tokens = tokenizer_encode_func(filled_prompt, add_special_tokens=True)

        # Adjust tgt_line for label alignment
        tgt_line = " ".join([tgt_line] * len(src_line.strip().split())) if len(tgt_line.split()) == 1 and tgt_line.strip() else tgt_line
        if len(src_line.split()) != len(tgt_line.split()):
            raise ValueError(f"Source line and Target line tokens dont match for {src_line}")

        # src_tokens = tokenizer_encode_func(src_line, add_special_tokens=False)
        tgt_tokens = tokenizer_encode_func(tgt_line, add_special_tokens=False)

        total_prompt_tokens = prompt_tokens + tgt_tokens

        # print(f"Current Tokens {total_prompt_tokens}")
        # decoded_prompt = LanguageIdentificationDataset.decode_text(total_prompt_tokens, tokenizer)
        # print(f"Decoded prompt {decoded_prompt}")

        # Handle long sequences
        if len(total_prompt_tokens) > max_seq_length:
            # print(f"splitting {len(total_prompt_tokens)}")
            try:
                windows = split_windows_func(prompt_template, src_line, org_tgt_line,
                                            overlap_percentage, max_seq_length, tokenizer)
            except Exception as e:
                print(f"Windows exception {e}")
            return [(win, org_tgt_line) for win in windows]
        else:
            return [(total_prompt_tokens, org_tgt_line)]


    @staticmethod
    def decode_text(tokens, tokenizer):
        return tokenizer.decode(tokens)
    
    @staticmethod
    def encode_text(text, tokenizer, add_special_tokens=True):
        """Static method for tokenization to avoid pickling errors."""
        return tokenizer.encode_plus(text, truncation=False, return_tensors=None, add_special_tokens=add_special_tokens)["input_ids"]

    def _process_file_data(self, src_file, tgt_file):
        with open(src_file, mode='r', encoding='utf8') as sfile, open(tgt_file, mode='r', encoding='utf8') as tfile:
            if self.files_have_header:
                src_file_lines = sfile.readlines()[1:]
                tgt_file_lines = tfile.readlines()[1:]
            else:
                src_file_lines = sfile.readlines()
                tgt_file_lines = tfile.readlines()

        lang_code = list(set(tgt_file_lines))[0].strip()
        num_of_samples_to_use = int(len(src_file_lines) * self.sample_dataset_share)

        # Randomly select some share of data from the list
        src_file_lines = random.sample(src_file_lines, num_of_samples_to_use)
        tgt_file_lines = random.sample(tgt_file_lines, num_of_samples_to_use)
        self.log.info(f"Sampled {self.sample_dataset_share*100} percent of {src_file} dataset with {len(src_file_lines)} samples.")

        num_workers = max(1, int(cpu_count() * 0.4))  # Use 40% of available CPU cores

        # Prepare multiprocessing arguments
        args_list = [
            (src_line, tgt_line, self.max_seq_length, 0.5, self.tokenizer.pad_token_id,
             LanguageIdentificationDataset._is_english_string, 
             LanguageIdentificationDataset._split_into_windows,
             functools.partial(LanguageIdentificationDataset.encode_text, tokenizer=self.tokenizer))  # Pass method reference
            for src_line, tgt_line in zip(src_file_lines, tgt_file_lines)
        ]

        gen_llm_args_list = [
            (self.prompt_template, src_line, tgt_line, self.max_seq_length, 0.5, self.tokenizer.pad_token_id, self.tokenizer,
             LanguageIdentificationDataset._is_english_string, 
             LanguageIdentificationDataset._split_into_windows_for_gen_llm,
             functools.partial(LanguageIdentificationDataset.encode_text, tokenizer=self.tokenizer))  # Pass method reference
            for src_line, tgt_line in zip(src_file_lines, tgt_file_lines)
        ]

        # Use multiprocessing with safer settings
        if self.is_gen_llm:
            with Pool(processes=num_workers) as pool:
                results = pool.map(LanguageIdentificationDataset.process_line_gen_llm, gen_llm_args_list)
        else:
            with Pool(processes=num_workers) as pool:
                results = pool.map(LanguageIdentificationDataset.process_line, args_list)
        # results = []
        # with ThreadPoolExecutor(max_workers=num_workers) as executor:
        #     futures = [executor.submit(LanguageIdentificationDataset.process_line, args) for args in args_list]
        #     for future in as_completed(futures):
        #         result = future.result()
        #         results.append(result)


        # Flatten results and remove None values
        processed_pairs = [pair for sublist in results if sublist for pair in sublist]

        # Separate into source and target lists
        new_src_file_lines, new_tgt_file_lines = zip(*processed_pairs) if processed_pairs else ([], [])

        return lang_code, list(new_src_file_lines), list(new_tgt_file_lines)

    def _validate_and_load_file_data(self):
        """
        validates, loads and processes data
        :return: None
        """
        # filename_match_threshold = 0.99
        src_files_list = []
        tgt_files_list = []

        for lang_dir in os.listdir(self.data_dir):
            self.log.info(f"Now processing {os.path.join(self.data_dir, lang_dir)} directory.")
            src_data_dir = os.path.join(self.data_dir, lang_dir, 'src')
            tgt_data_dir = os.path.join(self.data_dir, lang_dir, 'tgt')
            for src_file in os.listdir(src_data_dir):
                matched = False
                for tgt_file in os.listdir(tgt_data_dir):
                    # sim_score = self._similar_name(src_file, tgt_file)
                    # if sim_score >= filename_match_threshold:
                    if src_file.split(".")[0] == tgt_file.split(".")[0]:
                        src_files_list.append(src_file)
                        tgt_files_list.append(tgt_file)
                        matched = True
                        break
                if matched:
                    continue  # continue to next loop
                else:
                    self.log.info(f"Skipping file {src_file} since matching label file not found in {tgt_data_dir}.")
            # Validate files and content
            src_filtered_files = [os.path.join(src_data_dir, file) for file in src_files_list if
                                  os.path.isfile(os.path.join(src_data_dir, file))]
            tgt_filtered_files = [os.path.join(tgt_data_dir, file) for file in tgt_files_list if
                                  os.path.isfile(os.path.join(tgt_data_dir, file))]
            if len(src_filtered_files) != len(tgt_filtered_files):
                msg_err_num_files = f"Number of files in {src_data_dir} is {len(src_filtered_files)} does not match" \
                                    f"with {len(tgt_filtered_files)} files present in {tgt_data_dir}"
                raise ValueError(msg_err_num_files)
            else:
                for src_file, tgt_file in zip(src_filtered_files, tgt_filtered_files):
                    new_src_file_lines = []
                    new_tgt_file_lines = []
                    src_num_lines = sum(1 for _ in open(src_file))
                    tgt_num_lines = sum(1 for _ in open(tgt_file))
                    src_num_lines = src_num_lines - 1 if self.files_have_header else src_num_lines
                    tgt_num_lines = tgt_num_lines - 1 if self.files_have_header else tgt_num_lines
                    if src_num_lines != tgt_num_lines:
                        self.log.info(f"{src_num_lines} lines in {src_file} "
                                      f"do not match with {tgt_num_lines} in {tgt_file}, skipping processing these files")
                    else:
                        self.log.info(f"Processing {src_file} and {tgt_file} with {tgt_num_lines} samples.")
                        lang_code, new_src_file_lines , new_tgt_file_lines = self._process_file_data(src_file, tgt_file)
                            
                        # num_of_samples_to_use = int(len(new_src_file_lines) * self.sample_dataset_share)

                        # # Randomly select some share of data from the list
                        # new_src_file_lines = random.sample(new_src_file_lines, num_of_samples_to_use)
                        # new_tgt_file_lines = random.sample(new_tgt_file_lines, num_of_samples_to_use)
                        # self.log.info(f"Sampled {self.sample_dataset_share*100} percent of this dataset")

                        # any further preprocessing here and then append
                        self.src_data.extend(new_src_file_lines)
                        self.tgt_data.extend(new_tgt_file_lines)
                        
                        if self.is_train:
                            if lang_code not in self.file_stats:
                                self.file_stats.update({lang_code : [{"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)}]})
                            else:
                                self.file_stats[lang_code].append({"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)})
                        self.log.info(f"Files {src_file} and {tgt_file} have {len(new_tgt_file_lines)} samples after processing.")



