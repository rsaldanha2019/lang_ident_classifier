# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_dataset
# @Time             : 18/12/23 2:34 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import functools
import glob
from itertools import chain, islice
import json
import math
# from multiprocessing import Pool, cpu_count
from multiprocessing import cpu_count
from multiprocessing.dummy import Pool
import os
from difflib import SequenceMatcher
from logging import Logger
import random
import re
import shutil
from typing import Any, List
import unicodedata
import numpy as np
import torch
import pyarrow as pa
import pyarrow.parquet as pq
from torch.utils.data import Dataset, IterableDataset, get_worker_info

class LanguageIdentificationDataset(IterableDataset):
    """
    contains methods for Dataset related operations
    """
    TOKENIZER = None  # Class-level tokenizer

    def __init__(self, data_dir: str, files_have__header: bool,
                 pretrained_embedding_tokenizer: Any, max_output_length: int,
                 classes_config_path: str, log: Logger,
                 is_train: bool, sample_dataset_share: float = 1.0,
                 num_workers: int = 2,
                 random_seed: int = 20, is_gen_llm: bool = False, prompt_template = None,
                 use_disk_store: bool = False):
        """
        initializes the class instance with default parameters
        :param data_dir: path of the data directory
        :param files_have__header: if True, indicates that
        files have header and will skip 1 line
        :param log: instance of a Logger object for logging
        """
        super(LanguageIdentificationDataset, self).__init__()
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        random.seed(random_seed)
        np.random.seed(random_seed)
        self.random_seed = random_seed
        self.log = log
        self.is_train = is_train
        self.is_gen_llm = is_gen_llm
        self.prompt_template = prompt_template
        self.files_have_header = files_have__header
        self.data_dir = data_dir
        self.max_seq_length = max_output_length
        LanguageIdentificationDataset.TOKENIZER = pretrained_embedding_tokenizer
        self.tokenizer = pretrained_embedding_tokenizer
        self.ignore_index = -100 if is_gen_llm else self.tokenizer.pad_token_id
        self.use_disk_store = use_disk_store
        parent_dir = os.path.basename(self.data_dir.rstrip("/"))
        self.rank = 0
        self.world_size = 1
        if torch.distributed.is_initialized():
            self.rank = torch.distributed.get_rank()
            self.world_size = torch.distributed.get_world_size()
        self.disk_store_dir = os.path.join("disk_store", f"rank_{self.rank}", parent_dir)
        if os.path.exists(self.disk_store_dir):
            shutil.rmtree(self.disk_store_dir)  # force remove
        if self.use_disk_store:
            os.makedirs(self.disk_store_dir, exist_ok=True)
        self._shard_counter = 0  # start shard numbering from 0
        self._shard_files = []
        self._shard_sizes = []
        self.length = 0
        self.shard_paths = []
        self.data = []
        self.src_data = []
        self.attn_data = []
        self.tgt_data = []
        self.file_stats = {}
        self.sample_dataset_share = sample_dataset_share
        self.num_workers = num_workers
        self._validate_and_load_file_data()
        # self.validate_windowing_samples()
        self.classes, self.class_weights = self._get_classes_dict(classes_config_path, is_train)
        print(f"Dataset classes {self.classes} and Weights {self.class_weights}")

    # Incorrect len for iterable dataset since it reports all data not per rank
    # def __len__(self):
    #     """
    #     method to obtain number of samples in the dataset
    #     :return: length of the dataset
    #     """
    #     # return len(self.tgt_data)
    #     if self.use_disk_store:
    #         # Count rows across all shards for this rank
    #         # shard_files = glob.glob(f"{self.disk_store_dir}/rank_{self.rank}_shard_*.parquet")
    #         # total_rows = sum(pq.read_metadata(f).num_rows for f in shard_files)
    #         # # print(f"For parquet files {total_rows} rows")
    #         # return total_rows
    #         return sum(self._shard_sizes)
    #     else:
    #         # print(f"From memory {len(self.data)} rows")
    #         return len(self.data)

    def __len__(self):
        """
        Returns number of samples this rank will process.
        Lightning progress bar will reflect distributed training correctly.
        """
        if getattr(self, "use_disk_store", False):
            n_total = sum(self._shard_sizes)
        else:
            n_total = len(self.data)

        # Per-rank slice
        world_size = max(1, int(getattr(self, "world_size", 1)))
        rank = max(0, int(getattr(self, "rank", 0)))
        start = (n_total * rank) // world_size
        end = (n_total * (rank + 1)) // world_size

        return end - start

    # @property
    # def total_size(self):
    #     # total samples in all shards
    #     return sum(self._shard_sizes)

    # def _get_shards_for_rank(self):
    #     # Called once per dataset instance, with known rank & world_size
    #     num_shards = len(self._shard_files)
    #     shards_per_rank = num_shards // self.world_size
    #     remainder = num_shards % self.world_size

    #     if self.rank < remainder:
    #         start = self.rank * (shards_per_rank + 1)
    #         end = start + shards_per_rank + 1
    #     else:
    #         start = remainder * (shards_per_rank + 1) + (self.rank - remainder) * shards_per_rank
    #         end = start + shards_per_rank

    #     return self._shard_files[start:end], self._shard_sizes[start:end]

    # def _get_shards_for_worker(self):
    #     worker_info = get_worker_info()
    #     worker_id = worker_info.id if worker_info else 0
    #     num_workers = worker_info.num_workers if worker_info else 1

    #     rank_shard_files, rank_shard_sizes = self._get_shards_for_rank()
    #     num_shards = len(rank_shard_files)

    #     base = num_shards // num_workers
    #     rem = num_shards % num_workers

    #     if worker_id < rem:
    #         start = worker_id * (base + 1)
    #         end = start + base + 1
    #     else:
    #         start = rem * (base + 1) + (worker_id - rem) * base
    #         end = start + base

    #     return rank_shard_files[start:end], rank_shard_sizes[start:end]

    # @property
    # def num_samples(self):
    #     # sum sizes of shards assigned to this rank *and* worker (if any workers)
    #     _, sizes = self._get_shards_for_worker()
    #     return sum(sizes)

    def _get_shards_for_rank_balanced(self):
        """Assign shards to rank to balance total samples, not just shard counts."""
        shards = list(zip(self._shard_files, self._shard_sizes))
        total_samples = sum(size for _, size in shards)
        target_per_rank = total_samples // self.world_size

        rank_shards = []
        cumulative = 0
        for shard_path, shard_size in shards:
            if cumulative + shard_size <= target_per_rank or not rank_shards:
                rank_shards.append((shard_path, shard_size))
                cumulative += shard_size
            else:
                break
        shard_files, shard_sizes = zip(*rank_shards) if rank_shards else ([], [])
        return list(shard_files), list(shard_sizes)


    def __iter__(self):
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info else 0
        num_workers = worker_info.num_workers if worker_info else 1

        # -------- IN-MEMORY BRANCH (no shards) --------
        if not getattr(self, "use_disk_store", False):
            n = len(self.data)
            ws = max(1, int(getattr(self, "world_size", 1)))
            rk = max(0, int(getattr(self, "rank", 0)))

            # per-rank slice [start, end)
            start = (n * rk) // ws
            end   = (n * (rk + 1)) // ws

            # split that slice across workers
            span   = end - start
            wstart = start + (span * worker_id) // num_workers
            wend   = start + (span * (worker_id + 1)) // num_workers

            for idx in range(wstart, wend):
                sample = self.data[idx]
                lang_code     = sample.get('lang_code','unk')
                input_ids      = sample['input_ids']
                target_data    = sample['labels']
                sample_id      = sample.get('sample_id', idx)
                chunk_id       = sample.get('chunk_id', 0)
                word_positions = sample.get('word_positions', [])

                target_data = [
                    self.ignore_index if t is None
                    else int(t) if isinstance(t, str) and t.lstrip('-').isdigit()
                    else t
                    for t in target_data
                ]

                if not self.is_gen_llm:
                    target_ids = [
                        self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
                        for t in target_data
                    ]
                    pad_token_id = self.tokenizer.pad_token_id
                    padding_length = self.max_seq_length - len(target_ids)
                    target_ids += [pad_token_id] * padding_length
                else:
                    target_ids = target_data

                yield {
                    "lang_code": lang_code,
                    "input_ids": torch.tensor(input_ids, dtype=torch.long),
                    "labels": torch.tensor(target_ids, dtype=torch.long),
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "word_positions": word_positions,
                }
            return

        # ---------- Disk (parquet) mode ----------
        # shard assignment logic (unchanged)
        num_shards = len(self._shard_files)
        base = num_shards // num_workers
        rem = num_shards % num_workers

        if worker_id < rem:
            start = worker_id * (base + 1)
            end = start + base + 1
        else:
            start = rem * (base + 1) + (worker_id - rem) * base
            end = start + base

        assigned_shards = self._shard_files[start:end]

        for shard_idx , shard_path in enumerate(assigned_shards):
            table = pq.read_table(shard_path, columns=None, use_threads=False)
            samples = table.to_pylist()

            # Seeded shuffle for reproducibility
            rank = getattr(self, "rank", 0)
            seed = self.random_seed + shard_idx + worker_id + (rank * 1000)
            rng = random.Random(seed)
            rng.shuffle(samples)

            for sample in samples:
                lang_code = sample['lang_code']
                input_ids = sample['input_ids']
                target_data = sample['labels']
                sample_id = sample['sample_id']
                chunk_id = sample['chunk_id']
                word_positions = sample['word_positions']

                target_data = [
                    self.ignore_index if t is None 
                    else int(t) if isinstance(t, str) and t.lstrip('-').isdigit()
                    else t
                    for t in target_data
                ]

                if not self.is_gen_llm:
                    target_ids = [
                        self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
                        for t in target_data
                    ]
                    pad_token_id = self.tokenizer.pad_token_id
                    padding_length = self.max_seq_length - len(target_ids)
                    target_ids += [pad_token_id] * padding_length
                else:
                    target_ids = target_data  # for generative

                yield {
                    "lang_code": lang_code,
                    "input_ids": torch.tensor(input_ids, dtype=torch.long),
                    "labels": torch.tensor(target_ids, dtype=torch.long),
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "word_positions": word_positions,
                }


    def _get_shards_for_rank(self):
        """
        Split shards evenly across ranks.
        If num_shards % world_size != 0, the first 'remainder' ranks get 1 extra shard.
        """
        num_shards = len(self._shard_files)
        base = num_shards // self.world_size
        rem = num_shards % self.world_size

        if self.rank < rem:
            start = self.rank * (base + 1)
            end = start + base + 1
        else:
            start = rem * (base + 1) + (self.rank - rem) * base
            end = start + base

        return self._shard_files[start:end], self._shard_sizes[start:end]


    def _get_shards_for_worker(self):
        """
        Further split this rank's shards across DataLoader workers.
        Keeps per-worker shard counts balanced.
        """
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info else 0
        num_workers = worker_info.num_workers if worker_info else 1

        rank_shard_files, rank_shard_sizes = self._get_shards_for_rank_balanced()
        num_shards = len(rank_shard_files)

        base = num_shards // num_workers
        rem = num_shards % num_workers

        if worker_id < rem:
            start = worker_id * (base + 1)
            end = start + base + 1
        else:
            start = rem * (base + 1) + (worker_id - rem) * base
            end = start + base

        return rank_shard_files[start:end], rank_shard_sizes[start:end]


    @property
    def total_size(self):
        """Global dataset size (all ranks)."""
        if not getattr(self, "use_disk_store", False):
            return len(self.data)
        return sum(self._shard_sizes)  # this remains 'local' if _shard_sizes is per-rank

    @property
    def num_samples(self):
        """Total samples assigned to THIS rank."""
        if not getattr(self, "use_disk_store", False):
            n  = len(self.data)
            ws = max(1, int(getattr(self, "world_size", 1)))
            rk = max(0, int(getattr(self, "rank", 0)))
            start = (n * rk) // ws
            end   = (n * (rk + 1)) // ws
            return end - start
        shard_files, shard_sizes = self._get_shards_for_rank_balanced()
        return sum(shard_sizes)



    # def __iter__(self):
    #     """Iterate over samples for this worker without per-sample padding."""
    #     worker_shards, _ = self._get_shards_for_worker()

    #     for shard_path in worker_shards:
    #         table = pq.read_table(shard_path, columns=None, use_threads=False)
    #         samples = table.to_pylist()

    #         random.shuffle(samples)  # shard-level shuffle

    #         for sample in samples:
    #             input_ids = sample['input_ids']
    #             target_data = sample['labels']
    #             sample_id = sample['sample_id']
    #             chunk_id = sample['chunk_id']
    #             word_positions = sample['word_positions']

    #             # Clean target_data
    #             target_data = [
    #                 self.ignore_index if t is None 
    #                 else int(t) if isinstance(t, str) and t.lstrip('-').isdigit()
    #                 else t
    #                 for t in target_data
    #             ]

    #             # Map language codes to class IDs only, no padding here
    #             if not self.is_gen_llm:
    #                 target_ids = [
    #                     self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
    #                     for t in target_data
    #                 ]
    #             else:
    #                 target_ids = target_data

    #             yield {
    #                 "input_ids": torch.tensor(input_ids, dtype=torch.long),
    #                 "labels": torch.tensor(target_ids, dtype=torch.long),
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #             }


    
    @property
    def estimated_len(self):
        if self.use_disk_store:
            self.length = sum(self._shard_sizes)
        else:
            self.length = len(self.data)
        return self.length
    # def load_shard(self, shard_path):
    #     samples = []
    #     with open(shard_path, 'r', encoding='utf-8') as f:
    #         samples.extend(f.readlines())
    #     print(f"Loaded {len(samples)} samples from file: {shard_path}")
    #     return samples

    def _get_class_id_from_lang_code(self, lang_code):
        for lang_id, lang_info in self.classes.items():
            if lang_info["lang_code"] == lang_code.strip():
                return lang_id
        #returns unk id as 0
        return self.classes.get("unk", {}).get("id", 0)

    def _get_lang_code_from_class_id(self, class_id):
        return self.classes[class_id]["lang_code"]

    def get_num_classes(self):
        return len(self.classes)

    @staticmethod
    def _process_shard_streaming(args):
        LANG_RE = re.compile(r"[^\d\s]+")  # match non-digit tokens
        shard_path, tokenizer, ignore_index, is_gen_llm = args
        counter = Counter()

        parquet_file = pq.ParquetFile(shard_path)
        for rg in range(parquet_file.num_row_groups):
            table = parquet_file.read_row_group(rg, columns=["labels"])
            labels_column = table["labels"]

            # Convert Arrow list<item> column to Python lists in batch
            labels_batch = labels_column.to_pylist()

            if is_gen_llm:
                # Flatten, skip ignore_index, batch decode
                valid_batches = []
                for labels in labels_batch:
                    valid_ids = [l for l in labels if l != ignore_index]
                    if valid_ids:
                        valid_batches.append(valid_ids)
                if valid_batches:
                    decoded_texts = tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
                    for detok_str in decoded_texts:
                        langs = LANG_RE.findall(detok_str)
                        counter.update(langs)
            else:
                # Directly collect string labels without digits
                for labels in labels_batch:
                    langs = [lbl.strip() for lbl in labels if isinstance(lbl, str) and LANG_RE.match(lbl)]
                    counter.update(langs)

        return counter


    # def _add_languages(self, lang_code_dict):
    #     LANG_RE = re.compile(r"[^\d\s]+")  # match non-digit tokens
    #     counter = Counter()

    #     if not self.use_disk_store:
    #         # Process in-memory data in batches
    #         if self.is_gen_llm:
    #             valid_batches = []
    #             for entry in self.data:
    #                 labels = entry.get("labels", [])
    #                 valid_ids = [l for l in labels if l != self.ignore_index]
    #                 if valid_ids:
    #                     valid_batches.append(valid_ids)
    #             if valid_batches:
    #                 decoded_texts = self.tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
    #                 for detok_str in decoded_texts:
    #                     langs = LANG_RE.findall(detok_str)
    #                     counter.update(langs)
    #         else:
    #             for entry in self.data:
    #                 labels = entry.get("labels", [])
    #                 langs = [lbl.strip() for lbl in labels if isinstance(lbl, str) and LANG_RE.match(lbl)]
    #                 counter.update(langs)
    #     else:
    #         args_list = [
    #             (shard, self.tokenizer, self.ignore_index, self.is_gen_llm)
    #             for shard in self.shard_paths
    #         ]
    #         max_workers = min(cpu_count(), len(self.shard_paths))
    #         with Pool(processes=max_workers) as pool:
    #             for shard_counter in pool.imap_unordered(
    #                 LanguageIdentificationDataset._process_shard_streaming,
    #                 args_list,
    #                 chunksize=1  # ensures shards start fast
    #             ):
    #                 counter.update(shard_counter)

    #     # Build lang_code_dict efficiently
    #     existing_langs = {v['lang_code']: k for k, v in lang_code_dict.items()}

    #     if "unk" not in existing_langs:
    #         new_id = len(lang_code_dict)
    #         lang_code_dict[new_id] = {"lang_code": "unk", "lang_samples": 0, "lang_files": []}
    #         existing_langs["unk"] = new_id

    #     for lang, count in counter.items():
    #         lang = lang.strip()
    #         file_list = self.file_stats.get(lang, [])
    #         if lang in existing_langs:
    #             idx = existing_langs[lang]
    #             existing = lang_code_dict[idx]
    #             lang_code_dict[idx] = {
    #                 "lang_code": lang,
    #                 "lang_samples": existing["lang_samples"] + count,
    #                 "lang_files": list(set(existing["lang_files"] + file_list))
    #             }
    #         else:
    #             new_id = len(lang_code_dict)
    #             lang_code_dict[new_id] = {
    #                 "lang_code": lang,
    #                 "lang_samples": count,
    #                 "lang_files": file_list
    #             }
    #             existing_langs[lang] = new_id

    #     return lang_code_dict    

    def _add_languages(self, lang_code_dict):
        LANG_RE = re.compile(r"[^\d\s]+")  # match non-digit tokens
        counter = Counter()
        file_sample_counts = {}  # store sample counts per language file

        if not self.use_disk_store:
            # In-memory processing
            if self.is_gen_llm:
                valid_batches = []
                for entry in self.data:
                    labels = entry.get("labels", [])
                    valid_ids = [l for l in labels if l != self.ignore_index]
                    if valid_ids:
                        valid_batches.append(valid_ids)
                if valid_batches:
                    decoded_texts = self.tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
                    for detok_str in decoded_texts:
                        langs = LANG_RE.findall(detok_str)
                        counter.update(langs)
            else:
                for entry in self.data:
                    labels = entry.get("labels", [])
                    langs = [lbl.strip() for lbl in labels if isinstance(lbl, str) and LANG_RE.match(lbl)]
                    counter.update(langs)
        else:
            args_list = [
                (shard, self.tokenizer, self.ignore_index, self.is_gen_llm)
                for shard in self.shard_paths
            ]
            max_workers = min(cpu_count(), len(self.shard_paths))
            with Pool(processes=max_workers) as pool:
                for shard_counter in pool.imap_unordered(
                    LanguageIdentificationDataset._process_shard_streaming,
                    args_list,
                    chunksize=1
                ):
                    counter.update(shard_counter)

        # Build lang_code_dict efficiently
        existing_langs = {v['lang_code']: k for k, v in lang_code_dict.items()}

        if "unk" not in existing_langs:
            new_id = len(lang_code_dict)
            lang_code_dict[new_id] = {"lang_code": "unk", "lang_samples": 0, "lang_files": []}
            existing_langs["unk"] = new_id

        for lang, count in counter.items():
            lang = lang.strip()
            # get all files for this language
            file_list = self.file_stats.get(lang, [])
            total_samples = sum(f.get("samples_after_processing", 0) for f in file_list)
            if lang in existing_langs:
                idx = existing_langs[lang]
                existing = lang_code_dict[idx]
                lang_code_dict[idx] = {
                    "lang_code": lang,
                    "lang_samples": existing["lang_samples"] + total_samples,
                    "lang_files": list(set(existing["lang_files"] + file_list))
                }
            else:
                new_id = len(lang_code_dict)
                lang_code_dict[new_id] = {
                    "lang_code": lang,
                    "lang_samples": total_samples,
                    "lang_files": file_list
                }
                existing_langs[lang] = new_id

        return lang_code_dict

    def _normalize_class_weights(self, weights):
        total_weight = np.sum(weights)
        normalized_weights = weights / total_weight
        return normalized_weights

    def _get_class_weights(self, classes_dict):
        # Calculate class weights based on lang_samples
        total_samples = sum(entry['lang_samples'] for entry in classes_dict.values())

        class_weights = {}
        for lang_code, lang_data in classes_dict.items():
            class_samples = lang_data['lang_samples']
            if class_samples > 0:
                # weights are inversely proportional to number of samples
                class_weight = total_samples / (class_samples * len(classes_dict))
            else:
                class_weight = 0  # Set weight to 0 if there are no samples
            classes_dict[lang_code].update({"lang_weight":class_weight})
        class_weights = [entry['lang_weight'] for entry in classes_dict.values()]
        # class_weights = self._normalize_class_weights(class_weights)
        # Update the lang_weights with normalized class weights
        for i, (lang_code, lang_data) in enumerate(classes_dict.items()):
            lang_data["lang_weight"] = class_weights[i]
        return class_weights, classes_dict

    def _get_classes_dict(self, classes_config_path, is_train):
        dist =  torch.distributed.is_initialized()
        rank =  torch.distributed.get_rank() if dist else 0

        if dist:    
            torch.distributed.barrier()
        classes_dict = {}
        class_weights = {}
        if os.path.exists(classes_config_path):
            with open(classes_config_path, mode='r+', encoding='utf8') as ccp:
                # classes_dict = json.load(ccp)
                raw_dict = json.load(ccp)  # Load JSON normally (keys are strings)
    
                classes_dict = {
                    float(k) if "." in k else int(k): v  # Convert only top-level keys
                    for k, v in raw_dict.items()
                }
                class_weights = [classes_dict[i]['lang_weight'] for i in sorted(classes_dict.keys())]
        

        if is_train and rank == 0:
            classes_dict = self._add_languages(lang_code_dict=classes_dict)
            class_weights, classes_dict = self._get_class_weights(classes_dict=classes_dict)

            with open(classes_config_path, mode='w+', encoding='utf8') as ccp_w:
                json.dump(classes_dict, ccp_w, indent=2)
        
        if dist:
            torch.distributed.barrier()
        
        if not class_weights:
            with open(classes_config_path, mode='r+', encoding='utf8') as ccp:
                # classes_dict = json.load(ccp)
                raw_dict = json.load(ccp)  # Load JSON normally (keys are strings)
    
                classes_dict = {
                    float(k) if "." in k else int(k): v  # Convert only top-level keys
                    for k, v in raw_dict.items()
                }
                class_weights = [classes_dict[i]['lang_weight'] for i in sorted(classes_dict.keys())]

        return classes_dict, class_weights
    
    def get_labels(self):
        return [self._get_class_id_from_lang_code(lang_code) for lang_code in self.tgt_data]

    # def __getitem__(self, idx: int) -> Any:
    #     input_ids = self.src_data[idx]  # assumed to be list[int]
    #     target_id = self._get_class_id_from_lang_code(self.tgt_data[idx])
    #     if target_id is None:
    #         print(f'Language not present at idx {idx}, value: {self.tgt_data[idx]}')
    #         target_id = 0  # fallback class

    #     # Safety check for tokenizer.pad_token_id
    #     pad_token_id = self.tokenizer.pad_token_id
    #     if pad_token_id is None:
    #         pad_token_id = self.tokenizer.eos_token_id  # fallback
    #         self.tokenizer.pad_token = self.tokenizer.eos_token  # ensure consistency

    #     max_len = self.max_seq_length
    #     seq_len = len(input_ids)

    #     # Pad input_ids
    #     input_ids = input_ids[:max_len]
    #     padding_length = max_len - len(input_ids)
    #     input_ids += [pad_token_id] * padding_length

    #     # Attention mask: 1s for real tokens, 0s for padding
    #     attention_mask = [1] * min(seq_len, max_len) + [0] * padding_length

    #     # For classification per token, repeat target_id; or return single class label
    #     target_ids = [target_id] * min(seq_len, max_len) + [-100] * padding_length  # -100 to ignore loss on pad

    #     return (
    #         torch.tensor(input_ids, dtype=torch.long),
    #         torch.tensor(attention_mask, dtype=torch.long),
    #         torch.tensor(target_ids, dtype=torch.long),
    #     )
    
    # def __getitem__(self, idx):
    #     # input_ids = self.src_data[idx]
    #     # target_data = self.tgt_data[idx]
    #     # sample = self.data[idx]
    #     if self.use_disk_store:
    #         shard_files = sorted(glob.glob(f"{self.disk_store_dir}/rank_{self.rank}_shard_*.parquet"))
    #         running_total = 0
    #         sample = None
    #         for shard in shard_files:
    #             num_rows = pq.read_metadata(shard).num_rows
    #             if idx < running_total + num_rows:
    #                 row_idx = idx - running_total
    #                 table = pq.read_table(shard, columns=None, use_threads=False)
    #                 sample = table.to_pylist()[row_idx]
    #                 break
    #             running_total += num_rows
    #     else:
    #         sample = self.data[idx]

    #     input_ids = sample['input_ids']
    #     target_data = sample['labels']
    #     sample_id = sample['sample_id']
    #     chunk_id = sample['chunk_id']
    #     word_positions = sample['word_positions']

    #     # Replace None in target_data with self.ignore_index
    #     # target_data = [
    #     #     self.ignore_index if t is None else t
    #     #     for t in target_data
    #     # ]
    #     target_data = [
    #         self.ignore_index if t is None 
    #         else int(t) if isinstance(t, str) and t.lstrip('-').isdigit()
    #         else t
    #         for t in target_data
    #     ]

    #     # Show only the *first* sample in val and test mode
    #     # if not hasattr(self, "_has_logged_sample"):
    #     #     self._has_logged_sample = {"val": False, "test": False}

    #     # if not self.is_train and not self._has_logged_sample["test"] and idx == 0:
    #     #     print(f"[TEST] Sample idx=0\nInput IDs: {input_ids}\nTarget: {target_data}")
    #     #     self._has_logged_sample["test"] = True
    #     # elif self.is_train is False and not self._has_logged_sample["val"] and idx == 0:
    #     #     print(f"[VAL] Sample idx=0\nInput IDs: {input_ids}\nTarget: {target_data}")
    #     #     self._has_logged_sample["val"] = True

    #     # Now apply class ID mapping
    #     if self.is_gen_llm == False:
    #         target_ids = [
    #             self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
    #             for t in target_data
    #         ]
    #         # Safety check for tokenizer.pad_token_id
    #         pad_token_id = self.tokenizer.pad_token_id
    #         # if pad_token_id is None:
    #         #     pad_token_id = self.tokenizer.eos_token_id  # fallback
    #         #     self.tokenizer.pad_token = self.tokenizer.eos_token  # ensure consistency

    #         max_len = self.max_seq_length
    #         seq_len = len(target_ids)

    #         padding_length = max_len - seq_len
    #         # For classification per token, repeat target_id; or return single class label
    #         target_ids = target_ids + [pad_token_id] * padding_length  # -100 to ignore loss on pad
    #     else:
    #         # gen llm only
    #         target_ids = target_data
    #     # target_ids = [
    #     #         self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
    #     #         for t in target_data
    #     #     ]
    #     # # Safety check for tokenizer.pad_token_id
    #     # pad_token_id = self.tokenizer.pad_token_id
    #     # if pad_token_id is None:
    #     #     pad_token_id = self.tokenizer.eos_token_id  # fallback
    #     #     self.tokenizer.pad_token = self.tokenizer.eos_token  # ensure consistency

    #     # max_len = self.max_seq_length
    #     # seq_len = len(target_ids)

    #     # padding_length = max_len - seq_len
    #     # # For classification per token, repeat target_id; or return single class label
    #     # target_ids = target_ids + [-100] * padding_length  # -100 to ignore loss on pad

    #     # return (
    #     #     torch.tensor(input_ids, dtype=torch.long),
    #     #     torch.tensor(target_ids, dtype=torch.long)
    #     # )
    #     return {
    #         "input_ids": torch.tensor(input_ids, dtype=torch.long),
    #         "labels": torch.tensor(target_ids, dtype=torch.long),
    #         "sample_id": sample_id,
    #         "chunk_id": chunk_id,
    #         "word_positions": word_positions,  # keep as list, tensorize later if needed
    #     }

    def validate_windowing_samples(self, num_samples: int = 5):
        """
        Validates windowed source text and label alignment on a random sample of the dataset.
        Useful for debugging tokenizer behavior and checking label correctness.
        """
        if not hasattr(self, 'src_data') or not hasattr(self, 'tgt_data'):
            self.log.warning("No src_data or tgt_data loaded. Cannot validate.")
            return

        from random import sample
        from transformers import PreTrainedTokenizer

        tokenizer = self.tokenizer
        if not isinstance(tokenizer, PreTrainedTokenizer):
            self.log.warning("Tokenizer does not support decode(). Skipping validation.")
            return

        indices = sample(range(len(self.src_data)), min(num_samples, len(self.src_data)))

        for idx in indices:
            input_ids = self.src_data[idx]
            tgt_label = self.tgt_data[idx]

            print(f"\n=== SAMPLE {idx} ===")
            decoded_text = tokenizer.decode(input_ids, skip_special_tokens=True)
            print(f"Decoded window text: {decoded_text}")
            print(f"Input IDs (len={len(input_ids)}): {input_ids}")
            print(f"Target label: {tgt_label}")

            if isinstance(tgt_label, list):
                print(f"Label list length: {len(tgt_label)}")
                print(f"Label values (truncated): {tgt_label[:10]}...")
                if len(input_ids) != len(tgt_label):
                    print("Length mismatch between input IDs and token-level labels.")
            else:
                print("Label is per-sequence, not per-token.")


    def _similar_name(self, name_1: str, name_2: str) -> float:
        """
        takes two filenames, compares and returns the match score
        :param name_1: file name of file 1
        :param name_2: file name of file 2
        :return: match score
        """
        return SequenceMatcher(None, name_1, name_2).ratio()

    # Function to calculate overlap length based on percentage
    def _calculate_overlap(self, overlap_percentage):
        return int(self.max_seq_length * overlap_percentage)
    
    @staticmethod
    def _split_into_token_windows(tokens, max_len, overlap_ratio=0.5):
        step = int(max_len * (1 - overlap_ratio))
        if step < 1: step = 1
        return [tokens[i:i + max_len] for i in range(0, len(tokens), step)]

    # Function to split line into overlapping windows
    @staticmethod
    def _split_into_windows(src_line, overlap_length, max_seq_length):
        windows = []
        for i in range(0, len(src_line), max_seq_length - overlap_length):
            windows.append(src_line[i:i + max_seq_length])
        return windows

    @staticmethod
    def tokenize_words_fast(text: str, tokenizer, add_special_tokens=True) -> List[List[int]]:
        """
        Tokenize text into per-word token IDs using a stateless encoder_ function.
        Assumes encoder_ is a callable configured with is_split_into_words=True.
        """
        words = text.split()
        encodings = tokenizer(words, is_split_into_words=True, add_special_tokens=add_special_tokens)  # encoder_ must be a lightweight tokenizer function

        word_ids = encodings.word_ids()
        input_ids = encodings.input_ids

        grouped_tokens = []
        current_word = -1
        current_tokens = []

        for token_id, word_id in zip(input_ids, word_ids):
            if word_id is None:
                continue
            if word_id != current_word:
                if current_tokens:
                    grouped_tokens.append(current_tokens)
                current_tokens = [token_id]
                current_word = word_id
            else:
                current_tokens.append(token_id)
        if current_tokens:
            grouped_tokens.append(current_tokens)

        return grouped_tokens


    @staticmethod
    def _split_into_windows_for_gen_llm(
        prompt_template: str,
        src_line: str,
        tgt_line: str,
        overlap_percentage: float,
        max_seq_length: int,
        tokenizer
    ):
        """
        Efficiently splits input into overlapping windows and tokenizes them in batch.
        - Uses {input_text} and {response} placeholders in the prompt_template
        - {response} is just space-separated labels
        """

        src_words = src_line.strip().split()
        tgt_labels = tgt_line.strip().split()
        single_label = len(tgt_labels) == 1

        # assert not (len(src_words) != len(tgt_labels) and not single_label), \
        #     "Mismatch between source words and target labels"

        # assert "{input_text}" in prompt_template and "{response}" in prompt_template, \
        #     "Prompt template must include {input_text} and {response}"

        # Estimate tokens per word
        test_src = src_words[:10]
        test_tgt = [tgt_labels[0]] * len(test_src) if single_label else tgt_labels[:10]
        test_prompt = prompt_template.replace("{input_text}", " ".join(test_src)).replace("{response}", " ".join(test_tgt))
        test_tokens = tokenizer.encode(test_prompt, add_special_tokens=True)
        avg_tokens_per_word = len(test_tokens) / max(1, len(test_src))

        est_words_per_window = int(max_seq_length / avg_tokens_per_word)
        if est_words_per_window < 1:
            raise ValueError("max_seq_length too small to fit even one word")

        overlap_words = int(overlap_percentage * est_words_per_window)

        # First, collect prompt strings for all windows
        prompt_texts = []
        start = 0
        last_end = 0
        window_spans = []

        while start < len(src_words):
            end = min(start + est_words_per_window, len(src_words))
            src_window = src_words[start:end]
            tgt_window = [tgt_labels[0]] * len(src_window) if single_label else tgt_labels[start:end]

            prompt_text = prompt_template.replace("{input_text}", " ".join(src_window)).replace("{response}", " ".join(tgt_window))
            prompt_texts.append(prompt_text)
            window_spans.append((start, end))  # for debugging or reference

            if end >= len(src_words):
                break
            start = max(end - overlap_words, last_end + 1)
            last_end = end

        # Tokenize all at once
        tokenized_outputs = tokenizer(
            prompt_texts,
            add_special_tokens=True,
            truncation=False,
            return_attention_mask=False
        )

        # Filter based on length
        windows = [
            tokens for tokens in tokenized_outputs["input_ids"]
            if len(tokens) <= max_seq_length
        ]

        # print(f"Original line {src_line} and ")
        # for win in windows:
        #     print(f"decoded window {LanguageIdentificationDataset.decode_text(win, tokenizer=tokenizer)}")

        return windows



    @staticmethod
    def _is_arabic(text):
        for char in text:
            if 'ARABIC' not in unicodedata.name(char, ''):
                return False
        return True

    @staticmethod
    def _reverse_arabic_sentence(sentence):
        if LanguageIdentificationDataset._is_arabic(sentence):
            # If the sentence is in Arabic script, reverse it
            # reversed_sentence = sentence[::-1]
            # Step 1: Split the sentence into words
            words = sentence.strip().split()

            # Step 2: Reverse the order of words (keeping characters in place)
            reversed_sentence = " ".join(reversed(words))
            # reversed_sentence = sentence
            return reversed_sentence
        else:
            return sentence
    
    @staticmethod
    def _is_english_string(input_string):
        # Function to check if a character is part of the English alphabet
        def is_english_char(char):
            return 'a' <= char.lower() <= 'z'

        # Convert the string to a list of characters
        characters = list(input_string)

        # Count the English alphabet characters
        english_chars_count = sum(1 for char in characters if is_english_char(char))

        # Calculate the percentage of English alphabet characters
        percentage_english = english_chars_count / len(characters)

        # Check if more than 50% of characters are from the English alphabet
        return percentage_english > 0.5
    
    @staticmethod
    def process_line(args):
        """
        Process a single line: clean, check language, tokenize, and split.
        Returns (src_tokens, tgt_line) if valid, else None.
        """
        (src_line, tgt_line, max_seq_length, overlap_percentage, pad_token_id, 
         is_english_func, split_windows_func, tokenizer_encode_func) = args

        tgt_line = tgt_line.strip()
        src_line = ' '.join(src_line.split())  # Remove extra spaces

        # Check language constraints
        is_english = is_english_func(src_line)
        if ("_en" in tgt_line and not is_english) or ("_en" not in tgt_line and is_english):
            return None  # Skip mismatched languages

        src_tokens = tokenizer_encode_func(src_line)

        # Handle long sequences
        if len(src_tokens) > max_seq_length:
            overlap_len = int(overlap_percentage * max_seq_length)
            windows = split_windows_func(src_tokens, overlap_len, max_seq_length)
            windows = [win + [pad_token_id] * (max_seq_length - len(win)) for win in windows]
            return [(win, tgt_line) for win in windows]
        else:
            # Pad shorter sequences to max_seq_length
            src_tokens += [pad_token_id] * (max_seq_length - len(src_tokens))
            return [(src_tokens, tgt_line)]

    @staticmethod
    def process_line_gen_llm(args):
        """
        Process a single line: clean, check language, tokenize, and split.
        Returns (src_tokens, tgt_line) if valid, else None.
        """
        (prompt_template, src_line, tgt_line, max_seq_length, overlap_percentage, pad_token_id, tokenizer,
        is_english_func, split_windows_func, tokenizer_encode_func) = args

        tgt_line = tgt_line.strip()
        org_tgt_line = tgt_line
        src_line = ' '.join(src_line.split())  # Normalize whitespace

        # Check language constraints
        is_english = is_english_func(src_line)
        if ("_en" in tgt_line and not is_english) or ("_en" not in tgt_line and is_english):
            return None  # Skip mismatched languages

        # Replace {input_text}
        filled_prompt = prompt_template.replace("{input_text}", src_line)

        # Trim at {response} if present
        if "{response}" in filled_prompt:
            filled_prompt = filled_prompt.split("{response}")[0]  # drop everything after {response}

        # Tokenize
        prompt_tokens = tokenizer_encode_func(filled_prompt, add_special_tokens=True)

        # Adjust tgt_line for label alignment
        tgt_line = " ".join([tgt_line] * len(src_line.strip().split())) if len(tgt_line.split()) == 1 and tgt_line.strip() else tgt_line
        if len(src_line.split()) != len(tgt_line.split()):
            raise ValueError(f"Source line and Target line tokens dont match for {src_line}")

        # src_tokens = tokenizer_encode_func(src_line, add_special_tokens=False)
        tgt_tokens = tokenizer_encode_func(tgt_line, add_special_tokens=False)

        total_prompt_tokens = prompt_tokens + tgt_tokens

        # print(f"Current Tokens {total_prompt_tokens}")
        # decoded_prompt = LanguageIdentificationDataset.decode_text(total_prompt_tokens, tokenizer)
        # print(f"Decoded prompt {decoded_prompt}")

        # Handle long sequences
        if len(total_prompt_tokens) > max_seq_length:
            # print(f"splitting {len(total_prompt_tokens)}")
            try:
                windows = split_windows_func(prompt_template, src_line, org_tgt_line,
                                            overlap_percentage, max_seq_length, tokenizer)
            except Exception as e:
                print(f"Windows exception {e}")
            return [(win, org_tgt_line) for win in windows]
        else:
            return [(total_prompt_tokens, org_tgt_line)]

    # @staticmethod
    # def process_batch(args):
    #     src_lines, tgt_lines, max_seq_len, overlap_ratio = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     results = []

    #     for src, tgt in zip(src_lines, tgt_lines):
    #         src = src.strip()
    #         words = src.split()
    #         tgt_parts = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # Case 1: Single label
    #         if len(tgt_parts) == 1:
    #             word_labels = [tgt_parts[0]] * len(words)

    #         # Case 2: Word-level labels
    #         elif len(tgt_parts) == len(words):
    #             word_labels = tgt_parts

    #         else:
    #             continue  # skip badly aligned lines

    #         input_ids = []
    #         labels = []

    #         for word, label in zip(words, word_labels):
    #             tokens = tokenizer.encode(word, add_special_tokens=False)
    #             input_ids.extend(tokens)

    #             if len(tokens) > 0:
    #                 labels.append(label)  # Label the first token
    #                 labels.extend([tokenizer.pad_token_id] * (len(tokens) - 1))  # Ignore the rest

    #         step = int(max_seq_len * (1 - overlap_ratio))
    #         for i in range(0, len(input_ids), step):
    #             chunk_ids = input_ids[i:i + max_seq_len]
    #             chunk_labels = labels[i:i + max_seq_len]

    #             pad_len = max_seq_len - len(chunk_ids)
    #             results.append((
    #                 chunk_ids + [pad_id] * pad_len,
    #                 chunk_labels + [tokenizer.pad_token_id] * pad_len
    #             ))

    #     return results

    # @staticmethod
    # def process_batch_classifier(args):
    #     src_lines, tgt_lines, max_seq_len, overlap_ratio = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     ignore_label = tokenizer.pad_token_id  # or a custom ignore index

    #     results = []

    #     for sample_id, (src, tgt) in enumerate(zip(src_lines, tgt_lines)):
    #         src_words = src.strip().split()
    #         tgt_labels = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # Skip misaligned label cases
    #         if len(tgt_labels) == 1:
    #             word_labels = [tgt_labels[0]] * len(src_words)
    #         elif len(tgt_labels) == len(src_words):
    #             word_labels = tgt_labels
    #         else:
    #             continue

    #         # Proper tokenization with word alignment
    #         tokenized = tokenizer(
    #             src_words,
    #             add_special_tokens=False,
    #             return_attention_mask=False,
    #             return_token_type_ids=False,
    #             is_split_into_words=True
    #         )

    #         word_ids = tokenized.word_ids()  # List of word index for each token

    #         flat_input_ids = tokenized["input_ids"]
    #         flat_labels = []
    #         word_start_indices = []
    #         current_word = None

    #         for i, word_idx in enumerate(word_ids):
    #             if word_idx is None:
    #                 # Skip tokens not associated with a word (unlikely without special tokens)
    #                 continue
    #             # Mark the start index of each new word
    #             if word_idx != current_word:
    #                 word_start_indices.append(i)
    #                 current_word = word_idx
    #                 # First token of the word gets the label
    #                 flat_labels.append(word_labels[word_idx])
    #             else:
    #                 # Subsequent tokens get ignore label
    #                 flat_labels.append(ignore_label)

    #         step = max(1, int(max_seq_len * (1 - overlap_ratio)))
    #         n = len(flat_input_ids)
    #         i = 0
    #         chunk_id = 0
    #         prev_end = -1

    #         while i < n:
    #             input_ids = flat_input_ids[i:i + max_seq_len]
    #             labels = flat_labels[i:i + max_seq_len]

    #             pad_len = max_seq_len - len(input_ids)
    #             input_ids += [pad_id] * pad_len
    #             labels += [ignore_label] * pad_len

    #             # Find word indices partially included in this chunk
    #             word_positions = [
    #                 wi for wi, start_idx in enumerate(word_start_indices)
    #                 if i <= start_idx < i + max_seq_len
    #             ]

    #             results.append({
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #             })

    #             if i + step >= n or i + step <= prev_end:
    #                 break

    #             prev_end = i + max_seq_len
    #             i += step
    #             chunk_id += 1

    #     return results
    
    # Old working
    # @staticmethod
    # def process_batch_classifier(args):
    #     src_lines, tgt_lines, max_seq_len, overlap_ratio = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     ignore_label = tokenizer.pad_token_id  # or custom ignore index

    #     results = []

    #     for sample_id, (src, tgt) in enumerate(zip(src_lines, tgt_lines)):
    #         src_words = src.strip().split()
    #         tgt_labels = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         if len(tgt_labels) == 1:
    #             word_labels = [tgt_labels[0]] * len(src_words)
    #         elif len(tgt_labels) == len(src_words):
    #             word_labels = tgt_labels
    #         else:
    #             continue  # skip misaligned

    #         # tokenize words once
    #         tokenized = tokenizer(
    #             src_words,
    #             add_special_tokens=False,
    #             return_attention_mask=False,
    #             return_token_type_ids=False,
    #             is_split_into_words=True
    #         )

    #         input_ids = tokenized["input_ids"]
    #         word_ids = tokenized.word_ids()

    #         # precompute flat_labels
    #         flat_labels = [ignore_label] * len(input_ids)
    #         word_start_indices = []
    #         current_word = None
    #         for i, word_idx in enumerate(word_ids):
    #             if word_idx is None:
    #                 continue
    #             if word_idx != current_word:
    #                 word_start_indices.append(i)
    #                 current_word = word_idx
    #                 flat_labels[i] = word_labels[word_idx]
    #             else:
    #                 flat_labels[i] = ignore_label

    #         # sliding chunks by word-aligned step
    #         step = max(1, int(max_seq_len * (1 - overlap_ratio)))
    #         n = len(input_ids)
    #         i = 0
    #         chunk_id = 0
    #         prev_end = -1

    #         while i < n:
    #             end_idx = i + max_seq_len
    #             chunk_input_ids = input_ids[i:end_idx]
    #             chunk_labels = flat_labels[i:end_idx]

    #             # pad if needed
    #             pad_len = max_seq_len - len(chunk_input_ids)
    #             if pad_len > 0:
    #                 chunk_input_ids += [pad_id] * pad_len
    #                 chunk_labels += [ignore_label] * pad_len

    #             # word positions in chunk
    #             word_positions = [wi for wi, start_idx in enumerate(word_start_indices)
    #                             if i <= start_idx < end_idx]

    #             results.append({
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #                 "input_ids": chunk_input_ids,
    #                 "labels": chunk_labels,
    #             })

    #             if end_idx >= n or end_idx <= prev_end:
    #                 break
    #             prev_end = end_idx
    #             i += step
    #             chunk_id += 1

    #     return results


    # @staticmethod
    # def process_batch_classifier(args):
    #     src_lines, tgt_lines, max_seq_len, overlap_ratio = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     ignore_label = tokenizer.pad_token_id  # or custom ignore index

    #     results = []

    #     # Preprocess target labels into lists
    #     tgt_lists = []
    #     for tgt, src in zip(tgt_lines, src_lines):
    #         tgt_labels = tgt if isinstance(tgt, list) else tgt.strip().split()
    #         src_words = src.strip().split()
    #         # print(f"Stage 1 : source {src_words} and {tgt_labels}")
    #         if len(tgt_labels) == 1:
    #             tgt_lists.append([tgt_labels[0]] * len(src_words))
    #         elif len(tgt_labels) == len(src_words):
    #             tgt_lists.append(tgt_labels)
    #         else:
    #             tgt_lists.append(None)  # misaligned
    #     # print(f"Stage 2: {tgt_lists}")
    #     # Filter out misaligned
    #     filtered = [(s.strip().split(), t) for s, t in zip(src_lines, tgt_lists) if t is not None]
    #     if not filtered:
    #         return results

    #     src_words_batch, tgt_labels_batch = zip(*filtered)
    #     # print(f"Stage 3: src {src_words_batch[0]} and tgt {tgt_labels_batch[0]}")

    #     # Batch tokenization
    #     tokenized = tokenizer(
    #         src_words_batch,
    #         add_special_tokens=False,
    #         return_attention_mask=False,
    #         return_token_type_ids=False,
    #         is_split_into_words=True,
    #         padding=False,
    #     )

    #     batch_input_ids = tokenized["input_ids"]
    #     batch_word_ids = [tokenized.word_ids(i) for i in range(len(batch_input_ids))]

    #     for sample_id, (input_ids, word_ids, word_labels) in enumerate(zip(batch_input_ids, batch_word_ids, tgt_labels_batch)):
    #         # flat labels aligned to tokens
    #         flat_labels = [ignore_label] * len(input_ids)
    #         word_start_indices = []
    #         current_word = None
    #         for i, widx in enumerate(word_ids):
    #             if widx is None:
    #                 continue
    #             if widx != current_word:
    #                 word_start_indices.append(i)
    #                 current_word = widx
    #                 flat_labels[i] = word_labels[widx]
    #             else:
    #                 flat_labels[i] = ignore_label

    #         # sliding chunks
    #         step = max(1, int(max_seq_len * (1 - overlap_ratio)))
    #         n = len(input_ids)
    #         i = 0
    #         chunk_id = 0
    #         prev_end = -1

    #         while i < n:
    #             end_idx = i + max_seq_len
    #             chunk_input_ids = input_ids[i:end_idx]
    #             chunk_labels = flat_labels[i:end_idx]

    #             pad_len = max_seq_len - len(chunk_input_ids)
    #             if pad_len > 0:
    #                 chunk_input_ids += [pad_id] * pad_len
    #                 chunk_labels += [ignore_label] * pad_len

    #             word_positions = [wi for wi, start_idx in enumerate(word_start_indices)
    #                             if i <= start_idx < end_idx]

    #             results.append({
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #                 "input_ids": chunk_input_ids,
    #                 "labels": chunk_labels,
    #             })

    #             if sample_id == 0:
    #                 print(f"Stage Results {results[sample_id]}")

    #             if end_idx >= n or end_idx <= prev_end:
    #                 break
    #             prev_end = end_idx
    #             i += step
    #             chunk_id += 1

    #     return results

    @staticmethod
    def process_batch_classifier(args):
        src_lines, tgt_lines, max_seq_len, overlap_ratio = args
        tokenizer = LanguageIdentificationDataset.TOKENIZER
        pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
        ignore_label = tokenizer.pad_token_id  # or custom ignore index

        space_ids = [tokenizer.pad_token_id]

        results = []

        for sample_id, (src, tgt) in enumerate(zip(src_lines, tgt_lines)):
            src_words = src.strip().split()
            tgt_labels = tgt if isinstance(tgt, list) else tgt.strip().split()

            # Align targets
            if len(tgt_labels) == 1:
                src_word_labels = [tgt_labels[0]] * len(src_words)
            elif len(tgt_labels) == len(src_words):
                src_word_labels = tgt_labels
            else:
                continue  # skip misaligned

            # Tokenize words (just source side)
            tokenized_src_words = tokenizer(
                src_words,
                add_special_tokens=False,
                return_attention_mask=False,
                return_token_type_ids=False,
            )

            src_word_token_info = [
                (word, tokens, len(tokens))
                for word, tokens in zip(src_words, tokenized_src_words["input_ids"])
            ]

            i = 0
            n = len(src_word_token_info)
            chunk_id = 0
            prev_j = -1

            while i < n:
                total_len = 0
                chunk_input_tokens = []
                chunk_words = []
                chunk_labels = []
                word_positions = []

                j = i
                while j < n:
                    src_word, src_ids, src_len = src_word_token_info[j]
                    tgt_label = src_word_labels[j]

                    # if not last word, add trailing space
                    if j < n - 1:
                        word_total = src_len + len(space_ids)
                    else:
                        word_total = src_len

                    if total_len + word_total > max_seq_len:
                        break  # finalize current chunk

                    if j < n - 1:
                        chunk_input_tokens.extend(src_ids + space_ids)
                    else:
                        chunk_input_tokens.extend(src_ids)

                    chunk_words.append(src_word)
                    chunk_labels.append(tgt_label)
                    word_positions.append(len(word_positions))  # local consecutive index

                    total_len += word_total
                    j += 1

                if not chunk_input_tokens:
                    i += 1
                    continue

                input_ids = chunk_input_tokens
                labels = chunk_labels  # word-level labels only

                # pad input_ids if needed
                pad_len = max_seq_len - len(input_ids)
                if pad_len > 0:
                    input_ids += [pad_id] * pad_len
                    # labels remain at word-level length (no padding)

                results.append({
                    "lang_code": tgt_label,
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "word_positions": word_positions.copy(),
                    "input_ids": input_ids,
                    "labels": labels,
                })

                # if sample_id == 0:
                #     print(f"Stage Results {results[sample_id]}")

                chunk_id += 1

                if j >= n or j <= prev_j:
                    break
                prev_j = j

                # Overlap step
                overlap = max(1, int(overlap_ratio * len(chunk_words)))
                i = j - overlap if j - overlap > i else j

        return results

    # @staticmethod
    # def process_batch_gen_llm(args):
    #     prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER

    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100  # Standard for loss masking
    #     response_prefix = "###Response:\n"
    #     results = []

    #     for src, tgt in zip(src_lines, tgt_lines):
    #         src = src.strip()
    #         src_words = src.split()
    #         tgt_words = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # Check alignment: one label per word
    #         if len(tgt_words) == 1:
    #             tgt_word_labels = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) == len(src_words):
    #             tgt_word_labels = tgt_words
    #         else:
    #             continue  # Skip misaligned

    #         # Step 1: Prompt with real input
    #         prompt = prompt_template.format(input_text=src)
    #         prompt_ids = tokenizer.encode(prompt, add_special_tokens=False)
            

    #         # Step 2: Tokenize words + assign label to first subtoken, ignore rest
    #         response_ids, response_labels = [], []

    #         for word, label in zip(src_words, tgt_word_labels):
    #             word_ids = tokenizer.encode(word, add_special_tokens=False)
    #             if not word_ids:
    #                 continue
                
    #             response_ids.extend(word_ids)
    #             response_labels.append(label)  # First token gets label
    #             response_labels.extend([ignore_index] * (len(word_ids) - 1))  # Rest ignored

    #         # Step 3: Final full input + label
    #         full_input_ids = prompt_ids + response_ids + [eos_id]
    #         full_labels = [ignore_index] * len(prompt_ids) + response_labels + [ignore_index]

    #         # Step 4: Sliding window
    #         step = int(max_seq_len * (1 - overlap_ratio))
    #         for i in range(0, len(full_input_ids), step):
    #             chunk_ids = full_input_ids[i:i + max_seq_len]
    #             chunk_labels = full_labels[i:i + max_seq_len]

    #             # Pad if needed
    #             pad_len = max_seq_len - len(chunk_ids)
    #             chunk_ids += [pad_id] * pad_len
    #             chunk_labels += [ignore_index] * pad_len

    #             results.append((chunk_ids, chunk_labels))

    #     return results

    # @staticmethod
    # def process_batch_gen_llm(args):
    #     prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER

    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100

    #     input_prefix = "\n### Input:\n"
    #     response_prefix = "\n### Response:\n"

    #     results = []

    #     for src, tgt in zip(src_lines, tgt_lines):
    #         src_words = src.strip().split()
    #         tgt_words = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # Alignment: one label per word
    #         if len(tgt_words) == 1:
    #             src_word_labels = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) == len(src_words):
    #             src_word_labels = tgt_words
    #         else:
    #             continue  # Skip misaligned

    #         instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
    #         input_ids = tokenizer.encode(input_prefix + src.strip(), add_special_tokens=False)
    #         response_ids = tokenizer.encode(response_prefix + " ".join(tgt_words), add_special_tokens=False)

    #         prompt_ids = instruction_ids + input_ids + response_ids + [eos_id]
    #         label_prefix_len = len(instruction_ids) + len(input_ids)
    #         labels = [ignore_index] * label_prefix_len + response_ids + [eos_id]

    #         if len(prompt_ids) <= max_seq_len:
    #             padded_input_ids = prompt_ids + [pad_id] * (max_seq_len - len(prompt_ids))
    #             padded_labels = labels + [ignore_index] * (max_seq_len - len(labels))
    #             results.append((padded_input_ids, padded_labels))
    #             continue

    #         # Word-aligned sliding window fallback
    #         window_size = len(src_words)
    #         step_size = max(1, int(window_size * (1 - overlap_ratio)))

    #         for i in range(0, len(src_words), step_size):
    #             chunk_src_words = src_words[i:i + window_size]
    #             chunk_tgt_words = src_word_labels[i:i + window_size]

    #             while len(chunk_src_words) > 0:
    #                 input_text = input_prefix + " ".join(chunk_src_words)
    #                 response_text = response_prefix + " ".join(chunk_tgt_words)

    #                 input_ids = tokenizer.encode(input_text, add_special_tokens=False)
    #                 response_ids = tokenizer.encode(response_text, add_special_tokens=False)

    #                 prompt_ids = instruction_ids + input_ids + response_ids + [eos_id]
    #                 label_prefix_len = len(instruction_ids) + len(input_ids)
    #                 labels = [ignore_index] * label_prefix_len + response_ids + [eos_id]

    #                 if len(prompt_ids) <= max_seq_len:
    #                     padded_input_ids = prompt_ids + [pad_id] * (max_seq_len - len(prompt_ids))
    #                     padded_labels = labels + [ignore_index] * (max_seq_len - len(labels))
    #                     results.append((padded_input_ids, padded_labels))
    #                     break

    #                 # Shrink the window
    #                 chunk_src_words = chunk_src_words[:-1]
    #                 chunk_tgt_words = chunk_tgt_words[:-1]

        # return results
    
    @staticmethod
    def process_batch_gen_llm(args):
        prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train = args

        tokenizer = LanguageIdentificationDataset.TOKENIZER

        pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
        eos_id = tokenizer.eos_token_id
        ignore_index = -100

        input_prefix = "\n<|start_header_id|>user<|end_header_id|>\n"
        response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"

        results = []
        instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
        input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
        response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
        space_ids = tokenizer.encode(" ", add_special_tokens=False)
        prefix = instruction_ids + input_prefix_ids
        suffix = response_prefix_ids
        eos_len = 1  # for eos_id

        fixed_len = len(prefix) + len(suffix) + eos_len

        results = []
        sample_id_counter = 0  # Add this outside your zip loop

        for sample_id, (src, tgt) in enumerate(zip(src_lines, tgt_lines)):
            chunk_id = 0
            # if is_train == False:
            #     print(f"Eval raw {src} and {tgt}")
            src_words = src.strip().split()
            tgt_words = tgt if isinstance(tgt, list) else tgt.strip().split()

            if len(tgt_words) == 1:
                src_word_labels = [tgt_words[0]] * len(src_words)
            elif len(tgt_words) == len(src_words):
                src_word_labels = tgt_words
            else:
                print(f"Invalid Pair in data {src} and {tgt_words}")
                continue  # skip invalid pair

            # if is_train == False:
            #     print(f"in Eval Mode {src_words} and {src_word_labels}")
            
            tokenized_src_words = tokenizer(
                src_words,
                add_special_tokens=False,
                return_attention_mask=False,
                return_token_type_ids=False,
            )

            # if is_train == False:
            #     print(f"in Eval Mode {src_words} and {tokenized_src_words}")

            src_word_token_info = [
                (word, tokens, len(tokens))
                for word, tokens in zip(src_words, tokenized_src_words["input_ids"])
            ]
            
            tokenized_tgt_words = tokenizer(
                src_word_labels,
                add_special_tokens=False,
                return_attention_mask=False,
                return_token_type_ids=False,
            )

            tgt_word_token_info = [
                (word, tokens, len(tokens))
                for word, tokens in zip(src_word_labels, tokenized_tgt_words["input_ids"])
            ]

            i = 0
            n = len(src_word_token_info)
            fixed_len = len(prefix) + len(suffix) + eos_len
            all_chunk_texts = []
            all_chunk_label_seqs = []
            # if is_train == False:
            #     print(f"Src token info  {len(src_word_token_info)} and tgt {len(tgt_word_token_info)}")
            # Last chunk repetion prevention check 
            prev_j = -1

            while i < n:
                word_positions = []  # NEW: track word indices in full sequence
                total_len = fixed_len
                chunk_input_tokens = []
                chunk_label_tokens = []
                chunk_words = []
                chunk_labels = []

                j = i
                while j < n:
                    src_word, src_ids, src_len = src_word_token_info[j]
                    tgt_word, tgt_ids, tgt_len = tgt_word_token_info[j]
                    # if is_train == False:
                    #     print(f"Eval check {src_word, src_ids, src_len} and {tgt_word, tgt_ids, tgt_len}")

                    # word_total = src_len + tgt_len + 2 * len(space_ids)
                    word_total = src_len + tgt_len + (2 * len(space_ids) if j < n - 1 else 0)
                    # if total_len + word_total > max_seq_len:
                    #     break
                    # If the word itself is unchunkable, skip it and move on
                    if total_len + word_total > max_seq_len:
                        break  # finalize current chunk

                    if j < n - 1:  # not the last word
                        chunk_input_tokens.append(src_ids + space_ids)
                        chunk_label_tokens.append(tgt_ids + space_ids)
                    else:  # last word: no trailing space
                        chunk_input_tokens.append(src_ids)
                        chunk_label_tokens.append(tgt_ids)
                    chunk_words.append(src_word)
                    chunk_labels.append(tgt_word)
                    word_positions.append(j)  # NEW: store index of this word in original sentence
                    # if is_train == False:
                    #     print(f"Now Adding {chunk_words} and {chunk_labels} and {chunk_input_tokens} and {chunk_label_tokens}")

                    total_len += word_total
                    j += 1

                if not chunk_input_tokens:
                    i += 1
                    continue

                flat_input_ids = [id for group in chunk_input_tokens for id in group]
                flat_label_ids = [id for group in chunk_label_tokens for id in group]

                input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                labels = (
                    [ignore_index] * (len(prefix) + len(flat_input_ids) + len(suffix)) +
                    flat_label_ids +
                    [ignore_index]
                )

                pad_len = max_seq_len - len(input_ids)
                input_ids += [pad_id] * pad_len
                labels += [ignore_index] * pad_len

                # results.append((input_ids, labels))
                # ADD METADATA TO RESULT
                results.append({
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "word_positions": word_positions.copy(),
                    "input_ids": input_ids,
                    "labels": labels,
                })

                chunk_id += 1

                all_chunk_texts.append(" ".join(chunk_words))
                all_chunk_label_seqs.append(" ".join(chunk_labels))

                if j >= n or j <= prev_j:
                    break  # last chunk has already been included

                prev_j = j

                # Overlap step
                overlap = max(1, int(overlap_ratio * len(chunk_words)))
                i = j - overlap if j - overlap > i else j

            # === DEBUG PRINT ===
            # if not is_train and len(all_chunk_texts) > 2:
            #     log_lines = []
            #     log_lines.append(f"\n=== ORIGINAL INPUT ===")
            #     log_lines.append(f"Source: {' '.join(src_words)}")
            #     log_lines.append(f"Labels: {src_word_labels}")
            #     log_lines.append(f"Max seq len: {max_seq_len}")
            #     log_lines.append(f"=== AFTER WINDOWING ===")
            #     for ci, (ct, cl, (input_ids, label_ids)) in enumerate(zip(all_chunk_texts, all_chunk_label_seqs, results)):
            #         input_len = len(results[ci][0])
            #         log_lines.append(f"Chunk {ci + 1}:")
            #         log_lines.append(f"  Text   : {ct}")
            #         log_lines.append(f"  Labels : {cl}")
            #         log_lines.append(f"  Length : {input_len} tokens")
            #         log_lines.append(f"  Input IDs : {results[ci][0]}...")
            #         log_lines.append(f"  Label IDs : {results[ci][1]}...")
            #     print("\n".join(log_lines))
        return results


    @staticmethod
    def decode_text(tokens, tokenizer):
        return tokenizer.decode(tokens)
    
    @staticmethod
    def encode_text(text, tokenizer, add_special_tokens=True):
        """Static method for tokenization to avoid pickling errors."""
        return tokenizer.encode_plus(text, truncation=False, return_tensors=None, add_special_tokens=add_special_tokens)["input_ids"]

    # def _process_file_data(self, src_file, tgt_file):
    #     with open(src_file, mode='r', encoding='utf8') as sfile, open(tgt_file, mode='r', encoding='utf8') as tfile:
    #         if self.files_have_header:
    #             src_file_lines = sfile.readlines()[1:]
    #             tgt_file_lines = tfile.readlines()[1:]
    #         else:
    #             src_file_lines = sfile.readlines()
    #             tgt_file_lines = tfile.readlines()

    #     lang_code = list(set(tgt_file_lines))[0].strip()
    #     num_of_samples_to_use = int(len(src_file_lines) * self.sample_dataset_share)

    #     # Randomly select some share of data from the list
    #     src_file_lines = random.sample(src_file_lines, num_of_samples_to_use)
    #     tgt_file_lines = random.sample(tgt_file_lines, num_of_samples_to_use)
    #     self.log.info(f"Sampled {self.sample_dataset_share*100} percent of {src_file} dataset with {len(src_file_lines)} samples.")

    #     # num_workers = max(1, int(cpu_count() * 0.4))  # Use 40% of available CPU cores
    #     num_workers = max(1, self.num_workers)

    #     # Prepare multiprocessing arguments
    #     args_list = [
    #         (src_line, tgt_line, self.max_seq_length, 0.5, self.tokenizer.pad_token_id,
    #          LanguageIdentificationDataset._is_english_string, 
    #          LanguageIdentificationDataset._split_into_windows,
    #          functools.partial(LanguageIdentificationDataset.encode_text, tokenizer=self.tokenizer))  # Pass method reference
    #         for src_line, tgt_line in zip(src_file_lines, tgt_file_lines)
    #     ]

    #     gen_llm_args_list = [
    #         (self.prompt_template, src_line, tgt_line, self.max_seq_length, 0.5, self.tokenizer.pad_token_id, self.tokenizer,
    #          LanguageIdentificationDataset._is_english_string, 
    #          LanguageIdentificationDataset._split_into_windows_for_gen_llm,
    #          functools.partial(LanguageIdentificationDataset.encode_text, tokenizer=self.tokenizer))  # Pass method reference
    #         for src_line, tgt_line in zip(src_file_lines, tgt_file_lines)
    #     ]

    #     # Use multiprocessing with safer settings
    #     if self.is_gen_llm:
    #         with Pool(processes=num_workers) as pool:
    #             results = pool.map(LanguageIdentificationDataset.process_line_gen_llm, gen_llm_args_list)
    #     else:
    #         with Pool(processes=num_workers) as pool:
    #             results = pool.map(LanguageIdentificationDataset.process_line, args_list)
    #     # results = []
    #     # with ThreadPoolExecutor(max_workers=num_workers) as executor:
    #     #     futures = [executor.submit(LanguageIdentificationDataset.process_line, args) for args in args_list]
    #     #     for future in as_completed(futures):
    #     #         result = future.result()
    #     #         results.append(result)


    #     # Flatten results and remove None values
    #     processed_pairs = [pair for sublist in results if sublist for pair in sublist]

    #     # Separate into source and target lists
    #     new_src_file_lines, new_tgt_file_lines = zip(*processed_pairs) if processed_pairs else ([], [])

    #     return lang_code, list(new_src_file_lines), list(new_tgt_file_lines)

    def _process_file_data(self, src_file, tgt_file):
        # Load source and target lines
        data = []
        src_data = []
        tgt_data = []
        with open(src_file, 'r', encoding='utf8') as sfile, open(tgt_file, 'r', encoding='utf8') as tfile:
            src_lines = sfile.readlines()[1:] if self.files_have_header else sfile.readlines()
            tgt_lines = tfile.readlines()[1:] if self.files_have_header else tfile.readlines()

        # Ensure aligned sampling
        # combined = list(zip(src_lines, tgt_lines))
        # num_samples = int(len(combined) * self.sample_dataset_share)
        # sampled = random.sample(combined, num_samples)
        # src_lines, tgt_lines = zip(*sampled)
        # src_lines, tgt_lines = list(src_lines), list(tgt_lines)
        num_samples = int(len(src_lines) * self.sample_dataset_share)
        # indices = random.sample(range(len(src_lines)), num_samples)
        indices = np.random.choice(len(src_lines), num_samples, replace=False)
        src_lines = [src_lines[i] for i in indices]
        tgt_lines = [tgt_lines[i] for i in indices]

        # Extract representative language code for logging
        lang_code = list(set(t.strip() for t in tgt_lines))[0]
        self.log.info(f"Sampled {self.sample_dataset_share * 100:.1f} percent of {src_file} dataset: {num_samples} lines.")

        # Build batches
        # batch_size = 1000
        # Helper: batch iterator using islice
        def batch_iter(seq, batch_size):
            it = iter(seq)
            while True:
                batch = list(islice(it, batch_size))
                if not batch:
                    break
                yield batch

        batch_size = 100_000
        if self.is_gen_llm:
            # batches = [
            #     (self.prompt_template, src_lines[i:i + batch_size], tgt_lines[i:i + batch_size],
            #     self.max_seq_length, 0.5, self.is_train)
            #     for i in range(0, len(src_lines), batch_size)
            # ]
            batches = [
                    (self.prompt_template, src_batch, tgt_batch,
                    self.max_seq_length, 0.5, self.is_train)
                    for src_batch, tgt_batch in zip(batch_iter(src_lines, batch_size),
                                                    batch_iter(tgt_lines, batch_size))
                ]
            with Pool(self.num_workers) as pool:
                all_results = pool.map(LanguageIdentificationDataset.process_batch_gen_llm, batches)

            flat = [x for batch in all_results for x in batch]
            if flat:
                data = flat
                # src_data, tgt_data = zip(*flat)
                # self.src_data.extend(src_out)
                # self.tgt_data.extend(tgt_out)
        else:
            class_id_fn = functools.partial(self._get_class_id_from_lang_code)
            # batches = [
            #     (src_lines[i:i + batch_size], tgt_lines[i:i + batch_size],
            #     self.max_seq_length, 0.5)
            #     for i in range(0, len(src_lines), batch_size)
            # ]
            batches = [
                    (src_batch, tgt_batch, self.max_seq_length, 0.5)
                    for src_batch, tgt_batch in zip(batch_iter(src_lines, batch_size),
                                                    batch_iter(tgt_lines, batch_size))
                ]
            with Pool(self.num_workers) as pool:
                all_results = pool.map(LanguageIdentificationDataset.process_batch_classifier, batches)
            flat = [x for batch in all_results for x in batch]
            if flat:
                # src_data, tgt_data = zip(*flat)
                data = flat
                # self.src_data.extend(src_out)
                # self.tgt_data.extend(tgt_out)

        # return lang_code, src_data, tgt_data
        return lang_code, data


    def _validate_and_load_file_data(self):
        """
        validates, loads and processes data
        :return: None
        """
        # filename_match_threshold = 0.99
        src_files_list = []
        tgt_files_list = []

        for lang_dir in os.listdir(self.data_dir):
            self.log.info(f"Now processing {os.path.join(self.data_dir, lang_dir)} directory.")
            src_data_dir = os.path.join(self.data_dir, lang_dir, 'src')
            tgt_data_dir = os.path.join(self.data_dir, lang_dir, 'tgt')
            for src_file in os.listdir(src_data_dir):
                matched = False
                for tgt_file in os.listdir(tgt_data_dir):
                    # sim_score = self._similar_name(src_file, tgt_file)
                    # if sim_score >= filename_match_threshold:
                    if src_file.split(".")[0] == tgt_file.split(".")[0]:
                        src_files_list.append(src_file)
                        tgt_files_list.append(tgt_file)
                        matched = True
                        break
                if matched:
                    continue  # continue to next loop
                else:
                    self.log.info(f"Skipping file {src_file} since matching label file not found in {tgt_data_dir}.")
            # Validate files and content
            src_filtered_files = [os.path.join(src_data_dir, file) for file in src_files_list if
                                  os.path.isfile(os.path.join(src_data_dir, file))]
            tgt_filtered_files = [os.path.join(tgt_data_dir, file) for file in tgt_files_list if
                                  os.path.isfile(os.path.join(tgt_data_dir, file))]
            if len(src_filtered_files) != len(tgt_filtered_files):
                msg_err_num_files = f"Number of files in {src_data_dir} is {len(src_filtered_files)} does not match" \
                                    f"with {len(tgt_filtered_files)} files present in {tgt_data_dir}"
                raise ValueError(msg_err_num_files)
            else:
                for src_file, tgt_file in zip(src_filtered_files, tgt_filtered_files):
                    new_src_file_lines = []
                    new_tgt_file_lines = []
                    src_num_lines = sum(1 for _ in open(src_file))
                    tgt_num_lines = sum(1 for _ in open(tgt_file))
                    src_num_lines = src_num_lines - 1 if self.files_have_header else src_num_lines
                    tgt_num_lines = tgt_num_lines - 1 if self.files_have_header else tgt_num_lines
                    if src_num_lines != tgt_num_lines:
                        self.log.info(f"{src_num_lines} lines in {src_file} "
                                      f"do not match with {tgt_num_lines} in {tgt_file}, skipping processing these files")
                    else:
                        self.log.info(f"Processing {src_file} and {tgt_file} with {tgt_num_lines} samples.")
                        # lang_code, new_src_file_lines , new_tgt_file_lines = self._process_file_data(src_file, tgt_file)
                        lang_code, new_tgt_file_lines = self._process_file_data(src_file, tgt_file)
                        if self.use_disk_store:
                            # Write shard
                            shard_path = os.path.join(
                                self.disk_store_dir,
                                f"rank_{self.rank}_shard_{getattr(self, '_shard_counter', 0)}.parquet"
                            )
                            self.shard_paths.append(shard_path)
                            schema = pa.schema([
                                ("lang_code", pa.string()),
                                ("sample_id", pa.int64()),
                                ("chunk_id", pa.int64()),
                                ("word_positions", pa.list_(pa.int64())),
                                ("input_ids", pa.list_(pa.int64())),
                                ("labels", pa.list_(pa.string())),  # force to string
                            ])
                            for row in new_tgt_file_lines:
                                if "labels" in row:
                                    row["labels"] = [str(x) if x is not None else "" for x in row["labels"]]

                            table = pa.Table.from_pylist(new_tgt_file_lines, schema=schema)
                            pq.write_table(table, shard_path, compression="snappy")

                            # Increment counter
                            self._shard_counter = getattr(self, "_shard_counter", 0) + 1

                            # Refresh shard file list and sizes
                            self._shard_files = sorted(glob.glob(f"{self.disk_store_dir}/rank_{self.rank}_shard_*.parquet"))
                            self._shard_sizes = [pq.read_metadata(f).num_rows for f in self._shard_files]

                        else:
                            self.data.extend(new_tgt_file_lines)
                        
                        # num_of_samples_to_use = int(len(new_src_file_lines) * self.sample_dataset_share)

                        # # Randomly select some share of data from the list
                        # new_src_file_lines = random.sample(new_src_file_lines, num_of_samples_to_use)
                        # new_tgt_file_lines = random.sample(new_tgt_file_lines, num_of_samples_to_use)
                        # self.log.info(f"Sampled {self.sample_dataset_share*100} percent of this dataset")

                        # any further preprocessing here and then append
                        # self.src_data.extend(new_src_file_lines)
                        # self.tgt_data.extend(new_tgt_file_lines)
                        
                        
                        if self.is_train:
                            if lang_code not in self.file_stats:
                                self.file_stats.update({lang_code : [{"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)}]})
                            else:
                                self.file_stats[lang_code].append({"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(new_tgt_file_lines)})
                        self.log.info(f"Files {src_file} and {tgt_file} have {len(new_tgt_file_lines)} samples after processing.")
