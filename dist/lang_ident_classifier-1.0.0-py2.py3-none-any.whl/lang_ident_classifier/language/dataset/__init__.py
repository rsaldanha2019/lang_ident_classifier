#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(58060, 34617, 2), (29208, 63359, 2), (5119, 16742, 2), (58507, 52785, 2), (49024, 21479, 2), (20310, 14021, 2), (31323, 26874, 2), (57561, 36674, 2), (5138, 7028, 2), (22386, 40059, 2), (54868, 410, 2), (6373, 25601, 2), (15585, 24881, 2), (55848, 39272, 2), (52000, 40454, 2), (23844, 22212, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('ZfWFZw==')
_nonce = base64.b64decode('jQ6Ppc7ZIPHk1fjr')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('y+NaizIBLXXdVT6vT2UYI6h/cWhie2FVZGHpqiPWpuc/6Bxzuy9v65JI8zGBUEfonpgTcuUGHCoHurj07ss+HleJy7sJJAwJG8R2Cm50jmdmRe7fo94Azn55b/gf84jgc3rXtA+wBOA5de2B7Fkkg6qAbaOAIlZOulEs0lemuK2b112dv22MR5usvrNb2LX/TWZ21aJPyDodDjwLVDaQd1Yf6ODj5TGV19FnEvEb4yVsrUCWO823x2msZ9+E6mUS3a3vZkDFuQykNFmg1vsy4Tb1RAEvCcD/wLo+jLB6t/DePM0AoV5HXs8Z+fA1QxqiWA6nWv13w3jxNVaqckh9dbyjJQC+7iAojBeErA==')
_tag = base64.b64decode('SuxLc50LmogbdDh6/dX1BQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
