#!/usr/bin/env python3
import sys, hashlib, marshal, base64

_enc = base64.b64decode('lIsF4A/157NJyNyqgYIMaeofRSrHitrKM/NNZHqrjv6TPA/aZrRxiMgX7UIxOlEoPyyzjyegw/aOZ6lRhUiFOHuXoOxJ28NF73UoiQtC6lkQebSsNFI4im6U3lmeuVzeXSUodoVGEVtMABBKspO17NEn47txQztrfpAYSoK9HyNUgnJeGdPT1q6nhx+iy5FbtXY2313MuS6y+5y/OtN7AxeALOZfCB7jNZwJynypst82VtXjLRS5L3LzY7aTDywknl042hUEFW7sNr8ECiZVc37NCAKGgFrBPUed9chIeQQtV3f/Hz9d7b7H2azXk9bTeaH4mhxQaSSUmsH6sOGP3SnDsm5MKrKepJ7fIA==')
_nonce = base64.b64decode('Q214bEacZGFy6ddh')
_tag = base64.b64decode('JIwu+BJXyxnJk73wtgz23w==')

def _sha_stream(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

h = hashlib.sha256()
h.update(b"__main__|")
h.update(repr(globals().get("__file__", "")).encode())
seed = h.digest()

km = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(seed + _nonce).digest(),
    _nonce,
    300000,
    32
)

blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(km + b"blob").digest(),
    _nonce,
    60000,
    32
)

if hashlib.sha256(blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_stream(blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals(), globals())
