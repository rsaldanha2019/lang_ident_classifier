#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(45252, 43363, 2), (17400, 2922, 2), (37329, 13714, 2), (13896, 3926, 2), (49583, 24111, 2), (44490, 1102, 2), (33882, 26834, 2), (55028, 22186, 2), (10229, 25101, 2), (53926, 39412, 2), (36615, 64024, 2), (47745, 23817, 2), (11457, 28511, 2), (27109, 61757, 2), (36908, 11572, 2), (38624, 33351, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('GadIkg==')
_nonce = base64.b64decode('v5+xE2SQXr5x2GEO')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('utJ+WBKlaig36xgbF06C0gGr5oTfLSilbhsVSlErFL0KvLUX4O9WdWcil7cjzgmk5S1uJ8nfgF4ishVu/fwiuMv0VLLTxyi84h+QC+3tFK6I2DTDHXYsKN+6g7bpDa9IUe35xOOVvguLoufErX7mipYUZu1eRUKHVft8HLRTQ3r36M8N5Y4aO8C68kBfxtprN+VNp5aJIfMvPMMaaqvQAIAALMTKFId18q5+ZsqvywkyrhxCW/Z10sIKUQSIoAj5YW7veEQ/ZUpotzIuDnJUs7rIVdV+f8uG8b26/xDJiLEevs33PJ/re+7VwxjurhI1wO/4JrAQTAFgtnWIv7xKk3xq6717o1URTd/wgg==')
_tag = base64.b64decode('DTgEbedLOK9KKQIV1IQamA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
