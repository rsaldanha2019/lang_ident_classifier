
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(48147, 55410, 2), (2069, 15353, 2), (21276, 61073, 2), (20292, 21474, 2), (64288, 2497, 2), (49491, 38499, 2), (8484, 33054, 2), (30432, 43840, 2), (46583, 27924, 2), (38853, 14138, 2), (29955, 18062, 2), (30067, 56283, 2), (6864, 35200, 2), (19211, 27954, 2), (16705, 60446, 2), (9112, 33383, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('ZGEz7A==')
_nonce = base64.b64decode('hVaEsCinFtEnrxLE')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('VoF0HTZ3ulo6JwH5E7lcJicWoS+XRP/L64wM1p6yRTFFG4fuGb3pGAh6sCQ5YEEiYQcinNDDvo7eWkl+krxdrGYtNBsb3xa/75vLFWLTiI2ed86rVupzqUYmXVIzy99UuidwQbyZaIs9ks4fQCb0/Hya6z5HcK/xCvY7n3ISpsMK+zRCA49DULMjLkN3Iw/eMpQvKFPO+hshxOT7MyXdymx3VllZ/O58noUWFUmyCI3F3woqKRbPEnZxm3ACUw9/QfXl903712HbRBlNnOVOIbtMT54iNL9+Gs0hgJznzgPrpk+fDGUE+uqsUjE92AWoTde0x3BqnavqfTOJSsjB7lEUngtlb6VdCMCtAA==')
_tag = base64.b64decode('GFryORgQpmiMsf7D1R0IBQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
