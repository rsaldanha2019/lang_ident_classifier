# -------- grouped_by_sample_distributed_sampler.py --------
import math
import torch
from torch.utils.data import Sampler

class CustomGroupBySampleDistributedSampler(Sampler[int]):
    """
    DDP/FSDP-safe sampler that assigns all chunks of the same sample_id
    to the same rank. Ensures no sample_id is split across ranks.
    """
    def __init__(self, dataset, num_replicas=None, rank=None,
                 shuffle: bool = False, seed: int = 0, drop_last: bool = False):
        if num_replicas is None:
            if not torch.distributed.is_available() or not torch.distributed.is_initialized():
                raise RuntimeError("Distributed not initialized.")
            num_replicas = torch.distributed.get_world_size()
        if rank is None:
            if not torch.distributed.is_available() or not torch.distributed.is_initialized():
                raise RuntimeError("Distributed not initialized.")
            rank = torch.distributed.get_rank()

        self.dataset = dataset
        self.num_replicas = num_replicas
        self.rank = rank
        self.shuffle = shuffle
        self.seed = seed
        torch.manual_seed(seed)
        self.drop_last = drop_last
        self.epoch = 0

        # --- group dataset indices by sample_id ---
        self.sample_to_idxs = {}
        for idx in range(len(dataset)):
            sid = int(dataset[idx]["sample_id"])
            self.sample_to_idxs.setdefault(sid, []).append(idx)

        # stable order inside each sample group
        for sid, idxs in self.sample_to_idxs.items():
            try:
                idxs.sort(key=lambda k: dataset[k]["chunk_id"])
            except Exception:
                idxs.sort()

        self.sample_ids = sorted(self.sample_to_idxs.keys())
        self.num_samples_total = len(self.sample_ids)

        # total dataset size in indices
        self.total_size = len(dataset)

        # Lightning expects these
        if self.drop_last:
            self.num_samples = self.total_size // self.num_replicas
        else:
            self.num_samples = int(math.ceil(self.total_size / self.num_replicas))

    def __iter__(self):
        # shuffle sample groups
        g = torch.Generator()
        g.manual_seed(self.seed + self.epoch)
        sids = list(self.sample_ids)
        if self.shuffle:
            perm = torch.randperm(len(sids), generator=g).tolist()
            sids = [sids[i] for i in perm]

        # partition sids to replicas
        partitions = [[] for _ in range(self.num_replicas)]
        for i, sid in enumerate(sids):
            partitions[i % self.num_replicas].append(sid)

        my_sids = partitions[self.rank]

        # expand sample_ids → indices
        indices = []
        for sid in my_sids:
            indices.extend(self.sample_to_idxs[sid])

        # --- balance across ranks ---
        # pad or trim so every rank yields exactly num_samples
        if len(indices) < self.num_samples:
            # repeat from start
            indices.extend(indices[: (self.num_samples - len(indices))])
        elif len(indices) > self.num_samples:
            indices = indices[: self.num_samples]

        return iter(indices)

    def __len__(self):
        return self.num_samples

    def set_epoch(self, epoch: int):
        self.epoch = epoch
