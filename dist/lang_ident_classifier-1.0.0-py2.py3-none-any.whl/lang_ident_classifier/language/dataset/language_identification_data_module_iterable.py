# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_data_module
# @Time             : 19/12/23 12:11 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import math
import os
import random
from typing import Any
import lightning as pl
import numpy as np
from lightning.pytorch.utilities.data import DataLoader
from lightning.pytorch.utilities.types import TRAIN_DATALOADERS, EVAL_DATALOADERS
import torch
import torch.utils
import torch.utils.data
import torch.utils.data.distributed
from torch.utils.data import Dataset, IterableDataset
from torch.nn.utils.rnn import pad_sequence
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset

class LanguageIdentificationDataModule(pl.LightningDataModule):
    """
    contains methods for dataloader operations for
    the lightning data module
    """
    def __init__(self,
                 train_dataset: LanguageIdentificationDataset = None,
                 val_dataset: LanguageIdentificationDataset = None,
                 test_dataset: LanguageIdentificationDataset = None,
                 predict_dataset: LanguageIdentificationDataset = None,
                 batch_size: int = 8,
                 num_workers: int = 2,
                 train_data_shuffle: bool = True,
                 tokenizer: Any = None,
                 random_seed: int = 20):
        super(LanguageIdentificationDataModule, self).__init__()
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        np.random.seed(random_seed)
        self.random_seed = random_seed
        self.tokenizer = tokenizer
        self.train_dataset = train_dataset
        self.val_dataset = val_dataset
        self.test_dataset = test_dataset
        self.predict_dataset = predict_dataset
        self.batch_size = batch_size
        # self.num_workers = math.ceil(os.cpu_count()*0.4) # uses 40% of cpus available
        self.num_workers = num_workers
        self.train_data_shuffle = train_data_shuffle
        self.gen = torch.Generator()
        self.gen.manual_seed(random_seed)
    
    def worker_init_fn(self, worker_id):
        # np.random.seed(self.random_seed + worker_id)  # Use the global seed for initialization
        worker_seed = self.random_seed + worker_id
        np.random.seed(worker_seed)
        random.seed(worker_seed)
    
    def train_dataloader(self) -> TRAIN_DATALOADERS:
        """
        using the class instance params, creates a
        train dataloader instance
        :return: train dataloader instance
        """
        if self.train_dataset is not None:
            return DataLoader(self.train_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.train_dataset._shard_counter if self.train_dataset._shard_counter != 0 and self.train_dataset._shard_counter <= self.num_workers else self.num_workers,
                              persistent_workers=True if self.num_workers > 0 else False,
                              shuffle=self.train_data_shuffle,
                              worker_init_fn=self.worker_init_fn,
                            #   collate_fn=self.collate_fn,
                              generator=self.gen,
                              prefetch_factor=self.num_workers * 2 if self.num_workers < 2 else self.num_workers,
                              pin_memory=True)

    def val_dataloader(self) -> EVAL_DATALOADERS:
        """
        using the class instance params, creates a
        validation dataloader instance
        :return: val dataloader instance
        """
        if self.val_dataset is not None:
            return DataLoader(self.val_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.val_dataset._shard_counter if self.val_dataset._shard_counter != 0 and self.val_dataset._shard_counter <= self.num_workers else self.num_workers,
                              persistent_workers=True if self.num_workers > 0 else False,
                              shuffle=False,
                              worker_init_fn=self.worker_init_fn,
                            #   collate_fn=self.collate_fn,
                              generator=self.gen,
                              prefetch_factor=self.num_workers * 2 if self.num_workers < 2 else self.num_workers,
                              pin_memory=True)

    def test_dataloader(self) -> EVAL_DATALOADERS:
        """
        Creates a test DataLoader that handles both single-device and multi-device setups dynamically.
        """
        is_single_device = torch.cuda.device_count() <= 1 or not torch.distributed.is_initialized()
        
        sampler = None
        if not is_single_device and isinstance(self.test_dataset, Dataset) and not isinstance(self.test_dataset, IterableDataset):
            sampler = torch.utils.data.distributed.DistributedSampler(
                self.test_dataset,
                shuffle=False,  # No shuffling for testing
                seed=self.random_seed
            )
        
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            num_workers=self.test_dataset._shard_counter if self.test_dataset._shard_counter != 0 and self.test_dataset._shard_counter <= self.num_workers else self.num_workers,
            persistent_workers=True if self.num_workers > 0 else False, # prevent None check in distributed setup
            shuffle=False,  # Shuffle only in single-device setup
            sampler=sampler,
            # collate_fn=self.collate_fn,
            worker_init_fn=self.worker_init_fn,
            generator=self.gen,
            prefetch_factor=self.num_workers * 2 if self.num_workers < 2 else self.num_workers,
            pin_memory=True)


    def predict_dataloader(self) -> EVAL_DATALOADERS:
        """
        using the class instance params, creates a
        predict dataloader instance
        :return: predict data loader instance
        """
        if self.predict_dataset is not None:
            return DataLoader(self.predict_dataset,
                              batch_size=self.batch_size,
                              num_workers=self.num_workers,
                              persistent_workers=True if self.num_workers > 0 else False,
                              shuffle=False,
                              worker_init_fn=self.worker_init_fn,
                            #   collate_fn=self.collate_fn,
                              generator=self.gen)

    # def collate_fn(self, batch):
    #     lang_codes = [item["lang_code"] for item in batch]
    #     input_ids = [item["input_ids"] for item in batch]
    #     labels = [item["labels"] for item in batch]
    #     sample_ids = [item["sample_id"] for item in batch]
    #     chunk_ids = [item["chunk_id"] for item in batch]
    #     word_positions = [item["word_positions"] for item in batch]

    #     return {
    #         "lang_codes": lang_codes,
    #         "input_ids": torch.stack(input_ids),
    #         "labels": torch.stack(labels),
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #     }

    # def collate_fn(self, batch):
    #     # Extract sequences
    #     input_ids = [item["input_ids"] for item in batch]
    #     labels = [item["labels"] for item in batch]
    #     sample_ids = [item["sample_id"] for item in batch]
    #     chunk_ids = [item["chunk_id"] for item in batch]
    #     word_positions = [item["word_positions"] for item in batch]

    #     # Pad at batch level
    #     pad_token_id = self.tokenizer.pad_token_id
    #     ignore_index = self.ignore_index

    #     input_ids_padded = pad_sequence(
    #         input_ids,
    #         batch_first=True,
    #         padding_value=pad_token_id
    #     )
    #     labels_padded = pad_sequence(
    #         labels,
    #         batch_first=True,
    #         padding_value=ignore_index
    #     )

    #     return {
    #         "input_ids": input_ids_padded,
    #         "labels": labels_padded,
    #         "sample_ids": sample_ids,
    #         "chunk_ids": chunk_ids,
    #         "word_positions": word_positions,
    #     }

