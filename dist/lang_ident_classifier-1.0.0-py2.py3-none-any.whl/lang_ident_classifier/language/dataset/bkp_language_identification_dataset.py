# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _08982d39d52c
import _6238125fe950
import _93cc85e58892
import _39b6ee242af6
from _4f4e7444ad78 import _579dc3896898, _ae8f912773d4
from _7c243ce90380 import _6beab8f2e9bd, _399d36454d08
from _1f903c7878c6 import _a5335fec3130
from _a183b9847250._61abbaa5144f import _8f1d5cdfc4d1
from _82c20f683505 import _01c44ee147a5, _309472d5359b, _0d40690f18b2

import _469bdfb38c00 as _5af885616f2d
import _4bf21352bef5
from _4bf21352bef5._ade7b0b04a64._8be811368b73 import _882d6bb4801d
from _05f400d939b3 import _2de420cd977c


class _f13447fbd48f(_882d6bb4801d):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _c8476d7b0f47 = _af6fe6a286b4  # class-level tokenizer (set on __init__)
    _b6aba09456f0 = _525d92b374a6

    def _3e399f62c27a(
        self,
        _29279732db2c: _16e270684126,
        _3c285d31d86b: _8d1793de00c0,
        _b8071fdb723e: _01c44ee147a5,
        _9d1de7bf579c: _b802846acae0,
        _539323246214: _16e270684126,
        _1e91b7ca883d: _2de420cd977c,
        _458feaf42d49: _8d1793de00c0,
        _ba201adcc512: _8d1793de00c0,
        _ade430624e0d: _869f11c1595e = 1.0,
        _01b0c54dfcc5: _b802846acae0 = 2,
        _bf8a9d4d73f1: _b802846acae0 = 20,
        _33fd50a053d8: _8d1793de00c0 = _525d92b374a6,
        _a5cf6bdf14cf: _16e270684126 = _af6fe6a286b4,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _932d1b71256c()._e760123c2785()

        # Deterministic behavior
        _4bf21352bef5._09d3a95fb8f3(_bf8a9d4d73f1)
        if _4bf21352bef5._c719c9fb6bc8._cc1ae173afc9():
            _4bf21352bef5._c719c9fb6bc8._e97819a7d9fa(_bf8a9d4d73f1)
        _93cc85e58892._dc5c4f1ecc89(_bf8a9d4d73f1)
        _5af885616f2d._93cc85e58892._dc5c4f1ecc89(_bf8a9d4d73f1)

        # Basic parameters & bookkeeping
        self._1e91b7ca883d = _1e91b7ca883d
        self._458feaf42d49 = _458feaf42d49
        self._ba201adcc512 = _ba201adcc512
        self._33fd50a053d8 = _33fd50a053d8
        self._a5cf6bdf14cf = _a5cf6bdf14cf
        self._3c285d31d86b = _3c285d31d86b
        self._29279732db2c = _29279732db2c
        self._9d1de7bf579c = _9d1de7bf579c
        self._f4637f3301f6 = 0
        self._ade430624e0d = _ade430624e0d
        self._01b0c54dfcc5 = _01b0c54dfcc5
        self._35d8c64c88de = -100

        # Tokenizer handling
        _5692efae393e._c8476d7b0f47 = _b8071fdb723e
        self._472c6bbe1889 = _b8071fdb723e
        if self._33fd50a053d8:
            # preserve earlier code's fallback pad id (kept intentionally)
            if not self._472c6bbe1889._db637296b0f4:
                self._472c6bbe1889._db637296b0f4 = 128004

        # storage filled by _validate_and_load_file_data
        self._b1afedbf35b7: _309472d5359b[_eb3ced3bebcb] = []
        self._e8489253d5c2 = {}

        # Load and process files; then derive classes/weights
        self._6124e960b148()
        self._fcb05a6e5efa, self._bd2852ba1913 = self._961bf79b5786(_539323246214, _458feaf42d49)

    def _c95dd89d219e(self) -> _b802846acae0:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _eab3df06a926(self._b1afedbf35b7)

    def _87fc82462751(self, _22c308d9f333: _b802846acae0) -> _eb3ced3bebcb:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _ab2a82fe8fdb = self._b1afedbf35b7[_22c308d9f333]
        _3934cea42506 = _ab2a82fe8fdb._2b3b4e9c854e("lang_code", "unk")
        _512c9c4af8b3 = _ab2a82fe8fdb["input_ids"]
        _186617818be7 = _ab2a82fe8fdb["labels"]
        _f1baeeca1100 = _ab2a82fe8fdb._2b3b4e9c854e("word_positions", [])
        _05155e186eb5 = _ab2a82fe8fdb["num_chunks"]
        _39c6ba9cfab6 = _ab2a82fe8fdb._2b3b4e9c854e("sample_id", _22c308d9f333)
        _ea54f9a57d1d = _ab2a82fe8fdb._2b3b4e9c854e("chunk_id", 0)
        _bbbcf3439a84 = _ab2a82fe8fdb._2b3b4e9c854e("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _186617818be7 = [
            self._35d8c64c88de
            if _25cbf98459f5 is _af6fe6a286b4
            else _b802846acae0(_25cbf98459f5) if _9d2fdb7fab9e(_25cbf98459f5, _16e270684126) and _25cbf98459f5._696ed627443d("-")._da0cb8929ad7()
            else _25cbf98459f5
            for _25cbf98459f5 in _186617818be7
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._33fd50a053d8:
            _93ddaa3e03a6 = [
                self._211380715da1(_25cbf98459f5) if _9d2fdb7fab9e(_25cbf98459f5, _16e270684126) else _25cbf98459f5
                for _25cbf98459f5 in _186617818be7
            ]
            _ba5c61ffd2fd = _eab3df06a926(_93ddaa3e03a6)
            _0b99c5f0b573 = _156589dbff91(0, self._9d1de7bf579c - _ba5c61ffd2fd)
            _93ddaa3e03a6 = _93ddaa3e03a6 + [self._35d8c64c88de] * _0b99c5f0b573
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _93ddaa3e03a6 = _186617818be7

        return {
            "lang_code": _3934cea42506,
            "input_ids": _4bf21352bef5._bdea3fb70bce(_512c9c4af8b3, _ba014330b356=_4bf21352bef5._4da99a447fb3),
            "labels": _4bf21352bef5._bdea3fb70bce(_93ddaa3e03a6, _ba014330b356=_4bf21352bef5._4da99a447fb3),
            "sample_id": _39c6ba9cfab6,
            "chunk_id": _ea54f9a57d1d,
            "word_positions": _f1baeeca1100,
            "prompt_len": _bbbcf3439a84,
            "num_chunks": _05155e186eb5,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _67166020646b(self, _3934cea42506: _16e270684126) -> _b802846acae0:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _87f29fed94c8, _10cff839f1b6 in self._fcb05a6e5efa._1b2a2cea7b9d():
            if _10cff839f1b6["lang_code"] == _16e270684126(_3934cea42506)._1a6ea35a0cc5():
                return _87f29fed94c8
        return self._fcb05a6e5efa._2b3b4e9c854e("unk", {})._2b3b4e9c854e("id", -1)

    def _91db7886c148(self, _78538570f086: _b802846acae0) -> _16e270684126:
        """Reverse mapping; assumes class_id present."""
        return self._fcb05a6e5efa[_78538570f086]["lang_code"]

    def _c0f41f59963a(self) -> _b802846acae0:
        return _eab3df06a926(self._fcb05a6e5efa)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _be4eb507072a(self, _bc2bb05c7fb0: _eb3ced3bebcb) -> _eb3ced3bebcb:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _6cb1e356e7a0 = _39b6ee242af6._13b338f6583d(r"[^\d\s]+")  # tokens with non-digit characters
        _a077722ead9c = _6beab8f2e9bd()

        if self._33fd50a053d8:
            _b7ddb1404a44 = []
            for _6699114e3465 in self._b1afedbf35b7:
                _dd2898df961b = _6699114e3465._2b3b4e9c854e("labels", []) if _9d2fdb7fab9e(_6699114e3465, _eb3ced3bebcb) else (_6699114e3465[1] if _9d2fdb7fab9e(_6699114e3465, _ba3ef3beba1d) and _eab3df06a926(_6699114e3465) > 1 else [])
                _2c7e6a371a61 = [_ae9adf9c5295 for _ae9adf9c5295 in _dd2898df961b if _ae9adf9c5295 != self._35d8c64c88de]
                if _2c7e6a371a61:
                    _b7ddb1404a44._070912edbe13(_2c7e6a371a61)
            if _b7ddb1404a44:
                _17b4e394f904 = self._472c6bbe1889._9c775d4ddb94(_b7ddb1404a44, _cddb7f134156=_b056e3454aed)
                for _dd9f12ef92ea in _17b4e394f904:
                    _de645fa97a3c = _6cb1e356e7a0._942eec456d5f(_dd9f12ef92ea)
                    _a077722ead9c._cf2548bc7d45(_de645fa97a3c)
        else:
            for _6699114e3465 in self._b1afedbf35b7:
                _dd2898df961b = _6699114e3465._2b3b4e9c854e("labels", [])
                _de645fa97a3c = [_4178f2e40648._1a6ea35a0cc5() for _4178f2e40648 in _dd2898df961b if _9d2fdb7fab9e(_4178f2e40648, _16e270684126) and _6cb1e356e7a0._461e523b8072(_4178f2e40648)]
                _a077722ead9c._cf2548bc7d45(_de645fa97a3c)

        _70c065994556 = {_cf26dde40d3b["lang_code"]: _95c1e049a679 for _95c1e049a679, _cf26dde40d3b in _bc2bb05c7fb0._1b2a2cea7b9d()}

        for _491385fb56f7, _2dad283df3cf in _a077722ead9c._1b2a2cea7b9d():
            _491385fb56f7 = _491385fb56f7._1a6ea35a0cc5()
            _582e10edd8ee = self._e8489253d5c2._2b3b4e9c854e(_491385fb56f7, [])
            _911a876bdc8e = _8cf98ff4520e(_e36060b6cfb0._2b3b4e9c854e("samples_after_processing", 0) for _e36060b6cfb0 in _582e10edd8ee)
            if _491385fb56f7 in _70c065994556:
                _22c308d9f333 = _70c065994556[_491385fb56f7]
                _9717737cc7ab = _bc2bb05c7fb0[_22c308d9f333]
                _33badff5ee64 = _9717737cc7ab["lang_files"] + _582e10edd8ee
                _0e41a06df6ca = _8a9e66c67e25({_e36060b6cfb0["file_name"]: _e36060b6cfb0 for _e36060b6cfb0 in _33badff5ee64}._3e625e5a7081())
                _bc2bb05c7fb0[_22c308d9f333] = {
                    "lang_code": _491385fb56f7,
                    "lang_samples": _9717737cc7ab["lang_samples"] + _911a876bdc8e,
                    "lang_files": _0e41a06df6ca,
                }
            else:
                _36c68b2ffea9 = _eab3df06a926(_bc2bb05c7fb0)
                _bc2bb05c7fb0[_36c68b2ffea9] = {
                    "lang_code": _491385fb56f7,
                    "lang_samples": _911a876bdc8e,
                    "lang_files": _582e10edd8ee,
                }
                _70c065994556[_491385fb56f7] = _36c68b2ffea9

        return _bc2bb05c7fb0

    def _3a12e8c10972(self, _dc0fbdc8ffd3: _309472d5359b[_869f11c1595e]) -> _5af885616f2d._6413be99388e:
        _6fef93cf7ef0 = _5af885616f2d._8cf98ff4520e(_dc0fbdc8ffd3)
        return _dc0fbdc8ffd3 / _6fef93cf7ef0 if _6fef93cf7ef0 != 0 else _5af885616f2d._07979ad611bd(_dc0fbdc8ffd3)

    def _4ec9b0f56815(self, _2f786d66a006: _eb3ced3bebcb) -> _0d40690f18b2[_309472d5359b[_869f11c1595e], _eb3ced3bebcb]:
        _911a876bdc8e = _8cf98ff4520e(_6699114e3465["lang_samples"] for _6699114e3465 in _2f786d66a006._3e625e5a7081())
        for _3934cea42506, _811f4a3f2151 in _2f786d66a006._1b2a2cea7b9d():
            _c05528537e43 = _811f4a3f2151["lang_samples"]
            if _c05528537e43 > 0:
                _69e6d2c84492 = _911a876bdc8e / (_c05528537e43 * _eab3df06a926(_2f786d66a006))
            else:
                _69e6d2c84492 = 0.0
            _2f786d66a006[_3934cea42506]["lang_weight"] = _69e6d2c84492
        _bd2852ba1913 = [_6699114e3465["lang_weight"] for _6699114e3465 in _2f786d66a006._3e625e5a7081()]
        # Update stored lang weights (keeps original behavior)
        for _9698f5f71017, (_3934cea42506, _811f4a3f2151) in _2de0e22ce5e9(_2f786d66a006._1b2a2cea7b9d()):
            _811f4a3f2151["lang_weight"] = _bd2852ba1913[_9698f5f71017]
        return _bd2852ba1913, _2f786d66a006

    def _e0a21e109830(self, _539323246214: _16e270684126, _458feaf42d49: _8d1793de00c0) -> _0d40690f18b2[_eb3ced3bebcb, _eb3ced3bebcb]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _2f786d66a006 = {}
        _bd2852ba1913 = {}
        if _08982d39d52c._2c69f5699736._1048d0e9c0b6(_539323246214):
            with _90facb620c91(_539323246214, "r", _a36ccf3cfe76="utf8") as _3caabae805dd:
                _c0a2302757b3 = _6238125fe950._9cf1789cc82b(_3caabae805dd)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _2f786d66a006 = {
                    (_869f11c1595e(_95c1e049a679) if "." in _95c1e049a679 else _b802846acae0(_95c1e049a679)): _cf26dde40d3b
                    for _95c1e049a679, _cf26dde40d3b in _c0a2302757b3._1b2a2cea7b9d()
                }

        if _458feaf42d49:
            _2f786d66a006 = self._ff98b3b72ede(_bc2bb05c7fb0=_2f786d66a006)
            _bd2852ba1913, _2f786d66a006 = self._c20c7ff62924(_2f786d66a006=_2f786d66a006)
            with _90facb620c91(_539323246214, "w", _a36ccf3cfe76="utf8") as _1b72b8093638:
                _6238125fe950._b6e655ace930(_2f786d66a006, _1b72b8093638, _0a6cba6ba8f2=2)

        return _2f786d66a006, _bd2852ba1913

    def _be11cbc18a09(self) -> _309472d5359b[_b802846acae0]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._211380715da1(_3934cea42506) for _3934cea42506 in self._2af8373f2d2b] if _eea5af7d67a5(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _9f574d10fd52(self, _d70bddea3098: _869f11c1595e) -> _b802846acae0:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _b802846acae0(self._9d1de7bf579c * _d70bddea3098)

    @_fbe12a8688c7
    def _e6f04693535e(_d201dccab7f2: _16e270684126) -> _8d1793de00c0:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _20e572e2e7f2
        for _e37c26c6a78e in _d201dccab7f2:
            if "ARABIC" not in _20e572e2e7f2._dc7750076336(_e37c26c6a78e, ""):
                return _525d92b374a6
        return _b056e3454aed

    @_fbe12a8688c7
    def _0f1df089d780(_19c41201232a: _16e270684126) -> _16e270684126:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _5692efae393e._274a99fa682b(_19c41201232a):
            _bfbaa49767c3 = _19c41201232a._1a6ea35a0cc5()._65a53ed20cc0()
            _b5d07abcc74d = " "._67ae7ee3f9f4(_2b6d710786eb(_bfbaa49767c3))
            return _b5d07abcc74d
        return _19c41201232a

    def _420b21ddf4b5(self, _301115b75dde: _16e270684126, _c67bfb077d89: _16e270684126) -> _869f11c1595e:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _a5335fec3130(_af6fe6a286b4, _301115b75dde, _c67bfb077d89)._b1ccdefced86()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_fbe12a8688c7
    def _d42885f35f39(_f5dc9d9972ef) -> _0d40690f18b2[_309472d5359b[_eb3ced3bebcb], _b802846acae0]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import _471b2bbfdf3e
        _f21e1eb50233 = _471b2bbfdf3e._471b2bbfdf3e()
        _750e3946bd88, _22bde44f1e11, _e12c6a79aa74, _4fcf54a39f4e, _458feaf42d49, _fe7b31002d18 = _f5dc9d9972ef
        _472c6bbe1889 = _5692efae393e._c8476d7b0f47
        _ff3724d0c6e9 = 0
        _de6b5a1441f1 = _472c6bbe1889._db637296b0f4
        _705b20fc4e84: _309472d5359b[_eb3ced3bebcb] = []

        # Clean inputs and prepare per-word lists
        _0d4886313183 = [_2bf5edbc6a21._1a6ea35a0cc5() for _2bf5edbc6a21 in _750e3946bd88]
        _de0320197bea = [_25cbf98459f5._1a6ea35a0cc5() for _25cbf98459f5 in _22bde44f1e11]
        _29c795bbeb0c = [_d201dccab7f2._65a53ed20cc0() if _d201dccab7f2 else ["<empty>"] for _d201dccab7f2 in _0d4886313183]
        _26880b220e92 = []
        for _f8cca0a2dea1, _4f827c751b2e in _c3fad8a0897c(_29c795bbeb0c, _22bde44f1e11):
            _908c1107fb27 = _4f827c751b2e if _9d2fdb7fab9e(_4f827c751b2e, _8a9e66c67e25) else (_4f827c751b2e._1a6ea35a0cc5()._65a53ed20cc0() if _4f827c751b2e._1a6ea35a0cc5() else ["<empty>"])
            if _eab3df06a926(_908c1107fb27) == 1:
                _908c1107fb27 = [_908c1107fb27[0]] * _eab3df06a926(_f8cca0a2dea1)
            elif _eab3df06a926(_908c1107fb27) != _eab3df06a926(_f8cca0a2dea1):
                _908c1107fb27 = _908c1107fb27[:_eab3df06a926(_f8cca0a2dea1)] if _eab3df06a926(_908c1107fb27) > _eab3df06a926(_f8cca0a2dea1) else _908c1107fb27 + [_908c1107fb27[-1]] * (_eab3df06a926(_f8cca0a2dea1) - _eab3df06a926(_908c1107fb27))
            _26880b220e92._070912edbe13(_908c1107fb27)

        # Flatten all words for a single tokenizer call (faster)
        _54a2f3aa36c2 = _8a9e66c67e25(_579dc3896898(*_29c795bbeb0c))
        _e3c371320dbe = _471b2bbfdf3e._471b2bbfdf3e()
        try:
            _628297448641 = _472c6bbe1889(_54a2f3aa36c2, _cc10d2e91139=_525d92b374a6, _30debd9631a4=_525d92b374a6, _a75dcc7aef67=_525d92b374a6)
        except _0281ff95afd8 as _b4f30ba1d90c:
            _b062c9430a67(f"Tokenization error: {_b4f30ba1d90c}")
            _628297448641 = {"input_ids": [[0] for _ in _54a2f3aa36c2]}
        # build word token info per sentence
        _9f701ce9b7c7 = 0
        _4a1e4bdc2eca = []
        for _f8cca0a2dea1 in _29c795bbeb0c:
            _97fe107fa6dd = _eab3df06a926(_f8cca0a2dea1)
            _d150cd5e8601 = [(_9698f5f71017, _628297448641["input_ids"][_9f701ce9b7c7 + _9698f5f71017], _eab3df06a926(_628297448641["input_ids"][_9f701ce9b7c7 + _9698f5f71017])) for _9698f5f71017 in _e8512585fd08(_97fe107fa6dd)]
            _4a1e4bdc2eca._070912edbe13(_d150cd5e8601)
            _9f701ce9b7c7 += _97fe107fa6dd

        # chunk each sentence into token windows
        for _60c8bfe1c2f9, (_f8cca0a2dea1, _d5baf94140fd, _908c1107fb27) in _2de0e22ce5e9(_c3fad8a0897c(_29c795bbeb0c, _4a1e4bdc2eca, _26880b220e92)):
            _39c6ba9cfab6 = _fe7b31002d18 + _60c8bfe1c2f9
            _ea54f9a57d1d = 0
            if _f8cca0a2dea1 == ["<empty>"]:
                _512c9c4af8b3 = [0] * _e12c6a79aa74
                _705b20fc4e84._070912edbe13({
                    "sample_id": _39c6ba9cfab6,
                    "chunk_id": _ea54f9a57d1d,
                    "input_ids": _512c9c4af8b3,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _9698f5f71017 = 0
            _61816d08bb6f = _eab3df06a926(_d5baf94140fd)
            _76e847c9b205 = []
            while _9698f5f71017 < _61816d08bb6f:
                _54117773303e = 0
                _ffb823dd659a = []
                _413956a7628c = []
                _f1baeeca1100 = []
                _7f4b41816e70 = _9698f5f71017
                while _7f4b41816e70 < _61816d08bb6f:
                    _8e6a1459df43, _93107bd19b1c, _626188cf5619 = _d5baf94140fd[_7f4b41816e70]
                    _2add3bc847bd = _908c1107fb27[_8e6a1459df43] if _8e6a1459df43 < _eab3df06a926(_908c1107fb27) else _908c1107fb27[-1] if _908c1107fb27 else "<unknown>"
                    if _626188cf5619 > _e12c6a79aa74 and not _ffb823dd659a:
                        _ffb823dd659a += _93107bd19b1c[:_e12c6a79aa74]
                        _413956a7628c._070912edbe13(_2add3bc847bd)
                        _f1baeeca1100._070912edbe13(_8e6a1459df43)
                        _7f4b41816e70 += 1
                        break
                    if _54117773303e + _626188cf5619 > _e12c6a79aa74 and _ffb823dd659a:
                        break
                    _ffb823dd659a += _93107bd19b1c
                    _413956a7628c._070912edbe13(_2add3bc847bd)
                    _ff3724d0c6e9 += 1
                    _f1baeeca1100._070912edbe13(_7f4b41816e70)
                    _54117773303e += _626188cf5619
                    _7f4b41816e70 += 1

                if not _ffb823dd659a:
                    # fallback: take token prefix to avoid infinite loop
                    _ffb823dd659a = _d5baf94140fd[_9698f5f71017][1][:_e12c6a79aa74] or [0]
                    _413956a7628c = [_908c1107fb27[_9698f5f71017] if _9698f5f71017 < _eab3df06a926(_908c1107fb27) else _908c1107fb27[-1] if _908c1107fb27 else "<unknown>"]
                    _f1baeeca1100 = [_9698f5f71017]
                    _ff3724d0c6e9 += 1
                    _9698f5f71017 += 1

                # pad tokens to fixed length
                if _eab3df06a926(_ffb823dd659a) < _e12c6a79aa74:
                    _ffb823dd659a += [_de6b5a1441f1] * (_e12c6a79aa74 - _eab3df06a926(_ffb823dd659a))

                _76e847c9b205._070912edbe13({
                    "sample_id": _39c6ba9cfab6,
                    "chunk_id": _ea54f9a57d1d,
                    "input_ids": _ffb823dd659a,
                    "labels": _413956a7628c,
                    "word_positions": _f1baeeca1100,
                    "num_chunks": 1
                })
                _ea54f9a57d1d += 1

                if _7f4b41816e70 >= _61816d08bb6f:
                    break

                # stride with overlap (in words)
                _73b8d2dbef5a = _eab3df06a926(_f1baeeca1100)
                _7b659ce65a37 = _b802846acae0(_4fcf54a39f4e * _73b8d2dbef5a)
                _7b659ce65a37 = _723d7b93db65(_7b659ce65a37, _73b8d2dbef5a - 1) if _73b8d2dbef5a > 1 else 0
                _9d7107be109f = _7f4b41816e70 - _7b659ce65a37
                if _9d7107be109f <= _9698f5f71017:
                    _9d7107be109f = _9698f5f71017 + 1
                _9698f5f71017 = _9d7107be109f

            _05155e186eb5 = _eab3df06a926(_76e847c9b205)
            for _dea04d5039d7 in _76e847c9b205:
                _dea04d5039d7["num_chunks"] = _05155e186eb5
            _705b20fc4e84._02aa8b56d508(_76e847c9b205)

            if not _5692efae393e._b6aba09456f0 and not _458feaf42d49 and _05155e186eb5 > 1:
                _b062c9430a67(f"[DEBUG] sample_id={_39c6ba9cfab6}", _df085244289d=_b056e3454aed)
                _5692efae393e._b6aba09456f0 = _b056e3454aed

        # Timing/logging suppressed to preserve original behavior
        return _705b20fc4e84, _ff3724d0c6e9

    @_fbe12a8688c7
    def _fdfd6cea6126(_f5dc9d9972ef) -> _0d40690f18b2[_309472d5359b[_eb3ced3bebcb], _b802846acae0]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import _471b2bbfdf3e
        _f21e1eb50233 = _471b2bbfdf3e._471b2bbfdf3e()
        (_a5cf6bdf14cf, _750e3946bd88, _22bde44f1e11, _e12c6a79aa74, _4fcf54a39f4e, _ba201adcc512, _fe7b31002d18) = _f5dc9d9972ef
        _472c6bbe1889 = _5692efae393e._c8476d7b0f47
        _de6b5a1441f1 = _472c6bbe1889._db637296b0f4 or _472c6bbe1889._26d282bbcd9f
        _b5cb103cab37 = _472c6bbe1889._26d282bbcd9f
        _35d8c64c88de = -100

        # Chat-ish prefixes used in dataset construction
        # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
        # "Identify the language of every word and reply with space-separated codes only.\n"
        # "Do not include any explanation or extra text.\n")
        # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _f28024bfb1e8 = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
        "Identify the language of every word and reply with space-separated codes only.\n"
        "Do not include any explanation or extra text.\n")
        _c40ffa021791 = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _6151b4b4fe22 = _472c6bbe1889._73dda7a0a3ff(_a5cf6bdf14cf, _cc10d2e91139=_525d92b374a6)
        _4ceb1e31a660 = _472c6bbe1889._73dda7a0a3ff(_f28024bfb1e8, _cc10d2e91139=_525d92b374a6)
        _dfcd88697701 = _472c6bbe1889._73dda7a0a3ff(_c40ffa021791, _cc10d2e91139=_525d92b374a6)
        _59eeb45b7c80 = _472c6bbe1889._73dda7a0a3ff(" ", _cc10d2e91139=_525d92b374a6)
        _ace57d70e3bd = _6151b4b4fe22 + _4ceb1e31a660
        _e2a5af35840c = _dfcd88697701
        _d6d75ce220e8 = 1
        _0fc28eeb885a = _eab3df06a926(_ace57d70e3bd) + _eab3df06a926(_e2a5af35840c) + _d6d75ce220e8

        _705b20fc4e84: _309472d5359b[_eb3ced3bebcb] = []
        _ff3724d0c6e9 = 0

        # Preprocess lines into words lists and align labels to words
        _0d4886313183 = [_2bf5edbc6a21._1a6ea35a0cc5() for _2bf5edbc6a21 in _750e3946bd88]
        _de0320197bea = [_25cbf98459f5._1a6ea35a0cc5() for _25cbf98459f5 in _22bde44f1e11]
        _29c795bbeb0c = []
        _9cc4d5ee385c = []
        for _685bdc692a9b, _4f827c751b2e in _c3fad8a0897c(_0d4886313183, _22bde44f1e11):
            _f8cca0a2dea1 = _685bdc692a9b._65a53ed20cc0() if _685bdc692a9b else ["<empty>"]
            _9029758e010c = _4f827c751b2e if _9d2fdb7fab9e(_4f827c751b2e, _8a9e66c67e25) else (_4f827c751b2e._1a6ea35a0cc5()._65a53ed20cc0() if _4f827c751b2e._1a6ea35a0cc5() else ["<empty>"])
            if _eab3df06a926(_9029758e010c) == 1:
                _9029758e010c = [_9029758e010c[0]] * _eab3df06a926(_f8cca0a2dea1)
            elif _eab3df06a926(_9029758e010c) != _eab3df06a926(_f8cca0a2dea1):
                _9029758e010c = _9029758e010c[:_eab3df06a926(_f8cca0a2dea1)] if _eab3df06a926(_9029758e010c) > _eab3df06a926(_f8cca0a2dea1) else _9029758e010c + [_9029758e010c[-1]] * (_eab3df06a926(_f8cca0a2dea1) - _eab3df06a926(_9029758e010c))
            _29c795bbeb0c._070912edbe13(_f8cca0a2dea1)
            _9cc4d5ee385c._070912edbe13(_9029758e010c)

        # Flatten words for efficient tokenization
        _54a2f3aa36c2 = _8a9e66c67e25(_579dc3896898(*_29c795bbeb0c))
        _86c505dd206d = _8a9e66c67e25(_579dc3896898(*_9cc4d5ee385c))
        _11d2c63eae5e = _472c6bbe1889(_54a2f3aa36c2, _cc10d2e91139=_525d92b374a6, _30debd9631a4=_525d92b374a6)["input_ids"]
        _e602a7a7aa93 = _472c6bbe1889(_86c505dd206d, _cc10d2e91139=_525d92b374a6, _30debd9631a4=_525d92b374a6)["input_ids"]

        # Build per-line token info
        _9f701ce9b7c7 = 0
        _c71d2829a231 = 0
        _4a1e4bdc2eca = []
        _ab22eac9c85e = []
        for _f8cca0a2dea1, _9029758e010c in _c3fad8a0897c(_29c795bbeb0c, _9cc4d5ee385c):
            _97fe107fa6dd = _eab3df06a926(_f8cca0a2dea1)
            _b66340fe8085 = _eab3df06a926(_9029758e010c)
            if _f8cca0a2dea1 == ["<empty>"] or _9029758e010c == ["<empty>"]:
                _4a1e4bdc2eca._070912edbe13([(_f8cca0a2dea1[0], [0], 1)])
                _ab22eac9c85e._070912edbe13([(_9029758e010c[0], [0], 1)])
                continue
            try:
                _d150cd5e8601 = [(_be7cd782ca1c, _11d2c63eae5e[_9f701ce9b7c7 + _9698f5f71017], _eab3df06a926(_11d2c63eae5e[_9f701ce9b7c7 + _9698f5f71017]) if _9d2fdb7fab9e(_11d2c63eae5e[_9f701ce9b7c7 + _9698f5f71017], _8a9e66c67e25) else 1) for _9698f5f71017, _be7cd782ca1c in _2de0e22ce5e9(_f8cca0a2dea1)]
                _6686481992e0 = [(_be7cd782ca1c, _e602a7a7aa93[_c71d2829a231 + _9698f5f71017], _eab3df06a926(_e602a7a7aa93[_c71d2829a231 + _9698f5f71017]) if _9d2fdb7fab9e(_e602a7a7aa93[_c71d2829a231 + _9698f5f71017], _8a9e66c67e25) else 1) for _9698f5f71017, _be7cd782ca1c in _2de0e22ce5e9(_9029758e010c)]
            except _1e6f43dd73fd:
                # On tokenization mismatches, fallback safely
                _4a1e4bdc2eca._070912edbe13([(_f8cca0a2dea1[0], [0], 1)])
                _ab22eac9c85e._070912edbe13([(_9029758e010c[0], [0], 1)])
                _9f701ce9b7c7 += _97fe107fa6dd
                _c71d2829a231 += _b66340fe8085
                continue
            _4a1e4bdc2eca._070912edbe13(_d150cd5e8601)
            _ab22eac9c85e._070912edbe13(_6686481992e0)
            _9f701ce9b7c7 += _97fe107fa6dd
            _c71d2829a231 += _b66340fe8085

        # Build chunks per sentence
        for _60c8bfe1c2f9, (_f8cca0a2dea1, _d5baf94140fd, _68a9d77f4285) in _2de0e22ce5e9(_c3fad8a0897c(_29c795bbeb0c, _4a1e4bdc2eca, _ab22eac9c85e)):
            _39c6ba9cfab6 = _fe7b31002d18 + _60c8bfe1c2f9
            _ea54f9a57d1d = 0
            _df9f965e6874 = [_057dc782159a[0] for _057dc782159a in _68a9d77f4285]

            if _f8cca0a2dea1 == ["<empty>"]:
                _512c9c4af8b3 = _ace57d70e3bd + [0] + _e2a5af35840c + [_b5cb103cab37]
                _dd2898df961b = [_35d8c64c88de] * _eab3df06a926(_512c9c4af8b3)
                _550b26ab37a2 = _e12c6a79aa74 - _eab3df06a926(_512c9c4af8b3)
                if _550b26ab37a2 > 0:
                    _512c9c4af8b3 += [_de6b5a1441f1] * _550b26ab37a2
                    _dd2898df961b += [_35d8c64c88de] * _550b26ab37a2
                _705b20fc4e84._070912edbe13({
                    "lang_codes": ["<empty>"],
                    "sample_id": _39c6ba9cfab6,
                    "chunk_id": _ea54f9a57d1d,
                    "word_positions": [0],
                    "input_ids": _512c9c4af8b3,
                    "labels": _dd2898df961b,
                    "prompt_len": _eab3df06a926(_ace57d70e3bd) + 1 + _eab3df06a926(_e2a5af35840c),
                    "chunk_words": ["<empty>"],
                    "chunk_labels": ["<empty>"],
                    "num_chunks": 1
                })
                continue

            _9698f5f71017 = 0
            _61816d08bb6f = _eab3df06a926(_d5baf94140fd)
            _1eacd269acbe = -1
            _76e847c9b205 = []
            while _9698f5f71017 < _61816d08bb6f:
                _54117773303e = _0fc28eeb885a
                _3c12bca7d063 = []
                _26826a534add = []
                _f1baeeca1100 = []
                _9f48213a25a5 = []
                _8bf2e008c18a = []
                _413956a7628c = []
                _7f4b41816e70 = _9698f5f71017
                while _7f4b41816e70 < _61816d08bb6f:
                    _, _6ae6a37f34ba, _97fe107fa6dd = _d5baf94140fd[_7f4b41816e70]
                    _12f7c2d2a389, _6e129ce2f24d, _b66340fe8085 = _68a9d77f4285[_7f4b41816e70]
                    _595cfff1d5c1 = _eab3df06a926(_59eeb45b7c80) if _7f4b41816e70 < _61816d08bb6f - 1 else 0
                    # choose conservative word_total so both streams fit
                    _6c6d7331284f = _156589dbff91(_97fe107fa6dd, _b66340fe8085) + _595cfff1d5c1
                    if _54117773303e + _6c6d7331284f > _e12c6a79aa74 * 0.9:
                        break

                    # append inputs and spaces
                    _3c12bca7d063 += _6ae6a37f34ba if _9d2fdb7fab9e(_6ae6a37f34ba, _8a9e66c67e25) else [_6ae6a37f34ba]
                    if _595cfff1d5c1:
                        _3c12bca7d063 += _59eeb45b7c80

                    # append labels and word_positions
                    if _b66340fe8085:
                        _26826a534add += _6e129ce2f24d if _9d2fdb7fab9e(_6e129ce2f24d, _8a9e66c67e25) else [_6e129ce2f24d]
                        _f1baeeca1100 += [_7f4b41816e70] * _b66340fe8085
                    if _595cfff1d5c1:
                        _26826a534add += _59eeb45b7c80
                        _f1baeeca1100 += [-1] * _595cfff1d5c1

                    _9f48213a25a5._070912edbe13(_12f7c2d2a389)
                    _8bf2e008c18a._070912edbe13(_f8cca0a2dea1[_7f4b41816e70])
                    _413956a7628c._070912edbe13(_12f7c2d2a389)
                    _ff3724d0c6e9 += _eab3df06a926(_f8cca0a2dea1[_7f4b41816e70])
                    _54117773303e += _6c6d7331284f
                    _7f4b41816e70 += 1

                if not _3c12bca7d063:
                    _9698f5f71017 += 1
                    continue

                _35e1d3799634 = _3c12bca7d063
                _1d5abf29a411 = _26826a534add
                _bbbcf3439a84 = _eab3df06a926(_ace57d70e3bd) + _eab3df06a926(_35e1d3799634) + _eab3df06a926(_e2a5af35840c)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                if _ba201adcc512 is _525d92b374a6:
                    _512c9c4af8b3 = _ace57d70e3bd + _35e1d3799634 + _e2a5af35840c + _1d5abf29a411 + [_b5cb103cab37]
                    _dd2898df961b = [_35d8c64c88de] * _bbbcf3439a84 + _1d5abf29a411 + [_35d8c64c88de]
                else:
                    _512c9c4af8b3 = _ace57d70e3bd + _35e1d3799634 + _e2a5af35840c + [_b5cb103cab37]
                    _dd2898df961b = [_35d8c64c88de] * _bbbcf3439a84 + _1d5abf29a411 + [_35d8c64c88de]

                # pad to fixed size (inputs appended or prepended depending on test/train)
                _74507cab1524 = _e12c6a79aa74 - _eab3df06a926(_512c9c4af8b3)
                _a1feaffb0eeb = _e12c6a79aa74 - _eab3df06a926(_dd2898df961b)
                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len
                if _74507cab1524 > 0:
                    if _ba201adcc512:
                        _512c9c4af8b3 = [_de6b5a1441f1] * _74507cab1524 + _512c9c4af8b3
                    else:
                        _512c9c4af8b3 += [_de6b5a1441f1] * _74507cab1524
                if _a1feaffb0eeb > 0:
                    if _ba201adcc512:
                        _dd2898df961b = [_35d8c64c88de] * _a1feaffb0eeb + _dd2898df961b
                    else:
                        _dd2898df961b += [_35d8c64c88de] * _a1feaffb0eeb

                _76e847c9b205._070912edbe13({
                    "lang_codes": _9f48213a25a5,
                    "sample_id": _39c6ba9cfab6,
                    "chunk_id": _ea54f9a57d1d,
                    "word_positions": _f1baeeca1100,
                    "input_ids": _512c9c4af8b3,
                    "labels": _dd2898df961b,
                    "prompt_len": _bbbcf3439a84,
                    "chunk_words": _8bf2e008c18a,
                    "chunk_labels": _413956a7628c,
                    "num_chunks": 1
                })
                _ea54f9a57d1d += 1

                if _7f4b41816e70 >= _61816d08bb6f or _7f4b41816e70 <= _1eacd269acbe:
                    break
                _1eacd269acbe = _7f4b41816e70
                _901d3dc84d1d = _156589dbff91(1, _b802846acae0(_4fcf54a39f4e * _eab3df06a926(_8bf2e008c18a)))
                _9698f5f71017 = _7f4b41816e70 - _901d3dc84d1d if (_7f4b41816e70 - _901d3dc84d1d) > _9698f5f71017 else _7f4b41816e70

            _05155e186eb5 = _eab3df06a926(_76e847c9b205)
            for _dea04d5039d7 in _76e847c9b205:
                _dea04d5039d7["num_chunks"] = _05155e186eb5
            _705b20fc4e84._02aa8b56d508(_76e847c9b205)

            if not _5692efae393e._b6aba09456f0 and not _ba201adcc512 and _05155e186eb5 > 1:
                _5692efae393e._b6aba09456f0 = _b056e3454aed

        return _705b20fc4e84, _ff3724d0c6e9

    # -------------------------
    # File processing & validation
    # -------------------------
    def _b30afe5bbcf2(self, _87697c1e88c5: _16e270684126, _12bb7c002444: _16e270684126, _fe7b31002d18: _b802846acae0) -> _0d40690f18b2[_16e270684126, _309472d5359b[_eb3ced3bebcb], _b802846acae0]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _8be811368b73 = []

        with _90facb620c91(_87697c1e88c5, "r", _a36ccf3cfe76="utf8") as _ea9e82c6e3c2, _90facb620c91(_12bb7c002444, "r", _a36ccf3cfe76="utf8") as _4e3d0064eeac:
            _750e3946bd88 = _ea9e82c6e3c2._9eef7440f686()[1:] if self._3c285d31d86b else _ea9e82c6e3c2._9eef7440f686()
            _22bde44f1e11 = _4e3d0064eeac._9eef7440f686()[1:] if self._3c285d31d86b else _4e3d0064eeac._9eef7440f686()

        # sample some share if requested
        _a6ec16c68e08 = _b802846acae0(_eab3df06a926(_750e3946bd88) * self._ade430624e0d)
        if _a6ec16c68e08 < _eab3df06a926(_750e3946bd88):
            _2dc8bc4126df = _5af885616f2d._93cc85e58892._22c3ebc087b7(_eab3df06a926(_750e3946bd88), _a6ec16c68e08, _95a082346cea=_525d92b374a6)
            _750e3946bd88 = [_750e3946bd88[_9698f5f71017] for _9698f5f71017 in _2dc8bc4126df]
            _22bde44f1e11 = [_22bde44f1e11[_9698f5f71017] for _9698f5f71017 in _2dc8bc4126df]

        _3934cea42506 = _8a9e66c67e25({_25cbf98459f5._1a6ea35a0cc5() for _25cbf98459f5 in _22bde44f1e11})[0] if _22bde44f1e11 else "unk"
        self._1e91b7ca883d._057dc782159a(f"Sampled {self._ade430624e0d * 100:.1f}% of {_87697c1e88c5}: {_eab3df06a926(_750e3946bd88)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _564b852622f4(_71bcaf20820e, _444fcf007274):
            _84a81fc9e6d3 = _c104ede13aa2(_71bcaf20820e)
            while _b056e3454aed:
                _9c0635dd4488 = _8a9e66c67e25(_ae8f912773d4(_84a81fc9e6d3, _444fcf007274))
                if not _9c0635dd4488:
                    break
                yield _9c0635dd4488

        _444fcf007274 = 10_000
        if self._33fd50a053d8:
            _812bb8a0f672 = [
                (self._a5cf6bdf14cf, _8b38464fee42, _c818b4a9c40f, self._9d1de7bf579c, 0.25, self._ba201adcc512, _fe7b31002d18 + _ac57a2f202a0 * _444fcf007274)
                for _ac57a2f202a0, (_8b38464fee42, _c818b4a9c40f) in _2de0e22ce5e9(_c3fad8a0897c(_19c447baec4c(_750e3946bd88, _444fcf007274), _19c447baec4c(_22bde44f1e11, _444fcf007274)))
            ]
            with _8f1d5cdfc4d1(self._01b0c54dfcc5) as _a8126840facc:
                _3824e4cf595b = _a8126840facc._80e6317db081(_5692efae393e._e6c19653021a, _812bb8a0f672)
        else:
            _812bb8a0f672 = [
                (_8b38464fee42, _c818b4a9c40f, self._9d1de7bf579c, 0.5, self._458feaf42d49, _fe7b31002d18 + _ac57a2f202a0 * _444fcf007274)
                for _ac57a2f202a0, (_8b38464fee42, _c818b4a9c40f) in _2de0e22ce5e9(_c3fad8a0897c(_19c447baec4c(_750e3946bd88, _444fcf007274), _19c447baec4c(_22bde44f1e11, _444fcf007274)))
            ]
            with _8f1d5cdfc4d1(self._01b0c54dfcc5) as _a8126840facc:
                _3824e4cf595b = _a8126840facc._80e6317db081(_5692efae393e._ba0fbf03fee7, _812bb8a0f672)

        _acebd11021ee = []
        for _705b20fc4e84, _96100ae90b67 in _3824e4cf595b:
            _acebd11021ee._02aa8b56d508(_705b20fc4e84)
            self._f4637f3301f6 += _96100ae90b67

        if _acebd11021ee:
            _8be811368b73 = _acebd11021ee

        return _3934cea42506, _8be811368b73, _eab3df06a926(_750e3946bd88)

    def _d4df582283b0(self) -> _af6fe6a286b4:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _a5f4d0410ebf = 0

        for _405ec890fca2 in _08982d39d52c._a29db0c935ad(self._29279732db2c):
            self._1e91b7ca883d._057dc782159a(f"Now processing {_08982d39d52c._2c69f5699736._67ae7ee3f9f4(self._29279732db2c, _405ec890fca2)} directory.")
            _6e008a87feb6 = _08982d39d52c._2c69f5699736._67ae7ee3f9f4(self._29279732db2c, _405ec890fca2, "src")
            _bd3701306360 = _08982d39d52c._2c69f5699736._67ae7ee3f9f4(self._29279732db2c, _405ec890fca2, "tgt")

            _ea956e55005b = []
            _a27848c94cbc = []
            for _87697c1e88c5 in _08982d39d52c._a29db0c935ad(_6e008a87feb6):
                _00ef2ca9c543 = _525d92b374a6
                for _12bb7c002444 in _08982d39d52c._a29db0c935ad(_bd3701306360):
                    if _87697c1e88c5._65a53ed20cc0(".")[0] == _12bb7c002444._65a53ed20cc0(".")[0]:
                        _ea956e55005b._070912edbe13(_87697c1e88c5)
                        _a27848c94cbc._070912edbe13(_12bb7c002444)
                        _00ef2ca9c543 = _b056e3454aed
                        break
                if not _00ef2ca9c543:
                    self._1e91b7ca883d._057dc782159a(f"Skipping file {_87697c1e88c5} since matching label file not found in {_bd3701306360}.")

            _57e00d75758e = [_08982d39d52c._2c69f5699736._67ae7ee3f9f4(_6e008a87feb6, _e36060b6cfb0) for _e36060b6cfb0 in _ea956e55005b if _08982d39d52c._2c69f5699736._4d6587f03404(_08982d39d52c._2c69f5699736._67ae7ee3f9f4(_6e008a87feb6, _e36060b6cfb0))]
            _561d7d17498b = [_08982d39d52c._2c69f5699736._67ae7ee3f9f4(_bd3701306360, _e36060b6cfb0) for _e36060b6cfb0 in _a27848c94cbc if _08982d39d52c._2c69f5699736._4d6587f03404(_08982d39d52c._2c69f5699736._67ae7ee3f9f4(_bd3701306360, _e36060b6cfb0))]

            if _eab3df06a926(_57e00d75758e) != _eab3df06a926(_561d7d17498b):
                raise _da5c8f26b416(f"Number of files in {_6e008a87feb6} ({_eab3df06a926(_57e00d75758e)}) does not match {_bd3701306360} ({_eab3df06a926(_561d7d17498b)})")

            for _87697c1e88c5, _12bb7c002444 in _c3fad8a0897c(_57e00d75758e, _561d7d17498b):
                _06e10b54cb42 = _8cf98ff4520e(1 for _ in _90facb620c91(_87697c1e88c5))
                _26aa9496780c = _8cf98ff4520e(1 for _ in _90facb620c91(_12bb7c002444))
                _06e10b54cb42 = _06e10b54cb42 - 1 if self._3c285d31d86b else _06e10b54cb42
                _26aa9496780c = _26aa9496780c - 1 if self._3c285d31d86b else _26aa9496780c

                if _06e10b54cb42 != _26aa9496780c:
                    self._1e91b7ca883d._057dc782159a(f"{_06e10b54cb42} lines in {_87697c1e88c5} do not match with {_26aa9496780c} in {_12bb7c002444}, skipping these files")
                    continue

                self._1e91b7ca883d._057dc782159a(f"Processing {_87697c1e88c5} and {_12bb7c002444} with {_26aa9496780c} samples.")
                _3934cea42506, _b1afedbf35b7, _b1a73d0f71be = self._4a715f00b21c(_87697c1e88c5, _12bb7c002444, _fe7b31002d18=_a5f4d0410ebf)
                _a5f4d0410ebf += _b1a73d0f71be

                self._b1afedbf35b7._02aa8b56d508(_b1afedbf35b7)
                if self._458feaf42d49:
                    if _3934cea42506 not in self._e8489253d5c2:
                        self._e8489253d5c2._cf2548bc7d45({
                            _3934cea42506: [{
                                "file_name": _08982d39d52c._2c69f5699736._dda77a769724(_12bb7c002444),
                                "samples_before_processing": _26aa9496780c,
                                "samples_after_processing": _eab3df06a926(_b1afedbf35b7)
                            }]
                        })
                    else:
                        self._e8489253d5c2[_3934cea42506]._070912edbe13({
                            "file_name": _08982d39d52c._2c69f5699736._dda77a769724(_12bb7c002444),
                            "samples_before_processing": _26aa9496780c,
                            "samples_after_processing": _eab3df06a926(_b1afedbf35b7)
                        })
                self._1e91b7ca883d._057dc782159a(f"Files {_87697c1e88c5} and {_12bb7c002444} have {_eab3df06a926(_b1afedbf35b7)} samples after processing.")

        # verify dataset integrity
        self._caf3101f6e94()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _190770d163c9(self) -> _af6fe6a286b4:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _d8a581a15bec = self._b1afedbf35b7
        if not _d8a581a15bec:
            self._1e91b7ca883d._057dc782159a("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _ded93f4d2ddb = [_bc1dd5051a44["sample_id"] for _bc1dd5051a44 in _d8a581a15bec]
        _f07c2506a454 = _0ebd3d0283ba(_ded93f4d2ddb)
        _c979d13c3475 = _156589dbff91(_f07c2506a454)
        _5762acd89e6c = (_eab3df06a926(_f07c2506a454) == _c979d13c3475 + 1)
        self._1e91b7ca883d._057dc782159a(f"[sample_id] unique={_eab3df06a926(_f07c2506a454)} max={_c979d13c3475} coverage_ok={_5762acd89e6c} (expect True)")
        if not _5762acd89e6c:
            _db2af6eaa84f = _964655b9903e(_0ebd3d0283ba(_e8512585fd08(_c979d13c3475 + 1)) - _f07c2506a454)
            self._1e91b7ca883d._057dc782159a(f" Missing sample_ids: {_db2af6eaa84f[:20]}{' ...' if _eab3df06a926(_db2af6eaa84f) > 20 else ''}")
            raise _da5c8f26b416(f"Increase max_seq_len as missing sample_ids detected: {_db2af6eaa84f[:20]}{' ...' if _eab3df06a926(_db2af6eaa84f) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _5097894b41f9 = [(_bc1dd5051a44["sample_id"], _bc1dd5051a44["chunk_id"]) for _bc1dd5051a44 in _d8a581a15bec]
        _0804e3de9885 = [_95c1e049a679 for _95c1e049a679, _cf26dde40d3b in _6beab8f2e9bd(_5097894b41f9)._1b2a2cea7b9d() if _cf26dde40d3b > 1]
        self._1e91b7ca883d._057dc782159a(f"[(sample_id,chunk_id)] duplicates: {_eab3df06a926(_0804e3de9885)} (expect 0)")
        if _0804e3de9885:
            self._1e91b7ca883d._057dc782159a(f" Examples: {_0804e3de9885[:10]}")
            raise _da5c8f26b416(f"Duplicate (sample_id, chunk_id) pairs detected: {_0804e3de9885[:10]}")

        # 3) per-sample chunk_id sequentiality
        _cf430f1391f8 = _399d36454d08(_8a9e66c67e25)
        for _bc1dd5051a44 in _d8a581a15bec:
            _cf430f1391f8[_bc1dd5051a44["sample_id"]]._070912edbe13(_bc1dd5051a44["chunk_id"])
        _b4e10c070f1d = {}
        for _066073b7018d, _93107bd19b1c in _cf430f1391f8._1b2a2cea7b9d():
            _02654b171a32 = _964655b9903e(_93107bd19b1c)
            _34a844d94bef = _8a9e66c67e25(_e8512585fd08(_eab3df06a926(_02654b171a32)))
            if _02654b171a32 != _34a844d94bef:
                _b4e10c070f1d[_066073b7018d] = {"have": _02654b171a32[:20], "expected_prefix": _34a844d94bef[:20]}
        self._1e91b7ca883d._057dc782159a(f"[per-sample chunk_id sequence] bad_samples: {_eab3df06a926(_b4e10c070f1d)} (expect 0)")
        if _b4e10c070f1d:
            _d5163faf7d26 = _8a9e66c67e25(_b4e10c070f1d._1b2a2cea7b9d())[:5]
            for _066073b7018d, _057dc782159a in _d5163faf7d26:
                self._1e91b7ca883d._057dc782159a(f" sample_id={_066073b7018d} have={_057dc782159a['have']} expected_prefix={_057dc782159a['expected_prefix']}")
            raise _da5c8f26b416(f"Non-sequential chunk_id sequences detected for sample_ids: {_8a9e66c67e25(_b4e10c070f1d._6fa953edc958())[:5]}")

        # 4) overall stats reporting
        _7fd89cef0325 = _eab3df06a926(_f07c2506a454)
        _d240a5a26f64 = _eab3df06a926(_d8a581a15bec)
        _2c262e0660cd = _d240a5a26f64 / _7fd89cef0325 if _7fd89cef0325 > 0 else 0
        self._1e91b7ca883d._057dc782159a(f"[audit] base={_7fd89cef0325} -> chunks={_d240a5a26f64} (avg {_2c262e0660cd:.2f} per sample)")

    @_185e62936da6
    def _814d005a9dd7(self) -> _b802846acae0:
        """Return number of unique base samples (unique sample_id)."""
        if not _b7b363f74173(self, "file_data_dict_list", _af6fe6a286b4):
            return 0
        return _eab3df06a926({_b802846acae0(_6699114e3465["sample_id"]) for _6699114e3465 in self._b1afedbf35b7})

    @_185e62936da6
    def _b0bbdd753b2b(self) -> _b802846acae0:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _b7b363f74173(self, "file_data_dict_list", _af6fe6a286b4):
            return 0

        _99844892c7fe = _399d36454d08(_0ebd3d0283ba)
        for _6699114e3465 in self._b1afedbf35b7:
            _066073b7018d = _b802846acae0(_6699114e3465._2b3b4e9c854e("sample_id", -1))
            for _0462c0e4615c in _6699114e3465._2b3b4e9c854e("word_positions", []):
                try:
                    _5e117b282a7a = _b802846acae0(_0462c0e4615c)
                except _0281ff95afd8:
                    continue
                if _5e117b282a7a >= 0:
                    _99844892c7fe[_066073b7018d]._e1de5dddc7f3(_5e117b282a7a)

        return _8cf98ff4520e(_eab3df06a926(_beff783091ed) for _beff783091ed in _99844892c7fe._3e625e5a7081())
