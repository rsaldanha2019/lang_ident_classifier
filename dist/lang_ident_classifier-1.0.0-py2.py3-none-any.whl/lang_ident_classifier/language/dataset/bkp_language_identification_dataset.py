# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
import json
import random
import re
from itertools import _721ef1c67ccb, _bf50dc7d3258
from collections import _2e6e6938ff64, _9a619ef54ff5
from _d033e8538a3c import _3ff59629ff8d
from _f3ed690fc624._dd57fddbee1c import _6915f6e4bd8a
from typing import _004f8db621f8, _71de54aead0c, _59262292ed8e

import _ef1704fb1838 as _003d33c0ae33
import _6def5cf99a3e
from _6def5cf99a3e._828a28a7042d._14b837291a2a import _1c81e7190781
from _94f7584d668a import _6fe8742a823a


class _a3ca2289f91b(_1c81e7190781):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _888c9eb7aafc = _a4ed72919fbd  # class-level tokenizer (set on __init__)
    _5acde86f3764 = _bc6b8a1e8217

    def _b5e8946d0d58(
        self,
        _dc7aa740583e: _cf315f7c3451,
        _421a88df6a79: _0f651b4cb428,
        _08667b3ec153: _004f8db621f8,
        _7af89ac4c85e: _697dcf680088,
        _43bf47f6955f: _cf315f7c3451,
        _e8d42f1fd0cb: _6fe8742a823a,
        _a970c90da6a9: _0f651b4cb428,
        _305a0f5ea336: _0f651b4cb428,
        _6c15af75ee49: _035f39b8c016 = 1.0,
        _04446ba3dc95: _697dcf680088 = 2,
        _867e6eb0d968: _697dcf680088 = 20,
        _18a6602a5311: _0f651b4cb428 = _bc6b8a1e8217,
        _6841017daf9b: _cf315f7c3451 = _a4ed72919fbd,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _fc9a9e6859f9()._d6e9d9cb5086()

        # Deterministic behavior
        _6def5cf99a3e._ecd543fde789(_867e6eb0d968)
        if _6def5cf99a3e._5d82d131c417._cf7d52c66900():
            _6def5cf99a3e._5d82d131c417._377f1f172e65(_867e6eb0d968)
        random._e4b86864bfc5(_867e6eb0d968)
        _003d33c0ae33.random._e4b86864bfc5(_867e6eb0d968)

        # Basic parameters & bookkeeping
        self._e8d42f1fd0cb = _e8d42f1fd0cb
        self._a970c90da6a9 = _a970c90da6a9
        self._305a0f5ea336 = _305a0f5ea336
        self._18a6602a5311 = _18a6602a5311
        self._6841017daf9b = _6841017daf9b
        self._421a88df6a79 = _421a88df6a79
        self._dc7aa740583e = _dc7aa740583e
        self._7af89ac4c85e = _7af89ac4c85e
        self._333e6e3d8200 = 0
        self._6c15af75ee49 = _6c15af75ee49
        self._04446ba3dc95 = _04446ba3dc95
        self._050b4781d5ba = -100

        # Tokenizer handling
        _131ad476148a._888c9eb7aafc = _08667b3ec153
        self._4d19f4b6daaf = _08667b3ec153
        if self._18a6602a5311:
            # preserve earlier code's fallback pad id (kept intentionally)
            if not self._4d19f4b6daaf._8b6667f92fa4:
                self._4d19f4b6daaf._8b6667f92fa4 = 128004

        # storage filled by _validate_and_load_file_data
        self._7fe009b433ed: _71de54aead0c[_672dd349ec1b] = []
        self._53195e088b5b = {}

        # Load and process files; then derive classes/weights
        self._812bb657dc8b()
        self._97dca46410a9, self._c2a46a6ce057 = self._8a9eb6f9f9a8(_43bf47f6955f, _a970c90da6a9)

    def _5d3f6c809676(self) -> _697dcf680088:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _1f39e1c175e6(self._7fe009b433ed)

    def _f6e47f964ccf(self, _c39774ae8bc6: _697dcf680088) -> _672dd349ec1b:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _9a7f00c360b9 = self._7fe009b433ed[_c39774ae8bc6]
        _b488deb0261e = _9a7f00c360b9._3bde8846f2d5("lang_code", "unk")
        _7a78d6f0832b = _9a7f00c360b9["input_ids"]
        _3360822645dc = _9a7f00c360b9["labels"]
        _c8032e7030fd = _9a7f00c360b9._3bde8846f2d5("word_positions", [])
        _1385870d4d66 = _9a7f00c360b9["num_chunks"]
        _816fd206d4f0 = _9a7f00c360b9._3bde8846f2d5("sample_id", _c39774ae8bc6)
        _0601408e0bde = _9a7f00c360b9._3bde8846f2d5("chunk_id", 0)
        _e6d1b201fdbc = _9a7f00c360b9._3bde8846f2d5("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _3360822645dc = [
            self._050b4781d5ba
            if _351212b2cc0d is _a4ed72919fbd
            else _697dcf680088(_351212b2cc0d) if _9ad36d8a7f25(_351212b2cc0d, _cf315f7c3451) and _351212b2cc0d._f7fa31e39182("-")._62e5fa6dcb7b()
            else _351212b2cc0d
            for _351212b2cc0d in _3360822645dc
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._18a6602a5311:
            _9ef6748fce67 = [
                self._e0f950489c16(_351212b2cc0d) if _9ad36d8a7f25(_351212b2cc0d, _cf315f7c3451) else _351212b2cc0d
                for _351212b2cc0d in _3360822645dc
            ]
            _0bc8204fc3fb = _1f39e1c175e6(_9ef6748fce67)
            _8ad0419476a5 = _b25187b37f0e(0, self._7af89ac4c85e - _0bc8204fc3fb)
            _9ef6748fce67 = _9ef6748fce67 + [self._050b4781d5ba] * _8ad0419476a5
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _9ef6748fce67 = _3360822645dc

        return {
            "lang_code": _b488deb0261e,
            "input_ids": _6def5cf99a3e._ccf322d63a73(_7a78d6f0832b, _e6440877c8f0=_6def5cf99a3e._ff6a02390585),
            "labels": _6def5cf99a3e._ccf322d63a73(_9ef6748fce67, _e6440877c8f0=_6def5cf99a3e._ff6a02390585),
            "sample_id": _816fd206d4f0,
            "chunk_id": _0601408e0bde,
            "word_positions": _c8032e7030fd,
            "prompt_len": _e6d1b201fdbc,
            "num_chunks": _1385870d4d66,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _7a08f616e527(self, _b488deb0261e: _cf315f7c3451) -> _697dcf680088:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _ab18b6f1286c, _7c8786451080 in self._97dca46410a9._baa61336564e():
            if _7c8786451080["lang_code"] == _cf315f7c3451(_b488deb0261e)._e289e9bec5c9():
                return _ab18b6f1286c
        return self._97dca46410a9._3bde8846f2d5("unk", {})._3bde8846f2d5("id", -1)

    def _7c0bce33817e(self, _7b2a1bc82f6f: _697dcf680088) -> _cf315f7c3451:
        """Reverse mapping; assumes class_id present."""
        return self._97dca46410a9[_7b2a1bc82f6f]["lang_code"]

    def _d1cf64fb2746(self) -> _697dcf680088:
        return _1f39e1c175e6(self._97dca46410a9)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _46d9cc9f766f(self, _ac477146e15b: _672dd349ec1b) -> _672dd349ec1b:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _80fe5bf7ab45 = re._bc4c3e0d638b(r"[^\d\s]+")  # tokens with non-digit characters
        _f74854753226 = _2e6e6938ff64()

        if self._18a6602a5311:
            _56e27809ffd1 = []
            for _274dfaf022fd in self._7fe009b433ed:
                _80f0c72e9dbc = _274dfaf022fd._3bde8846f2d5("labels", []) if _9ad36d8a7f25(_274dfaf022fd, _672dd349ec1b) else (_274dfaf022fd[1] if _9ad36d8a7f25(_274dfaf022fd, _e8fb02a49c80) and _1f39e1c175e6(_274dfaf022fd) > 1 else [])
                _390f85ad6e12 = [_daba2d513218 for _daba2d513218 in _80f0c72e9dbc if _daba2d513218 != self._050b4781d5ba]
                if _390f85ad6e12:
                    _56e27809ffd1._0f653c953078(_390f85ad6e12)
            if _56e27809ffd1:
                _39d907049fa6 = self._4d19f4b6daaf._6ada76f7c6cc(_56e27809ffd1, _a67cb93d7223=_418d7f8287fb)
                for _0b62bee428a4 in _39d907049fa6:
                    _5b41d5fdf325 = _80fe5bf7ab45._9d2d040b9c3b(_0b62bee428a4)
                    _f74854753226._75a2232a3982(_5b41d5fdf325)
        else:
            for _274dfaf022fd in self._7fe009b433ed:
                _80f0c72e9dbc = _274dfaf022fd._3bde8846f2d5("labels", [])
                _5b41d5fdf325 = [_d4d4e094a12d._e289e9bec5c9() for _d4d4e094a12d in _80f0c72e9dbc if _9ad36d8a7f25(_d4d4e094a12d, _cf315f7c3451) and _80fe5bf7ab45._568c520ab28a(_d4d4e094a12d)]
                _f74854753226._75a2232a3982(_5b41d5fdf325)

        _2aaddf3fd472 = {_17737da7d35b["lang_code"]: _ef6eabb71e22 for _ef6eabb71e22, _17737da7d35b in _ac477146e15b._baa61336564e()}

        for _9114dfb8ca04, _4e79d463e84d in _f74854753226._baa61336564e():
            _9114dfb8ca04 = _9114dfb8ca04._e289e9bec5c9()
            _49b441c760c2 = self._53195e088b5b._3bde8846f2d5(_9114dfb8ca04, [])
            _bf3a6ccba512 = _0bda4c04c3c2(_f1c83c55389d._3bde8846f2d5("samples_after_processing", 0) for _f1c83c55389d in _49b441c760c2)
            if _9114dfb8ca04 in _2aaddf3fd472:
                _c39774ae8bc6 = _2aaddf3fd472[_9114dfb8ca04]
                _95fbef65035d = _ac477146e15b[_c39774ae8bc6]
                _f21309a03f16 = _95fbef65035d["lang_files"] + _49b441c760c2
                _892e6f03b1d1 = _4dacef2e419f({_f1c83c55389d["file_name"]: _f1c83c55389d for _f1c83c55389d in _f21309a03f16}._128176debebf())
                _ac477146e15b[_c39774ae8bc6] = {
                    "lang_code": _9114dfb8ca04,
                    "lang_samples": _95fbef65035d["lang_samples"] + _bf3a6ccba512,
                    "lang_files": _892e6f03b1d1,
                }
            else:
                _ca4001efce69 = _1f39e1c175e6(_ac477146e15b)
                _ac477146e15b[_ca4001efce69] = {
                    "lang_code": _9114dfb8ca04,
                    "lang_samples": _bf3a6ccba512,
                    "lang_files": _49b441c760c2,
                }
                _2aaddf3fd472[_9114dfb8ca04] = _ca4001efce69

        return _ac477146e15b

    def _89f592fef77c(self, _ffcd2d9d7d42: _71de54aead0c[_035f39b8c016]) -> _003d33c0ae33._7fdbe4dbc28b:
        _23ae4cd90801 = _003d33c0ae33._0bda4c04c3c2(_ffcd2d9d7d42)
        return _ffcd2d9d7d42 / _23ae4cd90801 if _23ae4cd90801 != 0 else _003d33c0ae33._b577463af80a(_ffcd2d9d7d42)

    def _cd4fe4a815f5(self, _bcfd323926f7: _672dd349ec1b) -> _59262292ed8e[_71de54aead0c[_035f39b8c016], _672dd349ec1b]:
        _bf3a6ccba512 = _0bda4c04c3c2(_274dfaf022fd["lang_samples"] for _274dfaf022fd in _bcfd323926f7._128176debebf())
        for _b488deb0261e, _7b0cd35d7243 in _bcfd323926f7._baa61336564e():
            _1058cbfbcdfe = _7b0cd35d7243["lang_samples"]
            if _1058cbfbcdfe > 0:
                _162d6cd86be5 = _bf3a6ccba512 / (_1058cbfbcdfe * _1f39e1c175e6(_bcfd323926f7))
            else:
                _162d6cd86be5 = 0.0
            _bcfd323926f7[_b488deb0261e]["lang_weight"] = _162d6cd86be5
        _c2a46a6ce057 = [_274dfaf022fd["lang_weight"] for _274dfaf022fd in _bcfd323926f7._128176debebf()]
        # Update stored lang weights (keeps original behavior)
        for _99941260896c, (_b488deb0261e, _7b0cd35d7243) in _9de7f7ec7090(_bcfd323926f7._baa61336564e()):
            _7b0cd35d7243["lang_weight"] = _c2a46a6ce057[_99941260896c]
        return _c2a46a6ce057, _bcfd323926f7

    def _93ec3af8b3c5(self, _43bf47f6955f: _cf315f7c3451, _a970c90da6a9: _0f651b4cb428) -> _59262292ed8e[_672dd349ec1b, _672dd349ec1b]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _bcfd323926f7 = {}
        _c2a46a6ce057 = {}
        if os._a1bef626383d._d3c7812c04cf(_43bf47f6955f):
            with _3a1c8f7e5617(_43bf47f6955f, "r", _ed9a3e7e4187="utf8") as _6f5e16c94d14:
                _f8d8fc4d2057 = json._46db8794c11f(_6f5e16c94d14)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _bcfd323926f7 = {
                    (_035f39b8c016(_ef6eabb71e22) if "." in _ef6eabb71e22 else _697dcf680088(_ef6eabb71e22)): _17737da7d35b
                    for _ef6eabb71e22, _17737da7d35b in _f8d8fc4d2057._baa61336564e()
                }

        if _a970c90da6a9:
            _bcfd323926f7 = self._1cef994edd84(_ac477146e15b=_bcfd323926f7)
            _c2a46a6ce057, _bcfd323926f7 = self._ce03d2dc33ca(_bcfd323926f7=_bcfd323926f7)
            with _3a1c8f7e5617(_43bf47f6955f, "w", _ed9a3e7e4187="utf8") as _a8736528c64b:
                json._ddac065b3204(_bcfd323926f7, _a8736528c64b, _2871f0eaa749=2)

        return _bcfd323926f7, _c2a46a6ce057

    def _152baa1e9cd7(self) -> _71de54aead0c[_697dcf680088]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._e0f950489c16(_b488deb0261e) for _b488deb0261e in self._ed915d4ed750] if _5710b0a675b7(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _98fb5fa20fee(self, _c765e7c2552f: _035f39b8c016) -> _697dcf680088:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _697dcf680088(self._7af89ac4c85e * _c765e7c2552f)

    @_8b88772fc4e7
    def _5415762666af(_d89e60ec0434: _cf315f7c3451) -> _0f651b4cb428:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _9daa749023c1
        for _64f1245cf4f9 in _d89e60ec0434:
            if "ARABIC" not in _9daa749023c1._e450d5a24aa4(_64f1245cf4f9, ""):
                return _bc6b8a1e8217
        return _418d7f8287fb

    @_8b88772fc4e7
    def _8dfcc00251f9(_c4065e8af43c: _cf315f7c3451) -> _cf315f7c3451:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _131ad476148a._a0a5daa6379e(_c4065e8af43c):
            _3040aeec5694 = _c4065e8af43c._e289e9bec5c9()._405c382b5868()
            _4ed46b16edd1 = " "._d990887a70f2(_b47cdc7a8cf1(_3040aeec5694))
            return _4ed46b16edd1
        return _c4065e8af43c

    def _030b6497ea52(self, _a36593a4426a: _cf315f7c3451, _d2b9eb48cbd4: _cf315f7c3451) -> _035f39b8c016:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _3ff59629ff8d(_a4ed72919fbd, _a36593a4426a, _d2b9eb48cbd4)._334067f4cee0()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_8b88772fc4e7
    def _4d78e6e025e3(_e2b84434cd2f) -> _59262292ed8e[_71de54aead0c[_672dd349ec1b], _697dcf680088]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import time
        _d00d36d24030 = time.time()
        _b191834c376e, _7f6ff76fcf5f, _cc700a426c1b, _1429de15da46, _a970c90da6a9, _f84a1c8852e0 = _e2b84434cd2f
        _4d19f4b6daaf = _131ad476148a._888c9eb7aafc
        _d6bd16949c73 = 0
        _9580f7607e12 = _4d19f4b6daaf._8b6667f92fa4
        _af61a5d90697: _71de54aead0c[_672dd349ec1b] = []

        # Clean inputs and prepare per-word lists
        _f84acf0fea87 = [_a35bc086b2ae._e289e9bec5c9() for _a35bc086b2ae in _b191834c376e]
        _e6de6521c6ae = [_351212b2cc0d._e289e9bec5c9() for _351212b2cc0d in _7f6ff76fcf5f]
        _24fbcf78e79c = [_d89e60ec0434._405c382b5868() if _d89e60ec0434 else ["<empty>"] for _d89e60ec0434 in _f84acf0fea87]
        _62e7a4407cb5 = []
        for _b4e3ced9ee2a, _305334715db1 in _131a884417a5(_24fbcf78e79c, _7f6ff76fcf5f):
            _1a2421c8720c = _305334715db1 if _9ad36d8a7f25(_305334715db1, _4dacef2e419f) else (_305334715db1._e289e9bec5c9()._405c382b5868() if _305334715db1._e289e9bec5c9() else ["<empty>"])
            if _1f39e1c175e6(_1a2421c8720c) == 1:
                _1a2421c8720c = [_1a2421c8720c[0]] * _1f39e1c175e6(_b4e3ced9ee2a)
            elif _1f39e1c175e6(_1a2421c8720c) != _1f39e1c175e6(_b4e3ced9ee2a):
                _1a2421c8720c = _1a2421c8720c[:_1f39e1c175e6(_b4e3ced9ee2a)] if _1f39e1c175e6(_1a2421c8720c) > _1f39e1c175e6(_b4e3ced9ee2a) else _1a2421c8720c + [_1a2421c8720c[-1]] * (_1f39e1c175e6(_b4e3ced9ee2a) - _1f39e1c175e6(_1a2421c8720c))
            _62e7a4407cb5._0f653c953078(_1a2421c8720c)

        # Flatten all words for a single tokenizer call (faster)
        _1415f68af568 = _4dacef2e419f(_721ef1c67ccb(*_24fbcf78e79c))
        _1c321f91c7b3 = time.time()
        try:
            _89eed7d5df1b = _4d19f4b6daaf(_1415f68af568, _9f1c315c35b5=_bc6b8a1e8217, _27e32b4b2551=_bc6b8a1e8217, _adae80b4c16e=_bc6b8a1e8217)
        except _63908b8c95f8 as _d2099a4f1a12:
            _60f08312d7ce(f"Tokenization error: {_d2099a4f1a12}")
            _89eed7d5df1b = {"input_ids": [[0] for _ in _1415f68af568]}
        # build word token info per sentence
        _80609231bba5 = 0
        _6d88514ec738 = []
        for _b4e3ced9ee2a in _24fbcf78e79c:
            _42e3bbc21175 = _1f39e1c175e6(_b4e3ced9ee2a)
            _09192ad7be9e = [(_99941260896c, _89eed7d5df1b["input_ids"][_80609231bba5 + _99941260896c], _1f39e1c175e6(_89eed7d5df1b["input_ids"][_80609231bba5 + _99941260896c])) for _99941260896c in _c90b02a52c3a(_42e3bbc21175)]
            _6d88514ec738._0f653c953078(_09192ad7be9e)
            _80609231bba5 += _42e3bbc21175

        # chunk each sentence into token windows
        for _be5efdad2a48, (_b4e3ced9ee2a, _b37b49767d78, _1a2421c8720c) in _9de7f7ec7090(_131a884417a5(_24fbcf78e79c, _6d88514ec738, _62e7a4407cb5)):
            _816fd206d4f0 = _f84a1c8852e0 + _be5efdad2a48
            _0601408e0bde = 0
            if _b4e3ced9ee2a == ["<empty>"]:
                _7a78d6f0832b = [0] * _cc700a426c1b
                _af61a5d90697._0f653c953078({
                    "sample_id": _816fd206d4f0,
                    "chunk_id": _0601408e0bde,
                    "input_ids": _7a78d6f0832b,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _99941260896c = 0
            _789f87e072e7 = _1f39e1c175e6(_b37b49767d78)
            _0f1442571e45 = []
            while _99941260896c < _789f87e072e7:
                _aab0d5d62ca2 = 0
                _ef5326aec1ac = []
                _f5de6deafdcc = []
                _c8032e7030fd = []
                _b394f24f8b81 = _99941260896c
                while _b394f24f8b81 < _789f87e072e7:
                    _817b098ac4b0, _84b84aad08d5, _5c4f910bde0a = _b37b49767d78[_b394f24f8b81]
                    _71b81bdc1504 = _1a2421c8720c[_817b098ac4b0] if _817b098ac4b0 < _1f39e1c175e6(_1a2421c8720c) else _1a2421c8720c[-1] if _1a2421c8720c else "<unknown>"
                    if _5c4f910bde0a > _cc700a426c1b and not _ef5326aec1ac:
                        _ef5326aec1ac += _84b84aad08d5[:_cc700a426c1b]
                        _f5de6deafdcc._0f653c953078(_71b81bdc1504)
                        _c8032e7030fd._0f653c953078(_817b098ac4b0)
                        _b394f24f8b81 += 1
                        break
                    if _aab0d5d62ca2 + _5c4f910bde0a > _cc700a426c1b and _ef5326aec1ac:
                        break
                    _ef5326aec1ac += _84b84aad08d5
                    _f5de6deafdcc._0f653c953078(_71b81bdc1504)
                    _d6bd16949c73 += 1
                    _c8032e7030fd._0f653c953078(_b394f24f8b81)
                    _aab0d5d62ca2 += _5c4f910bde0a
                    _b394f24f8b81 += 1

                if not _ef5326aec1ac:
                    # fallback: take token prefix to avoid infinite loop
                    _ef5326aec1ac = _b37b49767d78[_99941260896c][1][:_cc700a426c1b] or [0]
                    _f5de6deafdcc = [_1a2421c8720c[_99941260896c] if _99941260896c < _1f39e1c175e6(_1a2421c8720c) else _1a2421c8720c[-1] if _1a2421c8720c else "<unknown>"]
                    _c8032e7030fd = [_99941260896c]
                    _d6bd16949c73 += 1
                    _99941260896c += 1

                # pad tokens to fixed length
                if _1f39e1c175e6(_ef5326aec1ac) < _cc700a426c1b:
                    _ef5326aec1ac += [_9580f7607e12] * (_cc700a426c1b - _1f39e1c175e6(_ef5326aec1ac))

                _0f1442571e45._0f653c953078({
                    "sample_id": _816fd206d4f0,
                    "chunk_id": _0601408e0bde,
                    "input_ids": _ef5326aec1ac,
                    "labels": _f5de6deafdcc,
                    "word_positions": _c8032e7030fd,
                    "num_chunks": 1
                })
                _0601408e0bde += 1

                if _b394f24f8b81 >= _789f87e072e7:
                    break

                # stride with overlap (in words)
                _b0e231fc7934 = _1f39e1c175e6(_c8032e7030fd)
                _007565b2b83f = _697dcf680088(_1429de15da46 * _b0e231fc7934)
                _007565b2b83f = _e6fcad63b0f8(_007565b2b83f, _b0e231fc7934 - 1) if _b0e231fc7934 > 1 else 0
                _2d66caa60097 = _b394f24f8b81 - _007565b2b83f
                if _2d66caa60097 <= _99941260896c:
                    _2d66caa60097 = _99941260896c + 1
                _99941260896c = _2d66caa60097

            _1385870d4d66 = _1f39e1c175e6(_0f1442571e45)
            for _c2df558f0cd6 in _0f1442571e45:
                _c2df558f0cd6["num_chunks"] = _1385870d4d66
            _af61a5d90697._e577d553bd5b(_0f1442571e45)

            if not _131ad476148a._5acde86f3764 and not _a970c90da6a9 and _1385870d4d66 > 1:
                _60f08312d7ce(f"[DEBUG] sample_id={_816fd206d4f0}", _1c612f0c7c72=_418d7f8287fb)
                _131ad476148a._5acde86f3764 = _418d7f8287fb

        # Timing/logging suppressed to preserve original behavior
        return _af61a5d90697, _d6bd16949c73

    @_8b88772fc4e7
    def _2d01aabc6bf1(_e2b84434cd2f) -> _59262292ed8e[_71de54aead0c[_672dd349ec1b], _697dcf680088]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import time
        _d00d36d24030 = time.time()
        (_6841017daf9b, _b191834c376e, _7f6ff76fcf5f, _cc700a426c1b, _1429de15da46, _305a0f5ea336, _f84a1c8852e0) = _e2b84434cd2f
        _4d19f4b6daaf = _131ad476148a._888c9eb7aafc
        _9580f7607e12 = _4d19f4b6daaf._8b6667f92fa4 or _4d19f4b6daaf._5bb41614358f
        _b34040aa1ab4 = _4d19f4b6daaf._5bb41614358f
        _050b4781d5ba = -100

        # Chat-ish prefixes used in dataset construction
        # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
        # "Identify the language of every word and reply with space-separated codes only.\n"
        # "Do not include any explanation or extra text.\n")
        # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _78dd7ceb06cf = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
        "Identify the language of every word and reply with space-separated codes only.\n"
        "Do not include any explanation or extra text.\n")
        _837086c0ac02 = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _f60f9dfebeb7 = _4d19f4b6daaf._b8dc4b54e389(_6841017daf9b, _9f1c315c35b5=_bc6b8a1e8217)
        _fb2a6a2eb552 = _4d19f4b6daaf._b8dc4b54e389(_78dd7ceb06cf, _9f1c315c35b5=_bc6b8a1e8217)
        _12c0670a9b43 = _4d19f4b6daaf._b8dc4b54e389(_837086c0ac02, _9f1c315c35b5=_bc6b8a1e8217)
        _7437a6d96084 = _4d19f4b6daaf._b8dc4b54e389(" ", _9f1c315c35b5=_bc6b8a1e8217)
        _c67707a60334 = _f60f9dfebeb7 + _fb2a6a2eb552
        _b9598011f654 = _12c0670a9b43
        _4eb37a8afc78 = 1
        _e20cdcb8148b = _1f39e1c175e6(_c67707a60334) + _1f39e1c175e6(_b9598011f654) + _4eb37a8afc78

        _af61a5d90697: _71de54aead0c[_672dd349ec1b] = []
        _d6bd16949c73 = 0

        # Preprocess lines into words lists and align labels to words
        _f84acf0fea87 = [_a35bc086b2ae._e289e9bec5c9() for _a35bc086b2ae in _b191834c376e]
        _e6de6521c6ae = [_351212b2cc0d._e289e9bec5c9() for _351212b2cc0d in _7f6ff76fcf5f]
        _24fbcf78e79c = []
        _6e51bbcf9b28 = []
        for _ba774c03ad0b, _305334715db1 in _131a884417a5(_f84acf0fea87, _7f6ff76fcf5f):
            _b4e3ced9ee2a = _ba774c03ad0b._405c382b5868() if _ba774c03ad0b else ["<empty>"]
            _6a034061b384 = _305334715db1 if _9ad36d8a7f25(_305334715db1, _4dacef2e419f) else (_305334715db1._e289e9bec5c9()._405c382b5868() if _305334715db1._e289e9bec5c9() else ["<empty>"])
            if _1f39e1c175e6(_6a034061b384) == 1:
                _6a034061b384 = [_6a034061b384[0]] * _1f39e1c175e6(_b4e3ced9ee2a)
            elif _1f39e1c175e6(_6a034061b384) != _1f39e1c175e6(_b4e3ced9ee2a):
                _6a034061b384 = _6a034061b384[:_1f39e1c175e6(_b4e3ced9ee2a)] if _1f39e1c175e6(_6a034061b384) > _1f39e1c175e6(_b4e3ced9ee2a) else _6a034061b384 + [_6a034061b384[-1]] * (_1f39e1c175e6(_b4e3ced9ee2a) - _1f39e1c175e6(_6a034061b384))
            _24fbcf78e79c._0f653c953078(_b4e3ced9ee2a)
            _6e51bbcf9b28._0f653c953078(_6a034061b384)

        # Flatten words for efficient tokenization
        _1415f68af568 = _4dacef2e419f(_721ef1c67ccb(*_24fbcf78e79c))
        _bc275e01fef9 = _4dacef2e419f(_721ef1c67ccb(*_6e51bbcf9b28))
        _7a241a012bb4 = _4d19f4b6daaf(_1415f68af568, _9f1c315c35b5=_bc6b8a1e8217, _27e32b4b2551=_bc6b8a1e8217)["input_ids"]
        _d78e88e1adb8 = _4d19f4b6daaf(_bc275e01fef9, _9f1c315c35b5=_bc6b8a1e8217, _27e32b4b2551=_bc6b8a1e8217)["input_ids"]

        # Build per-line token info
        _80609231bba5 = 0
        _f3d1914bf7d0 = 0
        _6d88514ec738 = []
        _a1b31aeaf00a = []
        for _b4e3ced9ee2a, _6a034061b384 in _131a884417a5(_24fbcf78e79c, _6e51bbcf9b28):
            _42e3bbc21175 = _1f39e1c175e6(_b4e3ced9ee2a)
            _c67644213b1d = _1f39e1c175e6(_6a034061b384)
            if _b4e3ced9ee2a == ["<empty>"] or _6a034061b384 == ["<empty>"]:
                _6d88514ec738._0f653c953078([(_b4e3ced9ee2a[0], [0], 1)])
                _a1b31aeaf00a._0f653c953078([(_6a034061b384[0], [0], 1)])
                continue
            try:
                _09192ad7be9e = [(_0d6ba7561aa4, _7a241a012bb4[_80609231bba5 + _99941260896c], _1f39e1c175e6(_7a241a012bb4[_80609231bba5 + _99941260896c]) if _9ad36d8a7f25(_7a241a012bb4[_80609231bba5 + _99941260896c], _4dacef2e419f) else 1) for _99941260896c, _0d6ba7561aa4 in _9de7f7ec7090(_b4e3ced9ee2a)]
                _754e5a4227d7 = [(_0d6ba7561aa4, _d78e88e1adb8[_f3d1914bf7d0 + _99941260896c], _1f39e1c175e6(_d78e88e1adb8[_f3d1914bf7d0 + _99941260896c]) if _9ad36d8a7f25(_d78e88e1adb8[_f3d1914bf7d0 + _99941260896c], _4dacef2e419f) else 1) for _99941260896c, _0d6ba7561aa4 in _9de7f7ec7090(_6a034061b384)]
            except _32e95fc5bf04:
                # On tokenization mismatches, fallback safely
                _6d88514ec738._0f653c953078([(_b4e3ced9ee2a[0], [0], 1)])
                _a1b31aeaf00a._0f653c953078([(_6a034061b384[0], [0], 1)])
                _80609231bba5 += _42e3bbc21175
                _f3d1914bf7d0 += _c67644213b1d
                continue
            _6d88514ec738._0f653c953078(_09192ad7be9e)
            _a1b31aeaf00a._0f653c953078(_754e5a4227d7)
            _80609231bba5 += _42e3bbc21175
            _f3d1914bf7d0 += _c67644213b1d

        # Build chunks per sentence
        for _be5efdad2a48, (_b4e3ced9ee2a, _b37b49767d78, _41af48b308b0) in _9de7f7ec7090(_131a884417a5(_24fbcf78e79c, _6d88514ec738, _a1b31aeaf00a)):
            _816fd206d4f0 = _f84a1c8852e0 + _be5efdad2a48
            _0601408e0bde = 0
            _4d3e76e017b5 = [_7bc40f5127fe[0] for _7bc40f5127fe in _41af48b308b0]

            if _b4e3ced9ee2a == ["<empty>"]:
                _7a78d6f0832b = _c67707a60334 + [0] + _b9598011f654 + [_b34040aa1ab4]
                _80f0c72e9dbc = [_050b4781d5ba] * _1f39e1c175e6(_7a78d6f0832b)
                _aefab6286400 = _cc700a426c1b - _1f39e1c175e6(_7a78d6f0832b)
                if _aefab6286400 > 0:
                    _7a78d6f0832b += [_9580f7607e12] * _aefab6286400
                    _80f0c72e9dbc += [_050b4781d5ba] * _aefab6286400
                _af61a5d90697._0f653c953078({
                    "lang_codes": ["<empty>"],
                    "sample_id": _816fd206d4f0,
                    "chunk_id": _0601408e0bde,
                    "word_positions": [0],
                    "input_ids": _7a78d6f0832b,
                    "labels": _80f0c72e9dbc,
                    "prompt_len": _1f39e1c175e6(_c67707a60334) + 1 + _1f39e1c175e6(_b9598011f654),
                    "chunk_words": ["<empty>"],
                    "chunk_labels": ["<empty>"],
                    "num_chunks": 1
                })
                continue

            _99941260896c = 0
            _789f87e072e7 = _1f39e1c175e6(_b37b49767d78)
            _e1b6888067a0 = -1
            _0f1442571e45 = []
            while _99941260896c < _789f87e072e7:
                _aab0d5d62ca2 = _e20cdcb8148b
                _6560e3be930b = []
                _17ef62764662 = []
                _c8032e7030fd = []
                _68034115b1a3 = []
                _e5100ef3468b = []
                _f5de6deafdcc = []
                _b394f24f8b81 = _99941260896c
                while _b394f24f8b81 < _789f87e072e7:
                    _, _f3bc022f675a, _42e3bbc21175 = _b37b49767d78[_b394f24f8b81]
                    _79b2f14ba33c, _a099852c9ee9, _c67644213b1d = _41af48b308b0[_b394f24f8b81]
                    _d3181b3c0be4 = _1f39e1c175e6(_7437a6d96084) if _b394f24f8b81 < _789f87e072e7 - 1 else 0
                    # choose conservative word_total so both streams fit
                    _bdd00d3df567 = _b25187b37f0e(_42e3bbc21175, _c67644213b1d) + _d3181b3c0be4
                    if _aab0d5d62ca2 + _bdd00d3df567 > _cc700a426c1b * 0.9:
                        break

                    # append inputs and spaces
                    _6560e3be930b += _f3bc022f675a if _9ad36d8a7f25(_f3bc022f675a, _4dacef2e419f) else [_f3bc022f675a]
                    if _d3181b3c0be4:
                        _6560e3be930b += _7437a6d96084

                    # append labels and word_positions
                    if _c67644213b1d:
                        _17ef62764662 += _a099852c9ee9 if _9ad36d8a7f25(_a099852c9ee9, _4dacef2e419f) else [_a099852c9ee9]
                        _c8032e7030fd += [_b394f24f8b81] * _c67644213b1d
                    if _d3181b3c0be4:
                        _17ef62764662 += _7437a6d96084
                        _c8032e7030fd += [-1] * _d3181b3c0be4

                    _68034115b1a3._0f653c953078(_79b2f14ba33c)
                    _e5100ef3468b._0f653c953078(_b4e3ced9ee2a[_b394f24f8b81])
                    _f5de6deafdcc._0f653c953078(_79b2f14ba33c)
                    _d6bd16949c73 += _1f39e1c175e6(_b4e3ced9ee2a[_b394f24f8b81])
                    _aab0d5d62ca2 += _bdd00d3df567
                    _b394f24f8b81 += 1

                if not _6560e3be930b:
                    _99941260896c += 1
                    continue

                _2c0efcb0a158 = _6560e3be930b
                _62400bd35912 = _17ef62764662
                _e6d1b201fdbc = _1f39e1c175e6(_c67707a60334) + _1f39e1c175e6(_2c0efcb0a158) + _1f39e1c175e6(_b9598011f654)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                if _305a0f5ea336 is _bc6b8a1e8217:
                    _7a78d6f0832b = _c67707a60334 + _2c0efcb0a158 + _b9598011f654 + _62400bd35912 + [_b34040aa1ab4]
                    _80f0c72e9dbc = [_050b4781d5ba] * _e6d1b201fdbc + _62400bd35912 + [_050b4781d5ba]
                else:
                    _7a78d6f0832b = _c67707a60334 + _2c0efcb0a158 + _b9598011f654 + [_b34040aa1ab4]
                    _80f0c72e9dbc = [_050b4781d5ba] * _e6d1b201fdbc + _62400bd35912 + [_050b4781d5ba]

                # pad to fixed size (inputs appended or prepended depending on test/train)
                _918da320f53a = _cc700a426c1b - _1f39e1c175e6(_7a78d6f0832b)
                _6de33a7f4415 = _cc700a426c1b - _1f39e1c175e6(_80f0c72e9dbc)
                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len
                if _918da320f53a > 0:
                    if _305a0f5ea336:
                        _7a78d6f0832b = [_9580f7607e12] * _918da320f53a + _7a78d6f0832b
                    else:
                        _7a78d6f0832b += [_9580f7607e12] * _918da320f53a
                if _6de33a7f4415 > 0:
                    if _305a0f5ea336:
                        _80f0c72e9dbc = [_050b4781d5ba] * _6de33a7f4415 + _80f0c72e9dbc
                    else:
                        _80f0c72e9dbc += [_050b4781d5ba] * _6de33a7f4415

                _0f1442571e45._0f653c953078({
                    "lang_codes": _68034115b1a3,
                    "sample_id": _816fd206d4f0,
                    "chunk_id": _0601408e0bde,
                    "word_positions": _c8032e7030fd,
                    "input_ids": _7a78d6f0832b,
                    "labels": _80f0c72e9dbc,
                    "prompt_len": _e6d1b201fdbc,
                    "chunk_words": _e5100ef3468b,
                    "chunk_labels": _f5de6deafdcc,
                    "num_chunks": 1
                })
                _0601408e0bde += 1

                if _b394f24f8b81 >= _789f87e072e7 or _b394f24f8b81 <= _e1b6888067a0:
                    break
                _e1b6888067a0 = _b394f24f8b81
                _0018331c8eab = _b25187b37f0e(1, _697dcf680088(_1429de15da46 * _1f39e1c175e6(_e5100ef3468b)))
                _99941260896c = _b394f24f8b81 - _0018331c8eab if (_b394f24f8b81 - _0018331c8eab) > _99941260896c else _b394f24f8b81

            _1385870d4d66 = _1f39e1c175e6(_0f1442571e45)
            for _c2df558f0cd6 in _0f1442571e45:
                _c2df558f0cd6["num_chunks"] = _1385870d4d66
            _af61a5d90697._e577d553bd5b(_0f1442571e45)

            if not _131ad476148a._5acde86f3764 and not _305a0f5ea336 and _1385870d4d66 > 1:
                _131ad476148a._5acde86f3764 = _418d7f8287fb

        return _af61a5d90697, _d6bd16949c73

    # -------------------------
    # File processing & validation
    # -------------------------
    def _6f96adc27df0(self, _9a8e30c63dc4: _cf315f7c3451, _bc2aeb2b2b96: _cf315f7c3451, _f84a1c8852e0: _697dcf680088) -> _59262292ed8e[_cf315f7c3451, _71de54aead0c[_672dd349ec1b], _697dcf680088]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _14b837291a2a = []

        with _3a1c8f7e5617(_9a8e30c63dc4, "r", _ed9a3e7e4187="utf8") as _2ab7fa8b88ee, _3a1c8f7e5617(_bc2aeb2b2b96, "r", _ed9a3e7e4187="utf8") as _5fe2ebcd6cb5:
            _b191834c376e = _2ab7fa8b88ee._d17f1ab68f3d()[1:] if self._421a88df6a79 else _2ab7fa8b88ee._d17f1ab68f3d()
            _7f6ff76fcf5f = _5fe2ebcd6cb5._d17f1ab68f3d()[1:] if self._421a88df6a79 else _5fe2ebcd6cb5._d17f1ab68f3d()

        # sample some share if requested
        _0fe614196ae2 = _697dcf680088(_1f39e1c175e6(_b191834c376e) * self._6c15af75ee49)
        if _0fe614196ae2 < _1f39e1c175e6(_b191834c376e):
            _eb53a0256d44 = _003d33c0ae33.random._005a77946abd(_1f39e1c175e6(_b191834c376e), _0fe614196ae2, _97fda2b61661=_bc6b8a1e8217)
            _b191834c376e = [_b191834c376e[_99941260896c] for _99941260896c in _eb53a0256d44]
            _7f6ff76fcf5f = [_7f6ff76fcf5f[_99941260896c] for _99941260896c in _eb53a0256d44]

        _b488deb0261e = _4dacef2e419f({_351212b2cc0d._e289e9bec5c9() for _351212b2cc0d in _7f6ff76fcf5f})[0] if _7f6ff76fcf5f else "unk"
        self._e8d42f1fd0cb._7bc40f5127fe(f"Sampled {self._6c15af75ee49 * 100:.1f}% of {_9a8e30c63dc4}: {_1f39e1c175e6(_b191834c376e)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _c7729184bd30(_564805c33984, _77621c95495d):
            _e56327db6e5c = _a4769e5cc8ac(_564805c33984)
            while _418d7f8287fb:
                _552d511b3634 = _4dacef2e419f(_bf50dc7d3258(_e56327db6e5c, _77621c95495d))
                if not _552d511b3634:
                    break
                yield _552d511b3634

        _77621c95495d = 10_000
        if self._18a6602a5311:
            _c3281330dbaf = [
                (self._6841017daf9b, _1b96d9a04571, _13509f1c0d0c, self._7af89ac4c85e, 0.25, self._305a0f5ea336, _f84a1c8852e0 + _890ccc2c3e8e * _77621c95495d)
                for _890ccc2c3e8e, (_1b96d9a04571, _13509f1c0d0c) in _9de7f7ec7090(_131a884417a5(_8f6ca40cdd11(_b191834c376e, _77621c95495d), _8f6ca40cdd11(_7f6ff76fcf5f, _77621c95495d)))
            ]
            with _6915f6e4bd8a(self._04446ba3dc95) as _54d4bc969956:
                _92e586bc604a = _54d4bc969956._6298b948b527(_131ad476148a._d649a7989b36, _c3281330dbaf)
        else:
            _c3281330dbaf = [
                (_1b96d9a04571, _13509f1c0d0c, self._7af89ac4c85e, 0.5, self._a970c90da6a9, _f84a1c8852e0 + _890ccc2c3e8e * _77621c95495d)
                for _890ccc2c3e8e, (_1b96d9a04571, _13509f1c0d0c) in _9de7f7ec7090(_131a884417a5(_8f6ca40cdd11(_b191834c376e, _77621c95495d), _8f6ca40cdd11(_7f6ff76fcf5f, _77621c95495d)))
            ]
            with _6915f6e4bd8a(self._04446ba3dc95) as _54d4bc969956:
                _92e586bc604a = _54d4bc969956._6298b948b527(_131ad476148a._e361e0b61e53, _c3281330dbaf)

        _6d00054f49e4 = []
        for _af61a5d90697, _aef16346df45 in _92e586bc604a:
            _6d00054f49e4._e577d553bd5b(_af61a5d90697)
            self._333e6e3d8200 += _aef16346df45

        if _6d00054f49e4:
            _14b837291a2a = _6d00054f49e4

        return _b488deb0261e, _14b837291a2a, _1f39e1c175e6(_b191834c376e)

    def _3ded87617592(self) -> _a4ed72919fbd:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _9bfd63fa3c83 = 0

        for _cdc869dffab7 in os._515843ca1744(self._dc7aa740583e):
            self._e8d42f1fd0cb._7bc40f5127fe(f"Now processing {os._a1bef626383d._d990887a70f2(self._dc7aa740583e, _cdc869dffab7)} directory.")
            _f2afaf84eca0 = os._a1bef626383d._d990887a70f2(self._dc7aa740583e, _cdc869dffab7, "src")
            _7cdfc17eebe5 = os._a1bef626383d._d990887a70f2(self._dc7aa740583e, _cdc869dffab7, "tgt")

            _9a21a2538a82 = []
            _4e4e4e53acaf = []
            for _9a8e30c63dc4 in os._515843ca1744(_f2afaf84eca0):
                _45326fe78bd5 = _bc6b8a1e8217
                for _bc2aeb2b2b96 in os._515843ca1744(_7cdfc17eebe5):
                    if _9a8e30c63dc4._405c382b5868(".")[0] == _bc2aeb2b2b96._405c382b5868(".")[0]:
                        _9a21a2538a82._0f653c953078(_9a8e30c63dc4)
                        _4e4e4e53acaf._0f653c953078(_bc2aeb2b2b96)
                        _45326fe78bd5 = _418d7f8287fb
                        break
                if not _45326fe78bd5:
                    self._e8d42f1fd0cb._7bc40f5127fe(f"Skipping file {_9a8e30c63dc4} since matching label file not found in {_7cdfc17eebe5}.")

            _80e8d7783dac = [os._a1bef626383d._d990887a70f2(_f2afaf84eca0, _f1c83c55389d) for _f1c83c55389d in _9a21a2538a82 if os._a1bef626383d._b17ec3f9c239(os._a1bef626383d._d990887a70f2(_f2afaf84eca0, _f1c83c55389d))]
            _13df13c86d05 = [os._a1bef626383d._d990887a70f2(_7cdfc17eebe5, _f1c83c55389d) for _f1c83c55389d in _4e4e4e53acaf if os._a1bef626383d._b17ec3f9c239(os._a1bef626383d._d990887a70f2(_7cdfc17eebe5, _f1c83c55389d))]

            if _1f39e1c175e6(_80e8d7783dac) != _1f39e1c175e6(_13df13c86d05):
                raise _f1f4436c232b(f"Number of files in {_f2afaf84eca0} ({_1f39e1c175e6(_80e8d7783dac)}) does not match {_7cdfc17eebe5} ({_1f39e1c175e6(_13df13c86d05)})")

            for _9a8e30c63dc4, _bc2aeb2b2b96 in _131a884417a5(_80e8d7783dac, _13df13c86d05):
                _0d528fe27389 = _0bda4c04c3c2(1 for _ in _3a1c8f7e5617(_9a8e30c63dc4))
                _9911ac03b133 = _0bda4c04c3c2(1 for _ in _3a1c8f7e5617(_bc2aeb2b2b96))
                _0d528fe27389 = _0d528fe27389 - 1 if self._421a88df6a79 else _0d528fe27389
                _9911ac03b133 = _9911ac03b133 - 1 if self._421a88df6a79 else _9911ac03b133

                if _0d528fe27389 != _9911ac03b133:
                    self._e8d42f1fd0cb._7bc40f5127fe(f"{_0d528fe27389} lines in {_9a8e30c63dc4} do not match with {_9911ac03b133} in {_bc2aeb2b2b96}, skipping these files")
                    continue

                self._e8d42f1fd0cb._7bc40f5127fe(f"Processing {_9a8e30c63dc4} and {_bc2aeb2b2b96} with {_9911ac03b133} samples.")
                _b488deb0261e, _7fe009b433ed, _84f07f70d050 = self._bb5b70d7a883(_9a8e30c63dc4, _bc2aeb2b2b96, _f84a1c8852e0=_9bfd63fa3c83)
                _9bfd63fa3c83 += _84f07f70d050

                self._7fe009b433ed._e577d553bd5b(_7fe009b433ed)
                if self._a970c90da6a9:
                    if _b488deb0261e not in self._53195e088b5b:
                        self._53195e088b5b._75a2232a3982({
                            _b488deb0261e: [{
                                "file_name": os._a1bef626383d._c0fe2419b9a0(_bc2aeb2b2b96),
                                "samples_before_processing": _9911ac03b133,
                                "samples_after_processing": _1f39e1c175e6(_7fe009b433ed)
                            }]
                        })
                    else:
                        self._53195e088b5b[_b488deb0261e]._0f653c953078({
                            "file_name": os._a1bef626383d._c0fe2419b9a0(_bc2aeb2b2b96),
                            "samples_before_processing": _9911ac03b133,
                            "samples_after_processing": _1f39e1c175e6(_7fe009b433ed)
                        })
                self._e8d42f1fd0cb._7bc40f5127fe(f"Files {_9a8e30c63dc4} and {_bc2aeb2b2b96} have {_1f39e1c175e6(_7fe009b433ed)} samples after processing.")

        # verify dataset integrity
        self._29129e1b4d26()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _2ebbd06965cd(self) -> _a4ed72919fbd:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _ff1b8fc26b45 = self._7fe009b433ed
        if not _ff1b8fc26b45:
            self._e8d42f1fd0cb._7bc40f5127fe("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _3f626f0443dd = [_e820f2af73aa["sample_id"] for _e820f2af73aa in _ff1b8fc26b45]
        _5cf34fa17c7d = _040cc7d94ea2(_3f626f0443dd)
        _318906f5f4a4 = _b25187b37f0e(_5cf34fa17c7d)
        _d7f31a1d67f7 = (_1f39e1c175e6(_5cf34fa17c7d) == _318906f5f4a4 + 1)
        self._e8d42f1fd0cb._7bc40f5127fe(f"[sample_id] unique={_1f39e1c175e6(_5cf34fa17c7d)} max={_318906f5f4a4} coverage_ok={_d7f31a1d67f7} (expect True)")
        if not _d7f31a1d67f7:
            _5dc6c2b0d8b3 = _8337b6d3f36d(_040cc7d94ea2(_c90b02a52c3a(_318906f5f4a4 + 1)) - _5cf34fa17c7d)
            self._e8d42f1fd0cb._7bc40f5127fe(f" Missing sample_ids: {_5dc6c2b0d8b3[:20]}{' ...' if _1f39e1c175e6(_5dc6c2b0d8b3) > 20 else ''}")
            raise _f1f4436c232b(f"Increase max_seq_len as missing sample_ids detected: {_5dc6c2b0d8b3[:20]}{' ...' if _1f39e1c175e6(_5dc6c2b0d8b3) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _70b083ce7b67 = [(_e820f2af73aa["sample_id"], _e820f2af73aa["chunk_id"]) for _e820f2af73aa in _ff1b8fc26b45]
        _6c4f2a54ae79 = [_ef6eabb71e22 for _ef6eabb71e22, _17737da7d35b in _2e6e6938ff64(_70b083ce7b67)._baa61336564e() if _17737da7d35b > 1]
        self._e8d42f1fd0cb._7bc40f5127fe(f"[(sample_id,chunk_id)] duplicates: {_1f39e1c175e6(_6c4f2a54ae79)} (expect 0)")
        if _6c4f2a54ae79:
            self._e8d42f1fd0cb._7bc40f5127fe(f" Examples: {_6c4f2a54ae79[:10]}")
            raise _f1f4436c232b(f"Duplicate (sample_id, chunk_id) pairs detected: {_6c4f2a54ae79[:10]}")

        # 3) per-sample chunk_id sequentiality
        _8c447b2ae6aa = _9a619ef54ff5(_4dacef2e419f)
        for _e820f2af73aa in _ff1b8fc26b45:
            _8c447b2ae6aa[_e820f2af73aa["sample_id"]]._0f653c953078(_e820f2af73aa["chunk_id"])
        _b4b23cc050ce = {}
        for _0e10e7e92769, _84b84aad08d5 in _8c447b2ae6aa._baa61336564e():
            _7e1306561b48 = _8337b6d3f36d(_84b84aad08d5)
            _90ff969d7029 = _4dacef2e419f(_c90b02a52c3a(_1f39e1c175e6(_7e1306561b48)))
            if _7e1306561b48 != _90ff969d7029:
                _b4b23cc050ce[_0e10e7e92769] = {"have": _7e1306561b48[:20], "expected_prefix": _90ff969d7029[:20]}
        self._e8d42f1fd0cb._7bc40f5127fe(f"[per-sample chunk_id sequence] bad_samples: {_1f39e1c175e6(_b4b23cc050ce)} (expect 0)")
        if _b4b23cc050ce:
            _32c1b7940e4a = _4dacef2e419f(_b4b23cc050ce._baa61336564e())[:5]
            for _0e10e7e92769, _7bc40f5127fe in _32c1b7940e4a:
                self._e8d42f1fd0cb._7bc40f5127fe(f" sample_id={_0e10e7e92769} have={_7bc40f5127fe['have']} expected_prefix={_7bc40f5127fe['expected_prefix']}")
            raise _f1f4436c232b(f"Non-sequential chunk_id sequences detected for sample_ids: {_4dacef2e419f(_b4b23cc050ce._a2d2f58052a5())[:5]}")

        # 4) overall stats reporting
        _42340daa2f58 = _1f39e1c175e6(_5cf34fa17c7d)
        _ccb1875a93fb = _1f39e1c175e6(_ff1b8fc26b45)
        _563b98996973 = _ccb1875a93fb / _42340daa2f58 if _42340daa2f58 > 0 else 0
        self._e8d42f1fd0cb._7bc40f5127fe(f"[audit] base={_42340daa2f58} -> chunks={_ccb1875a93fb} (avg {_563b98996973:.2f} per sample)")

    @_039708f51f85
    def _5f1c90cd5112(self) -> _697dcf680088:
        """Return number of unique base samples (unique sample_id)."""
        if not _883e8b2bbdab(self, "file_data_dict_list", _a4ed72919fbd):
            return 0
        return _1f39e1c175e6({_697dcf680088(_274dfaf022fd["sample_id"]) for _274dfaf022fd in self._7fe009b433ed})

    @_039708f51f85
    def _b35d2d2dda29(self) -> _697dcf680088:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _883e8b2bbdab(self, "file_data_dict_list", _a4ed72919fbd):
            return 0

        _46e09dd68238 = _9a619ef54ff5(_040cc7d94ea2)
        for _274dfaf022fd in self._7fe009b433ed:
            _0e10e7e92769 = _697dcf680088(_274dfaf022fd._3bde8846f2d5("sample_id", -1))
            for _5be079f2a769 in _274dfaf022fd._3bde8846f2d5("word_positions", []):
                try:
                    _e2785bb1e6aa = _697dcf680088(_5be079f2a769)
                except _63908b8c95f8:
                    continue
                if _e2785bb1e6aa >= 0:
                    _46e09dd68238[_0e10e7e92769]._adfb6530d16c(_e2785bb1e6aa)

        return _0bda4c04c3c2(_1f39e1c175e6(_e1e3716b9374) for _e1e3716b9374 in _46e09dd68238._128176debebf())
