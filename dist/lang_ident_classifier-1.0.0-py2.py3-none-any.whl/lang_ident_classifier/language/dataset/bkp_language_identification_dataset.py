# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
import json
import random
import re
from itertools import _9d7f086ec8a4, _640a08ab21e4
from collections import _b0e7ccab13ed, _7504ba34a34e
from _afeedc1c9931 import _bd0558746853
from _8ef20661521f._f9e375df8ee3 import _f3ab52e1b5ad
from typing import _1fd8572e744b, _4e89cfc939b4, _7d4432a280af

import _356ffc7a49c8 as _f835768c4ce1
import _893bd43b7dd3
from _893bd43b7dd3._faa4c6c1ddc1._36438751ffcf import _358625b2a245
from _05a707bcadc8 import _20185751082f


class _be581cbe73c5(_358625b2a245):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _1e454eb8c387 = _831a8983adbc  # class-level tokenizer (set on __init__)
    _d11380cc7652 = _32969177bf07

    def _d890a311d56d(
        self,
        _ab929f62e4be: _6a045dfa1c63,
        _0789f981932a: _6a1c86a84495,
        _9d7c2976c674: _1fd8572e744b,
        _b8b469e4ffce: _3a9c0010a6dd,
        _0659c0c0d365: _6a045dfa1c63,
        _d3ff3966ef41: _20185751082f,
        _af839d832896: _6a1c86a84495,
        _d7e3544f8532: _6a1c86a84495,
        _f5f947b79f45: _891084678fda = 1.0,
        _54a0785055a1: _3a9c0010a6dd = 2,
        _3ccc522e99bd: _3a9c0010a6dd = 20,
        _a38ab8e668ff: _6a1c86a84495 = _32969177bf07,
        _e3ce1002623f: _6a045dfa1c63 = _831a8983adbc,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _a35ab9338237()._4a1873faf9b4()

        # Deterministic behavior
        _893bd43b7dd3._e8813ea12c8c(_3ccc522e99bd)
        if _893bd43b7dd3._437484f4dce3._4dd0a7c4f068():
            _893bd43b7dd3._437484f4dce3._4d8ebe4b9469(_3ccc522e99bd)
        random._8102deb1bde2(_3ccc522e99bd)
        _f835768c4ce1.random._8102deb1bde2(_3ccc522e99bd)

        # Basic parameters & bookkeeping
        self._d3ff3966ef41 = _d3ff3966ef41
        self._af839d832896 = _af839d832896
        self._d7e3544f8532 = _d7e3544f8532
        self._a38ab8e668ff = _a38ab8e668ff
        self._e3ce1002623f = _e3ce1002623f
        self._0789f981932a = _0789f981932a
        self._ab929f62e4be = _ab929f62e4be
        self._b8b469e4ffce = _b8b469e4ffce
        self._c26d10bb032f = 0
        self._f5f947b79f45 = _f5f947b79f45
        self._54a0785055a1 = _54a0785055a1
        self._000240dc19d5 = -100

        # Tokenizer handling
        _b4259c8cdaf7._1e454eb8c387 = _9d7c2976c674
        self._2da4f27c8795 = _9d7c2976c674
        if self._a38ab8e668ff:
            # preserve earlier code's fallback pad id (kept intentionally)
            if not self._2da4f27c8795._53b89241b3bf:
                self._2da4f27c8795._53b89241b3bf = 128004

        # storage filled by _validate_and_load_file_data
        self._1f0c46ce9fb0: _4e89cfc939b4[_148ffac03632] = []
        self._b318b0363241 = {}

        # Load and process files; then derive classes/weights
        self._9baf605575ea()
        self._c69977fc8192, self._ca1024d0ea4f = self._83c50bc9fc3e(_0659c0c0d365, _af839d832896)

    def _026053e9d8f0(self) -> _3a9c0010a6dd:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _2ec55714df51(self._1f0c46ce9fb0)

    def _8b6d29738897(self, _0c83430f2aab: _3a9c0010a6dd) -> _148ffac03632:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _c89f1176a846 = self._1f0c46ce9fb0[_0c83430f2aab]
        _993168388055 = _c89f1176a846._d953a726bc4f("lang_code", "unk")
        _48816479f7fe = _c89f1176a846["input_ids"]
        _c2e3c54e8438 = _c89f1176a846["labels"]
        _b306e1fc314b = _c89f1176a846._d953a726bc4f("word_positions", [])
        _79a5dbd720b0 = _c89f1176a846["num_chunks"]
        _29e4b5244ba0 = _c89f1176a846._d953a726bc4f("sample_id", _0c83430f2aab)
        _41b31db0ccd9 = _c89f1176a846._d953a726bc4f("chunk_id", 0)
        _953d6591cc39 = _c89f1176a846._d953a726bc4f("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _c2e3c54e8438 = [
            self._000240dc19d5
            if _a3329c6ad33b is _831a8983adbc
            else _3a9c0010a6dd(_a3329c6ad33b) if _f1f80895f41d(_a3329c6ad33b, _6a045dfa1c63) and _a3329c6ad33b._677f5cb458b1("-")._55582267dd89()
            else _a3329c6ad33b
            for _a3329c6ad33b in _c2e3c54e8438
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._a38ab8e668ff:
            _1ae26134982f = [
                self._a413acbc2729(_a3329c6ad33b) if _f1f80895f41d(_a3329c6ad33b, _6a045dfa1c63) else _a3329c6ad33b
                for _a3329c6ad33b in _c2e3c54e8438
            ]
            _6c32da232e27 = _2ec55714df51(_1ae26134982f)
            _cb9d99e9bc80 = _97460a09739e(0, self._b8b469e4ffce - _6c32da232e27)
            _1ae26134982f = _1ae26134982f + [self._000240dc19d5] * _cb9d99e9bc80
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _1ae26134982f = _c2e3c54e8438

        return {
            "lang_code": _993168388055,
            "input_ids": _893bd43b7dd3._081d4adc16c3(_48816479f7fe, _a2872e3b3ec1=_893bd43b7dd3._bae05fae9aa9),
            "labels": _893bd43b7dd3._081d4adc16c3(_1ae26134982f, _a2872e3b3ec1=_893bd43b7dd3._bae05fae9aa9),
            "sample_id": _29e4b5244ba0,
            "chunk_id": _41b31db0ccd9,
            "word_positions": _b306e1fc314b,
            "prompt_len": _953d6591cc39,
            "num_chunks": _79a5dbd720b0,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _b89f4f9e5d7e(self, _993168388055: _6a045dfa1c63) -> _3a9c0010a6dd:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _2f7192f7e13a, _9cea296ebc87 in self._c69977fc8192._9bac9a49b29b():
            if _9cea296ebc87["lang_code"] == _6a045dfa1c63(_993168388055)._515fa058eee3():
                return _2f7192f7e13a
        return self._c69977fc8192._d953a726bc4f("unk", {})._d953a726bc4f("id", -1)

    def _871dad8d1f63(self, _b4ec01f3f2a3: _3a9c0010a6dd) -> _6a045dfa1c63:
        """Reverse mapping; assumes class_id present."""
        return self._c69977fc8192[_b4ec01f3f2a3]["lang_code"]

    def _9cdbe6b296f2(self) -> _3a9c0010a6dd:
        return _2ec55714df51(self._c69977fc8192)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _e3c1d560b68e(self, _5c7b5af5575f: _148ffac03632) -> _148ffac03632:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _6c3e191fe83b = re._beb3c6e0d76c(r"[^\d\s]+")  # tokens with non-digit characters
        _1c5ab8a16bb3 = _b0e7ccab13ed()

        if self._a38ab8e668ff:
            _c0c58e53ca5f = []
            for _5bbe69405b0f in self._1f0c46ce9fb0:
                _1c8db79b660e = _5bbe69405b0f._d953a726bc4f("labels", []) if _f1f80895f41d(_5bbe69405b0f, _148ffac03632) else (_5bbe69405b0f[1] if _f1f80895f41d(_5bbe69405b0f, _a7f4c6550249) and _2ec55714df51(_5bbe69405b0f) > 1 else [])
                _4f314e7cc872 = [_90f63e501f7e for _90f63e501f7e in _1c8db79b660e if _90f63e501f7e != self._000240dc19d5]
                if _4f314e7cc872:
                    _c0c58e53ca5f._9ed62860ee14(_4f314e7cc872)
            if _c0c58e53ca5f:
                _3d24fed21027 = self._2da4f27c8795._d4d0828ab5f6(_c0c58e53ca5f, _93ab399b812d=_c3c940047ffc)
                for _629bf3c2714d in _3d24fed21027:
                    _9226a88800f5 = _6c3e191fe83b._3904046ad8de(_629bf3c2714d)
                    _1c5ab8a16bb3._123d0d08c8f1(_9226a88800f5)
        else:
            for _5bbe69405b0f in self._1f0c46ce9fb0:
                _1c8db79b660e = _5bbe69405b0f._d953a726bc4f("labels", [])
                _9226a88800f5 = [_06eada108033._515fa058eee3() for _06eada108033 in _1c8db79b660e if _f1f80895f41d(_06eada108033, _6a045dfa1c63) and _6c3e191fe83b._36f3ab467cc6(_06eada108033)]
                _1c5ab8a16bb3._123d0d08c8f1(_9226a88800f5)

        _c36b515aeec1 = {_d692b9eb6944["lang_code"]: _457a2e0ccdf8 for _457a2e0ccdf8, _d692b9eb6944 in _5c7b5af5575f._9bac9a49b29b()}

        for _be65b5d74ae4, _611b6056991d in _1c5ab8a16bb3._9bac9a49b29b():
            _be65b5d74ae4 = _be65b5d74ae4._515fa058eee3()
            _7075fc43bc5f = self._b318b0363241._d953a726bc4f(_be65b5d74ae4, [])
            _e33258c8a949 = _ba285fed62aa(_e7b8dd48e8aa._d953a726bc4f("samples_after_processing", 0) for _e7b8dd48e8aa in _7075fc43bc5f)
            if _be65b5d74ae4 in _c36b515aeec1:
                _0c83430f2aab = _c36b515aeec1[_be65b5d74ae4]
                _f4066357453a = _5c7b5af5575f[_0c83430f2aab]
                _b3df7dc7a583 = _f4066357453a["lang_files"] + _7075fc43bc5f
                _5870b74d8ddb = _78e899ca6a41({_e7b8dd48e8aa["file_name"]: _e7b8dd48e8aa for _e7b8dd48e8aa in _b3df7dc7a583}._39a94c906a40())
                _5c7b5af5575f[_0c83430f2aab] = {
                    "lang_code": _be65b5d74ae4,
                    "lang_samples": _f4066357453a["lang_samples"] + _e33258c8a949,
                    "lang_files": _5870b74d8ddb,
                }
            else:
                _992e938d10ef = _2ec55714df51(_5c7b5af5575f)
                _5c7b5af5575f[_992e938d10ef] = {
                    "lang_code": _be65b5d74ae4,
                    "lang_samples": _e33258c8a949,
                    "lang_files": _7075fc43bc5f,
                }
                _c36b515aeec1[_be65b5d74ae4] = _992e938d10ef

        return _5c7b5af5575f

    def _aa472d9b4fd7(self, _35439a9fa23c: _4e89cfc939b4[_891084678fda]) -> _f835768c4ce1._006d8f33ffe6:
        _adff280b0063 = _f835768c4ce1._ba285fed62aa(_35439a9fa23c)
        return _35439a9fa23c / _adff280b0063 if _adff280b0063 != 0 else _f835768c4ce1._b54b442f7a78(_35439a9fa23c)

    def _50271491ef61(self, _d8ac98d7a20f: _148ffac03632) -> _7d4432a280af[_4e89cfc939b4[_891084678fda], _148ffac03632]:
        _e33258c8a949 = _ba285fed62aa(_5bbe69405b0f["lang_samples"] for _5bbe69405b0f in _d8ac98d7a20f._39a94c906a40())
        for _993168388055, _e60b37fd1581 in _d8ac98d7a20f._9bac9a49b29b():
            _55c4b42fa71f = _e60b37fd1581["lang_samples"]
            if _55c4b42fa71f > 0:
                _687753a27838 = _e33258c8a949 / (_55c4b42fa71f * _2ec55714df51(_d8ac98d7a20f))
            else:
                _687753a27838 = 0.0
            _d8ac98d7a20f[_993168388055]["lang_weight"] = _687753a27838
        _ca1024d0ea4f = [_5bbe69405b0f["lang_weight"] for _5bbe69405b0f in _d8ac98d7a20f._39a94c906a40()]
        # Update stored lang weights (keeps original behavior)
        for _460022a29a37, (_993168388055, _e60b37fd1581) in _2108d41addc1(_d8ac98d7a20f._9bac9a49b29b()):
            _e60b37fd1581["lang_weight"] = _ca1024d0ea4f[_460022a29a37]
        return _ca1024d0ea4f, _d8ac98d7a20f

    def _53b400d446dc(self, _0659c0c0d365: _6a045dfa1c63, _af839d832896: _6a1c86a84495) -> _7d4432a280af[_148ffac03632, _148ffac03632]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _d8ac98d7a20f = {}
        _ca1024d0ea4f = {}
        if os._a56405a67fdd._7615cceb2137(_0659c0c0d365):
            with _d54618fe32c1(_0659c0c0d365, "r", _3624c8668a62="utf8") as _7a4d9f516934:
                _f781cc3b2b3b = json._be3421553fd7(_7a4d9f516934)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _d8ac98d7a20f = {
                    (_891084678fda(_457a2e0ccdf8) if "." in _457a2e0ccdf8 else _3a9c0010a6dd(_457a2e0ccdf8)): _d692b9eb6944
                    for _457a2e0ccdf8, _d692b9eb6944 in _f781cc3b2b3b._9bac9a49b29b()
                }

        if _af839d832896:
            _d8ac98d7a20f = self._ead57eed31eb(_5c7b5af5575f=_d8ac98d7a20f)
            _ca1024d0ea4f, _d8ac98d7a20f = self._c6bed82cbd44(_d8ac98d7a20f=_d8ac98d7a20f)
            with _d54618fe32c1(_0659c0c0d365, "w", _3624c8668a62="utf8") as _add5348d5d47:
                json._4f636f627a15(_d8ac98d7a20f, _add5348d5d47, _fe41768e3e20=2)

        return _d8ac98d7a20f, _ca1024d0ea4f

    def _95878bc70e87(self) -> _4e89cfc939b4[_3a9c0010a6dd]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._a413acbc2729(_993168388055) for _993168388055 in self._3ceca856d52c] if _85617cab3b69(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _a713c3e468f6(self, _cb709356cbf2: _891084678fda) -> _3a9c0010a6dd:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _3a9c0010a6dd(self._b8b469e4ffce * _cb709356cbf2)

    @_34f61c0c39b8
    def _635972764aae(_3721bc530506: _6a045dfa1c63) -> _6a1c86a84495:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _3fba60258a6d
        for _e456024b54ae in _3721bc530506:
            if "ARABIC" not in _3fba60258a6d._806a6ec29f07(_e456024b54ae, ""):
                return _32969177bf07
        return _c3c940047ffc

    @_34f61c0c39b8
    def _9bd6dfecad9e(_9c5adbf2e2df: _6a045dfa1c63) -> _6a045dfa1c63:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _b4259c8cdaf7._cf44a872a579(_9c5adbf2e2df):
            _303c63828929 = _9c5adbf2e2df._515fa058eee3()._266bbd8f52d2()
            _e2b7962e5960 = " "._e1a483f6e8b6(_914d459b41bf(_303c63828929))
            return _e2b7962e5960
        return _9c5adbf2e2df

    def _afd360aa1bee(self, _c845b9db5a18: _6a045dfa1c63, _ca765a8d6c8e: _6a045dfa1c63) -> _891084678fda:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _bd0558746853(_831a8983adbc, _c845b9db5a18, _ca765a8d6c8e)._794115ec2523()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_34f61c0c39b8
    def _d58975b3fc89(_6d4f193c6d3c) -> _7d4432a280af[_4e89cfc939b4[_148ffac03632], _3a9c0010a6dd]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import time
        _8f6a7d523085 = time.time()
        _b581c95ce7ea, _24750148eb8c, _4ced76ace17d, _9519739fdaf5, _af839d832896, _d296efb169f6 = _6d4f193c6d3c
        _2da4f27c8795 = _b4259c8cdaf7._1e454eb8c387
        _69da056b1831 = 0
        _740d0cb65432 = _2da4f27c8795._53b89241b3bf
        _e8da7afc0335: _4e89cfc939b4[_148ffac03632] = []

        # Clean inputs and prepare per-word lists
        _ac1977bd37fc = [_843399303b9d._515fa058eee3() for _843399303b9d in _b581c95ce7ea]
        _3b1efffc5495 = [_a3329c6ad33b._515fa058eee3() for _a3329c6ad33b in _24750148eb8c]
        _e4b2618ac99f = [_3721bc530506._266bbd8f52d2() if _3721bc530506 else ["<empty>"] for _3721bc530506 in _ac1977bd37fc]
        _453ddb06f318 = []
        for _40a6c05108c8, _54d69451f43d in _02cb1c712f27(_e4b2618ac99f, _24750148eb8c):
            _bf084f38cd66 = _54d69451f43d if _f1f80895f41d(_54d69451f43d, _78e899ca6a41) else (_54d69451f43d._515fa058eee3()._266bbd8f52d2() if _54d69451f43d._515fa058eee3() else ["<empty>"])
            if _2ec55714df51(_bf084f38cd66) == 1:
                _bf084f38cd66 = [_bf084f38cd66[0]] * _2ec55714df51(_40a6c05108c8)
            elif _2ec55714df51(_bf084f38cd66) != _2ec55714df51(_40a6c05108c8):
                _bf084f38cd66 = _bf084f38cd66[:_2ec55714df51(_40a6c05108c8)] if _2ec55714df51(_bf084f38cd66) > _2ec55714df51(_40a6c05108c8) else _bf084f38cd66 + [_bf084f38cd66[-1]] * (_2ec55714df51(_40a6c05108c8) - _2ec55714df51(_bf084f38cd66))
            _453ddb06f318._9ed62860ee14(_bf084f38cd66)

        # Flatten all words for a single tokenizer call (faster)
        _9df91d38f67b = _78e899ca6a41(_9d7f086ec8a4(*_e4b2618ac99f))
        _843da63340fe = time.time()
        try:
            _06c456981e5d = _2da4f27c8795(_9df91d38f67b, _ffe200e69970=_32969177bf07, _8e13a7920cd1=_32969177bf07, _68b88ce8c856=_32969177bf07)
        except _b403de649c70 as _75c02753698e:
            _9ddc035fa21f(f"Tokenization error: {_75c02753698e}")
            _06c456981e5d = {"input_ids": [[0] for _ in _9df91d38f67b]}
        # build word token info per sentence
        _de2fc00bacfb = 0
        _6fddf80d8d7b = []
        for _40a6c05108c8 in _e4b2618ac99f:
            _995c669e5446 = _2ec55714df51(_40a6c05108c8)
            _e44b8f0b1aef = [(_460022a29a37, _06c456981e5d["input_ids"][_de2fc00bacfb + _460022a29a37], _2ec55714df51(_06c456981e5d["input_ids"][_de2fc00bacfb + _460022a29a37])) for _460022a29a37 in _fc1e3db2b21b(_995c669e5446)]
            _6fddf80d8d7b._9ed62860ee14(_e44b8f0b1aef)
            _de2fc00bacfb += _995c669e5446

        # chunk each sentence into token windows
        for _e462c9d68805, (_40a6c05108c8, _21563869d8db, _bf084f38cd66) in _2108d41addc1(_02cb1c712f27(_e4b2618ac99f, _6fddf80d8d7b, _453ddb06f318)):
            _29e4b5244ba0 = _d296efb169f6 + _e462c9d68805
            _41b31db0ccd9 = 0
            if _40a6c05108c8 == ["<empty>"]:
                _48816479f7fe = [0] * _4ced76ace17d
                _e8da7afc0335._9ed62860ee14({
                    "sample_id": _29e4b5244ba0,
                    "chunk_id": _41b31db0ccd9,
                    "input_ids": _48816479f7fe,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _460022a29a37 = 0
            _ae66a0df36fa = _2ec55714df51(_21563869d8db)
            _589d68de24c2 = []
            while _460022a29a37 < _ae66a0df36fa:
                _a568dc772851 = 0
                _23a503dfa3ee = []
                _ce7c77c74645 = []
                _b306e1fc314b = []
                _59e8707a35ca = _460022a29a37
                while _59e8707a35ca < _ae66a0df36fa:
                    _bba5c37d2631, _3b8f9c81a568, _d8efb98b9738 = _21563869d8db[_59e8707a35ca]
                    _cc74ce4caf36 = _bf084f38cd66[_bba5c37d2631] if _bba5c37d2631 < _2ec55714df51(_bf084f38cd66) else _bf084f38cd66[-1] if _bf084f38cd66 else "<unknown>"
                    if _d8efb98b9738 > _4ced76ace17d and not _23a503dfa3ee:
                        _23a503dfa3ee += _3b8f9c81a568[:_4ced76ace17d]
                        _ce7c77c74645._9ed62860ee14(_cc74ce4caf36)
                        _b306e1fc314b._9ed62860ee14(_bba5c37d2631)
                        _59e8707a35ca += 1
                        break
                    if _a568dc772851 + _d8efb98b9738 > _4ced76ace17d and _23a503dfa3ee:
                        break
                    _23a503dfa3ee += _3b8f9c81a568
                    _ce7c77c74645._9ed62860ee14(_cc74ce4caf36)
                    _69da056b1831 += 1
                    _b306e1fc314b._9ed62860ee14(_59e8707a35ca)
                    _a568dc772851 += _d8efb98b9738
                    _59e8707a35ca += 1

                if not _23a503dfa3ee:
                    # fallback: take token prefix to avoid infinite loop
                    _23a503dfa3ee = _21563869d8db[_460022a29a37][1][:_4ced76ace17d] or [0]
                    _ce7c77c74645 = [_bf084f38cd66[_460022a29a37] if _460022a29a37 < _2ec55714df51(_bf084f38cd66) else _bf084f38cd66[-1] if _bf084f38cd66 else "<unknown>"]
                    _b306e1fc314b = [_460022a29a37]
                    _69da056b1831 += 1
                    _460022a29a37 += 1

                # pad tokens to fixed length
                if _2ec55714df51(_23a503dfa3ee) < _4ced76ace17d:
                    _23a503dfa3ee += [_740d0cb65432] * (_4ced76ace17d - _2ec55714df51(_23a503dfa3ee))

                _589d68de24c2._9ed62860ee14({
                    "sample_id": _29e4b5244ba0,
                    "chunk_id": _41b31db0ccd9,
                    "input_ids": _23a503dfa3ee,
                    "labels": _ce7c77c74645,
                    "word_positions": _b306e1fc314b,
                    "num_chunks": 1
                })
                _41b31db0ccd9 += 1

                if _59e8707a35ca >= _ae66a0df36fa:
                    break

                # stride with overlap (in words)
                _bffb2c381276 = _2ec55714df51(_b306e1fc314b)
                _d98ade7538e7 = _3a9c0010a6dd(_9519739fdaf5 * _bffb2c381276)
                _d98ade7538e7 = _358678fdc22c(_d98ade7538e7, _bffb2c381276 - 1) if _bffb2c381276 > 1 else 0
                _c9620ad8395d = _59e8707a35ca - _d98ade7538e7
                if _c9620ad8395d <= _460022a29a37:
                    _c9620ad8395d = _460022a29a37 + 1
                _460022a29a37 = _c9620ad8395d

            _79a5dbd720b0 = _2ec55714df51(_589d68de24c2)
            for _82fa6b026d7d in _589d68de24c2:
                _82fa6b026d7d["num_chunks"] = _79a5dbd720b0
            _e8da7afc0335._1860a80b55c5(_589d68de24c2)

            if not _b4259c8cdaf7._d11380cc7652 and not _af839d832896 and _79a5dbd720b0 > 1:
                _9ddc035fa21f(f"[DEBUG] sample_id={_29e4b5244ba0}", _4f2cfcc31e9a=_c3c940047ffc)
                _b4259c8cdaf7._d11380cc7652 = _c3c940047ffc

        # Timing/logging suppressed to preserve original behavior
        return _e8da7afc0335, _69da056b1831

    @_34f61c0c39b8
    def _57cad60dac31(_6d4f193c6d3c) -> _7d4432a280af[_4e89cfc939b4[_148ffac03632], _3a9c0010a6dd]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import time
        _8f6a7d523085 = time.time()
        (_e3ce1002623f, _b581c95ce7ea, _24750148eb8c, _4ced76ace17d, _9519739fdaf5, _d7e3544f8532, _d296efb169f6) = _6d4f193c6d3c
        _2da4f27c8795 = _b4259c8cdaf7._1e454eb8c387
        _740d0cb65432 = _2da4f27c8795._53b89241b3bf or _2da4f27c8795._08e820aedda9
        _23634e57a596 = _2da4f27c8795._08e820aedda9
        _000240dc19d5 = -100

        # Chat-ish prefixes used in dataset construction
        # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
        # "Identify the language of every word and reply with space-separated codes only.\n"
        # "Do not include any explanation or extra text.\n")
        # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _3c848cd5c873 = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
        "Identify the language of every word and reply with space-separated codes only.\n"
        "Do not include any explanation or extra text.\n")
        _d4bcc7d4e1ae = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _3361cdf50945 = _2da4f27c8795._a21b20ecaf2b(_e3ce1002623f, _ffe200e69970=_32969177bf07)
        _515e73a3887d = _2da4f27c8795._a21b20ecaf2b(_3c848cd5c873, _ffe200e69970=_32969177bf07)
        _a25d34ceeaf9 = _2da4f27c8795._a21b20ecaf2b(_d4bcc7d4e1ae, _ffe200e69970=_32969177bf07)
        _990cb94952b9 = _2da4f27c8795._a21b20ecaf2b(" ", _ffe200e69970=_32969177bf07)
        _8ca6fc663927 = _3361cdf50945 + _515e73a3887d
        _3df506a0a4eb = _a25d34ceeaf9
        _cb0e5adb6a03 = 1
        _f55a1834faf6 = _2ec55714df51(_8ca6fc663927) + _2ec55714df51(_3df506a0a4eb) + _cb0e5adb6a03

        _e8da7afc0335: _4e89cfc939b4[_148ffac03632] = []
        _69da056b1831 = 0

        # Preprocess lines into words lists and align labels to words
        _ac1977bd37fc = [_843399303b9d._515fa058eee3() for _843399303b9d in _b581c95ce7ea]
        _3b1efffc5495 = [_a3329c6ad33b._515fa058eee3() for _a3329c6ad33b in _24750148eb8c]
        _e4b2618ac99f = []
        _47b7906b1187 = []
        for _9c975752efd5, _54d69451f43d in _02cb1c712f27(_ac1977bd37fc, _24750148eb8c):
            _40a6c05108c8 = _9c975752efd5._266bbd8f52d2() if _9c975752efd5 else ["<empty>"]
            _d478d8d65fe6 = _54d69451f43d if _f1f80895f41d(_54d69451f43d, _78e899ca6a41) else (_54d69451f43d._515fa058eee3()._266bbd8f52d2() if _54d69451f43d._515fa058eee3() else ["<empty>"])
            if _2ec55714df51(_d478d8d65fe6) == 1:
                _d478d8d65fe6 = [_d478d8d65fe6[0]] * _2ec55714df51(_40a6c05108c8)
            elif _2ec55714df51(_d478d8d65fe6) != _2ec55714df51(_40a6c05108c8):
                _d478d8d65fe6 = _d478d8d65fe6[:_2ec55714df51(_40a6c05108c8)] if _2ec55714df51(_d478d8d65fe6) > _2ec55714df51(_40a6c05108c8) else _d478d8d65fe6 + [_d478d8d65fe6[-1]] * (_2ec55714df51(_40a6c05108c8) - _2ec55714df51(_d478d8d65fe6))
            _e4b2618ac99f._9ed62860ee14(_40a6c05108c8)
            _47b7906b1187._9ed62860ee14(_d478d8d65fe6)

        # Flatten words for efficient tokenization
        _9df91d38f67b = _78e899ca6a41(_9d7f086ec8a4(*_e4b2618ac99f))
        _bc1b638aa2fc = _78e899ca6a41(_9d7f086ec8a4(*_47b7906b1187))
        _96202f3beb3d = _2da4f27c8795(_9df91d38f67b, _ffe200e69970=_32969177bf07, _8e13a7920cd1=_32969177bf07)["input_ids"]
        _a2d991622b57 = _2da4f27c8795(_bc1b638aa2fc, _ffe200e69970=_32969177bf07, _8e13a7920cd1=_32969177bf07)["input_ids"]

        # Build per-line token info
        _de2fc00bacfb = 0
        _710e0620f604 = 0
        _6fddf80d8d7b = []
        _4130951ba749 = []
        for _40a6c05108c8, _d478d8d65fe6 in _02cb1c712f27(_e4b2618ac99f, _47b7906b1187):
            _995c669e5446 = _2ec55714df51(_40a6c05108c8)
            _e4a10df99158 = _2ec55714df51(_d478d8d65fe6)
            if _40a6c05108c8 == ["<empty>"] or _d478d8d65fe6 == ["<empty>"]:
                _6fddf80d8d7b._9ed62860ee14([(_40a6c05108c8[0], [0], 1)])
                _4130951ba749._9ed62860ee14([(_d478d8d65fe6[0], [0], 1)])
                continue
            try:
                _e44b8f0b1aef = [(_b9e64fe163b5, _96202f3beb3d[_de2fc00bacfb + _460022a29a37], _2ec55714df51(_96202f3beb3d[_de2fc00bacfb + _460022a29a37]) if _f1f80895f41d(_96202f3beb3d[_de2fc00bacfb + _460022a29a37], _78e899ca6a41) else 1) for _460022a29a37, _b9e64fe163b5 in _2108d41addc1(_40a6c05108c8)]
                _9bcb36faa0ba = [(_b9e64fe163b5, _a2d991622b57[_710e0620f604 + _460022a29a37], _2ec55714df51(_a2d991622b57[_710e0620f604 + _460022a29a37]) if _f1f80895f41d(_a2d991622b57[_710e0620f604 + _460022a29a37], _78e899ca6a41) else 1) for _460022a29a37, _b9e64fe163b5 in _2108d41addc1(_d478d8d65fe6)]
            except _8e27327d8783:
                # On tokenization mismatches, fallback safely
                _6fddf80d8d7b._9ed62860ee14([(_40a6c05108c8[0], [0], 1)])
                _4130951ba749._9ed62860ee14([(_d478d8d65fe6[0], [0], 1)])
                _de2fc00bacfb += _995c669e5446
                _710e0620f604 += _e4a10df99158
                continue
            _6fddf80d8d7b._9ed62860ee14(_e44b8f0b1aef)
            _4130951ba749._9ed62860ee14(_9bcb36faa0ba)
            _de2fc00bacfb += _995c669e5446
            _710e0620f604 += _e4a10df99158

        # Build chunks per sentence
        for _e462c9d68805, (_40a6c05108c8, _21563869d8db, _93e66301df7c) in _2108d41addc1(_02cb1c712f27(_e4b2618ac99f, _6fddf80d8d7b, _4130951ba749)):
            _29e4b5244ba0 = _d296efb169f6 + _e462c9d68805
            _41b31db0ccd9 = 0
            _fa9fe1311ff7 = [_58570bd46881[0] for _58570bd46881 in _93e66301df7c]

            if _40a6c05108c8 == ["<empty>"]:
                _48816479f7fe = _8ca6fc663927 + [0] + _3df506a0a4eb + [_23634e57a596]
                _1c8db79b660e = [_000240dc19d5] * _2ec55714df51(_48816479f7fe)
                _7c0e937d25de = _4ced76ace17d - _2ec55714df51(_48816479f7fe)
                if _7c0e937d25de > 0:
                    _48816479f7fe += [_740d0cb65432] * _7c0e937d25de
                    _1c8db79b660e += [_000240dc19d5] * _7c0e937d25de
                _e8da7afc0335._9ed62860ee14({
                    "lang_codes": ["<empty>"],
                    "sample_id": _29e4b5244ba0,
                    "chunk_id": _41b31db0ccd9,
                    "word_positions": [0],
                    "input_ids": _48816479f7fe,
                    "labels": _1c8db79b660e,
                    "prompt_len": _2ec55714df51(_8ca6fc663927) + 1 + _2ec55714df51(_3df506a0a4eb),
                    "chunk_words": ["<empty>"],
                    "chunk_labels": ["<empty>"],
                    "num_chunks": 1
                })
                continue

            _460022a29a37 = 0
            _ae66a0df36fa = _2ec55714df51(_21563869d8db)
            _9e2dc000db41 = -1
            _589d68de24c2 = []
            while _460022a29a37 < _ae66a0df36fa:
                _a568dc772851 = _f55a1834faf6
                _024f610e45e0 = []
                _fd76eeb61b84 = []
                _b306e1fc314b = []
                _1be508a61da1 = []
                _5a8a9e1c555b = []
                _ce7c77c74645 = []
                _59e8707a35ca = _460022a29a37
                while _59e8707a35ca < _ae66a0df36fa:
                    _, _cfa6db876feb, _995c669e5446 = _21563869d8db[_59e8707a35ca]
                    _c99c65f76d88, _e140051d7e40, _e4a10df99158 = _93e66301df7c[_59e8707a35ca]
                    _c2c87d233892 = _2ec55714df51(_990cb94952b9) if _59e8707a35ca < _ae66a0df36fa - 1 else 0
                    # choose conservative word_total so both streams fit
                    _9fb796fde631 = _97460a09739e(_995c669e5446, _e4a10df99158) + _c2c87d233892
                    if _a568dc772851 + _9fb796fde631 > _4ced76ace17d * 0.9:
                        break

                    # append inputs and spaces
                    _024f610e45e0 += _cfa6db876feb if _f1f80895f41d(_cfa6db876feb, _78e899ca6a41) else [_cfa6db876feb]
                    if _c2c87d233892:
                        _024f610e45e0 += _990cb94952b9

                    # append labels and word_positions
                    if _e4a10df99158:
                        _fd76eeb61b84 += _e140051d7e40 if _f1f80895f41d(_e140051d7e40, _78e899ca6a41) else [_e140051d7e40]
                        _b306e1fc314b += [_59e8707a35ca] * _e4a10df99158
                    if _c2c87d233892:
                        _fd76eeb61b84 += _990cb94952b9
                        _b306e1fc314b += [-1] * _c2c87d233892

                    _1be508a61da1._9ed62860ee14(_c99c65f76d88)
                    _5a8a9e1c555b._9ed62860ee14(_40a6c05108c8[_59e8707a35ca])
                    _ce7c77c74645._9ed62860ee14(_c99c65f76d88)
                    _69da056b1831 += _2ec55714df51(_40a6c05108c8[_59e8707a35ca])
                    _a568dc772851 += _9fb796fde631
                    _59e8707a35ca += 1

                if not _024f610e45e0:
                    _460022a29a37 += 1
                    continue

                _b97292cffa2d = _024f610e45e0
                _a1073c0409e9 = _fd76eeb61b84
                _953d6591cc39 = _2ec55714df51(_8ca6fc663927) + _2ec55714df51(_b97292cffa2d) + _2ec55714df51(_3df506a0a4eb)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                if _d7e3544f8532 is _32969177bf07:
                    _48816479f7fe = _8ca6fc663927 + _b97292cffa2d + _3df506a0a4eb + _a1073c0409e9 + [_23634e57a596]
                    _1c8db79b660e = [_000240dc19d5] * _953d6591cc39 + _a1073c0409e9 + [_000240dc19d5]
                else:
                    _48816479f7fe = _8ca6fc663927 + _b97292cffa2d + _3df506a0a4eb + [_23634e57a596]
                    _1c8db79b660e = [_000240dc19d5] * _953d6591cc39 + _a1073c0409e9 + [_000240dc19d5]

                # pad to fixed size (inputs appended or prepended depending on test/train)
                _f23d7fe7f991 = _4ced76ace17d - _2ec55714df51(_48816479f7fe)
                _4eafa3ff9744 = _4ced76ace17d - _2ec55714df51(_1c8db79b660e)
                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len
                if _f23d7fe7f991 > 0:
                    if _d7e3544f8532:
                        _48816479f7fe = [_740d0cb65432] * _f23d7fe7f991 + _48816479f7fe
                    else:
                        _48816479f7fe += [_740d0cb65432] * _f23d7fe7f991
                if _4eafa3ff9744 > 0:
                    if _d7e3544f8532:
                        _1c8db79b660e = [_000240dc19d5] * _4eafa3ff9744 + _1c8db79b660e
                    else:
                        _1c8db79b660e += [_000240dc19d5] * _4eafa3ff9744

                _589d68de24c2._9ed62860ee14({
                    "lang_codes": _1be508a61da1,
                    "sample_id": _29e4b5244ba0,
                    "chunk_id": _41b31db0ccd9,
                    "word_positions": _b306e1fc314b,
                    "input_ids": _48816479f7fe,
                    "labels": _1c8db79b660e,
                    "prompt_len": _953d6591cc39,
                    "chunk_words": _5a8a9e1c555b,
                    "chunk_labels": _ce7c77c74645,
                    "num_chunks": 1
                })
                _41b31db0ccd9 += 1

                if _59e8707a35ca >= _ae66a0df36fa or _59e8707a35ca <= _9e2dc000db41:
                    break
                _9e2dc000db41 = _59e8707a35ca
                _6d3c89cc9efe = _97460a09739e(1, _3a9c0010a6dd(_9519739fdaf5 * _2ec55714df51(_5a8a9e1c555b)))
                _460022a29a37 = _59e8707a35ca - _6d3c89cc9efe if (_59e8707a35ca - _6d3c89cc9efe) > _460022a29a37 else _59e8707a35ca

            _79a5dbd720b0 = _2ec55714df51(_589d68de24c2)
            for _82fa6b026d7d in _589d68de24c2:
                _82fa6b026d7d["num_chunks"] = _79a5dbd720b0
            _e8da7afc0335._1860a80b55c5(_589d68de24c2)

            if not _b4259c8cdaf7._d11380cc7652 and not _d7e3544f8532 and _79a5dbd720b0 > 1:
                _b4259c8cdaf7._d11380cc7652 = _c3c940047ffc

        return _e8da7afc0335, _69da056b1831

    # -------------------------
    # File processing & validation
    # -------------------------
    def _355f31f3cf41(self, _f064be3c3df9: _6a045dfa1c63, _67b640c7070d: _6a045dfa1c63, _d296efb169f6: _3a9c0010a6dd) -> _7d4432a280af[_6a045dfa1c63, _4e89cfc939b4[_148ffac03632], _3a9c0010a6dd]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _36438751ffcf = []

        with _d54618fe32c1(_f064be3c3df9, "r", _3624c8668a62="utf8") as _b37fd9e4842b, _d54618fe32c1(_67b640c7070d, "r", _3624c8668a62="utf8") as _6629d31bc408:
            _b581c95ce7ea = _b37fd9e4842b._1c0c882778ef()[1:] if self._0789f981932a else _b37fd9e4842b._1c0c882778ef()
            _24750148eb8c = _6629d31bc408._1c0c882778ef()[1:] if self._0789f981932a else _6629d31bc408._1c0c882778ef()

        # sample some share if requested
        _08a8bf114a03 = _3a9c0010a6dd(_2ec55714df51(_b581c95ce7ea) * self._f5f947b79f45)
        if _08a8bf114a03 < _2ec55714df51(_b581c95ce7ea):
            _24ab4fdf5045 = _f835768c4ce1.random._d3077de5cb21(_2ec55714df51(_b581c95ce7ea), _08a8bf114a03, _d423b90f0f48=_32969177bf07)
            _b581c95ce7ea = [_b581c95ce7ea[_460022a29a37] for _460022a29a37 in _24ab4fdf5045]
            _24750148eb8c = [_24750148eb8c[_460022a29a37] for _460022a29a37 in _24ab4fdf5045]

        _993168388055 = _78e899ca6a41({_a3329c6ad33b._515fa058eee3() for _a3329c6ad33b in _24750148eb8c})[0] if _24750148eb8c else "unk"
        self._d3ff3966ef41._58570bd46881(f"Sampled {self._f5f947b79f45 * 100:.1f}% of {_f064be3c3df9}: {_2ec55714df51(_b581c95ce7ea)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _b436fc9787cb(_f54f059fe930, _c895bcfa1f40):
            _27e6b6d099bf = _4720209b5ca8(_f54f059fe930)
            while _c3c940047ffc:
                _3190108e9e50 = _78e899ca6a41(_640a08ab21e4(_27e6b6d099bf, _c895bcfa1f40))
                if not _3190108e9e50:
                    break
                yield _3190108e9e50

        _c895bcfa1f40 = 10_000
        if self._a38ab8e668ff:
            _3b4f7ec997df = [
                (self._e3ce1002623f, _fb4d65ea6308, _e4827af3f35f, self._b8b469e4ffce, 0.25, self._d7e3544f8532, _d296efb169f6 + _1560165b085c * _c895bcfa1f40)
                for _1560165b085c, (_fb4d65ea6308, _e4827af3f35f) in _2108d41addc1(_02cb1c712f27(_6653938c0d14(_b581c95ce7ea, _c895bcfa1f40), _6653938c0d14(_24750148eb8c, _c895bcfa1f40)))
            ]
            with _f3ab52e1b5ad(self._54a0785055a1) as _74ce4bd24248:
                _d2a8ffa90d1c = _74ce4bd24248._8b22ff3d8f45(_b4259c8cdaf7._cc8ded495192, _3b4f7ec997df)
        else:
            _3b4f7ec997df = [
                (_fb4d65ea6308, _e4827af3f35f, self._b8b469e4ffce, 0.5, self._af839d832896, _d296efb169f6 + _1560165b085c * _c895bcfa1f40)
                for _1560165b085c, (_fb4d65ea6308, _e4827af3f35f) in _2108d41addc1(_02cb1c712f27(_6653938c0d14(_b581c95ce7ea, _c895bcfa1f40), _6653938c0d14(_24750148eb8c, _c895bcfa1f40)))
            ]
            with _f3ab52e1b5ad(self._54a0785055a1) as _74ce4bd24248:
                _d2a8ffa90d1c = _74ce4bd24248._8b22ff3d8f45(_b4259c8cdaf7._86a6c3532038, _3b4f7ec997df)

        _dd03b0dfc6e4 = []
        for _e8da7afc0335, _15e1aee84ac7 in _d2a8ffa90d1c:
            _dd03b0dfc6e4._1860a80b55c5(_e8da7afc0335)
            self._c26d10bb032f += _15e1aee84ac7

        if _dd03b0dfc6e4:
            _36438751ffcf = _dd03b0dfc6e4

        return _993168388055, _36438751ffcf, _2ec55714df51(_b581c95ce7ea)

    def _4c122a48177e(self) -> _831a8983adbc:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _aa3626daaf0c = 0

        for _1865e74104bb in os._f8b36e81e0fe(self._ab929f62e4be):
            self._d3ff3966ef41._58570bd46881(f"Now processing {os._a56405a67fdd._e1a483f6e8b6(self._ab929f62e4be, _1865e74104bb)} directory.")
            _a3f81509e215 = os._a56405a67fdd._e1a483f6e8b6(self._ab929f62e4be, _1865e74104bb, "src")
            _75c770737f5a = os._a56405a67fdd._e1a483f6e8b6(self._ab929f62e4be, _1865e74104bb, "tgt")

            _a2bd0502fa90 = []
            _0bae1936d13a = []
            for _f064be3c3df9 in os._f8b36e81e0fe(_a3f81509e215):
                _ad53d5a2e063 = _32969177bf07
                for _67b640c7070d in os._f8b36e81e0fe(_75c770737f5a):
                    if _f064be3c3df9._266bbd8f52d2(".")[0] == _67b640c7070d._266bbd8f52d2(".")[0]:
                        _a2bd0502fa90._9ed62860ee14(_f064be3c3df9)
                        _0bae1936d13a._9ed62860ee14(_67b640c7070d)
                        _ad53d5a2e063 = _c3c940047ffc
                        break
                if not _ad53d5a2e063:
                    self._d3ff3966ef41._58570bd46881(f"Skipping file {_f064be3c3df9} since matching label file not found in {_75c770737f5a}.")

            _c98aa3e5e19a = [os._a56405a67fdd._e1a483f6e8b6(_a3f81509e215, _e7b8dd48e8aa) for _e7b8dd48e8aa in _a2bd0502fa90 if os._a56405a67fdd._f7094fce95aa(os._a56405a67fdd._e1a483f6e8b6(_a3f81509e215, _e7b8dd48e8aa))]
            _0570611fdd59 = [os._a56405a67fdd._e1a483f6e8b6(_75c770737f5a, _e7b8dd48e8aa) for _e7b8dd48e8aa in _0bae1936d13a if os._a56405a67fdd._f7094fce95aa(os._a56405a67fdd._e1a483f6e8b6(_75c770737f5a, _e7b8dd48e8aa))]

            if _2ec55714df51(_c98aa3e5e19a) != _2ec55714df51(_0570611fdd59):
                raise _7f27e7ccf3c1(f"Number of files in {_a3f81509e215} ({_2ec55714df51(_c98aa3e5e19a)}) does not match {_75c770737f5a} ({_2ec55714df51(_0570611fdd59)})")

            for _f064be3c3df9, _67b640c7070d in _02cb1c712f27(_c98aa3e5e19a, _0570611fdd59):
                _a16837c21a1f = _ba285fed62aa(1 for _ in _d54618fe32c1(_f064be3c3df9))
                _7cd769785c89 = _ba285fed62aa(1 for _ in _d54618fe32c1(_67b640c7070d))
                _a16837c21a1f = _a16837c21a1f - 1 if self._0789f981932a else _a16837c21a1f
                _7cd769785c89 = _7cd769785c89 - 1 if self._0789f981932a else _7cd769785c89

                if _a16837c21a1f != _7cd769785c89:
                    self._d3ff3966ef41._58570bd46881(f"{_a16837c21a1f} lines in {_f064be3c3df9} do not match with {_7cd769785c89} in {_67b640c7070d}, skipping these files")
                    continue

                self._d3ff3966ef41._58570bd46881(f"Processing {_f064be3c3df9} and {_67b640c7070d} with {_7cd769785c89} samples.")
                _993168388055, _1f0c46ce9fb0, _05fec5d5f600 = self._c57e054728fb(_f064be3c3df9, _67b640c7070d, _d296efb169f6=_aa3626daaf0c)
                _aa3626daaf0c += _05fec5d5f600

                self._1f0c46ce9fb0._1860a80b55c5(_1f0c46ce9fb0)
                if self._af839d832896:
                    if _993168388055 not in self._b318b0363241:
                        self._b318b0363241._123d0d08c8f1({
                            _993168388055: [{
                                "file_name": os._a56405a67fdd._b84489d27a8c(_67b640c7070d),
                                "samples_before_processing": _7cd769785c89,
                                "samples_after_processing": _2ec55714df51(_1f0c46ce9fb0)
                            }]
                        })
                    else:
                        self._b318b0363241[_993168388055]._9ed62860ee14({
                            "file_name": os._a56405a67fdd._b84489d27a8c(_67b640c7070d),
                            "samples_before_processing": _7cd769785c89,
                            "samples_after_processing": _2ec55714df51(_1f0c46ce9fb0)
                        })
                self._d3ff3966ef41._58570bd46881(f"Files {_f064be3c3df9} and {_67b640c7070d} have {_2ec55714df51(_1f0c46ce9fb0)} samples after processing.")

        # verify dataset integrity
        self._a13120143cfb()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _0c55d1d1ee3b(self) -> _831a8983adbc:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _797dff9229dd = self._1f0c46ce9fb0
        if not _797dff9229dd:
            self._d3ff3966ef41._58570bd46881("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _a17c30c5f171 = [_542bdd453b78["sample_id"] for _542bdd453b78 in _797dff9229dd]
        _179ac3c2f564 = _319fd5b088ee(_a17c30c5f171)
        _c2cdf0dee37e = _97460a09739e(_179ac3c2f564)
        _0f3aa56a1273 = (_2ec55714df51(_179ac3c2f564) == _c2cdf0dee37e + 1)
        self._d3ff3966ef41._58570bd46881(f"[sample_id] unique={_2ec55714df51(_179ac3c2f564)} max={_c2cdf0dee37e} coverage_ok={_0f3aa56a1273} (expect True)")
        if not _0f3aa56a1273:
            _d36e24baafb6 = _99a1689e60fc(_319fd5b088ee(_fc1e3db2b21b(_c2cdf0dee37e + 1)) - _179ac3c2f564)
            self._d3ff3966ef41._58570bd46881(f" Missing sample_ids: {_d36e24baafb6[:20]}{' ...' if _2ec55714df51(_d36e24baafb6) > 20 else ''}")
            raise _7f27e7ccf3c1(f"Increase max_seq_len as missing sample_ids detected: {_d36e24baafb6[:20]}{' ...' if _2ec55714df51(_d36e24baafb6) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _57dc7f2716a3 = [(_542bdd453b78["sample_id"], _542bdd453b78["chunk_id"]) for _542bdd453b78 in _797dff9229dd]
        _af6d4b12cbc5 = [_457a2e0ccdf8 for _457a2e0ccdf8, _d692b9eb6944 in _b0e7ccab13ed(_57dc7f2716a3)._9bac9a49b29b() if _d692b9eb6944 > 1]
        self._d3ff3966ef41._58570bd46881(f"[(sample_id,chunk_id)] duplicates: {_2ec55714df51(_af6d4b12cbc5)} (expect 0)")
        if _af6d4b12cbc5:
            self._d3ff3966ef41._58570bd46881(f" Examples: {_af6d4b12cbc5[:10]}")
            raise _7f27e7ccf3c1(f"Duplicate (sample_id, chunk_id) pairs detected: {_af6d4b12cbc5[:10]}")

        # 3) per-sample chunk_id sequentiality
        _a4f69fe39781 = _7504ba34a34e(_78e899ca6a41)
        for _542bdd453b78 in _797dff9229dd:
            _a4f69fe39781[_542bdd453b78["sample_id"]]._9ed62860ee14(_542bdd453b78["chunk_id"])
        _c9863b727c6a = {}
        for _121889e05432, _3b8f9c81a568 in _a4f69fe39781._9bac9a49b29b():
            _03ded1a2c746 = _99a1689e60fc(_3b8f9c81a568)
            _eed8c97aaaf4 = _78e899ca6a41(_fc1e3db2b21b(_2ec55714df51(_03ded1a2c746)))
            if _03ded1a2c746 != _eed8c97aaaf4:
                _c9863b727c6a[_121889e05432] = {"have": _03ded1a2c746[:20], "expected_prefix": _eed8c97aaaf4[:20]}
        self._d3ff3966ef41._58570bd46881(f"[per-sample chunk_id sequence] bad_samples: {_2ec55714df51(_c9863b727c6a)} (expect 0)")
        if _c9863b727c6a:
            _5c6d43d793af = _78e899ca6a41(_c9863b727c6a._9bac9a49b29b())[:5]
            for _121889e05432, _58570bd46881 in _5c6d43d793af:
                self._d3ff3966ef41._58570bd46881(f" sample_id={_121889e05432} have={_58570bd46881['have']} expected_prefix={_58570bd46881['expected_prefix']}")
            raise _7f27e7ccf3c1(f"Non-sequential chunk_id sequences detected for sample_ids: {_78e899ca6a41(_c9863b727c6a._0cc062b20221())[:5]}")

        # 4) overall stats reporting
        _56443a1648e9 = _2ec55714df51(_179ac3c2f564)
        _418de4d86aa9 = _2ec55714df51(_797dff9229dd)
        _3bf2edd2c8a4 = _418de4d86aa9 / _56443a1648e9 if _56443a1648e9 > 0 else 0
        self._d3ff3966ef41._58570bd46881(f"[audit] base={_56443a1648e9} -> chunks={_418de4d86aa9} (avg {_3bf2edd2c8a4:.2f} per sample)")

    @_ba92995c75a8
    def _2f8174455bd3(self) -> _3a9c0010a6dd:
        """Return number of unique base samples (unique sample_id)."""
        if not _7a961ab8e371(self, "file_data_dict_list", _831a8983adbc):
            return 0
        return _2ec55714df51({_3a9c0010a6dd(_5bbe69405b0f["sample_id"]) for _5bbe69405b0f in self._1f0c46ce9fb0})

    @_ba92995c75a8
    def _ca28e1e0814e(self) -> _3a9c0010a6dd:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _7a961ab8e371(self, "file_data_dict_list", _831a8983adbc):
            return 0

        _d53024cd5563 = _7504ba34a34e(_319fd5b088ee)
        for _5bbe69405b0f in self._1f0c46ce9fb0:
            _121889e05432 = _3a9c0010a6dd(_5bbe69405b0f._d953a726bc4f("sample_id", -1))
            for _9ff1eebe842d in _5bbe69405b0f._d953a726bc4f("word_positions", []):
                try:
                    _a550a1bf70cd = _3a9c0010a6dd(_9ff1eebe842d)
                except _b403de649c70:
                    continue
                if _a550a1bf70cd >= 0:
                    _d53024cd5563[_121889e05432]._cdffd34fc6f6(_a550a1bf70cd)

        return _ba285fed62aa(_2ec55714df51(_e636cabab089) for _e636cabab089 in _d53024cd5563._39a94c906a40())
