# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import os
import json
import random
import re
from itertools import _7767a1728306, _70d61d2a1c85
from collections import _39b5a63babd0, _4ce30fbe5bb8
from _06546853d891 import _c7a661fcc721
from _5d6c18b31bd4._667c7b38825c import _094d0030547b
from typing import _61adc4f49067, _fa98628c1f41, _2d0498a708fb

import _082d4d7d8201 as _e332d14bb7bd
import _6b4b30bd9a3d
from _6b4b30bd9a3d._5aa51c30ca55._cef1a8d2c58f import _ffc49da824fd
from _9172b25bd12c import _c79f1e164959


class _060d695ea52c(_ffc49da824fd):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _d280c94131ac = _c2e74c58c90b  # class-level tokenizer (set on __init__)
    _4e4ba20bd649 = _f631985d3e6e

    def _8a2339085b6e(
        self,
        _0c710414852f: _3a7dc6aafab4,
        _0abd8d06f32f: _2bbbbeafa9e5,
        _dd20ae62705d: _61adc4f49067,
        _d3ce24d3dbd5: _c3d7ab130f30,
        _3ca914db3c53: _3a7dc6aafab4,
        _4bccee266577: _c79f1e164959,
        _1bfdb1d1bcb8: _2bbbbeafa9e5,
        _c76caf436db5: _2bbbbeafa9e5,
        _72af933656c3: _322d4739e29e = 1.0,
        _6930a4ab8100: _c3d7ab130f30 = 2,
        _f2a9f6ed58b1: _c3d7ab130f30 = 20,
        _78a2f356af1f: _2bbbbeafa9e5 = _f631985d3e6e,
        _1daa2583ba08: _3a7dc6aafab4 = _c2e74c58c90b,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _60cd30a6c4d0()._c8daceb943fa()

        # Deterministic behavior
        _6b4b30bd9a3d._87faaf6c95aa(_f2a9f6ed58b1)
        if _6b4b30bd9a3d._6c636c8bc6a7._bd975150b463():
            _6b4b30bd9a3d._6c636c8bc6a7._e98a942ca012(_f2a9f6ed58b1)
        random._b1d695b1f188(_f2a9f6ed58b1)
        _e332d14bb7bd.random._b1d695b1f188(_f2a9f6ed58b1)

        # Basic parameters & bookkeeping
        self._4bccee266577 = _4bccee266577
        self._1bfdb1d1bcb8 = _1bfdb1d1bcb8
        self._c76caf436db5 = _c76caf436db5
        self._78a2f356af1f = _78a2f356af1f
        self._1daa2583ba08 = _1daa2583ba08
        self._0abd8d06f32f = _0abd8d06f32f
        self._0c710414852f = _0c710414852f
        self._d3ce24d3dbd5 = _d3ce24d3dbd5
        self._652ec340498f = 0
        self._72af933656c3 = _72af933656c3
        self._6930a4ab8100 = _6930a4ab8100
        self._ca799f7b3477 = -100

        # Tokenizer handling
        _d96135af9daf._d280c94131ac = _dd20ae62705d
        self._d5c955e85e97 = _dd20ae62705d
        if self._78a2f356af1f:
            # preserve earlier code's fallback pad id (kept intentionally)
            if not self._d5c955e85e97._70448a9d1e92:
                self._d5c955e85e97._70448a9d1e92 = 128004

        # storage filled by _validate_and_load_file_data
        self._bbfc1d3078e6: _fa98628c1f41[_635d43130f39] = []
        self._d301858cb552 = {}

        # Load and process files; then derive classes/weights
        self._54dbb804de72()
        self._b6d8db7c8cbe, self._670a37877d7a = self._41ff0257cafe(_3ca914db3c53, _1bfdb1d1bcb8)

    def _c807e824848f(self) -> _c3d7ab130f30:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _728349aff8c6(self._bbfc1d3078e6)

    def _ca66a2742df4(self, _8601ed007717: _c3d7ab130f30) -> _635d43130f39:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _cb0af1bd824f = self._bbfc1d3078e6[_8601ed007717]
        _0f4d60105b72 = _cb0af1bd824f._370900561a63("lang_code", "unk")
        _fb13d793f8fd = _cb0af1bd824f["input_ids"]
        _fe505c5fec17 = _cb0af1bd824f["labels"]
        _38be964aea38 = _cb0af1bd824f._370900561a63("word_positions", [])
        _4520225425c0 = _cb0af1bd824f["num_chunks"]
        _35240ccb4fa2 = _cb0af1bd824f._370900561a63("sample_id", _8601ed007717)
        _30465d7ed3d1 = _cb0af1bd824f._370900561a63("chunk_id", 0)
        _8a4e2f04ebd0 = _cb0af1bd824f._370900561a63("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _fe505c5fec17 = [
            self._ca799f7b3477
            if _1f450e2fdac0 is _c2e74c58c90b
            else _c3d7ab130f30(_1f450e2fdac0) if _3da3a21910de(_1f450e2fdac0, _3a7dc6aafab4) and _1f450e2fdac0._46634fc8df44("-")._4b5bcbd0300b()
            else _1f450e2fdac0
            for _1f450e2fdac0 in _fe505c5fec17
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._78a2f356af1f:
            _d6a91903ca2b = [
                self._ac4beab55287(_1f450e2fdac0) if _3da3a21910de(_1f450e2fdac0, _3a7dc6aafab4) else _1f450e2fdac0
                for _1f450e2fdac0 in _fe505c5fec17
            ]
            _1b7ec9210a19 = _728349aff8c6(_d6a91903ca2b)
            _cf83c3592667 = _08525bac259d(0, self._d3ce24d3dbd5 - _1b7ec9210a19)
            _d6a91903ca2b = _d6a91903ca2b + [self._ca799f7b3477] * _cf83c3592667
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _d6a91903ca2b = _fe505c5fec17

        return {
            "lang_code": _0f4d60105b72,
            "input_ids": _6b4b30bd9a3d._fc555e19c7ce(_fb13d793f8fd, _6977bc2b3ddf=_6b4b30bd9a3d._a1f80917dd41),
            "labels": _6b4b30bd9a3d._fc555e19c7ce(_d6a91903ca2b, _6977bc2b3ddf=_6b4b30bd9a3d._a1f80917dd41),
            "sample_id": _35240ccb4fa2,
            "chunk_id": _30465d7ed3d1,
            "word_positions": _38be964aea38,
            "prompt_len": _8a4e2f04ebd0,
            "num_chunks": _4520225425c0,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _87ee0ee46990(self, _0f4d60105b72: _3a7dc6aafab4) -> _c3d7ab130f30:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _dae03e5c81e3, _1b11a1a80da0 in self._b6d8db7c8cbe._5bb011f9c5bf():
            if _1b11a1a80da0["lang_code"] == _3a7dc6aafab4(_0f4d60105b72)._f7672f9849c4():
                return _dae03e5c81e3
        return self._b6d8db7c8cbe._370900561a63("unk", {})._370900561a63("id", -1)

    def _32924edef788(self, _abc6c64e38a1: _c3d7ab130f30) -> _3a7dc6aafab4:
        """Reverse mapping; assumes class_id present."""
        return self._b6d8db7c8cbe[_abc6c64e38a1]["lang_code"]

    def _2bb9db80174a(self) -> _c3d7ab130f30:
        return _728349aff8c6(self._b6d8db7c8cbe)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _8c1e1a6efa59(self, _6fc9dd04f187: _635d43130f39) -> _635d43130f39:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _3550b1fac25d = re._4676dc7a3d66(r"[^\d\s]+")  # tokens with non-digit characters
        _1f5715093779 = _39b5a63babd0()

        if self._78a2f356af1f:
            _60b74db4f26a = []
            for _920278f47f32 in self._bbfc1d3078e6:
                _ef507f9aff7f = _920278f47f32._370900561a63("labels", []) if _3da3a21910de(_920278f47f32, _635d43130f39) else (_920278f47f32[1] if _3da3a21910de(_920278f47f32, _390168aa8805) and _728349aff8c6(_920278f47f32) > 1 else [])
                _44ece37f152c = [_5c717c02a80a for _5c717c02a80a in _ef507f9aff7f if _5c717c02a80a != self._ca799f7b3477]
                if _44ece37f152c:
                    _60b74db4f26a._e2851be0edd0(_44ece37f152c)
            if _60b74db4f26a:
                _949d64060b59 = self._d5c955e85e97._3a698fc424ce(_60b74db4f26a, _1911ac6ab662=_109b554a057f)
                for _e8412a4d62c5 in _949d64060b59:
                    _bd69417c624b = _3550b1fac25d._1aa36da399b7(_e8412a4d62c5)
                    _1f5715093779._f6d80ccfeb41(_bd69417c624b)
        else:
            for _920278f47f32 in self._bbfc1d3078e6:
                _ef507f9aff7f = _920278f47f32._370900561a63("labels", [])
                _bd69417c624b = [_d4338cf40516._f7672f9849c4() for _d4338cf40516 in _ef507f9aff7f if _3da3a21910de(_d4338cf40516, _3a7dc6aafab4) and _3550b1fac25d._840a8fdec0e5(_d4338cf40516)]
                _1f5715093779._f6d80ccfeb41(_bd69417c624b)

        _ad4518de7370 = {_8bb07eedbd55["lang_code"]: _928ec8c88c22 for _928ec8c88c22, _8bb07eedbd55 in _6fc9dd04f187._5bb011f9c5bf()}

        for _b53367ddd157, _8b605419fcd5 in _1f5715093779._5bb011f9c5bf():
            _b53367ddd157 = _b53367ddd157._f7672f9849c4()
            _b0fe72902a10 = self._d301858cb552._370900561a63(_b53367ddd157, [])
            _c7ecd7166038 = _8d4e27c2b1c8(_1f2b5172f74b._370900561a63("samples_after_processing", 0) for _1f2b5172f74b in _b0fe72902a10)
            if _b53367ddd157 in _ad4518de7370:
                _8601ed007717 = _ad4518de7370[_b53367ddd157]
                _dab5eea1912c = _6fc9dd04f187[_8601ed007717]
                _f6f57cda660e = _dab5eea1912c["lang_files"] + _b0fe72902a10
                _cdca455e9a76 = _be0dce0b3aaf({_1f2b5172f74b["file_name"]: _1f2b5172f74b for _1f2b5172f74b in _f6f57cda660e}._f4f1704c955c())
                _6fc9dd04f187[_8601ed007717] = {
                    "lang_code": _b53367ddd157,
                    "lang_samples": _dab5eea1912c["lang_samples"] + _c7ecd7166038,
                    "lang_files": _cdca455e9a76,
                }
            else:
                _c22be74a4ded = _728349aff8c6(_6fc9dd04f187)
                _6fc9dd04f187[_c22be74a4ded] = {
                    "lang_code": _b53367ddd157,
                    "lang_samples": _c7ecd7166038,
                    "lang_files": _b0fe72902a10,
                }
                _ad4518de7370[_b53367ddd157] = _c22be74a4ded

        return _6fc9dd04f187

    def _aa63a5dec7a2(self, _6a80587238b1: _fa98628c1f41[_322d4739e29e]) -> _e332d14bb7bd._a5f0283b67d8:
        _6bd6b01985c4 = _e332d14bb7bd._8d4e27c2b1c8(_6a80587238b1)
        return _6a80587238b1 / _6bd6b01985c4 if _6bd6b01985c4 != 0 else _e332d14bb7bd._2e3465a670b6(_6a80587238b1)

    def _1f6f18fc0557(self, _1845aabd52ac: _635d43130f39) -> _2d0498a708fb[_fa98628c1f41[_322d4739e29e], _635d43130f39]:
        _c7ecd7166038 = _8d4e27c2b1c8(_920278f47f32["lang_samples"] for _920278f47f32 in _1845aabd52ac._f4f1704c955c())
        for _0f4d60105b72, _b95899696a06 in _1845aabd52ac._5bb011f9c5bf():
            _f473a69018b8 = _b95899696a06["lang_samples"]
            if _f473a69018b8 > 0:
                _5f4dbaae654d = _c7ecd7166038 / (_f473a69018b8 * _728349aff8c6(_1845aabd52ac))
            else:
                _5f4dbaae654d = 0.0
            _1845aabd52ac[_0f4d60105b72]["lang_weight"] = _5f4dbaae654d
        _670a37877d7a = [_920278f47f32["lang_weight"] for _920278f47f32 in _1845aabd52ac._f4f1704c955c()]
        # Update stored lang weights (keeps original behavior)
        for _c5d8cf854af0, (_0f4d60105b72, _b95899696a06) in _91d60e0fd5ed(_1845aabd52ac._5bb011f9c5bf()):
            _b95899696a06["lang_weight"] = _670a37877d7a[_c5d8cf854af0]
        return _670a37877d7a, _1845aabd52ac

    def _24cceea7f9c6(self, _3ca914db3c53: _3a7dc6aafab4, _1bfdb1d1bcb8: _2bbbbeafa9e5) -> _2d0498a708fb[_635d43130f39, _635d43130f39]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _1845aabd52ac = {}
        _670a37877d7a = {}
        if os._4b66be4bcc92._ac849abd710b(_3ca914db3c53):
            with _cad843b356f8(_3ca914db3c53, "r", _47bff64d3029="utf8") as _b4d012636e91:
                _248d6b3847a3 = json._52ec94010286(_b4d012636e91)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _1845aabd52ac = {
                    (_322d4739e29e(_928ec8c88c22) if "." in _928ec8c88c22 else _c3d7ab130f30(_928ec8c88c22)): _8bb07eedbd55
                    for _928ec8c88c22, _8bb07eedbd55 in _248d6b3847a3._5bb011f9c5bf()
                }

        if _1bfdb1d1bcb8:
            _1845aabd52ac = self._5e948b941a7c(_6fc9dd04f187=_1845aabd52ac)
            _670a37877d7a, _1845aabd52ac = self._39bb27d921b2(_1845aabd52ac=_1845aabd52ac)
            with _cad843b356f8(_3ca914db3c53, "w", _47bff64d3029="utf8") as _20f08a31bd43:
                json._c5b6a845077b(_1845aabd52ac, _20f08a31bd43, _78292494df3a=2)

        return _1845aabd52ac, _670a37877d7a

    def _06a9b7ae3a66(self) -> _fa98628c1f41[_c3d7ab130f30]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._ac4beab55287(_0f4d60105b72) for _0f4d60105b72 in self._7af015d4a0e9] if _e9ee941234e3(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _4be9cdf3c949(self, _741a853a806f: _322d4739e29e) -> _c3d7ab130f30:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _c3d7ab130f30(self._d3ce24d3dbd5 * _741a853a806f)

    @_e036071b8f39
    def _3c290b30549e(_c9433b3cd352: _3a7dc6aafab4) -> _2bbbbeafa9e5:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _b20ec6fb55d3
        for _cbb8e38312be in _c9433b3cd352:
            if "ARABIC" not in _b20ec6fb55d3._de576f485a12(_cbb8e38312be, ""):
                return _f631985d3e6e
        return _109b554a057f

    @_e036071b8f39
    def _024643f31c3e(_8400de368e65: _3a7dc6aafab4) -> _3a7dc6aafab4:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _d96135af9daf._4cce500d98e5(_8400de368e65):
            _104d430d91df = _8400de368e65._f7672f9849c4()._f2fae967a4a5()
            _b92f4a5b6b33 = " "._3d1a81c4cf8c(_81e8bd0c367f(_104d430d91df))
            return _b92f4a5b6b33
        return _8400de368e65

    def _07ddc0ece1d0(self, _d1d876b34deb: _3a7dc6aafab4, _2e7ddba88dec: _3a7dc6aafab4) -> _322d4739e29e:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _c7a661fcc721(_c2e74c58c90b, _d1d876b34deb, _2e7ddba88dec)._d81b74c9993b()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_e036071b8f39
    def _a334996c12d2(_d4f48794e4c5) -> _2d0498a708fb[_fa98628c1f41[_635d43130f39], _c3d7ab130f30]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import time
        _c3017315327c = time.time()
        _89e2c2ac94ca, _3e54312dfb4f, _5c2e6aee2337, _75e4f48be822, _1bfdb1d1bcb8, _9545b4586e00 = _d4f48794e4c5
        _d5c955e85e97 = _d96135af9daf._d280c94131ac
        _d9289396287a = 0
        _d91c446d1b1d = _d5c955e85e97._70448a9d1e92
        _ed847a68fa8c: _fa98628c1f41[_635d43130f39] = []

        # Clean inputs and prepare per-word lists
        _63ca7e87f733 = [_9ce962808cb7._f7672f9849c4() for _9ce962808cb7 in _89e2c2ac94ca]
        _a242849581b5 = [_1f450e2fdac0._f7672f9849c4() for _1f450e2fdac0 in _3e54312dfb4f]
        _32c054109b37 = [_c9433b3cd352._f2fae967a4a5() if _c9433b3cd352 else ["<empty>"] for _c9433b3cd352 in _63ca7e87f733]
        _f0aa255528bd = []
        for _ddab1b7bc8f3, _7ead73bacfc7 in _afac324b76e3(_32c054109b37, _3e54312dfb4f):
            _00c4f1046e7a = _7ead73bacfc7 if _3da3a21910de(_7ead73bacfc7, _be0dce0b3aaf) else (_7ead73bacfc7._f7672f9849c4()._f2fae967a4a5() if _7ead73bacfc7._f7672f9849c4() else ["<empty>"])
            if _728349aff8c6(_00c4f1046e7a) == 1:
                _00c4f1046e7a = [_00c4f1046e7a[0]] * _728349aff8c6(_ddab1b7bc8f3)
            elif _728349aff8c6(_00c4f1046e7a) != _728349aff8c6(_ddab1b7bc8f3):
                _00c4f1046e7a = _00c4f1046e7a[:_728349aff8c6(_ddab1b7bc8f3)] if _728349aff8c6(_00c4f1046e7a) > _728349aff8c6(_ddab1b7bc8f3) else _00c4f1046e7a + [_00c4f1046e7a[-1]] * (_728349aff8c6(_ddab1b7bc8f3) - _728349aff8c6(_00c4f1046e7a))
            _f0aa255528bd._e2851be0edd0(_00c4f1046e7a)

        # Flatten all words for a single tokenizer call (faster)
        _0fa996167e61 = _be0dce0b3aaf(_7767a1728306(*_32c054109b37))
        _2c486d241d8e = time.time()
        try:
            _40c342cdcf01 = _d5c955e85e97(_0fa996167e61, _94700bcdb6fb=_f631985d3e6e, _0b40c7c9b917=_f631985d3e6e, _7f8fa44969ff=_f631985d3e6e)
        except _4f59878d84dd as _129c1f04677f:
            _228c1675c383(f"Tokenization error: {_129c1f04677f}")
            _40c342cdcf01 = {"input_ids": [[0] for _ in _0fa996167e61]}
        # build word token info per sentence
        _4d28e0cc78e9 = 0
        _5d7ff16d3f79 = []
        for _ddab1b7bc8f3 in _32c054109b37:
            _34f14d059cd6 = _728349aff8c6(_ddab1b7bc8f3)
            _bde184c1f073 = [(_c5d8cf854af0, _40c342cdcf01["input_ids"][_4d28e0cc78e9 + _c5d8cf854af0], _728349aff8c6(_40c342cdcf01["input_ids"][_4d28e0cc78e9 + _c5d8cf854af0])) for _c5d8cf854af0 in _7a50ffe3b168(_34f14d059cd6)]
            _5d7ff16d3f79._e2851be0edd0(_bde184c1f073)
            _4d28e0cc78e9 += _34f14d059cd6

        # chunk each sentence into token windows
        for _6bbdd144fcf2, (_ddab1b7bc8f3, _836870d6d952, _00c4f1046e7a) in _91d60e0fd5ed(_afac324b76e3(_32c054109b37, _5d7ff16d3f79, _f0aa255528bd)):
            _35240ccb4fa2 = _9545b4586e00 + _6bbdd144fcf2
            _30465d7ed3d1 = 0
            if _ddab1b7bc8f3 == ["<empty>"]:
                _fb13d793f8fd = [0] * _5c2e6aee2337
                _ed847a68fa8c._e2851be0edd0({
                    "sample_id": _35240ccb4fa2,
                    "chunk_id": _30465d7ed3d1,
                    "input_ids": _fb13d793f8fd,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _c5d8cf854af0 = 0
            _77a4dd28a493 = _728349aff8c6(_836870d6d952)
            _1f3e49fb1331 = []
            while _c5d8cf854af0 < _77a4dd28a493:
                _95035cdad5ed = 0
                _7ed504a6288c = []
                _6af5e12306d6 = []
                _38be964aea38 = []
                _b5184d4ad59d = _c5d8cf854af0
                while _b5184d4ad59d < _77a4dd28a493:
                    _f70568c10a40, _23e0af9c6156, _d4a6f2310274 = _836870d6d952[_b5184d4ad59d]
                    _447374c1c0a6 = _00c4f1046e7a[_f70568c10a40] if _f70568c10a40 < _728349aff8c6(_00c4f1046e7a) else _00c4f1046e7a[-1] if _00c4f1046e7a else "<unknown>"
                    if _d4a6f2310274 > _5c2e6aee2337 and not _7ed504a6288c:
                        _7ed504a6288c += _23e0af9c6156[:_5c2e6aee2337]
                        _6af5e12306d6._e2851be0edd0(_447374c1c0a6)
                        _38be964aea38._e2851be0edd0(_f70568c10a40)
                        _b5184d4ad59d += 1
                        break
                    if _95035cdad5ed + _d4a6f2310274 > _5c2e6aee2337 and _7ed504a6288c:
                        break
                    _7ed504a6288c += _23e0af9c6156
                    _6af5e12306d6._e2851be0edd0(_447374c1c0a6)
                    _d9289396287a += 1
                    _38be964aea38._e2851be0edd0(_b5184d4ad59d)
                    _95035cdad5ed += _d4a6f2310274
                    _b5184d4ad59d += 1

                if not _7ed504a6288c:
                    # fallback: take token prefix to avoid infinite loop
                    _7ed504a6288c = _836870d6d952[_c5d8cf854af0][1][:_5c2e6aee2337] or [0]
                    _6af5e12306d6 = [_00c4f1046e7a[_c5d8cf854af0] if _c5d8cf854af0 < _728349aff8c6(_00c4f1046e7a) else _00c4f1046e7a[-1] if _00c4f1046e7a else "<unknown>"]
                    _38be964aea38 = [_c5d8cf854af0]
                    _d9289396287a += 1
                    _c5d8cf854af0 += 1

                # pad tokens to fixed length
                if _728349aff8c6(_7ed504a6288c) < _5c2e6aee2337:
                    _7ed504a6288c += [_d91c446d1b1d] * (_5c2e6aee2337 - _728349aff8c6(_7ed504a6288c))

                _1f3e49fb1331._e2851be0edd0({
                    "sample_id": _35240ccb4fa2,
                    "chunk_id": _30465d7ed3d1,
                    "input_ids": _7ed504a6288c,
                    "labels": _6af5e12306d6,
                    "word_positions": _38be964aea38,
                    "num_chunks": 1
                })
                _30465d7ed3d1 += 1

                if _b5184d4ad59d >= _77a4dd28a493:
                    break

                # stride with overlap (in words)
                _0c919a7f5fc5 = _728349aff8c6(_38be964aea38)
                _448a908e9cd1 = _c3d7ab130f30(_75e4f48be822 * _0c919a7f5fc5)
                _448a908e9cd1 = _55e2b8a3ae72(_448a908e9cd1, _0c919a7f5fc5 - 1) if _0c919a7f5fc5 > 1 else 0
                _49e7d279b8e4 = _b5184d4ad59d - _448a908e9cd1
                if _49e7d279b8e4 <= _c5d8cf854af0:
                    _49e7d279b8e4 = _c5d8cf854af0 + 1
                _c5d8cf854af0 = _49e7d279b8e4

            _4520225425c0 = _728349aff8c6(_1f3e49fb1331)
            for _5d5d6eddbdb5 in _1f3e49fb1331:
                _5d5d6eddbdb5["num_chunks"] = _4520225425c0
            _ed847a68fa8c._dfdfb933c675(_1f3e49fb1331)

            if not _d96135af9daf._4e4ba20bd649 and not _1bfdb1d1bcb8 and _4520225425c0 > 1:
                _228c1675c383(f"[DEBUG] sample_id={_35240ccb4fa2}", _8bae6a092797=_109b554a057f)
                _d96135af9daf._4e4ba20bd649 = _109b554a057f

        # Timing/logging suppressed to preserve original behavior
        return _ed847a68fa8c, _d9289396287a

    @_e036071b8f39
    def _1d0751ea0695(_d4f48794e4c5) -> _2d0498a708fb[_fa98628c1f41[_635d43130f39], _c3d7ab130f30]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import time
        _c3017315327c = time.time()
        (_1daa2583ba08, _89e2c2ac94ca, _3e54312dfb4f, _5c2e6aee2337, _75e4f48be822, _c76caf436db5, _9545b4586e00) = _d4f48794e4c5
        _d5c955e85e97 = _d96135af9daf._d280c94131ac
        _d91c446d1b1d = _d5c955e85e97._70448a9d1e92 or _d5c955e85e97._330a4e2b0810
        _896c810267c2 = _d5c955e85e97._330a4e2b0810
        _ca799f7b3477 = -100

        # Chat-ish prefixes used in dataset construction
        # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
        # "Identify the language of every word and reply with space-separated codes only.\n"
        # "Do not include any explanation or extra text.\n")
        # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _03d7f848de3b = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
        "Identify the language of every word and reply with space-separated codes only.\n"
        "Do not include any explanation or extra text.\n")
        _91b10850555e = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        _b1ed9debe191 = _d5c955e85e97._ab9d1c073b86(_1daa2583ba08, _94700bcdb6fb=_f631985d3e6e)
        _ccdaafa6fa2f = _d5c955e85e97._ab9d1c073b86(_03d7f848de3b, _94700bcdb6fb=_f631985d3e6e)
        _554f8b3bf74c = _d5c955e85e97._ab9d1c073b86(_91b10850555e, _94700bcdb6fb=_f631985d3e6e)
        _29f682b586c5 = _d5c955e85e97._ab9d1c073b86(" ", _94700bcdb6fb=_f631985d3e6e)
        _0d5fea3d1fb5 = _b1ed9debe191 + _ccdaafa6fa2f
        _476edaeb16ed = _554f8b3bf74c
        _47500877a10d = 1
        _0d5eaae7c96c = _728349aff8c6(_0d5fea3d1fb5) + _728349aff8c6(_476edaeb16ed) + _47500877a10d

        _ed847a68fa8c: _fa98628c1f41[_635d43130f39] = []
        _d9289396287a = 0

        # Preprocess lines into words lists and align labels to words
        _63ca7e87f733 = [_9ce962808cb7._f7672f9849c4() for _9ce962808cb7 in _89e2c2ac94ca]
        _a242849581b5 = [_1f450e2fdac0._f7672f9849c4() for _1f450e2fdac0 in _3e54312dfb4f]
        _32c054109b37 = []
        _fc46e9e16cdb = []
        for _90db1ef7f76f, _7ead73bacfc7 in _afac324b76e3(_63ca7e87f733, _3e54312dfb4f):
            _ddab1b7bc8f3 = _90db1ef7f76f._f2fae967a4a5() if _90db1ef7f76f else ["<empty>"]
            _c2f946c7e08b = _7ead73bacfc7 if _3da3a21910de(_7ead73bacfc7, _be0dce0b3aaf) else (_7ead73bacfc7._f7672f9849c4()._f2fae967a4a5() if _7ead73bacfc7._f7672f9849c4() else ["<empty>"])
            if _728349aff8c6(_c2f946c7e08b) == 1:
                _c2f946c7e08b = [_c2f946c7e08b[0]] * _728349aff8c6(_ddab1b7bc8f3)
            elif _728349aff8c6(_c2f946c7e08b) != _728349aff8c6(_ddab1b7bc8f3):
                _c2f946c7e08b = _c2f946c7e08b[:_728349aff8c6(_ddab1b7bc8f3)] if _728349aff8c6(_c2f946c7e08b) > _728349aff8c6(_ddab1b7bc8f3) else _c2f946c7e08b + [_c2f946c7e08b[-1]] * (_728349aff8c6(_ddab1b7bc8f3) - _728349aff8c6(_c2f946c7e08b))
            _32c054109b37._e2851be0edd0(_ddab1b7bc8f3)
            _fc46e9e16cdb._e2851be0edd0(_c2f946c7e08b)

        # Flatten words for efficient tokenization
        _0fa996167e61 = _be0dce0b3aaf(_7767a1728306(*_32c054109b37))
        _a84d266e7835 = _be0dce0b3aaf(_7767a1728306(*_fc46e9e16cdb))
        _5d011959ee2f = _d5c955e85e97(_0fa996167e61, _94700bcdb6fb=_f631985d3e6e, _0b40c7c9b917=_f631985d3e6e)["input_ids"]
        _d955157b8646 = _d5c955e85e97(_a84d266e7835, _94700bcdb6fb=_f631985d3e6e, _0b40c7c9b917=_f631985d3e6e)["input_ids"]

        # Build per-line token info
        _4d28e0cc78e9 = 0
        _cd94038a3077 = 0
        _5d7ff16d3f79 = []
        _e90541457370 = []
        for _ddab1b7bc8f3, _c2f946c7e08b in _afac324b76e3(_32c054109b37, _fc46e9e16cdb):
            _34f14d059cd6 = _728349aff8c6(_ddab1b7bc8f3)
            _5924ffd166de = _728349aff8c6(_c2f946c7e08b)
            if _ddab1b7bc8f3 == ["<empty>"] or _c2f946c7e08b == ["<empty>"]:
                _5d7ff16d3f79._e2851be0edd0([(_ddab1b7bc8f3[0], [0], 1)])
                _e90541457370._e2851be0edd0([(_c2f946c7e08b[0], [0], 1)])
                continue
            try:
                _bde184c1f073 = [(_e3f95637fc5d, _5d011959ee2f[_4d28e0cc78e9 + _c5d8cf854af0], _728349aff8c6(_5d011959ee2f[_4d28e0cc78e9 + _c5d8cf854af0]) if _3da3a21910de(_5d011959ee2f[_4d28e0cc78e9 + _c5d8cf854af0], _be0dce0b3aaf) else 1) for _c5d8cf854af0, _e3f95637fc5d in _91d60e0fd5ed(_ddab1b7bc8f3)]
                _7dcc25af04af = [(_e3f95637fc5d, _d955157b8646[_cd94038a3077 + _c5d8cf854af0], _728349aff8c6(_d955157b8646[_cd94038a3077 + _c5d8cf854af0]) if _3da3a21910de(_d955157b8646[_cd94038a3077 + _c5d8cf854af0], _be0dce0b3aaf) else 1) for _c5d8cf854af0, _e3f95637fc5d in _91d60e0fd5ed(_c2f946c7e08b)]
            except _04302af55b3e:
                # On tokenization mismatches, fallback safely
                _5d7ff16d3f79._e2851be0edd0([(_ddab1b7bc8f3[0], [0], 1)])
                _e90541457370._e2851be0edd0([(_c2f946c7e08b[0], [0], 1)])
                _4d28e0cc78e9 += _34f14d059cd6
                _cd94038a3077 += _5924ffd166de
                continue
            _5d7ff16d3f79._e2851be0edd0(_bde184c1f073)
            _e90541457370._e2851be0edd0(_7dcc25af04af)
            _4d28e0cc78e9 += _34f14d059cd6
            _cd94038a3077 += _5924ffd166de

        # Build chunks per sentence
        for _6bbdd144fcf2, (_ddab1b7bc8f3, _836870d6d952, _e3a9b3d68814) in _91d60e0fd5ed(_afac324b76e3(_32c054109b37, _5d7ff16d3f79, _e90541457370)):
            _35240ccb4fa2 = _9545b4586e00 + _6bbdd144fcf2
            _30465d7ed3d1 = 0
            _9e17c5588e12 = [_28a829c28727[0] for _28a829c28727 in _e3a9b3d68814]

            if _ddab1b7bc8f3 == ["<empty>"]:
                _fb13d793f8fd = _0d5fea3d1fb5 + [0] + _476edaeb16ed + [_896c810267c2]
                _ef507f9aff7f = [_ca799f7b3477] * _728349aff8c6(_fb13d793f8fd)
                _0e8e29f8fbb6 = _5c2e6aee2337 - _728349aff8c6(_fb13d793f8fd)
                if _0e8e29f8fbb6 > 0:
                    _fb13d793f8fd += [_d91c446d1b1d] * _0e8e29f8fbb6
                    _ef507f9aff7f += [_ca799f7b3477] * _0e8e29f8fbb6
                _ed847a68fa8c._e2851be0edd0({
                    "lang_codes": ["<empty>"],
                    "sample_id": _35240ccb4fa2,
                    "chunk_id": _30465d7ed3d1,
                    "word_positions": [0],
                    "input_ids": _fb13d793f8fd,
                    "labels": _ef507f9aff7f,
                    "prompt_len": _728349aff8c6(_0d5fea3d1fb5) + 1 + _728349aff8c6(_476edaeb16ed),
                    "chunk_words": ["<empty>"],
                    "chunk_labels": ["<empty>"],
                    "num_chunks": 1
                })
                continue

            _c5d8cf854af0 = 0
            _77a4dd28a493 = _728349aff8c6(_836870d6d952)
            _fbb91984e39f = -1
            _1f3e49fb1331 = []
            while _c5d8cf854af0 < _77a4dd28a493:
                _95035cdad5ed = _0d5eaae7c96c
                _d01aa06bd751 = []
                _1bd16cebc2a4 = []
                _38be964aea38 = []
                _bc26c546a94c = []
                _d820ee6ba962 = []
                _6af5e12306d6 = []
                _b5184d4ad59d = _c5d8cf854af0
                while _b5184d4ad59d < _77a4dd28a493:
                    _, _d5b1d59fb360, _34f14d059cd6 = _836870d6d952[_b5184d4ad59d]
                    _724f782edd39, _34065b7b959c, _5924ffd166de = _e3a9b3d68814[_b5184d4ad59d]
                    _c22a2a75440c = _728349aff8c6(_29f682b586c5) if _b5184d4ad59d < _77a4dd28a493 - 1 else 0
                    # choose conservative word_total so both streams fit
                    _d0ec0bda4fbd = _08525bac259d(_34f14d059cd6, _5924ffd166de) + _c22a2a75440c
                    if _95035cdad5ed + _d0ec0bda4fbd > _5c2e6aee2337 * 0.9:
                        break

                    # append inputs and spaces
                    _d01aa06bd751 += _d5b1d59fb360 if _3da3a21910de(_d5b1d59fb360, _be0dce0b3aaf) else [_d5b1d59fb360]
                    if _c22a2a75440c:
                        _d01aa06bd751 += _29f682b586c5

                    # append labels and word_positions
                    if _5924ffd166de:
                        _1bd16cebc2a4 += _34065b7b959c if _3da3a21910de(_34065b7b959c, _be0dce0b3aaf) else [_34065b7b959c]
                        _38be964aea38 += [_b5184d4ad59d] * _5924ffd166de
                    if _c22a2a75440c:
                        _1bd16cebc2a4 += _29f682b586c5
                        _38be964aea38 += [-1] * _c22a2a75440c

                    _bc26c546a94c._e2851be0edd0(_724f782edd39)
                    _d820ee6ba962._e2851be0edd0(_ddab1b7bc8f3[_b5184d4ad59d])
                    _6af5e12306d6._e2851be0edd0(_724f782edd39)
                    _d9289396287a += _728349aff8c6(_ddab1b7bc8f3[_b5184d4ad59d])
                    _95035cdad5ed += _d0ec0bda4fbd
                    _b5184d4ad59d += 1

                if not _d01aa06bd751:
                    _c5d8cf854af0 += 1
                    continue

                _c070bdc0ec32 = _d01aa06bd751
                _2817803313fb = _1bd16cebc2a4
                _8a4e2f04ebd0 = _728349aff8c6(_0d5fea3d1fb5) + _728349aff8c6(_c070bdc0ec32) + _728349aff8c6(_476edaeb16ed)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                if _c76caf436db5 is _f631985d3e6e:
                    _fb13d793f8fd = _0d5fea3d1fb5 + _c070bdc0ec32 + _476edaeb16ed + _2817803313fb + [_896c810267c2]
                    _ef507f9aff7f = [_ca799f7b3477] * _8a4e2f04ebd0 + _2817803313fb + [_ca799f7b3477]
                else:
                    _fb13d793f8fd = _0d5fea3d1fb5 + _c070bdc0ec32 + _476edaeb16ed + [_896c810267c2]
                    _ef507f9aff7f = [_ca799f7b3477] * _8a4e2f04ebd0 + _2817803313fb + [_ca799f7b3477]

                # pad to fixed size (inputs appended or prepended depending on test/train)
                _5ceb1267c3e5 = _5c2e6aee2337 - _728349aff8c6(_fb13d793f8fd)
                _88f1f62d8d2d = _5c2e6aee2337 - _728349aff8c6(_ef507f9aff7f)
                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len
                if _5ceb1267c3e5 > 0:
                    if _c76caf436db5:
                        _fb13d793f8fd = [_d91c446d1b1d] * _5ceb1267c3e5 + _fb13d793f8fd
                    else:
                        _fb13d793f8fd += [_d91c446d1b1d] * _5ceb1267c3e5
                if _88f1f62d8d2d > 0:
                    if _c76caf436db5:
                        _ef507f9aff7f = [_ca799f7b3477] * _88f1f62d8d2d + _ef507f9aff7f
                    else:
                        _ef507f9aff7f += [_ca799f7b3477] * _88f1f62d8d2d

                _1f3e49fb1331._e2851be0edd0({
                    "lang_codes": _bc26c546a94c,
                    "sample_id": _35240ccb4fa2,
                    "chunk_id": _30465d7ed3d1,
                    "word_positions": _38be964aea38,
                    "input_ids": _fb13d793f8fd,
                    "labels": _ef507f9aff7f,
                    "prompt_len": _8a4e2f04ebd0,
                    "chunk_words": _d820ee6ba962,
                    "chunk_labels": _6af5e12306d6,
                    "num_chunks": 1
                })
                _30465d7ed3d1 += 1

                if _b5184d4ad59d >= _77a4dd28a493 or _b5184d4ad59d <= _fbb91984e39f:
                    break
                _fbb91984e39f = _b5184d4ad59d
                _e69d2090d109 = _08525bac259d(1, _c3d7ab130f30(_75e4f48be822 * _728349aff8c6(_d820ee6ba962)))
                _c5d8cf854af0 = _b5184d4ad59d - _e69d2090d109 if (_b5184d4ad59d - _e69d2090d109) > _c5d8cf854af0 else _b5184d4ad59d

            _4520225425c0 = _728349aff8c6(_1f3e49fb1331)
            for _5d5d6eddbdb5 in _1f3e49fb1331:
                _5d5d6eddbdb5["num_chunks"] = _4520225425c0
            _ed847a68fa8c._dfdfb933c675(_1f3e49fb1331)

            if not _d96135af9daf._4e4ba20bd649 and not _c76caf436db5 and _4520225425c0 > 1:
                _d96135af9daf._4e4ba20bd649 = _109b554a057f

        return _ed847a68fa8c, _d9289396287a

    # -------------------------
    # File processing & validation
    # -------------------------
    def _6c01ad3cd6e2(self, _48d2959ef499: _3a7dc6aafab4, _9d18f0541bfe: _3a7dc6aafab4, _9545b4586e00: _c3d7ab130f30) -> _2d0498a708fb[_3a7dc6aafab4, _fa98628c1f41[_635d43130f39], _c3d7ab130f30]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _cef1a8d2c58f = []

        with _cad843b356f8(_48d2959ef499, "r", _47bff64d3029="utf8") as _9fd16275e256, _cad843b356f8(_9d18f0541bfe, "r", _47bff64d3029="utf8") as _82096a01fc7c:
            _89e2c2ac94ca = _9fd16275e256._315686266c9c()[1:] if self._0abd8d06f32f else _9fd16275e256._315686266c9c()
            _3e54312dfb4f = _82096a01fc7c._315686266c9c()[1:] if self._0abd8d06f32f else _82096a01fc7c._315686266c9c()

        # sample some share if requested
        _c6430c9921da = _c3d7ab130f30(_728349aff8c6(_89e2c2ac94ca) * self._72af933656c3)
        if _c6430c9921da < _728349aff8c6(_89e2c2ac94ca):
            _28df1f900a01 = _e332d14bb7bd.random._b084b4917193(_728349aff8c6(_89e2c2ac94ca), _c6430c9921da, _78f3275ad6c5=_f631985d3e6e)
            _89e2c2ac94ca = [_89e2c2ac94ca[_c5d8cf854af0] for _c5d8cf854af0 in _28df1f900a01]
            _3e54312dfb4f = [_3e54312dfb4f[_c5d8cf854af0] for _c5d8cf854af0 in _28df1f900a01]

        _0f4d60105b72 = _be0dce0b3aaf({_1f450e2fdac0._f7672f9849c4() for _1f450e2fdac0 in _3e54312dfb4f})[0] if _3e54312dfb4f else "unk"
        self._4bccee266577._28a829c28727(f"Sampled {self._72af933656c3 * 100:.1f}% of {_48d2959ef499}: {_728349aff8c6(_89e2c2ac94ca)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _069f75fd089d(_3dfd45d6c0d5, _a1adfaa106a8):
            _189e0920803a = _fb619a06e487(_3dfd45d6c0d5)
            while _109b554a057f:
                _6cfbaf719c06 = _be0dce0b3aaf(_70d61d2a1c85(_189e0920803a, _a1adfaa106a8))
                if not _6cfbaf719c06:
                    break
                yield _6cfbaf719c06

        _a1adfaa106a8 = 10_000
        if self._78a2f356af1f:
            _7edb87ec08a4 = [
                (self._1daa2583ba08, _df1629533062, _72e2c98cae46, self._d3ce24d3dbd5, 0.25, self._c76caf436db5, _9545b4586e00 + _7176362bb91f * _a1adfaa106a8)
                for _7176362bb91f, (_df1629533062, _72e2c98cae46) in _91d60e0fd5ed(_afac324b76e3(_f8f431274d03(_89e2c2ac94ca, _a1adfaa106a8), _f8f431274d03(_3e54312dfb4f, _a1adfaa106a8)))
            ]
            with _094d0030547b(self._6930a4ab8100) as _718f459f34bb:
                _0f49aa1b11ab = _718f459f34bb._89871bc173a3(_d96135af9daf._4da85e75635f, _7edb87ec08a4)
        else:
            _7edb87ec08a4 = [
                (_df1629533062, _72e2c98cae46, self._d3ce24d3dbd5, 0.5, self._1bfdb1d1bcb8, _9545b4586e00 + _7176362bb91f * _a1adfaa106a8)
                for _7176362bb91f, (_df1629533062, _72e2c98cae46) in _91d60e0fd5ed(_afac324b76e3(_f8f431274d03(_89e2c2ac94ca, _a1adfaa106a8), _f8f431274d03(_3e54312dfb4f, _a1adfaa106a8)))
            ]
            with _094d0030547b(self._6930a4ab8100) as _718f459f34bb:
                _0f49aa1b11ab = _718f459f34bb._89871bc173a3(_d96135af9daf._c15fcbd40b09, _7edb87ec08a4)

        _b8b8e90cb232 = []
        for _ed847a68fa8c, _8799f5da822b in _0f49aa1b11ab:
            _b8b8e90cb232._dfdfb933c675(_ed847a68fa8c)
            self._652ec340498f += _8799f5da822b

        if _b8b8e90cb232:
            _cef1a8d2c58f = _b8b8e90cb232

        return _0f4d60105b72, _cef1a8d2c58f, _728349aff8c6(_89e2c2ac94ca)

    def _d32b57f2da26(self) -> _c2e74c58c90b:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _bbecf0b579a3 = 0

        for _9a32f8d397f7 in os._0f344a35f0f0(self._0c710414852f):
            self._4bccee266577._28a829c28727(f"Now processing {os._4b66be4bcc92._3d1a81c4cf8c(self._0c710414852f, _9a32f8d397f7)} directory.")
            _a340da5c4ee4 = os._4b66be4bcc92._3d1a81c4cf8c(self._0c710414852f, _9a32f8d397f7, "src")
            _0205ae2d0fad = os._4b66be4bcc92._3d1a81c4cf8c(self._0c710414852f, _9a32f8d397f7, "tgt")

            _1f9c5085c5d2 = []
            _02773ec9dac8 = []
            for _48d2959ef499 in os._0f344a35f0f0(_a340da5c4ee4):
                _ef6607b82b48 = _f631985d3e6e
                for _9d18f0541bfe in os._0f344a35f0f0(_0205ae2d0fad):
                    if _48d2959ef499._f2fae967a4a5(".")[0] == _9d18f0541bfe._f2fae967a4a5(".")[0]:
                        _1f9c5085c5d2._e2851be0edd0(_48d2959ef499)
                        _02773ec9dac8._e2851be0edd0(_9d18f0541bfe)
                        _ef6607b82b48 = _109b554a057f
                        break
                if not _ef6607b82b48:
                    self._4bccee266577._28a829c28727(f"Skipping file {_48d2959ef499} since matching label file not found in {_0205ae2d0fad}.")

            _13bfa1a71cb9 = [os._4b66be4bcc92._3d1a81c4cf8c(_a340da5c4ee4, _1f2b5172f74b) for _1f2b5172f74b in _1f9c5085c5d2 if os._4b66be4bcc92._f85e75e81138(os._4b66be4bcc92._3d1a81c4cf8c(_a340da5c4ee4, _1f2b5172f74b))]
            _b88bb9835235 = [os._4b66be4bcc92._3d1a81c4cf8c(_0205ae2d0fad, _1f2b5172f74b) for _1f2b5172f74b in _02773ec9dac8 if os._4b66be4bcc92._f85e75e81138(os._4b66be4bcc92._3d1a81c4cf8c(_0205ae2d0fad, _1f2b5172f74b))]

            if _728349aff8c6(_13bfa1a71cb9) != _728349aff8c6(_b88bb9835235):
                raise _14f0bf43307b(f"Number of files in {_a340da5c4ee4} ({_728349aff8c6(_13bfa1a71cb9)}) does not match {_0205ae2d0fad} ({_728349aff8c6(_b88bb9835235)})")

            for _48d2959ef499, _9d18f0541bfe in _afac324b76e3(_13bfa1a71cb9, _b88bb9835235):
                _efc01b3a3952 = _8d4e27c2b1c8(1 for _ in _cad843b356f8(_48d2959ef499))
                _1b95f6a1f558 = _8d4e27c2b1c8(1 for _ in _cad843b356f8(_9d18f0541bfe))
                _efc01b3a3952 = _efc01b3a3952 - 1 if self._0abd8d06f32f else _efc01b3a3952
                _1b95f6a1f558 = _1b95f6a1f558 - 1 if self._0abd8d06f32f else _1b95f6a1f558

                if _efc01b3a3952 != _1b95f6a1f558:
                    self._4bccee266577._28a829c28727(f"{_efc01b3a3952} lines in {_48d2959ef499} do not match with {_1b95f6a1f558} in {_9d18f0541bfe}, skipping these files")
                    continue

                self._4bccee266577._28a829c28727(f"Processing {_48d2959ef499} and {_9d18f0541bfe} with {_1b95f6a1f558} samples.")
                _0f4d60105b72, _bbfc1d3078e6, _275b6478e945 = self._95467f62375e(_48d2959ef499, _9d18f0541bfe, _9545b4586e00=_bbecf0b579a3)
                _bbecf0b579a3 += _275b6478e945

                self._bbfc1d3078e6._dfdfb933c675(_bbfc1d3078e6)
                if self._1bfdb1d1bcb8:
                    if _0f4d60105b72 not in self._d301858cb552:
                        self._d301858cb552._f6d80ccfeb41({
                            _0f4d60105b72: [{
                                "file_name": os._4b66be4bcc92._56a31926d9b0(_9d18f0541bfe),
                                "samples_before_processing": _1b95f6a1f558,
                                "samples_after_processing": _728349aff8c6(_bbfc1d3078e6)
                            }]
                        })
                    else:
                        self._d301858cb552[_0f4d60105b72]._e2851be0edd0({
                            "file_name": os._4b66be4bcc92._56a31926d9b0(_9d18f0541bfe),
                            "samples_before_processing": _1b95f6a1f558,
                            "samples_after_processing": _728349aff8c6(_bbfc1d3078e6)
                        })
                self._4bccee266577._28a829c28727(f"Files {_48d2959ef499} and {_9d18f0541bfe} have {_728349aff8c6(_bbfc1d3078e6)} samples after processing.")

        # verify dataset integrity
        self._74eb1fbcd486()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _924f5657ade6(self) -> _c2e74c58c90b:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _4d9a0c3b4a38 = self._bbfc1d3078e6
        if not _4d9a0c3b4a38:
            self._4bccee266577._28a829c28727("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _d96ca9b5c135 = [_af2b89b61e4b["sample_id"] for _af2b89b61e4b in _4d9a0c3b4a38]
        _4fef12163920 = _6db5f51123be(_d96ca9b5c135)
        _5ad3c2f08675 = _08525bac259d(_4fef12163920)
        _1df2a99c6afa = (_728349aff8c6(_4fef12163920) == _5ad3c2f08675 + 1)
        self._4bccee266577._28a829c28727(f"[sample_id] unique={_728349aff8c6(_4fef12163920)} max={_5ad3c2f08675} coverage_ok={_1df2a99c6afa} (expect True)")
        if not _1df2a99c6afa:
            _ad2fe40a94c7 = _84cf310b19ac(_6db5f51123be(_7a50ffe3b168(_5ad3c2f08675 + 1)) - _4fef12163920)
            self._4bccee266577._28a829c28727(f" Missing sample_ids: {_ad2fe40a94c7[:20]}{' ...' if _728349aff8c6(_ad2fe40a94c7) > 20 else ''}")
            raise _14f0bf43307b(f"Increase max_seq_len as missing sample_ids detected: {_ad2fe40a94c7[:20]}{' ...' if _728349aff8c6(_ad2fe40a94c7) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _fb7ad4d66460 = [(_af2b89b61e4b["sample_id"], _af2b89b61e4b["chunk_id"]) for _af2b89b61e4b in _4d9a0c3b4a38]
        _e4e8ead49919 = [_928ec8c88c22 for _928ec8c88c22, _8bb07eedbd55 in _39b5a63babd0(_fb7ad4d66460)._5bb011f9c5bf() if _8bb07eedbd55 > 1]
        self._4bccee266577._28a829c28727(f"[(sample_id,chunk_id)] duplicates: {_728349aff8c6(_e4e8ead49919)} (expect 0)")
        if _e4e8ead49919:
            self._4bccee266577._28a829c28727(f" Examples: {_e4e8ead49919[:10]}")
            raise _14f0bf43307b(f"Duplicate (sample_id, chunk_id) pairs detected: {_e4e8ead49919[:10]}")

        # 3) per-sample chunk_id sequentiality
        _3d7238e33242 = _4ce30fbe5bb8(_be0dce0b3aaf)
        for _af2b89b61e4b in _4d9a0c3b4a38:
            _3d7238e33242[_af2b89b61e4b["sample_id"]]._e2851be0edd0(_af2b89b61e4b["chunk_id"])
        _59d038bec6d8 = {}
        for _98e8520c9bca, _23e0af9c6156 in _3d7238e33242._5bb011f9c5bf():
            _12e405c61809 = _84cf310b19ac(_23e0af9c6156)
            _620ffc7eb11a = _be0dce0b3aaf(_7a50ffe3b168(_728349aff8c6(_12e405c61809)))
            if _12e405c61809 != _620ffc7eb11a:
                _59d038bec6d8[_98e8520c9bca] = {"have": _12e405c61809[:20], "expected_prefix": _620ffc7eb11a[:20]}
        self._4bccee266577._28a829c28727(f"[per-sample chunk_id sequence] bad_samples: {_728349aff8c6(_59d038bec6d8)} (expect 0)")
        if _59d038bec6d8:
            _a059d8a43ee2 = _be0dce0b3aaf(_59d038bec6d8._5bb011f9c5bf())[:5]
            for _98e8520c9bca, _28a829c28727 in _a059d8a43ee2:
                self._4bccee266577._28a829c28727(f" sample_id={_98e8520c9bca} have={_28a829c28727['have']} expected_prefix={_28a829c28727['expected_prefix']}")
            raise _14f0bf43307b(f"Non-sequential chunk_id sequences detected for sample_ids: {_be0dce0b3aaf(_59d038bec6d8._4a5828ab4a2f())[:5]}")

        # 4) overall stats reporting
        _67bcae1c0167 = _728349aff8c6(_4fef12163920)
        _40945764dec1 = _728349aff8c6(_4d9a0c3b4a38)
        _4980869ebe39 = _40945764dec1 / _67bcae1c0167 if _67bcae1c0167 > 0 else 0
        self._4bccee266577._28a829c28727(f"[audit] base={_67bcae1c0167} -> chunks={_40945764dec1} (avg {_4980869ebe39:.2f} per sample)")

    @_d1e20fb23dab
    def _258536a15c85(self) -> _c3d7ab130f30:
        """Return number of unique base samples (unique sample_id)."""
        if not _2dcf04750caf(self, "file_data_dict_list", _c2e74c58c90b):
            return 0
        return _728349aff8c6({_c3d7ab130f30(_920278f47f32["sample_id"]) for _920278f47f32 in self._bbfc1d3078e6})

    @_d1e20fb23dab
    def _194124da2e38(self) -> _c3d7ab130f30:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _2dcf04750caf(self, "file_data_dict_list", _c2e74c58c90b):
            return 0

        _fb3fb487d6c2 = _4ce30fbe5bb8(_6db5f51123be)
        for _920278f47f32 in self._bbfc1d3078e6:
            _98e8520c9bca = _c3d7ab130f30(_920278f47f32._370900561a63("sample_id", -1))
            for _ec85488749f4 in _920278f47f32._370900561a63("word_positions", []):
                try:
                    _7742c40a1b31 = _c3d7ab130f30(_ec85488749f4)
                except _4f59878d84dd:
                    continue
                if _7742c40a1b31 >= 0:
                    _fb3fb487d6c2[_98e8520c9bca]._2e24403f03a4(_7742c40a1b31)

        return _8d4e27c2b1c8(_728349aff8c6(_1bb7d507c2ba) for _1bb7d507c2ba in _fb3fb487d6c2._f4f1704c955c())
