# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import math
import os
import json
import random
import re
from itertools import _fd556e9182b5, _b79c3ffd441d
from collections import _3fe4029d83b9, _b565bd8b9ef3
from _7552e36105f5 import _7de42857eb7d
from _fd14b931dbac._9aa416a36379 import _1c89ad0c6689
from typing import _508d2a060708, _5d1f7246c52f, _fe317f785f5d

import _63aaf12b83dc as _e133289597c7
import _3d3935f367c8
from _3d3935f367c8._95984d6854b7._96f6ad10105d import _23dabaa43cf5
from _fccdac1ec8ed import _8f95d135338b


class _10de0df27523(_23dabaa43cf5):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _7cc5bb79eb92 = _1d4965d3cd35  # class-level tokenizer (set on __init__)
    _dcea1da1005f = _a6de65e7b346
    _220b968bb60a = {}
    def _c6a1ef442882(
        self,
        _383bbaf2b542: _901b8c763fb2,
        _baafecd54e0c: _28824264040d,
        _61b121af4c73: _508d2a060708,
        _73ad0b27950a: _5d7afa179e83,
        _f97e35d26751: _901b8c763fb2,
        _3622c3f4fc5c: _8f95d135338b,
        _6d873d8c8332: _28824264040d,
        _3b4cc1a500c1: _28824264040d,
        _c40da6dde6c8: _5a5f545d03f2 = 1.0,
        _8ed8b544225c: _5d7afa179e83 = 2,
        _71eda01799eb: _5d7afa179e83 = 20,
        _560405d0861c: _28824264040d = _a6de65e7b346,
        _2279bd194baa: _901b8c763fb2 = _1d4965d3cd35,
        _9ae9fba68afe: _901b8c763fb2 = _1d4965d3cd35,
        _b9025f347516: _901b8c763fb2 = _1d4965d3cd35,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _dad2aee93381()._595152680925()

        # Deterministic behavior
        _3d3935f367c8._536d8f88f225(_71eda01799eb)
        if _3d3935f367c8._0b685d4d9c4a._739ee369d520():
            _3d3935f367c8._0b685d4d9c4a._a50691543175(_71eda01799eb)
        random._d9496e4d87be(_71eda01799eb)
        _e133289597c7.random._d9496e4d87be(_71eda01799eb)

        # Basic parameters & bookkeeping
        self._3622c3f4fc5c = _3622c3f4fc5c
        self._6d873d8c8332 = _6d873d8c8332
        self._3b4cc1a500c1 = _3b4cc1a500c1
        self._560405d0861c = _560405d0861c
        self._2279bd194baa = _2279bd194baa
        self._9ae9fba68afe = _9ae9fba68afe
        self._b9025f347516 = _b9025f347516
        self._baafecd54e0c = _baafecd54e0c
        self._383bbaf2b542 = _383bbaf2b542
        self._73ad0b27950a = _73ad0b27950a
        self._f01bfb029712 = 0
        self._c40da6dde6c8 = _c40da6dde6c8
        self._8ed8b544225c = _8ed8b544225c
        self._e876cf442a5a = -100

        # Tokenizer handling
        if _560405d0861c:
            _61b121af4c73._ddd63406e05d = "left"
        _663dd22ba3ac._7cc5bb79eb92 = _61b121af4c73
        self._d66262f7b026 = _61b121af4c73
        if self._560405d0861c:
            # preserve earlier code's fallback pad id (kept intentionally)
            # if not self.tokenizer.pad_token_id:
            #     self.tokenizer.pad_token_id = 128004
    
            # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
            #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
            #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
            #     print(f"Added padding token  <PAD> with (id: {tid})")
            
            if not _61b121af4c73._8b6a38036769:
                _61b121af4c73._670ee3c7db03(["_P"], _2d79bd6fedf6=_a6de65e7b346)
                _0d745736788a = _61b121af4c73._ea774017d46a("_P")
                _61b121af4c73._8b6a38036769 = _0d745736788a
                _555b364167c9(f"Added padding token  _P with (id: {_0d745736788a})")

        # lang_codes
        self._9cbd84d615fb = []
        
        # storage filled by _validate_and_load_file_data
        self._b7081b77aea7: _5d1f7246c52f[_ac44143b82bf] = []
        self._ddf4b2e49cc4 = {}

        # Load and process files; then derive classes/weights
        self._7cb2e90b8e12()
        self._bf11bf1e3582, self._0af250580d7a = self._7f12ef4c0669(_f97e35d26751, _6d873d8c8332)
        

    def _cf7719cd5c20(self) -> _5d7afa179e83:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _3d3550fa73b5(self._b7081b77aea7)

    def _e87e5194bbdb(self, _d430932e74a9: _5d7afa179e83) -> _ac44143b82bf:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _0df193490e8b = self._b7081b77aea7[_d430932e74a9]
        _6f15042bfe0a = _0df193490e8b._a231624e36ee("lang_code", "unk")
        _30f88d213602 = _0df193490e8b["input_ids"]
        _84e8bde4332f = _0df193490e8b["labels"]
        _3f0e14a4ece1 = _0df193490e8b._a231624e36ee("word_positions", [])
        _abfdbcac51cb = _0df193490e8b["num_chunks"]
        _d209f2fec0c4 = _0df193490e8b._a231624e36ee("sample_id", _d430932e74a9)
        _46e930634904 = _0df193490e8b._a231624e36ee("chunk_id", 0)
        _52321de29c67 = _0df193490e8b._a231624e36ee("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _84e8bde4332f = [
            self._e876cf442a5a
            if _756313482b47 is _1d4965d3cd35
            else _5d7afa179e83(_756313482b47) if _a90ac2038707(_756313482b47, _901b8c763fb2) and _756313482b47._b92fd092a4d8("-")._30b00909f73c()
            else _756313482b47
            for _756313482b47 in _84e8bde4332f
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._560405d0861c:
            _7a924307a68c = [
                self._f59075ab3465(_756313482b47) if _a90ac2038707(_756313482b47, _901b8c763fb2) else _756313482b47
                for _756313482b47 in _84e8bde4332f
            ]
            _b1debd9c686e = _3d3550fa73b5(_7a924307a68c)
            _4a1545946ec5 = _b8e778a9db72(0, self._73ad0b27950a - _b1debd9c686e)
            _7a924307a68c = _7a924307a68c + [self._e876cf442a5a] * _4a1545946ec5
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _7a924307a68c = _84e8bde4332f

        return {
            "lang_code": _6f15042bfe0a,
            "input_ids": _3d3935f367c8._29cf8da7aec6(_30f88d213602, _77bfcc867031=_3d3935f367c8._350a98962ea5),
            "labels": _3d3935f367c8._29cf8da7aec6(_7a924307a68c, _77bfcc867031=_3d3935f367c8._350a98962ea5),
            "sample_id": _d209f2fec0c4,
            "chunk_id": _46e930634904,
            "word_positions": _3f0e14a4ece1,
            "prompt_len": _52321de29c67,
            "num_chunks": _abfdbcac51cb,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _f854279dba7f(self, _6f15042bfe0a: _901b8c763fb2) -> _5d7afa179e83:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _f857ac0cce7c, _865633f16f35 in self._bf11bf1e3582._35641697bd5f():
            if _865633f16f35["lang_code"] == _901b8c763fb2(_6f15042bfe0a)._cf99a6a1aeea():
                return _f857ac0cce7c
        return self._bf11bf1e3582._a231624e36ee("unk", {})._a231624e36ee("id", -1)

    def _7cbdfe6e0887(self, _3cc9492d7b97: _5d7afa179e83) -> _901b8c763fb2:
        """Reverse mapping; assumes class_id present."""
        return self._bf11bf1e3582[_3cc9492d7b97]["lang_code"]

    def _e9386dabf33f(self) -> _5d7afa179e83:
        return _3d3550fa73b5(self._bf11bf1e3582)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _1ef8b583c825(self, _0f8361da3c0f: _ac44143b82bf) -> _ac44143b82bf:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _ebe687b44123 = re._fc7b34de7991(r"[^\d\s]+")  # tokens with non-digit characters
        _9258d3fb9c8b = _3fe4029d83b9()

        if self._560405d0861c:
            _6b7f448bb695 = []
            for _e02c2659728d in self._b7081b77aea7:
                _3939d73b0d40 = _e02c2659728d._a231624e36ee("labels", []) if _a90ac2038707(_e02c2659728d, _ac44143b82bf) else (_e02c2659728d[1] if _a90ac2038707(_e02c2659728d, _13957ac14ff8) and _3d3550fa73b5(_e02c2659728d) > 1 else [])
                _2fde88f957ed = [_4547307edda2 for _4547307edda2 in _3939d73b0d40 if _4547307edda2 != self._e876cf442a5a]
                if _2fde88f957ed:
                    _6b7f448bb695._80c9bfd7d114(_2fde88f957ed)
            if _6b7f448bb695:
                # decoded_texts = self.tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
                _d512f2e6bbfc = [
                    _756313482b47._741bc1ecfc05("||", " ")._cf99a6a1aeea()
                    for _756313482b47 in self._d66262f7b026._0872d5c416c8(_6b7f448bb695, _90b66f871492=_496297332322)
                ]
                # Step 1: Create a reverse lookup dictionary (value -> key)
                _d3d17c16019c = {_3ac104d9250d: _82e68e1dced8 for _82e68e1dced8, _3ac104d9250d in _663dd22ba3ac._220b968bb60a._35641697bd5f()}

                for _e091ca5cf205 in _d512f2e6bbfc:
                    # Step 2: Split the string, replace the values, and join them back
                    _e091ca5cf205 = ' '._ee84420063c1([_d3d17c16019c._a231624e36ee(_fa4257a95807, _fa4257a95807) for _fa4257a95807 in _e091ca5cf205._c857b267e68c()])
                    _1e4428a10a4a = _ebe687b44123._b986c5f24e5f(_e091ca5cf205)
                    _9258d3fb9c8b._281051724e9b(_1e4428a10a4a)
        else:
            for _e02c2659728d in self._b7081b77aea7:
                _3939d73b0d40 = _e02c2659728d._a231624e36ee("labels", [])
                _1e4428a10a4a = [_63ef479411d5._cf99a6a1aeea() for _63ef479411d5 in _3939d73b0d40 if _a90ac2038707(_63ef479411d5, _901b8c763fb2) and _ebe687b44123._85ef771cc112(_63ef479411d5)]
                _9258d3fb9c8b._281051724e9b(_1e4428a10a4a)

        _1eb8c08b9840 = {_3ac104d9250d["lang_code"]: _82e68e1dced8 for _82e68e1dced8, _3ac104d9250d in _0f8361da3c0f._35641697bd5f()}

        for _19514d5bc2d4, _9b0777559c2c in _9258d3fb9c8b._35641697bd5f():
            _19514d5bc2d4 = _19514d5bc2d4._cf99a6a1aeea()
            _a6d4dbe14294 = self._ddf4b2e49cc4._a231624e36ee(_19514d5bc2d4, [])
            _5c4c1e18e343 = _dfe0cb08072a(_e782702a2750._a231624e36ee("samples_after_processing", 0) for _e782702a2750 in _a6d4dbe14294)
            if _19514d5bc2d4 in _1eb8c08b9840:
                _d430932e74a9 = _1eb8c08b9840[_19514d5bc2d4]
                _c9a9a87c9775 = _0f8361da3c0f[_d430932e74a9]
                _697d18aa2864 = _c9a9a87c9775["lang_files"] + _a6d4dbe14294
                _c0e59816827b = _cc29e7e3f832({_e782702a2750["file_name"]: _e782702a2750 for _e782702a2750 in _697d18aa2864}._45aedbb22abc())
                _0f8361da3c0f[_d430932e74a9] = {
                    "lang_code": _19514d5bc2d4,
                    "lang_samples": _c9a9a87c9775["lang_samples"] + _5c4c1e18e343,
                    "lang_files": _c0e59816827b,
                }
            else:
                _ce6cb30a18a7 = _3d3550fa73b5(_0f8361da3c0f)
                _0f8361da3c0f[_ce6cb30a18a7] = {
                    "lang_code": _19514d5bc2d4,
                    "lang_samples": _5c4c1e18e343,
                    "lang_files": _a6d4dbe14294,
                }
                _1eb8c08b9840[_19514d5bc2d4] = _ce6cb30a18a7

        return _0f8361da3c0f

    def _56eddbd28fe9(self, _41d92030cc38: _5d1f7246c52f[_5a5f545d03f2]) -> _e133289597c7._bf4f3c8affba:
        _502bb979ab51 = _e133289597c7._dfe0cb08072a(_41d92030cc38)
        return _41d92030cc38 / _502bb979ab51 if _502bb979ab51 != 0 else _e133289597c7._cc8eac81b12e(_41d92030cc38)

    def _a37379a68530(self, _0183d52deb77: _ac44143b82bf) -> _fe317f785f5d[_5d1f7246c52f[_5a5f545d03f2], _ac44143b82bf]:
        _5c4c1e18e343 = _dfe0cb08072a(_e02c2659728d["lang_samples"] for _e02c2659728d in _0183d52deb77._45aedbb22abc())
        for _6f15042bfe0a, _3cdca2d0e7d0 in _0183d52deb77._35641697bd5f():
            _ca15a3d83eeb = _3cdca2d0e7d0["lang_samples"]
            # # if class_samples > 0:
            # #     class_weight = total_samples / (class_samples * len(classes_dict))
            # # else:
            # #     class_weight = 0.0
            # if class_samples > 0:
            #     class_weight = total_samples / class_samples
            # else:
            #     class_weight = 0.0
            if _ca15a3d83eeb > 0 :
                _296eda80b27a = math._3622c3f4fc5c(_5c4c1e18e343 / _ca15a3d83eeb) + 1.0
            else:
                _296eda80b27a = 0.0
            _0183d52deb77[_6f15042bfe0a]["lang_weight"] = _296eda80b27a
        _0af250580d7a = [_e02c2659728d["lang_weight"] for _e02c2659728d in _0183d52deb77._45aedbb22abc()]
        # Update stored lang weights (keeps original behavior)
        for _7321a9cef882, (_6f15042bfe0a, _3cdca2d0e7d0) in _ceaad99a6b8b(_0183d52deb77._35641697bd5f()):
            _3cdca2d0e7d0["lang_weight"] = _0af250580d7a[_7321a9cef882]
        return _0af250580d7a, _0183d52deb77

    def _f22c1d7d974d(self, _f97e35d26751: _901b8c763fb2, _6d873d8c8332: _28824264040d) -> _fe317f785f5d[_ac44143b82bf, _ac44143b82bf]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _0183d52deb77 = {}
        _0af250580d7a = {}
        if os._ca133139ad80._7452e47650f6(_f97e35d26751):
            with _8632fccf05aa(_f97e35d26751, "r", _18db4f15836c="utf8") as _5cc3066e465f:
                _ea05c3016311 = json._294d0f866e85(_5cc3066e465f)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _0183d52deb77 = {
                    (_5a5f545d03f2(_82e68e1dced8) if "." in _82e68e1dced8 else _5d7afa179e83(_82e68e1dced8)): _3ac104d9250d
                    for _82e68e1dced8, _3ac104d9250d in _ea05c3016311._35641697bd5f()
                }

        if _6d873d8c8332:
            _0183d52deb77 = self._d3daecf3e0f7(_0f8361da3c0f=_0183d52deb77)
            _0af250580d7a, _0183d52deb77 = self._ade600f1f214(_0183d52deb77=_0183d52deb77)
            with _8632fccf05aa(_f97e35d26751, "w", _18db4f15836c="utf8") as _ea305605c9d1:
                json._b92302d4eaf8(_0183d52deb77, _ea305605c9d1, _3b97d90bdd8f=2)

        return _0183d52deb77, _0af250580d7a

    def _d92d40829c86(self) -> _5d1f7246c52f[_5d7afa179e83]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._f59075ab3465(_6f15042bfe0a) for _6f15042bfe0a in self._e0358f78505b] if _e2913188e672(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _15b236e0a08c(self, _0a5ce93f113c: _5a5f545d03f2) -> _5d7afa179e83:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _5d7afa179e83(self._73ad0b27950a * _0a5ce93f113c)

    @_9efdb82f8555
    def _c6584832ec5c(_1b3df4cc961f: _901b8c763fb2) -> _28824264040d:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _653844536ae2
        for _1374b05c0195 in _1b3df4cc961f:
            if "ARABIC" not in _653844536ae2._1f7d6ed7bdc9(_1374b05c0195, ""):
                return _a6de65e7b346
        return _496297332322

    @_9efdb82f8555
    def _9a3b90dcb5b9(_853aa26e8da0: _901b8c763fb2) -> _901b8c763fb2:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _663dd22ba3ac._809ff4b8d1bd(_853aa26e8da0):
            _c030f09dc45a = _853aa26e8da0._cf99a6a1aeea()._c857b267e68c()
            _551af209015f = " "._ee84420063c1(_3382673d7ce7(_c030f09dc45a))
            return _551af209015f
        return _853aa26e8da0

    def _f389730babe8(self, _fecc3ebd222b: _901b8c763fb2, _cebcfb773070: _901b8c763fb2) -> _5a5f545d03f2:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _7de42857eb7d(_1d4965d3cd35, _fecc3ebd222b, _cebcfb773070)._d81c3e4478e0()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_9efdb82f8555
    def _268af58f2c15(_0e7861da9fb0) -> _fe317f785f5d[_5d1f7246c52f[_ac44143b82bf], _5d7afa179e83]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import time
        _9b7579b2cbbf = time.time()
        _ffde35acd689, _6a7d58b3eef4, _fae3b526ad0f, _bfeb455d91e5, _6d873d8c8332, _2868df7ac709 = _0e7861da9fb0
        _d66262f7b026 = _663dd22ba3ac._7cc5bb79eb92
        _01728f9cbd0b = 0
        _6d8fb30cf6b9 = _d66262f7b026._8b6a38036769
        _c89227b6c1fd: _5d1f7246c52f[_ac44143b82bf] = []

        # Clean inputs and prepare per-word lists
        _1c63750db7d8 = [_ba2288704f30._cf99a6a1aeea() for _ba2288704f30 in _ffde35acd689]
        _9af37c484877 = [_756313482b47._cf99a6a1aeea() for _756313482b47 in _6a7d58b3eef4]
        _6ef5a06d68d7 = [_1b3df4cc961f._c857b267e68c() if _1b3df4cc961f else ["<empty>"] for _1b3df4cc961f in _1c63750db7d8]
        _9a926dca125e = []
        for _6ec56fb88250, _5adae9bee0c1 in _42583248704d(_6ef5a06d68d7, _6a7d58b3eef4):
            _324f0bb0e93e = _5adae9bee0c1 if _a90ac2038707(_5adae9bee0c1, _cc29e7e3f832) else (_5adae9bee0c1._cf99a6a1aeea()._c857b267e68c() if _5adae9bee0c1._cf99a6a1aeea() else ["<empty>"])
            if _3d3550fa73b5(_324f0bb0e93e) == 1:
                _324f0bb0e93e = [_324f0bb0e93e[0]] * _3d3550fa73b5(_6ec56fb88250)
            elif _3d3550fa73b5(_324f0bb0e93e) != _3d3550fa73b5(_6ec56fb88250):
                _324f0bb0e93e = _324f0bb0e93e[:_3d3550fa73b5(_6ec56fb88250)] if _3d3550fa73b5(_324f0bb0e93e) > _3d3550fa73b5(_6ec56fb88250) else _324f0bb0e93e + [_324f0bb0e93e[-1]] * (_3d3550fa73b5(_6ec56fb88250) - _3d3550fa73b5(_324f0bb0e93e))
            _9a926dca125e._80c9bfd7d114(_324f0bb0e93e)

        # Flatten all words for a single tokenizer call (faster)
        _6f23a00c266d = _cc29e7e3f832(_fd556e9182b5(*_6ef5a06d68d7))
        _980e4fd30d95 = time.time()
        try:
            _95f1141da13b = _d66262f7b026(_6f23a00c266d, _b15465b2399e=_a6de65e7b346, _24386162b47d=_a6de65e7b346, _85245be4b722=_a6de65e7b346)
        except _cad5c0f8a0cb as _fa8c5eb480c6:
            _555b364167c9(f"Tokenization error: {_fa8c5eb480c6}")
            _95f1141da13b = {"input_ids": [[0] for _ in _6f23a00c266d]}
        # build word token info per sentence
        _60199aeefbdd = 0
        _1783f2f78da7 = []
        for _6ec56fb88250 in _6ef5a06d68d7:
            _c4037ceabeec = _3d3550fa73b5(_6ec56fb88250)
            _a59869fafaef = [(_7321a9cef882, _95f1141da13b["input_ids"][_60199aeefbdd + _7321a9cef882], _3d3550fa73b5(_95f1141da13b["input_ids"][_60199aeefbdd + _7321a9cef882])) for _7321a9cef882 in _6cba3fadb962(_c4037ceabeec)]
            _1783f2f78da7._80c9bfd7d114(_a59869fafaef)
            _60199aeefbdd += _c4037ceabeec

        # chunk each sentence into token windows
        for _849c0e292fe7, (_6ec56fb88250, _9824867cea03, _324f0bb0e93e) in _ceaad99a6b8b(_42583248704d(_6ef5a06d68d7, _1783f2f78da7, _9a926dca125e)):
            _d209f2fec0c4 = _2868df7ac709 + _849c0e292fe7
            _46e930634904 = 0
            if _6ec56fb88250 == ["<empty>"]:
                _30f88d213602 = [0] * _fae3b526ad0f
                _c89227b6c1fd._80c9bfd7d114({
                    "sample_id": _d209f2fec0c4,
                    "chunk_id": _46e930634904,
                    "input_ids": _30f88d213602,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _7321a9cef882 = 0
            _21be4e1b021a = _3d3550fa73b5(_9824867cea03)
            _4df361f4db11 = []
            while _7321a9cef882 < _21be4e1b021a:
                _08c2df92342f = 0
                _00d5075e0445 = []
                _f51bb7c789c5 = []
                _3f0e14a4ece1 = []
                _a708fc356cab = _7321a9cef882
                while _a708fc356cab < _21be4e1b021a:
                    _db8ffac4349c, _43f619396f4e, _dce84354547d = _9824867cea03[_a708fc356cab]
                    _778da70846c3 = _324f0bb0e93e[_db8ffac4349c] if _db8ffac4349c < _3d3550fa73b5(_324f0bb0e93e) else _324f0bb0e93e[-1] if _324f0bb0e93e else "<unknown>"
                    if _dce84354547d > _fae3b526ad0f and not _00d5075e0445:
                        _00d5075e0445 += _43f619396f4e[:_fae3b526ad0f]
                        _f51bb7c789c5._80c9bfd7d114(_778da70846c3)
                        _3f0e14a4ece1._80c9bfd7d114(_db8ffac4349c)
                        _a708fc356cab += 1
                        break
                    if _08c2df92342f + _dce84354547d > _fae3b526ad0f and _00d5075e0445:
                        break
                    _00d5075e0445 += _43f619396f4e
                    _f51bb7c789c5._80c9bfd7d114(_778da70846c3)
                    _01728f9cbd0b += 1
                    _3f0e14a4ece1._80c9bfd7d114(_a708fc356cab)
                    _08c2df92342f += _dce84354547d
                    _a708fc356cab += 1

                if not _00d5075e0445:
                    # fallback: take token prefix to avoid infinite loop
                    _00d5075e0445 = _9824867cea03[_7321a9cef882][1][:_fae3b526ad0f] or [0]
                    _f51bb7c789c5 = [_324f0bb0e93e[_7321a9cef882] if _7321a9cef882 < _3d3550fa73b5(_324f0bb0e93e) else _324f0bb0e93e[-1] if _324f0bb0e93e else "<unknown>"]
                    _3f0e14a4ece1 = [_7321a9cef882]
                    _01728f9cbd0b += 1
                    _7321a9cef882 += 1

                # pad tokens to fixed length
                if _3d3550fa73b5(_00d5075e0445) < _fae3b526ad0f:
                    _00d5075e0445 += [_6d8fb30cf6b9] * (_fae3b526ad0f - _3d3550fa73b5(_00d5075e0445))

                _4df361f4db11._80c9bfd7d114({
                    "sample_id": _d209f2fec0c4,
                    "chunk_id": _46e930634904,
                    "input_ids": _00d5075e0445,
                    "labels": _f51bb7c789c5,
                    "word_positions": _3f0e14a4ece1,
                    "num_chunks": 1
                })
                _46e930634904 += 1

                if _a708fc356cab >= _21be4e1b021a:
                    break

                # stride with overlap (in words)
                _71790bb8241c = _3d3550fa73b5(_3f0e14a4ece1)
                _fb60d6d1ea2d = _5d7afa179e83(_bfeb455d91e5 * _71790bb8241c)
                _fb60d6d1ea2d = _532d121895da(_fb60d6d1ea2d, _71790bb8241c - 1) if _71790bb8241c > 1 else 0
                _d71b39e435cb = _a708fc356cab - _fb60d6d1ea2d
                if _d71b39e435cb <= _7321a9cef882:
                    _d71b39e435cb = _7321a9cef882 + 1
                _7321a9cef882 = _d71b39e435cb

            _abfdbcac51cb = _3d3550fa73b5(_4df361f4db11)
            for _ff6b59722f6b in _4df361f4db11:
                _ff6b59722f6b["num_chunks"] = _abfdbcac51cb
            _c89227b6c1fd._670bd6418919(_4df361f4db11)

            if not _663dd22ba3ac._dcea1da1005f and not _6d873d8c8332 and _abfdbcac51cb > 1:
                _555b364167c9(f"[DEBUG] sample_id={_d209f2fec0c4}", _9ce20170c74a=_496297332322)
                _663dd22ba3ac._dcea1da1005f = _496297332322

        # Timing/logging suppressed to preserve original behavior
        return _c89227b6c1fd, _01728f9cbd0b

    # @staticmethod
    # def process_batch_gen_llm_classifier(args) -> Tuple[List[dict], int]:
    #     """
    #     Construct chunks for generative LLM framing.
    #     The function follows the previously specified format:
    #       - Insert single space tokens between words in both streams.
    #       - word_positions contains per-label-token positions and -1 entries for spaces.
    #       - Overlap computed in WORDS, not tokens.
    #     """
    #     import time
    #     start_time = time.time()
    #     (prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_test, start_sample_id) = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100

    #     # Chat-ish prefixes used in dataset construction
    #     # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
    #     # "Identify the language of every word and reply with space-separated codes only.\n"
    #     # "Do not include any explanation or extra text.\n")
    #     # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     input_prefix = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
    #     "Identify the language of every word and reply with space-separated codes only.\n"
    #     "Do not include any explanation or extra text.\n")
    #     response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
    #     input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
    #     response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
    #     space_ids = tokenizer.encode(" ", add_special_tokens=False)
    #     prefix = instruction_ids + input_prefix_ids
    #     suffix = response_prefix_ids
    #     eos_len = 1
    #     fixed_len = len(prefix) + len(suffix) + eos_len

    #     results: List[dict] = []
    #     local_label_counter = 0

    #     # Preprocess lines into words lists and align labels to words
    #     src_texts = [s.strip() for s in src_lines]
    #     tgt_texts = [t.strip() for t in tgt_lines]
    #     src_words_list = []
    #     tgt_words_list = []
    #     for src, tgt in zip(src_texts, tgt_lines):
    #         src_words = src.split() if src else ["<empty>"]
    #         tgt_words = tgt if isinstance(tgt, list) else (tgt.strip().split() if tgt.strip() else ["<empty>"])
    #         if len(tgt_words) == 1:
    #             tgt_words = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) != len(src_words):
    #             tgt_words = tgt_words[:len(src_words)] if len(tgt_words) > len(src_words) else tgt_words + [tgt_words[-1]] * (len(src_words) - len(tgt_words))
    #         src_words_list.append(src_words)
    #         tgt_words_list.append(tgt_words)

    #     # Flatten words for efficient tokenization
    #     all_src_words = list(chain(*src_words_list))
    #     all_tgt_words = list(chain(*tgt_words_list))

    #     unique_tgt_words = {w for words in tgt_words_list for w in words}

    #     for word in unique_tgt_words:
    #         if word not in LanguageIdentificationDataset.tracking_classes:
    #             class_tokens = tokenizer.encode(word, add_special_tokens=False)
    #             if len(class_tokens) > 1:
    #                 LanguageIdentificationDataset.tracking_classes[word] = f"{len(LanguageIdentificationDataset.tracking_classes)+1}"
    #             else:
    #                 LanguageIdentificationDataset.tracking_classes[word] = word
    #     # print(f"check tracking classes {LanguageIdentificationDataset.tracking_classes}")
    #     # FOR NEW TOKEN UNCOMMENT THIS
    #     # Unique Token logic
    #     # new_tokens = []
    #     # tracking = []

    #     # for word in unique_tgt_words:
    #     #     if len(tokenizer.encode(word, add_special_tokens=False)) > 1:
    #     #         new_token = f"{word}"
    #     #         new_tokens.append(new_token)
    #     #         tracking.append((word, new_token))

    #     # if new_tokens:
    #     #     tokenizer.add_tokens(new_tokens, special_tokens=False)
    #     #     for word, token in tracking:
    #     #         token_id = tokenizer.convert_tokens_to_ids(token)
    #     #         print(f"Added word '{word}' with token {token} (id: {token_id})")
    #     # else:
    #     #     print("No multi-token words found")
        
    #     # tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     # tok_tgt = tokenizer(all_tgt_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_tgt = tokenizer([str(LanguageIdentificationDataset.tracking_classes.get(tgt)) for tgt in all_tgt_words], add_special_tokens=False, return_attention_mask=False)["input_ids"]

    #     # Build per-line token info
    #     src_idx = 0
    #     tgt_idx = 0
    #     src_word_token_info_list = []
    #     tgt_word_token_info_list = []
    #     for src_words, tgt_words in zip(src_words_list, tgt_words_list):
    #         src_len = len(src_words)
    #         tgt_len = len(tgt_words)
    #         if src_words == ["<empty>"] or tgt_words == ["<empty>"]:
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             continue
    #         try:
    #             src_info = [(w, tok_src[src_idx + i], len(tok_src[src_idx + i]) if isinstance(tok_src[src_idx + i], list) else 1) for i, w in enumerate(src_words)]
    #             tgt_info = [(w, tok_tgt[tgt_idx + i], len(tok_tgt[tgt_idx + i]) if isinstance(tok_tgt[tgt_idx + i], list) else 1) for i, w in enumerate(tgt_words)]
    #         except IndexError:
    #             # On tokenization mismatches, fallback safely
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             src_idx += src_len
    #             tgt_idx += tgt_len
    #             continue
    #         src_word_token_info_list.append(src_info)
    #         tgt_word_token_info_list.append(tgt_info)
    #         src_idx += src_len
    #         tgt_idx += tgt_len

    #     # Build chunks per sentence
    #     for line_idx, (src_words, src_word_token_info, tgt_word_token_info) in enumerate(zip(src_words_list, src_word_token_info_list, tgt_word_token_info_list)):
    #         sample_id = start_sample_id + line_idx
    #         chunk_id = 0
    #         src_word_labels = [info[0] for info in tgt_word_token_info]

    #         if src_words == ["<empty>"]:
    #             input_ids = prefix + [0] + suffix + [eos_id]
    #             labels = [ignore_index] * len(input_ids)
    #             pad_len = max_seq_len - len(input_ids)
    #             if pad_len > 0:
    #                 input_ids += [pad_id] * pad_len
    #                 labels += [ignore_index] * pad_len
    #             results.append({
    #                 "lang_codes": ["<empty>"],
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": [0],
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": len(prefix) + 1 + len(suffix),
    #                 "chunk_words": ["<empty>"],
    #                 "chunk_labels": ["<empty>"],
    #                 "num_chunks": 1
    #             })
    #             continue

    #         i = 0
    #         n = len(src_word_token_info)
    #         prev_j = -1
    #         chunk_results = []
    #         while i < n:
    #             total_len = fixed_len
    #             chunk_input_tokens = []
    #             chunk_label_tokens = []
    #             word_positions = []
    #             lang_codes = []
    #             chunk_words = []
    #             chunk_labels = []
    #             j = i
    #             while j < n:
    #                 _, src_ids, src_len = src_word_token_info[j]
    #                 tgt_word, tgt_ids, tgt_len = tgt_word_token_info[j]
    #                 inter_word_spaces = len(space_ids) if j < n - 1 else 0
    #                 # choose conservative word_total so both streams fit
    #                 word_total = max(src_len, tgt_len) + inter_word_spaces
    #                 if total_len + word_total > max_seq_len * 0.9:
    #                     break

    #                 # append inputs and spaces
    #                 chunk_input_tokens += src_ids if isinstance(src_ids, list) else [src_ids]
    #                 if inter_word_spaces:
    #                     chunk_input_tokens += space_ids

    #                 # append labels and word_positions
    #                 if tgt_len:
    #                     chunk_label_tokens += tgt_ids if isinstance(tgt_ids, list) else [tgt_ids]
    #                     word_positions += [j] * tgt_len
    #                 if inter_word_spaces:
    #                     chunk_label_tokens += space_ids
    #                     word_positions += [-1] * inter_word_spaces

    #                 lang_codes.append(tgt_word)
    #                 chunk_words.append(src_words[j])
    #                 chunk_labels.append(tgt_word)
    #                 local_label_counter += len(src_words[j])
    #                 total_len += word_total
    #                 j += 1

    #             if not chunk_input_tokens:
    #                 i += 1
    #                 continue

    #             flat_input_ids = chunk_input_tokens
    #             flat_label_ids = chunk_label_tokens
    #             prompt_len = len(prefix) + len(flat_input_ids) + len(suffix)

    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
    #             # RIGHT PAD + LEFT PAD TEST METHOD
    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
    #             # # pad to fixed size (inputs appended or prepended depending on test/train)
    #             # inputs_pad_len = max_seq_len - len(input_ids)
    #             # labels_pad_len = max_seq_len - len(labels)
    #             # if inputs_pad_len > 0:
    #             #     if is_test:
    #             #         input_ids = [pad_id] * inputs_pad_len + input_ids
    #             #     else:
    #             #         input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     if is_test:
    #             #         labels = [ignore_index] * labels_pad_len + labels
    #             #     else:
    #             #         labels += [ignore_index] * labels_pad_len
                
    #             # LEFT PAD METHOD
    #             if is_test is False:
    #                 input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             else:
    #                 input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             inputs_pad_len = max_seq_len - len(input_ids)
    #             labels_pad_len = max_seq_len - len(labels)
    #             if inputs_pad_len > 0:
    #                 input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # if is_test:
    #                 #     input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # else:
    #                 #     input_ids += [pad_id] * inputs_pad_len
    #             if labels_pad_len > 0:
    #                 labels = [ignore_index] * labels_pad_len + labels
    #                 # if is_test:
    #                 #     labels = [ignore_index] * labels_pad_len + labels
    #                 # else:
    #                 #     labels += [ignore_index] * labels_pad_len

    #             # if inputs_pad_len > 0:
    #             #     input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     labels += [ignore_index] * labels_pad_len

    #             if len(input_ids) != max_seq_len or len(labels) != max_seq_len:
    #                 raise RuntimeError(
    #                     f"[SEQ LEN VIOLATION] "
    #                     f"sample_id={sample_id} "
    #                     f"chunk_id={chunk_id} "
    #                     f"is_test={is_test} "
    #                     f"len(input_ids)={len(input_ids)} "
    #                     f"len(labels)={len(labels)} "
    #                     f"max_seq_len={max_seq_len} "
    #                     f"prompt_len={prompt_len} "
    #                     f"flat_input_len={len(flat_input_ids)} "
    #                     f"flat_label_len={len(flat_label_ids)}"
    #                 )


    #             chunk_results.append({
    #                 "lang_codes": lang_codes,
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": prompt_len,
    #                 "chunk_words": chunk_words,
    #                 "chunk_labels": chunk_labels,
    #                 "num_chunks": 1
    #             })
    #             chunk_id += 1

    #             if j >= n or j <= prev_j:
    #                 break
    #             prev_j = j
    #             overlap_words = max(1, int(overlap_ratio * len(chunk_words)))
    #             i = j - overlap_words if (j - overlap_words) > i else j

    #         num_chunks = len(chunk_results)
    #         for r in chunk_results:
    #             r["num_chunks"] = num_chunks
    #         results.extend(chunk_results)

    #         if not LanguageIdentificationDataset.is_debug_sample_shown and not is_test and num_chunks > 1:
    #             LanguageIdentificationDataset.is_debug_sample_shown = True

    #     return results, local_label_counter

    @_9efdb82f8555
    def _cb5210b22703(_0e7861da9fb0) -> _fe317f785f5d[_5d1f7246c52f[_ac44143b82bf], _5d7afa179e83]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import time
        _9b7579b2cbbf = time.time()
        (_2279bd194baa, _ffde35acd689, _6a7d58b3eef4, _fae3b526ad0f, _bfeb455d91e5, _3b4cc1a500c1, _2868df7ac709) = _0e7861da9fb0
        _d66262f7b026 = _663dd22ba3ac._7cc5bb79eb92
        _6d8fb30cf6b9 = _d66262f7b026._8b6a38036769 or _d66262f7b026._6071efd21d75
        _bc36f2547205 = _d66262f7b026._6071efd21d75
        _e876cf442a5a = -100

        # Chat-ish prefixes used in dataset construction
        _32f6ccea12ba = _d66262f7b026._d1dd57645b19._afd88324f332()
        if "llama" in _32f6ccea12ba:
            _6aa2a0a2d865 = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _df64a8ae761b = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        elif "qwen" in _32f6ccea12ba:
            _6aa2a0a2d865 = ("<|im_start|>system\nYou are Qwen, created by Alibaba Cloud."
            "You are a helpful assistant.<|im_end|>\n<|im_start|>user\n"
            "Instructions:\nIdentify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _df64a8ae761b = "<|im_end|>\n<|im_start|>assistant\n"
        elif "gemma" in _32f6ccea12ba:
            _6aa2a0a2d865 = ("<bos><start_of_turn>user\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _df64a8ae761b = "<end_of_turn>\n<start_of_turn>model\n"
        else:
            raise _05152452fdec(f"Gen LLM module currently doesnt support {_32f6ccea12ba}")
        _bfd72cf9935b = _d66262f7b026._cc10562e8314(_2279bd194baa, _b15465b2399e=_a6de65e7b346)
        _bc7c3bd78520 = _d66262f7b026._cc10562e8314(_6aa2a0a2d865, _b15465b2399e=_a6de65e7b346)
        _dc9b00138541 = _d66262f7b026._cc10562e8314(_df64a8ae761b, _b15465b2399e=_a6de65e7b346)
        # space_ids = tokenizer.encode(" ", add_special_tokens=False)
        _a59682553fb9 = _d66262f7b026._cc10562e8314("||", _b15465b2399e=_a6de65e7b346)
        _2c3a97b71d53 = _bfd72cf9935b + _bc7c3bd78520
        _3f6b3b262986 = _dc9b00138541
        _5c4c227c3063 = 1
        _cc2749ef37bc = _3d3550fa73b5(_2c3a97b71d53) + _3d3550fa73b5(_3f6b3b262986) + _5c4c227c3063

        _c89227b6c1fd: _5d1f7246c52f[_ac44143b82bf] = []
        _01728f9cbd0b = 0

        # Preprocess lines into words lists and align labels to words
        _1c63750db7d8 = [_ba2288704f30._cf99a6a1aeea() for _ba2288704f30 in _ffde35acd689]
        _9af37c484877 = [_756313482b47._cf99a6a1aeea() for _756313482b47 in _6a7d58b3eef4]
        _6ef5a06d68d7 = []
        _e2346692127b = []
        for _3cd67c666d5b, _5adae9bee0c1 in _42583248704d(_1c63750db7d8, _6a7d58b3eef4):
            _6ec56fb88250 = _3cd67c666d5b._c857b267e68c() if _3cd67c666d5b else ["<empty>"]
            _aa8832e2eba8 = _5adae9bee0c1 if _a90ac2038707(_5adae9bee0c1, _cc29e7e3f832) else (_5adae9bee0c1._cf99a6a1aeea()._c857b267e68c() if _5adae9bee0c1._cf99a6a1aeea() else ["<empty>"])
            if _3d3550fa73b5(_aa8832e2eba8) == 1:
                _aa8832e2eba8 = [_aa8832e2eba8[0]] * _3d3550fa73b5(_6ec56fb88250)
            elif _3d3550fa73b5(_aa8832e2eba8) != _3d3550fa73b5(_6ec56fb88250):
                _aa8832e2eba8 = _aa8832e2eba8[:_3d3550fa73b5(_6ec56fb88250)] if _3d3550fa73b5(_aa8832e2eba8) > _3d3550fa73b5(_6ec56fb88250) else _aa8832e2eba8 + [_aa8832e2eba8[-1]] * (_3d3550fa73b5(_6ec56fb88250) - _3d3550fa73b5(_aa8832e2eba8))
            _6ef5a06d68d7._80c9bfd7d114(_6ec56fb88250)
            _e2346692127b._80c9bfd7d114(_aa8832e2eba8)

        # Flatten words for efficient tokenization
        _6f23a00c266d = _cc29e7e3f832(_fd556e9182b5(*_6ef5a06d68d7))
        _ba659253c12b = _cc29e7e3f832(_fd556e9182b5(*_e2346692127b))

        _237d337c1a62 = {_7618c4a410c0 for _c030f09dc45a in _e2346692127b for _7618c4a410c0 in _c030f09dc45a}

        for _fa4257a95807 in _237d337c1a62:
            if _fa4257a95807 not in _663dd22ba3ac._220b968bb60a:
                _5551245df829 = _d66262f7b026._cc10562e8314(_fa4257a95807, _b15465b2399e=_a6de65e7b346)
                if _3d3550fa73b5(_5551245df829) > 1:
                    _663dd22ba3ac._220b968bb60a[_fa4257a95807] = f"{_3d3550fa73b5(_663dd22ba3ac._220b968bb60a)+1}"
                else:
                    _663dd22ba3ac._220b968bb60a[_fa4257a95807] = _fa4257a95807
        
        _d75a7da4e4db = _d66262f7b026(_6f23a00c266d, _b15465b2399e=_a6de65e7b346, _24386162b47d=_a6de65e7b346)["input_ids"]
        _ecdb5d11f11f = _d66262f7b026([_901b8c763fb2(_663dd22ba3ac._220b968bb60a._a231624e36ee(_5adae9bee0c1)) for _5adae9bee0c1 in _ba659253c12b], _b15465b2399e=_a6de65e7b346, _24386162b47d=_a6de65e7b346)["input_ids"]

        # Build per-line token info
        _60199aeefbdd = 0
        _7e0182fdf750 = 0
        _1783f2f78da7 = []
        _b830f2239afc = []
        for _6ec56fb88250, _aa8832e2eba8 in _42583248704d(_6ef5a06d68d7, _e2346692127b):
            _c4037ceabeec = _3d3550fa73b5(_6ec56fb88250)
            _e3058fd535de = _3d3550fa73b5(_aa8832e2eba8)
            if _6ec56fb88250 == ["<empty>"] or _aa8832e2eba8 == ["<empty>"]:
                _1783f2f78da7._80c9bfd7d114([(_6ec56fb88250[0], [0], 1)])
                _b830f2239afc._80c9bfd7d114([(_aa8832e2eba8[0], [0], 1)])
                continue
            try:
                _a59869fafaef = [(_7618c4a410c0, _d75a7da4e4db[_60199aeefbdd + _7321a9cef882], _3d3550fa73b5(_d75a7da4e4db[_60199aeefbdd + _7321a9cef882]) if _a90ac2038707(_d75a7da4e4db[_60199aeefbdd + _7321a9cef882], _cc29e7e3f832) else 1) for _7321a9cef882, _7618c4a410c0 in _ceaad99a6b8b(_6ec56fb88250)]
                _c9bc11500d9f = [(_7618c4a410c0, _ecdb5d11f11f[_7e0182fdf750 + _7321a9cef882], _3d3550fa73b5(_ecdb5d11f11f[_7e0182fdf750 + _7321a9cef882]) if _a90ac2038707(_ecdb5d11f11f[_7e0182fdf750 + _7321a9cef882], _cc29e7e3f832) else 1) for _7321a9cef882, _7618c4a410c0 in _ceaad99a6b8b(_aa8832e2eba8)]
            except _74c0b5171714:
                # On tokenization mismatches, fallback safely
                _1783f2f78da7._80c9bfd7d114([(_6ec56fb88250[0], [0], 1)])
                _b830f2239afc._80c9bfd7d114([(_aa8832e2eba8[0], [0], 1)])
                _60199aeefbdd += _c4037ceabeec
                _7e0182fdf750 += _e3058fd535de
                continue
            _1783f2f78da7._80c9bfd7d114(_a59869fafaef)
            _b830f2239afc._80c9bfd7d114(_c9bc11500d9f)
            _60199aeefbdd += _c4037ceabeec
            _7e0182fdf750 += _e3058fd535de

        # Build chunks per sentence
        for _849c0e292fe7, (_6ec56fb88250, _9824867cea03, _e57c67fb5786) in _ceaad99a6b8b(_42583248704d(_6ef5a06d68d7, _1783f2f78da7, _b830f2239afc)):
            _d209f2fec0c4 = _2868df7ac709 + _849c0e292fe7
            _46e930634904 = 0
            _6a26aabc931a = [_2394b93e9ae5[0] for _2394b93e9ae5 in _e57c67fb5786]

            if _6ec56fb88250 == ["<empty>"]:
                _555b364167c9(f"Skiiping line {_849c0e292fe7} in file since its empty")

            _7321a9cef882 = 0
            _21be4e1b021a = _3d3550fa73b5(_9824867cea03)
            _8070445bcc3b = -1
            _4df361f4db11 = []
            while _7321a9cef882 < _21be4e1b021a:
                _08c2df92342f = _cc2749ef37bc
                _e80686c1e0d4 = []
                _ad9ca3e23687 = []
                _3f0e14a4ece1 = []
                _9cbd84d615fb = []
                _73ef099b32f6 = []
                _f51bb7c789c5 = []
                _a708fc356cab = _7321a9cef882
                while _a708fc356cab < _21be4e1b021a:
                    _, _c0356ef2541f, _c4037ceabeec = _9824867cea03[_a708fc356cab]
                    _29362a94ecf8, _fe367c0708f5, _e3058fd535de = _e57c67fb5786[_a708fc356cab]
                    _c6c17d0c70b4 = _3d3550fa73b5(_a59682553fb9) if _a708fc356cab < _21be4e1b021a - 1 else 0
                    # choose conservative word_total so both streams fit
                    # word_total = max(src_len, tgt_len) + inter_word_spaces
                    # if total_len + word_total > max_seq_len * 0.9:
                    #     break

                    # account for BOTH streams + spaces
                    # word_input = src_len + inter_word_spaces
                    # word_label = tgt_len + inter_word_spaces
                    # word_total = word_input + word_label

                    _f10daf24645c = _c4037ceabeec + _c6c17d0c70b4
                    _a9a174884aa8 = _f10daf24645c if _3b4cc1a500c1 else (_f10daf24645c + _e3058fd535de + _c6c17d0c70b4)


                    if _08c2df92342f + _a9a174884aa8 > _fae3b526ad0f:
                        break


                    # append inputs and spaces
                    _e80686c1e0d4 += _c0356ef2541f if _a90ac2038707(_c0356ef2541f, _cc29e7e3f832) else [_c0356ef2541f]
                    if _c6c17d0c70b4:
                        _e80686c1e0d4 += _a59682553fb9

                    # append labels and word_positions
                    if _e3058fd535de:
                        _ad9ca3e23687 += _fe367c0708f5 if _a90ac2038707(_fe367c0708f5, _cc29e7e3f832) else [_fe367c0708f5]
                        _3f0e14a4ece1 += [_a708fc356cab] * _e3058fd535de
                    if _c6c17d0c70b4:
                        _ad9ca3e23687 += _a59682553fb9
                        _3f0e14a4ece1 += [-1] * _c6c17d0c70b4

                    _9cbd84d615fb._80c9bfd7d114(_29362a94ecf8)
                    _73ef099b32f6._80c9bfd7d114(_6ec56fb88250[_a708fc356cab])
                    _f51bb7c789c5._80c9bfd7d114(_29362a94ecf8)
                    _01728f9cbd0b += _3d3550fa73b5(_6ec56fb88250[_a708fc356cab])
                    _08c2df92342f += _a9a174884aa8
                    _a708fc356cab += 1

                if not _e80686c1e0d4:
                    _7321a9cef882 += 1
                    continue

                _c12e11c5aa2a = _e80686c1e0d4
                _2223343b0a85 = _ad9ca3e23687
                _52321de29c67 = _3d3550fa73b5(_2c3a97b71d53) + _3d3550fa73b5(_c12e11c5aa2a) + _3d3550fa73b5(_3f6b3b262986)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
                # RIGHT PAD + LEFT PAD TEST METHOD
                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

                # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
                # # pad to fixed size (inputs appended or prepended depending on test/train)
                # inputs_pad_len = max_seq_len - len(input_ids)
                # labels_pad_len = max_seq_len - len(labels)
                # if inputs_pad_len > 0:
                #     if is_test:
                #         input_ids = [pad_id] * inputs_pad_len + input_ids
                #     else:
                #         input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     if is_test:
                #         labels = [ignore_index] * labels_pad_len + labels
                #     else:
                #         labels += [ignore_index] * labels_pad_len
                
                # LEFT PAD METHOD
                if _3b4cc1a500c1 is _a6de65e7b346:
                    _30f88d213602 = _2c3a97b71d53 + _c12e11c5aa2a + _3f6b3b262986 + _2223343b0a85 + [_bc36f2547205]
                    _3939d73b0d40 = [_e876cf442a5a] * _52321de29c67 + _2223343b0a85 + [_e876cf442a5a]
                else:
                    # input_ids = prefix + flat_input_ids + suffix + [eos_id]
                    # labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                    # REMOVE EOS
                    # input_ids = prefix + flat_input_ids + suffix
                    # labels = [ignore_index] * prompt_len + flat_label_ids
                    _cd4c7f3cd12b = _2c3a97b71d53 + _c12e11c5aa2a + _3f6b3b262986

                    _29bb94c5bb0c = _fae3b526ad0f - _3d3550fa73b5(_cd4c7f3cd12b)
                    _30f88d213602 = [_6d8fb30cf6b9] * _29bb94c5bb0c + _cd4c7f3cd12b

                    _3939d73b0d40 = [_e876cf442a5a] * _fae3b526ad0f + _2223343b0a85
                    # label_start = inputs_pad_len + prompt_len
                    # labels[label_start : label_start + len(flat_label_ids)] = flat_label_ids

                if not _3b4cc1a500c1:
                    _29bb94c5bb0c = _fae3b526ad0f - _3d3550fa73b5(_30f88d213602)
                    _66542b1fc898 = _fae3b526ad0f - _3d3550fa73b5(_3939d73b0d40)
                    if _29bb94c5bb0c > 0:
                        _30f88d213602 = [_6d8fb30cf6b9] * _29bb94c5bb0c + _30f88d213602
                        # if is_test:
                        #     input_ids = [pad_id] * inputs_pad_len + input_ids
                        # else:
                        #     input_ids += [pad_id] * inputs_pad_len
                    if _66542b1fc898 > 0:
                        _3939d73b0d40 = [_e876cf442a5a] * _66542b1fc898 + _3939d73b0d40
                        # if is_test:
                        #     labels = [ignore_index] * labels_pad_len + labels
                        # else:
                        #     labels += [ignore_index] * labels_pad_len

                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len

                # not respecting rule in test since test will be free flowing
                if _3b4cc1a500c1 is _a6de65e7b346 and (_3d3550fa73b5(_30f88d213602) != _fae3b526ad0f or _3d3550fa73b5(_3939d73b0d40) != _fae3b526ad0f):
                    raise _d2df598c624a(
                        f"[SEQ LEN VIOLATION] "
                        f"sample_id={_d209f2fec0c4} "
                        f"chunk_id={_46e930634904} "
                        f"is_test={_3b4cc1a500c1} "
                        f"len(input_ids)={_3d3550fa73b5(_30f88d213602)} "
                        f"len(labels)={_3d3550fa73b5(_3939d73b0d40)} "
                        f"max_seq_len={_fae3b526ad0f} "
                        f"prompt_len={_52321de29c67} "
                        f"flat_input_len={_3d3550fa73b5(_c12e11c5aa2a)} "
                        f"flat_label_len={_3d3550fa73b5(_2223343b0a85)}"
                    )


                _4df361f4db11._80c9bfd7d114({
                    "lang_codes": _9cbd84d615fb,
                    "sample_id": _d209f2fec0c4,
                    "chunk_id": _46e930634904,
                    "word_positions": _3f0e14a4ece1,
                    "input_ids": _30f88d213602,
                    "labels": _3939d73b0d40,
                    "prompt_len": _52321de29c67,
                    "chunk_words": _73ef099b32f6,
                    "chunk_labels": _f51bb7c789c5,
                    "num_chunks": 1
                })
                _46e930634904 += 1

                if _a708fc356cab >= _21be4e1b021a or _a708fc356cab <= _8070445bcc3b:
                    break
                _8070445bcc3b = _a708fc356cab
                _0afb0f79045d = _b8e778a9db72(1, _5d7afa179e83(_bfeb455d91e5 * _3d3550fa73b5(_73ef099b32f6)))
                _7321a9cef882 = _a708fc356cab - _0afb0f79045d if (_a708fc356cab - _0afb0f79045d) > _7321a9cef882 else _a708fc356cab

            _abfdbcac51cb = _3d3550fa73b5(_4df361f4db11)
            for _ff6b59722f6b in _4df361f4db11:
                _ff6b59722f6b["num_chunks"] = _abfdbcac51cb
            _c89227b6c1fd._670bd6418919(_4df361f4db11)

            if not _663dd22ba3ac._dcea1da1005f and not _3b4cc1a500c1 and _abfdbcac51cb > 1:
                _663dd22ba3ac._dcea1da1005f = _496297332322

        return _c89227b6c1fd, _01728f9cbd0b

    # -------------------------
    # File processing & validation
    # -------------------------
    def _6f783b47b876(self, _adf93c9b93b0: _901b8c763fb2, _7881749004e3: _901b8c763fb2, _2868df7ac709: _5d7afa179e83) -> _fe317f785f5d[_901b8c763fb2, _5d1f7246c52f[_ac44143b82bf], _5d7afa179e83]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _96f6ad10105d = []

        with _8632fccf05aa(_adf93c9b93b0, "r", _18db4f15836c="utf8") as _184b111dce52, _8632fccf05aa(_7881749004e3, "r", _18db4f15836c="utf8") as _c9389c3da02d:
            _ffde35acd689 = _184b111dce52._af8b5c56b15d()[1:] if self._baafecd54e0c else _184b111dce52._af8b5c56b15d()
            _6a7d58b3eef4 = _c9389c3da02d._af8b5c56b15d()[1:] if self._baafecd54e0c else _c9389c3da02d._af8b5c56b15d()

        # sample some share if requested
        _461f1cd7af82 = _5d7afa179e83(_3d3550fa73b5(_ffde35acd689) * self._c40da6dde6c8)
        if _461f1cd7af82 < _3d3550fa73b5(_ffde35acd689):
            _7e5d69c9fcdd = _e133289597c7.random._bac55bce4256(_3d3550fa73b5(_ffde35acd689), _461f1cd7af82, _741bc1ecfc05=_a6de65e7b346)
            _ffde35acd689 = [_ffde35acd689[_7321a9cef882] for _7321a9cef882 in _7e5d69c9fcdd]
            _6a7d58b3eef4 = [_6a7d58b3eef4[_7321a9cef882] for _7321a9cef882 in _7e5d69c9fcdd]

        _6f15042bfe0a = _cc29e7e3f832({_756313482b47._cf99a6a1aeea() for _756313482b47 in _6a7d58b3eef4})[0] if _6a7d58b3eef4 else "unk"
        self._3622c3f4fc5c._2394b93e9ae5(f"Sampled {self._c40da6dde6c8 * 100:.1f}% of {_adf93c9b93b0}: {_3d3550fa73b5(_ffde35acd689)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _391b1fa11bae(_7e308fb7aaab, _0b0a407ce7ae):
            _6f0d7b5c810b = _2e03ace7a66d(_7e308fb7aaab)
            while _496297332322:
                _16beb219fcba = _cc29e7e3f832(_b79c3ffd441d(_6f0d7b5c810b, _0b0a407ce7ae))
                if not _16beb219fcba:
                    break
                yield _16beb219fcba

        _0b0a407ce7ae = 10_000
        if self._560405d0861c:
            _aff7d69101c4 = [
                (self._2279bd194baa, _4c2b82458482, _31f445b826cb, self._73ad0b27950a, 0.25, self._3b4cc1a500c1, _2868df7ac709 + _8e76a798e1fa * _0b0a407ce7ae)
                for _8e76a798e1fa, (_4c2b82458482, _31f445b826cb) in _ceaad99a6b8b(_42583248704d(_a47e770c1e26(_ffde35acd689, _0b0a407ce7ae), _a47e770c1e26(_6a7d58b3eef4, _0b0a407ce7ae)))
            ]
            with _1c89ad0c6689(self._8ed8b544225c) as _2e987feba6ef:
                _e59dd7bb13ef = _2e987feba6ef._692111be944f(_663dd22ba3ac._fbb5bfb81b32, _aff7d69101c4)
        else:
            _aff7d69101c4 = [
                (_4c2b82458482, _31f445b826cb, self._73ad0b27950a, 0.5, self._6d873d8c8332, _2868df7ac709 + _8e76a798e1fa * _0b0a407ce7ae)
                for _8e76a798e1fa, (_4c2b82458482, _31f445b826cb) in _ceaad99a6b8b(_42583248704d(_a47e770c1e26(_ffde35acd689, _0b0a407ce7ae), _a47e770c1e26(_6a7d58b3eef4, _0b0a407ce7ae)))
            ]
            with _1c89ad0c6689(self._8ed8b544225c) as _2e987feba6ef:
                _e59dd7bb13ef = _2e987feba6ef._692111be944f(_663dd22ba3ac._f439046a5a22, _aff7d69101c4)

        _1eda9c2e139e = []
        for _c89227b6c1fd, _ac39f5021b6c in _e59dd7bb13ef:
            _1eda9c2e139e._670bd6418919(_c89227b6c1fd)
            self._f01bfb029712 += _ac39f5021b6c

        if _1eda9c2e139e:
            _96f6ad10105d = _1eda9c2e139e

        return _6f15042bfe0a, _96f6ad10105d, _3d3550fa73b5(_ffde35acd689)

    def _be68d0ca7e64(self) -> _1d4965d3cd35:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _5e7131d2b12e = 0

        for _9b5cf31e2429 in os._f6d44757aafb(self._383bbaf2b542):
            self._3622c3f4fc5c._2394b93e9ae5(f"Now processing {os._ca133139ad80._ee84420063c1(self._383bbaf2b542, _9b5cf31e2429)} directory.")
            _ccb6338cd9e5 = os._ca133139ad80._ee84420063c1(self._383bbaf2b542, _9b5cf31e2429, "src")
            _9bad5af56b73 = os._ca133139ad80._ee84420063c1(self._383bbaf2b542, _9b5cf31e2429, "tgt")

            _f837d6e2eaed = []
            _8ddb57bc3eae = []
            for _adf93c9b93b0 in os._f6d44757aafb(_ccb6338cd9e5):
                _8ea9021bbc38 = _a6de65e7b346
                for _7881749004e3 in os._f6d44757aafb(_9bad5af56b73):
                    if _adf93c9b93b0._c857b267e68c(".")[0] == _7881749004e3._c857b267e68c(".")[0]:
                        _f837d6e2eaed._80c9bfd7d114(_adf93c9b93b0)
                        _8ddb57bc3eae._80c9bfd7d114(_7881749004e3)
                        _8ea9021bbc38 = _496297332322
                        break
                if not _8ea9021bbc38:
                    self._3622c3f4fc5c._2394b93e9ae5(f"Skipping file {_adf93c9b93b0} since matching label file not found in {_9bad5af56b73}.")

            _eb63450b80a0 = [os._ca133139ad80._ee84420063c1(_ccb6338cd9e5, _e782702a2750) for _e782702a2750 in _f837d6e2eaed if os._ca133139ad80._92cbddeb164f(os._ca133139ad80._ee84420063c1(_ccb6338cd9e5, _e782702a2750))]
            _a70222077e51 = [os._ca133139ad80._ee84420063c1(_9bad5af56b73, _e782702a2750) for _e782702a2750 in _8ddb57bc3eae if os._ca133139ad80._92cbddeb164f(os._ca133139ad80._ee84420063c1(_9bad5af56b73, _e782702a2750))]

            if _3d3550fa73b5(_eb63450b80a0) != _3d3550fa73b5(_a70222077e51):
                raise _05152452fdec(f"Number of files in {_ccb6338cd9e5} ({_3d3550fa73b5(_eb63450b80a0)}) does not match {_9bad5af56b73} ({_3d3550fa73b5(_a70222077e51)})")

            for _adf93c9b93b0, _7881749004e3 in _42583248704d(_eb63450b80a0, _a70222077e51):
                _de6d3e9fb746 = _dfe0cb08072a(1 for _ in _8632fccf05aa(_adf93c9b93b0))
                _968e91f01669 = _dfe0cb08072a(1 for _ in _8632fccf05aa(_7881749004e3))
                _de6d3e9fb746 = _de6d3e9fb746 - 1 if self._baafecd54e0c else _de6d3e9fb746
                _968e91f01669 = _968e91f01669 - 1 if self._baafecd54e0c else _968e91f01669

                if _de6d3e9fb746 != _968e91f01669:
                    self._3622c3f4fc5c._2394b93e9ae5(f"{_de6d3e9fb746} lines in {_adf93c9b93b0} do not match with {_968e91f01669} in {_7881749004e3}, skipping these files")
                    continue

                self._3622c3f4fc5c._2394b93e9ae5(f"Processing {_adf93c9b93b0} and {_7881749004e3} with {_968e91f01669} samples.")
                _6f15042bfe0a, _b7081b77aea7, _387abc26e2ff = self._f9a1ca320205(_adf93c9b93b0, _7881749004e3, _2868df7ac709=_5e7131d2b12e)
                _5e7131d2b12e += _387abc26e2ff

                self._b7081b77aea7._670bd6418919(_b7081b77aea7)
                if self._6d873d8c8332:
                    if _6f15042bfe0a not in self._ddf4b2e49cc4:
                        self._ddf4b2e49cc4._281051724e9b({
                            _6f15042bfe0a: [{
                                "file_name": os._ca133139ad80._812e3008119b(_7881749004e3),
                                "samples_before_processing": _968e91f01669,
                                "samples_after_processing": _3d3550fa73b5(_b7081b77aea7)
                            }]
                        })
                    else:
                        self._ddf4b2e49cc4[_6f15042bfe0a]._80c9bfd7d114({
                            "file_name": os._ca133139ad80._812e3008119b(_7881749004e3),
                            "samples_before_processing": _968e91f01669,
                            "samples_after_processing": _3d3550fa73b5(_b7081b77aea7)
                        })
                if _6f15042bfe0a not in self._9cbd84d615fb:
                    self._9cbd84d615fb._80c9bfd7d114(_6f15042bfe0a)
                self._3622c3f4fc5c._2394b93e9ae5(f"Files {_adf93c9b93b0} and {_7881749004e3} have {_3d3550fa73b5(_b7081b77aea7)} samples after processing.")

        # verify dataset integrity
        self._b3ed36744a8d()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _11432f9a31b7(self) -> _1d4965d3cd35:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _274afd2f9472 = self._b7081b77aea7
        if not _274afd2f9472:
            self._3622c3f4fc5c._2394b93e9ae5("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _819324e8a825 = [_1489be9dad63["sample_id"] for _1489be9dad63 in _274afd2f9472]
        _162c34386cb2 = _43fa1a31b65e(_819324e8a825)
        _184669854a41 = _b8e778a9db72(_162c34386cb2)
        _6d8cfd192e66 = (_3d3550fa73b5(_162c34386cb2) == _184669854a41 + 1)
        self._3622c3f4fc5c._2394b93e9ae5(f"[sample_id] unique={_3d3550fa73b5(_162c34386cb2)} max={_184669854a41} coverage_ok={_6d8cfd192e66} (expect True)")
        if not _6d8cfd192e66:
            _86c729fe9959 = _75c70d9e7595(_43fa1a31b65e(_6cba3fadb962(_184669854a41 + 1)) - _162c34386cb2)
            self._3622c3f4fc5c._2394b93e9ae5(f" Missing sample_ids: {_86c729fe9959[:20]}{' ...' if _3d3550fa73b5(_86c729fe9959) > 20 else ''}")
            raise _05152452fdec(f"Increase max_seq_len as missing sample_ids detected: {_86c729fe9959[:20]}{' ...' if _3d3550fa73b5(_86c729fe9959) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _0e2fcf08d031 = [(_1489be9dad63["sample_id"], _1489be9dad63["chunk_id"]) for _1489be9dad63 in _274afd2f9472]
        _381d5f28e213 = [_82e68e1dced8 for _82e68e1dced8, _3ac104d9250d in _3fe4029d83b9(_0e2fcf08d031)._35641697bd5f() if _3ac104d9250d > 1]
        self._3622c3f4fc5c._2394b93e9ae5(f"[(sample_id,chunk_id)] duplicates: {_3d3550fa73b5(_381d5f28e213)} (expect 0)")
        if _381d5f28e213:
            self._3622c3f4fc5c._2394b93e9ae5(f" Examples: {_381d5f28e213[:10]}")
            raise _05152452fdec(f"Duplicate (sample_id, chunk_id) pairs detected: {_381d5f28e213[:10]}")

        # 3) per-sample chunk_id sequentiality
        _f2af36cd296e = _b565bd8b9ef3(_cc29e7e3f832)
        for _1489be9dad63 in _274afd2f9472:
            _f2af36cd296e[_1489be9dad63["sample_id"]]._80c9bfd7d114(_1489be9dad63["chunk_id"])
        _7a38a7e73b92 = {}
        for _520022520fe7, _43f619396f4e in _f2af36cd296e._35641697bd5f():
            _cb69ea675520 = _75c70d9e7595(_43f619396f4e)
            _99f39f263045 = _cc29e7e3f832(_6cba3fadb962(_3d3550fa73b5(_cb69ea675520)))
            if _cb69ea675520 != _99f39f263045:
                _7a38a7e73b92[_520022520fe7] = {"have": _cb69ea675520[:20], "expected_prefix": _99f39f263045[:20]}
        self._3622c3f4fc5c._2394b93e9ae5(f"[per-sample chunk_id sequence] bad_samples: {_3d3550fa73b5(_7a38a7e73b92)} (expect 0)")
        if _7a38a7e73b92:
            _91697a29ee04 = _cc29e7e3f832(_7a38a7e73b92._35641697bd5f())[:5]
            for _520022520fe7, _2394b93e9ae5 in _91697a29ee04:
                self._3622c3f4fc5c._2394b93e9ae5(f" sample_id={_520022520fe7} have={_2394b93e9ae5['have']} expected_prefix={_2394b93e9ae5['expected_prefix']}")
            raise _05152452fdec(f"Non-sequential chunk_id sequences detected for sample_ids: {_cc29e7e3f832(_7a38a7e73b92._b20520b27e1b())[:5]}")

        # 4) overall stats reporting
        _3a2ebb4e7940 = _3d3550fa73b5(_162c34386cb2)
        _d40a67d009ac = _3d3550fa73b5(_274afd2f9472)
        _8d51938f3534 = _d40a67d009ac / _3a2ebb4e7940 if _3a2ebb4e7940 > 0 else 0
        self._3622c3f4fc5c._2394b93e9ae5(f"[audit] base={_3a2ebb4e7940} -> chunks={_d40a67d009ac} (avg {_8d51938f3534:.2f} per sample)")

    @_3092d024a202
    def _547c46d87741(self) -> _5d7afa179e83:
        """Return number of unique base samples (unique sample_id)."""
        if not _26f77d4733ad(self, "file_data_dict_list", _1d4965d3cd35):
            return 0
        return _3d3550fa73b5({_5d7afa179e83(_e02c2659728d["sample_id"]) for _e02c2659728d in self._b7081b77aea7})

    @_3092d024a202
    def _81850c88ee94(self) -> _5d7afa179e83:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _26f77d4733ad(self, "file_data_dict_list", _1d4965d3cd35):
            return 0

        _ace3b58db1d6 = _b565bd8b9ef3(_43fa1a31b65e)
        for _e02c2659728d in self._b7081b77aea7:
            _520022520fe7 = _5d7afa179e83(_e02c2659728d._a231624e36ee("sample_id", -1))
            for _ad6990ea145f in _e02c2659728d._a231624e36ee("word_positions", []):
                try:
                    _da8d64f21612 = _5d7afa179e83(_ad6990ea145f)
                except _cad5c0f8a0cb:
                    continue
                if _da8d64f21612 >= 0:
                    _ace3b58db1d6[_520022520fe7]._f364218e9251(_da8d64f21612)

        return _dfe0cb08072a(_3d3550fa73b5(_b9b34aa23674) for _b9b34aa23674 in _ace3b58db1d6._45aedbb22abc())
