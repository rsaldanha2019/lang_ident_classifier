# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import math
import os
import json
import random
import re
from itertools import _46166e286331, _b74152a544fa
from collections import _9c091ffaa7ad, _2193ff065e07
from _5d29f676299e import _b5cada2ded32
from _8b18f4178c1d._fc1b472d26e6 import _9c1483216106
from typing import _a5a94d8b7597, _6dfc16ead591, _5803ad393504

import _ec59adf0599f as _d0afcb0be876
import _ebf1da21692f
from _ebf1da21692f._f2494d370433._762e08553033 import _203cb1fa7dc4
from _21d9cfb18874 import _fdc3c5d3462d


class _b0aa81d312a5(_203cb1fa7dc4):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _a9c4564ce385 = _cfc3571f8de3  # class-level tokenizer (set on __init__)
    _bee89779f31b = _b540653fdfe3
    _30cbac2b6eac = {}
    def _4df71fa79528(
        self,
        _6481bf177058: _6ef6d90644bb,
        _6a645a806b40: _0d1c55a617bc,
        _9713c898c293: _a5a94d8b7597,
        _533269cf6d37: _3d1c328fa912,
        _c964a09141c2: _6ef6d90644bb,
        _2418a79664b3: _fdc3c5d3462d,
        _24bd309a6166: _0d1c55a617bc,
        _3580a254a065: _0d1c55a617bc,
        _3d665689d229: _9c76ee370266 = 1.0,
        _19692984113d: _3d1c328fa912 = 2,
        _3ff0bf577bfc: _3d1c328fa912 = 20,
        _aa3506b4d979: _0d1c55a617bc = _b540653fdfe3,
        _335fa6114a14: _6ef6d90644bb = _cfc3571f8de3,
        _e62cfef17931: _6ef6d90644bb = _cfc3571f8de3,
        _ec6bd4f635ba: _6ef6d90644bb = _cfc3571f8de3,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _d76fa024cc32()._e5e37ff02e5b()

        # Deterministic behavior
        _ebf1da21692f._130cbbb42d93(_3ff0bf577bfc)
        if _ebf1da21692f._792e749445a3._19657f09a356():
            _ebf1da21692f._792e749445a3._7178a7e02dc9(_3ff0bf577bfc)
        random._f3c3901f0105(_3ff0bf577bfc)
        _d0afcb0be876.random._f3c3901f0105(_3ff0bf577bfc)

        # Basic parameters & bookkeeping
        self._2418a79664b3 = _2418a79664b3
        self._24bd309a6166 = _24bd309a6166
        self._3580a254a065 = _3580a254a065
        self._aa3506b4d979 = _aa3506b4d979
        self._335fa6114a14 = _335fa6114a14
        self._e62cfef17931 = _e62cfef17931
        self._ec6bd4f635ba = _ec6bd4f635ba
        self._6a645a806b40 = _6a645a806b40
        self._6481bf177058 = _6481bf177058
        self._533269cf6d37 = _533269cf6d37
        self._87fa90a7e39d = 0
        self._3d665689d229 = _3d665689d229
        self._19692984113d = _19692984113d
        self._00bababf768f = -100

        # Tokenizer handling
        if _aa3506b4d979:
            _9713c898c293._43c22ed9e39f = "left"
        _eb503cf05f6e._a9c4564ce385 = _9713c898c293
        self._3320ff706d22 = _9713c898c293
        if self._aa3506b4d979:
            # preserve earlier code's fallback pad id (kept intentionally)
            # if not self.tokenizer.pad_token_id:
            #     self.tokenizer.pad_token_id = 128004
    
            # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
            #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
            #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
            #     print(f"Added padding token  <PAD> with (id: {tid})")
            
            if not _9713c898c293._7d2f0bed1e62:
                _9713c898c293._2eec0ab9f52c(["_P"], _d5c0ebb25dbc=_b540653fdfe3)
                _2b92416adca2 = _9713c898c293._3bfe956e3a53("_P")
                _9713c898c293._7d2f0bed1e62 = _2b92416adca2
                _bd7afedccd58(f"Added padding token  _P with (id: {_2b92416adca2})")

        # lang_codes
        self._3af6d58c81de = []
        
        # storage filled by _validate_and_load_file_data
        self._ff4d88b2fc6c: _6dfc16ead591[_afc4799a056c] = []
        self._9f6bbbfb4c0e = {}

        # Load and process files; then derive classes/weights
        self._47169df1fe72()
        self._0ba370247760, self._042098547e55 = self._1adf287f61fb(_c964a09141c2, _24bd309a6166)
        

    def _bdee0c840aac(self) -> _3d1c328fa912:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _1c66aa9c733f(self._ff4d88b2fc6c)

    def _094d78e2f9a1(self, _ca39c9399566: _3d1c328fa912) -> _afc4799a056c:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _3a441d87faff = self._ff4d88b2fc6c[_ca39c9399566]
        _12e2fa54d5f3 = _3a441d87faff._1285dcab0576("lang_code", "unk")
        _1fa770e60ea4 = _3a441d87faff["input_ids"]
        _3020570d3800 = _3a441d87faff["labels"]
        _5ca77b51a7bb = _3a441d87faff._1285dcab0576("word_positions", [])
        _d38ad751950d = _3a441d87faff["num_chunks"]
        _2c31ef5a0aad = _3a441d87faff._1285dcab0576("sample_id", _ca39c9399566)
        _616e4947cdc7 = _3a441d87faff._1285dcab0576("chunk_id", 0)
        _6030a080e421 = _3a441d87faff._1285dcab0576("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _3020570d3800 = [
            self._00bababf768f
            if _69bac5b12513 is _cfc3571f8de3
            else _3d1c328fa912(_69bac5b12513) if _90785efbc0cd(_69bac5b12513, _6ef6d90644bb) and _69bac5b12513._60fd619ee4f2("-")._5c7b75f0bad5()
            else _69bac5b12513
            for _69bac5b12513 in _3020570d3800
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._aa3506b4d979:
            _64a2bca5ad10 = [
                self._a374a08a3289(_69bac5b12513) if _90785efbc0cd(_69bac5b12513, _6ef6d90644bb) else _69bac5b12513
                for _69bac5b12513 in _3020570d3800
            ]
            _bbfcc417364c = _1c66aa9c733f(_64a2bca5ad10)
            _88e783e2c260 = _5295c213d508(0, self._533269cf6d37 - _bbfcc417364c)
            _64a2bca5ad10 = _64a2bca5ad10 + [self._00bababf768f] * _88e783e2c260
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _64a2bca5ad10 = _3020570d3800

        return {
            "lang_code": _12e2fa54d5f3,
            "input_ids": _ebf1da21692f._19ddd68075ae(_1fa770e60ea4, _bc63b73d7367=_ebf1da21692f._71338ec2d74e),
            "labels": _ebf1da21692f._19ddd68075ae(_64a2bca5ad10, _bc63b73d7367=_ebf1da21692f._71338ec2d74e),
            "sample_id": _2c31ef5a0aad,
            "chunk_id": _616e4947cdc7,
            "word_positions": _5ca77b51a7bb,
            "prompt_len": _6030a080e421,
            "num_chunks": _d38ad751950d,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _3d8108d3005c(self, _12e2fa54d5f3: _6ef6d90644bb) -> _3d1c328fa912:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _1ab4afa0ac71, _b28286470e82 in self._0ba370247760._86bb2eb51909():
            if _b28286470e82["lang_code"] == _6ef6d90644bb(_12e2fa54d5f3)._0370782b3d88():
                return _1ab4afa0ac71
        return self._0ba370247760._1285dcab0576("unk", {})._1285dcab0576("id", -1)

    def _a4e580884f8c(self, _e23cbbda8354: _3d1c328fa912) -> _6ef6d90644bb:
        """Reverse mapping; assumes class_id present."""
        return self._0ba370247760[_e23cbbda8354]["lang_code"]

    def _e88dac85c7a8(self) -> _3d1c328fa912:
        return _1c66aa9c733f(self._0ba370247760)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _0810fa6054e7(self, _df0cc48318ab: _afc4799a056c) -> _afc4799a056c:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _18dbdc0f9a96 = re._127751d4c463(r"[^\d\s]+")  # tokens with non-digit characters
        _475e1d3cfdc5 = _9c091ffaa7ad()

        if self._aa3506b4d979:
            _413f21b4921a = []
            for _f673e9a4afcd in self._ff4d88b2fc6c:
                _1e59776c55e6 = _f673e9a4afcd._1285dcab0576("labels", []) if _90785efbc0cd(_f673e9a4afcd, _afc4799a056c) else (_f673e9a4afcd[1] if _90785efbc0cd(_f673e9a4afcd, _5cd73a91b03c) and _1c66aa9c733f(_f673e9a4afcd) > 1 else [])
                _3dc4e1a839d3 = [_876c7b1eff15 for _876c7b1eff15 in _1e59776c55e6 if _876c7b1eff15 != self._00bababf768f]
                if _3dc4e1a839d3:
                    _413f21b4921a._2dcc4cf777da(_3dc4e1a839d3)
            if _413f21b4921a:
                # decoded_texts = self.tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
                _87d44c6a4863 = [
                    _69bac5b12513._6e0128873289("||", " ")._0370782b3d88()
                    for _69bac5b12513 in self._3320ff706d22._cdb796ab9d39(_413f21b4921a, _979fd5339b09=_50627122a7a4)
                ]
                # Step 1: Create a reverse lookup dictionary (value -> key)
                _42d1a4aa7b78 = {_4ee5e90bced0: _bb1f7a6bf204 for _bb1f7a6bf204, _4ee5e90bced0 in _eb503cf05f6e._30cbac2b6eac._86bb2eb51909()}

                for _1a6585cf1273 in _87d44c6a4863:
                    # Step 2: Split the string, replace the values, and join them back
                    _1a6585cf1273 = ' '._8fc90ac08fae([_42d1a4aa7b78._1285dcab0576(_959fe5e14d28, _959fe5e14d28) for _959fe5e14d28 in _1a6585cf1273._24910183b02d()])
                    _d552555b2dd8 = _18dbdc0f9a96._cc112375c5c0(_1a6585cf1273)
                    _475e1d3cfdc5._30deb64296bc(_d552555b2dd8)
        else:
            for _f673e9a4afcd in self._ff4d88b2fc6c:
                _1e59776c55e6 = _f673e9a4afcd._1285dcab0576("labels", [])
                _d552555b2dd8 = [_8519e97130f6._0370782b3d88() for _8519e97130f6 in _1e59776c55e6 if _90785efbc0cd(_8519e97130f6, _6ef6d90644bb) and _18dbdc0f9a96._3c0dfdc4e73e(_8519e97130f6)]
                _475e1d3cfdc5._30deb64296bc(_d552555b2dd8)

        _dee8dd5d99a3 = {_4ee5e90bced0["lang_code"]: _bb1f7a6bf204 for _bb1f7a6bf204, _4ee5e90bced0 in _df0cc48318ab._86bb2eb51909()}

        for _3e74f610e5e4, _975585760999 in _475e1d3cfdc5._86bb2eb51909():
            _3e74f610e5e4 = _3e74f610e5e4._0370782b3d88()
            _57d45b8e8845 = self._9f6bbbfb4c0e._1285dcab0576(_3e74f610e5e4, [])
            _3faf10e5dc50 = _dbcdad1a3e86(_552a49517de6._1285dcab0576("samples_after_processing", 0) for _552a49517de6 in _57d45b8e8845)
            if _3e74f610e5e4 in _dee8dd5d99a3:
                _ca39c9399566 = _dee8dd5d99a3[_3e74f610e5e4]
                _aaa5936411f3 = _df0cc48318ab[_ca39c9399566]
                _a0e9bb2f25d5 = _aaa5936411f3["lang_files"] + _57d45b8e8845
                _ee79b45aad2b = _0bdde09334bf({_552a49517de6["file_name"]: _552a49517de6 for _552a49517de6 in _a0e9bb2f25d5}._f656a4e8676d())
                _df0cc48318ab[_ca39c9399566] = {
                    "lang_code": _3e74f610e5e4,
                    "lang_samples": _aaa5936411f3["lang_samples"] + _3faf10e5dc50,
                    "lang_files": _ee79b45aad2b,
                }
            else:
                _3691bcb82996 = _1c66aa9c733f(_df0cc48318ab)
                _df0cc48318ab[_3691bcb82996] = {
                    "lang_code": _3e74f610e5e4,
                    "lang_samples": _3faf10e5dc50,
                    "lang_files": _57d45b8e8845,
                }
                _dee8dd5d99a3[_3e74f610e5e4] = _3691bcb82996

        return _df0cc48318ab

    def _df55cbaf11e9(self, _52c9723db4ab: _6dfc16ead591[_9c76ee370266]) -> _d0afcb0be876._65a01c0c30ca:
        _4091c1859a5f = _d0afcb0be876._dbcdad1a3e86(_52c9723db4ab)
        return _52c9723db4ab / _4091c1859a5f if _4091c1859a5f != 0 else _d0afcb0be876._38f2b7eb832b(_52c9723db4ab)

    def _56831576f197(self, _3ebd9fce2590: _afc4799a056c) -> _5803ad393504[_6dfc16ead591[_9c76ee370266], _afc4799a056c]:
        _3faf10e5dc50 = _dbcdad1a3e86(_f673e9a4afcd["lang_samples"] for _f673e9a4afcd in _3ebd9fce2590._f656a4e8676d())
        for _12e2fa54d5f3, _85a14fc93259 in _3ebd9fce2590._86bb2eb51909():
            _2438a0a373fb = _85a14fc93259["lang_samples"]
            # # if class_samples > 0:
            # #     class_weight = total_samples / (class_samples * len(classes_dict))
            # # else:
            # #     class_weight = 0.0
            # if class_samples > 0:
            #     class_weight = total_samples / class_samples
            # else:
            #     class_weight = 0.0
            if _2438a0a373fb > 0 :
                _17dce8c1a5aa = math._2418a79664b3(_3faf10e5dc50 / _2438a0a373fb) + 1.0
            else:
                _17dce8c1a5aa = 0.0
            _3ebd9fce2590[_12e2fa54d5f3]["lang_weight"] = _17dce8c1a5aa
        _042098547e55 = [_f673e9a4afcd["lang_weight"] for _f673e9a4afcd in _3ebd9fce2590._f656a4e8676d()]
        # Update stored lang weights (keeps original behavior)
        for _5d3092ca069b, (_12e2fa54d5f3, _85a14fc93259) in _3751d1ecdb50(_3ebd9fce2590._86bb2eb51909()):
            _85a14fc93259["lang_weight"] = _042098547e55[_5d3092ca069b]
        return _042098547e55, _3ebd9fce2590

    def _7a3fe26b3ce4(self, _c964a09141c2: _6ef6d90644bb, _24bd309a6166: _0d1c55a617bc) -> _5803ad393504[_afc4799a056c, _afc4799a056c]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _3ebd9fce2590 = {}
        _042098547e55 = {}
        if os._fe2fda1756ec._be2604ae75be(_c964a09141c2):
            with _a9f381ed8e0b(_c964a09141c2, "r", _daa592e49ecd="utf8") as _c78919041d43:
                _2d3d861f5c86 = json._872effc6faef(_c78919041d43)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _3ebd9fce2590 = {
                    (_9c76ee370266(_bb1f7a6bf204) if "." in _bb1f7a6bf204 else _3d1c328fa912(_bb1f7a6bf204)): _4ee5e90bced0
                    for _bb1f7a6bf204, _4ee5e90bced0 in _2d3d861f5c86._86bb2eb51909()
                }

        if _24bd309a6166:
            _3ebd9fce2590 = self._8a9b7373f9d9(_df0cc48318ab=_3ebd9fce2590)
            _042098547e55, _3ebd9fce2590 = self._d8ca9c2d389e(_3ebd9fce2590=_3ebd9fce2590)
            with _a9f381ed8e0b(_c964a09141c2, "w", _daa592e49ecd="utf8") as _b8484c6759c5:
                json._51c6c626e41f(_3ebd9fce2590, _b8484c6759c5, _5671747881b6=2)

        return _3ebd9fce2590, _042098547e55

    def _c0f28c354708(self) -> _6dfc16ead591[_3d1c328fa912]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._a374a08a3289(_12e2fa54d5f3) for _12e2fa54d5f3 in self._ba702096fc8f] if _2778478c2e5a(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _63ab9dab1b3b(self, _74029ffa91a7: _9c76ee370266) -> _3d1c328fa912:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _3d1c328fa912(self._533269cf6d37 * _74029ffa91a7)

    @_22c369a125a9
    def _a6f40e75a209(_d6a35a415d61: _6ef6d90644bb) -> _0d1c55a617bc:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _0449abb4dd31
        for _7912d27427a7 in _d6a35a415d61:
            if "ARABIC" not in _0449abb4dd31._02766cc1cae9(_7912d27427a7, ""):
                return _b540653fdfe3
        return _50627122a7a4

    @_22c369a125a9
    def _4458a5740a9f(_f12b5142b473: _6ef6d90644bb) -> _6ef6d90644bb:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _eb503cf05f6e._604ce82a249f(_f12b5142b473):
            _bddd6de772ff = _f12b5142b473._0370782b3d88()._24910183b02d()
            _cc69154f6ae0 = " "._8fc90ac08fae(_f5c7a29eb640(_bddd6de772ff))
            return _cc69154f6ae0
        return _f12b5142b473

    def _fad35b0adaf4(self, _a4de5a167113: _6ef6d90644bb, _98fe92f978d6: _6ef6d90644bb) -> _9c76ee370266:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _b5cada2ded32(_cfc3571f8de3, _a4de5a167113, _98fe92f978d6)._dacdf6e515ce()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_22c369a125a9
    def _46641b5b14a2(_49084399f787) -> _5803ad393504[_6dfc16ead591[_afc4799a056c], _3d1c328fa912]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import time
        _4048a1efbe08 = time.time()
        _c3cdc55c7615, _481340484914, _728a671b2f1b, _017aa84d08bf, _24bd309a6166, _4b3b09702d2a = _49084399f787
        _3320ff706d22 = _eb503cf05f6e._a9c4564ce385
        _81028c262e5a = 0
        _b3bbaa4a1dca = _3320ff706d22._7d2f0bed1e62
        _7ab4e41ec66d: _6dfc16ead591[_afc4799a056c] = []

        # Clean inputs and prepare per-word lists
        _a363e68c3a21 = [_6f5aba9806d5._0370782b3d88() for _6f5aba9806d5 in _c3cdc55c7615]
        _aafb0998ac0d = [_69bac5b12513._0370782b3d88() for _69bac5b12513 in _481340484914]
        _ea213755b3eb = [_d6a35a415d61._24910183b02d() if _d6a35a415d61 else ["<empty>"] for _d6a35a415d61 in _a363e68c3a21]
        _90197664a938 = []
        for _514aabf6b8c7, _8e40584760ec in _7c807028b561(_ea213755b3eb, _481340484914):
            _5c550f900904 = _8e40584760ec if _90785efbc0cd(_8e40584760ec, _0bdde09334bf) else (_8e40584760ec._0370782b3d88()._24910183b02d() if _8e40584760ec._0370782b3d88() else ["<empty>"])
            if _1c66aa9c733f(_5c550f900904) == 1:
                _5c550f900904 = [_5c550f900904[0]] * _1c66aa9c733f(_514aabf6b8c7)
            elif _1c66aa9c733f(_5c550f900904) != _1c66aa9c733f(_514aabf6b8c7):
                _5c550f900904 = _5c550f900904[:_1c66aa9c733f(_514aabf6b8c7)] if _1c66aa9c733f(_5c550f900904) > _1c66aa9c733f(_514aabf6b8c7) else _5c550f900904 + [_5c550f900904[-1]] * (_1c66aa9c733f(_514aabf6b8c7) - _1c66aa9c733f(_5c550f900904))
            _90197664a938._2dcc4cf777da(_5c550f900904)

        # Flatten all words for a single tokenizer call (faster)
        _2b8a67570b30 = _0bdde09334bf(_46166e286331(*_ea213755b3eb))
        _c925be21e596 = time.time()
        try:
            _f563a1f1db0b = _3320ff706d22(_2b8a67570b30, _1d3bb54c998f=_b540653fdfe3, _b7dbf4e6b507=_b540653fdfe3, _5303b9c12c4a=_b540653fdfe3)
        except _a43d2bd7f21c as _e8235f8e4a83:
            _bd7afedccd58(f"Tokenization error: {_e8235f8e4a83}")
            _f563a1f1db0b = {"input_ids": [[0] for _ in _2b8a67570b30]}
        # build word token info per sentence
        _3df7072066ea = 0
        _ff402e08eb73 = []
        for _514aabf6b8c7 in _ea213755b3eb:
            _b9c0d44117e8 = _1c66aa9c733f(_514aabf6b8c7)
            _06f211db2a4f = [(_5d3092ca069b, _f563a1f1db0b["input_ids"][_3df7072066ea + _5d3092ca069b], _1c66aa9c733f(_f563a1f1db0b["input_ids"][_3df7072066ea + _5d3092ca069b])) for _5d3092ca069b in _0a2eac52b52d(_b9c0d44117e8)]
            _ff402e08eb73._2dcc4cf777da(_06f211db2a4f)
            _3df7072066ea += _b9c0d44117e8

        # chunk each sentence into token windows
        for _ab5907a5d3b9, (_514aabf6b8c7, _45b06f7e79c3, _5c550f900904) in _3751d1ecdb50(_7c807028b561(_ea213755b3eb, _ff402e08eb73, _90197664a938)):
            _2c31ef5a0aad = _4b3b09702d2a + _ab5907a5d3b9
            _616e4947cdc7 = 0
            if _514aabf6b8c7 == ["<empty>"]:
                _1fa770e60ea4 = [0] * _728a671b2f1b
                _7ab4e41ec66d._2dcc4cf777da({
                    "sample_id": _2c31ef5a0aad,
                    "chunk_id": _616e4947cdc7,
                    "input_ids": _1fa770e60ea4,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _5d3092ca069b = 0
            _8b301a0c7051 = _1c66aa9c733f(_45b06f7e79c3)
            _b1402c746fb1 = []
            while _5d3092ca069b < _8b301a0c7051:
                _fa097325f524 = 0
                _1725d3c56482 = []
                _d420be5993ae = []
                _5ca77b51a7bb = []
                _34414a1c692e = _5d3092ca069b
                while _34414a1c692e < _8b301a0c7051:
                    _edbb9c914d97, _4a7e5b20aeab, _7662380dd04b = _45b06f7e79c3[_34414a1c692e]
                    _69e0807fa049 = _5c550f900904[_edbb9c914d97] if _edbb9c914d97 < _1c66aa9c733f(_5c550f900904) else _5c550f900904[-1] if _5c550f900904 else "<unknown>"
                    if _7662380dd04b > _728a671b2f1b and not _1725d3c56482:
                        _1725d3c56482 += _4a7e5b20aeab[:_728a671b2f1b]
                        _d420be5993ae._2dcc4cf777da(_69e0807fa049)
                        _5ca77b51a7bb._2dcc4cf777da(_edbb9c914d97)
                        _34414a1c692e += 1
                        break
                    if _fa097325f524 + _7662380dd04b > _728a671b2f1b and _1725d3c56482:
                        break
                    _1725d3c56482 += _4a7e5b20aeab
                    _d420be5993ae._2dcc4cf777da(_69e0807fa049)
                    _81028c262e5a += 1
                    _5ca77b51a7bb._2dcc4cf777da(_34414a1c692e)
                    _fa097325f524 += _7662380dd04b
                    _34414a1c692e += 1

                if not _1725d3c56482:
                    # fallback: take token prefix to avoid infinite loop
                    _1725d3c56482 = _45b06f7e79c3[_5d3092ca069b][1][:_728a671b2f1b] or [0]
                    _d420be5993ae = [_5c550f900904[_5d3092ca069b] if _5d3092ca069b < _1c66aa9c733f(_5c550f900904) else _5c550f900904[-1] if _5c550f900904 else "<unknown>"]
                    _5ca77b51a7bb = [_5d3092ca069b]
                    _81028c262e5a += 1
                    _5d3092ca069b += 1

                # pad tokens to fixed length
                if _1c66aa9c733f(_1725d3c56482) < _728a671b2f1b:
                    _1725d3c56482 += [_b3bbaa4a1dca] * (_728a671b2f1b - _1c66aa9c733f(_1725d3c56482))

                _b1402c746fb1._2dcc4cf777da({
                    "sample_id": _2c31ef5a0aad,
                    "chunk_id": _616e4947cdc7,
                    "input_ids": _1725d3c56482,
                    "labels": _d420be5993ae,
                    "word_positions": _5ca77b51a7bb,
                    "num_chunks": 1
                })
                _616e4947cdc7 += 1

                if _34414a1c692e >= _8b301a0c7051:
                    break

                # stride with overlap (in words)
                _98c885502560 = _1c66aa9c733f(_5ca77b51a7bb)
                _0af4e7dc04f7 = _3d1c328fa912(_017aa84d08bf * _98c885502560)
                _0af4e7dc04f7 = _e049aa03e645(_0af4e7dc04f7, _98c885502560 - 1) if _98c885502560 > 1 else 0
                _90b50a78291d = _34414a1c692e - _0af4e7dc04f7
                if _90b50a78291d <= _5d3092ca069b:
                    _90b50a78291d = _5d3092ca069b + 1
                _5d3092ca069b = _90b50a78291d

            _d38ad751950d = _1c66aa9c733f(_b1402c746fb1)
            for _0930a732ad26 in _b1402c746fb1:
                _0930a732ad26["num_chunks"] = _d38ad751950d
            _7ab4e41ec66d._06d4a6a3c76a(_b1402c746fb1)

            if not _eb503cf05f6e._bee89779f31b and not _24bd309a6166 and _d38ad751950d > 1:
                _bd7afedccd58(f"[DEBUG] sample_id={_2c31ef5a0aad}", _838e804d6039=_50627122a7a4)
                _eb503cf05f6e._bee89779f31b = _50627122a7a4

        # Timing/logging suppressed to preserve original behavior
        return _7ab4e41ec66d, _81028c262e5a

    # @staticmethod
    # def process_batch_gen_llm_classifier(args) -> Tuple[List[dict], int]:
    #     """
    #     Construct chunks for generative LLM framing.
    #     The function follows the previously specified format:
    #       - Insert single space tokens between words in both streams.
    #       - word_positions contains per-label-token positions and -1 entries for spaces.
    #       - Overlap computed in WORDS, not tokens.
    #     """
    #     import time
    #     start_time = time.time()
    #     (prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_test, start_sample_id) = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100

    #     # Chat-ish prefixes used in dataset construction
    #     # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
    #     # "Identify the language of every word and reply with space-separated codes only.\n"
    #     # "Do not include any explanation or extra text.\n")
    #     # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     input_prefix = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
    #     "Identify the language of every word and reply with space-separated codes only.\n"
    #     "Do not include any explanation or extra text.\n")
    #     response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
    #     input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
    #     response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
    #     space_ids = tokenizer.encode(" ", add_special_tokens=False)
    #     prefix = instruction_ids + input_prefix_ids
    #     suffix = response_prefix_ids
    #     eos_len = 1
    #     fixed_len = len(prefix) + len(suffix) + eos_len

    #     results: List[dict] = []
    #     local_label_counter = 0

    #     # Preprocess lines into words lists and align labels to words
    #     src_texts = [s.strip() for s in src_lines]
    #     tgt_texts = [t.strip() for t in tgt_lines]
    #     src_words_list = []
    #     tgt_words_list = []
    #     for src, tgt in zip(src_texts, tgt_lines):
    #         src_words = src.split() if src else ["<empty>"]
    #         tgt_words = tgt if isinstance(tgt, list) else (tgt.strip().split() if tgt.strip() else ["<empty>"])
    #         if len(tgt_words) == 1:
    #             tgt_words = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) != len(src_words):
    #             tgt_words = tgt_words[:len(src_words)] if len(tgt_words) > len(src_words) else tgt_words + [tgt_words[-1]] * (len(src_words) - len(tgt_words))
    #         src_words_list.append(src_words)
    #         tgt_words_list.append(tgt_words)

    #     # Flatten words for efficient tokenization
    #     all_src_words = list(chain(*src_words_list))
    #     all_tgt_words = list(chain(*tgt_words_list))

    #     unique_tgt_words = {w for words in tgt_words_list for w in words}

    #     for word in unique_tgt_words:
    #         if word not in LanguageIdentificationDataset.tracking_classes:
    #             class_tokens = tokenizer.encode(word, add_special_tokens=False)
    #             if len(class_tokens) > 1:
    #                 LanguageIdentificationDataset.tracking_classes[word] = f"{len(LanguageIdentificationDataset.tracking_classes)+1}"
    #             else:
    #                 LanguageIdentificationDataset.tracking_classes[word] = word
    #     # print(f"check tracking classes {LanguageIdentificationDataset.tracking_classes}")
    #     # FOR NEW TOKEN UNCOMMENT THIS
    #     # Unique Token logic
    #     # new_tokens = []
    #     # tracking = []

    #     # for word in unique_tgt_words:
    #     #     if len(tokenizer.encode(word, add_special_tokens=False)) > 1:
    #     #         new_token = f"{word}"
    #     #         new_tokens.append(new_token)
    #     #         tracking.append((word, new_token))

    #     # if new_tokens:
    #     #     tokenizer.add_tokens(new_tokens, special_tokens=False)
    #     #     for word, token in tracking:
    #     #         token_id = tokenizer.convert_tokens_to_ids(token)
    #     #         print(f"Added word '{word}' with token {token} (id: {token_id})")
    #     # else:
    #     #     print("No multi-token words found")
        
    #     # tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     # tok_tgt = tokenizer(all_tgt_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_tgt = tokenizer([str(LanguageIdentificationDataset.tracking_classes.get(tgt)) for tgt in all_tgt_words], add_special_tokens=False, return_attention_mask=False)["input_ids"]

    #     # Build per-line token info
    #     src_idx = 0
    #     tgt_idx = 0
    #     src_word_token_info_list = []
    #     tgt_word_token_info_list = []
    #     for src_words, tgt_words in zip(src_words_list, tgt_words_list):
    #         src_len = len(src_words)
    #         tgt_len = len(tgt_words)
    #         if src_words == ["<empty>"] or tgt_words == ["<empty>"]:
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             continue
    #         try:
    #             src_info = [(w, tok_src[src_idx + i], len(tok_src[src_idx + i]) if isinstance(tok_src[src_idx + i], list) else 1) for i, w in enumerate(src_words)]
    #             tgt_info = [(w, tok_tgt[tgt_idx + i], len(tok_tgt[tgt_idx + i]) if isinstance(tok_tgt[tgt_idx + i], list) else 1) for i, w in enumerate(tgt_words)]
    #         except IndexError:
    #             # On tokenization mismatches, fallback safely
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             src_idx += src_len
    #             tgt_idx += tgt_len
    #             continue
    #         src_word_token_info_list.append(src_info)
    #         tgt_word_token_info_list.append(tgt_info)
    #         src_idx += src_len
    #         tgt_idx += tgt_len

    #     # Build chunks per sentence
    #     for line_idx, (src_words, src_word_token_info, tgt_word_token_info) in enumerate(zip(src_words_list, src_word_token_info_list, tgt_word_token_info_list)):
    #         sample_id = start_sample_id + line_idx
    #         chunk_id = 0
    #         src_word_labels = [info[0] for info in tgt_word_token_info]

    #         if src_words == ["<empty>"]:
    #             input_ids = prefix + [0] + suffix + [eos_id]
    #             labels = [ignore_index] * len(input_ids)
    #             pad_len = max_seq_len - len(input_ids)
    #             if pad_len > 0:
    #                 input_ids += [pad_id] * pad_len
    #                 labels += [ignore_index] * pad_len
    #             results.append({
    #                 "lang_codes": ["<empty>"],
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": [0],
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": len(prefix) + 1 + len(suffix),
    #                 "chunk_words": ["<empty>"],
    #                 "chunk_labels": ["<empty>"],
    #                 "num_chunks": 1
    #             })
    #             continue

    #         i = 0
    #         n = len(src_word_token_info)
    #         prev_j = -1
    #         chunk_results = []
    #         while i < n:
    #             total_len = fixed_len
    #             chunk_input_tokens = []
    #             chunk_label_tokens = []
    #             word_positions = []
    #             lang_codes = []
    #             chunk_words = []
    #             chunk_labels = []
    #             j = i
    #             while j < n:
    #                 _, src_ids, src_len = src_word_token_info[j]
    #                 tgt_word, tgt_ids, tgt_len = tgt_word_token_info[j]
    #                 inter_word_spaces = len(space_ids) if j < n - 1 else 0
    #                 # choose conservative word_total so both streams fit
    #                 word_total = max(src_len, tgt_len) + inter_word_spaces
    #                 if total_len + word_total > max_seq_len * 0.9:
    #                     break

    #                 # append inputs and spaces
    #                 chunk_input_tokens += src_ids if isinstance(src_ids, list) else [src_ids]
    #                 if inter_word_spaces:
    #                     chunk_input_tokens += space_ids

    #                 # append labels and word_positions
    #                 if tgt_len:
    #                     chunk_label_tokens += tgt_ids if isinstance(tgt_ids, list) else [tgt_ids]
    #                     word_positions += [j] * tgt_len
    #                 if inter_word_spaces:
    #                     chunk_label_tokens += space_ids
    #                     word_positions += [-1] * inter_word_spaces

    #                 lang_codes.append(tgt_word)
    #                 chunk_words.append(src_words[j])
    #                 chunk_labels.append(tgt_word)
    #                 local_label_counter += len(src_words[j])
    #                 total_len += word_total
    #                 j += 1

    #             if not chunk_input_tokens:
    #                 i += 1
    #                 continue

    #             flat_input_ids = chunk_input_tokens
    #             flat_label_ids = chunk_label_tokens
    #             prompt_len = len(prefix) + len(flat_input_ids) + len(suffix)

    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
    #             # RIGHT PAD + LEFT PAD TEST METHOD
    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
    #             # # pad to fixed size (inputs appended or prepended depending on test/train)
    #             # inputs_pad_len = max_seq_len - len(input_ids)
    #             # labels_pad_len = max_seq_len - len(labels)
    #             # if inputs_pad_len > 0:
    #             #     if is_test:
    #             #         input_ids = [pad_id] * inputs_pad_len + input_ids
    #             #     else:
    #             #         input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     if is_test:
    #             #         labels = [ignore_index] * labels_pad_len + labels
    #             #     else:
    #             #         labels += [ignore_index] * labels_pad_len
                
    #             # LEFT PAD METHOD
    #             if is_test is False:
    #                 input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             else:
    #                 input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             inputs_pad_len = max_seq_len - len(input_ids)
    #             labels_pad_len = max_seq_len - len(labels)
    #             if inputs_pad_len > 0:
    #                 input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # if is_test:
    #                 #     input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # else:
    #                 #     input_ids += [pad_id] * inputs_pad_len
    #             if labels_pad_len > 0:
    #                 labels = [ignore_index] * labels_pad_len + labels
    #                 # if is_test:
    #                 #     labels = [ignore_index] * labels_pad_len + labels
    #                 # else:
    #                 #     labels += [ignore_index] * labels_pad_len

    #             # if inputs_pad_len > 0:
    #             #     input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     labels += [ignore_index] * labels_pad_len

    #             if len(input_ids) != max_seq_len or len(labels) != max_seq_len:
    #                 raise RuntimeError(
    #                     f"[SEQ LEN VIOLATION] "
    #                     f"sample_id={sample_id} "
    #                     f"chunk_id={chunk_id} "
    #                     f"is_test={is_test} "
    #                     f"len(input_ids)={len(input_ids)} "
    #                     f"len(labels)={len(labels)} "
    #                     f"max_seq_len={max_seq_len} "
    #                     f"prompt_len={prompt_len} "
    #                     f"flat_input_len={len(flat_input_ids)} "
    #                     f"flat_label_len={len(flat_label_ids)}"
    #                 )


    #             chunk_results.append({
    #                 "lang_codes": lang_codes,
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": prompt_len,
    #                 "chunk_words": chunk_words,
    #                 "chunk_labels": chunk_labels,
    #                 "num_chunks": 1
    #             })
    #             chunk_id += 1

    #             if j >= n or j <= prev_j:
    #                 break
    #             prev_j = j
    #             overlap_words = max(1, int(overlap_ratio * len(chunk_words)))
    #             i = j - overlap_words if (j - overlap_words) > i else j

    #         num_chunks = len(chunk_results)
    #         for r in chunk_results:
    #             r["num_chunks"] = num_chunks
    #         results.extend(chunk_results)

    #         if not LanguageIdentificationDataset.is_debug_sample_shown and not is_test and num_chunks > 1:
    #             LanguageIdentificationDataset.is_debug_sample_shown = True

    #     return results, local_label_counter

    @_22c369a125a9
    def _dc7a81a9025e(_49084399f787) -> _5803ad393504[_6dfc16ead591[_afc4799a056c], _3d1c328fa912]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import time
        _4048a1efbe08 = time.time()
        (_335fa6114a14, _c3cdc55c7615, _481340484914, _728a671b2f1b, _017aa84d08bf, _3580a254a065, _4b3b09702d2a) = _49084399f787
        _3320ff706d22 = _eb503cf05f6e._a9c4564ce385
        _b3bbaa4a1dca = _3320ff706d22._7d2f0bed1e62 or _3320ff706d22._e3b0eb670d02
        _04cab00982f9 = _3320ff706d22._e3b0eb670d02
        _00bababf768f = -100

        # Chat-ish prefixes used in dataset construction
        _afa7e446f345 = _3320ff706d22._31523fce3feb._fca25d648708()
        if "llama" in _afa7e446f345:
            _0fab52feb44d = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _04fb5ac9611f = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        elif "qwen" in _afa7e446f345:
            _0fab52feb44d = ("<|im_start|>system\nYou are Qwen, created by Alibaba Cloud."
            "You are a helpful assistant.<|im_end|>\n<|im_start|>user\n"
            "Instructions:\nIdentify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _04fb5ac9611f = "<|im_end|>\n<|im_start|>assistant\n"
        elif "gemma" in _afa7e446f345:
            _0fab52feb44d = ("<bos><start_of_turn>user\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _04fb5ac9611f = "<end_of_turn>\n<start_of_turn>model\n"
        else:
            raise _914f119daa35(f"Gen LLM module currently doesnt support {_afa7e446f345}")
        _c2ca8ec89ae7 = _3320ff706d22._b447e0d023c6(_335fa6114a14, _1d3bb54c998f=_b540653fdfe3)
        _ee62531dce5a = _3320ff706d22._b447e0d023c6(_0fab52feb44d, _1d3bb54c998f=_b540653fdfe3)
        _a0b19b6ae9b6 = _3320ff706d22._b447e0d023c6(_04fb5ac9611f, _1d3bb54c998f=_b540653fdfe3)
        # space_ids = tokenizer.encode(" ", add_special_tokens=False)
        _d232a7f3eab5 = _3320ff706d22._b447e0d023c6("||", _1d3bb54c998f=_b540653fdfe3)
        _1c1abd8c1db4 = _c2ca8ec89ae7 + _ee62531dce5a
        _bb08e7fcdb24 = _a0b19b6ae9b6
        _9da47b3cdb14 = 1
        _21ec73328400 = _1c66aa9c733f(_1c1abd8c1db4) + _1c66aa9c733f(_bb08e7fcdb24) + _9da47b3cdb14

        _7ab4e41ec66d: _6dfc16ead591[_afc4799a056c] = []
        _81028c262e5a = 0

        # Preprocess lines into words lists and align labels to words
        _a363e68c3a21 = [_6f5aba9806d5._0370782b3d88() for _6f5aba9806d5 in _c3cdc55c7615]
        _aafb0998ac0d = [_69bac5b12513._0370782b3d88() for _69bac5b12513 in _481340484914]
        _ea213755b3eb = []
        _04b1e5ce70b2 = []
        for _b1e08120fb41, _8e40584760ec in _7c807028b561(_a363e68c3a21, _481340484914):
            _514aabf6b8c7 = _b1e08120fb41._24910183b02d() if _b1e08120fb41 else ["<empty>"]
            _688e32c6a0cd = _8e40584760ec if _90785efbc0cd(_8e40584760ec, _0bdde09334bf) else (_8e40584760ec._0370782b3d88()._24910183b02d() if _8e40584760ec._0370782b3d88() else ["<empty>"])
            if _1c66aa9c733f(_688e32c6a0cd) == 1:
                _688e32c6a0cd = [_688e32c6a0cd[0]] * _1c66aa9c733f(_514aabf6b8c7)
            elif _1c66aa9c733f(_688e32c6a0cd) != _1c66aa9c733f(_514aabf6b8c7):
                _688e32c6a0cd = _688e32c6a0cd[:_1c66aa9c733f(_514aabf6b8c7)] if _1c66aa9c733f(_688e32c6a0cd) > _1c66aa9c733f(_514aabf6b8c7) else _688e32c6a0cd + [_688e32c6a0cd[-1]] * (_1c66aa9c733f(_514aabf6b8c7) - _1c66aa9c733f(_688e32c6a0cd))
            _ea213755b3eb._2dcc4cf777da(_514aabf6b8c7)
            _04b1e5ce70b2._2dcc4cf777da(_688e32c6a0cd)

        # Flatten words for efficient tokenization
        _2b8a67570b30 = _0bdde09334bf(_46166e286331(*_ea213755b3eb))
        _723a1b667db9 = _0bdde09334bf(_46166e286331(*_04b1e5ce70b2))

        _fc92c9fec6fa = {_7f873ed6cd17 for _bddd6de772ff in _04b1e5ce70b2 for _7f873ed6cd17 in _bddd6de772ff}

        for _959fe5e14d28 in _fc92c9fec6fa:
            if _959fe5e14d28 not in _eb503cf05f6e._30cbac2b6eac:
                _3bd130a40e25 = _3320ff706d22._b447e0d023c6(_959fe5e14d28, _1d3bb54c998f=_b540653fdfe3)
                if _1c66aa9c733f(_3bd130a40e25) > 1:
                    _eb503cf05f6e._30cbac2b6eac[_959fe5e14d28] = f"{_1c66aa9c733f(_eb503cf05f6e._30cbac2b6eac)+1}"
                else:
                    _eb503cf05f6e._30cbac2b6eac[_959fe5e14d28] = _959fe5e14d28
        
        _d9871419241c = _3320ff706d22(_2b8a67570b30, _1d3bb54c998f=_b540653fdfe3, _b7dbf4e6b507=_b540653fdfe3)["input_ids"]
        _5b1353e6cfdc = _3320ff706d22([_6ef6d90644bb(_eb503cf05f6e._30cbac2b6eac._1285dcab0576(_8e40584760ec)) for _8e40584760ec in _723a1b667db9], _1d3bb54c998f=_b540653fdfe3, _b7dbf4e6b507=_b540653fdfe3)["input_ids"]

        # Build per-line token info
        _3df7072066ea = 0
        _b6934cec7701 = 0
        _ff402e08eb73 = []
        _54b0ab75dcbe = []
        for _514aabf6b8c7, _688e32c6a0cd in _7c807028b561(_ea213755b3eb, _04b1e5ce70b2):
            _b9c0d44117e8 = _1c66aa9c733f(_514aabf6b8c7)
            _daef322489f6 = _1c66aa9c733f(_688e32c6a0cd)
            if _514aabf6b8c7 == ["<empty>"] or _688e32c6a0cd == ["<empty>"]:
                _ff402e08eb73._2dcc4cf777da([(_514aabf6b8c7[0], [0], 1)])
                _54b0ab75dcbe._2dcc4cf777da([(_688e32c6a0cd[0], [0], 1)])
                continue
            try:
                _06f211db2a4f = [(_7f873ed6cd17, _d9871419241c[_3df7072066ea + _5d3092ca069b], _1c66aa9c733f(_d9871419241c[_3df7072066ea + _5d3092ca069b]) if _90785efbc0cd(_d9871419241c[_3df7072066ea + _5d3092ca069b], _0bdde09334bf) else 1) for _5d3092ca069b, _7f873ed6cd17 in _3751d1ecdb50(_514aabf6b8c7)]
                _455918d8f9b2 = [(_7f873ed6cd17, _5b1353e6cfdc[_b6934cec7701 + _5d3092ca069b], _1c66aa9c733f(_5b1353e6cfdc[_b6934cec7701 + _5d3092ca069b]) if _90785efbc0cd(_5b1353e6cfdc[_b6934cec7701 + _5d3092ca069b], _0bdde09334bf) else 1) for _5d3092ca069b, _7f873ed6cd17 in _3751d1ecdb50(_688e32c6a0cd)]
            except _19f7f3331141:
                # On tokenization mismatches, fallback safely
                _ff402e08eb73._2dcc4cf777da([(_514aabf6b8c7[0], [0], 1)])
                _54b0ab75dcbe._2dcc4cf777da([(_688e32c6a0cd[0], [0], 1)])
                _3df7072066ea += _b9c0d44117e8
                _b6934cec7701 += _daef322489f6
                continue
            _ff402e08eb73._2dcc4cf777da(_06f211db2a4f)
            _54b0ab75dcbe._2dcc4cf777da(_455918d8f9b2)
            _3df7072066ea += _b9c0d44117e8
            _b6934cec7701 += _daef322489f6

        # Build chunks per sentence
        for _ab5907a5d3b9, (_514aabf6b8c7, _45b06f7e79c3, _7f8b52d8e462) in _3751d1ecdb50(_7c807028b561(_ea213755b3eb, _ff402e08eb73, _54b0ab75dcbe)):
            _2c31ef5a0aad = _4b3b09702d2a + _ab5907a5d3b9
            _616e4947cdc7 = 0
            _8b124f67cfd6 = [_e1dc28ece1db[0] for _e1dc28ece1db in _7f8b52d8e462]

            if _514aabf6b8c7 == ["<empty>"]:
                _bd7afedccd58(f"Skiiping line {_ab5907a5d3b9} in file since its empty")

            _5d3092ca069b = 0
            _8b301a0c7051 = _1c66aa9c733f(_45b06f7e79c3)
            _c5bd69930b95 = -1
            _b1402c746fb1 = []
            while _5d3092ca069b < _8b301a0c7051:
                _fa097325f524 = _21ec73328400
                _6010e76fd323 = []
                _b43457dd817c = []
                _5ca77b51a7bb = []
                _3af6d58c81de = []
                _6f03f22e70c9 = []
                _d420be5993ae = []
                _34414a1c692e = _5d3092ca069b
                while _34414a1c692e < _8b301a0c7051:
                    _, _8b359e6e6c0d, _b9c0d44117e8 = _45b06f7e79c3[_34414a1c692e]
                    _ea5692700b80, _4ddc388d65f9, _daef322489f6 = _7f8b52d8e462[_34414a1c692e]
                    _7367def4a458 = _1c66aa9c733f(_d232a7f3eab5) if _34414a1c692e < _8b301a0c7051 - 1 else 0
                    # choose conservative word_total so both streams fit
                    # word_total = max(src_len, tgt_len) + inter_word_spaces
                    # if total_len + word_total > max_seq_len * 0.9:
                    #     break

                    # account for BOTH streams + spaces
                    # word_input = src_len + inter_word_spaces
                    # word_label = tgt_len + inter_word_spaces
                    # word_total = word_input + word_label

                    _1e26d70db220 = _b9c0d44117e8 + _7367def4a458
                    _11c587a31c5a = _1e26d70db220 if _3580a254a065 else (_1e26d70db220 + _daef322489f6 + _7367def4a458)


                    if _fa097325f524 + _11c587a31c5a > _728a671b2f1b:
                        break


                    # append inputs and spaces
                    _6010e76fd323 += _8b359e6e6c0d if _90785efbc0cd(_8b359e6e6c0d, _0bdde09334bf) else [_8b359e6e6c0d]
                    if _7367def4a458:
                        _6010e76fd323 += _d232a7f3eab5

                    # append labels and word_positions
                    if _daef322489f6:
                        _b43457dd817c += _4ddc388d65f9 if _90785efbc0cd(_4ddc388d65f9, _0bdde09334bf) else [_4ddc388d65f9]
                        _5ca77b51a7bb += [_34414a1c692e] * _daef322489f6
                    if _7367def4a458:
                        _b43457dd817c += _d232a7f3eab5
                        _5ca77b51a7bb += [-1] * _7367def4a458

                    _3af6d58c81de._2dcc4cf777da(_ea5692700b80)
                    _6f03f22e70c9._2dcc4cf777da(_514aabf6b8c7[_34414a1c692e])
                    _d420be5993ae._2dcc4cf777da(_ea5692700b80)
                    _81028c262e5a += _1c66aa9c733f(_514aabf6b8c7[_34414a1c692e])
                    _fa097325f524 += _11c587a31c5a
                    _34414a1c692e += 1

                if not _6010e76fd323:
                    _5d3092ca069b += 1
                    continue

                _1256d8a8ad52 = _6010e76fd323
                _93dafc6d4903 = _b43457dd817c
                _6030a080e421 = _1c66aa9c733f(_1c1abd8c1db4) + _1c66aa9c733f(_1256d8a8ad52) + _1c66aa9c733f(_bb08e7fcdb24)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
                # RIGHT PAD + LEFT PAD TEST METHOD
                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

                # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
                # # pad to fixed size (inputs appended or prepended depending on test/train)
                # inputs_pad_len = max_seq_len - len(input_ids)
                # labels_pad_len = max_seq_len - len(labels)
                # if inputs_pad_len > 0:
                #     if is_test:
                #         input_ids = [pad_id] * inputs_pad_len + input_ids
                #     else:
                #         input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     if is_test:
                #         labels = [ignore_index] * labels_pad_len + labels
                #     else:
                #         labels += [ignore_index] * labels_pad_len
                
                # LEFT PAD METHOD
                if _3580a254a065 is _b540653fdfe3:
                    _1fa770e60ea4 = _1c1abd8c1db4 + _1256d8a8ad52 + _bb08e7fcdb24 + _93dafc6d4903 + [_04cab00982f9]
                    _1e59776c55e6 = [_00bababf768f] * _6030a080e421 + _93dafc6d4903 + [_00bababf768f]
                else:
                    # input_ids = prefix + flat_input_ids + suffix + [eos_id]
                    # labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                    # REMOVE EOS
                    # input_ids = prefix + flat_input_ids + suffix
                    # labels = [ignore_index] * prompt_len + flat_label_ids
                    _144ee71a546f = _1c1abd8c1db4 + _1256d8a8ad52 + _bb08e7fcdb24

                    _9233d4c97ff2 = _728a671b2f1b - _1c66aa9c733f(_144ee71a546f)
                    _1fa770e60ea4 = [_b3bbaa4a1dca] * _9233d4c97ff2 + _144ee71a546f

                    _1e59776c55e6 = [_00bababf768f] * _728a671b2f1b + _93dafc6d4903
                    # label_start = inputs_pad_len + prompt_len
                    # labels[label_start : label_start + len(flat_label_ids)] = flat_label_ids

                if not _3580a254a065:
                    _9233d4c97ff2 = _728a671b2f1b - _1c66aa9c733f(_1fa770e60ea4)
                    _9f6365d3922d = _728a671b2f1b - _1c66aa9c733f(_1e59776c55e6)
                    if _9233d4c97ff2 > 0:
                        _1fa770e60ea4 = [_b3bbaa4a1dca] * _9233d4c97ff2 + _1fa770e60ea4
                        # if is_test:
                        #     input_ids = [pad_id] * inputs_pad_len + input_ids
                        # else:
                        #     input_ids += [pad_id] * inputs_pad_len
                    if _9f6365d3922d > 0:
                        _1e59776c55e6 = [_00bababf768f] * _9f6365d3922d + _1e59776c55e6
                        # if is_test:
                        #     labels = [ignore_index] * labels_pad_len + labels
                        # else:
                        #     labels += [ignore_index] * labels_pad_len

                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len

                # not respecting rule in test since test will be free flowing
                if _3580a254a065 is _b540653fdfe3 and (_1c66aa9c733f(_1fa770e60ea4) != _728a671b2f1b or _1c66aa9c733f(_1e59776c55e6) != _728a671b2f1b):
                    raise _395434d71a2d(
                        f"[SEQ LEN VIOLATION] "
                        f"sample_id={_2c31ef5a0aad} "
                        f"chunk_id={_616e4947cdc7} "
                        f"is_test={_3580a254a065} "
                        f"len(input_ids)={_1c66aa9c733f(_1fa770e60ea4)} "
                        f"len(labels)={_1c66aa9c733f(_1e59776c55e6)} "
                        f"max_seq_len={_728a671b2f1b} "
                        f"prompt_len={_6030a080e421} "
                        f"flat_input_len={_1c66aa9c733f(_1256d8a8ad52)} "
                        f"flat_label_len={_1c66aa9c733f(_93dafc6d4903)}"
                    )


                _b1402c746fb1._2dcc4cf777da({
                    "lang_codes": _3af6d58c81de,
                    "sample_id": _2c31ef5a0aad,
                    "chunk_id": _616e4947cdc7,
                    "word_positions": _5ca77b51a7bb,
                    "input_ids": _1fa770e60ea4,
                    "labels": _1e59776c55e6,
                    "prompt_len": _6030a080e421,
                    "chunk_words": _6f03f22e70c9,
                    "chunk_labels": _d420be5993ae,
                    "num_chunks": 1
                })
                _616e4947cdc7 += 1

                if _34414a1c692e >= _8b301a0c7051 or _34414a1c692e <= _c5bd69930b95:
                    break
                _c5bd69930b95 = _34414a1c692e
                _188c2eb59939 = _5295c213d508(1, _3d1c328fa912(_017aa84d08bf * _1c66aa9c733f(_6f03f22e70c9)))
                _5d3092ca069b = _34414a1c692e - _188c2eb59939 if (_34414a1c692e - _188c2eb59939) > _5d3092ca069b else _34414a1c692e

            _d38ad751950d = _1c66aa9c733f(_b1402c746fb1)
            for _0930a732ad26 in _b1402c746fb1:
                _0930a732ad26["num_chunks"] = _d38ad751950d
            _7ab4e41ec66d._06d4a6a3c76a(_b1402c746fb1)

            if not _eb503cf05f6e._bee89779f31b and not _3580a254a065 and _d38ad751950d > 1:
                _eb503cf05f6e._bee89779f31b = _50627122a7a4

        return _7ab4e41ec66d, _81028c262e5a

    # -------------------------
    # File processing & validation
    # -------------------------
    def _a2c67e36d785(self, _d01c8447fa2a: _6ef6d90644bb, _8e145a57d442: _6ef6d90644bb, _4b3b09702d2a: _3d1c328fa912) -> _5803ad393504[_6ef6d90644bb, _6dfc16ead591[_afc4799a056c], _3d1c328fa912]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _762e08553033 = []

        with _a9f381ed8e0b(_d01c8447fa2a, "r", _daa592e49ecd="utf8") as _564eceea65fd, _a9f381ed8e0b(_8e145a57d442, "r", _daa592e49ecd="utf8") as _a8ece721b771:
            _c3cdc55c7615 = _564eceea65fd._2f73fa901a2d()[1:] if self._6a645a806b40 else _564eceea65fd._2f73fa901a2d()
            _481340484914 = _a8ece721b771._2f73fa901a2d()[1:] if self._6a645a806b40 else _a8ece721b771._2f73fa901a2d()

        # sample some share if requested
        _584d09822087 = _3d1c328fa912(_1c66aa9c733f(_c3cdc55c7615) * self._3d665689d229)
        if _584d09822087 < _1c66aa9c733f(_c3cdc55c7615):
            _0a99a8997f14 = _d0afcb0be876.random._0bcaae3a6538(_1c66aa9c733f(_c3cdc55c7615), _584d09822087, _6e0128873289=_b540653fdfe3)
            _c3cdc55c7615 = [_c3cdc55c7615[_5d3092ca069b] for _5d3092ca069b in _0a99a8997f14]
            _481340484914 = [_481340484914[_5d3092ca069b] for _5d3092ca069b in _0a99a8997f14]

        _12e2fa54d5f3 = _0bdde09334bf({_69bac5b12513._0370782b3d88() for _69bac5b12513 in _481340484914})[0] if _481340484914 else "unk"
        self._2418a79664b3._e1dc28ece1db(f"Sampled {self._3d665689d229 * 100:.1f}% of {_d01c8447fa2a}: {_1c66aa9c733f(_c3cdc55c7615)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _3e578f644ceb(_8ab0646d05f0, _bf315a881759):
            _6960c7ac47fe = _253ddfd07962(_8ab0646d05f0)
            while _50627122a7a4:
                _01ac0bcf6eda = _0bdde09334bf(_b74152a544fa(_6960c7ac47fe, _bf315a881759))
                if not _01ac0bcf6eda:
                    break
                yield _01ac0bcf6eda

        _bf315a881759 = 10_000
        if self._aa3506b4d979:
            _b9f7e1be2b90 = [
                (self._335fa6114a14, _d8e839d663d2, _4e10cb62b22e, self._533269cf6d37, 0.25, self._3580a254a065, _4b3b09702d2a + _18b7dac7185c * _bf315a881759)
                for _18b7dac7185c, (_d8e839d663d2, _4e10cb62b22e) in _3751d1ecdb50(_7c807028b561(_34dc04afa0dc(_c3cdc55c7615, _bf315a881759), _34dc04afa0dc(_481340484914, _bf315a881759)))
            ]
            with _9c1483216106(self._19692984113d) as _af9ea48b50eb:
                _37f48a903cbe = _af9ea48b50eb._aea42e62a9a8(_eb503cf05f6e._ebfd4925c033, _b9f7e1be2b90)
        else:
            _b9f7e1be2b90 = [
                (_d8e839d663d2, _4e10cb62b22e, self._533269cf6d37, 0.5, self._24bd309a6166, _4b3b09702d2a + _18b7dac7185c * _bf315a881759)
                for _18b7dac7185c, (_d8e839d663d2, _4e10cb62b22e) in _3751d1ecdb50(_7c807028b561(_34dc04afa0dc(_c3cdc55c7615, _bf315a881759), _34dc04afa0dc(_481340484914, _bf315a881759)))
            ]
            with _9c1483216106(self._19692984113d) as _af9ea48b50eb:
                _37f48a903cbe = _af9ea48b50eb._aea42e62a9a8(_eb503cf05f6e._df4005fa154c, _b9f7e1be2b90)

        _36f085977947 = []
        for _7ab4e41ec66d, _abc76afca9e9 in _37f48a903cbe:
            _36f085977947._06d4a6a3c76a(_7ab4e41ec66d)
            self._87fa90a7e39d += _abc76afca9e9

        if _36f085977947:
            _762e08553033 = _36f085977947

        return _12e2fa54d5f3, _762e08553033, _1c66aa9c733f(_c3cdc55c7615)

    def _b64f339af492(self) -> _cfc3571f8de3:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _c84aa2f7eafc = 0

        for _4d5809e79300 in os._c6a27ffa9683(self._6481bf177058):
            self._2418a79664b3._e1dc28ece1db(f"Now processing {os._fe2fda1756ec._8fc90ac08fae(self._6481bf177058, _4d5809e79300)} directory.")
            _c3eb49f032ef = os._fe2fda1756ec._8fc90ac08fae(self._6481bf177058, _4d5809e79300, "src")
            _02a678dfe0e4 = os._fe2fda1756ec._8fc90ac08fae(self._6481bf177058, _4d5809e79300, "tgt")

            _a4d0f3f85f43 = []
            _a8c42a0cd239 = []
            for _d01c8447fa2a in os._c6a27ffa9683(_c3eb49f032ef):
                _209f05600059 = _b540653fdfe3
                for _8e145a57d442 in os._c6a27ffa9683(_02a678dfe0e4):
                    if _d01c8447fa2a._24910183b02d(".")[0] == _8e145a57d442._24910183b02d(".")[0]:
                        _a4d0f3f85f43._2dcc4cf777da(_d01c8447fa2a)
                        _a8c42a0cd239._2dcc4cf777da(_8e145a57d442)
                        _209f05600059 = _50627122a7a4
                        break
                if not _209f05600059:
                    self._2418a79664b3._e1dc28ece1db(f"Skipping file {_d01c8447fa2a} since matching label file not found in {_02a678dfe0e4}.")

            _56da9feb0065 = [os._fe2fda1756ec._8fc90ac08fae(_c3eb49f032ef, _552a49517de6) for _552a49517de6 in _a4d0f3f85f43 if os._fe2fda1756ec._3a7845eb9e6a(os._fe2fda1756ec._8fc90ac08fae(_c3eb49f032ef, _552a49517de6))]
            _f6bffbe52ada = [os._fe2fda1756ec._8fc90ac08fae(_02a678dfe0e4, _552a49517de6) for _552a49517de6 in _a8c42a0cd239 if os._fe2fda1756ec._3a7845eb9e6a(os._fe2fda1756ec._8fc90ac08fae(_02a678dfe0e4, _552a49517de6))]

            if _1c66aa9c733f(_56da9feb0065) != _1c66aa9c733f(_f6bffbe52ada):
                raise _914f119daa35(f"Number of files in {_c3eb49f032ef} ({_1c66aa9c733f(_56da9feb0065)}) does not match {_02a678dfe0e4} ({_1c66aa9c733f(_f6bffbe52ada)})")

            for _d01c8447fa2a, _8e145a57d442 in _7c807028b561(_56da9feb0065, _f6bffbe52ada):
                _1b98f3aba0ea = _dbcdad1a3e86(1 for _ in _a9f381ed8e0b(_d01c8447fa2a))
                _b25d9a2dc1f8 = _dbcdad1a3e86(1 for _ in _a9f381ed8e0b(_8e145a57d442))
                _1b98f3aba0ea = _1b98f3aba0ea - 1 if self._6a645a806b40 else _1b98f3aba0ea
                _b25d9a2dc1f8 = _b25d9a2dc1f8 - 1 if self._6a645a806b40 else _b25d9a2dc1f8

                if _1b98f3aba0ea != _b25d9a2dc1f8:
                    self._2418a79664b3._e1dc28ece1db(f"{_1b98f3aba0ea} lines in {_d01c8447fa2a} do not match with {_b25d9a2dc1f8} in {_8e145a57d442}, skipping these files")
                    continue

                self._2418a79664b3._e1dc28ece1db(f"Processing {_d01c8447fa2a} and {_8e145a57d442} with {_b25d9a2dc1f8} samples.")
                _12e2fa54d5f3, _ff4d88b2fc6c, _c17f5b719e74 = self._47c3aa978bdd(_d01c8447fa2a, _8e145a57d442, _4b3b09702d2a=_c84aa2f7eafc)
                _c84aa2f7eafc += _c17f5b719e74

                self._ff4d88b2fc6c._06d4a6a3c76a(_ff4d88b2fc6c)
                if self._24bd309a6166:
                    if _12e2fa54d5f3 not in self._9f6bbbfb4c0e:
                        self._9f6bbbfb4c0e._30deb64296bc({
                            _12e2fa54d5f3: [{
                                "file_name": os._fe2fda1756ec._62ab42426d06(_8e145a57d442),
                                "samples_before_processing": _b25d9a2dc1f8,
                                "samples_after_processing": _1c66aa9c733f(_ff4d88b2fc6c)
                            }]
                        })
                    else:
                        self._9f6bbbfb4c0e[_12e2fa54d5f3]._2dcc4cf777da({
                            "file_name": os._fe2fda1756ec._62ab42426d06(_8e145a57d442),
                            "samples_before_processing": _b25d9a2dc1f8,
                            "samples_after_processing": _1c66aa9c733f(_ff4d88b2fc6c)
                        })
                if _12e2fa54d5f3 not in self._3af6d58c81de:
                    self._3af6d58c81de._2dcc4cf777da(_12e2fa54d5f3)
                self._2418a79664b3._e1dc28ece1db(f"Files {_d01c8447fa2a} and {_8e145a57d442} have {_1c66aa9c733f(_ff4d88b2fc6c)} samples after processing.")

        # verify dataset integrity
        self._ed8850531429()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _fe8fc20854aa(self) -> _cfc3571f8de3:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _0862678d88cb = self._ff4d88b2fc6c
        if not _0862678d88cb:
            self._2418a79664b3._e1dc28ece1db("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _a84784dfe882 = [_63de0dd09015["sample_id"] for _63de0dd09015 in _0862678d88cb]
        _ac3ca5c8918f = _e945b78f564b(_a84784dfe882)
        _2f4b88eba0e8 = _5295c213d508(_ac3ca5c8918f)
        _7a2e3f2e37e0 = (_1c66aa9c733f(_ac3ca5c8918f) == _2f4b88eba0e8 + 1)
        self._2418a79664b3._e1dc28ece1db(f"[sample_id] unique={_1c66aa9c733f(_ac3ca5c8918f)} max={_2f4b88eba0e8} coverage_ok={_7a2e3f2e37e0} (expect True)")
        if not _7a2e3f2e37e0:
            _26f71c7cb23a = _0eeea6a41653(_e945b78f564b(_0a2eac52b52d(_2f4b88eba0e8 + 1)) - _ac3ca5c8918f)
            self._2418a79664b3._e1dc28ece1db(f" Missing sample_ids: {_26f71c7cb23a[:20]}{' ...' if _1c66aa9c733f(_26f71c7cb23a) > 20 else ''}")
            raise _914f119daa35(f"Increase max_seq_len as missing sample_ids detected: {_26f71c7cb23a[:20]}{' ...' if _1c66aa9c733f(_26f71c7cb23a) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _bd6d82e2ed36 = [(_63de0dd09015["sample_id"], _63de0dd09015["chunk_id"]) for _63de0dd09015 in _0862678d88cb]
        _29507a1c8902 = [_bb1f7a6bf204 for _bb1f7a6bf204, _4ee5e90bced0 in _9c091ffaa7ad(_bd6d82e2ed36)._86bb2eb51909() if _4ee5e90bced0 > 1]
        self._2418a79664b3._e1dc28ece1db(f"[(sample_id,chunk_id)] duplicates: {_1c66aa9c733f(_29507a1c8902)} (expect 0)")
        if _29507a1c8902:
            self._2418a79664b3._e1dc28ece1db(f" Examples: {_29507a1c8902[:10]}")
            raise _914f119daa35(f"Duplicate (sample_id, chunk_id) pairs detected: {_29507a1c8902[:10]}")

        # 3) per-sample chunk_id sequentiality
        _82de55aeb6b3 = _2193ff065e07(_0bdde09334bf)
        for _63de0dd09015 in _0862678d88cb:
            _82de55aeb6b3[_63de0dd09015["sample_id"]]._2dcc4cf777da(_63de0dd09015["chunk_id"])
        _9c687b405436 = {}
        for _11f3b9706043, _4a7e5b20aeab in _82de55aeb6b3._86bb2eb51909():
            _9a872fbeab08 = _0eeea6a41653(_4a7e5b20aeab)
            _5f5d6e490496 = _0bdde09334bf(_0a2eac52b52d(_1c66aa9c733f(_9a872fbeab08)))
            if _9a872fbeab08 != _5f5d6e490496:
                _9c687b405436[_11f3b9706043] = {"have": _9a872fbeab08[:20], "expected_prefix": _5f5d6e490496[:20]}
        self._2418a79664b3._e1dc28ece1db(f"[per-sample chunk_id sequence] bad_samples: {_1c66aa9c733f(_9c687b405436)} (expect 0)")
        if _9c687b405436:
            _11ede34dac28 = _0bdde09334bf(_9c687b405436._86bb2eb51909())[:5]
            for _11f3b9706043, _e1dc28ece1db in _11ede34dac28:
                self._2418a79664b3._e1dc28ece1db(f" sample_id={_11f3b9706043} have={_e1dc28ece1db['have']} expected_prefix={_e1dc28ece1db['expected_prefix']}")
            raise _914f119daa35(f"Non-sequential chunk_id sequences detected for sample_ids: {_0bdde09334bf(_9c687b405436._70df0b919572())[:5]}")

        # 4) overall stats reporting
        _b9b71e9a8ba1 = _1c66aa9c733f(_ac3ca5c8918f)
        _c2002ee14be6 = _1c66aa9c733f(_0862678d88cb)
        _5ffb82a409a3 = _c2002ee14be6 / _b9b71e9a8ba1 if _b9b71e9a8ba1 > 0 else 0
        self._2418a79664b3._e1dc28ece1db(f"[audit] base={_b9b71e9a8ba1} -> chunks={_c2002ee14be6} (avg {_5ffb82a409a3:.2f} per sample)")

    @_aae05953f708
    def _e8c34ce3343e(self) -> _3d1c328fa912:
        """Return number of unique base samples (unique sample_id)."""
        if not _73eb52085102(self, "file_data_dict_list", _cfc3571f8de3):
            return 0
        return _1c66aa9c733f({_3d1c328fa912(_f673e9a4afcd["sample_id"]) for _f673e9a4afcd in self._ff4d88b2fc6c})

    @_aae05953f708
    def _394d9d3654bd(self) -> _3d1c328fa912:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _73eb52085102(self, "file_data_dict_list", _cfc3571f8de3):
            return 0

        _83c2fbb27f66 = _2193ff065e07(_e945b78f564b)
        for _f673e9a4afcd in self._ff4d88b2fc6c:
            _11f3b9706043 = _3d1c328fa912(_f673e9a4afcd._1285dcab0576("sample_id", -1))
            for _a4dcd5605018 in _f673e9a4afcd._1285dcab0576("word_positions", []):
                try:
                    _c338edd1e80c = _3d1c328fa912(_a4dcd5605018)
                except _a43d2bd7f21c:
                    continue
                if _c338edd1e80c >= 0:
                    _83c2fbb27f66[_11f3b9706043]._53aaa845c26e(_c338edd1e80c)

        return _dbcdad1a3e86(_1c66aa9c733f(_65f1288b6354) for _65f1288b6354 in _83c2fbb27f66._f656a4e8676d())
