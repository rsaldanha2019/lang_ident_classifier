# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import math
import os
import json
import random
import re
from itertools import _28a334689f55, _a89f01fafcb3
from collections import _80f0a681e890, _f05bde3ccdf2
from _b2f63ea3abf7 import _7e0101309245
from _67b0f6c10beb._ea2f213bf53e import _d66e6ac587de
from typing import _cfe12485a409, _829a9a45a59d, _6d0356d5585a

import _376b9ec05ddb as _6bb0ce512018
import _9a1e3d561c07
from _9a1e3d561c07._ad2a043c8b98._ba5c49d90060 import _79d7424fbd9d
from _a35518a44023 import _f74a854ecc6d


class _b8633cf21878(_79d7424fbd9d):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _6d72359a17cb = _ad0402046ac8  # class-level tokenizer (set on __init__)
    _1185003e127e = _0078635c21ad
    _e4d0683fd624 = {}
    def _b7070be0febb(
        self,
        _207c136a10cd: _71d7a04b1277,
        _6fddf642c265: _6b2b534d6558,
        _d9fb1ae3dbc2: _cfe12485a409,
        _800acf5cccd5: _930d91ca9532,
        _e45d8af4ba31: _71d7a04b1277,
        _8c276d6c84bd: _f74a854ecc6d,
        _22481d3fe483: _6b2b534d6558,
        _657ba10b6fb4: _6b2b534d6558,
        _a8cef213b88f: _18514138edde = 1.0,
        _dce319e8fa26: _930d91ca9532 = 2,
        _15692747cba1: _930d91ca9532 = 20,
        _0e7d92be427e: _6b2b534d6558 = _0078635c21ad,
        _961eef13cbe9: _71d7a04b1277 = _ad0402046ac8,
        _f2b88cf369d1: _71d7a04b1277 = _ad0402046ac8,
        _e86dd15d6acf: _71d7a04b1277 = _ad0402046ac8,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _5cae7f45b96d()._08b665fae007()

        # Deterministic behavior
        _9a1e3d561c07._0594d3fa0298(_15692747cba1)
        if _9a1e3d561c07._25b92e1b87a0._ba86088f06bf():
            _9a1e3d561c07._25b92e1b87a0._9d391472cc3f(_15692747cba1)
        random._3ad7c20fb535(_15692747cba1)
        _6bb0ce512018.random._3ad7c20fb535(_15692747cba1)

        # Basic parameters & bookkeeping
        self._8c276d6c84bd = _8c276d6c84bd
        self._22481d3fe483 = _22481d3fe483
        self._657ba10b6fb4 = _657ba10b6fb4
        self._0e7d92be427e = _0e7d92be427e
        self._961eef13cbe9 = _961eef13cbe9
        self._f2b88cf369d1 = _f2b88cf369d1
        self._e86dd15d6acf = _e86dd15d6acf
        self._6fddf642c265 = _6fddf642c265
        self._207c136a10cd = _207c136a10cd
        self._800acf5cccd5 = _800acf5cccd5
        self._5cdc410765dd = 0
        self._a8cef213b88f = _a8cef213b88f
        self._dce319e8fa26 = _dce319e8fa26
        self._b6dc2bddf6cf = -100

        # Tokenizer handling
        if _0e7d92be427e:
            _d9fb1ae3dbc2._47b3c25d474f = "left"
        _a4cf51e3e98e._6d72359a17cb = _d9fb1ae3dbc2
        self._6bb13f3953b0 = _d9fb1ae3dbc2
        if self._0e7d92be427e:
            # preserve earlier code's fallback pad id (kept intentionally)
            # if not self.tokenizer.pad_token_id:
            #     self.tokenizer.pad_token_id = 128004
    
            # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
            #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
            #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
            #     print(f"Added padding token  <PAD> with (id: {tid})")
            
            if not _d9fb1ae3dbc2._4d221d74ba4e:
                _d9fb1ae3dbc2._d184284720bf(["_P"], _6534335b933f=_0078635c21ad)
                _8294abaa294b = _d9fb1ae3dbc2._eeb090c21e2a("_P")
                _d9fb1ae3dbc2._4d221d74ba4e = _8294abaa294b
                _e5d61d597e1a(f"Added padding token  _P with (id: {_8294abaa294b})")

        # lang_codes
        self._46887b386fe7 = []
        
        # storage filled by _validate_and_load_file_data
        self._cd3cae497152: _829a9a45a59d[_8a544caf2f2a] = []
        self._7a86d34f3df9 = {}

        # Load and process files; then derive classes/weights
        self._ae4c8f671bde()
        self._b9c127ef3b96, self._58e1b33b7eb2 = self._a6284d11842d(_e45d8af4ba31, _22481d3fe483)
        

    def _b7fd6c08aba3(self) -> _930d91ca9532:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _5ee7ed6ec54e(self._cd3cae497152)

    def _be54a6db2c08(self, _87ec4f1d2cc3: _930d91ca9532) -> _8a544caf2f2a:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _a3f5572c2608 = self._cd3cae497152[_87ec4f1d2cc3]
        _64ec0ec2c123 = _a3f5572c2608._4c7811cdac2d("lang_code", "unk")
        _7a3920f28c38 = _a3f5572c2608["input_ids"]
        _75cf5b3060ce = _a3f5572c2608["labels"]
        _7c4070bdb99e = _a3f5572c2608._4c7811cdac2d("word_positions", [])
        _873ed553ad02 = _a3f5572c2608["num_chunks"]
        _56b725eb79fa = _a3f5572c2608._4c7811cdac2d("sample_id", _87ec4f1d2cc3)
        _d03d026d893a = _a3f5572c2608._4c7811cdac2d("chunk_id", 0)
        _e99b47af93cb = _a3f5572c2608._4c7811cdac2d("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _75cf5b3060ce = [
            self._b6dc2bddf6cf
            if _c5b0d6714c34 is _ad0402046ac8
            else _930d91ca9532(_c5b0d6714c34) if _57d5da28e849(_c5b0d6714c34, _71d7a04b1277) and _c5b0d6714c34._e90cf72f18a2("-")._9328cd14ec67()
            else _c5b0d6714c34
            for _c5b0d6714c34 in _75cf5b3060ce
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._0e7d92be427e:
            _47569df9e239 = [
                self._e247ef0cac3b(_c5b0d6714c34) if _57d5da28e849(_c5b0d6714c34, _71d7a04b1277) else _c5b0d6714c34
                for _c5b0d6714c34 in _75cf5b3060ce
            ]
            _798920beef98 = _5ee7ed6ec54e(_47569df9e239)
            _a3e1586d7254 = _fd271ae0d1a5(0, self._800acf5cccd5 - _798920beef98)
            _47569df9e239 = _47569df9e239 + [self._b6dc2bddf6cf] * _a3e1586d7254
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _47569df9e239 = _75cf5b3060ce

        return {
            "lang_code": _64ec0ec2c123,
            "input_ids": _9a1e3d561c07._3a90df4e9bf9(_7a3920f28c38, _87fbb3d3d905=_9a1e3d561c07._592cdf641c34),
            "labels": _9a1e3d561c07._3a90df4e9bf9(_47569df9e239, _87fbb3d3d905=_9a1e3d561c07._592cdf641c34),
            "sample_id": _56b725eb79fa,
            "chunk_id": _d03d026d893a,
            "word_positions": _7c4070bdb99e,
            "prompt_len": _e99b47af93cb,
            "num_chunks": _873ed553ad02,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _6767ca10a93b(self, _64ec0ec2c123: _71d7a04b1277) -> _930d91ca9532:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _412506998945, _dabf5af87912 in self._b9c127ef3b96._96614439f4c0():
            if _dabf5af87912["lang_code"] == _71d7a04b1277(_64ec0ec2c123)._6dac1b94f2d0():
                return _412506998945
        return self._b9c127ef3b96._4c7811cdac2d("unk", {})._4c7811cdac2d("id", -1)

    def _d9c7962c8460(self, _ce94cde329f4: _930d91ca9532) -> _71d7a04b1277:
        """Reverse mapping; assumes class_id present."""
        return self._b9c127ef3b96[_ce94cde329f4]["lang_code"]

    def _cbb30d003b01(self) -> _930d91ca9532:
        return _5ee7ed6ec54e(self._b9c127ef3b96)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _fe53a325d041(self, _a55045dbd6d8: _8a544caf2f2a) -> _8a544caf2f2a:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _f645c1a5a767 = re._83c66891be32(r"[^\d\s]+")  # tokens with non-digit characters
        _4746dc9d11a7 = _80f0a681e890()

        if self._0e7d92be427e:
            _d4cd924a04e7 = []
            for _08bb88f5c2da in self._cd3cae497152:
                _e293dd726ec6 = _08bb88f5c2da._4c7811cdac2d("labels", []) if _57d5da28e849(_08bb88f5c2da, _8a544caf2f2a) else (_08bb88f5c2da[1] if _57d5da28e849(_08bb88f5c2da, _cadf865f6f10) and _5ee7ed6ec54e(_08bb88f5c2da) > 1 else [])
                _5d41d87167f8 = [_8f620b3546d1 for _8f620b3546d1 in _e293dd726ec6 if _8f620b3546d1 != self._b6dc2bddf6cf]
                if _5d41d87167f8:
                    _d4cd924a04e7._e525c1927324(_5d41d87167f8)
            if _d4cd924a04e7:
                # decoded_texts = self.tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
                _9129fedfe42f = [
                    _c5b0d6714c34._ffed0cc01f67("||", " ")._6dac1b94f2d0()
                    for _c5b0d6714c34 in self._6bb13f3953b0._1c79f350c38a(_d4cd924a04e7, _4552fcbb4838=_1a819bd4416f)
                ]
                # Step 1: Create a reverse lookup dictionary (value -> key)
                _5d3139b27e20 = {_950127b9930f: _86ef50eb3d82 for _86ef50eb3d82, _950127b9930f in _a4cf51e3e98e._e4d0683fd624._96614439f4c0()}

                for _f841231978c8 in _9129fedfe42f:
                    # Step 2: Split the string, replace the values, and join them back
                    _f841231978c8 = ' '._8035eee40da5([_5d3139b27e20._4c7811cdac2d(_0528e140a116, _0528e140a116) for _0528e140a116 in _f841231978c8._5260a7491935()])
                    _414c2d1df5bf = _f645c1a5a767._2e8718a7f668(_f841231978c8)
                    _4746dc9d11a7._5f4459bacd1a(_414c2d1df5bf)
        else:
            for _08bb88f5c2da in self._cd3cae497152:
                _e293dd726ec6 = _08bb88f5c2da._4c7811cdac2d("labels", [])
                _414c2d1df5bf = [_e7b8cf4ce7a5._6dac1b94f2d0() for _e7b8cf4ce7a5 in _e293dd726ec6 if _57d5da28e849(_e7b8cf4ce7a5, _71d7a04b1277) and _f645c1a5a767._b9a0fe4f76dd(_e7b8cf4ce7a5)]
                _4746dc9d11a7._5f4459bacd1a(_414c2d1df5bf)

        _09494ca82a5a = {_950127b9930f["lang_code"]: _86ef50eb3d82 for _86ef50eb3d82, _950127b9930f in _a55045dbd6d8._96614439f4c0()}

        for _d6bd29692c47, _4721f7995b0a in _4746dc9d11a7._96614439f4c0():
            _d6bd29692c47 = _d6bd29692c47._6dac1b94f2d0()
            _0eb222ca9835 = self._7a86d34f3df9._4c7811cdac2d(_d6bd29692c47, [])
            _dcb2f4e8ade9 = _2bebe2558207(_b7a8f9423b0b._4c7811cdac2d("samples_after_processing", 0) for _b7a8f9423b0b in _0eb222ca9835)
            if _d6bd29692c47 in _09494ca82a5a:
                _87ec4f1d2cc3 = _09494ca82a5a[_d6bd29692c47]
                _bf907887fda2 = _a55045dbd6d8[_87ec4f1d2cc3]
                _3648af698f1d = _bf907887fda2["lang_files"] + _0eb222ca9835
                _c1d7d74b4b79 = _07bbf18385ec({_b7a8f9423b0b["file_name"]: _b7a8f9423b0b for _b7a8f9423b0b in _3648af698f1d}._e1c7be4d4ea1())
                _a55045dbd6d8[_87ec4f1d2cc3] = {
                    "lang_code": _d6bd29692c47,
                    "lang_samples": _bf907887fda2["lang_samples"] + _dcb2f4e8ade9,
                    "lang_files": _c1d7d74b4b79,
                }
            else:
                _a96ddf07676e = _5ee7ed6ec54e(_a55045dbd6d8)
                _a55045dbd6d8[_a96ddf07676e] = {
                    "lang_code": _d6bd29692c47,
                    "lang_samples": _dcb2f4e8ade9,
                    "lang_files": _0eb222ca9835,
                }
                _09494ca82a5a[_d6bd29692c47] = _a96ddf07676e

        return _a55045dbd6d8

    def _72a8fc0f0fa9(self, _21ebc71723a9: _829a9a45a59d[_18514138edde]) -> _6bb0ce512018._32a4d4d9298f:
        _b6f5db47e879 = _6bb0ce512018._2bebe2558207(_21ebc71723a9)
        return _21ebc71723a9 / _b6f5db47e879 if _b6f5db47e879 != 0 else _6bb0ce512018._6fb8d6b7a310(_21ebc71723a9)

    def _61acf876bdda(self, _309998dc47c9: _8a544caf2f2a) -> _6d0356d5585a[_829a9a45a59d[_18514138edde], _8a544caf2f2a]:
        _dcb2f4e8ade9 = _2bebe2558207(_08bb88f5c2da["lang_samples"] for _08bb88f5c2da in _309998dc47c9._e1c7be4d4ea1())
        for _64ec0ec2c123, _e82db9c3349f in _309998dc47c9._96614439f4c0():
            _c00844855650 = _e82db9c3349f["lang_samples"]
            # # if class_samples > 0:
            # #     class_weight = total_samples / (class_samples * len(classes_dict))
            # # else:
            # #     class_weight = 0.0
            # if class_samples > 0:
            #     class_weight = total_samples / class_samples
            # else:
            #     class_weight = 0.0
            if _c00844855650 > 0 :
                _45ce8a3a69ad = math._8c276d6c84bd(_dcb2f4e8ade9 / _c00844855650) + 1.0
            else:
                _45ce8a3a69ad = 0.0
            _309998dc47c9[_64ec0ec2c123]["lang_weight"] = _45ce8a3a69ad
        _58e1b33b7eb2 = [_08bb88f5c2da["lang_weight"] for _08bb88f5c2da in _309998dc47c9._e1c7be4d4ea1()]
        # Update stored lang weights (keeps original behavior)
        for _1bd2d9a57272, (_64ec0ec2c123, _e82db9c3349f) in _425b0aa64cd7(_309998dc47c9._96614439f4c0()):
            _e82db9c3349f["lang_weight"] = _58e1b33b7eb2[_1bd2d9a57272]
        return _58e1b33b7eb2, _309998dc47c9

    def _12137de93fa7(self, _e45d8af4ba31: _71d7a04b1277, _22481d3fe483: _6b2b534d6558) -> _6d0356d5585a[_8a544caf2f2a, _8a544caf2f2a]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _309998dc47c9 = {}
        _58e1b33b7eb2 = {}
        if os._f7b4415f42f6._56eeb1a70386(_e45d8af4ba31):
            with _7ff2f2e7c37a(_e45d8af4ba31, "r", _68680513ed8e="utf8") as _8ad9747bcd03:
                _5bb39c91e8ac = json._cfd9516cfe52(_8ad9747bcd03)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _309998dc47c9 = {
                    (_18514138edde(_86ef50eb3d82) if "." in _86ef50eb3d82 else _930d91ca9532(_86ef50eb3d82)): _950127b9930f
                    for _86ef50eb3d82, _950127b9930f in _5bb39c91e8ac._96614439f4c0()
                }

        if _22481d3fe483:
            _309998dc47c9 = self._13cdf3fb3db7(_a55045dbd6d8=_309998dc47c9)
            _58e1b33b7eb2, _309998dc47c9 = self._2a96dce47329(_309998dc47c9=_309998dc47c9)
            with _7ff2f2e7c37a(_e45d8af4ba31, "w", _68680513ed8e="utf8") as _b3b9aaa35cb5:
                json._fcbfc4a069dc(_309998dc47c9, _b3b9aaa35cb5, _34aeb6d8788e=2)

        return _309998dc47c9, _58e1b33b7eb2

    def _877b9def05d0(self) -> _829a9a45a59d[_930d91ca9532]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._e247ef0cac3b(_64ec0ec2c123) for _64ec0ec2c123 in self._a4c11b75a72e] if _34291e9d4248(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _35d710983403(self, _b4006271aecb: _18514138edde) -> _930d91ca9532:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _930d91ca9532(self._800acf5cccd5 * _b4006271aecb)

    @_efafc2efd732
    def _f0694a0bf3bd(_25b4846e079a: _71d7a04b1277) -> _6b2b534d6558:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _b96e971a6fd6
        for _6f804474eb5c in _25b4846e079a:
            if "ARABIC" not in _b96e971a6fd6._23d855e7c160(_6f804474eb5c, ""):
                return _0078635c21ad
        return _1a819bd4416f

    @_efafc2efd732
    def _b47d20972a4f(_6dbbe88e8ac5: _71d7a04b1277) -> _71d7a04b1277:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _a4cf51e3e98e._22026311681f(_6dbbe88e8ac5):
            _e5a6e3431f80 = _6dbbe88e8ac5._6dac1b94f2d0()._5260a7491935()
            _d7a7ff935fae = " "._8035eee40da5(_adf9515c7239(_e5a6e3431f80))
            return _d7a7ff935fae
        return _6dbbe88e8ac5

    def _089370ce7c90(self, _06060734575b: _71d7a04b1277, _6bde9922158e: _71d7a04b1277) -> _18514138edde:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _7e0101309245(_ad0402046ac8, _06060734575b, _6bde9922158e)._305aba8981bb()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_efafc2efd732
    def _ad298d3e5fd4(_d1c72a6ee282) -> _6d0356d5585a[_829a9a45a59d[_8a544caf2f2a], _930d91ca9532]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import time
        _b03d4d7f80e5 = time.time()
        _97b3d69c6de3, _e89a28472b1e, _fc27b327e199, _664053f5344f, _22481d3fe483, _7f13d2f92956 = _d1c72a6ee282
        _6bb13f3953b0 = _a4cf51e3e98e._6d72359a17cb
        _3b9c61348f36 = 0
        _c75e9d4aceac = _6bb13f3953b0._4d221d74ba4e
        _854a412608d7: _829a9a45a59d[_8a544caf2f2a] = []

        # Clean inputs and prepare per-word lists
        _e9b7bc694c40 = [_9c278e8b319c._6dac1b94f2d0() for _9c278e8b319c in _97b3d69c6de3]
        _9a0c3916cb50 = [_c5b0d6714c34._6dac1b94f2d0() for _c5b0d6714c34 in _e89a28472b1e]
        _05c9f502bdb8 = [_25b4846e079a._5260a7491935() if _25b4846e079a else ["<empty>"] for _25b4846e079a in _e9b7bc694c40]
        _f18034f2311a = []
        for _9ac2fd3d7493, _a6d47806eb06 in _46fc3d88d0e5(_05c9f502bdb8, _e89a28472b1e):
            _7fa10d6b6aff = _a6d47806eb06 if _57d5da28e849(_a6d47806eb06, _07bbf18385ec) else (_a6d47806eb06._6dac1b94f2d0()._5260a7491935() if _a6d47806eb06._6dac1b94f2d0() else ["<empty>"])
            if _5ee7ed6ec54e(_7fa10d6b6aff) == 1:
                _7fa10d6b6aff = [_7fa10d6b6aff[0]] * _5ee7ed6ec54e(_9ac2fd3d7493)
            elif _5ee7ed6ec54e(_7fa10d6b6aff) != _5ee7ed6ec54e(_9ac2fd3d7493):
                _7fa10d6b6aff = _7fa10d6b6aff[:_5ee7ed6ec54e(_9ac2fd3d7493)] if _5ee7ed6ec54e(_7fa10d6b6aff) > _5ee7ed6ec54e(_9ac2fd3d7493) else _7fa10d6b6aff + [_7fa10d6b6aff[-1]] * (_5ee7ed6ec54e(_9ac2fd3d7493) - _5ee7ed6ec54e(_7fa10d6b6aff))
            _f18034f2311a._e525c1927324(_7fa10d6b6aff)

        # Flatten all words for a single tokenizer call (faster)
        _4705e95db08d = _07bbf18385ec(_28a334689f55(*_05c9f502bdb8))
        _f0f488a4541b = time.time()
        try:
            _6d8ded63d0c4 = _6bb13f3953b0(_4705e95db08d, _926a6b12a170=_0078635c21ad, _2b1a05256fba=_0078635c21ad, _41fda9ef2e7d=_0078635c21ad)
        except _614308da514f as _8b8d34b45fe0:
            _e5d61d597e1a(f"Tokenization error: {_8b8d34b45fe0}")
            _6d8ded63d0c4 = {"input_ids": [[0] for _ in _4705e95db08d]}
        # build word token info per sentence
        _c09e33d23b67 = 0
        _40a4c12ff21e = []
        for _9ac2fd3d7493 in _05c9f502bdb8:
            _ff1c56e8c9b3 = _5ee7ed6ec54e(_9ac2fd3d7493)
            _d36d7e61064d = [(_1bd2d9a57272, _6d8ded63d0c4["input_ids"][_c09e33d23b67 + _1bd2d9a57272], _5ee7ed6ec54e(_6d8ded63d0c4["input_ids"][_c09e33d23b67 + _1bd2d9a57272])) for _1bd2d9a57272 in _5c567263a057(_ff1c56e8c9b3)]
            _40a4c12ff21e._e525c1927324(_d36d7e61064d)
            _c09e33d23b67 += _ff1c56e8c9b3

        # chunk each sentence into token windows
        for _109c3cf584da, (_9ac2fd3d7493, _c8e01f16d3d1, _7fa10d6b6aff) in _425b0aa64cd7(_46fc3d88d0e5(_05c9f502bdb8, _40a4c12ff21e, _f18034f2311a)):
            _56b725eb79fa = _7f13d2f92956 + _109c3cf584da
            _d03d026d893a = 0
            if _9ac2fd3d7493 == ["<empty>"]:
                _7a3920f28c38 = [0] * _fc27b327e199
                _854a412608d7._e525c1927324({
                    "sample_id": _56b725eb79fa,
                    "chunk_id": _d03d026d893a,
                    "input_ids": _7a3920f28c38,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _1bd2d9a57272 = 0
            _90512f800d76 = _5ee7ed6ec54e(_c8e01f16d3d1)
            _95b7014f6def = []
            while _1bd2d9a57272 < _90512f800d76:
                _b8551f635fc4 = 0
                _0f16d6110d62 = []
                _bdc248cebc9d = []
                _7c4070bdb99e = []
                _bc983c46fdef = _1bd2d9a57272
                while _bc983c46fdef < _90512f800d76:
                    _307b76033228, _dec065a69c80, _fb2f280cf6d8 = _c8e01f16d3d1[_bc983c46fdef]
                    _6f428e19f6c2 = _7fa10d6b6aff[_307b76033228] if _307b76033228 < _5ee7ed6ec54e(_7fa10d6b6aff) else _7fa10d6b6aff[-1] if _7fa10d6b6aff else "<unknown>"
                    if _fb2f280cf6d8 > _fc27b327e199 and not _0f16d6110d62:
                        _0f16d6110d62 += _dec065a69c80[:_fc27b327e199]
                        _bdc248cebc9d._e525c1927324(_6f428e19f6c2)
                        _7c4070bdb99e._e525c1927324(_307b76033228)
                        _bc983c46fdef += 1
                        break
                    if _b8551f635fc4 + _fb2f280cf6d8 > _fc27b327e199 and _0f16d6110d62:
                        break
                    _0f16d6110d62 += _dec065a69c80
                    _bdc248cebc9d._e525c1927324(_6f428e19f6c2)
                    _3b9c61348f36 += 1
                    _7c4070bdb99e._e525c1927324(_bc983c46fdef)
                    _b8551f635fc4 += _fb2f280cf6d8
                    _bc983c46fdef += 1

                if not _0f16d6110d62:
                    # fallback: take token prefix to avoid infinite loop
                    _0f16d6110d62 = _c8e01f16d3d1[_1bd2d9a57272][1][:_fc27b327e199] or [0]
                    _bdc248cebc9d = [_7fa10d6b6aff[_1bd2d9a57272] if _1bd2d9a57272 < _5ee7ed6ec54e(_7fa10d6b6aff) else _7fa10d6b6aff[-1] if _7fa10d6b6aff else "<unknown>"]
                    _7c4070bdb99e = [_1bd2d9a57272]
                    _3b9c61348f36 += 1
                    _1bd2d9a57272 += 1

                # pad tokens to fixed length
                if _5ee7ed6ec54e(_0f16d6110d62) < _fc27b327e199:
                    _0f16d6110d62 += [_c75e9d4aceac] * (_fc27b327e199 - _5ee7ed6ec54e(_0f16d6110d62))

                _95b7014f6def._e525c1927324({
                    "sample_id": _56b725eb79fa,
                    "chunk_id": _d03d026d893a,
                    "input_ids": _0f16d6110d62,
                    "labels": _bdc248cebc9d,
                    "word_positions": _7c4070bdb99e,
                    "num_chunks": 1
                })
                _d03d026d893a += 1

                if _bc983c46fdef >= _90512f800d76:
                    break

                # stride with overlap (in words)
                _3746ea10f0f3 = _5ee7ed6ec54e(_7c4070bdb99e)
                _e33b1e091839 = _930d91ca9532(_664053f5344f * _3746ea10f0f3)
                _e33b1e091839 = _2e075fcd10c6(_e33b1e091839, _3746ea10f0f3 - 1) if _3746ea10f0f3 > 1 else 0
                _9439e6070aaa = _bc983c46fdef - _e33b1e091839
                if _9439e6070aaa <= _1bd2d9a57272:
                    _9439e6070aaa = _1bd2d9a57272 + 1
                _1bd2d9a57272 = _9439e6070aaa

            _873ed553ad02 = _5ee7ed6ec54e(_95b7014f6def)
            for _f40cdbdfe199 in _95b7014f6def:
                _f40cdbdfe199["num_chunks"] = _873ed553ad02
            _854a412608d7._e9d9fdeee926(_95b7014f6def)

            if not _a4cf51e3e98e._1185003e127e and not _22481d3fe483 and _873ed553ad02 > 1:
                _e5d61d597e1a(f"[DEBUG] sample_id={_56b725eb79fa}", _2f859534bb36=_1a819bd4416f)
                _a4cf51e3e98e._1185003e127e = _1a819bd4416f

        # Timing/logging suppressed to preserve original behavior
        return _854a412608d7, _3b9c61348f36

    # @staticmethod
    # def process_batch_gen_llm_classifier(args) -> Tuple[List[dict], int]:
    #     """
    #     Construct chunks for generative LLM framing.
    #     The function follows the previously specified format:
    #       - Insert single space tokens between words in both streams.
    #       - word_positions contains per-label-token positions and -1 entries for spaces.
    #       - Overlap computed in WORDS, not tokens.
    #     """
    #     import time
    #     start_time = time.time()
    #     (prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_test, start_sample_id) = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100

    #     # Chat-ish prefixes used in dataset construction
    #     # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
    #     # "Identify the language of every word and reply with space-separated codes only.\n"
    #     # "Do not include any explanation or extra text.\n")
    #     # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     input_prefix = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
    #     "Identify the language of every word and reply with space-separated codes only.\n"
    #     "Do not include any explanation or extra text.\n")
    #     response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
    #     input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
    #     response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
    #     space_ids = tokenizer.encode(" ", add_special_tokens=False)
    #     prefix = instruction_ids + input_prefix_ids
    #     suffix = response_prefix_ids
    #     eos_len = 1
    #     fixed_len = len(prefix) + len(suffix) + eos_len

    #     results: List[dict] = []
    #     local_label_counter = 0

    #     # Preprocess lines into words lists and align labels to words
    #     src_texts = [s.strip() for s in src_lines]
    #     tgt_texts = [t.strip() for t in tgt_lines]
    #     src_words_list = []
    #     tgt_words_list = []
    #     for src, tgt in zip(src_texts, tgt_lines):
    #         src_words = src.split() if src else ["<empty>"]
    #         tgt_words = tgt if isinstance(tgt, list) else (tgt.strip().split() if tgt.strip() else ["<empty>"])
    #         if len(tgt_words) == 1:
    #             tgt_words = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) != len(src_words):
    #             tgt_words = tgt_words[:len(src_words)] if len(tgt_words) > len(src_words) else tgt_words + [tgt_words[-1]] * (len(src_words) - len(tgt_words))
    #         src_words_list.append(src_words)
    #         tgt_words_list.append(tgt_words)

    #     # Flatten words for efficient tokenization
    #     all_src_words = list(chain(*src_words_list))
    #     all_tgt_words = list(chain(*tgt_words_list))

    #     unique_tgt_words = {w for words in tgt_words_list for w in words}

    #     for word in unique_tgt_words:
    #         if word not in LanguageIdentificationDataset.tracking_classes:
    #             class_tokens = tokenizer.encode(word, add_special_tokens=False)
    #             if len(class_tokens) > 1:
    #                 LanguageIdentificationDataset.tracking_classes[word] = f"{len(LanguageIdentificationDataset.tracking_classes)+1}"
    #             else:
    #                 LanguageIdentificationDataset.tracking_classes[word] = word
    #     # print(f"check tracking classes {LanguageIdentificationDataset.tracking_classes}")
    #     # FOR NEW TOKEN UNCOMMENT THIS
    #     # Unique Token logic
    #     # new_tokens = []
    #     # tracking = []

    #     # for word in unique_tgt_words:
    #     #     if len(tokenizer.encode(word, add_special_tokens=False)) > 1:
    #     #         new_token = f"{word}"
    #     #         new_tokens.append(new_token)
    #     #         tracking.append((word, new_token))

    #     # if new_tokens:
    #     #     tokenizer.add_tokens(new_tokens, special_tokens=False)
    #     #     for word, token in tracking:
    #     #         token_id = tokenizer.convert_tokens_to_ids(token)
    #     #         print(f"Added word '{word}' with token {token} (id: {token_id})")
    #     # else:
    #     #     print("No multi-token words found")
        
    #     # tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     # tok_tgt = tokenizer(all_tgt_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_tgt = tokenizer([str(LanguageIdentificationDataset.tracking_classes.get(tgt)) for tgt in all_tgt_words], add_special_tokens=False, return_attention_mask=False)["input_ids"]

    #     # Build per-line token info
    #     src_idx = 0
    #     tgt_idx = 0
    #     src_word_token_info_list = []
    #     tgt_word_token_info_list = []
    #     for src_words, tgt_words in zip(src_words_list, tgt_words_list):
    #         src_len = len(src_words)
    #         tgt_len = len(tgt_words)
    #         if src_words == ["<empty>"] or tgt_words == ["<empty>"]:
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             continue
    #         try:
    #             src_info = [(w, tok_src[src_idx + i], len(tok_src[src_idx + i]) if isinstance(tok_src[src_idx + i], list) else 1) for i, w in enumerate(src_words)]
    #             tgt_info = [(w, tok_tgt[tgt_idx + i], len(tok_tgt[tgt_idx + i]) if isinstance(tok_tgt[tgt_idx + i], list) else 1) for i, w in enumerate(tgt_words)]
    #         except IndexError:
    #             # On tokenization mismatches, fallback safely
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             src_idx += src_len
    #             tgt_idx += tgt_len
    #             continue
    #         src_word_token_info_list.append(src_info)
    #         tgt_word_token_info_list.append(tgt_info)
    #         src_idx += src_len
    #         tgt_idx += tgt_len

    #     # Build chunks per sentence
    #     for line_idx, (src_words, src_word_token_info, tgt_word_token_info) in enumerate(zip(src_words_list, src_word_token_info_list, tgt_word_token_info_list)):
    #         sample_id = start_sample_id + line_idx
    #         chunk_id = 0
    #         src_word_labels = [info[0] for info in tgt_word_token_info]

    #         if src_words == ["<empty>"]:
    #             input_ids = prefix + [0] + suffix + [eos_id]
    #             labels = [ignore_index] * len(input_ids)
    #             pad_len = max_seq_len - len(input_ids)
    #             if pad_len > 0:
    #                 input_ids += [pad_id] * pad_len
    #                 labels += [ignore_index] * pad_len
    #             results.append({
    #                 "lang_codes": ["<empty>"],
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": [0],
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": len(prefix) + 1 + len(suffix),
    #                 "chunk_words": ["<empty>"],
    #                 "chunk_labels": ["<empty>"],
    #                 "num_chunks": 1
    #             })
    #             continue

    #         i = 0
    #         n = len(src_word_token_info)
    #         prev_j = -1
    #         chunk_results = []
    #         while i < n:
    #             total_len = fixed_len
    #             chunk_input_tokens = []
    #             chunk_label_tokens = []
    #             word_positions = []
    #             lang_codes = []
    #             chunk_words = []
    #             chunk_labels = []
    #             j = i
    #             while j < n:
    #                 _, src_ids, src_len = src_word_token_info[j]
    #                 tgt_word, tgt_ids, tgt_len = tgt_word_token_info[j]
    #                 inter_word_spaces = len(space_ids) if j < n - 1 else 0
    #                 # choose conservative word_total so both streams fit
    #                 word_total = max(src_len, tgt_len) + inter_word_spaces
    #                 if total_len + word_total > max_seq_len * 0.9:
    #                     break

    #                 # append inputs and spaces
    #                 chunk_input_tokens += src_ids if isinstance(src_ids, list) else [src_ids]
    #                 if inter_word_spaces:
    #                     chunk_input_tokens += space_ids

    #                 # append labels and word_positions
    #                 if tgt_len:
    #                     chunk_label_tokens += tgt_ids if isinstance(tgt_ids, list) else [tgt_ids]
    #                     word_positions += [j] * tgt_len
    #                 if inter_word_spaces:
    #                     chunk_label_tokens += space_ids
    #                     word_positions += [-1] * inter_word_spaces

    #                 lang_codes.append(tgt_word)
    #                 chunk_words.append(src_words[j])
    #                 chunk_labels.append(tgt_word)
    #                 local_label_counter += len(src_words[j])
    #                 total_len += word_total
    #                 j += 1

    #             if not chunk_input_tokens:
    #                 i += 1
    #                 continue

    #             flat_input_ids = chunk_input_tokens
    #             flat_label_ids = chunk_label_tokens
    #             prompt_len = len(prefix) + len(flat_input_ids) + len(suffix)

    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
    #             # RIGHT PAD + LEFT PAD TEST METHOD
    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
    #             # # pad to fixed size (inputs appended or prepended depending on test/train)
    #             # inputs_pad_len = max_seq_len - len(input_ids)
    #             # labels_pad_len = max_seq_len - len(labels)
    #             # if inputs_pad_len > 0:
    #             #     if is_test:
    #             #         input_ids = [pad_id] * inputs_pad_len + input_ids
    #             #     else:
    #             #         input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     if is_test:
    #             #         labels = [ignore_index] * labels_pad_len + labels
    #             #     else:
    #             #         labels += [ignore_index] * labels_pad_len
                
    #             # LEFT PAD METHOD
    #             if is_test is False:
    #                 input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             else:
    #                 input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             inputs_pad_len = max_seq_len - len(input_ids)
    #             labels_pad_len = max_seq_len - len(labels)
    #             if inputs_pad_len > 0:
    #                 input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # if is_test:
    #                 #     input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # else:
    #                 #     input_ids += [pad_id] * inputs_pad_len
    #             if labels_pad_len > 0:
    #                 labels = [ignore_index] * labels_pad_len + labels
    #                 # if is_test:
    #                 #     labels = [ignore_index] * labels_pad_len + labels
    #                 # else:
    #                 #     labels += [ignore_index] * labels_pad_len

    #             # if inputs_pad_len > 0:
    #             #     input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     labels += [ignore_index] * labels_pad_len

    #             if len(input_ids) != max_seq_len or len(labels) != max_seq_len:
    #                 raise RuntimeError(
    #                     f"[SEQ LEN VIOLATION] "
    #                     f"sample_id={sample_id} "
    #                     f"chunk_id={chunk_id} "
    #                     f"is_test={is_test} "
    #                     f"len(input_ids)={len(input_ids)} "
    #                     f"len(labels)={len(labels)} "
    #                     f"max_seq_len={max_seq_len} "
    #                     f"prompt_len={prompt_len} "
    #                     f"flat_input_len={len(flat_input_ids)} "
    #                     f"flat_label_len={len(flat_label_ids)}"
    #                 )


    #             chunk_results.append({
    #                 "lang_codes": lang_codes,
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": prompt_len,
    #                 "chunk_words": chunk_words,
    #                 "chunk_labels": chunk_labels,
    #                 "num_chunks": 1
    #             })
    #             chunk_id += 1

    #             if j >= n or j <= prev_j:
    #                 break
    #             prev_j = j
    #             overlap_words = max(1, int(overlap_ratio * len(chunk_words)))
    #             i = j - overlap_words if (j - overlap_words) > i else j

    #         num_chunks = len(chunk_results)
    #         for r in chunk_results:
    #             r["num_chunks"] = num_chunks
    #         results.extend(chunk_results)

    #         if not LanguageIdentificationDataset.is_debug_sample_shown and not is_test and num_chunks > 1:
    #             LanguageIdentificationDataset.is_debug_sample_shown = True

    #     return results, local_label_counter

    @_efafc2efd732
    def _f729790423db(_d1c72a6ee282) -> _6d0356d5585a[_829a9a45a59d[_8a544caf2f2a], _930d91ca9532]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import time
        _b03d4d7f80e5 = time.time()
        (_961eef13cbe9, _97b3d69c6de3, _e89a28472b1e, _fc27b327e199, _664053f5344f, _657ba10b6fb4, _7f13d2f92956) = _d1c72a6ee282
        _6bb13f3953b0 = _a4cf51e3e98e._6d72359a17cb
        _c75e9d4aceac = _6bb13f3953b0._4d221d74ba4e or _6bb13f3953b0._bf087f79385d
        _145dee75b824 = _6bb13f3953b0._bf087f79385d
        _b6dc2bddf6cf = -100

        # Chat-ish prefixes used in dataset construction
        _b490739f29cb = _6bb13f3953b0._bd290756152c._7fbe1d358fb6()
        if "llama" in _b490739f29cb:
            _2d032350b5c1 = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _c05e2b1dd6d5 = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        elif "qwen" in _b490739f29cb:
            _2d032350b5c1 = ("<|im_start|>system\nYou are Qwen, created by Alibaba Cloud."
            "You are a helpful assistant.<|im_end|>\n<|im_start|>user\n"
            "Instructions:\nIdentify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _c05e2b1dd6d5 = "<|im_end|>\n<|im_start|>assistant\n"
        elif "gemma" in _b490739f29cb:
            _2d032350b5c1 = ("<bos><start_of_turn>user\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _c05e2b1dd6d5 = "<end_of_turn>\n<start_of_turn>model\n"
        else:
            raise _3eec2230ddc5(f"Gen LLM module currently doesnt support {_b490739f29cb}")
        _ac37866ee4d2 = _6bb13f3953b0._4244b435cac9(_961eef13cbe9, _926a6b12a170=_0078635c21ad)
        _9bf0e8800a0e = _6bb13f3953b0._4244b435cac9(_2d032350b5c1, _926a6b12a170=_0078635c21ad)
        _fc1590a0a840 = _6bb13f3953b0._4244b435cac9(_c05e2b1dd6d5, _926a6b12a170=_0078635c21ad)
        # space_ids = tokenizer.encode(" ", add_special_tokens=False)
        _7edc25f58488 = _6bb13f3953b0._4244b435cac9("||", _926a6b12a170=_0078635c21ad)
        _7729f402bb4c = _ac37866ee4d2 + _9bf0e8800a0e
        _eb07b373d4e9 = _fc1590a0a840
        _b1123b5667a5 = 1
        _696d616e5bb2 = _5ee7ed6ec54e(_7729f402bb4c) + _5ee7ed6ec54e(_eb07b373d4e9) + _b1123b5667a5

        _854a412608d7: _829a9a45a59d[_8a544caf2f2a] = []
        _3b9c61348f36 = 0

        # Preprocess lines into words lists and align labels to words
        _e9b7bc694c40 = [_9c278e8b319c._6dac1b94f2d0() for _9c278e8b319c in _97b3d69c6de3]
        _9a0c3916cb50 = [_c5b0d6714c34._6dac1b94f2d0() for _c5b0d6714c34 in _e89a28472b1e]
        _05c9f502bdb8 = []
        _5d04a947dd87 = []
        for _2097bcc7106e, _a6d47806eb06 in _46fc3d88d0e5(_e9b7bc694c40, _e89a28472b1e):
            _9ac2fd3d7493 = _2097bcc7106e._5260a7491935() if _2097bcc7106e else ["<empty>"]
            _b9077d771664 = _a6d47806eb06 if _57d5da28e849(_a6d47806eb06, _07bbf18385ec) else (_a6d47806eb06._6dac1b94f2d0()._5260a7491935() if _a6d47806eb06._6dac1b94f2d0() else ["<empty>"])
            if _5ee7ed6ec54e(_b9077d771664) == 1:
                _b9077d771664 = [_b9077d771664[0]] * _5ee7ed6ec54e(_9ac2fd3d7493)
            elif _5ee7ed6ec54e(_b9077d771664) != _5ee7ed6ec54e(_9ac2fd3d7493):
                _b9077d771664 = _b9077d771664[:_5ee7ed6ec54e(_9ac2fd3d7493)] if _5ee7ed6ec54e(_b9077d771664) > _5ee7ed6ec54e(_9ac2fd3d7493) else _b9077d771664 + [_b9077d771664[-1]] * (_5ee7ed6ec54e(_9ac2fd3d7493) - _5ee7ed6ec54e(_b9077d771664))
            _05c9f502bdb8._e525c1927324(_9ac2fd3d7493)
            _5d04a947dd87._e525c1927324(_b9077d771664)

        # Flatten words for efficient tokenization
        _4705e95db08d = _07bbf18385ec(_28a334689f55(*_05c9f502bdb8))
        _33ac1e36534e = _07bbf18385ec(_28a334689f55(*_5d04a947dd87))

        _76e0d7280615 = {_798a6cee84e1 for _e5a6e3431f80 in _5d04a947dd87 for _798a6cee84e1 in _e5a6e3431f80}

        for _0528e140a116 in _76e0d7280615:
            if _0528e140a116 not in _a4cf51e3e98e._e4d0683fd624:
                _b43c537b0815 = _6bb13f3953b0._4244b435cac9(_0528e140a116, _926a6b12a170=_0078635c21ad)
                if _5ee7ed6ec54e(_b43c537b0815) > 1:
                    _a4cf51e3e98e._e4d0683fd624[_0528e140a116] = f"{_5ee7ed6ec54e(_a4cf51e3e98e._e4d0683fd624)+1}"
                else:
                    _a4cf51e3e98e._e4d0683fd624[_0528e140a116] = _0528e140a116
        
        _3ed2a22a0526 = _6bb13f3953b0(_4705e95db08d, _926a6b12a170=_0078635c21ad, _2b1a05256fba=_0078635c21ad)["input_ids"]
        _b19b1f45d0aa = _6bb13f3953b0([_71d7a04b1277(_a4cf51e3e98e._e4d0683fd624._4c7811cdac2d(_a6d47806eb06)) for _a6d47806eb06 in _33ac1e36534e], _926a6b12a170=_0078635c21ad, _2b1a05256fba=_0078635c21ad)["input_ids"]

        # Build per-line token info
        _c09e33d23b67 = 0
        _f3b88f7dd422 = 0
        _40a4c12ff21e = []
        _92761d2e557c = []
        for _9ac2fd3d7493, _b9077d771664 in _46fc3d88d0e5(_05c9f502bdb8, _5d04a947dd87):
            _ff1c56e8c9b3 = _5ee7ed6ec54e(_9ac2fd3d7493)
            _89bce3fed35d = _5ee7ed6ec54e(_b9077d771664)
            if _9ac2fd3d7493 == ["<empty>"] or _b9077d771664 == ["<empty>"]:
                _40a4c12ff21e._e525c1927324([(_9ac2fd3d7493[0], [0], 1)])
                _92761d2e557c._e525c1927324([(_b9077d771664[0], [0], 1)])
                continue
            try:
                _d36d7e61064d = [(_798a6cee84e1, _3ed2a22a0526[_c09e33d23b67 + _1bd2d9a57272], _5ee7ed6ec54e(_3ed2a22a0526[_c09e33d23b67 + _1bd2d9a57272]) if _57d5da28e849(_3ed2a22a0526[_c09e33d23b67 + _1bd2d9a57272], _07bbf18385ec) else 1) for _1bd2d9a57272, _798a6cee84e1 in _425b0aa64cd7(_9ac2fd3d7493)]
                _bd84711701ad = [(_798a6cee84e1, _b19b1f45d0aa[_f3b88f7dd422 + _1bd2d9a57272], _5ee7ed6ec54e(_b19b1f45d0aa[_f3b88f7dd422 + _1bd2d9a57272]) if _57d5da28e849(_b19b1f45d0aa[_f3b88f7dd422 + _1bd2d9a57272], _07bbf18385ec) else 1) for _1bd2d9a57272, _798a6cee84e1 in _425b0aa64cd7(_b9077d771664)]
            except _7509be0da8a6:
                # On tokenization mismatches, fallback safely
                _40a4c12ff21e._e525c1927324([(_9ac2fd3d7493[0], [0], 1)])
                _92761d2e557c._e525c1927324([(_b9077d771664[0], [0], 1)])
                _c09e33d23b67 += _ff1c56e8c9b3
                _f3b88f7dd422 += _89bce3fed35d
                continue
            _40a4c12ff21e._e525c1927324(_d36d7e61064d)
            _92761d2e557c._e525c1927324(_bd84711701ad)
            _c09e33d23b67 += _ff1c56e8c9b3
            _f3b88f7dd422 += _89bce3fed35d

        # Build chunks per sentence
        for _109c3cf584da, (_9ac2fd3d7493, _c8e01f16d3d1, _ce3965a8ab3e) in _425b0aa64cd7(_46fc3d88d0e5(_05c9f502bdb8, _40a4c12ff21e, _92761d2e557c)):
            _56b725eb79fa = _7f13d2f92956 + _109c3cf584da
            _d03d026d893a = 0
            _7f33aabe6c73 = [_fb3a277eb982[0] for _fb3a277eb982 in _ce3965a8ab3e]

            if _9ac2fd3d7493 == ["<empty>"]:
                _e5d61d597e1a(f"Skiiping line {_109c3cf584da} in file since its empty")

            _1bd2d9a57272 = 0
            _90512f800d76 = _5ee7ed6ec54e(_c8e01f16d3d1)
            _107d915984fd = -1
            _95b7014f6def = []
            while _1bd2d9a57272 < _90512f800d76:
                _b8551f635fc4 = _696d616e5bb2
                _3e298b933b02 = []
                _b5207baf68f4 = []
                _7c4070bdb99e = []
                _46887b386fe7 = []
                _b09e9e0f3f2c = []
                _bdc248cebc9d = []
                _bc983c46fdef = _1bd2d9a57272
                while _bc983c46fdef < _90512f800d76:
                    _, _d12437b322a6, _ff1c56e8c9b3 = _c8e01f16d3d1[_bc983c46fdef]
                    _0d12081af6b0, _a9d925262bba, _89bce3fed35d = _ce3965a8ab3e[_bc983c46fdef]
                    _f4cdb2844fd5 = _5ee7ed6ec54e(_7edc25f58488) if _bc983c46fdef < _90512f800d76 - 1 else 0
                    # choose conservative word_total so both streams fit
                    # word_total = max(src_len, tgt_len) + inter_word_spaces
                    # if total_len + word_total > max_seq_len * 0.9:
                    #     break

                    # account for BOTH streams + spaces
                    # word_input = src_len + inter_word_spaces
                    # word_label = tgt_len + inter_word_spaces
                    # word_total = word_input + word_label

                    _4ddb26255152 = _ff1c56e8c9b3 + _f4cdb2844fd5
                    _e824b3ba2112 = _4ddb26255152 if _657ba10b6fb4 else (_4ddb26255152 + _89bce3fed35d + _f4cdb2844fd5)


                    if _b8551f635fc4 + _e824b3ba2112 > _fc27b327e199:
                        break


                    # append inputs and spaces
                    _3e298b933b02 += _d12437b322a6 if _57d5da28e849(_d12437b322a6, _07bbf18385ec) else [_d12437b322a6]
                    if _f4cdb2844fd5:
                        _3e298b933b02 += _7edc25f58488

                    # append labels and word_positions
                    if _89bce3fed35d:
                        _b5207baf68f4 += _a9d925262bba if _57d5da28e849(_a9d925262bba, _07bbf18385ec) else [_a9d925262bba]
                        _7c4070bdb99e += [_bc983c46fdef] * _89bce3fed35d
                    if _f4cdb2844fd5:
                        _b5207baf68f4 += _7edc25f58488
                        _7c4070bdb99e += [-1] * _f4cdb2844fd5

                    _46887b386fe7._e525c1927324(_0d12081af6b0)
                    _b09e9e0f3f2c._e525c1927324(_9ac2fd3d7493[_bc983c46fdef])
                    _bdc248cebc9d._e525c1927324(_0d12081af6b0)
                    _3b9c61348f36 += _5ee7ed6ec54e(_9ac2fd3d7493[_bc983c46fdef])
                    _b8551f635fc4 += _e824b3ba2112
                    _bc983c46fdef += 1

                if not _3e298b933b02:
                    _1bd2d9a57272 += 1
                    continue

                _9bc98d90edaf = _3e298b933b02
                _089bd0c987b6 = _b5207baf68f4
                _e99b47af93cb = _5ee7ed6ec54e(_7729f402bb4c) + _5ee7ed6ec54e(_9bc98d90edaf) + _5ee7ed6ec54e(_eb07b373d4e9)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
                # RIGHT PAD + LEFT PAD TEST METHOD
                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

                # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
                # # pad to fixed size (inputs appended or prepended depending on test/train)
                # inputs_pad_len = max_seq_len - len(input_ids)
                # labels_pad_len = max_seq_len - len(labels)
                # if inputs_pad_len > 0:
                #     if is_test:
                #         input_ids = [pad_id] * inputs_pad_len + input_ids
                #     else:
                #         input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     if is_test:
                #         labels = [ignore_index] * labels_pad_len + labels
                #     else:
                #         labels += [ignore_index] * labels_pad_len
                
                # LEFT PAD METHOD
                if _657ba10b6fb4 is _0078635c21ad:
                    _7a3920f28c38 = _7729f402bb4c + _9bc98d90edaf + _eb07b373d4e9 + _089bd0c987b6 + [_145dee75b824]
                    _e293dd726ec6 = [_b6dc2bddf6cf] * _e99b47af93cb + _089bd0c987b6 + [_b6dc2bddf6cf]
                else:
                    # input_ids = prefix + flat_input_ids + suffix + [eos_id]
                    # labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                    # REMOVE EOS
                    # input_ids = prefix + flat_input_ids + suffix
                    # labels = [ignore_index] * prompt_len + flat_label_ids
                    _aca7bf9140f9 = _7729f402bb4c + _9bc98d90edaf + _eb07b373d4e9

                    _8c67ace159dd = _fc27b327e199 - _5ee7ed6ec54e(_aca7bf9140f9)
                    _7a3920f28c38 = [_c75e9d4aceac] * _8c67ace159dd + _aca7bf9140f9

                    _e293dd726ec6 = [_b6dc2bddf6cf] * _fc27b327e199 + _089bd0c987b6
                    # label_start = inputs_pad_len + prompt_len
                    # labels[label_start : label_start + len(flat_label_ids)] = flat_label_ids

                if not _657ba10b6fb4:
                    _8c67ace159dd = _fc27b327e199 - _5ee7ed6ec54e(_7a3920f28c38)
                    _1278dedfa357 = _fc27b327e199 - _5ee7ed6ec54e(_e293dd726ec6)
                    if _8c67ace159dd > 0:
                        _7a3920f28c38 = [_c75e9d4aceac] * _8c67ace159dd + _7a3920f28c38
                        # if is_test:
                        #     input_ids = [pad_id] * inputs_pad_len + input_ids
                        # else:
                        #     input_ids += [pad_id] * inputs_pad_len
                    if _1278dedfa357 > 0:
                        _e293dd726ec6 = [_b6dc2bddf6cf] * _1278dedfa357 + _e293dd726ec6
                        # if is_test:
                        #     labels = [ignore_index] * labels_pad_len + labels
                        # else:
                        #     labels += [ignore_index] * labels_pad_len

                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len

                # not respecting rule in test since test will be free flowing
                if _657ba10b6fb4 is _0078635c21ad and (_5ee7ed6ec54e(_7a3920f28c38) != _fc27b327e199 or _5ee7ed6ec54e(_e293dd726ec6) != _fc27b327e199):
                    raise _32fd06e16871(
                        f"[SEQ LEN VIOLATION] "
                        f"sample_id={_56b725eb79fa} "
                        f"chunk_id={_d03d026d893a} "
                        f"is_test={_657ba10b6fb4} "
                        f"len(input_ids)={_5ee7ed6ec54e(_7a3920f28c38)} "
                        f"len(labels)={_5ee7ed6ec54e(_e293dd726ec6)} "
                        f"max_seq_len={_fc27b327e199} "
                        f"prompt_len={_e99b47af93cb} "
                        f"flat_input_len={_5ee7ed6ec54e(_9bc98d90edaf)} "
                        f"flat_label_len={_5ee7ed6ec54e(_089bd0c987b6)}"
                    )


                _95b7014f6def._e525c1927324({
                    "lang_codes": _46887b386fe7,
                    "sample_id": _56b725eb79fa,
                    "chunk_id": _d03d026d893a,
                    "word_positions": _7c4070bdb99e,
                    "input_ids": _7a3920f28c38,
                    "labels": _e293dd726ec6,
                    "prompt_len": _e99b47af93cb,
                    "chunk_words": _b09e9e0f3f2c,
                    "chunk_labels": _bdc248cebc9d,
                    "num_chunks": 1
                })
                _d03d026d893a += 1

                if _bc983c46fdef >= _90512f800d76 or _bc983c46fdef <= _107d915984fd:
                    break
                _107d915984fd = _bc983c46fdef
                _f8844686d889 = _fd271ae0d1a5(1, _930d91ca9532(_664053f5344f * _5ee7ed6ec54e(_b09e9e0f3f2c)))
                _1bd2d9a57272 = _bc983c46fdef - _f8844686d889 if (_bc983c46fdef - _f8844686d889) > _1bd2d9a57272 else _bc983c46fdef

            _873ed553ad02 = _5ee7ed6ec54e(_95b7014f6def)
            for _f40cdbdfe199 in _95b7014f6def:
                _f40cdbdfe199["num_chunks"] = _873ed553ad02
            _854a412608d7._e9d9fdeee926(_95b7014f6def)

            if not _a4cf51e3e98e._1185003e127e and not _657ba10b6fb4 and _873ed553ad02 > 1:
                _a4cf51e3e98e._1185003e127e = _1a819bd4416f

        return _854a412608d7, _3b9c61348f36

    # -------------------------
    # File processing & validation
    # -------------------------
    def _1d0dcffd72d6(self, _1abbc3cf635c: _71d7a04b1277, _9836b3f426e6: _71d7a04b1277, _7f13d2f92956: _930d91ca9532) -> _6d0356d5585a[_71d7a04b1277, _829a9a45a59d[_8a544caf2f2a], _930d91ca9532]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _ba5c49d90060 = []

        with _7ff2f2e7c37a(_1abbc3cf635c, "r", _68680513ed8e="utf8") as _d43b223ca184, _7ff2f2e7c37a(_9836b3f426e6, "r", _68680513ed8e="utf8") as _d415d4cfa9b6:
            _97b3d69c6de3 = _d43b223ca184._d3860d627b55()[1:] if self._6fddf642c265 else _d43b223ca184._d3860d627b55()
            _e89a28472b1e = _d415d4cfa9b6._d3860d627b55()[1:] if self._6fddf642c265 else _d415d4cfa9b6._d3860d627b55()

        # sample some share if requested
        _8403ef607e97 = _930d91ca9532(_5ee7ed6ec54e(_97b3d69c6de3) * self._a8cef213b88f)
        if _8403ef607e97 < _5ee7ed6ec54e(_97b3d69c6de3):
            _24529d0a9265 = _6bb0ce512018.random._18a36bfe00f9(_5ee7ed6ec54e(_97b3d69c6de3), _8403ef607e97, _ffed0cc01f67=_0078635c21ad)
            _97b3d69c6de3 = [_97b3d69c6de3[_1bd2d9a57272] for _1bd2d9a57272 in _24529d0a9265]
            _e89a28472b1e = [_e89a28472b1e[_1bd2d9a57272] for _1bd2d9a57272 in _24529d0a9265]

        _64ec0ec2c123 = _07bbf18385ec({_c5b0d6714c34._6dac1b94f2d0() for _c5b0d6714c34 in _e89a28472b1e})[0] if _e89a28472b1e else "unk"
        self._8c276d6c84bd._fb3a277eb982(f"Sampled {self._a8cef213b88f * 100:.1f}% of {_1abbc3cf635c}: {_5ee7ed6ec54e(_97b3d69c6de3)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _bc092fee5266(_f61fb1130763, _86f45a6f67ea):
            _0a6be8a7d8bd = _b3a141136251(_f61fb1130763)
            while _1a819bd4416f:
                _0d38fd963fc8 = _07bbf18385ec(_a89f01fafcb3(_0a6be8a7d8bd, _86f45a6f67ea))
                if not _0d38fd963fc8:
                    break
                yield _0d38fd963fc8

        _86f45a6f67ea = 10_000
        if self._0e7d92be427e:
            _ddcfe56fcaa4 = [
                (self._961eef13cbe9, _ff28423aa5ac, _c951d28bc4c2, self._800acf5cccd5, 0.25, self._657ba10b6fb4, _7f13d2f92956 + _eb8c02213d7b * _86f45a6f67ea)
                for _eb8c02213d7b, (_ff28423aa5ac, _c951d28bc4c2) in _425b0aa64cd7(_46fc3d88d0e5(_0995b494e30c(_97b3d69c6de3, _86f45a6f67ea), _0995b494e30c(_e89a28472b1e, _86f45a6f67ea)))
            ]
            with _d66e6ac587de(self._dce319e8fa26) as _9ff7cd53468b:
                _7254372ddff5 = _9ff7cd53468b._d8f128d5ea34(_a4cf51e3e98e._e5d9c3b21fea, _ddcfe56fcaa4)
        else:
            _ddcfe56fcaa4 = [
                (_ff28423aa5ac, _c951d28bc4c2, self._800acf5cccd5, 0.5, self._22481d3fe483, _7f13d2f92956 + _eb8c02213d7b * _86f45a6f67ea)
                for _eb8c02213d7b, (_ff28423aa5ac, _c951d28bc4c2) in _425b0aa64cd7(_46fc3d88d0e5(_0995b494e30c(_97b3d69c6de3, _86f45a6f67ea), _0995b494e30c(_e89a28472b1e, _86f45a6f67ea)))
            ]
            with _d66e6ac587de(self._dce319e8fa26) as _9ff7cd53468b:
                _7254372ddff5 = _9ff7cd53468b._d8f128d5ea34(_a4cf51e3e98e._85dadb0b7e0f, _ddcfe56fcaa4)

        _b4d747e81260 = []
        for _854a412608d7, _57b1155b9617 in _7254372ddff5:
            _b4d747e81260._e9d9fdeee926(_854a412608d7)
            self._5cdc410765dd += _57b1155b9617

        if _b4d747e81260:
            _ba5c49d90060 = _b4d747e81260

        return _64ec0ec2c123, _ba5c49d90060, _5ee7ed6ec54e(_97b3d69c6de3)

    def _d5b13b628d77(self) -> _ad0402046ac8:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _abb756b13add = 0

        for _7f3ade5f1b16 in os._ac0dd99ec659(self._207c136a10cd):
            self._8c276d6c84bd._fb3a277eb982(f"Now processing {os._f7b4415f42f6._8035eee40da5(self._207c136a10cd, _7f3ade5f1b16)} directory.")
            _fa5ffbb92f2c = os._f7b4415f42f6._8035eee40da5(self._207c136a10cd, _7f3ade5f1b16, "src")
            _6bd4321b9679 = os._f7b4415f42f6._8035eee40da5(self._207c136a10cd, _7f3ade5f1b16, "tgt")

            _e676114b537d = []
            _0084fdf637c4 = []
            for _1abbc3cf635c in os._ac0dd99ec659(_fa5ffbb92f2c):
                _6e2de07e9578 = _0078635c21ad
                for _9836b3f426e6 in os._ac0dd99ec659(_6bd4321b9679):
                    if _1abbc3cf635c._5260a7491935(".")[0] == _9836b3f426e6._5260a7491935(".")[0]:
                        _e676114b537d._e525c1927324(_1abbc3cf635c)
                        _0084fdf637c4._e525c1927324(_9836b3f426e6)
                        _6e2de07e9578 = _1a819bd4416f
                        break
                if not _6e2de07e9578:
                    self._8c276d6c84bd._fb3a277eb982(f"Skipping file {_1abbc3cf635c} since matching label file not found in {_6bd4321b9679}.")

            _75c164f27d97 = [os._f7b4415f42f6._8035eee40da5(_fa5ffbb92f2c, _b7a8f9423b0b) for _b7a8f9423b0b in _e676114b537d if os._f7b4415f42f6._5ce1a7eead4c(os._f7b4415f42f6._8035eee40da5(_fa5ffbb92f2c, _b7a8f9423b0b))]
            _3970243877b5 = [os._f7b4415f42f6._8035eee40da5(_6bd4321b9679, _b7a8f9423b0b) for _b7a8f9423b0b in _0084fdf637c4 if os._f7b4415f42f6._5ce1a7eead4c(os._f7b4415f42f6._8035eee40da5(_6bd4321b9679, _b7a8f9423b0b))]

            if _5ee7ed6ec54e(_75c164f27d97) != _5ee7ed6ec54e(_3970243877b5):
                raise _3eec2230ddc5(f"Number of files in {_fa5ffbb92f2c} ({_5ee7ed6ec54e(_75c164f27d97)}) does not match {_6bd4321b9679} ({_5ee7ed6ec54e(_3970243877b5)})")

            for _1abbc3cf635c, _9836b3f426e6 in _46fc3d88d0e5(_75c164f27d97, _3970243877b5):
                _bdc241102e46 = _2bebe2558207(1 for _ in _7ff2f2e7c37a(_1abbc3cf635c))
                _e9045d8b51a9 = _2bebe2558207(1 for _ in _7ff2f2e7c37a(_9836b3f426e6))
                _bdc241102e46 = _bdc241102e46 - 1 if self._6fddf642c265 else _bdc241102e46
                _e9045d8b51a9 = _e9045d8b51a9 - 1 if self._6fddf642c265 else _e9045d8b51a9

                if _bdc241102e46 != _e9045d8b51a9:
                    self._8c276d6c84bd._fb3a277eb982(f"{_bdc241102e46} lines in {_1abbc3cf635c} do not match with {_e9045d8b51a9} in {_9836b3f426e6}, skipping these files")
                    continue

                self._8c276d6c84bd._fb3a277eb982(f"Processing {_1abbc3cf635c} and {_9836b3f426e6} with {_e9045d8b51a9} samples.")
                _64ec0ec2c123, _cd3cae497152, _09bda4128a6c = self._5b1beeb7eca6(_1abbc3cf635c, _9836b3f426e6, _7f13d2f92956=_abb756b13add)
                _abb756b13add += _09bda4128a6c

                self._cd3cae497152._e9d9fdeee926(_cd3cae497152)
                if self._22481d3fe483:
                    if _64ec0ec2c123 not in self._7a86d34f3df9:
                        self._7a86d34f3df9._5f4459bacd1a({
                            _64ec0ec2c123: [{
                                "file_name": os._f7b4415f42f6._a0081e977444(_9836b3f426e6),
                                "samples_before_processing": _e9045d8b51a9,
                                "samples_after_processing": _5ee7ed6ec54e(_cd3cae497152)
                            }]
                        })
                    else:
                        self._7a86d34f3df9[_64ec0ec2c123]._e525c1927324({
                            "file_name": os._f7b4415f42f6._a0081e977444(_9836b3f426e6),
                            "samples_before_processing": _e9045d8b51a9,
                            "samples_after_processing": _5ee7ed6ec54e(_cd3cae497152)
                        })
                if _64ec0ec2c123 not in self._46887b386fe7:
                    self._46887b386fe7._e525c1927324(_64ec0ec2c123)
                self._8c276d6c84bd._fb3a277eb982(f"Files {_1abbc3cf635c} and {_9836b3f426e6} have {_5ee7ed6ec54e(_cd3cae497152)} samples after processing.")

        # verify dataset integrity
        self._ccac1a240cec()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _4b05ed774d9b(self) -> _ad0402046ac8:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _8d322315f3a5 = self._cd3cae497152
        if not _8d322315f3a5:
            self._8c276d6c84bd._fb3a277eb982("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _299872b2423e = [_ab25ffe78a37["sample_id"] for _ab25ffe78a37 in _8d322315f3a5]
        _6fac4a04ce5f = _33993f842d1e(_299872b2423e)
        _49c5b2db6ee5 = _fd271ae0d1a5(_6fac4a04ce5f)
        _c8722a101c44 = (_5ee7ed6ec54e(_6fac4a04ce5f) == _49c5b2db6ee5 + 1)
        self._8c276d6c84bd._fb3a277eb982(f"[sample_id] unique={_5ee7ed6ec54e(_6fac4a04ce5f)} max={_49c5b2db6ee5} coverage_ok={_c8722a101c44} (expect True)")
        if not _c8722a101c44:
            _cc3d71a5df0f = _1d520662f15f(_33993f842d1e(_5c567263a057(_49c5b2db6ee5 + 1)) - _6fac4a04ce5f)
            self._8c276d6c84bd._fb3a277eb982(f" Missing sample_ids: {_cc3d71a5df0f[:20]}{' ...' if _5ee7ed6ec54e(_cc3d71a5df0f) > 20 else ''}")
            raise _3eec2230ddc5(f"Increase max_seq_len as missing sample_ids detected: {_cc3d71a5df0f[:20]}{' ...' if _5ee7ed6ec54e(_cc3d71a5df0f) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _d9c7445cf465 = [(_ab25ffe78a37["sample_id"], _ab25ffe78a37["chunk_id"]) for _ab25ffe78a37 in _8d322315f3a5]
        _0dc28bbc4774 = [_86ef50eb3d82 for _86ef50eb3d82, _950127b9930f in _80f0a681e890(_d9c7445cf465)._96614439f4c0() if _950127b9930f > 1]
        self._8c276d6c84bd._fb3a277eb982(f"[(sample_id,chunk_id)] duplicates: {_5ee7ed6ec54e(_0dc28bbc4774)} (expect 0)")
        if _0dc28bbc4774:
            self._8c276d6c84bd._fb3a277eb982(f" Examples: {_0dc28bbc4774[:10]}")
            raise _3eec2230ddc5(f"Duplicate (sample_id, chunk_id) pairs detected: {_0dc28bbc4774[:10]}")

        # 3) per-sample chunk_id sequentiality
        _d1a1c99ec101 = _f05bde3ccdf2(_07bbf18385ec)
        for _ab25ffe78a37 in _8d322315f3a5:
            _d1a1c99ec101[_ab25ffe78a37["sample_id"]]._e525c1927324(_ab25ffe78a37["chunk_id"])
        _df276d7de407 = {}
        for _e398929897c3, _dec065a69c80 in _d1a1c99ec101._96614439f4c0():
            _f7c59825a5cb = _1d520662f15f(_dec065a69c80)
            _af40edbfddce = _07bbf18385ec(_5c567263a057(_5ee7ed6ec54e(_f7c59825a5cb)))
            if _f7c59825a5cb != _af40edbfddce:
                _df276d7de407[_e398929897c3] = {"have": _f7c59825a5cb[:20], "expected_prefix": _af40edbfddce[:20]}
        self._8c276d6c84bd._fb3a277eb982(f"[per-sample chunk_id sequence] bad_samples: {_5ee7ed6ec54e(_df276d7de407)} (expect 0)")
        if _df276d7de407:
            _0bb11e6111c0 = _07bbf18385ec(_df276d7de407._96614439f4c0())[:5]
            for _e398929897c3, _fb3a277eb982 in _0bb11e6111c0:
                self._8c276d6c84bd._fb3a277eb982(f" sample_id={_e398929897c3} have={_fb3a277eb982['have']} expected_prefix={_fb3a277eb982['expected_prefix']}")
            raise _3eec2230ddc5(f"Non-sequential chunk_id sequences detected for sample_ids: {_07bbf18385ec(_df276d7de407._bdbae2730c98())[:5]}")

        # 4) overall stats reporting
        _eefc468ec9f4 = _5ee7ed6ec54e(_6fac4a04ce5f)
        _7d2e2aa43bef = _5ee7ed6ec54e(_8d322315f3a5)
        _17d53628aa52 = _7d2e2aa43bef / _eefc468ec9f4 if _eefc468ec9f4 > 0 else 0
        self._8c276d6c84bd._fb3a277eb982(f"[audit] base={_eefc468ec9f4} -> chunks={_7d2e2aa43bef} (avg {_17d53628aa52:.2f} per sample)")

    @_8d1007eda647
    def _561edee50db1(self) -> _930d91ca9532:
        """Return number of unique base samples (unique sample_id)."""
        if not _f273b9bd95b6(self, "file_data_dict_list", _ad0402046ac8):
            return 0
        return _5ee7ed6ec54e({_930d91ca9532(_08bb88f5c2da["sample_id"]) for _08bb88f5c2da in self._cd3cae497152})

    @_8d1007eda647
    def _cd21a0508ce4(self) -> _930d91ca9532:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _f273b9bd95b6(self, "file_data_dict_list", _ad0402046ac8):
            return 0

        _1c19c151a276 = _f05bde3ccdf2(_33993f842d1e)
        for _08bb88f5c2da in self._cd3cae497152:
            _e398929897c3 = _930d91ca9532(_08bb88f5c2da._4c7811cdac2d("sample_id", -1))
            for _fddda92d7339 in _08bb88f5c2da._4c7811cdac2d("word_positions", []):
                try:
                    _a8bb1c02a8f5 = _930d91ca9532(_fddda92d7339)
                except _614308da514f:
                    continue
                if _a8bb1c02a8f5 >= 0:
                    _1c19c151a276[_e398929897c3]._73b35bd92164(_a8bb1c02a8f5)

        return _2bebe2558207(_5ee7ed6ec54e(_0a3a99ac2eda) for _0a3a99ac2eda in _1c19c151a276._e1c7be4d4ea1())
