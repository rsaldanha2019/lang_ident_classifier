# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : language_identification_dataset.py
# @Time             : 2025-10-23 14:11 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _e4a1c132696e
import _9f834920047e
import _a7f775c14fb9
import _62be2c3a2de3
import _cce19f14042c
from _db348e22f9a7 import _562ce915fe41, _d934a322a951
from _72d742b48b2d import _bcaa7995a731, _b7f618578693
from _b102fe331a64 import _533e5748410c
from _120e58425fe1._d45fda4f6eda import _cd8b8c23988b
from _c3109800c917 import _69cadc852c98, _963d169bbd37, _807d03b0641f

import _2a5c9cdc8f53 as _231ff69d0ba6
import _676dba817bf2
from _676dba817bf2._b56e7871179a._567d2c50b45c import _6251028fb796
from _f6e4d8cffe38 import _4cbe6c2b72ba


class _dfeaf4f3b7e8(_6251028fb796):
    """
    Dataset handler for language-identification tasks.

    This class supports two modes:
      - Classification per-token (`is_gen_llm == False`)
      - Generative LLM framing (`is_gen_llm == True`)

    Files are read per-language directory structure under `data/<train/val/test>/<language>/{src,tgt}`.
    Data is chunked into token-length windows, padded to `max_seq_length`, and
    returned as dicts suitable for collate functions.

    Important attributes set during construction:
      - self.file_data_dict_list : list[dict]  -- processed chunked examples
      - self.file_stats : metadata per language file (used for class weighting)
      - LanguageIdentificationDataset.TOKENIZER : class-level tokenizer reference
    """

    _bdf48e99c683 = _b87227a133c3  # class-level tokenizer (set on __init__)
    _ffec05c7fed1 = _ad7e3de25951
    _5d3a28a700e7 = {}
    def _c99a8f301d95(
        self,
        _0c1d5e27091a: _9c0cd04f03f2,
        _3e77d66fdded: _ef26bbaa8984,
        _6eddb347dd21: _69cadc852c98,
        _a98491020d3c: _885c44f476fc,
        _cd753802e17f: _9c0cd04f03f2,
        _d3b82e12b672: _4cbe6c2b72ba,
        _e08a04b651de: _ef26bbaa8984,
        _88fc0dafa83d: _ef26bbaa8984,
        _14fbaef7e5b6: _2b8a64a7db5a = 1.0,
        _093d33839a22: _885c44f476fc = 2,
        _742eb5e3a28d: _885c44f476fc = 20,
        _f966cf7c8516: _ef26bbaa8984 = _ad7e3de25951,
        _5cf25e51dedf: _9c0cd04f03f2 = _b87227a133c3,
        _5f27b55fbb49: _9c0cd04f03f2 = _b87227a133c3,
        _506be871257c: _9c0cd04f03f2 = _b87227a133c3,
    ):
        """
        Initialize dataset.

        :param data_dir: Root directory containing per-language subdirectories
                         with `src` and `tgt` files.
        :param files_have_header: If True, skip first line in files.
        :param pretrained_embedding_tokenizer: tokenizer instance (HuggingFace-style).
        :param max_seq_length: maximum token length per chunk.
        :param classes_config_path: path to JSON file with classes mapping.
        :param log: logger instance for informational messages.
        :param is_train: True when preparing training splits (affects class updates).
        :param is_test: True when running test/inference mode.
        :param sample_dataset_share: fraction of each file to sample (0..1).
        :param num_workers: number of worker threads for parallel processing.
        :param random_seed: RNG seed for deterministic sampling.
        :param is_gen_llm: if True, produce generative-LLM style chunks.
        :param prompt_template: used by generative LLM preparation.
        """
        _12e38442da34()._af83a1ffcbe0()

        # Deterministic behavior
        _676dba817bf2._1b8842ba00c3(_742eb5e3a28d)
        if _676dba817bf2._a29d1eda36a2._e95e20e6f8ea():
            _676dba817bf2._a29d1eda36a2._ad29c24523a3(_742eb5e3a28d)
        _62be2c3a2de3._0e355c254ee1(_742eb5e3a28d)
        _231ff69d0ba6._62be2c3a2de3._0e355c254ee1(_742eb5e3a28d)

        # Basic parameters & bookkeeping
        self._d3b82e12b672 = _d3b82e12b672
        self._e08a04b651de = _e08a04b651de
        self._88fc0dafa83d = _88fc0dafa83d
        self._f966cf7c8516 = _f966cf7c8516
        self._5cf25e51dedf = _5cf25e51dedf
        self._5f27b55fbb49 = _5f27b55fbb49
        self._506be871257c = _506be871257c
        self._3e77d66fdded = _3e77d66fdded
        self._0c1d5e27091a = _0c1d5e27091a
        self._a98491020d3c = _a98491020d3c
        self._7533fd874ed4 = 0
        self._14fbaef7e5b6 = _14fbaef7e5b6
        self._093d33839a22 = _093d33839a22
        self._75cb41b20c76 = -100

        # Tokenizer handling
        if _f966cf7c8516:
            _6eddb347dd21._a9f3643b8771 = "left"
        _b0c416bda489._bdf48e99c683 = _6eddb347dd21
        self._1b268f3d841e = _6eddb347dd21
        if self._f966cf7c8516:
            # preserve earlier code's fallback pad id (kept intentionally)
            # if not self.tokenizer.pad_token_id:
            #     self.tokenizer.pad_token_id = 128004
    
            # if not self.tokenizer.pad_token_id and "<PAD>" not in self.tokenizer.get_vocab():
            #     self.tokenizer.add_tokens(["<PAD>"], special_tokens=False)
            #     tid = self.tokenizer.convert_tokens_to_ids("<PAD>")
            #     print(f"Added padding token  <PAD> with (id: {tid})")
            
            if not _6eddb347dd21._b0af4822375b:
                _6eddb347dd21._00c4a8e1abb9(["_P"], _9eb469e11c23=_ad7e3de25951)
                _0ef6289e7736 = _6eddb347dd21._db55da69be4b("_P")
                _6eddb347dd21._b0af4822375b = _0ef6289e7736
                _440fdb3c09bb(f"Added padding token  _P with (id: {_0ef6289e7736})")

        # lang_codes
        self._738b589978eb = []
        
        # storage filled by _validate_and_load_file_data
        self._5ff190a2f681: _963d169bbd37[_1cb00d143b15] = []
        self._4fb82953c16b = {}

        # Load and process files; then derive classes/weights
        self._7f11a1a4321a()
        self._75feee318ab5, self._cbc7a61c2fad = self._adb5ddf2de0e(_cd753802e17f, _e08a04b651de)
        

    def _35e4ab161878(self) -> _885c44f476fc:
        """Number of chunked samples in the dataset (after preprocessing)."""
        return _67663aab9f54(self._5ff190a2f681)

    def _2df7fb25b8a4(self, _139320f939ab: _885c44f476fc) -> _1cb00d143b15:
        """
        Return the idx-th chunk as a dict suitable for collate functions:
        {
          "lang_code": str,
          "input_ids": torch.LongTensor,
          "labels": torch.LongTensor,
          "sample_id": int,
          "chunk_id": int,
          "word_positions": list[int],
          "prompt_len": int,
          "num_chunks": int
        }
        """
        _e4b905681570 = self._5ff190a2f681[_139320f939ab]
        _f2360d185638 = _e4b905681570._df40f92b36f9("lang_code", "unk")
        _0dff3b1d2329 = _e4b905681570["input_ids"]
        _925a8228f639 = _e4b905681570["labels"]
        _412d9f5bb625 = _e4b905681570._df40f92b36f9("word_positions", [])
        _51956ce4faaa = _e4b905681570["num_chunks"]
        _c48e26210f50 = _e4b905681570._df40f92b36f9("sample_id", _139320f939ab)
        _0c738c36e2c1 = _e4b905681570._df40f92b36f9("chunk_id", 0)
        _ce49eb55ca09 = _e4b905681570._df40f92b36f9("prompt_len", 0)

        # Convert target entries to integers and replace None with ignore_index
        _925a8228f639 = [
            self._75cb41b20c76
            if _380508b149e2 is _b87227a133c3
            else _885c44f476fc(_380508b149e2) if _1377a5a72ae1(_380508b149e2, _9c0cd04f03f2) and _380508b149e2._48bf23fb7fc7("-")._67a45cc1fc24()
            else _380508b149e2
            for _380508b149e2 in _925a8228f639
        ]

        # For classification mode: map string labels to class ids and pad to max_seq_length
        if not self._f966cf7c8516:
            _ce757f7d7df9 = [
                self._c5b686493850(_380508b149e2) if _1377a5a72ae1(_380508b149e2, _9c0cd04f03f2) else _380508b149e2
                for _380508b149e2 in _925a8228f639
            ]
            _964bdd205db1 = _67663aab9f54(_ce757f7d7df9)
            _a531bc184635 = _c010b5cfe426(0, self._a98491020d3c - _964bdd205db1)
            _ce757f7d7df9 = _ce757f7d7df9 + [self._75cb41b20c76] * _a531bc184635
        else:
            # generative LLM mode expects already-formed targets (no re-mapping/padding here)
            _ce757f7d7df9 = _925a8228f639

        return {
            "lang_code": _f2360d185638,
            "input_ids": _676dba817bf2._20b99c33f6e0(_0dff3b1d2329, _6c5a514f819f=_676dba817bf2._805f131e5097),
            "labels": _676dba817bf2._20b99c33f6e0(_ce757f7d7df9, _6c5a514f819f=_676dba817bf2._805f131e5097),
            "sample_id": _c48e26210f50,
            "chunk_id": _0c738c36e2c1,
            "word_positions": _412d9f5bb625,
            "prompt_len": _ce49eb55ca09,
            "num_chunks": _51956ce4faaa,
        }

    # -------------------------
    # Class and language helpers
    # -------------------------
    def _70dc385efb39(self, _f2360d185638: _9c0cd04f03f2) -> _885c44f476fc:
        """Return numeric class id for a given language code; fallback -1 or unk id."""
        for _314f05b996cc, _e180761f186b in self._75feee318ab5._cc1f776fe8f4():
            if _e180761f186b["lang_code"] == _9c0cd04f03f2(_f2360d185638)._21885d76d411():
                return _314f05b996cc
        return self._75feee318ab5._df40f92b36f9("unk", {})._df40f92b36f9("id", -1)

    def _0b567caf5aaf(self, _5c69b65ac71e: _885c44f476fc) -> _9c0cd04f03f2:
        """Reverse mapping; assumes class_id present."""
        return self._75feee318ab5[_5c69b65ac71e]["lang_code"]

    def _bb3a28947a99(self) -> _885c44f476fc:
        return _67663aab9f54(self._75feee318ab5)

    # -------------------------
    # Language discovery & weights
    # -------------------------
    def _9770400d70e4(self, _44a66f767eb2: _1cb00d143b15) -> _1cb00d143b15:
        """
        Inspect processed file data and update/augment lang_code_dict with languages
        observed in the dataset. This function counts tokens/labels to decide
        lang sample sizes and merges file-level stats.
        """
        _c7004d93fe47 = _cce19f14042c._e99405ff7ed8(r"[^\d\s]+")  # tokens with non-digit characters
        _6907bc3013c7 = _bcaa7995a731()

        if self._f966cf7c8516:
            _44d161c129f2 = []
            for _2c6113d20094 in self._5ff190a2f681:
                _7d552721264b = _2c6113d20094._df40f92b36f9("labels", []) if _1377a5a72ae1(_2c6113d20094, _1cb00d143b15) else (_2c6113d20094[1] if _1377a5a72ae1(_2c6113d20094, _8577d1fe4282) and _67663aab9f54(_2c6113d20094) > 1 else [])
                _b9468f60980b = [_69c1a32085c9 for _69c1a32085c9 in _7d552721264b if _69c1a32085c9 != self._75cb41b20c76]
                if _b9468f60980b:
                    _44d161c129f2._d1887ea22bc9(_b9468f60980b)
            if _44d161c129f2:
                # decoded_texts = self.tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
                _034b85acd94c = [
                    _380508b149e2._9aac7bf530f0("||", " ")._21885d76d411()
                    for _380508b149e2 in self._1b268f3d841e._b63812aa7608(_44d161c129f2, _fd87ad17b15f=_f0f6b05dcb22)
                ]
                # Step 1: Create a reverse lookup dictionary (value -> key)
                _ffddd441aab7 = {_42a4ece89617: _0e35f8b41b89 for _0e35f8b41b89, _42a4ece89617 in _b0c416bda489._5d3a28a700e7._cc1f776fe8f4()}

                for _20aac0ae9317 in _034b85acd94c:
                    # Step 2: Split the string, replace the values, and join them back
                    _20aac0ae9317 = ' '._dea88d689be9([_ffddd441aab7._df40f92b36f9(_8d32a175916c, _8d32a175916c) for _8d32a175916c in _20aac0ae9317._64be617e355a()])
                    _56c1a2a2e2f7 = _c7004d93fe47._ca50977e277d(_20aac0ae9317)
                    _6907bc3013c7._87ece3595c0a(_56c1a2a2e2f7)
        else:
            for _2c6113d20094 in self._5ff190a2f681:
                _7d552721264b = _2c6113d20094._df40f92b36f9("labels", [])
                _56c1a2a2e2f7 = [_5956ef8bd425._21885d76d411() for _5956ef8bd425 in _7d552721264b if _1377a5a72ae1(_5956ef8bd425, _9c0cd04f03f2) and _c7004d93fe47._d1636114609c(_5956ef8bd425)]
                _6907bc3013c7._87ece3595c0a(_56c1a2a2e2f7)

        _eaebe92aa875 = {_42a4ece89617["lang_code"]: _0e35f8b41b89 for _0e35f8b41b89, _42a4ece89617 in _44a66f767eb2._cc1f776fe8f4()}

        for _14aa393e27a4, _04ca8f1ef234 in _6907bc3013c7._cc1f776fe8f4():
            _14aa393e27a4 = _14aa393e27a4._21885d76d411()
            _b1e1bf3c400c = self._4fb82953c16b._df40f92b36f9(_14aa393e27a4, [])
            _99714666aea8 = _caadb64c9dcd(_a42f078351d9._df40f92b36f9("samples_after_processing", 0) for _a42f078351d9 in _b1e1bf3c400c)
            if _14aa393e27a4 in _eaebe92aa875:
                _139320f939ab = _eaebe92aa875[_14aa393e27a4]
                _89ea787af456 = _44a66f767eb2[_139320f939ab]
                _a388ef4a5561 = _89ea787af456["lang_files"] + _b1e1bf3c400c
                _e8a8f0dce175 = _fd1d3db814b4({_a42f078351d9["file_name"]: _a42f078351d9 for _a42f078351d9 in _a388ef4a5561}._2b4e23504549())
                _44a66f767eb2[_139320f939ab] = {
                    "lang_code": _14aa393e27a4,
                    "lang_samples": _89ea787af456["lang_samples"] + _99714666aea8,
                    "lang_files": _e8a8f0dce175,
                }
            else:
                _b382851dd6ec = _67663aab9f54(_44a66f767eb2)
                _44a66f767eb2[_b382851dd6ec] = {
                    "lang_code": _14aa393e27a4,
                    "lang_samples": _99714666aea8,
                    "lang_files": _b1e1bf3c400c,
                }
                _eaebe92aa875[_14aa393e27a4] = _b382851dd6ec

        return _44a66f767eb2

    def _e3b6b67b046c(self, _3a1d3cbd2be8: _963d169bbd37[_2b8a64a7db5a]) -> _231ff69d0ba6._014fe2172ef4:
        _e02a9889291c = _231ff69d0ba6._caadb64c9dcd(_3a1d3cbd2be8)
        return _3a1d3cbd2be8 / _e02a9889291c if _e02a9889291c != 0 else _231ff69d0ba6._a0ae1b36e1b0(_3a1d3cbd2be8)

    def _32550b3a8abb(self, _35a91a4a4b83: _1cb00d143b15) -> _807d03b0641f[_963d169bbd37[_2b8a64a7db5a], _1cb00d143b15]:
        _99714666aea8 = _caadb64c9dcd(_2c6113d20094["lang_samples"] for _2c6113d20094 in _35a91a4a4b83._2b4e23504549())
        for _f2360d185638, _6611f5e43f40 in _35a91a4a4b83._cc1f776fe8f4():
            _2cd832d956db = _6611f5e43f40["lang_samples"]
            # # if class_samples > 0:
            # #     class_weight = total_samples / (class_samples * len(classes_dict))
            # # else:
            # #     class_weight = 0.0
            # if class_samples > 0:
            #     class_weight = total_samples / class_samples
            # else:
            #     class_weight = 0.0
            if _2cd832d956db > 0 :
                _1e9b7ea51d5e = _e4a1c132696e._d3b82e12b672(_99714666aea8 / _2cd832d956db) + 1.0
            else:
                _1e9b7ea51d5e = 0.0
            _35a91a4a4b83[_f2360d185638]["lang_weight"] = _1e9b7ea51d5e
        _cbc7a61c2fad = [_2c6113d20094["lang_weight"] for _2c6113d20094 in _35a91a4a4b83._2b4e23504549()]
        # Update stored lang weights (keeps original behavior)
        for _8a6fac9fdb03, (_f2360d185638, _6611f5e43f40) in _4d006df9481c(_35a91a4a4b83._cc1f776fe8f4()):
            _6611f5e43f40["lang_weight"] = _cbc7a61c2fad[_8a6fac9fdb03]
        return _cbc7a61c2fad, _35a91a4a4b83

    def _e16f12cf8f8a(self, _cd753802e17f: _9c0cd04f03f2, _e08a04b651de: _ef26bbaa8984) -> _807d03b0641f[_1cb00d143b15, _1cb00d143b15]:
        """
        Load classes mapping (JSON). If `is_train` is True the function will discover
        languages in the processed data and update the classes JSON on disk.
        """
        _35a91a4a4b83 = {}
        _cbc7a61c2fad = {}
        if _9f834920047e._e4d5b4d9f73f._a56e879aca13(_cd753802e17f):
            with _b1d33650bd86(_cd753802e17f, "r", _233a80116646="utf8") as _cd419d5642ac:
                _6daf71f9c82c = _a7f775c14fb9._abc379d9ac07(_cd419d5642ac)
                # convert numeric-like keys back to numeric ints/floats as originally done
                _35a91a4a4b83 = {
                    (_2b8a64a7db5a(_0e35f8b41b89) if "." in _0e35f8b41b89 else _885c44f476fc(_0e35f8b41b89)): _42a4ece89617
                    for _0e35f8b41b89, _42a4ece89617 in _6daf71f9c82c._cc1f776fe8f4()
                }

        if _e08a04b651de:
            _35a91a4a4b83 = self._3dcc426d4054(_44a66f767eb2=_35a91a4a4b83)
            _cbc7a61c2fad, _35a91a4a4b83 = self._edcfaf2b7367(_35a91a4a4b83=_35a91a4a4b83)
            with _b1d33650bd86(_cd753802e17f, "w", _233a80116646="utf8") as _204db32102d9:
                _a7f775c14fb9._95831eec3496(_35a91a4a4b83, _204db32102d9, _bbdda1e3a9db=2)

        return _35a91a4a4b83, _cbc7a61c2fad

    def _beaf3a2c6499(self) -> _963d169bbd37[_885c44f476fc]:
        """Return labels for the entire dataset (useful for e.g. class balancing)."""
        return [self._c5b686493850(_f2360d185638) for _f2360d185638 in self._518a195d9b4e] if _6674ada76bae(self, "tgt_data") else []

    # -------------------------
    # Small utilities requested kept
    # -------------------------
    def _e0f1a58ecaba(self, _5000f51f8a8a: _2b8a64a7db5a) -> _885c44f476fc:
        """
        Return number of tokens to overlap given an overlap percentage of max_seq_length.
        Useful for sliding-window chunking.
        """
        return _885c44f476fc(self._a98491020d3c * _5000f51f8a8a)

    @_fa8a2809a746
    def _bac97eda50d8(_d5712556b286: _9c0cd04f03f2) -> _ef26bbaa8984:
        """Return True if all characters in text belong to Arabic script (approx.)."""
        import _9de5f4e891c9
        for _723f62baab84 in _d5712556b286:
            if "ARABIC" not in _9de5f4e891c9._0d753f476b65(_723f62baab84, ""):
                return _ad7e3de25951
        return _f0f6b05dcb22

    @_fa8a2809a746
    def _523adc450ce3(_ddf35637d872: _9c0cd04f03f2) -> _9c0cd04f03f2:
        """
        When sentence is Arabic script, reverse the order of words to better handle
        right-to-left tokenization peculiarities in certain tokenizers.
        """
        if _b0c416bda489._4c38a2010d82(_ddf35637d872):
            _23023fbaac5e = _ddf35637d872._21885d76d411()._64be617e355a()
            _0d3276f46cee = " "._dea88d689be9(_b805665f6fb2(_23023fbaac5e))
            return _0d3276f46cee
        return _ddf35637d872

    def _7dbb2f8d4630(self, _6457dfdd81d4: _9c0cd04f03f2, _280637217418: _9c0cd04f03f2) -> _2b8a64a7db5a:
        """Return similarity ratio between two filenames; kept for optional diagnostics."""
        return _533e5748410c(_b87227a133c3, _6457dfdd81d4, _280637217418)._65b7cb644fdf()

    # -------------------------
    # Core, performance-sensitive static workers
    # -------------------------
    @_fa8a2809a746
    def _8baf52138c1f(_a719f4034217) -> _807d03b0641f[_963d169bbd37[_1cb00d143b15], _885c44f476fc]:
        """
        Convert batches of (src_lines, tgt_lines) into per-chunk dicts for classification.
        Returns (results_list, local_label_counter)
        """
        import _97e62429d8d1
        _58c4ff88bf61 = _97e62429d8d1._97e62429d8d1()
        _15a916424752, _e27c3a3f5ee4, _dc85815d29a2, _ff07c2fa61f9, _e08a04b651de, _33eb60b392dc = _a719f4034217
        _1b268f3d841e = _b0c416bda489._bdf48e99c683
        _43a1bf4ef550 = 0
        _0f5000650cf2 = _1b268f3d841e._b0af4822375b
        _d7f80ebe18be: _963d169bbd37[_1cb00d143b15] = []

        # Clean inputs and prepare per-word lists
        _d468c1562933 = [_d9bfcdf38597._21885d76d411() for _d9bfcdf38597 in _15a916424752]
        _68e36acd6343 = [_380508b149e2._21885d76d411() for _380508b149e2 in _e27c3a3f5ee4]
        _af9d2afd98bb = [_d5712556b286._64be617e355a() if _d5712556b286 else ["<empty>"] for _d5712556b286 in _d468c1562933]
        _4fcfff3e27d9 = []
        for _377d18d3a0d2, _893533ebeb7c in _828b7ca55a4e(_af9d2afd98bb, _e27c3a3f5ee4):
            _dd05f22357f3 = _893533ebeb7c if _1377a5a72ae1(_893533ebeb7c, _fd1d3db814b4) else (_893533ebeb7c._21885d76d411()._64be617e355a() if _893533ebeb7c._21885d76d411() else ["<empty>"])
            if _67663aab9f54(_dd05f22357f3) == 1:
                _dd05f22357f3 = [_dd05f22357f3[0]] * _67663aab9f54(_377d18d3a0d2)
            elif _67663aab9f54(_dd05f22357f3) != _67663aab9f54(_377d18d3a0d2):
                _dd05f22357f3 = _dd05f22357f3[:_67663aab9f54(_377d18d3a0d2)] if _67663aab9f54(_dd05f22357f3) > _67663aab9f54(_377d18d3a0d2) else _dd05f22357f3 + [_dd05f22357f3[-1]] * (_67663aab9f54(_377d18d3a0d2) - _67663aab9f54(_dd05f22357f3))
            _4fcfff3e27d9._d1887ea22bc9(_dd05f22357f3)

        # Flatten all words for a single tokenizer call (faster)
        _e9b83ecf006d = _fd1d3db814b4(_562ce915fe41(*_af9d2afd98bb))
        _c96641459d65 = _97e62429d8d1._97e62429d8d1()
        try:
            _c6c7bacdbd80 = _1b268f3d841e(_e9b83ecf006d, _e4e88cda5c3b=_ad7e3de25951, _f9b50a624d5d=_ad7e3de25951, _55327a5e973f=_ad7e3de25951)
        except _ac9e60ea6aea as _fe52a65c49a1:
            _440fdb3c09bb(f"Tokenization error: {_fe52a65c49a1}")
            _c6c7bacdbd80 = {"input_ids": [[0] for _ in _e9b83ecf006d]}
        # build word token info per sentence
        _ca3e2c9a995b = 0
        _c2fe03066c19 = []
        for _377d18d3a0d2 in _af9d2afd98bb:
            _311093d427e3 = _67663aab9f54(_377d18d3a0d2)
            _86ddacd06834 = [(_8a6fac9fdb03, _c6c7bacdbd80["input_ids"][_ca3e2c9a995b + _8a6fac9fdb03], _67663aab9f54(_c6c7bacdbd80["input_ids"][_ca3e2c9a995b + _8a6fac9fdb03])) for _8a6fac9fdb03 in _b133bf652dcc(_311093d427e3)]
            _c2fe03066c19._d1887ea22bc9(_86ddacd06834)
            _ca3e2c9a995b += _311093d427e3

        # chunk each sentence into token windows
        for _71bea0224061, (_377d18d3a0d2, _8740f58690ca, _dd05f22357f3) in _4d006df9481c(_828b7ca55a4e(_af9d2afd98bb, _c2fe03066c19, _4fcfff3e27d9)):
            _c48e26210f50 = _33eb60b392dc + _71bea0224061
            _0c738c36e2c1 = 0
            if _377d18d3a0d2 == ["<empty>"]:
                _0dff3b1d2329 = [0] * _dc85815d29a2
                _d7f80ebe18be._d1887ea22bc9({
                    "sample_id": _c48e26210f50,
                    "chunk_id": _0c738c36e2c1,
                    "input_ids": _0dff3b1d2329,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue

            _8a6fac9fdb03 = 0
            _8280d2a52fd6 = _67663aab9f54(_8740f58690ca)
            _7700323651e4 = []
            while _8a6fac9fdb03 < _8280d2a52fd6:
                _562decd7892b = 0
                _0b0bd4836e88 = []
                _48123b71718f = []
                _412d9f5bb625 = []
                _4f91941e5148 = _8a6fac9fdb03
                while _4f91941e5148 < _8280d2a52fd6:
                    _4014ae22d41b, _8da1b16460b2, _2428d06a5d8d = _8740f58690ca[_4f91941e5148]
                    _c833892562e6 = _dd05f22357f3[_4014ae22d41b] if _4014ae22d41b < _67663aab9f54(_dd05f22357f3) else _dd05f22357f3[-1] if _dd05f22357f3 else "<unknown>"
                    if _2428d06a5d8d > _dc85815d29a2 and not _0b0bd4836e88:
                        _0b0bd4836e88 += _8da1b16460b2[:_dc85815d29a2]
                        _48123b71718f._d1887ea22bc9(_c833892562e6)
                        _412d9f5bb625._d1887ea22bc9(_4014ae22d41b)
                        _4f91941e5148 += 1
                        break
                    if _562decd7892b + _2428d06a5d8d > _dc85815d29a2 and _0b0bd4836e88:
                        break
                    _0b0bd4836e88 += _8da1b16460b2
                    _48123b71718f._d1887ea22bc9(_c833892562e6)
                    _43a1bf4ef550 += 1
                    _412d9f5bb625._d1887ea22bc9(_4f91941e5148)
                    _562decd7892b += _2428d06a5d8d
                    _4f91941e5148 += 1

                if not _0b0bd4836e88:
                    # fallback: take token prefix to avoid infinite loop
                    _0b0bd4836e88 = _8740f58690ca[_8a6fac9fdb03][1][:_dc85815d29a2] or [0]
                    _48123b71718f = [_dd05f22357f3[_8a6fac9fdb03] if _8a6fac9fdb03 < _67663aab9f54(_dd05f22357f3) else _dd05f22357f3[-1] if _dd05f22357f3 else "<unknown>"]
                    _412d9f5bb625 = [_8a6fac9fdb03]
                    _43a1bf4ef550 += 1
                    _8a6fac9fdb03 += 1

                # pad tokens to fixed length
                if _67663aab9f54(_0b0bd4836e88) < _dc85815d29a2:
                    _0b0bd4836e88 += [_0f5000650cf2] * (_dc85815d29a2 - _67663aab9f54(_0b0bd4836e88))

                _7700323651e4._d1887ea22bc9({
                    "sample_id": _c48e26210f50,
                    "chunk_id": _0c738c36e2c1,
                    "input_ids": _0b0bd4836e88,
                    "labels": _48123b71718f,
                    "word_positions": _412d9f5bb625,
                    "num_chunks": 1
                })
                _0c738c36e2c1 += 1

                if _4f91941e5148 >= _8280d2a52fd6:
                    break

                # stride with overlap (in words)
                _444c12472ba3 = _67663aab9f54(_412d9f5bb625)
                _cd5053ea7c70 = _885c44f476fc(_ff07c2fa61f9 * _444c12472ba3)
                _cd5053ea7c70 = _df35fa383046(_cd5053ea7c70, _444c12472ba3 - 1) if _444c12472ba3 > 1 else 0
                _1eae9e8748d2 = _4f91941e5148 - _cd5053ea7c70
                if _1eae9e8748d2 <= _8a6fac9fdb03:
                    _1eae9e8748d2 = _8a6fac9fdb03 + 1
                _8a6fac9fdb03 = _1eae9e8748d2

            _51956ce4faaa = _67663aab9f54(_7700323651e4)
            for _01e776eefd9d in _7700323651e4:
                _01e776eefd9d["num_chunks"] = _51956ce4faaa
            _d7f80ebe18be._67cb322b75a4(_7700323651e4)

            if not _b0c416bda489._ffec05c7fed1 and not _e08a04b651de and _51956ce4faaa > 1:
                _440fdb3c09bb(f"[DEBUG] sample_id={_c48e26210f50}", _966ee3a26c93=_f0f6b05dcb22)
                _b0c416bda489._ffec05c7fed1 = _f0f6b05dcb22

        # Timing/logging suppressed to preserve original behavior
        return _d7f80ebe18be, _43a1bf4ef550

    # @staticmethod
    # def process_batch_gen_llm_classifier(args) -> Tuple[List[dict], int]:
    #     """
    #     Construct chunks for generative LLM framing.
    #     The function follows the previously specified format:
    #       - Insert single space tokens between words in both streams.
    #       - word_positions contains per-label-token positions and -1 entries for spaces.
    #       - Overlap computed in WORDS, not tokens.
    #     """
    #     import time
    #     start_time = time.time()
    #     (prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_test, start_sample_id) = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id = tokenizer.eos_token_id
    #     ignore_index = -100

    #     # Chat-ish prefixes used in dataset construction
    #     # input_prefix = ("\n<|start_header_id|>user<|end_header_id|>\n"
    #     # "Identify the language of every word and reply with space-separated codes only.\n"
    #     # "Do not include any explanation or extra text.\n")
    #     # response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     input_prefix = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\n"
    #     "Identify the language of every word and reply with space-separated codes only.\n"
    #     "Do not include any explanation or extra text.\n")
    #     response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
    #     instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
    #     input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
    #     response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
    #     space_ids = tokenizer.encode(" ", add_special_tokens=False)
    #     prefix = instruction_ids + input_prefix_ids
    #     suffix = response_prefix_ids
    #     eos_len = 1
    #     fixed_len = len(prefix) + len(suffix) + eos_len

    #     results: List[dict] = []
    #     local_label_counter = 0

    #     # Preprocess lines into words lists and align labels to words
    #     src_texts = [s.strip() for s in src_lines]
    #     tgt_texts = [t.strip() for t in tgt_lines]
    #     src_words_list = []
    #     tgt_words_list = []
    #     for src, tgt in zip(src_texts, tgt_lines):
    #         src_words = src.split() if src else ["<empty>"]
    #         tgt_words = tgt if isinstance(tgt, list) else (tgt.strip().split() if tgt.strip() else ["<empty>"])
    #         if len(tgt_words) == 1:
    #             tgt_words = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) != len(src_words):
    #             tgt_words = tgt_words[:len(src_words)] if len(tgt_words) > len(src_words) else tgt_words + [tgt_words[-1]] * (len(src_words) - len(tgt_words))
    #         src_words_list.append(src_words)
    #         tgt_words_list.append(tgt_words)

    #     # Flatten words for efficient tokenization
    #     all_src_words = list(chain(*src_words_list))
    #     all_tgt_words = list(chain(*tgt_words_list))

    #     unique_tgt_words = {w for words in tgt_words_list for w in words}

    #     for word in unique_tgt_words:
    #         if word not in LanguageIdentificationDataset.tracking_classes:
    #             class_tokens = tokenizer.encode(word, add_special_tokens=False)
    #             if len(class_tokens) > 1:
    #                 LanguageIdentificationDataset.tracking_classes[word] = f"{len(LanguageIdentificationDataset.tracking_classes)+1}"
    #             else:
    #                 LanguageIdentificationDataset.tracking_classes[word] = word
    #     # print(f"check tracking classes {LanguageIdentificationDataset.tracking_classes}")
    #     # FOR NEW TOKEN UNCOMMENT THIS
    #     # Unique Token logic
    #     # new_tokens = []
    #     # tracking = []

    #     # for word in unique_tgt_words:
    #     #     if len(tokenizer.encode(word, add_special_tokens=False)) > 1:
    #     #         new_token = f"{word}"
    #     #         new_tokens.append(new_token)
    #     #         tracking.append((word, new_token))

    #     # if new_tokens:
    #     #     tokenizer.add_tokens(new_tokens, special_tokens=False)
    #     #     for word, token in tracking:
    #     #         token_id = tokenizer.convert_tokens_to_ids(token)
    #     #         print(f"Added word '{word}' with token {token} (id: {token_id})")
    #     # else:
    #     #     print("No multi-token words found")
        
    #     # tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     # tok_tgt = tokenizer(all_tgt_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
    #     tok_tgt = tokenizer([str(LanguageIdentificationDataset.tracking_classes.get(tgt)) for tgt in all_tgt_words], add_special_tokens=False, return_attention_mask=False)["input_ids"]

    #     # Build per-line token info
    #     src_idx = 0
    #     tgt_idx = 0
    #     src_word_token_info_list = []
    #     tgt_word_token_info_list = []
    #     for src_words, tgt_words in zip(src_words_list, tgt_words_list):
    #         src_len = len(src_words)
    #         tgt_len = len(tgt_words)
    #         if src_words == ["<empty>"] or tgt_words == ["<empty>"]:
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             continue
    #         try:
    #             src_info = [(w, tok_src[src_idx + i], len(tok_src[src_idx + i]) if isinstance(tok_src[src_idx + i], list) else 1) for i, w in enumerate(src_words)]
    #             tgt_info = [(w, tok_tgt[tgt_idx + i], len(tok_tgt[tgt_idx + i]) if isinstance(tok_tgt[tgt_idx + i], list) else 1) for i, w in enumerate(tgt_words)]
    #         except IndexError:
    #             # On tokenization mismatches, fallback safely
    #             src_word_token_info_list.append([(src_words[0], [0], 1)])
    #             tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
    #             src_idx += src_len
    #             tgt_idx += tgt_len
    #             continue
    #         src_word_token_info_list.append(src_info)
    #         tgt_word_token_info_list.append(tgt_info)
    #         src_idx += src_len
    #         tgt_idx += tgt_len

    #     # Build chunks per sentence
    #     for line_idx, (src_words, src_word_token_info, tgt_word_token_info) in enumerate(zip(src_words_list, src_word_token_info_list, tgt_word_token_info_list)):
    #         sample_id = start_sample_id + line_idx
    #         chunk_id = 0
    #         src_word_labels = [info[0] for info in tgt_word_token_info]

    #         if src_words == ["<empty>"]:
    #             input_ids = prefix + [0] + suffix + [eos_id]
    #             labels = [ignore_index] * len(input_ids)
    #             pad_len = max_seq_len - len(input_ids)
    #             if pad_len > 0:
    #                 input_ids += [pad_id] * pad_len
    #                 labels += [ignore_index] * pad_len
    #             results.append({
    #                 "lang_codes": ["<empty>"],
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": [0],
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": len(prefix) + 1 + len(suffix),
    #                 "chunk_words": ["<empty>"],
    #                 "chunk_labels": ["<empty>"],
    #                 "num_chunks": 1
    #             })
    #             continue

    #         i = 0
    #         n = len(src_word_token_info)
    #         prev_j = -1
    #         chunk_results = []
    #         while i < n:
    #             total_len = fixed_len
    #             chunk_input_tokens = []
    #             chunk_label_tokens = []
    #             word_positions = []
    #             lang_codes = []
    #             chunk_words = []
    #             chunk_labels = []
    #             j = i
    #             while j < n:
    #                 _, src_ids, src_len = src_word_token_info[j]
    #                 tgt_word, tgt_ids, tgt_len = tgt_word_token_info[j]
    #                 inter_word_spaces = len(space_ids) if j < n - 1 else 0
    #                 # choose conservative word_total so both streams fit
    #                 word_total = max(src_len, tgt_len) + inter_word_spaces
    #                 if total_len + word_total > max_seq_len * 0.9:
    #                     break

    #                 # append inputs and spaces
    #                 chunk_input_tokens += src_ids if isinstance(src_ids, list) else [src_ids]
    #                 if inter_word_spaces:
    #                     chunk_input_tokens += space_ids

    #                 # append labels and word_positions
    #                 if tgt_len:
    #                     chunk_label_tokens += tgt_ids if isinstance(tgt_ids, list) else [tgt_ids]
    #                     word_positions += [j] * tgt_len
    #                 if inter_word_spaces:
    #                     chunk_label_tokens += space_ids
    #                     word_positions += [-1] * inter_word_spaces

    #                 lang_codes.append(tgt_word)
    #                 chunk_words.append(src_words[j])
    #                 chunk_labels.append(tgt_word)
    #                 local_label_counter += len(src_words[j])
    #                 total_len += word_total
    #                 j += 1

    #             if not chunk_input_tokens:
    #                 i += 1
    #                 continue

    #             flat_input_ids = chunk_input_tokens
    #             flat_label_ids = chunk_label_tokens
    #             prompt_len = len(prefix) + len(flat_input_ids) + len(suffix)

    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
    #             # RIGHT PAD + LEFT PAD TEST METHOD
    #             # if is_test is False:
    #             #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             # else:
    #             #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #             #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
    #             # # pad to fixed size (inputs appended or prepended depending on test/train)
    #             # inputs_pad_len = max_seq_len - len(input_ids)
    #             # labels_pad_len = max_seq_len - len(labels)
    #             # if inputs_pad_len > 0:
    #             #     if is_test:
    #             #         input_ids = [pad_id] * inputs_pad_len + input_ids
    #             #     else:
    #             #         input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     if is_test:
    #             #         labels = [ignore_index] * labels_pad_len + labels
    #             #     else:
    #             #         labels += [ignore_index] * labels_pad_len
                
    #             # LEFT PAD METHOD
    #             if is_test is False:
    #                 input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
    #             else:
    #                 input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #                 labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             inputs_pad_len = max_seq_len - len(input_ids)
    #             labels_pad_len = max_seq_len - len(labels)
    #             if inputs_pad_len > 0:
    #                 input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # if is_test:
    #                 #     input_ids = [pad_id] * inputs_pad_len + input_ids
    #                 # else:
    #                 #     input_ids += [pad_id] * inputs_pad_len
    #             if labels_pad_len > 0:
    #                 labels = [ignore_index] * labels_pad_len + labels
    #                 # if is_test:
    #                 #     labels = [ignore_index] * labels_pad_len + labels
    #                 # else:
    #                 #     labels += [ignore_index] * labels_pad_len

    #             # if inputs_pad_len > 0:
    #             #     input_ids += [pad_id] * inputs_pad_len
    #             # if labels_pad_len > 0:
    #             #     labels += [ignore_index] * labels_pad_len

    #             if len(input_ids) != max_seq_len or len(labels) != max_seq_len:
    #                 raise RuntimeError(
    #                     f"[SEQ LEN VIOLATION] "
    #                     f"sample_id={sample_id} "
    #                     f"chunk_id={chunk_id} "
    #                     f"is_test={is_test} "
    #                     f"len(input_ids)={len(input_ids)} "
    #                     f"len(labels)={len(labels)} "
    #                     f"max_seq_len={max_seq_len} "
    #                     f"prompt_len={prompt_len} "
    #                     f"flat_input_len={len(flat_input_ids)} "
    #                     f"flat_label_len={len(flat_label_ids)}"
    #                 )


    #             chunk_results.append({
    #                 "lang_codes": lang_codes,
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "word_positions": word_positions,
    #                 "input_ids": input_ids,
    #                 "labels": labels,
    #                 "prompt_len": prompt_len,
    #                 "chunk_words": chunk_words,
    #                 "chunk_labels": chunk_labels,
    #                 "num_chunks": 1
    #             })
    #             chunk_id += 1

    #             if j >= n or j <= prev_j:
    #                 break
    #             prev_j = j
    #             overlap_words = max(1, int(overlap_ratio * len(chunk_words)))
    #             i = j - overlap_words if (j - overlap_words) > i else j

    #         num_chunks = len(chunk_results)
    #         for r in chunk_results:
    #             r["num_chunks"] = num_chunks
    #         results.extend(chunk_results)

    #         if not LanguageIdentificationDataset.is_debug_sample_shown and not is_test and num_chunks > 1:
    #             LanguageIdentificationDataset.is_debug_sample_shown = True

    #     return results, local_label_counter

    @_fa8a2809a746
    def _8b05f53725a3(_a719f4034217) -> _807d03b0641f[_963d169bbd37[_1cb00d143b15], _885c44f476fc]:
        """
        Construct chunks for generative LLM framing.
        The function follows the previously specified format:
          - Insert single space tokens between words in both streams.
          - word_positions contains per-label-token positions and -1 entries for spaces.
          - Overlap computed in WORDS, not tokens.
        """
        import _97e62429d8d1
        _58c4ff88bf61 = _97e62429d8d1._97e62429d8d1()
        (_5cf25e51dedf, _15a916424752, _e27c3a3f5ee4, _dc85815d29a2, _ff07c2fa61f9, _88fc0dafa83d, _33eb60b392dc) = _a719f4034217
        _1b268f3d841e = _b0c416bda489._bdf48e99c683
        _0f5000650cf2 = _1b268f3d841e._b0af4822375b or _1b268f3d841e._47f4a168d151
        _0a22ee7c3297 = _1b268f3d841e._47f4a168d151
        _75cb41b20c76 = -100

        # Chat-ish prefixes used in dataset construction
        _edcbb9eee058 = _1b268f3d841e._61cb2dd7ba55._572538eab600()
        if "llama" in _edcbb9eee058:
            _cbef884ab704 = ("<|begin_of_text|><|start_header_id|>user<|end_header_id|>\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _07d80417b58c = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        elif "qwen" in _edcbb9eee058:
            _cbef884ab704 = ("<|im_start|>system\nYou are Qwen, created by Alibaba Cloud."
            "You are a helpful assistant.<|im_end|>\n<|im_start|>user\n"
            "Instructions:\nIdentify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _07d80417b58c = "<|im_end|>\n<|im_start|>assistant\n"
        elif "gemma" in _edcbb9eee058:
            _cbef884ab704 = ("<bos><start_of_turn>user\nInstructions:\n"
            "Identify the language of every word and reply with || delimted language ids only.\n"
            "Do not include any explanation or extra text.\nText:\n")
            _07d80417b58c = "<end_of_turn>\n<start_of_turn>model\n"
        else:
            raise _e944cf1ee5b4(f"Gen LLM module currently doesnt support {_edcbb9eee058}")
        _624e8620b310 = _1b268f3d841e._30cbfaeb4422(_5cf25e51dedf, _e4e88cda5c3b=_ad7e3de25951)
        _7dedde35bc1a = _1b268f3d841e._30cbfaeb4422(_cbef884ab704, _e4e88cda5c3b=_ad7e3de25951)
        _b145f5ac89b7 = _1b268f3d841e._30cbfaeb4422(_07d80417b58c, _e4e88cda5c3b=_ad7e3de25951)
        # space_ids = tokenizer.encode(" ", add_special_tokens=False)
        _beebf3c550d9 = _1b268f3d841e._30cbfaeb4422("||", _e4e88cda5c3b=_ad7e3de25951)
        _5c4f3756b987 = _624e8620b310 + _7dedde35bc1a
        _c8a57e21388a = _b145f5ac89b7
        _c81a53f79629 = 1
        _264532903868 = _67663aab9f54(_5c4f3756b987) + _67663aab9f54(_c8a57e21388a) + _c81a53f79629

        _d7f80ebe18be: _963d169bbd37[_1cb00d143b15] = []
        _43a1bf4ef550 = 0

        # Preprocess lines into words lists and align labels to words
        _d468c1562933 = [_d9bfcdf38597._21885d76d411() for _d9bfcdf38597 in _15a916424752]
        _68e36acd6343 = [_380508b149e2._21885d76d411() for _380508b149e2 in _e27c3a3f5ee4]
        _af9d2afd98bb = []
        _e3fbc5630ac2 = []
        for _70e3b53bf271, _893533ebeb7c in _828b7ca55a4e(_d468c1562933, _e27c3a3f5ee4):
            _377d18d3a0d2 = _70e3b53bf271._64be617e355a() if _70e3b53bf271 else ["<empty>"]
            _bf205a27bd4a = _893533ebeb7c if _1377a5a72ae1(_893533ebeb7c, _fd1d3db814b4) else (_893533ebeb7c._21885d76d411()._64be617e355a() if _893533ebeb7c._21885d76d411() else ["<empty>"])
            if _67663aab9f54(_bf205a27bd4a) == 1:
                _bf205a27bd4a = [_bf205a27bd4a[0]] * _67663aab9f54(_377d18d3a0d2)
            elif _67663aab9f54(_bf205a27bd4a) != _67663aab9f54(_377d18d3a0d2):
                _bf205a27bd4a = _bf205a27bd4a[:_67663aab9f54(_377d18d3a0d2)] if _67663aab9f54(_bf205a27bd4a) > _67663aab9f54(_377d18d3a0d2) else _bf205a27bd4a + [_bf205a27bd4a[-1]] * (_67663aab9f54(_377d18d3a0d2) - _67663aab9f54(_bf205a27bd4a))
            _af9d2afd98bb._d1887ea22bc9(_377d18d3a0d2)
            _e3fbc5630ac2._d1887ea22bc9(_bf205a27bd4a)

        # Flatten words for efficient tokenization
        _e9b83ecf006d = _fd1d3db814b4(_562ce915fe41(*_af9d2afd98bb))
        _d5d2de8e5545 = _fd1d3db814b4(_562ce915fe41(*_e3fbc5630ac2))

        _2146be887d11 = {_c272babb7fd1 for _23023fbaac5e in _e3fbc5630ac2 for _c272babb7fd1 in _23023fbaac5e}

        for _8d32a175916c in _2146be887d11:
            if _8d32a175916c not in _b0c416bda489._5d3a28a700e7:
                _668a0b9f740f = _1b268f3d841e._30cbfaeb4422(_8d32a175916c, _e4e88cda5c3b=_ad7e3de25951)
                if _67663aab9f54(_668a0b9f740f) > 1:
                    _b0c416bda489._5d3a28a700e7[_8d32a175916c] = f"{_67663aab9f54(_b0c416bda489._5d3a28a700e7)+1}"
                else:
                    _b0c416bda489._5d3a28a700e7[_8d32a175916c] = _8d32a175916c
        
        _8f5b3b2d9adb = _1b268f3d841e(_e9b83ecf006d, _e4e88cda5c3b=_ad7e3de25951, _f9b50a624d5d=_ad7e3de25951)["input_ids"]
        _f75814d246fe = _1b268f3d841e([_9c0cd04f03f2(_b0c416bda489._5d3a28a700e7._df40f92b36f9(_893533ebeb7c)) for _893533ebeb7c in _d5d2de8e5545], _e4e88cda5c3b=_ad7e3de25951, _f9b50a624d5d=_ad7e3de25951)["input_ids"]

        # Build per-line token info
        _ca3e2c9a995b = 0
        _e5dcafccfefd = 0
        _c2fe03066c19 = []
        _614492463d6c = []
        for _377d18d3a0d2, _bf205a27bd4a in _828b7ca55a4e(_af9d2afd98bb, _e3fbc5630ac2):
            _311093d427e3 = _67663aab9f54(_377d18d3a0d2)
            _02406cbabe62 = _67663aab9f54(_bf205a27bd4a)
            if _377d18d3a0d2 == ["<empty>"] or _bf205a27bd4a == ["<empty>"]:
                _c2fe03066c19._d1887ea22bc9([(_377d18d3a0d2[0], [0], 1)])
                _614492463d6c._d1887ea22bc9([(_bf205a27bd4a[0], [0], 1)])
                continue
            try:
                _86ddacd06834 = [(_c272babb7fd1, _8f5b3b2d9adb[_ca3e2c9a995b + _8a6fac9fdb03], _67663aab9f54(_8f5b3b2d9adb[_ca3e2c9a995b + _8a6fac9fdb03]) if _1377a5a72ae1(_8f5b3b2d9adb[_ca3e2c9a995b + _8a6fac9fdb03], _fd1d3db814b4) else 1) for _8a6fac9fdb03, _c272babb7fd1 in _4d006df9481c(_377d18d3a0d2)]
                _643e7180b326 = [(_c272babb7fd1, _f75814d246fe[_e5dcafccfefd + _8a6fac9fdb03], _67663aab9f54(_f75814d246fe[_e5dcafccfefd + _8a6fac9fdb03]) if _1377a5a72ae1(_f75814d246fe[_e5dcafccfefd + _8a6fac9fdb03], _fd1d3db814b4) else 1) for _8a6fac9fdb03, _c272babb7fd1 in _4d006df9481c(_bf205a27bd4a)]
            except _70f2b232c52a:
                # On tokenization mismatches, fallback safely
                _c2fe03066c19._d1887ea22bc9([(_377d18d3a0d2[0], [0], 1)])
                _614492463d6c._d1887ea22bc9([(_bf205a27bd4a[0], [0], 1)])
                _ca3e2c9a995b += _311093d427e3
                _e5dcafccfefd += _02406cbabe62
                continue
            _c2fe03066c19._d1887ea22bc9(_86ddacd06834)
            _614492463d6c._d1887ea22bc9(_643e7180b326)
            _ca3e2c9a995b += _311093d427e3
            _e5dcafccfefd += _02406cbabe62

        # Build chunks per sentence
        for _71bea0224061, (_377d18d3a0d2, _8740f58690ca, _b6b68cdc517b) in _4d006df9481c(_828b7ca55a4e(_af9d2afd98bb, _c2fe03066c19, _614492463d6c)):
            _c48e26210f50 = _33eb60b392dc + _71bea0224061
            _0c738c36e2c1 = 0
            _d2f8797b14f8 = [_32ec1516af75[0] for _32ec1516af75 in _b6b68cdc517b]

            if _377d18d3a0d2 == ["<empty>"]:
                _440fdb3c09bb(f"Skiiping line {_71bea0224061} in file since its empty")

            _8a6fac9fdb03 = 0
            _8280d2a52fd6 = _67663aab9f54(_8740f58690ca)
            _4b1605a05a45 = -1
            _7700323651e4 = []
            while _8a6fac9fdb03 < _8280d2a52fd6:
                _562decd7892b = _264532903868
                _d9b0394878d4 = []
                _3fb9dd259f0f = []
                _412d9f5bb625 = []
                _738b589978eb = []
                _e236dc97db6c = []
                _48123b71718f = []
                _4f91941e5148 = _8a6fac9fdb03
                while _4f91941e5148 < _8280d2a52fd6:
                    _, _173ec34d216f, _311093d427e3 = _8740f58690ca[_4f91941e5148]
                    _26d4a226372d, _ae9546b1a3f7, _02406cbabe62 = _b6b68cdc517b[_4f91941e5148]
                    _25306f366e3f = _67663aab9f54(_beebf3c550d9) if _4f91941e5148 < _8280d2a52fd6 - 1 else 0
                    # choose conservative word_total so both streams fit
                    # word_total = max(src_len, tgt_len) + inter_word_spaces
                    # if total_len + word_total > max_seq_len * 0.9:
                    #     break

                    # account for BOTH streams + spaces
                    # word_input = src_len + inter_word_spaces
                    # word_label = tgt_len + inter_word_spaces
                    # word_total = word_input + word_label

                    _43f629c8ddfc = _311093d427e3 + _25306f366e3f
                    _bc79a4d7431d = _43f629c8ddfc if _88fc0dafa83d else (_43f629c8ddfc + _02406cbabe62 + _25306f366e3f)


                    if _562decd7892b + _bc79a4d7431d > _dc85815d29a2:
                        break


                    # append inputs and spaces
                    _d9b0394878d4 += _173ec34d216f if _1377a5a72ae1(_173ec34d216f, _fd1d3db814b4) else [_173ec34d216f]
                    if _25306f366e3f:
                        _d9b0394878d4 += _beebf3c550d9

                    # append labels and word_positions
                    if _02406cbabe62:
                        _3fb9dd259f0f += _ae9546b1a3f7 if _1377a5a72ae1(_ae9546b1a3f7, _fd1d3db814b4) else [_ae9546b1a3f7]
                        _412d9f5bb625 += [_4f91941e5148] * _02406cbabe62
                    if _25306f366e3f:
                        _3fb9dd259f0f += _beebf3c550d9
                        _412d9f5bb625 += [-1] * _25306f366e3f

                    _738b589978eb._d1887ea22bc9(_26d4a226372d)
                    _e236dc97db6c._d1887ea22bc9(_377d18d3a0d2[_4f91941e5148])
                    _48123b71718f._d1887ea22bc9(_26d4a226372d)
                    _43a1bf4ef550 += _67663aab9f54(_377d18d3a0d2[_4f91941e5148])
                    _562decd7892b += _bc79a4d7431d
                    _4f91941e5148 += 1

                if not _d9b0394878d4:
                    _8a6fac9fdb03 += 1
                    continue

                _e0fa8f7ce686 = _d9b0394878d4
                _25c52261b83b = _3fb9dd259f0f
                _ce49eb55ca09 = _67663aab9f54(_5c4f3756b987) + _67663aab9f54(_e0fa8f7ce686) + _67663aab9f54(_c8a57e21388a)

                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
                # RIGHT PAD + LEFT PAD TEST METHOD
                # if is_test is False:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = prefix + flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

                # # print(f"LABELS HAVE UNK in data TEST {is_test} and unk is {(3200 in labels)}")
                # # pad to fixed size (inputs appended or prepended depending on test/train)
                # inputs_pad_len = max_seq_len - len(input_ids)
                # labels_pad_len = max_seq_len - len(labels)
                # if inputs_pad_len > 0:
                #     if is_test:
                #         input_ids = [pad_id] * inputs_pad_len + input_ids
                #     else:
                #         input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     if is_test:
                #         labels = [ignore_index] * labels_pad_len + labels
                #     else:
                #         labels += [ignore_index] * labels_pad_len
                
                # LEFT PAD METHOD
                if _88fc0dafa83d is _ad7e3de25951:
                    _0dff3b1d2329 = _5c4f3756b987 + _e0fa8f7ce686 + _c8a57e21388a + _25c52261b83b + [_0a22ee7c3297]
                    _7d552721264b = [_75cb41b20c76] * _ce49eb55ca09 + _25c52261b83b + [_75cb41b20c76]
                else:
                    # input_ids = prefix + flat_input_ids + suffix + [eos_id]
                    # labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                    # REMOVE EOS
                    # input_ids = prefix + flat_input_ids + suffix
                    # labels = [ignore_index] * prompt_len + flat_label_ids
                    _3e5ce1c57210 = _5c4f3756b987 + _e0fa8f7ce686 + _c8a57e21388a

                    _b09b5979dca1 = _dc85815d29a2 - _67663aab9f54(_3e5ce1c57210)
                    _0dff3b1d2329 = [_0f5000650cf2] * _b09b5979dca1 + _3e5ce1c57210

                    _7d552721264b = [_75cb41b20c76] * _dc85815d29a2 + _25c52261b83b
                    # label_start = inputs_pad_len + prompt_len
                    # labels[label_start : label_start + len(flat_label_ids)] = flat_label_ids

                if not _88fc0dafa83d:
                    _b09b5979dca1 = _dc85815d29a2 - _67663aab9f54(_0dff3b1d2329)
                    _a05ed60d7e82 = _dc85815d29a2 - _67663aab9f54(_7d552721264b)
                    if _b09b5979dca1 > 0:
                        _0dff3b1d2329 = [_0f5000650cf2] * _b09b5979dca1 + _0dff3b1d2329
                        # if is_test:
                        #     input_ids = [pad_id] * inputs_pad_len + input_ids
                        # else:
                        #     input_ids += [pad_id] * inputs_pad_len
                    if _a05ed60d7e82 > 0:
                        _7d552721264b = [_75cb41b20c76] * _a05ed60d7e82 + _7d552721264b
                        # if is_test:
                        #     labels = [ignore_index] * labels_pad_len + labels
                        # else:
                        #     labels += [ignore_index] * labels_pad_len

                # if inputs_pad_len > 0:
                #     input_ids += [pad_id] * inputs_pad_len
                # if labels_pad_len > 0:
                #     labels += [ignore_index] * labels_pad_len

                # not respecting rule in test since test will be free flowing
                if _88fc0dafa83d is _ad7e3de25951 and (_67663aab9f54(_0dff3b1d2329) != _dc85815d29a2 or _67663aab9f54(_7d552721264b) != _dc85815d29a2):
                    raise _a5f643f5564f(
                        f"[SEQ LEN VIOLATION] "
                        f"sample_id={_c48e26210f50} "
                        f"chunk_id={_0c738c36e2c1} "
                        f"is_test={_88fc0dafa83d} "
                        f"len(input_ids)={_67663aab9f54(_0dff3b1d2329)} "
                        f"len(labels)={_67663aab9f54(_7d552721264b)} "
                        f"max_seq_len={_dc85815d29a2} "
                        f"prompt_len={_ce49eb55ca09} "
                        f"flat_input_len={_67663aab9f54(_e0fa8f7ce686)} "
                        f"flat_label_len={_67663aab9f54(_25c52261b83b)}"
                    )


                _7700323651e4._d1887ea22bc9({
                    "lang_codes": _738b589978eb,
                    "sample_id": _c48e26210f50,
                    "chunk_id": _0c738c36e2c1,
                    "word_positions": _412d9f5bb625,
                    "input_ids": _0dff3b1d2329,
                    "labels": _7d552721264b,
                    "prompt_len": _ce49eb55ca09,
                    "chunk_words": _e236dc97db6c,
                    "chunk_labels": _48123b71718f,
                    "num_chunks": 1
                })
                _0c738c36e2c1 += 1

                if _4f91941e5148 >= _8280d2a52fd6 or _4f91941e5148 <= _4b1605a05a45:
                    break
                _4b1605a05a45 = _4f91941e5148
                _63f2585bd669 = _c010b5cfe426(1, _885c44f476fc(_ff07c2fa61f9 * _67663aab9f54(_e236dc97db6c)))
                _8a6fac9fdb03 = _4f91941e5148 - _63f2585bd669 if (_4f91941e5148 - _63f2585bd669) > _8a6fac9fdb03 else _4f91941e5148

            _51956ce4faaa = _67663aab9f54(_7700323651e4)
            for _01e776eefd9d in _7700323651e4:
                _01e776eefd9d["num_chunks"] = _51956ce4faaa
            _d7f80ebe18be._67cb322b75a4(_7700323651e4)

            if not _b0c416bda489._ffec05c7fed1 and not _88fc0dafa83d and _51956ce4faaa > 1:
                _b0c416bda489._ffec05c7fed1 = _f0f6b05dcb22

        return _d7f80ebe18be, _43a1bf4ef550

    # -------------------------
    # File processing & validation
    # -------------------------
    def _c6be93708baf(self, _82d4318c363b: _9c0cd04f03f2, _71d5bbe5b9f5: _9c0cd04f03f2, _33eb60b392dc: _885c44f476fc) -> _807d03b0641f[_9c0cd04f03f2, _963d169bbd37[_1cb00d143b15], _885c44f476fc]:
        """
        Process a single pair of source and target files, chunk them and return:
         (lang_code, list_of_chunks, number_of_source_lines_processed)
        This method uses multiprocessing.dummy Pool to parallelize at the batch level.
        """
        _567d2c50b45c = []

        with _b1d33650bd86(_82d4318c363b, "r", _233a80116646="utf8") as _d9065dc33a34, _b1d33650bd86(_71d5bbe5b9f5, "r", _233a80116646="utf8") as _87715fa61994:
            _15a916424752 = _d9065dc33a34._443438091dbd()[1:] if self._3e77d66fdded else _d9065dc33a34._443438091dbd()
            _e27c3a3f5ee4 = _87715fa61994._443438091dbd()[1:] if self._3e77d66fdded else _87715fa61994._443438091dbd()

        # sample some share if requested
        _203966cbdca2 = _885c44f476fc(_67663aab9f54(_15a916424752) * self._14fbaef7e5b6)
        if _203966cbdca2 < _67663aab9f54(_15a916424752):
            _082cad2ec301 = _231ff69d0ba6._62be2c3a2de3._d962d6777439(_67663aab9f54(_15a916424752), _203966cbdca2, _9aac7bf530f0=_ad7e3de25951)
            _15a916424752 = [_15a916424752[_8a6fac9fdb03] for _8a6fac9fdb03 in _082cad2ec301]
            _e27c3a3f5ee4 = [_e27c3a3f5ee4[_8a6fac9fdb03] for _8a6fac9fdb03 in _082cad2ec301]

        _f2360d185638 = _fd1d3db814b4({_380508b149e2._21885d76d411() for _380508b149e2 in _e27c3a3f5ee4})[0] if _e27c3a3f5ee4 else "unk"
        self._d3b82e12b672._32ec1516af75(f"Sampled {self._14fbaef7e5b6 * 100:.1f}% of {_82d4318c363b}: {_67663aab9f54(_15a916424752)} lines")

        # helper: batch iterator to limit memory & parallelize tokenization/chunking
        def _7d49d0afb0d6(_fdc16906fbd9, _00fcd537cd5a):
            _0277d4ab4f96 = _20ea308216b4(_fdc16906fbd9)
            while _f0f6b05dcb22:
                _3ce52abd06d6 = _fd1d3db814b4(_d934a322a951(_0277d4ab4f96, _00fcd537cd5a))
                if not _3ce52abd06d6:
                    break
                yield _3ce52abd06d6

        _00fcd537cd5a = 10_000
        if self._f966cf7c8516:
            _839605391942 = [
                (self._5cf25e51dedf, _adb533ebdabb, _ff6d8970e07c, self._a98491020d3c, 0.25, self._88fc0dafa83d, _33eb60b392dc + _11853e749764 * _00fcd537cd5a)
                for _11853e749764, (_adb533ebdabb, _ff6d8970e07c) in _4d006df9481c(_828b7ca55a4e(_135a8e76b7af(_15a916424752, _00fcd537cd5a), _135a8e76b7af(_e27c3a3f5ee4, _00fcd537cd5a)))
            ]
            with _cd8b8c23988b(self._093d33839a22) as _f92f5a906a36:
                _c61a777ff008 = _f92f5a906a36._53fac5d40832(_b0c416bda489._7223863c55de, _839605391942)
        else:
            _839605391942 = [
                (_adb533ebdabb, _ff6d8970e07c, self._a98491020d3c, 0.5, self._e08a04b651de, _33eb60b392dc + _11853e749764 * _00fcd537cd5a)
                for _11853e749764, (_adb533ebdabb, _ff6d8970e07c) in _4d006df9481c(_828b7ca55a4e(_135a8e76b7af(_15a916424752, _00fcd537cd5a), _135a8e76b7af(_e27c3a3f5ee4, _00fcd537cd5a)))
            ]
            with _cd8b8c23988b(self._093d33839a22) as _f92f5a906a36:
                _c61a777ff008 = _f92f5a906a36._53fac5d40832(_b0c416bda489._afdcf08ac6af, _839605391942)

        _0b02a00f62f4 = []
        for _d7f80ebe18be, _42d6b8c7f66c in _c61a777ff008:
            _0b02a00f62f4._67cb322b75a4(_d7f80ebe18be)
            self._7533fd874ed4 += _42d6b8c7f66c

        if _0b02a00f62f4:
            _567d2c50b45c = _0b02a00f62f4

        return _f2360d185638, _567d2c50b45c, _67663aab9f54(_15a916424752)

    def _3a425b202d64(self) -> _b87227a133c3:
        """
        Discover language directories under `data_dir`, find matching src/tgt files,
        process them and append chunk results into self.file_data_dict_list.
        Performs validation such as file counts matching per-language and raises
        informative errors when mismatch detected.
        """
        _170a933a0f2c = 0

        for _2f9a0a9ea253 in _9f834920047e._97b89dc3a9f4(self._0c1d5e27091a):
            self._d3b82e12b672._32ec1516af75(f"Now processing {_9f834920047e._e4d5b4d9f73f._dea88d689be9(self._0c1d5e27091a, _2f9a0a9ea253)} directory.")
            _cc42129bcec8 = _9f834920047e._e4d5b4d9f73f._dea88d689be9(self._0c1d5e27091a, _2f9a0a9ea253, "src")
            _7785cfc992cc = _9f834920047e._e4d5b4d9f73f._dea88d689be9(self._0c1d5e27091a, _2f9a0a9ea253, "tgt")

            _4922b60586dc = []
            _ae571557b235 = []
            for _82d4318c363b in _9f834920047e._97b89dc3a9f4(_cc42129bcec8):
                _e8a4d71e0ed7 = _ad7e3de25951
                for _71d5bbe5b9f5 in _9f834920047e._97b89dc3a9f4(_7785cfc992cc):
                    if _82d4318c363b._64be617e355a(".")[0] == _71d5bbe5b9f5._64be617e355a(".")[0]:
                        _4922b60586dc._d1887ea22bc9(_82d4318c363b)
                        _ae571557b235._d1887ea22bc9(_71d5bbe5b9f5)
                        _e8a4d71e0ed7 = _f0f6b05dcb22
                        break
                if not _e8a4d71e0ed7:
                    self._d3b82e12b672._32ec1516af75(f"Skipping file {_82d4318c363b} since matching label file not found in {_7785cfc992cc}.")

            _ec40281a5f88 = [_9f834920047e._e4d5b4d9f73f._dea88d689be9(_cc42129bcec8, _a42f078351d9) for _a42f078351d9 in _4922b60586dc if _9f834920047e._e4d5b4d9f73f._33030a725047(_9f834920047e._e4d5b4d9f73f._dea88d689be9(_cc42129bcec8, _a42f078351d9))]
            _2447e3b1a79d = [_9f834920047e._e4d5b4d9f73f._dea88d689be9(_7785cfc992cc, _a42f078351d9) for _a42f078351d9 in _ae571557b235 if _9f834920047e._e4d5b4d9f73f._33030a725047(_9f834920047e._e4d5b4d9f73f._dea88d689be9(_7785cfc992cc, _a42f078351d9))]

            if _67663aab9f54(_ec40281a5f88) != _67663aab9f54(_2447e3b1a79d):
                raise _e944cf1ee5b4(f"Number of files in {_cc42129bcec8} ({_67663aab9f54(_ec40281a5f88)}) does not match {_7785cfc992cc} ({_67663aab9f54(_2447e3b1a79d)})")

            for _82d4318c363b, _71d5bbe5b9f5 in _828b7ca55a4e(_ec40281a5f88, _2447e3b1a79d):
                _6a0fe217c2b3 = _caadb64c9dcd(1 for _ in _b1d33650bd86(_82d4318c363b))
                _48169b01f0a2 = _caadb64c9dcd(1 for _ in _b1d33650bd86(_71d5bbe5b9f5))
                _6a0fe217c2b3 = _6a0fe217c2b3 - 1 if self._3e77d66fdded else _6a0fe217c2b3
                _48169b01f0a2 = _48169b01f0a2 - 1 if self._3e77d66fdded else _48169b01f0a2

                if _6a0fe217c2b3 != _48169b01f0a2:
                    self._d3b82e12b672._32ec1516af75(f"{_6a0fe217c2b3} lines in {_82d4318c363b} do not match with {_48169b01f0a2} in {_71d5bbe5b9f5}, skipping these files")
                    continue

                self._d3b82e12b672._32ec1516af75(f"Processing {_82d4318c363b} and {_71d5bbe5b9f5} with {_48169b01f0a2} samples.")
                _f2360d185638, _5ff190a2f681, _208c577ce2cc = self._92589120ad8b(_82d4318c363b, _71d5bbe5b9f5, _33eb60b392dc=_170a933a0f2c)
                _170a933a0f2c += _208c577ce2cc

                self._5ff190a2f681._67cb322b75a4(_5ff190a2f681)
                if self._e08a04b651de:
                    if _f2360d185638 not in self._4fb82953c16b:
                        self._4fb82953c16b._87ece3595c0a({
                            _f2360d185638: [{
                                "file_name": _9f834920047e._e4d5b4d9f73f._920e6e33221a(_71d5bbe5b9f5),
                                "samples_before_processing": _48169b01f0a2,
                                "samples_after_processing": _67663aab9f54(_5ff190a2f681)
                            }]
                        })
                    else:
                        self._4fb82953c16b[_f2360d185638]._d1887ea22bc9({
                            "file_name": _9f834920047e._e4d5b4d9f73f._920e6e33221a(_71d5bbe5b9f5),
                            "samples_before_processing": _48169b01f0a2,
                            "samples_after_processing": _67663aab9f54(_5ff190a2f681)
                        })
                if _f2360d185638 not in self._738b589978eb:
                    self._738b589978eb._d1887ea22bc9(_f2360d185638)
                self._d3b82e12b672._32ec1516af75(f"Files {_82d4318c363b} and {_71d5bbe5b9f5} have {_67663aab9f54(_5ff190a2f681)} samples after processing.")

        # verify dataset integrity
        self._295f1d74d57f()

    # -------------------------
    # Auditing & derived metrics
    # -------------------------
    def _27a35a39374f(self) -> _b87227a133c3:
        """
        Run a set of sanity checks on the processed `file_data_dict_list`.
        Raises ValueError when structural inconsistencies are detected.
        """
        _f8ebba608ea1 = self._5ff190a2f681
        if not _f8ebba608ea1:
            self._d3b82e12b672._32ec1516af75("No data passed to audit_dataset.")
            return

        # 1) sample_id coverage
        _2a4b437ee789 = [_c027e4e4ee54["sample_id"] for _c027e4e4ee54 in _f8ebba608ea1]
        _33e1bc36c670 = _eae51af13c69(_2a4b437ee789)
        _f36d9ce6b422 = _c010b5cfe426(_33e1bc36c670)
        _94d503f67c4c = (_67663aab9f54(_33e1bc36c670) == _f36d9ce6b422 + 1)
        self._d3b82e12b672._32ec1516af75(f"[sample_id] unique={_67663aab9f54(_33e1bc36c670)} max={_f36d9ce6b422} coverage_ok={_94d503f67c4c} (expect True)")
        if not _94d503f67c4c:
            _e28a1743456f = _a8eb9c63ea97(_eae51af13c69(_b133bf652dcc(_f36d9ce6b422 + 1)) - _33e1bc36c670)
            self._d3b82e12b672._32ec1516af75(f" Missing sample_ids: {_e28a1743456f[:20]}{' ...' if _67663aab9f54(_e28a1743456f) > 20 else ''}")
            raise _e944cf1ee5b4(f"Increase max_seq_len as missing sample_ids detected: {_e28a1743456f[:20]}{' ...' if _67663aab9f54(_e28a1743456f) > 20 else ''}")

        # 2) (sample_id, chunk_id) uniqueness
        _d9a8c6f359b2 = [(_c027e4e4ee54["sample_id"], _c027e4e4ee54["chunk_id"]) for _c027e4e4ee54 in _f8ebba608ea1]
        _4efd143a6d7d = [_0e35f8b41b89 for _0e35f8b41b89, _42a4ece89617 in _bcaa7995a731(_d9a8c6f359b2)._cc1f776fe8f4() if _42a4ece89617 > 1]
        self._d3b82e12b672._32ec1516af75(f"[(sample_id,chunk_id)] duplicates: {_67663aab9f54(_4efd143a6d7d)} (expect 0)")
        if _4efd143a6d7d:
            self._d3b82e12b672._32ec1516af75(f" Examples: {_4efd143a6d7d[:10]}")
            raise _e944cf1ee5b4(f"Duplicate (sample_id, chunk_id) pairs detected: {_4efd143a6d7d[:10]}")

        # 3) per-sample chunk_id sequentiality
        _d4c56cc653e7 = _b7f618578693(_fd1d3db814b4)
        for _c027e4e4ee54 in _f8ebba608ea1:
            _d4c56cc653e7[_c027e4e4ee54["sample_id"]]._d1887ea22bc9(_c027e4e4ee54["chunk_id"])
        _adabdccc4088 = {}
        for _bd5efa88c4a4, _8da1b16460b2 in _d4c56cc653e7._cc1f776fe8f4():
            _a94518b9cd9a = _a8eb9c63ea97(_8da1b16460b2)
            _cdd7d30668d8 = _fd1d3db814b4(_b133bf652dcc(_67663aab9f54(_a94518b9cd9a)))
            if _a94518b9cd9a != _cdd7d30668d8:
                _adabdccc4088[_bd5efa88c4a4] = {"have": _a94518b9cd9a[:20], "expected_prefix": _cdd7d30668d8[:20]}
        self._d3b82e12b672._32ec1516af75(f"[per-sample chunk_id sequence] bad_samples: {_67663aab9f54(_adabdccc4088)} (expect 0)")
        if _adabdccc4088:
            _b824f54cd2d3 = _fd1d3db814b4(_adabdccc4088._cc1f776fe8f4())[:5]
            for _bd5efa88c4a4, _32ec1516af75 in _b824f54cd2d3:
                self._d3b82e12b672._32ec1516af75(f" sample_id={_bd5efa88c4a4} have={_32ec1516af75['have']} expected_prefix={_32ec1516af75['expected_prefix']}")
            raise _e944cf1ee5b4(f"Non-sequential chunk_id sequences detected for sample_ids: {_fd1d3db814b4(_adabdccc4088._34940f895e39())[:5]}")

        # 4) overall stats reporting
        _a457cd24ca67 = _67663aab9f54(_33e1bc36c670)
        _4c0c2a59a8d5 = _67663aab9f54(_f8ebba608ea1)
        _38079d452742 = _4c0c2a59a8d5 / _a457cd24ca67 if _a457cd24ca67 > 0 else 0
        self._d3b82e12b672._32ec1516af75(f"[audit] base={_a457cd24ca67} -> chunks={_4c0c2a59a8d5} (avg {_38079d452742:.2f} per sample)")

    @_e9bcbe29973a
    def _1fe5b6938c9f(self) -> _885c44f476fc:
        """Return number of unique base samples (unique sample_id)."""
        if not _5e85482271b4(self, "file_data_dict_list", _b87227a133c3):
            return 0
        return _67663aab9f54({_885c44f476fc(_2c6113d20094["sample_id"]) for _2c6113d20094 in self._5ff190a2f681})

    @_e9bcbe29973a
    def _6b4ea2eb8f82(self) -> _885c44f476fc:
        """
        Total number of label tokens across unique samples, counting unique
        word_positions per sample to avoid double-counting overlapping windows.
        """
        if not _5e85482271b4(self, "file_data_dict_list", _b87227a133c3):
            return 0

        _b8ea86557e02 = _b7f618578693(_eae51af13c69)
        for _2c6113d20094 in self._5ff190a2f681:
            _bd5efa88c4a4 = _885c44f476fc(_2c6113d20094._df40f92b36f9("sample_id", -1))
            for _4a8c7581b24f in _2c6113d20094._df40f92b36f9("word_positions", []):
                try:
                    _53ffc996bfde = _885c44f476fc(_4a8c7581b24f)
                except _ac9e60ea6aea:
                    continue
                if _53ffc996bfde >= 0:
                    _b8ea86557e02[_bd5efa88c4a4]._a66f5a095057(_53ffc996bfde)

        return _caadb64c9dcd(_67663aab9f54(_23f3278d2a1b) for _23f3278d2a1b in _b8ea86557e02._2b4e23504549())
