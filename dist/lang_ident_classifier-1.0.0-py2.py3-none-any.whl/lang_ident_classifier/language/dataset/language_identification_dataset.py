# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : language_identification_dataset
# @Time             : 18/12/23 2:34 pm IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor, as_completed
import functools
from itertools import chain, islice
import json
import math
# from multiprocessing import Pool, cpu_count
from multiprocessing.dummy import Pool
import os
from difflib import SequenceMatcher
from logging import Logger
import pickle
import random
import re
import time
from typing import Any, List
import unicodedata
import numpy as np
import torch
from torch.utils.data import Dataset

class LanguageIdentificationDataset(Dataset):
    """
    contains methods for Dataset related operations
    """
    TOKENIZER = None  # Class-level tokenizer
    is_debug_sample_shown = False

    def __init__(self, data_dir: str, files_have_header: bool,
                 pretrained_embedding_tokenizer: Any, max_seq_length: int,
                 classes_config_path: str, log: Logger,
                 is_train: bool, 
                 is_test: bool,
                 sample_dataset_share: float = 1.0,
                 num_workers: int = 2,
                 random_seed: int = 20, is_gen_llm: bool = False, prompt_template = None):
        """
        initializes the class instance with default parameters
        :param data_dir: path of the data directory
        :param files_have__header: if True, indicates that
        files have header and will skip 1 line
        :param log: instance of a Logger object for logging
        """
        super(LanguageIdentificationDataset, self).__init__()
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        random.seed(random_seed)
        np.random.seed(random_seed)
        self.log = log
        self.is_train = is_train
        self.is_test = is_test
        self.is_gen_llm = is_gen_llm
        self.prompt_template = prompt_template
        self.files_have_header = files_have_header
        self.data_dir = data_dir
        self.max_seq_length = max_seq_length
        self.label_sample_counter = 0
        LanguageIdentificationDataset.TOKENIZER = pretrained_embedding_tokenizer
        self.tokenizer = pretrained_embedding_tokenizer
        if self.is_gen_llm:
            #TODO: REMOVE THIS HARDCODING
            if not self.tokenizer.pad_token_id:
                self.tokenizer.pad_token_id = 128004  # <|finetune_right_pad_id|> 
        # self.ignore_index = -100 if is_gen_llm else self.tokenizer.pad_token_id
        self.ignore_index = -100
        self.src_data = []
        self.attn_data = []
        self.tgt_data = []
        self.file_data_dict_list = []
        self.file_stats = {}
        self.sample_dataset_share = sample_dataset_share
        self.num_workers = num_workers
        self._validate_and_load_file_data()
        # self.validate_windowing_samples()
        self.classes, self.class_weights = self._get_classes_dict(classes_config_path, is_train)

    def __len__(self):
        """
        method to obtain number of samples in the dataset
        :return: length of the dataset
        """
        return len(self.file_data_dict_list)

    def _get_class_id_from_lang_code(self, lang_code):
        for lang_id, lang_info in self.classes.items():
            if lang_info["lang_code"] == lang_code.strip():
                return lang_id
        # using fallback option as -1 otherwise code breaks 
        # but id is 0 for unk if decision threshold is used and 
        # this works for both cases
        return self.classes.get("unk", {}).get("id", -1)

    def _get_lang_code_from_class_id(self, class_id):
        return self.classes[class_id]["lang_code"]

    def get_num_classes(self):
        return len(self.classes)

    def _add_languages(self, lang_code_dict):
        LANG_RE = re.compile(r"[^\d\s]+")  # match non-digit tokens
        counter = Counter()
        file_sample_counts = {}  # store sample counts per language file

        # In-memory processing
        if self.is_gen_llm:
            valid_batches = []
            for entry in self.file_data_dict_list:
                if isinstance(entry, dict):
                    labels = entry.get("labels", [])
                elif isinstance(entry, tuple) and len(entry) > 1:
                    # assume (input_ids, labels)
                    labels = entry[1]
                else:
                    labels = []
                valid_ids = [l for l in labels if l != self.ignore_index]
                if valid_ids:
                    valid_batches.append(valid_ids)
            if valid_batches:
                decoded_texts = self.tokenizer.batch_decode(valid_batches, skip_special_tokens=True)
                for detok_str in decoded_texts:
                    langs = LANG_RE.findall(detok_str)
                    counter.update(langs)
        else:
            for entry in self.file_data_dict_list:
                labels = entry.get("labels", [])
                langs = [lbl.strip() for lbl in labels if isinstance(lbl, str) and LANG_RE.match(lbl)]
                counter.update(langs)

        # Build lang_code_dict efficiently
        existing_langs = {v['lang_code']: k for k, v in lang_code_dict.items()}

        # Remove UNK from dict
        # if "unk" not in existing_langs:
        #     new_id = len(lang_code_dict)
        #     lang_code_dict[new_id] = {"lang_code": "unk", "lang_samples": 0, "lang_files": []}
        #     existing_langs["unk"] = new_id

        for lang, count in counter.items():
            lang = lang.strip()
            # get all files for this language
            file_list = self.file_stats.get(lang, [])
            total_samples = sum(f.get("samples_after_processing", 0) for f in file_list)
            if lang in existing_langs:
                idx = existing_langs[lang]
                # existing = lang_code_dict[idx]
                # lang_code_dict[idx] = {
                #     "lang_code": lang,
                #     "lang_samples": existing["lang_samples"] + total_samples,
                #     "lang_files": list(set(existing["lang_files"] + file_list))
                # }
                existing = lang_code_dict[idx]
                combined_files = existing["lang_files"] + file_list
                lang_files = list({f["file_name"]: f for f in combined_files}.values())
                lang_code_dict[idx] = {
                    "lang_code": lang,
                    "lang_samples": existing["lang_samples"] + total_samples,
                    "lang_files": lang_files
                }
            else:
                new_id = len(lang_code_dict)
                lang_code_dict[new_id] = {
                    "lang_code": lang,
                    "lang_samples": total_samples,
                    "lang_files": file_list
                }
                existing_langs[lang] = new_id

        return lang_code_dict
  
    def _normalize_class_weights(self, weights):
        total_weight = np.sum(weights)
        normalized_weights = weights / total_weight
        return normalized_weights

    def _get_class_weights(self, classes_dict):
        # Calculate class weights based on lang_samples
        total_samples = sum(entry['lang_samples'] for entry in classes_dict.values())

        class_weights = {}
        for lang_code, lang_data in classes_dict.items():
            class_samples = lang_data['lang_samples']
            if class_samples > 0:
                # weights are inversely proportional to number of samples
                class_weight = total_samples / (class_samples * len(classes_dict))
            else:
                class_weight = 0  # Set weight to 0 if there are no samples
            classes_dict[lang_code].update({"lang_weight":class_weight})
        class_weights = [entry['lang_weight'] for entry in classes_dict.values()]
        # class_weights = self._normalize_class_weights(class_weights)
        # Update the lang_weights with normalized class weights
        for i, (lang_code, lang_data) in enumerate(classes_dict.items()):
            lang_data["lang_weight"] = class_weights[i]
        return class_weights, classes_dict

    def _get_classes_dict(self, classes_config_path, is_train):
            classes_dict = {}
            class_weights = {}
            if os.path.exists(classes_config_path):
                with open(classes_config_path, mode='r+', encoding='utf8') as ccp:
                    # classes_dict = json.load(ccp)
                    raw_dict = json.load(ccp)  # Load JSON normally (keys are strings)
        
                    classes_dict = {
                        float(k) if "." in k else int(k): v  # Convert only top-level keys
                        for k, v in raw_dict.items()
                    }

            if is_train:
                classes_dict = self._add_languages(lang_code_dict=classes_dict)
                class_weights, classes_dict = self._get_class_weights(classes_dict=classes_dict)

                with open(classes_config_path, mode='w+', encoding='utf8') as ccp_w:
                    json.dump(classes_dict, ccp_w, indent=2)

            return classes_dict, class_weights
    
    def get_labels(self):
        return [self._get_class_id_from_lang_code(lang_code) for lang_code in self.tgt_data]

    def __getitem__(self, idx):
        sample = self.file_data_dict_list[idx]
        lang_code = sample.get('lang_code', 'unk')
        input_ids = sample['input_ids']
        target_data = sample['labels']
        num_chunks = sample['num_chunks']
        sample_id = sample.get('sample_id', idx)
        chunk_id = sample.get('chunk_id', 0)
        word_positions = sample.get('word_positions', [])
        prompt_len = sample.get('prompt_len', 0)

        # Replace None in target_data with self.ignore_index
        target_data = [
            self.ignore_index if t is None
            else int(t) if isinstance(t, str) and t.lstrip('-').isdigit()
            else t
            for t in target_data
        ]

        # Show only the *first* sample in val and test mode
        # if not hasattr(self, "_has_logged_sample"):
        #     self._has_logged_sample = {"val": False, "test": False}

        # if not self.is_train and not self._has_logged_sample["test"] and idx == 0:
        #     print(f"[TEST] Sample idx=0\nInput IDs: {input_ids}\nTarget: {target_data}")
        #     self._has_logged_sample["test"] = True
        # elif self.is_train is False and not self._has_logged_sample["val"] and idx == 0:
        #     print(f"[VAL] Sample idx=0\nInput IDs: {input_ids}\nTarget: {target_data}")
        #     self._has_logged_sample["val"] = True

        # Now apply class ID mapping
        if not self.is_gen_llm:
            target_ids = [
                self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
                for t in target_data
            ]
            # tokenizer.pad_token_id
            max_len = self.max_seq_length
            seq_len = len(target_ids)

            padding_length = max_len - seq_len
            # For classification per token, repeat target_id; or return single class label
            target_ids = target_ids + [self.ignore_index] * padding_length  # -100 to ignore loss on pad
        else:
            # gen llm only (already padded + masked in process_batch_gen_llm)
            target_ids = target_data

        # target_ids = [
        #         self._get_class_id_from_lang_code(t) if isinstance(t, str) else t
        #         for t in target_data
        #     ]
        # # Safety check for tokenizer.pad_token_id
        # pad_token_id = self.tokenizer.pad_token_id
        # if pad_token_id is None:
        #     pad_token_id = self.tokenizer.eos_token_id  # fallback
        #     self.tokenizer.pad_token = self.tokenizer.eos_token  # ensure consistency

        # max_len = self.max_seq_length
        # seq_len = len(target_ids)

        # padding_length = max_len - seq_len
        # # For classification per token, repeat target_id; or return single class label
        # target_ids = target_ids + [-100] * padding_length  # -100 to ignore loss on pad

        return {
            "lang_code": lang_code,
            "input_ids": torch.tensor(input_ids, dtype=torch.long),
            "labels": torch.tensor(target_ids, dtype=torch.long),
            "sample_id": sample_id,
            "chunk_id": chunk_id,
            "word_positions": word_positions,
            "prompt_len": prompt_len,
            "num_chunks": num_chunks,
        }
    
    def _similar_name(self, name_1: str, name_2: str) -> float:
        """
        takes two filenames, compares and returns the match score
        :param name_1: file name of file 1
        :param name_2: file name of file 2
        :return: match score
        """
        return SequenceMatcher(None, name_1, name_2).ratio()

    # Function to calculate overlap length based on percentage
    def _calculate_overlap(self, overlap_percentage):
        return int(self.max_seq_length * overlap_percentage)
    
    @staticmethod
    def _split_into_token_windows(tokens, max_len, overlap_ratio=0.5):
        step = int(max_len * (1 - overlap_ratio))
        if step < 1: step = 1
        return [tokens[i:i + max_len] for i in range(0, len(tokens), step)]

    @staticmethod
    def tokenize_words_fast(text: str, tokenizer, add_special_tokens=True) -> List[List[int]]:
        """
        Tokenize text into per-word token IDs using a stateless encoder_ function.
        Assumes encoder_ is a callable configured with is_split_into_words=True.
        """
        words = text.split()
        encodings = tokenizer(words, is_split_into_words=True, add_special_tokens=add_special_tokens)  # encoder_ must be a lightweight tokenizer function

        word_ids = encodings.word_ids()
        input_ids = encodings.input_ids

        grouped_tokens = []
        current_word = -1
        current_tokens = []

        for token_id, word_id in zip(input_ids, word_ids):
            if word_id is None:
                continue
            if word_id != current_word:
                if current_tokens:
                    grouped_tokens.append(current_tokens)
                current_tokens = [token_id]
                current_word = word_id
            else:
                current_tokens.append(token_id)
        if current_tokens:
            grouped_tokens.append(current_tokens)

        return grouped_tokens

    @staticmethod
    def _is_arabic(text):
        for char in text:
            if 'ARABIC' not in unicodedata.name(char, ''):
                return False
        return True

    @staticmethod
    def _reverse_arabic_sentence(sentence):
        if LanguageIdentificationDataset._is_arabic(sentence):
            # If the sentence is in Arabic script, reverse it
            # reversed_sentence = sentence[::-1]
            # Step 1: Split the sentence into words
            words = sentence.strip().split()

            # Step 2: Reverse the order of words (keeping characters in place)
            reversed_sentence = " ".join(reversed(words))
            # reversed_sentence = sentence
            return reversed_sentence
        else:
            return sentence
    
    @staticmethod
    def _is_english_string(input_string):
        # Function to check if a character is part of the English alphabet
        def is_english_char(char):
            return 'a' <= char.lower() <= 'z'

        # Convert the string to a list of characters
        characters = list(input_string)

        # Count the English alphabet characters
        english_chars_count = sum(1 for char in characters if is_english_char(char))

        # Calculate the percentage of English alphabet characters
        percentage_english = english_chars_count / len(characters)

        # Check if more than 50% of characters are from the English alphabet
        return percentage_english > 0.5
    
    # def audit_dataset(self):
    #     """
    #     chunks: list of dicts from process_batch_classifier() or process_batch_gen_llm_classifier()
    #     Checks:
    #     1) sample_id uniqueness & coverage (0..max without gaps)
    #     2) (sample_id, chunk_id) uniqueness
    #     3) per-sample chunk_id sequence is 0..(#chunks-1)
    #     4) base vs. chunk summary
    #     """
    #     chunks = self.file_data_dict_list
    #     if not chunks:
    #         self.log.info("No data passed to audit_dataset.")
    #         return

    #     # 1) sample_id coverage
    #     sids = [c["sample_id"] for c in chunks]
    #     uniq = set(sids)
    #     max_sid = max(uniq)
    #     ok_coverage = (len(uniq) == max_sid + 1)
    #     self.log.info(
    #         f"[sample_id] unique={len(uniq)} max={max_sid} "
    #         f"coverage_ok={ok_coverage} (expect True)"
    #     )
    #     if not ok_coverage:
    #         missing = sorted(set(range(max_sid + 1)) - uniq)
    #         self.log.info(
    #             f"  Missing sample_ids: {missing[:20]}{' ...' if len(missing) > 20 else ''}"
    #         )

    #     # 2) (sample_id, chunk_id) uniqueness
    #     pairs = [(c["sample_id"], c["chunk_id"]) for c in chunks]
    #     dup_pairs = [k for k, v in Counter(pairs).items() if v > 1]
    #     self.log.info(f"[(sample_id,chunk_id)] duplicates: {len(dup_pairs)} (expect 0)")
    #     if dup_pairs:
    #         self.log.info(f"  Examples: {dup_pairs[:10]}")

    #     # 3) per-sample chunk_id sequence
    #     per = defaultdict(list)
    #     for c in chunks:
    #         per[c["sample_id"]].append(c["chunk_id"])
    #     bad = {}
    #     for sid, ids in per.items():
    #         ids_sorted = sorted(ids)
    #         expected = list(range(len(ids_sorted)))
    #         if ids_sorted != expected:
    #             bad[sid] = {"have": ids_sorted[:20], "expected_prefix": expected[:20]}
    #     self.log.info(f"[per-sample chunk_id sequence] bad_samples: {len(bad)} (expect 0)")
    #     if bad:
    #         some = list(bad.items())[:5]
    #         for sid, info in some:
    #             self.log.info(
    #                 f"  sample_id={sid} have={info['have']} expected_prefix={info['expected_prefix']}"
    #             )

    #     # 4) base vs chunk summary
    #     base_count = len(uniq)
    #     chunk_count = len(chunks)
    #     avg_chunks = chunk_count / base_count if base_count > 0 else 0
    #     self.log.info(
    #         f"[audit] base={base_count} -> chunks={chunk_count} "
    #         f"(avg {avg_chunks:.2f} per sample)"
    #     )

    def audit_dataset(self):
        """
        chunks: list of dicts from process_batch_classifier() or process_batch_gen_llm_classifier()
        Checks:
        1) sample_id uniqueness & coverage (0..max without gaps)
        2) (sample_id, chunk_id) uniqueness
        3) per-sample chunk_id sequence is 0..(#chunks-1)
        4) base vs. chunk summary
        """
        chunks = self.file_data_dict_list
        if not chunks:
            self.log.info("No data passed to audit_dataset.")
            return
        # 1) sample_id coverage
        sids = [c["sample_id"] for c in chunks]
        uniq = set(sids)
        max_sid = max(uniq)
        ok_coverage = (len(uniq) == max_sid + 1)
        self.log.info(
            f"[sample_id] unique={len(uniq)} max={max_sid} "
            f"coverage_ok={ok_coverage} (expect True)"
        )
        if not ok_coverage:
            missing = sorted(set(range(max_sid + 1)) - uniq)
            self.log.info(
                f" Missing sample_ids: {missing[:20]}{' ...' if len(missing) > 20 else ''}"
            )
            raise ValueError(f"Increase max_seq_len as missing sample_ids detected: {missing[:20]}{' ...' if len(missing) > 20 else ''}")
        # 2) (sample_id, chunk_id) uniqueness
        pairs = [(c["sample_id"], c["chunk_id"]) for c in chunks]
        dup_pairs = [k for k, v in Counter(pairs).items() if v > 1]
        self.log.info(f"[(sample_id,chunk_id)] duplicates: {len(dup_pairs)} (expect 0)")
        if dup_pairs:
            self.log.info(f" Examples: {dup_pairs[:10]}")
            raise ValueError(f"Duplicate (sample_id, chunk_id) pairs detected: {dup_pairs[:10]}")
        # 3) per-sample chunk_id sequence
        per = defaultdict(list)
        for c in chunks:
            per[c["sample_id"]].append(c["chunk_id"])
        bad = {}
        for sid, ids in per.items():
            ids_sorted = sorted(ids)
            expected = list(range(len(ids_sorted)))
            if ids_sorted != expected:
                bad[sid] = {"have": ids_sorted[:20], "expected_prefix": expected[:20]}
        self.log.info(f"[per-sample chunk_id sequence] bad_samples: {len(bad)} (expect 0)")
        if bad:
            some = list(bad.items())[:5]
            for sid, info in some:
                self.log.info(
                    f" sample_id={sid} have={info['have']} expected_prefix={info['expected_prefix']}"
                )
            raise ValueError(f"Non-sequential chunk_id sequences detected for sample_ids: {list(bad.keys())[:5]}")
        # 4) base vs chunk summary
        base_count = len(uniq)
        chunk_count = len(chunks)
        avg_chunks = chunk_count / base_count if base_count > 0 else 0
        self.log.info(
            f"[audit] base={base_count} -> chunks={chunk_count} "
            f"(avg {avg_chunks:.2f} per sample)"
        )

    # @staticmethod
    # def process_batch_classifier(args):
    #     src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train, start_sample_id = args
    #     tokenizer = LanguageIdentificationDataset.TOKENIZER
    #     local_label_counter = 0
    #     pad_id = tokenizer.pad_token_id

    #     results = []

    #     for line_idx, (src, tgt) in enumerate(zip(src_lines, tgt_lines)):
    #         sample_id = start_sample_id + line_idx

    #         src_words = src.strip().split()
    #         tgt_labels = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # align targets
    #         if len(tgt_labels) == 1:
    #             src_word_labels = [tgt_labels[0]] * len(src_words)
    #         elif len(tgt_labels) == len(src_words):
    #             src_word_labels = tgt_labels
    #         else:
    #         #     # skip misaligned pair
    #         #     continue
    #             # Handle misaligned pairs by padding or truncating tgt_words
    #             src_word_labels = tgt_labels[:len(src_words)] if len(tgt_labels) > len(src_words) else tgt_labels + [tgt_labels[-1]] * (len(src_words) - len(tgt_labels))

    #         #Incorrect counter
    #         # local_label_counter += len(src_word_labels)
            
    #         # tokenize each word separately
    #         tokenized = tokenizer(
    #             src_words,
    #             add_special_tokens=False,
    #             return_attention_mask=False,
    #             return_token_type_ids=False,
    #         )
    #         word_token_info = [
    #             (idx, ids, len(ids))
    #             for idx, (ids) in enumerate(tokenized["input_ids"])
    #         ]

    #         i = 0
    #         n = len(word_token_info)
    #         chunk_id = 0

    #         while i < n:
    #             total_len = 0
    #             chunk_ids, chunk_labels, word_positions = [], [], []

    #             j = i
    #             while j < n:
    #                 widx, ids, L = word_token_info[j]
    #                 tgt_label = src_word_labels[widx]

    #                 # if word alone is longer than max_seq_len, put it in its own chunk
    #                 if L > max_seq_len and not chunk_ids:
    #                     chunk_ids.extend(ids)
    #                     chunk_labels.append(tgt_label)
    #                     word_positions.append(widx)
    #                     j += 1
    #                     break

    #                 # normal packing
    #                 if total_len + L > max_seq_len and chunk_ids:
    #                     break

    #                 chunk_ids.extend(ids)
    #                 chunk_labels.append(tgt_label)
    #                 local_label_counter += 1
    #                 word_positions.append(j)   # j is the word’s global index in the sentence
    #                 total_len += L
    #                 j += 1
    #             # pad at the end if needed
    #             if len(chunk_ids) < max_seq_len:
    #                 chunk_ids = chunk_ids + [pad_id] * (max_seq_len - len(chunk_ids))

    #             results.append({
    #                 "sample_id": sample_id,
    #                 "chunk_id": chunk_id,
    #                 "input_ids": chunk_ids,
    #                 "labels": chunk_labels,
    #                 "word_positions": word_positions,
    #             })
    #             chunk_id += 1

    #             # stop if we already reached the end of the sentence
    #             if j >= n:
    #                 break

    #             # stride with overlap
    #             chunk_size = len(word_positions)
    #             overlap = int(overlap_ratio * chunk_size)
    #             overlap = min(overlap, chunk_size - 1) if chunk_size > 1 else 0
    #             next_i = j - overlap
    #             if next_i <= i:
    #                 next_i = i + 1
    #             i = next_i

    #         #updating num chunks 
    #         # for r in results: r["num_chunks"] = sum(1 for x in results if x["sample_id"] == r["sample_id"])
    #         num_chunks_per_sample = {}
    #         for r in results:
    #             sid = r["sample_id"]
    #             num_chunks_per_sample[sid] = num_chunks_per_sample.get(sid, 0) + 1
    #         for r in results:
    #             r["num_chunks"] = num_chunks_per_sample[r["sample_id"]]

    #         # DEBUG: show if >1 chunks produced
    #         # if not LanguageIdentificationDataset.is_debug_sample_shown and not is_train and chunk_id > 1:
    #         #     print(f"[DEBUG] sample_id={sample_id}", flush=True)
    #         #     print("  src_words :", src_words, flush=True)
    #         #     print("  tgt_labels:", src_word_labels, flush=True)
    #         #     print(f"  produced {chunk_id} chunks:", flush=True)
    #         #     for r in results[-chunk_id:]:
    #         #         words_in_chunk = [src_words[pos] for pos in r["word_positions"]]
    #         #         print(f"    chunk_id={r['chunk_id']} words={words_in_chunk} labels={src_word_labels}", flush=True)
    #         #     LanguageIdentificationDataset.is_debug_sample_shown = True


    #     return results, local_label_counter

    @staticmethod
    def process_batch_classifier(args):
        import time
        start_time = time.time()
        src_lines, tgt_lines, max_seq_len, overlap_ratio, is_train, start_sample_id = args
        tokenizer = LanguageIdentificationDataset.TOKENIZER
        local_label_counter = 0
        pad_id = tokenizer.pad_token_id
        results = []
        src_texts = [src.strip() for src in src_lines]
        tgt_texts = [tgt.strip() for tgt in tgt_lines]
        src_words_list = [text.split() if text else ["<empty>"] for text in src_texts]
        tgt_labels_list = []
        for src_words, tgt in zip(src_words_list, tgt_lines):
            tgt_labels = tgt if isinstance(tgt, list) else (tgt.strip().split() if tgt.strip() else ["<empty>"])
            if len(tgt_labels) == 1:
                tgt_labels = [tgt_labels[0]] * len(src_words)
            elif len(tgt_labels) != len(src_words):
                tgt_labels = tgt_labels[:len(src_words)] if len(tgt_labels) > len(src_words) else tgt_labels + [tgt_labels[-1]] * (len(src_words) - len(tgt_labels))
            tgt_labels_list.append(tgt_labels)
        all_src_words = list(chain(*src_words_list))
        tok_start = time.time()
        try:
            tokenized = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False, return_token_type_ids=False)
        except Exception as e:
            print(f"Tokenization error: {e}")
            tokenized = {"input_ids": [[0] for _ in all_src_words]}
        print(f"Tokenization took {time.time() - tok_start:.2f}s")
        src_idx = 0
        src_word_token_info_list = []
        for src_words in src_words_list:
            src_len = len(src_words)
            src_info = [(i, tokenized["input_ids"][src_idx + i], len(tokenized["input_ids"][src_idx + i])) for i in range(src_len)]
            src_word_token_info_list.append(src_info)
            src_idx += src_len
        for line_idx, (src_words, src_word_token_info, tgt_labels) in enumerate(zip(src_words_list, src_word_token_info_list, tgt_labels_list)):
            sample_id = start_sample_id + line_idx
            chunk_id = 0
            if src_words == ["<empty>"]:
                input_ids = [0] * max_seq_len
                results.append({
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "input_ids": input_ids,
                    "labels": ["<empty>"],
                    "word_positions": [0],
                    "num_chunks": 1
                })
                continue
            i = 0
            n = len(src_word_token_info)
            prev_j = -1
            chunk_results = []
            chunk_start = time.time()
            while i < n:
                total_len = 0
                chunk_ids = []
                chunk_labels = []
                word_positions = []
                j = i
                while j < n:
                    word_idx, ids, L = src_word_token_info[j]
                    tgt_label = tgt_labels[word_idx] if word_idx < len(tgt_labels) else tgt_labels[-1] if tgt_labels else "<unknown>"
                    if L > max_seq_len and not chunk_ids:
                        chunk_ids += ids[:max_seq_len]
                        chunk_labels.append(tgt_label)
                        word_positions.append(word_idx)
                        j += 1
                        break
                    if total_len + L > max_seq_len and chunk_ids:
                        break
                    chunk_ids += ids
                    chunk_labels.append(tgt_label)
                    local_label_counter += 1
                    word_positions.append(j)
                    total_len += L
                    j += 1
                if not chunk_ids:
                    chunk_ids = src_word_token_info[i][1][:max_seq_len] or [0]
                    chunk_labels = [tgt_labels[i] if i < len(tgt_labels) else tgt_labels[-1] if tgt_labels else "<unknown>"]
                    word_positions = [i]
                    local_label_counter += 1
                    i += 1
                if len(chunk_ids) < max_seq_len:
                    chunk_ids += [pad_id] * (max_seq_len - len(chunk_ids))
                chunk_results.append({
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "input_ids": chunk_ids,
                    "labels": chunk_labels,
                    "word_positions": word_positions,
                    "num_chunks": 1
                })
                chunk_id += 1
                if j >= n:
                    break
                chunk_size = len(word_positions)
                overlap = int(overlap_ratio * chunk_size)
                overlap = min(overlap, chunk_size - 1) if chunk_size > 1 else 0
                next_i = j - overlap
                if next_i <= i:
                    next_i = i + 1
                i = next_i
            print(f"Chunking took {time.time() - chunk_start:.2f}s for {chunk_id} chunks")
            num_chunks = len(chunk_results)
            for r in chunk_results:
                r["num_chunks"] = num_chunks
            results.extend(chunk_results)
            if not LanguageIdentificationDataset.is_debug_sample_shown and not is_train and num_chunks > 1:
                print(f"[DEBUG] sample_id={sample_id}", flush=True)
                print(" src_words :", src_words, flush=True)
                print(" tgt_labels:", tgt_labels, flush=True)
                print(f" produced {num_chunks} chunks:", flush=True)
                for r in chunk_results:
                    words_in_chunk = [src_words[pos] for pos in r["word_positions"] if pos < len(src_words)]
                    print(f" chunk_id={r['chunk_id']} words={words_in_chunk} labels={r['labels']}", flush=True)
                LanguageIdentificationDataset.is_debug_sample_shown = True
        print(f"Processed batch in {time.time() - start_time:.2f}s: {len(results)} samples")
        return results, local_label_counter

    # @staticmethod
    # def process_batch_gen_llm_classifier(args):
    #     """
    #     Spec:
    #     - Insert ONE literal space between words in BOTH input and label streams
    #     (no trailing space after the last word of a chunk).
    #     - word_positions: one entry PER LABEL TOKEN of a word (= its word index j),
    #     plus -1 entries for EACH space token inserted between label words.
    #     - Overlap computed in WORDS (not tokens).
    #     - Preserve original fields.
    #     """
    #     (prompt_template, src_lines, tgt_lines,
    #     max_seq_len, overlap_ratio, is_train, start_sample_id) = args
    #     local_label_counter = 0

    #     tokenizer = LanguageIdentificationDataset.TOKENIZER

    #     pad_id       = tokenizer.pad_token_id or tokenizer.eos_token_id
    #     eos_id       = tokenizer.eos_token_id
    #     ignore_index = -100

    #     # Chat template headers
    #     input_prefix    = "\n<|start_header_id|>user<|end_header_id|>\n"
    #     response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"

    #     # Pre-encode fixed parts
    #     instruction_ids     = tokenizer.encode(prompt_template, add_special_tokens=False)
    #     input_prefix_ids    = tokenizer.encode(input_prefix,  add_special_tokens=False)
    #     response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
    #     space_ids           = tokenizer.encode(" ", add_special_tokens=False)   # e.g., Llama3 → [220]

    #     prefix    = instruction_ids + input_prefix_ids
    #     suffix    = response_prefix_ids
    #     eos_len   = 1  # for eos_id
    #     fixed_len = len(prefix) + len(suffix) + eos_len

    #     results = []

    #     # for line_idx, (src, tgt) in enumerate(zip(src_lines, tgt_lines)):
    #     for line_idx, src in enumerate(src_lines):
    #         tgt = tgt_lines[line_idx] if tgt_lines else None

    #         sample_id = start_sample_id + line_idx
    #         chunk_id = 0

    #         src_words = src.strip().split()
    #         tgt_words = tgt if isinstance(tgt, list) else tgt.strip().split()

    #         # word-level alignment
    #         if len(tgt_words) == 1:
    #             src_word_labels = [tgt_words[0]] * len(src_words)
    #         elif len(tgt_words) == len(src_words):
    #             src_word_labels = tgt_words
    #         else:
    #         #     # skip misaligned pair
    #         #     continue
    #             # Handle misaligned pairs by padding or truncating tgt_words
    #             src_word_labels = tgt_words[:len(src_words)] if len(tgt_words) > len(src_words) else tgt_words + [tgt_words[-1]] * (len(src_words) - len(tgt_words))
            
    #         # wrong location this will count non chunked
    #         # local_label_counter += len(src_word_labels)

    #         # tokenize source and label words separately
    #         tok_src = tokenizer(src_words, add_special_tokens=False, return_attention_mask=False)
    #         tok_tgt = tokenizer(src_word_labels, add_special_tokens=False, return_attention_mask=False)

    #         src_word_token_info = [(w, ids, len(ids)) for w, ids in zip(src_words, tok_src["input_ids"])]
    #         tgt_word_token_info = [(w, ids, len(ids)) for w, ids in zip(src_word_labels, tok_tgt["input_ids"])]

    #         i = 0
    #         n = len(src_word_token_info)
    #         prev_j = -1

    #         while i < n:
    #             # accumulators for one chunk
    #             total_len = fixed_len
    #             chunk_input_tokens = []   # flattened later
    #             chunk_label_tokens = []   # flattened later
    #             word_positions     = []   # per LABEL token (+ -1 for label-space)
    #             chunk_words  = []
    #             chunk_labels = []
    #             lang_codes   = []

    #             j = i
    #             while j < n:
    #                 _, src_ids, src_len = src_word_token_info[j]
    #                 tgt_word, tgt_ids, tgt_len = tgt_word_token_info[j]

    #                 # include spaces ONLY between words inside the chunk (not after the last in chunk)
    #                 inter_word_spaces = len(space_ids) if j < n - 1 else 0

    #                 # amount added if we include this word now (both streams)
    #                 word_total = src_len + tgt_len + (2 * inter_word_spaces)

    #                 if total_len + word_total > max_seq_len:
    #                     break  # finalize current chunk

    #                 # ----- INPUT stream: append word, and a single space if NOT last word in chunk -----
    #                 chunk_input_tokens.extend(src_ids)
    #                 if inter_word_spaces:
    #                     chunk_input_tokens.extend(space_ids)

    #                 # ----- LABEL stream: per-label-token positions (j), then -1 for the inter-word space -----
    #                 if tgt_len:
    #                     chunk_label_tokens.extend(tgt_ids)
    #                     word_positions.extend([j] * tgt_len)
    #                 if inter_word_spaces:
    #                     chunk_label_tokens.extend(space_ids)
    #                     word_positions.extend([-1] * inter_word_spaces)

    #                 # metadata/debug
    #                 local_label_counter += len(src_words[j])
    #                 chunk_words.append(src_words[j])
    #                 chunk_labels.append(tgt_word)
    #                 lang_codes.append(tgt_word)

    #                 total_len += word_total
    #                 j += 1

    #             if not chunk_input_tokens:
    #                 # cannot fit even a single word: advance by one to avoid infinite loop
    #                 i += 1
    #                 continue

    #             flat_input_ids = chunk_input_tokens
    #             flat_label_ids = chunk_label_tokens

    #             # full packed sequence: [prefix] + input + [suffix] + label + [eos]
    #             # input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #             # labels = (
    #             #     [ignore_index] * (len(prefix) + len(flat_input_ids) + len(suffix))
    #             #     + flat_label_ids
    #             #     + [ignore_index]
    #             # )
    #             # full packed sequence
    #             # compute prompt length BEFORE adding eos/labels
    #             prompt_len = len(prefix) + len(flat_input_ids) + len(suffix)

    #             if is_train and tgt is not None:
    #                 # training with labels
    #                 input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #                 labels    = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             elif not is_train and tgt is not None:
    #                 # eval with labels (same construction as train, no backprop)
    #                 input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
    #                 labels    = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]

    #             else:
    #                 # inference: no tgt available
    #                 input_ids = prefix + flat_input_ids + suffix + [eos_id]
    #                 labels    = [ignore_index] * len(input_ids)

    #             # right-pad
    #             pad_len = max_seq_len - len(input_ids)
    #             if pad_len > 0:
    #                 input_ids += [pad_id] * pad_len
    #                 labels    += [ignore_index] * pad_len

    #             results.append({
    #                 "lang_codes":     lang_codes,
    #                 "sample_id":      sample_id,
    #                 "chunk_id":       chunk_id,
    #                 "word_positions": word_positions.copy(),  # per LABEL token (+ -1 for label spaces)
    #                 "input_ids":      input_ids,
    #                 "labels":         labels,
    #                 # "src_words":      chunk_words,   # for debug
    #                 # "tgt_words":      chunk_labels,  # for debug
    #                 "prompt_len":     prompt_len,  # <--- new
    #             })

    #             chunk_id += 1

    #             if j >= n or j <= prev_j:
    #                 break  # safety
    #             prev_j = j

    #             # ---- overlap IN WORDS (not tokens) ----
    #             overlap_words = max(1, int(overlap_ratio * len(chunk_words)))
    #             i = j - overlap_words if (j - overlap_words) > i else j

    #         #num chunks 
    #         # for r in results: r["num_chunks"] = sum(1 for x in results if x["sample_id"] == r["sample_id"])
    #         num_chunks_per_sample = {}
    #         for r in results:
    #             sid = r["sample_id"]
    #             num_chunks_per_sample[sid] = num_chunks_per_sample.get(sid, 0) + 1
    #         for r in results:
    #             r["num_chunks"] = num_chunks_per_sample[r["sample_id"]]

    #         # ---- optional debug (end-only) ----
    #         # if not LanguageIdentificationDataset.is_debug_sample_shown and not is_train and chunk_id > 1:
    #         #     print(f"\n[DEBUG] sample_id={sample_id} from {chunk_id} chunks", flush=True)
    #         #     print("  src_words :", src_words, flush=True)
    #         #     print("  tgt_words :", src_word_labels, flush=True)
    #         #     for chunk in results[-chunk_id:]:
    #         #         inp_str = f"{chunk['input_ids'][:10]} ... {chunk['input_ids'][-10:]}" if len(chunk["input_ids"]) > 20 else str(chunk["input_ids"])
    #         #         lab_str = f"{chunk['labels'][:10]} ... {chunk['labels'][-10:]}"     if len(chunk["labels"]) > 20     else str(chunk["labels"])
    #         #         print(f"    chunk_id={chunk['chunk_id']} words={chunk['src_words']} labels={chunk['tgt_words']}", flush=True)
    #         #         print(f"      word_positions: {chunk['word_positions']}", flush=True)
    #         #         print(f"      input_ids     : {inp_str}", flush=True)
    #         #         print(f"      labels        : {lab_str}", flush=True)
    #         #     LanguageIdentificationDataset.is_debug_sample_shown = True

    #     return results, local_label_counter

    @staticmethod
    def process_batch_gen_llm_classifier(args):
        """
        Spec:
        - Insert ONE literal space between words in BOTH input and label streams
        (no trailing space after the last word of a chunk).
        - word_positions: one entry PER LABEL TOKEN of a word (= its word index j),
        plus -1 entries for EACH space token inserted between label words.
        - Overlap computed in WORDS (not tokens).
        - Preserve original fields.
        """
        import time
        start_time = time.time()
        (prompt_template, src_lines, tgt_lines, max_seq_len, overlap_ratio, is_test, start_sample_id) = args
        tokenizer = LanguageIdentificationDataset.TOKENIZER
        pad_id = tokenizer.pad_token_id or tokenizer.eos_token_id
        eos_id = tokenizer.eos_token_id
        ignore_index = -100
        input_prefix = "\n<|start_header_id|>user<|end_header_id|>\n"
        response_prefix = "<|eot_id|>\n<|start_header_id|>assistant<|end_header_id|>\n"
        instruction_ids = tokenizer.encode(prompt_template, add_special_tokens=False)
        input_prefix_ids = tokenizer.encode(input_prefix, add_special_tokens=False)
        response_prefix_ids = tokenizer.encode(response_prefix, add_special_tokens=False)
        space_ids = tokenizer.encode(" ", add_special_tokens=False)
        prefix = instruction_ids + input_prefix_ids
        suffix = response_prefix_ids
        eos_len = 1
        fixed_len = len(prefix) + len(suffix) + eos_len
        results = []
        local_label_counter = 0
        # Preprocess lines
        src_texts = [src.strip() for src in src_lines]
        tgt_texts = [tgt.strip() for tgt in tgt_lines]
        src_words_list = []
        tgt_words_list = []
        for line_idx, (src, tgt) in enumerate(zip(src_texts, tgt_lines)):
            src_words = src.split() if src else ["<empty>"]
            tgt_words = tgt if isinstance(tgt, list) else (tgt.strip().split() if tgt.strip() else ["<empty>"])
            if len(tgt_words) == 1:
                tgt_words = [tgt_words[0]] * len(src_words)
            elif len(tgt_words) != len(src_words):
                tgt_words = tgt_words[:len(src_words)] if len(tgt_words) > len(src_words) else tgt_words + [tgt_words[-1]] * (len(src_words) - len(tgt_words))
            src_words_list.append(src_words)
            tgt_words_list.append(tgt_words)
        all_src_words = list(chain(*src_words_list))
        all_tgt_words = list(chain(*tgt_words_list))
        tok_start = time.time()
        tok_src = tokenizer(all_src_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
        tok_tgt = tokenizer(all_tgt_words, add_special_tokens=False, return_attention_mask=False)["input_ids"]
        # print(f"Tokenization took {time.time() - tok_start:.2f}s")
        src_idx = 0
        tgt_idx = 0
        src_word_token_info_list = []
        tgt_word_token_info_list = []
        for line_idx, (src_words, tgt_words) in enumerate(zip(src_words_list, tgt_words_list)):
            src_len = len(src_words)
            tgt_len = len(tgt_words)
            if src_words == ["<empty>"] or tgt_words == ["<empty>"]:
                src_word_token_info_list.append([(src_words[0], [0], 1)])
                tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
                continue
            try:
                src_info = [(w, tok_src[src_idx + i], len(tok_src[src_idx + i]) if isinstance(tok_src[src_idx + i], list) else 1) for i, w in enumerate(src_words)]
                tgt_info = [(w, tok_tgt[tgt_idx + i], len(tok_tgt[tgt_idx + i]) if isinstance(tok_tgt[tgt_idx + i], list) else 1) for i, w in enumerate(tgt_words)]
            except IndexError:
                print(f"Tokenization error at line {start_sample_id + line_idx}: src_len={src_len}, tok_src_len={len(tok_src)}, tgt_len={tgt_len}, tok_tgt_len={len(tok_tgt)}")
                src_word_token_info_list.append([(src_words[0], [0], 1)])
                tgt_word_token_info_list.append([(tgt_words[0], [0], 1)])
                src_idx += src_len
                tgt_idx += tgt_len
                continue
            src_word_token_info_list.append(src_info)
            tgt_word_token_info_list.append(tgt_info)
            src_idx += src_len
            tgt_idx += tgt_len
        for line_idx, (src_words, src_word_token_info, tgt_word_token_info) in enumerate(zip(src_words_list, src_word_token_info_list, tgt_word_token_info_list)):
            sample_id = start_sample_id + line_idx
            chunk_id = 0
            src_word_labels = [info[0] for info in tgt_word_token_info]
            if src_words == ["<empty>"]:
                input_ids = prefix + [0] + suffix + [eos_id]
                labels = [ignore_index] * len(input_ids)
                pad_len = max_seq_len - len(input_ids)
                if pad_len > 0:
                    input_ids += [pad_id] * pad_len
                    labels += [ignore_index] * pad_len
                results.append({
                    "lang_codes": ["<empty>"],
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "word_positions": [0],
                    "input_ids": input_ids,
                    "labels": labels,
                    "prompt_len": len(prefix) + 1 + len(suffix),
                    "chunk_words": ["<empty>"],
                    "chunk_labels": ["<empty>"],
                    "num_chunks": 1
                })
                continue
            i = 0
            n = len(src_word_token_info)
            prev_j = -1
            chunk_results = []
            chunk_start = time.time()
            while i < n:
                total_len = fixed_len
                chunk_input_tokens = []
                chunk_label_tokens = []
                word_positions = []
                lang_codes = []
                chunk_words = []
                chunk_labels = []
                j = i
                while j < n:
                    _, src_ids, src_len = src_word_token_info[j]
                    tgt_word, tgt_ids, tgt_len = tgt_word_token_info[j]
                    inter_word_spaces = len(space_ids) if j < n - 1 else 0
                    word_total = max(src_len, tgt_len) + inter_word_spaces
                    if total_len + word_total > max_seq_len * 0.9:
                        break
                    chunk_input_tokens += src_ids if isinstance(src_ids, list) else [src_ids]
                    if inter_word_spaces:
                        chunk_input_tokens += space_ids
                    if tgt_len:
                        chunk_label_tokens += tgt_ids if isinstance(tgt_ids, list) else [tgt_ids]
                        word_positions += [j] * tgt_len
                    if inter_word_spaces:
                        chunk_label_tokens += space_ids
                        word_positions += [-1] * inter_word_spaces
                    lang_codes.append(tgt_word)
                    chunk_words.append(src_words[j])
                    chunk_labels.append(tgt_word)
                    local_label_counter += len(src_words[j])
                    total_len += word_total
                    j += 1
                if not chunk_input_tokens:
                    i += 1
                    continue
                flat_input_ids = chunk_input_tokens
                flat_label_ids = chunk_label_tokens
                # prompt_len = len(prefix) + len(flat_input_ids) + len(suffix)
                # if is_train and tgt_texts[line_idx] is not None:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # elif not is_train and tgt_texts[line_idx] is not None:
                #     input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                #     labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                # else:
                #     input_ids = flat_input_ids + suffix + [eos_id]
                #     labels = [ignore_index] * len(input_ids)
                prompt_len = len(prefix) + len(flat_input_ids) + len(suffix)
                if is_test==False: #For train and val datasets
                    input_ids = prefix + flat_input_ids + suffix + flat_label_ids + [eos_id]
                    labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                else:
                    input_ids = prefix + flat_input_ids + suffix + [eos_id] + [pad_id] * len(flat_label_ids)
                    labels = [ignore_index] * prompt_len + flat_label_ids + [ignore_index]
                
                inputs_pad_len = max_seq_len - len(input_ids)
                labels_pad_len = max_seq_len - len(labels)
                if inputs_pad_len > 0:
                    input_ids += [pad_id] * inputs_pad_len
                if labels_pad_len > 0:
                    labels += [ignore_index] * labels_pad_len
                chunk_results.append({
                    "lang_codes": lang_codes,
                    "sample_id": sample_id,
                    "chunk_id": chunk_id,
                    "word_positions": word_positions,
                    "input_ids": input_ids,
                    "labels": labels,
                    "prompt_len": prompt_len,
                    "chunk_words": chunk_words,
                    "chunk_labels": chunk_labels,
                    "num_chunks": 1
                })
                chunk_id += 1
                if j >= n or j <= prev_j:
                    break
                prev_j = j
                overlap_words = max(1, int(overlap_ratio * len(chunk_words)))
                i = j - overlap_words if (j - overlap_words) > i else j
            # print(f"Chunking took {time.time() - chunk_start:.2f}s for {chunk_id} chunks")
            num_chunks = len(chunk_results)
            for r in chunk_results:
                r["num_chunks"] = num_chunks
            results.extend(chunk_results)
            if not LanguageIdentificationDataset.is_debug_sample_shown and not is_test and num_chunks > 1:
                print(f"\n[DEBUG] sample_id={sample_id} from {num_chunks} chunks", flush=True)
                print(" src_words :", src_words, flush=True)
                print(" tgt_words :", src_word_labels, flush=True)
                for chunk in chunk_results:
                    inp_str = f"{chunk['input_ids'][:10]} ... {chunk['input_ids'][-10:]}" if len(chunk["input_ids"]) > 20 else str(chunk["input_ids"])
                    lab_str = f"{chunk['labels'][:10]} ... {chunk['labels'][-10:]}" if len(chunk["labels"]) > 20 else str(chunk["labels"])
                    print(f" chunk_id={chunk['chunk_id']} lang_codes={chunk['lang_codes']} chunk_words={chunk['chunk_words']} chunk_labels={chunk['chunk_labels']}", flush=True)
                    print(f" word_positions: {chunk['word_positions']}", flush=True)
                    print(f" input_ids : {inp_str}", flush=True)
                    print(f" labels : {lab_str}", flush=True)
                LanguageIdentificationDataset.is_debug_sample_shown = True
        # print(f"Processed batch in {time.time() - start_time:.2f}s: {len(results)} samples")
        return results, local_label_counter
    
    @staticmethod
    def decode_text(tokens, tokenizer):
        return tokenizer.decode(tokens)
    
    @staticmethod
    def encode_text(text, tokenizer, add_special_tokens=True):
        """Static method for tokenization to avoid pickling errors."""
        return tokenizer.encode_plus(text, truncation=False, return_tensors=None, add_special_tokens=add_special_tokens)["input_ids"]

    def _process_file_data(self, src_file, tgt_file, start_sample_id):
        data = []

        with open(src_file, 'r', encoding='utf8') as sfile, open(tgt_file, 'r', encoding='utf8') as tfile:
            src_lines = sfile.readlines()[1:] if self.files_have_header else sfile.readlines()
            tgt_lines = tfile.readlines()[1:] if self.files_have_header else tfile.readlines()

        # sample some share
        num_samples = int(len(src_lines) * self.sample_dataset_share)
        indices = np.random.choice(len(src_lines), num_samples, replace=False)
        src_lines = [src_lines[i] for i in indices]
        tgt_lines = [tgt_lines[i] for i in indices]

        # representative lang code (just for logging)
        lang_code = list(set(t.strip() for t in tgt_lines))[0]
        self.log.info(f"Sampled {self.sample_dataset_share * 100:.1f}% of {src_file}: {num_samples} lines")

        # helper batch iterator
        def batch_iter(seq, batch_size):
            it = iter(seq)
            while True:
                batch = list(islice(it, batch_size))
                if not batch:
                    break
                yield batch

        batch_size = 10_000
        if self.is_gen_llm:
            batches = [
                (self.prompt_template, src_batch, tgt_batch,
                self.max_seq_length, 0.25, self.is_test, start_sample_id + offset*batch_size)
                for offset, (src_batch, tgt_batch) in enumerate(
                    zip(batch_iter(src_lines, batch_size), batch_iter(tgt_lines, batch_size))
                )
            ]
            with Pool(self.num_workers) as pool:
                all_results = pool.map(LanguageIdentificationDataset.process_batch_gen_llm_classifier, batches)
        else:
            batches = [
                (src_batch, tgt_batch, self.max_seq_length, 0.5, self.is_train, start_sample_id + offset*batch_size)
                for offset, (src_batch, tgt_batch) in enumerate(
                    zip(batch_iter(src_lines, batch_size), batch_iter(tgt_lines, batch_size))
                )
            ]
            with Pool(self.num_workers) as pool:
                all_results = pool.map(LanguageIdentificationDataset.process_batch_classifier, batches)

        # flat = [x for batch in all_results[0] for x in batch]
        # self.label_sample_counter += all_results[1]
        flat  = []
        for results, local_count in all_results:
            flat.extend(results)
            self.label_sample_counter += local_count
        if flat:
            data = flat

        # return language code, data, and how many source lines we processed
        return lang_code, data, len(src_lines)


    # def _process_file_data(self, src_file, tgt_file, start_sample_id):
    #     start_time = time.time()
    #     cache_file = f"{src_file}.cache.pkl"
    #     if os.path.exists(cache_file):
    #         os.remove(cache_file)
    #         self.log.info(f"Loading cached data for {src_file}")
    #         with open(cache_file, 'rb') as f:
    #             return pickle.load(f)

    #     data = []
    #     with open(src_file, 'r', encoding='utf8') as sfile, open(tgt_file, 'r', encoding='utf8') as tfile:
    #         src_lines = sfile.readlines()[1:] if self.files_have_header else sfile.readlines()
    #         tgt_lines = tfile.readlines()[1:] if self.files_have_header else tfile.readlines()

    #     num_samples = int(len(src_lines) * self.sample_dataset_share)
    #     indices = np.random.choice(len(src_lines), num_samples, replace=False)
    #     src_lines = [src_lines[i] for i in indices]
    #     tgt_lines = [tgt_lines[i] for i in indices]
    #     lang_code = list(set(t.strip() for t in tgt_lines))[0]
    #     self.log.info(f"Sampled {self.sample_dataset_share * 100:.1f}% of {src_file}: {num_samples} lines")

    #     def batch_iter(seq, batch_size):
    #         it = iter(seq)
    #         while True:
    #             batch = list(islice(it, batch_size))
    #             if not batch:
    #                 break
    #             yield batch

    #     batch_size = 100  # Reduced from 100_000
    #     self.log.info(f"Processing {len(src_lines)} lines in {len(src_lines)//batch_size + 1} batches")
    #     batches = [
    #         (self.prompt_template, src_batch, tgt_batch, self.max_seq_length, 0.5, self.is_train, start_sample_id + offset * batch_size)
    #         for offset, (src_batch, tgt_batch) in enumerate(
    #             zip(batch_iter(src_lines, batch_size), batch_iter(tgt_lines, batch_size))
    #         )
    #     ]

    #     results = []
    #     for i, batch in enumerate(batches):
    #         self.log.info(f"Processing batch {i+1}/{len(batches)}")
    #         batch_start = time.time()
    #         result = (LanguageIdentificationDataset.process_batch_gen_llm_classifier(batch)
    #                 if self.is_gen_llm else LanguageIdentificationDataset.process_batch_classifier(batch))
    #         results.append(result)
    #         self.log.info(f"Batch {i+1} processed in {time.time() - batch_start:.2f}s: {len(result[0])} samples")

    #     flat = []
    #     for result, local_count in results:
    #         flat.extend(result)
    #         self.label_sample_counter += local_count
    #     self.log.info(f"Processed {len(flat)} samples from {src_file} in {time.time() - start_time:.2f}s")

    #     if flat:
    #         data = flat
    #     result = (lang_code, data, len(src_lines))
    #     with open(cache_file, 'wb') as f:
    #         pickle.dump(result, f)
    #     return result


    def _validate_and_load_file_data(self):
        """
        validates, loads and processes data
        :return: None
        """
        global_sample_id = 0
        # filename_match_threshold = 0.99
        src_files_list = []
        tgt_files_list = []

        for lang_dir in os.listdir(self.data_dir):
            self.log.info(f"Now processing {os.path.join(self.data_dir, lang_dir)} directory.")
            src_data_dir = os.path.join(self.data_dir, lang_dir, 'src')
            tgt_data_dir = os.path.join(self.data_dir, lang_dir, 'tgt')
            for src_file in os.listdir(src_data_dir):
                matched = False
                for tgt_file in os.listdir(tgt_data_dir):
                    # sim_score = self._similar_name(src_file, tgt_file)
                    # if sim_score >= filename_match_threshold:
                    if src_file.split(".")[0] == tgt_file.split(".")[0]:
                        src_files_list.append(src_file)
                        tgt_files_list.append(tgt_file)
                        matched = True
                        break
                if matched:
                    continue  # continue to next loop
                else:
                    self.log.info(f"Skipping file {src_file} since matching label file not found in {tgt_data_dir}.")
            # Validate files and content
            src_filtered_files = [os.path.join(src_data_dir, file) for file in src_files_list if
                                  os.path.isfile(os.path.join(src_data_dir, file))]
            tgt_filtered_files = [os.path.join(tgt_data_dir, file) for file in tgt_files_list if
                                  os.path.isfile(os.path.join(tgt_data_dir, file))]
            if len(src_filtered_files) != len(tgt_filtered_files):
                msg_err_num_files = f"Number of files in {src_data_dir} is {len(src_filtered_files)} does not match" \
                                    f"with {len(tgt_filtered_files)} files present in {tgt_data_dir}"
                raise ValueError(msg_err_num_files)
            else:
                for src_file, tgt_file in zip(src_filtered_files, tgt_filtered_files):
                    file_data_dict_list = []
                    new_src_file_lines = []
                    new_tgt_file_lines = []
                    src_num_lines = sum(1 for _ in open(src_file))
                    tgt_num_lines = sum(1 for _ in open(tgt_file))
                    src_num_lines = src_num_lines - 1 if self.files_have_header else src_num_lines
                    tgt_num_lines = tgt_num_lines - 1 if self.files_have_header else tgt_num_lines
                    if src_num_lines != tgt_num_lines:
                        self.log.info(f"{src_num_lines} lines in {src_file} "
                                      f"do not match with {tgt_num_lines} in {tgt_file}, skipping processing these files")
                    else:
                        self.log.info(f"Processing {src_file} and {tgt_file} with {tgt_num_lines} samples.")
                        # lang_code, new_src_file_lines , new_tgt_file_lines = self._process_file_data(src_file, tgt_file)
                        lang_code, file_data_dict_list, lines_processed = self._process_file_data(
                            src_file, tgt_file, start_sample_id=global_sample_id
                        )
                        global_sample_id += lines_processed
                            
                        # num_of_samples_to_use = int(len(new_src_file_lines) * self.sample_dataset_share)

                        # # Randomly select some share of data from the list
                        # new_src_file_lines = random.sample(new_src_file_lines, num_of_samples_to_use)
                        # new_tgt_file_lines = random.sample(new_tgt_file_lines, num_of_samples_to_use)
                        # self.log.info(f"Sampled {self.sample_dataset_share*100} percent of this dataset")

                        # any further preprocessing here and then append
                        # self.src_data.extend(new_src_file_lines)
                        # self.tgt_data.extend(new_tgt_file_lines)
                        self.file_data_dict_list.extend(file_data_dict_list)
                        
                        if self.is_train:
                            if lang_code not in self.file_stats:
                                self.file_stats.update({lang_code : [{"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(file_data_dict_list)}]})
                            else:
                                self.file_stats[lang_code].append({"file_name": tgt_file,
                                    "samples_before_processing": tgt_num_lines,
                                    "samples_after_processing": len(file_data_dict_list)})
                        self.log.info(f"Files {src_file} and {tgt_file} have {len(file_data_dict_list)} samples after processing.")

        # run sample id clash check if needed for debug otherwise comment it
        self.audit_dataset()

    @property
    def actual_dataset_length(self) -> int:
        """
        Number of unique base samples (unique sample_id) present after preprocessing.
        """
        if not getattr(self, "file_data_dict_list", None):
            return 0
        return len({int(entry["sample_id"]) for entry in self.file_data_dict_list})

    # Correct version tallies with awk 'FNR>1' all file paths|wc -l -w count
    @property
    def actual_num_of_labels(self) -> int:
        """
        Total number of label tokens across unique samples.
        For each sample_id we collect all word_positions from its chunks and count unique positions;
        this avoids double-counting overlapping windows/chunks.
        """
        if not getattr(self, "file_data_dict_list", None):
            return 0

        per_sample_positions = defaultdict(set)
        for entry in self.file_data_dict_list:
            sid = int(entry.get("sample_id", -1))
            for p in entry.get("word_positions", []):
                # only count non-negative positions (some code uses -1 for separators)
                try:
                    pos = int(p)
                except Exception:
                    continue
                if pos >= 0:
                    per_sample_positions[sid].add(pos)

        # sum unique positions per sample
        return sum(len(posset) for posset in per_sample_positions.values())
