import math
import torch
from torch.utils.data import Sampler, get_worker_info

class DistributedIterableSampler(Sampler):
    def __init__(self, dataset, num_replicas=None, rank=None, shuffle=True, seed=0):
        if num_replicas is None:
            if not torch.distributed.is_available():
                raise RuntimeError("Requires distributed package to be available")
            num_replicas = torch.distributed.get_world_size()
        if rank is None:
            if not torch.distributed.is_available():
                raise RuntimeError("Requires distributed package to be available")
            rank = torch.distributed.get_rank()

        self.dataset = dataset
        self.num_replicas = num_replicas
        self.rank = rank
        self.shuffle = shuffle
        self.seed = seed

        self.total_size = len(dataset)  # total dataset length, must be defined in your IterableDataset!
        self.num_samples = int(math.ceil(self.total_size / self.num_replicas))

    def __iter__(self):
        # Determine worker info for multi-worker dataloader
        worker_info = get_worker_info()
        worker_id = worker_info.id if worker_info else 0
        num_workers = worker_info.num_workers if worker_info else 1

        # Generate all indices for this rank
        indices = list(range(self.rank, self.total_size, self.num_replicas))

        # Shuffle if needed
        if self.shuffle:
            g = torch.Generator()
            g.manual_seed(self.seed)
            indices = [indices[i] for i in torch.randperm(len(indices), generator=g)]

        # Further split for worker processes (if using num_workers>1)
        per_worker = int(math.ceil(len(indices) / num_workers))
        start = worker_id * per_worker
        end = min(start + per_worker, len(indices))
        worker_indices = indices[start:end]

        yield from worker_indices

    def __len__(self):
        return self.num_samples

