import torch
from torchmetrics import Metric
from pytorch_lightning.utilities.rank_zero import rank_zero_warn


class ClassWeightedAccuracy(Metric):
    full_state_update: bool = False  # avoids full dataset sync in DDP

    def __init__(self, track_per_class=False, **kwargs):
        self.k = kwargs.pop("k", 1)
        self.average = kwargs.pop("average", None)
        self.ignore_index = kwargs.pop("ignore_index", -100)
        self.num_classes = kwargs.pop("num_classes", 50000)
        self.class_weights_dict = kwargs.pop("class_weights", {})
        self.track_per_class = track_per_class

        super().__init__(**kwargs)

        self.unk_weight = self.class_weights_dict.get("unk", [[], 0.0])[1]
        self.token_weight_map = self._build_token_weight_map()

        self.add_state("correct", default=torch.tensor(0.0), dist_reduce_fx="sum")
        self.add_state("total", default=torch.tensor(0.0), dist_reduce_fx="sum")

        if self.track_per_class:
            self.add_state(
                "per_class_correct",
                default=torch.zeros(self.num_classes, dtype=torch.float32, device="cpu"),
                dist_reduce_fx="sum"
            )
            self.add_state(
                "per_class_total",
                default=torch.zeros(self.num_classes, dtype=torch.float32, device="cpu"),
                dist_reduce_fx="sum"
            )

    def _build_token_weight_map(self):
        weight_map = {}
        for label, (token_ids, weight) in self.class_weights_dict.items():
            if label == "unk":
                continue
            for tid in token_ids:
                weight_map[tid] = weight or 0.0
        return weight_map

    def update(self, preds: torch.Tensor, target: torch.Tensor):
        if preds.ndim == 3:
            preds = preds.view(-1, preds.size(-1))
        if target.ndim == 2:
            target = target.view(-1)

        mask = target != self.ignore_index
        preds = preds[mask]
        target = target[mask]

        if preds.numel() == 0 or target.numel() == 0:
            return

        if preds.ndim == 2:
            if self.k == 1:
                topk = torch.argmax(preds, dim=-1, keepdim=True)
            else:
                topk = preds.topk(self.k, dim=-1).indices
            correct_mask = topk.eq(target.unsqueeze(-1)).any(dim=-1)
        else:
            correct_mask = preds.eq(target)

        self.correct += correct_mask.sum()
        self.total += correct_mask.numel()

        if self.track_per_class:
            with torch.no_grad():
                target_ = target[correct_mask].to("cpu")
                correct_ = torch.ones_like(target_, dtype=torch.float32)
                total_ = torch.ones_like(target.to("cpu"), dtype=torch.float32)

                self.per_class_correct.index_add_(0, target_, correct_)
                self.per_class_total.index_add_(0, target.to("cpu"), total_)

    def compute(self):
        if self.total.item() == 0:
            rank_zero_warn("Metric compute() called but no valid examples seen.")
            return torch.tensor(0.0, device=self.correct.device)

        if self.average == "micro" or not self.track_per_class:
            return self.correct / self.total

        valid = self.per_class_total > 0
        acc_per_class = torch.zeros_like(self.per_class_total)
        acc_per_class[valid] = self.per_class_correct[valid] / self.per_class_total[valid]

        if self.average == "macro":
            return acc_per_class[valid].mean()

        elif self.average == "weighted":
            weights = self.per_class_total[valid] / self.per_class_total[valid].sum()
            return (acc_per_class[valid] * weights).sum()

        elif self.average == "custom":
            cids = torch.nonzero(valid, as_tuple=False).squeeze(1)
            if cids.numel() == 0:
                return torch.tensor(0.0, device=acc_per_class.device)

            weights_tensor = torch.tensor(
                [self.token_weight_map.get(cid.item(), self.unk_weight) for cid in cids],
                dtype=acc_per_class.dtype,
                device=acc_per_class.device
            )

            weighted_sum = (acc_per_class[cids] * weights_tensor).sum()
            total_weight = weights_tensor.sum()
            return weighted_sum / total_weight if total_weight > 0 else torch.tensor(0.0)

        else:
            return acc_per_class

    def reset(self):
        super().reset()  # clears all states
