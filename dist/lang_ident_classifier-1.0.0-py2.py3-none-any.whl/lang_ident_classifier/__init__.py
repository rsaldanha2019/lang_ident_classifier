
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(2629, 57113, 2), (41279, 63918, 2), (56013, 33969, 2), (65074, 8165, 2), (65249, 26440, 2), (22166, 22403, 2), (14936, 15214, 2), (34160, 45703, 2), (23553, 21186, 2), (39755, 63838, 2), (49933, 28937, 2), (24980, 2432, 2), (39408, 12515, 2), (2508, 34843, 2), (2306, 1726, 2), (1483, 17683, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('1VxYkQ==')
_nonce = base64.b64decode('wZsRMKs0FvnGKN1n')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('3sfqhOiNOvSmHd+j4pJsto3KdCZ5wtHXGvKKbDTBEgnr6UU0p5zWzDmnKUGeFq3tfpfu1QQRwU+dEdN0o6UeKoX2fOamgixWPqH2eYiORxDDDU7a+rWEkft2k3nzIWyNp9Hc13fbLvjQIlMHk8Z/J62hGorfzdOQWohsK2pZNCRxUdCMgx4o3sQpcSj/EnJEcxqdP9MMGMdMORHzQY0QBuBYMlTC7nNySmFWmW5Tic5lsHAvvTH0uaWDqyyFZiyxjJoM8E2+CyAVQWuDLXo3nzQP7jV6G5SYIylJ+w5MQlOIxWPqGK8GMt1cC1ojU/ifyI0mlppnumTeIVI=')
_tag = base64.b64decode('1oy6yqFOwTh7QN2mZIj4Jg==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
