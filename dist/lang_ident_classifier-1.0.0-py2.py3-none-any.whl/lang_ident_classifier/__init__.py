#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(16512, 64335, 2), (46058, 64054, 2), (49021, 16472, 2), (20587, 7052, 2), (53080, 45204, 2), (1701, 12763, 2), (18709, 35550, 2), (32382, 62244, 2), (17525, 6877, 2), (27176, 12604, 2), (54642, 57608, 2), (24912, 24441, 2), (18992, 26236, 2), (45265, 23452, 2), (3736, 39965, 2), (19179, 34013, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('u89J3A==')
_nonce = base64.b64decode('6ypa1luEmaW2H9NQ')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('+HFhd4qIZvH1EAjidx9OfWZJoEPId1Dr0cGP8cMniNl6uOluiva7hLqp894EVjepky4FlGUXFaPMLhOpkqBXflWbrJk5Gx2PJtAfFvr6aNhQAYGQW3jztJV6Hx3XwRsAeZw+490QWSiqZKns8yosTBA99B6OKXGte+T0IEqpV3eVwDPPFMiFmy16Ev1PNUX90V2URS76JKuywLDkZZ13eTB8WxPkMO7mlcWgxJETnKTwgK5tLu+Cj3mfANliOL839BBsv6qtzE16+LSP37Z/Nl2kr6SiDZvHlJv5vTaxCB8VNQnQUhkHEKYPATUSme0JlfU1ILCn4UnYJH4=')
_tag = base64.b64decode('5nNSEYU8vFqoywR8C3uLbA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
