#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(35863, 64295, 2), (31859, 58386, 2), (34996, 41561, 2), (44671, 12625, 2), (57992, 33357, 2), (33495, 17444, 2), (6712, 26664, 2), (42732, 25366, 2), (12642, 63868, 2), (30920, 5106, 2), (48756, 42257, 2), (41180, 48168, 2), (21899, 34112, 2), (65403, 47407, 2), (14230, 3656, 2), (37384, 13945, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('dzCYYQ==')
_nonce = base64.b64decode('pW08v2zYrq9ezV9j')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('OngqDR5RVdFH7bqL6rP3Wvz1TjqQ06Ano5Se5+hxOsiEfHYktMaY1WpMuulNoK0rHX2BKKvi69L+gpRoBzabl1a7wQ3Yzq1DQgPrcrf01EL2u5Syh2v3N6tTImi+HhUTw7VZxIEsy25cbiSj4ejsa1QPxY7h1yYMrcIsNYKRgfISd6GUVm42UkZfZ7MtZAWbcujayKP0bpOw2JwDZERy6aJLBTHSHS/frlLq/uWukylF/OlVq+bOsZB4O2DKVNlHLnAK63AGHjjnyyOy66nZqFASCXBvJdu15Oz+RZvFVOujM3UK9mkDt5JR8EbIj71HxAuTWiq34infuTU=')
_tag = base64.b64decode('x3rsop9rfXDoj7awap+LyA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
