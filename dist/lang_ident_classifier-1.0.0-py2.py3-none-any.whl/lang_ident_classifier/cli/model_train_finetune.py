# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:59 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from _c5bfefa138fc import _ab32c5f805b2
from _96ed981a5db7 import _f14b15574564
import _c57dd632eb7d, _4bf9cdec8a4c, _4395152355ba, _5a680431f2a7, _b20d8d3810de, _54b57f69f6df, _69a8c0fc0b0d, _d6784af9f7b9, _5a47de9db9a9
from _36272601a7bf import _94a2b9458ba9
from _863ec00efb50 import _0b2f858ac64c, _5db2953a5f43, _ea1f511d3981
import _783a47aa42ad as _045b88cb3b0e, _9cbacedf5363, _0daf95c512e7 as _892109dc8c3c
from _0daf95c512e7 import _32871f12a74a
from _0daf95c512e7._a18c1ff2e869 import _f104fe4f8470
from _0daf95c512e7._a18c1ff2e869._9a91ffd6a593._415e491c905f import _4dcf720601a0
from _381e55dd3351 import _9b7fb1ec1e81, _7f1aaa343e1f, _77bce0de33fa
from _c73f9412b7d1._ed36c80566fa._49a651420f3f._d221d5450d6a import _3cc3e89e9eaa
from _c73f9412b7d1._ed36c80566fa._49a651420f3f._c9ccb1c2d3f8 import _109336777482
from _c73f9412b7d1._ed36c80566fa._49a651420f3f._0879b93c9f66 import _4d15efcb853e
from _c73f9412b7d1._ed36c80566fa._49a651420f3f._9e4d05d420b2 import _de0323ad829f
from _c73f9412b7d1._ed36c80566fa._e6247564fb59._f933d2a3fab0 import _de3c2dfa4384
from _c73f9412b7d1._ed36c80566fa._e6247564fb59._9e4023fc2312 import _c96d5b4fb848
from _c73f9412b7d1._ed36c80566fa._5f7ccf4d28d8._702434bfcfab import _6ebb9c9a87fb
from _c73f9412b7d1._ed36c80566fa._5f7ccf4d28d8._d7feb89f712c import _dbef95cf6f38
from _c73f9412b7d1._ed36c80566fa._f104fe4f8470._fc920389b147 import _acecb220a8ea
from _c73f9412b7d1._ed36c80566fa._49a651420f3f._daa9becd9de2 import _80b03e35b4fa
from _c73f9412b7d1._ed36c80566fa._49a651420f3f._daa9becd9de2 import (
    _453796e171f2, _fdd30da26c7d, _6e78312b6d0a,
    _846a3f8305ba, _7f9b54bfa526, _2aa2dd6bc868,
    _eaf0428c3884, _c41fd0d12ba7, _916acc565a42,
    _fb6270a3be2a, _0991c8bdbeeb, _5f7c1233f268,
    _13364ba6a753, _20dfe41ade34
)

_5a680431f2a7._2343ec8fdfb0["TOKENIZERS_PARALLELISM"] = "True"
_1fd513e6eb91 = _9cbacedf5363._002daf70b691._86f0bb841b51() and _9cbacedf5363._002daf70b691._03b74e83dc42() > 0
if _1fd513e6eb91:
    try:
        from _28d8fb241414 import _8965fe43149c
        import _364790953275 as _cd72ece522cc
    except _27e13c16945b:
        _cd72ece522cc = _27e89c1f94bd


def _b40422004961(_d671ffb8afe2: _9cbacedf5363._45c0f0c73d6e._5b2f2aab8462, _7b3ecbf9a61a: _dc0821e820ac, _091181878c03: _ea1f511d3981[_dc0821e820ac] = _27e89c1f94bd) -> _27e89c1f94bd:
    if not _5a680431f2a7._cf72d5bd330c._9587bfd6c084(_7b3ecbf9a61a):
        raise _d2a4263c009d(f"Finetuned model path not found: {_7b3ecbf9a61a}")
    if _7b3ecbf9a61a._4a2f5a82546c((".pt", ".pth")):
        _e3e98d7ef05d = _091181878c03 or ("cpu" if not _9cbacedf5363._002daf70b691._86f0bb841b51() else _27e89c1f94bd)
        _67476fdd4af8 = _9cbacedf5363._c5c8d80abee6(_7b3ecbf9a61a, _091181878c03=_e3e98d7ef05d)
        _8c36de90cd49 = _67476fdd4af8._6b73b6986fc2("state_dict", _67476fdd4af8._6b73b6986fc2("model_state_dict", _67476fdd4af8)) if _58e42f4141ca(_67476fdd4af8, _0c1f5bf9be9f) else _67476fdd4af8
        if not _58e42f4141ca(_8c36de90cd49, _0c1f5bf9be9f):
            raise _8ef09a48cace(f"Loaded .pt file does not contain state_dict mapping: {_7b3ecbf9a61a}")
        _d671ffb8afe2._6d2d466e6197(_8c36de90cd49, _8497db689c62=_0a812bf64d05)
    elif _7b3ecbf9a61a._4a2f5a82546c(".ckpt"):
        try:
            if _48fe2e3cdd2e(_d671ffb8afe2._2469ae744bcd, "load_from_checkpoint"):
                _e2980848f5c0 = _d671ffb8afe2._2469ae744bcd._af35392d6b61(_7b3ecbf9a61a, **{})
                _d671ffb8afe2._6d2d466e6197(_e2980848f5c0._2f7927b8990d(), _8497db689c62=_0a812bf64d05)
                return
            _67476fdd4af8 = _9cbacedf5363._c5c8d80abee6(_7b3ecbf9a61a, _091181878c03="cpu")
            _8c36de90cd49 = _67476fdd4af8._6b73b6986fc2("state_dict", _67476fdd4af8)
            if not _58e42f4141ca(_8c36de90cd49, _0c1f5bf9be9f):
                raise _8ef09a48cace("Lightning checkpoint did not contain a recognizable state_dict.")
            _d671ffb8afe2._6d2d466e6197(_8c36de90cd49, _8497db689c62=_0a812bf64d05)
        except _27e13c16945b as _5fec0bac540f:
            raise _8ef09a48cace(f"Failed to load .ckpt into model: {_5fec0bac540f}") from _5fec0bac540f
    else:
        raise _967f467bccd9("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _7c38803ed127(_cbecfa53ca0c: _c57dd632eb7d._00d99ecc3a3b, _faa66c1267ed: _0b2f858ac64c, _f1fa40c7a323: _5db2953a5f43[_dc0821e820ac, _0b2f858ac64c], _c9747b7ba5d1: _dc0821e820ac, _76f61cfc5f31: _0b2f858ac64c, _fc9572d5aa49: _0b2f858ac64c, _30f43f93021b: _f20ce97f81a0, _a6993f45886e: _86c4e2144707, _fc89335e89bb: _0b2f858ac64c, _259feb737600: _86c4e2144707, _7a1cf1812242: _f14b15574564, _1dcb23139626: _dc0821e820ac = "32", _c4ad554a2a32: _9effda81892e = 0.0):
    """
    Compute test accuracy using the best checkpoint.
    """
    _318eeb629833 = _0a812bf64d05
    _766f66ac4a08 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="app.model_config_name",
        _ae1e9f39b02b=_dc0821e820ac,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )

    if _1fd513e6eb91:
        _c2728c52749f = _8965fe43149c(
            _845a06aea0d2=_530ea9427bc3,
            _a2450a809f4b=_6e78312b6d0a(),
            _1e2de815ce4e=_530ea9427bc3,
            _62bce263b2b7="nf4",
        )
        _318eeb629833 = _530ea9427bc3

    _a6f1b5938618 = 'gpu' if _9cbacedf5363._002daf70b691._86f0bb841b51() else 'cpu'
    _52e5355d4310 = 'cpu'
    if _a6f1b5938618 == 'gpu':
        _8e3d93cfca95 = _9cbacedf5363._7b25f245fa9d._1b80f8b85f43() if _9cbacedf5363._7b25f245fa9d._d7ca2fcab51b() else 0
        _52e5355d4310 = f"cuda:{_8e3d93cfca95}"
    else:
        _8e3d93cfca95 = -1

    _89a6cda12928 = _f1fa40c7a323._6b73b6986fc2("pretrained_model_embedding_name")

    _f1fa40c7a323._cb6e11e40932({
        "tokenizer": _76f61cfc5f31,
        "pretrained_embedding_model": _fc9572d5aa49,
        "device_dict": _fdd30da26c7d(),
        "model_config_name": _766f66ac4a08,
    })

    if not _c9747b7ba5d1:
        _7a1cf1812242._c0d027df0993("No best checkpoint found. Proceeding with current model weights.")
    else:
        _7a1cf1812242._c0d027df0993(f"Testing with best checkpoint: {_c9747b7ba5d1}")

    if "llama" in (_89a6cda12928 or ""):
        _d671ffb8afe2 = _dbef95cf6f38(**_f1fa40c7a323)
        _a6993f45886e = _530ea9427bc3
    else:
        _d671ffb8afe2 = _6ebb9c9a87fb(**_f1fa40c7a323)

    if _259feb737600:
        if _318eeb629833:
            _78afde1050a4 = lambda _ec4a356c5974: (
                _48fe2e3cdd2e(_ec4a356c5974, "weight") and _58e42f4141ca(_ec4a356c5974._429eb8729aad, _9cbacedf5363._617c126ad495) and _ec4a356c5974._429eb8729aad._4f157c9b1ca6() > 64 and
                not _58e42f4141ca(_ec4a356c5974, (_cd72ece522cc._45c0f0c73d6e._8988778e400b, _cd72ece522cc._45c0f0c73d6e._1cf76b53eb79, _c93c2392cafe(_cd72ece522cc._45c0f0c73d6e, "LinearNF4", _5208b41a596c(_27e89c1f94bd))))
            )
        else:
            _78afde1050a4 = lambda _ec4a356c5974: (
                _48fe2e3cdd2e(_ec4a356c5974, "weight") and _58e42f4141ca(_ec4a356c5974._429eb8729aad, _9cbacedf5363._617c126ad495) and _ec4a356c5974._429eb8729aad._4f157c9b1ca6() > 64
            )
        _b8fd704fc2a2 = _d671ffb8afe2._e84411c1f867
        _8a82df0cadd9 = _846a3f8305ba(_b8fd704fc2a2, _78afde1050a4=_78afde1050a4, _ad29eaaaf32d=_27e89c1f94bd, _9cec6f369a34=_27e89c1f94bd)
        _395da59e1588 = _7f1aaa343e1f(
            _d3a3fbc97a9d=8,
            _e6512413baa0=32,
            _4a63b0725dcf=0.1,
            _8a82df0cadd9=_deb55bfe8532(_8a82df0cadd9._a88ed79d4e7b()) if _8a82df0cadd9 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _59c30f9a8414=_9b7fb1ec1e81._291c240152b8 if _a6993f45886e else _9b7fb1ec1e81._e1d56d43cccb
        )
        _7a1cf1812242._c0d027df0993(f"In test Target Module trainable parameters before applying LORA: {_7f9b54bfa526(_b8fd704fc2a2)}")
        _b8fd704fc2a2 = _2aa2dd6bc868(_b8fd704fc2a2, _395da59e1588)
        _7a1cf1812242._c0d027df0993(f"In test Target Module trainable parameters after applying LORA: {_7f9b54bfa526(_b8fd704fc2a2)}")

    if _c9747b7ba5d1:
        _7a1cf1812242._c0d027df0993(f"Loading checkpoint from: {_c9747b7ba5d1}")
        try:
            _67476fdd4af8 = _9cbacedf5363._c5c8d80abee6(_c9747b7ba5d1, _091181878c03=_52e5355d4310)
            _8c36de90cd49 = _67476fdd4af8._6b73b6986fc2("state_dict", _67476fdd4af8)
            # Strip prefixes
            _2546287e940e = {}
            for _51994b123580, _d80a1141701d in _8c36de90cd49._b54671278a3d():
                _12caf4956f53 = _51994b123580
                while _12caf4956f53._50ef8c8ea09c('module.'):
                    _12caf4956f53 = _12caf4956f53[7:]
                while _12caf4956f53._50ef8c8ea09c('_forward_module.'):
                    _12caf4956f53 = _12caf4956f53[16:]
                _2546287e940e[_12caf4956f53] = _d80a1141701d
            # Load with strict=False to handle potential extras
            _d671ffb8afe2._6d2d466e6197(_2546287e940e, _8497db689c62=_0a812bf64d05)
        except _27e13c16945b as _5fec0bac540f:
            _7a1cf1812242._3c2a517b6220(f"Checkpoint load failed: {_5fec0bac540f}")
    else:
        _7a1cf1812242._3c2a517b6220("No best checkpoint found. Proceeding with in-memory model weights.")

    if _9cbacedf5363._002daf70b691._86f0bb841b51():
        _8e3d93cfca95 = _f20ce97f81a0(_453796e171f2())

    if _4dcf720601a0._031bb1dfe372() is _0a812bf64d05:
        _7a1cf1812242._c0d027df0993(f"Setting model to {_52e5355d4310}")
        _d671ffb8afe2 = _d671ffb8afe2._974bf55a5b0e(_ae1e9f39b02b=_9cbacedf5363._fe1472b7beb8, _60d215b04438=_52e5355d4310)

    _28de8977c472 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="app.data_dir",
        _ae1e9f39b02b=_dc0821e820ac,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="data_dir under app specifies the base directory for datasets."
    )

    _d6f0151a45f2 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="dataset.data_source_dir",
        _ae1e9f39b02b=_dc0821e820ac,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Base data source directory under data."
    )

    _1b59fc8a944f = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="dataset.test.data_dir",
        _ae1e9f39b02b=_dc0821e820ac,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _d29428d346d8 = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_28de8977c472,_d6f0151a45f2,_1b59fc8a944f)

    _a77205f72de8 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="dataset.files_have_header",
        _ae1e9f39b02b=_86c4e2144707,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _fab82e675967 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="app.random_seed",
        _ae1e9f39b02b=_f20ce97f81a0,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _5a9f599d536d = f"config/{_766f66ac4a08}/finetune/classes_config.json"

    _b956303f1590 = _de3c2dfa4384(
        _28de8977c472=_d29428d346d8,
        _a77205f72de8=_a77205f72de8,
        _7a1cf1812242=_7a1cf1812242,
        _76f61cfc5f31=_76f61cfc5f31,
        _81826eb94bad=_30f43f93021b,
        _5a9f599d536d=_5a9f599d536d,
        _2f6969f83de2=_0a812bf64d05,
        _215177c7da5f=_530ea9427bc3,
        _5f65ed40dd0d=_cbecfa53ca0c._d10766d7b40b,
        _a6993f45886e=_a6993f45886e,
        _fc89335e89bb=_fc89335e89bb,
        _fab82e675967=_fab82e675967,
    )
    _7a1cf1812242._c0d027df0993(f"Test samples: {_fe59e45cb0c1(_b956303f1590)}, Labels: {_c93c2392cafe(_b956303f1590, 'actual_num_of_labels', 'NA')}")

    _73e1a2f94b15 = [_dff0396f1474 for _, _dff0396f1474 in _d671ffb8afe2._687652b2dd52() if not _dff0396f1474._1349f9ec5098]
    _ed59e8ed7f7a = _13364ba6a753(_523af454aedc=_73e1a2f94b15) if _a6f1b5938618 == "gpu" else "auto"

    _0098b39c3e6e = _32871f12a74a(
        _d8a9659ee77e=_a6f1b5938618,
        _c410c850eca9=_c41fd0d12ba7(_a6f1b5938618=_a6f1b5938618),
        _b73f235e070d=1,
        _d18479a67f41=_ed59e8ed7f7a if _a6f1b5938618 == "gpu" else "auto",
        _440d64ef90c5=1,
        _1dcb23139626=_1dcb23139626,
        _03b279e838d6=0,
        _19321a093309=_0a812bf64d05,
        _b1b928868071=_0a812bf64d05,
        _f71df9b98655=_530ea9427bc3,
        _473b14b6b09d=_0a812bf64d05,
    )

    _59bce9310e7d = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.batch_size", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Batch size for training"
    )

    _ab689e624187 = _c96d5b4fb848(
        _b956303f1590=_b956303f1590,
        _5a75fc9b434d=_59bce9310e7d,
        _5f65ed40dd0d=_cbecfa53ca0c._d10766d7b40b,
        _a6993f45886e=_a6993f45886e,
        _c1b5ee1b98c3=_76f61cfc5f31,
        _fab82e675967=_fab82e675967,
    )

    _a1770510d3c6 = 0.0
    _3248219a6976 = [{}]
    _5d6b585cb2c4 = "SUCCESS"
    try:
        _3248219a6976 = _0098b39c3e6e._de982198ff28(_d671ffb8afe2._974bf55a5b0e(_9cbacedf5363._fe1472b7beb8), _38eb6d15afee=_ab689e624187)
        _a1770510d3c6 = _3248219a6976[0]._6b73b6986fc2("test_accuracy", 0.0)
    except _27e13c16945b as _5fec0bac540f:
        _7a1cf1812242._158b0703ba2b(f"Exception during testing: {_5fec0bac540f}")
        _5d6b585cb2c4 = _dc0821e820ac(_5fec0bac540f)

    # Log test metrics to CSV
    _668ee2a1a4eb = f"metrics/{_766f66ac4a08}"
    _5a680431f2a7._5dbcb2a4ef40(_668ee2a1a4eb, _451c47141b9b=_530ea9427bc3)
    _ad810abe4795 = "finetune_results.csv"
    _19edb17f550f = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_668ee2a1a4eb, _ad810abe4795)
    _2ace040843b1 = _f1fa40c7a323._950d5ed2066f()
    _2ace040843b1._3a9c98e9594e("pretrained_embedding_model", _27e89c1f94bd)
    _2ace040843b1._3a9c98e9594e("tokenizer", _27e89c1f94bd)
    _2ace040843b1._3a9c98e9594e("device_dict", _27e89c1f94bd)
    _252a329bc74c = _de0323ad829f()
    _2bbf5a0073f3, _c4fe44f51f05, _2567beb2a166 = _252a329bc74c._e42110d97e3c(_f20ce97f81a0(_c4ad554a2a32 * 1000))
    _6a5a62902db6 = f"{_2bbf5a0073f3} hours, {_c4fe44f51f05} minutes and {_2567beb2a166} seconds"
    _cf8d6dd4d6b9 = "{ " + ", "._69f8f8f43cf3(f"{_51994b123580}: {_d80a1141701d}" for _51994b123580, _d80a1141701d in _2ace040843b1._b54671278a3d()) + " }"
    _a9779a63840e = {
        'accuracy': _a1770510d3c6,
        'params': _cf8d6dd4d6b9,
        'execution_time': _c4ad554a2a32,
        'readable_time': _6a5a62902db6,
        'failure_reason': _5d6b585cb2c4,
        'other_metrics': _4395152355ba._c8bdbe3aab55(_3248219a6976[0])
    }
    with _8c8b24c4974d(_19edb17f550f, 'a+', _35add8005fd7="utf8") as _109054e91a0c:
        _8fb0f925a5c9 = _4bf9cdec8a4c._bb4612b4f09d(_109054e91a0c, _298118bb211c=_a9779a63840e._a88ed79d4e7b())
        if _5a680431f2a7._cf72d5bd330c._51e27944252f(_19edb17f550f) == 0:
            _8fb0f925a5c9._d7565146ac9b()
        _8fb0f925a5c9._b55cd0ed6bd1(_a9779a63840e)
    _7a1cf1812242._c0d027df0993(f"Test accuracy: {_a1770510d3c6}")

    try:
        if _48fe2e3cdd2e(_d671ffb8afe2, 'peft_config') or _58e42f4141ca(_d671ffb8afe2, _77bce0de33fa):
            _7a1cf1812242._c0d027df0993("PEFT/LoRA detected. Merging adapters...")
            try:
                _d671ffb8afe2 = _d671ffb8afe2._0ebb258dc506()
                _7a1cf1812242._c0d027df0993("LoRA adapters merged successfully.")
            except _27e13c16945b as _b3b7d001e46a:
                _7a1cf1812242._3c2a517b6220(f"LoRA merge failed: {_b3b7d001e46a}. Proceeding without merge.")
        else:
            _7a1cf1812242._c0d027df0993("No PEFT/LoRA detected. Skipping merge.")

        if _318eeb629833:
            _7a1cf1812242._c0d027df0993("Dequantizing for CPU save...")
            _d671ffb8afe2 = _d671ffb8afe2._974bf55a5b0e(_60d215b04438="cuda" if _9cbacedf5363._002daf70b691._86f0bb841b51() else "cpu")
            try:
                _d671ffb8afe2 = _0991c8bdbeeb(_d671ffb8afe2)
            except _27e13c16945b as _761b547f8888:
                _7a1cf1812242._3c2a517b6220(f"dequantize_bnb_model failed, using manual_dequantize: {_761b547f8888}")
                _d671ffb8afe2 = _fb6270a3be2a(_d671ffb8afe2)
            _d671ffb8afe2 = _d671ffb8afe2._9effda81892e()
            if _9cbacedf5363._7b25f245fa9d._d7ca2fcab51b():
                _9cbacedf5363._7b25f245fa9d._c5327afa55c1()
            _9617b1acecd6 = _d671ffb8afe2._974bf55a5b0e(_ae1e9f39b02b=_9cbacedf5363._fe1472b7beb8, _60d215b04438="cpu")
            _a7a4c6d5d122 = "saved_models"
            _5a680431f2a7._5dbcb2a4ef40(_a7a4c6d5d122, _451c47141b9b=_530ea9427bc3)
            _55e94831294a = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_a7a4c6d5d122, "finetuned_model.pt")
            _9cbacedf5363._8d22a78c5904(_9617b1acecd6._2f7927b8990d(), _55e94831294a)
            _7a1cf1812242._c0d027df0993(f"Saved lightweight checkpoint at {_55e94831294a}")
    except _27e13c16945b as _5fec0bac540f:
        _7a1cf1812242._158b0703ba2b(f"Exception during model saving: {_5fec0bac540f}")
        _5d6b585cb2c4 += " ; Model saving failed: " + _dc0821e820ac(_5fec0bac540f)
        # Update the CSV with updated failure_reason if needed, but since it's already written, perhaps append another row or update


def _d979da0e8fbb(_cbecfa53ca0c: _c57dd632eb7d._00d99ecc3a3b) -> _27e89c1f94bd:
    _916acc565a42()
    _6cfe0c25823b = _3cc3e89e9eaa()
    _faa66c1267ed = _6cfe0c25823b._a81be813e4fc(_cbecfa53ca0c._8936481b55f9)
    _570c34cd4d06 = _109336777482()
    _7a1cf1812242 = _570c34cd4d06._f391d7649574(_faa66c1267ed)
    _ba642802ec38 = _4d15efcb853e()
    _252a329bc74c = _de0323ad829f()

    _1be4ad5c3825 = _d6784af9f7b9._d6784af9f7b9()

    _fab82e675967 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="app.random_seed", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Seed for reproducibility under app.random_seed"
    )
    _045b88cb3b0e._b20d8d3810de._49966d99acfb(_fab82e675967)
    _b20d8d3810de._49966d99acfb(_fab82e675967)
    _892109dc8c3c._3b67594ebb81(_fab82e675967, _2bb11d61cced=_530ea9427bc3)
    _9cbacedf5363._7b792dc8192d(_fab82e675967)
    if _9cbacedf5363._002daf70b691._86f0bb841b51():
        _9cbacedf5363._002daf70b691._7ede283888d5(_fab82e675967)

    _955d2aa57764 = 0
    if _9cbacedf5363._002daf70b691._86f0bb841b51():
        _4155affad16e = _f20ce97f81a0(_5a680431f2a7._2343ec8fdfb0._6b73b6986fc2('RANK', '0'))
        _03d4a6bc4f68 = _f20ce97f81a0(_5a680431f2a7._2343ec8fdfb0._6b73b6986fc2('WORLD_SIZE', '1'))
        try:
            if not _9cbacedf5363._7b25f245fa9d._d7ca2fcab51b():
                _9cbacedf5363._7b25f245fa9d._555e0c5b99cc(
                    _18916e09e138=_cbecfa53ca0c._18916e09e138, _955d2aa57764=_4155affad16e, _03d4a6bc4f68=_03d4a6bc4f68,
                    _135f3e778f25=_94a2b9458ba9(_ae68842e157b=600)
                )
        except _27e13c16945b:
            pass
    if _9cbacedf5363._7b25f245fa9d._d7ca2fcab51b():
        try:
            _955d2aa57764 = _9cbacedf5363._7b25f245fa9d._1b80f8b85f43()
        except _27e13c16945b:
            _955d2aa57764 = _c93c2392cafe(_cbecfa53ca0c, "local_rank", 0)

    _766f66ac4a08 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="app.model_config_name", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Model config name under app.model_config_name"
    )
    _668ee2a1a4eb = f"metrics/{_766f66ac4a08}"
    _5a680431f2a7._5dbcb2a4ef40(_668ee2a1a4eb, _451c47141b9b=_530ea9427bc3)

    _89a6cda12928 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.pretrained_embedding", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _eb7590f9fbb7 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="app.pretrained_embeddings_dir", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _2e77bce8cc5d = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.pretrained_embedding_overwrite_old", _ae1e9f39b02b=_86c4e2144707, _2a1634cdfea9=_0a812bf64d05, _5139b8d092c1=_0a812bf64d05,
        _58e1ed45211f="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _318eeb629833 = _0a812bf64d05
    _c2728c52749f = _27e89c1f94bd
    _a6993f45886e = _0a812bf64d05
    _fc89335e89bb = _27e89c1f94bd
    if _1fd513e6eb91:
        try:
            _c2728c52749f = _8965fe43149c(
                _845a06aea0d2=_530ea9427bc3,
                _a2450a809f4b=_6e78312b6d0a(),
                _1e2de815ce4e=_530ea9427bc3,
                _62bce263b2b7="nf4",
            )
            _318eeb629833 = _530ea9427bc3
        except _27e13c16945b:
            _c2728c52749f = _27e89c1f94bd

    _1d3c0d50596c = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(
        _eb7590f9fbb7,
        _89a6cda12928 + ("_quantized" if _1fd513e6eb91 else "_fp32")
    )

    _ba642802ec38._b49fc05a3903(_1d3c0d50596c, _86cd2f53e73d=_2e77bce8cc5d)
    if _ba642802ec38._cef4add3313f(_1d3c0d50596c):
        _7a1cf1812242._c0d027df0993(f"Downloading pretrained embedding {_89a6cda12928}")
        try:
            from _407181800cc6 import _f660509a8fe0, _f393f294df26
            _9912af3ff5f7 = _f660509a8fe0()
            _92776947532a = _9912af3ff5f7._92776947532a(_89a6cda12928)
            _5d265b0d931c = _c93c2392cafe(_92776947532a, "sha", _27e89c1f94bd) or _27e89c1f94bd
            if "llama" in _89a6cda12928._4827b48ff6c7():
                _c36c0136f3ba = _5a680431f2a7._b757a98e8cb2("HF_LLAMA3B_TOKEN")
                if _c36c0136f3ba:
                    _f393f294df26(_859e0eb3a929=_c36c0136f3ba)
                else:
                    raise _8ef09a48cace("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _27e13c16945b:
            _5d265b0d931c = _27e89c1f94bd
        from _28d8fb241414 import _34e213828189
        _efe5ba2c504d = _34e213828189._adc155ac9647(_89a6cda12928, _5d265b0d931c=_5d265b0d931c)
        _7a1cf1812242._c0d027df0993(f"config of pretrained embedding used {_efe5ba2c504d}")
        if "llama" in _89a6cda12928._4827b48ff6c7():
            from _28d8fb241414 import _d2bab86c3af3, _92c1c13f60e0
            _fc9572d5aa49 = _d2bab86c3af3._adc155ac9647(
                _89a6cda12928, _5d265b0d931c=_5d265b0d931c,
                _72ccdd022a84=_c2728c52749f if (_1fd513e6eb91 and _c2728c52749f) else _27e89c1f94bd
            )
            _76f61cfc5f31 = _92c1c13f60e0._adc155ac9647(_89a6cda12928, _5d265b0d931c=_5d265b0d931c, _c5377a19e4f7=_0a812bf64d05)
            _a6993f45886e = _530ea9427bc3
            _fc89335e89bb = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _28d8fb241414 import _2066f6f30f6b, _92c1c13f60e0
            _fc9572d5aa49 = _2066f6f30f6b._adc155ac9647(_89a6cda12928, _5d265b0d931c=_5d265b0d931c)
            _76f61cfc5f31 = _92c1c13f60e0._adc155ac9647(_89a6cda12928, _5d265b0d931c=_5d265b0d931c)
            _a6993f45886e = _0a812bf64d05
        try:
            with _8c8b24c4974d(_5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_1d3c0d50596c, 'revision.txt'), 'w') as _3d062a37d65f:
                _3d062a37d65f._43aed60e1454(_5d265b0d931c)
            _fc9572d5aa49._4279bc4e9622(_1d3c0d50596c)
            _76f61cfc5f31._4279bc4e9622(_1d3c0d50596c)
        except _27e13c16945b:
            _7a1cf1812242._3c2a517b6220("Saving pretrained embedding locally failed; continuing.")
    else:
        _7a1cf1812242._c0d027df0993(f"Loading pretrained embedding from {_1d3c0d50596c}")
        from _28d8fb241414 import _34e213828189
        _efe5ba2c504d = _34e213828189._adc155ac9647(_1d3c0d50596c)
        _7a1cf1812242._c0d027df0993(f"Config of pretrained embedding used {_efe5ba2c504d}")
        if "llama" in _89a6cda12928._4827b48ff6c7():
            from _28d8fb241414 import _d2bab86c3af3, _92c1c13f60e0
            _fc9572d5aa49 = _d2bab86c3af3._adc155ac9647(
                _1d3c0d50596c,
                _72ccdd022a84=_c2728c52749f if (_1fd513e6eb91 and _c2728c52749f) else _27e89c1f94bd
            )
            _76f61cfc5f31 = _92c1c13f60e0._adc155ac9647(_1d3c0d50596c, _c5377a19e4f7=_0a812bf64d05)
            _a6993f45886e = _530ea9427bc3
            _fc89335e89bb = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _28d8fb241414 import _2066f6f30f6b, _92c1c13f60e0
            _fc9572d5aa49 = _2066f6f30f6b._adc155ac9647(_1d3c0d50596c)
            _76f61cfc5f31 = _92c1c13f60e0._adc155ac9647(_1d3c0d50596c)
            _a6993f45886e = _0a812bf64d05

    _30f43f93021b = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.max_seq_len", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Maximum sequence length for training"
    )
    _59bce9310e7d = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.batch_size", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Batch size for training"
    )
    _fd1cba7bba59 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.data_sample_share", _ae1e9f39b02b=_9effda81892e, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Proportion of dataset used for sampling"
    )
    _6ad88489d45d = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.optimizer", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Optimizer type under run_config.optimizer"
    )
    _b90f7d931d7d = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.learning_rate", _ae1e9f39b02b=_9effda81892e, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Learning rate for optimizer"
    )
    _2e0f3255f671 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.num_backbone_model_units_unfrozen", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Number of backbone model units unfrozen during training"
    )
    _f96878c2890f = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.loss_type", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Loss function type under run_config.loss_type"
    )
    _efd0871fe147 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.num_fc_layers_in_classifier_head", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Number of FC layers in classifier head"
    )
    _33ee6b296f58 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.activation_function_for_layer", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Activation function for layer under run_config.activation_function_for_layer"
    )
    _d0b0dbe774fe = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.add_dropout_after_embedding", _ae1e9f39b02b=_86c4e2144707, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _259feb737600 = _0a812bf64d05 if _2e0f3255f671 == 0 else _530ea9427bc3

    _f1fa40c7a323: _5db2953a5f43[_dc0821e820ac, _0b2f858ac64c] = {
        "device_dict": _fdd30da26c7d(),
        "pretrained_embedding_model": _fc9572d5aa49,
        "optimizer": _6ad88489d45d,
        "num_backbone_model_units_unfrozen": _2e0f3255f671,
        "loss_type": _f96878c2890f,
        "lr": _b90f7d931d7d,
        "is_train": _530ea9427bc3,
        "tokenizer": _76f61cfc5f31,
        "random_seed": _fab82e675967,
        "num_fc_layers": _efd0871fe147,
        "activation_function_for_layer": _33ee6b296f58,
        "add_dropout_after_embedding": _d0b0dbe774fe,
    }
    _f1fa40c7a323._cb6e11e40932({"pretrained_model_embedding_name": _89a6cda12928})
    if _a6993f45886e:
        _f1fa40c7a323._cb6e11e40932({"prompt_length": _30f43f93021b})

    _28de8977c472 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="app.data_dir", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Base data directory under app.data_dir"
    )
    _d6f0151a45f2 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="dataset.data_source_dir",
        _ae1e9f39b02b=_dc0821e820ac,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Base data source directory under data."
    )
    _8781d47b0d75 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="dataset.train.data_dir", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Subdirectory for training data under dataset.train.data_dir"
    )
    _5c0f059f7c65 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="dataset.val.data_dir", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Subdirectory for validation data under dataset.val.data_dir"
    )
    _b81aca009fc8 = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_28de8977c472, _d6f0151a45f2, _8781d47b0d75)
    _e23e22b0d8fc = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_28de8977c472, _d6f0151a45f2, _5c0f059f7c65)
    _a77205f72de8 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="dataset.files_have_header", _ae1e9f39b02b=_86c4e2144707, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Whether dataset files have header"
    )
    _5a9f599d536d = f"config/{_766f66ac4a08}/finetune/classes_config.json"
    _ba642802ec38._b49fc05a3903(_5a680431f2a7._cf72d5bd330c._0a08c7c2c517(_5a9f599d536d))

    _b8bbebdd0c82 = _de3c2dfa4384(
        _28de8977c472=_b81aca009fc8, _a77205f72de8=_a77205f72de8, _7a1cf1812242=_7a1cf1812242,
        _76f61cfc5f31=_76f61cfc5f31, _81826eb94bad=_30f43f93021b,
        _5a9f599d536d=_5a9f599d536d, _2f6969f83de2=_530ea9427bc3, _215177c7da5f=_0a812bf64d05,
        _fab82e675967=_fab82e675967, _7c279799e9ab=_fd1cba7bba59,
        _5f65ed40dd0d=_cbecfa53ca0c._d10766d7b40b, _a6993f45886e=_a6993f45886e, _fc89335e89bb=_fc89335e89bb,
    )
    _098478fb75bd = _de3c2dfa4384(
        _28de8977c472=_e23e22b0d8fc, _a77205f72de8=_a77205f72de8, _7a1cf1812242=_7a1cf1812242,
        _76f61cfc5f31=_76f61cfc5f31, _81826eb94bad=_30f43f93021b,
        _5a9f599d536d=_5a9f599d536d, _2f6969f83de2=_0a812bf64d05, _215177c7da5f=_0a812bf64d05,
        _fab82e675967=_fab82e675967, _7c279799e9ab=_fd1cba7bba59,
        _5f65ed40dd0d=_cbecfa53ca0c._d10766d7b40b, _a6993f45886e=_a6993f45886e, _fc89335e89bb=_fc89335e89bb,
    )
    _7a1cf1812242._c0d027df0993(f"Number of training data samples {_b8bbebdd0c82._828bdf0acd07()} with {_c93c2392cafe(_b8bbebdd0c82, 'label_sample_counter', 'NA')} labels and {_c93c2392cafe(_b8bbebdd0c82, 'actual_dataset_length', 'NA')} unique samples with {_c93c2392cafe(_b8bbebdd0c82, 'actual_num_of_labels', 'NA')} unique labels")
    _7a1cf1812242._c0d027df0993(f"Number of validation data samples {_098478fb75bd._828bdf0acd07()} with {_c93c2392cafe(_098478fb75bd, 'label_sample_counter', 'NA')} labels and {_c93c2392cafe(_098478fb75bd, 'actual_dataset_length', 'NA')} unique samples with {_c93c2392cafe(_098478fb75bd, 'actual_num_of_labels', 'NA')} unique labels.")

    _c442a8ed4fd7 = _b8bbebdd0c82._af1dde2bd33e()
    _0821daf23a96 = [_b8bbebdd0c82._c14be34d8dcc(_2ad7b9d89031) for _2ad7b9d89031 in _b8bbebdd0c82._df290e11033c._a88ed79d4e7b()]
    _15e3bcb7fb5d = _b8bbebdd0c82._15e3bcb7fb5d
    _429af990f4c2 = {}
    for _97576e89101c, (_de1660d05e4b, _429eb8729aad) in _1321c8d95a45(_ea88668492b8(_0821daf23a96, _15e3bcb7fb5d)):
        _eb65a1766cfa = _76f61cfc5f31(_de1660d05e4b, _4cfea44ecdcd=_0a812bf64d05)["input_ids"] if _a6993f45886e else [_97576e89101c]
        if _eb65a1766cfa:
            _429af990f4c2[_de1660d05e4b] = [_eb65a1766cfa, _429eb8729aad]
    _4eaf72fae1dd(f"Class Weights Generated {_429af990f4c2}")
    _7a1cf1812242._c0d027df0993(f"{_c442a8ed4fd7} classes in training data with classes {_0821daf23a96} and weights {_15e3bcb7fb5d}")
    _f1fa40c7a323._cb6e11e40932({"class_weights": _429af990f4c2, 
                   "class_names": _0821daf23a96,
                   "model_config_name": _766f66ac4a08})

    if "llama" in _89a6cda12928 and _a6993f45886e:
        _d671ffb8afe2 = _dbef95cf6f38(**_f1fa40c7a323)
    else:
        _d671ffb8afe2 = _6ebb9c9a87fb(**_f1fa40c7a323)

    _511e9ec486cb = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed,
        _12caf4956f53="operation_mode",
        _ae1e9f39b02b=_dc0821e820ac,
        _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _bf1aa65e23d1 = _27e89c1f94bd
    if _511e9ec486cb == "model_finetune":
        _bf1aa65e23d1 = _20dfe41ade34(
            _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.finetuned_model_path", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_0a812bf64d05,
            _58e1ed45211f="Optional path to pretrained model checkpoint for finetuning"
        )
        if _bf1aa65e23d1:
            _3c678af32234(_d671ffb8afe2, _bf1aa65e23d1, _091181878c03="cpu")
            _7a1cf1812242._c0d027df0993(f"Loaded finetuned model from {_bf1aa65e23d1}")

    _73e1a2f94b15 = []
    if _259feb737600:
        if _318eeb629833:
            _78afde1050a4 = lambda _ec4a356c5974: (
                _48fe2e3cdd2e(_ec4a356c5974, "weight") and
                _58e42f4141ca(_ec4a356c5974._429eb8729aad, _9cbacedf5363._617c126ad495) and
                _ec4a356c5974._429eb8729aad._4f157c9b1ca6() > 64 and
                not _58e42f4141ca(_ec4a356c5974, (_cd72ece522cc._45c0f0c73d6e._8988778e400b, _cd72ece522cc._45c0f0c73d6e._1cf76b53eb79, _cd72ece522cc._45c0f0c73d6e._872c4dcbdb5b))
            )
        else:
            _78afde1050a4 = lambda _ec4a356c5974: (
                _48fe2e3cdd2e(_ec4a356c5974, "weight") and
                _58e42f4141ca(_ec4a356c5974._429eb8729aad, _9cbacedf5363._617c126ad495) and
                _ec4a356c5974._429eb8729aad._4f157c9b1ca6() > 64
            )
        _b8fd704fc2a2 = _d671ffb8afe2._e84411c1f867
        _8a82df0cadd9 = _846a3f8305ba(_b8fd704fc2a2, _78afde1050a4=_78afde1050a4, _ad29eaaaf32d=_27e89c1f94bd, _9cec6f369a34=_27e89c1f94bd)
        try:
            _9d9907bba97d = _9b7fb1ec1e81._291c240152b8 if _a6993f45886e else _9b7fb1ec1e81._e1d56d43cccb
            _a566dd776cb5 = _80b03e35b4fa(_27e89c1f94bd, _8a82df0cadd9, _9d9907bba97d)
        except _27e13c16945b:
            _a566dd776cb5 = _7f1aaa343e1f(
                _d3a3fbc97a9d=8, _e6512413baa0=32, _4a63b0725dcf=0.1,
                _8a82df0cadd9=_deb55bfe8532(_8a82df0cadd9._a88ed79d4e7b()) if _8a82df0cadd9 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _59c30f9a8414=_9b7fb1ec1e81._291c240152b8 if _a6993f45886e else _9b7fb1ec1e81._e1d56d43cccb
            )
        _7a1cf1812242._c0d027df0993(f"Target Module trainable parameters before applying LORA is {_7f9b54bfa526(_b8fd704fc2a2)} and size is {_5f7c1233f268(_b8fd704fc2a2)} GB")
        _b8fd704fc2a2 = _2aa2dd6bc868(_b8fd704fc2a2, _a566dd776cb5)
        for _12caf4956f53, _ef71fc15f1e6 in _d671ffb8afe2._687652b2dd52():
            if not _ef71fc15f1e6._ea95212859de:
                _ef71fc15f1e6 = _ef71fc15f1e6._9e1fe8ca4dbe()
            if "encoder" in _12caf4956f53 and "lora" not in _12caf4956f53:
                _ef71fc15f1e6._1349f9ec5098 = _0a812bf64d05
            elif "embedding" in _12caf4956f53:
                _ef71fc15f1e6._1349f9ec5098 = "lora" in _12caf4956f53
        _7a1cf1812242._c0d027df0993(f"Target Module trainable parameters after applying LORA is {_7f9b54bfa526(_b8fd704fc2a2)} and size is {_5f7c1233f268(_b8fd704fc2a2)} GB")

    _8e3d93cfca95 = _f20ce97f81a0(_453796e171f2())
    _a6f1b5938618 = 'gpu' if _9cbacedf5363._002daf70b691._86f0bb841b51() else 'cpu'
    _52e5355d4310 = f"cuda:{_8e3d93cfca95}" if _a6f1b5938618 == 'gpu' else 'cpu'
    if _4dcf720601a0._031bb1dfe372() is _0a812bf64d05:
        _7a1cf1812242._c0d027df0993(f"Setting model to {_52e5355d4310}")
        _d671ffb8afe2 = _d671ffb8afe2._974bf55a5b0e(_ae1e9f39b02b=_9cbacedf5363._fe1472b7beb8, _60d215b04438=_52e5355d4310)

    _b65412e2089a = {}
    _b65412e2089a['model_name'] = _766f66ac4a08
    _440d64ef90c5 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="model.max_epochs", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Maximum number of epochs under model.max_epochs"
    )
    _b65412e2089a['max_epochs'] = _440d64ef90c5
    _9bd0d866a0b4 = _f104fe4f8470._5bca8b70909f(_91739f3ce456=2)
    _718d3755beea = "epoch_training_metrics.csv"
    _3ccedc42311e = "model_training_summary_metrics.csv"
    _c669a872154a = _acecb220a8ea(_7a1cf1812242,
                                       _9bd0d866a0b4=_9bd0d866a0b4,
                                       _b65412e2089a=_b65412e2089a,
                                       _881036c6df3d=_668ee2a1a4eb,
                                       _a9c1c108d193=_718d3755beea,
                                       _282019829f38=_3ccedc42311e,
                                       _07ab1addaa9e=_27e89c1f94bd)
    _115570bd8249 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="app.checkpoints_dir", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _02160aafcf3d = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_115570bd8249, _766f66ac4a08, "finetune")
    _5a680431f2a7._5dbcb2a4ef40(_02160aafcf3d, _451c47141b9b=_530ea9427bc3)
    _3306a3464ef7 = _f104fe4f8470._e3568179df50(_8e701ca8347c=_02160aafcf3d, _190847baf69f="intermediate",
        _dad4c3affea4=1, _7faa6fde094d=1000, _c3ca89c7a16f=_0a812bf64d05)
    _c9c72c43e430 = _f104fe4f8470._e3568179df50(_8e701ca8347c=_02160aafcf3d, _190847baf69f="last", _dad4c3affea4=1,
        _c3ca89c7a16f=_530ea9427bc3, _b3f99098bf26="val_loss", _9de7eb770ed3="min")
    _970cd4883684 = _f104fe4f8470._986375f35ed8(_b3f99098bf26="val_accuracy", _4eeccd39449b=3, _9de7eb770ed3="max", _293a0175eaac=_530ea9427bc3)
    _6442a27b5f38 = _f104fe4f8470._cd0d8c18b3f4(_0a03bea44865='step')

    for _12caf4956f53, _dff0396f1474 in _d671ffb8afe2._687652b2dd52():
        if not _dff0396f1474._1349f9ec5098:
            _73e1a2f94b15._1e736980458b(_dff0396f1474)
    _ed59e8ed7f7a = _13364ba6a753(_523af454aedc=_73e1a2f94b15) if _a6f1b5938618 == "gpu" else "auto"
    _b73f235e070d = _cbecfa53ca0c._b73f235e070d

    _505705c4f662 = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.accumulate_grad_batches", _ae1e9f39b02b=_f20ce97f81a0, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _fb261fa33b5f = _20dfe41ade34(
        _faa66c1267ed=_faa66c1267ed, _12caf4956f53="run_config.training_precision_type", _ae1e9f39b02b=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3,
        _58e1ed45211f="Training precision type under run_config.training_precision_type"
    )
    _da51f791c7b8 = _32871f12a74a(
        _d8a9659ee77e=_a6f1b5938618, _c410c850eca9=_c41fd0d12ba7(_a6f1b5938618),
        _b73f235e070d=_b73f235e070d, _d18479a67f41=_ed59e8ed7f7a if _a6f1b5938618 == "gpu" else "auto",
        _440d64ef90c5=_440d64ef90c5, _19321a093309=_0a812bf64d05, _a6b98e8b124c=_530ea9427bc3,
        _f71df9b98655=_530ea9427bc3, _473b14b6b09d=_0a812bf64d05,
        _505705c4f662=_505705c4f662,
        _1dcb23139626=_fb261fa33b5f,
        _f104fe4f8470=[_c669a872154a, _3306a3464ef7, _c9c72c43e430, _970cd4883684, _6442a27b5f38],
    )

    _5ee1cbfa21e6 = _c96d5b4fb848(
        _b8bbebdd0c82=_b8bbebdd0c82, _098478fb75bd=_098478fb75bd,
        _27ae59362ff7=_530ea9427bc3, _c1b5ee1b98c3=_76f61cfc5f31,
        _5a75fc9b434d=_59bce9310e7d, _5f65ed40dd0d=_cbecfa53ca0c._d10766d7b40b,
        _a6993f45886e=_a6993f45886e, _fab82e675967=_fab82e675967
    )

    if _8e3d93cfca95 == 0:
        _3575102316c7 = _eaf0428c3884(_d671ffb8afe2)
        _7a1cf1812242._c0d027df0993(f"Model Summary before fit is {_3575102316c7}")
        _7a1cf1812242._c0d027df0993(f"Model structure is {_d671ffb8afe2}")

    _9b5512786072 = _5a680431f2a7._cf72d5bd330c._69f8f8f43cf3(_02160aafcf3d, "intermediate.ckpt")
    if _5a680431f2a7._cf72d5bd330c._9587bfd6c084(_9b5512786072):
        _da51f791c7b8._630e6fc58864(_d671ffb8afe2, _38eb6d15afee=_5ee1cbfa21e6, _7b3ecbf9a61a=_9b5512786072)
    else:
        _da51f791c7b8._630e6fc58864(_d671ffb8afe2, _38eb6d15afee=_5ee1cbfa21e6)

    if _9cbacedf5363._7b25f245fa9d._d7ca2fcab51b():
        _9cbacedf5363._7b25f245fa9d._c5327afa55c1()
    _488426c0ced5 = _c9c72c43e430._205528e27070
    if _488426c0ced5:
        _7a1cf1812242._c0d027df0993(f"Best checkpoint saved at {_488426c0ced5}")

    _c4ad554a2a32 = _d6784af9f7b9._d6784af9f7b9() - _1be4ad5c3825
    # Run test set
    _2d4dd8ebfec2(_cbecfa53ca0c, _faa66c1267ed, _f1fa40c7a323, _488426c0ced5, _76f61cfc5f31, _fc9572d5aa49, _30f43f93021b, _a6993f45886e, _fc89335e89bb, _259feb737600, _7a1cf1812242, _1dcb23139626=_fb261fa33b5f, _c4ad554a2a32=_c4ad554a2a32)

    _7a1cf1812242._c0d027df0993("Finetuning completed successfully.")


def _a6667bebc2a0():
    _4797a0a34625 = _c57dd632eb7d._76ed04ab8ccb(_2771c76c2a35='Fine-tune a language identification model (single run)')
    _4797a0a34625._57fd04c7edee('--config_file_path', _5208b41a596c=_dc0821e820ac, _2a1634cdfea9=_530ea9427bc3)
    _4797a0a34625._57fd04c7edee('--num_nodes', _5208b41a596c=_f20ce97f81a0, _5139b8d092c1=1)
    _4797a0a34625._57fd04c7edee('--cpu_cores', _5208b41a596c=_f20ce97f81a0, _5139b8d092c1=1)
    _4797a0a34625._57fd04c7edee('--local-rank', _5208b41a596c=_f20ce97f81a0)
    _4797a0a34625._57fd04c7edee('--backend', _5208b41a596c=_dc0821e820ac, _5139b8d092c1="gloo", _d5eefcdaf04f=['gloo', 'mpi', 'nccl'])
    _4797a0a34625._57fd04c7edee('--run_timestamp', _5208b41a596c=_9effda81892e, _5139b8d092c1=_27e89c1f94bd)
    _cbecfa53ca0c = _4797a0a34625._f331c6d1a5ac()
    if _cbecfa53ca0c._376952a852cb is _27e89c1f94bd:
        _cbecfa53ca0c._376952a852cb = _d6784af9f7b9._d6784af9f7b9()
    _683a85ffe46e(_cbecfa53ca0c)


if __name__ == "__main__":
    _8a710ab20e86()