# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:59 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from __future__ import _7fd78cb223a0
from _2e834d398d99 import _5ac7c9263a3d
import _48c48a447abf, _7648c75c4980, json, os, random, _95f1abb5972a, sys, time, _1fde715f31eb
from _a9e98400d5f5 import _7fbe1d0ff3e5
from typing import _c6149b3c45ff, _faa26acb1d94, _9ea72954e94e
import _489c88e5824b as _f839a5a8c2ee, _5d88ddcdd444, _e3c692ff6883 as _165eaca90fb0
from _e3c692ff6883 import _78b7b55ecb2b
from _e3c692ff6883._e6b43f4e93e7 import _06ffd9b122c8
from _e3c692ff6883._e6b43f4e93e7._85a2166c4515._d033d1ee65c1 import _98bcfb6df346
from _4857b250f010 import _99c452a195fd, _fc0f247db53b, _cbdb35de4ee2
from _24c7a812d668._ee6bc10745e2._ec1a152ffeda._f0d38cf45384 import _3c705456c323
from _24c7a812d668._ee6bc10745e2._ec1a152ffeda._3917ab7c40a0 import _ca1a11f4de84
from _24c7a812d668._ee6bc10745e2._ec1a152ffeda._e6f3c372cec3 import _d90ef3c1c995
from _24c7a812d668._ee6bc10745e2._ec1a152ffeda._7d1a3ade4313 import _09eba5ed324f
from _24c7a812d668._ee6bc10745e2._872b1ad84e10._ae9dc4b5df99 import _7f24fd7ec938
from _24c7a812d668._ee6bc10745e2._872b1ad84e10._974a9c61cf66 import _88789e59437c
from _24c7a812d668._ee6bc10745e2._fbf1faceecbe._f97a6a381a92 import _d35997a5f5c0
from _24c7a812d668._ee6bc10745e2._fbf1faceecbe._82f40b554cd1 import _390c12fc7ede
from _24c7a812d668._ee6bc10745e2._06ffd9b122c8._dbbe4c481984 import _8bbc4fe348f0
from _24c7a812d668._ee6bc10745e2._ec1a152ffeda._4976a899ce9c import _8d1ccefcac4a
from _24c7a812d668._ee6bc10745e2._ec1a152ffeda._4976a899ce9c import (
    _71b3fbd2d52f, _71cd5f8918b1, _182eba580fa1,
    _76f99b44ea47, _6d92a6132702, _4bf357c628ab,
    _ecfb24ff70c1, _0ebb9ed9a860, _38f2f5e527ca,
    _dd76cf17db5b, _16a1d3838dde, _1687a7e0f4a1,
    _1cb95ab170a0, _2215936c6098
)

os._902afdb47993["TOKENIZERS_PARALLELISM"] = "True"
_e961e7dd79e5 = _5d88ddcdd444._2ab833a74284._fddc86e146c8() and _5d88ddcdd444._2ab833a74284._f72d4b03c4f3() > 0
if _e961e7dd79e5:
    try:
        from _90f5849b033e import _8644cacb823a
        import _7a33a38655a0 as _7668f055d4fb
    except _9cb8b429af51:
        _7668f055d4fb = _897774774bf9


def _3e4417d190f6(_12d68a1b5965: _5d88ddcdd444._2e303dc0f368._8e64e6e9e0c0, _f878cc391eae: _06cfcd6520f7, _92a6efb31cee: _9ea72954e94e[_06cfcd6520f7] = _897774774bf9) -> _897774774bf9:
    if not os._e1116d9ab641._e2588cd4fc58(_f878cc391eae):
        raise _52dc3d237613(f"Finetuned model path not found: {_f878cc391eae}")
    if _f878cc391eae._73ad31791226((".pt", ".pth")):
        _5b019276a8f7 = _92a6efb31cee or ("cpu" if not _5d88ddcdd444._2ab833a74284._fddc86e146c8() else _897774774bf9)
        _4f1831ad379f = _5d88ddcdd444._27d6972e4591(_f878cc391eae, _92a6efb31cee=_5b019276a8f7)
        _97a0dfba8aa9 = _4f1831ad379f._b411d07c23e2("state_dict", _4f1831ad379f._b411d07c23e2("model_state_dict", _4f1831ad379f)) if _c3afb80cdbfc(_4f1831ad379f, _497831814215) else _4f1831ad379f
        if not _c3afb80cdbfc(_97a0dfba8aa9, _497831814215):
            raise _6ec6340596e1(f"Loaded .pt file does not contain state_dict mapping: {_f878cc391eae}")
        _12d68a1b5965._6001a2cf6d5e(_97a0dfba8aa9, _28a117de9d37=_1cfaa47edaac)
    elif _f878cc391eae._73ad31791226(".ckpt"):
        try:
            if _8857e71d5b46(_12d68a1b5965._e765370be702, "load_from_checkpoint"):
                _bed41a582a35 = _12d68a1b5965._e765370be702._fbf69d0b3ffc(_f878cc391eae, **{})
                _12d68a1b5965._6001a2cf6d5e(_bed41a582a35._86950b824d74(), _28a117de9d37=_1cfaa47edaac)
                return
            _4f1831ad379f = _5d88ddcdd444._27d6972e4591(_f878cc391eae, _92a6efb31cee="cpu")
            _97a0dfba8aa9 = _4f1831ad379f._b411d07c23e2("state_dict", _4f1831ad379f)
            if not _c3afb80cdbfc(_97a0dfba8aa9, _497831814215):
                raise _6ec6340596e1("Lightning checkpoint did not contain a recognizable state_dict.")
            _12d68a1b5965._6001a2cf6d5e(_97a0dfba8aa9, _28a117de9d37=_1cfaa47edaac)
        except _9cb8b429af51 as _a5b8903d5501:
            raise _6ec6340596e1(f"Failed to load .ckpt into model: {_a5b8903d5501}") from _a5b8903d5501
    else:
        raise _7ca7be276141("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _932b7ee9e8cd(_74c9376782b8: _48c48a447abf._30809889d045, _703660960005: _c6149b3c45ff, _c35664564dfa: _faa26acb1d94[_06cfcd6520f7, _c6149b3c45ff], _0cc253b2ae81: _06cfcd6520f7, _8476f1faf605: _c6149b3c45ff, _4e5ea11dedc9: _c6149b3c45ff, _27ab11b36962: _1ac1e91bbed8, _019a31db9dbb: _55ac509dba47, _ab20a0cbe2b7: _c6149b3c45ff, _4279925e6f08: _55ac509dba47, _8cf760759c38: _5ac7c9263a3d, _d62164463983: _06cfcd6520f7 = "32", _786a861e26d9: _bbdbf3bd1ca4 = 0.0):
    """
    Compute test accuracy using the best checkpoint.
    """
    _af8e680dfa0b = _1cfaa47edaac
    _b40d7c7a97d8 = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="app.model_config_name",
        _78da8ebbcb40=_06cfcd6520f7,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )

    if _e961e7dd79e5:
        _0a08100e76d9 = _8644cacb823a(
            _641560dbb956=_668364b7222e,
            _fe0180f48c35=_182eba580fa1(),
            _f14160b115b8=_668364b7222e,
            _c3ed6061d9be="nf4",
        )
        _af8e680dfa0b = _668364b7222e

    _c5a85ca873ff = 'gpu' if _5d88ddcdd444._2ab833a74284._fddc86e146c8() else 'cpu'
    _d6a543fae36d = 'cpu'
    if _c5a85ca873ff == 'gpu':
        _c1906bf18fbf = _5d88ddcdd444._b3a91ee4a2e2._6595c6d5d03f() if _5d88ddcdd444._b3a91ee4a2e2._014db6a95ff3() else 0
        _d6a543fae36d = f"cuda:{_c1906bf18fbf}"
    else:
        _c1906bf18fbf = -1

    _5598dbe3a29a = _c35664564dfa._b411d07c23e2("pretrained_model_embedding_name")

    _c35664564dfa._f325fb443a36({
        "tokenizer": _8476f1faf605,
        "pretrained_embedding_model": _4e5ea11dedc9,
        "device_dict": _71cd5f8918b1(),
        "model_config_name": _b40d7c7a97d8,
    })

    if not _0cc253b2ae81:
        _8cf760759c38._b47d3e75126d("No best checkpoint found. Proceeding with current model weights.")
    else:
        _8cf760759c38._b47d3e75126d(f"Testing with best checkpoint: {_0cc253b2ae81}")

    if "llama" in (_5598dbe3a29a or ""):
        _12d68a1b5965 = _390c12fc7ede(**_c35664564dfa)
        _019a31db9dbb = _668364b7222e
    else:
        _12d68a1b5965 = _d35997a5f5c0(**_c35664564dfa)

    if _4279925e6f08:
        if _af8e680dfa0b:
            _0153e26218cb = lambda _9d5fc5e383c8: (
                _8857e71d5b46(_9d5fc5e383c8, "weight") and _c3afb80cdbfc(_9d5fc5e383c8._0eddf4b2303a, _5d88ddcdd444._fb27b18bfafd) and _9d5fc5e383c8._0eddf4b2303a._cf5a8dd86b5f() > 64 and
                not _c3afb80cdbfc(_9d5fc5e383c8, (_7668f055d4fb._2e303dc0f368._0b170cbfc388, _7668f055d4fb._2e303dc0f368._01d06221652d, _0039e1cd49fd(_7668f055d4fb._2e303dc0f368, "LinearNF4", _972af1e69193(_897774774bf9))))
            )
        else:
            _0153e26218cb = lambda _9d5fc5e383c8: (
                _8857e71d5b46(_9d5fc5e383c8, "weight") and _c3afb80cdbfc(_9d5fc5e383c8._0eddf4b2303a, _5d88ddcdd444._fb27b18bfafd) and _9d5fc5e383c8._0eddf4b2303a._cf5a8dd86b5f() > 64
            )
        _5ce631acb74f = _12d68a1b5965._d0f45acbf69b
        _5fb3f7792974 = _76f99b44ea47(_5ce631acb74f, _0153e26218cb=_0153e26218cb, _1c7e26b8e378=_897774774bf9, _2c90a9202260=_897774774bf9)
        _b48b6f85bd2e = _fc0f247db53b(
            _695c1c1997c7=8,
            _cfbe7c177aed=32,
            _12dabed36637=0.1,
            _5fb3f7792974=_339488fc64dc(_5fb3f7792974._09cfa1188a58()) if _5fb3f7792974 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _22654f4af963=_99c452a195fd._1320994fa637 if _019a31db9dbb else _99c452a195fd._548e7c94173e
        )
        _8cf760759c38._b47d3e75126d(f"In test Target Module trainable parameters before applying LORA: {_6d92a6132702(_5ce631acb74f)}")
        _5ce631acb74f = _4bf357c628ab(_5ce631acb74f, _b48b6f85bd2e)
        _8cf760759c38._b47d3e75126d(f"In test Target Module trainable parameters after applying LORA: {_6d92a6132702(_5ce631acb74f)}")

    if _0cc253b2ae81:
        _8cf760759c38._b47d3e75126d(f"Loading checkpoint from: {_0cc253b2ae81}")
        try:
            _4f1831ad379f = _5d88ddcdd444._27d6972e4591(_0cc253b2ae81, _92a6efb31cee=_d6a543fae36d)
            _97a0dfba8aa9 = _4f1831ad379f._b411d07c23e2("state_dict", _4f1831ad379f)
            # Strip prefixes
            _f65fd7083ada = {}
            for _51d85062b475, _a954a3d1259b in _97a0dfba8aa9._5ad911059bb3():
                _220fd3e3424d = _51d85062b475
                while _220fd3e3424d._9dec450d8f5a('module.'):
                    _220fd3e3424d = _220fd3e3424d[7:]
                while _220fd3e3424d._9dec450d8f5a('_forward_module.'):
                    _220fd3e3424d = _220fd3e3424d[16:]
                _f65fd7083ada[_220fd3e3424d] = _a954a3d1259b
            # Load with strict=False to handle potential extras
            _12d68a1b5965._6001a2cf6d5e(_f65fd7083ada, _28a117de9d37=_1cfaa47edaac)
        except _9cb8b429af51 as _a5b8903d5501:
            _8cf760759c38._a61d57862e21(f"Checkpoint load failed: {_a5b8903d5501}")
    else:
        _8cf760759c38._a61d57862e21("No best checkpoint found. Proceeding with in-memory model weights.")

    if _5d88ddcdd444._2ab833a74284._fddc86e146c8():
        _c1906bf18fbf = _1ac1e91bbed8(_71b3fbd2d52f())

    if _98bcfb6df346._72fea19dd882() is _1cfaa47edaac:
        _8cf760759c38._b47d3e75126d(f"Setting model to {_d6a543fae36d}")
        _12d68a1b5965 = _12d68a1b5965._f45be68cc3b7(_78da8ebbcb40=_5d88ddcdd444._2dbc590a6cb2, _627226216ac6=_d6a543fae36d)

    _559d365361f4 = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="app.data_dir",
        _78da8ebbcb40=_06cfcd6520f7,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="data_dir under app specifies the base directory for datasets."
    )

    _54522828a6b7 = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="dataset.data_source_dir",
        _78da8ebbcb40=_06cfcd6520f7,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Base data source directory under data."
    )

    _42ee6ed5c974 = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="dataset.test.data_dir",
        _78da8ebbcb40=_06cfcd6520f7,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _253a85f28e89 = os._e1116d9ab641._ff6b8afeac6d(_559d365361f4,_54522828a6b7,_42ee6ed5c974)

    _9d463dd8201f = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="dataset.files_have_header",
        _78da8ebbcb40=_55ac509dba47,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _25e1a5544290 = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="app.random_seed",
        _78da8ebbcb40=_1ac1e91bbed8,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _1b257c7f7e28 = f"config/{_b40d7c7a97d8}/finetune/classes_config.json"

    _ff56055c841e = _7f24fd7ec938(
        _559d365361f4=_253a85f28e89,
        _9d463dd8201f=_9d463dd8201f,
        _8cf760759c38=_8cf760759c38,
        _8476f1faf605=_8476f1faf605,
        _526b6311fa7d=_27ab11b36962,
        _1b257c7f7e28=_1b257c7f7e28,
        _9de24b389b8b=_1cfaa47edaac,
        _3e19a9b83c4c=_668364b7222e,
        _d7de7d5d5d75=_74c9376782b8._3233a4c61181,
        _019a31db9dbb=_019a31db9dbb,
        _ab20a0cbe2b7=_ab20a0cbe2b7,
        _25e1a5544290=_25e1a5544290,
    )
    _8cf760759c38._b47d3e75126d(f"Test samples: {_9fce0d7b929d(_ff56055c841e)}, Labels: {_0039e1cd49fd(_ff56055c841e, 'actual_num_of_labels', 'NA')}")

    _1812bd9a0ae8 = [_fbcdd60ff7e2 for _, _fbcdd60ff7e2 in _12d68a1b5965._4703d13d8bd3() if not _fbcdd60ff7e2._e05c23c9a1f2]
    _7e9018d39fe1 = _1cb95ab170a0(_181c9eafaed2=_1812bd9a0ae8) if _c5a85ca873ff == "gpu" else "auto"

    _9188dcf03b6f = _78b7b55ecb2b(
        _fac3225b4887=_c5a85ca873ff,
        _bcd01f216b1b=_0ebb9ed9a860(_c5a85ca873ff=_c5a85ca873ff),
        _e92ad53e1f8f=1,
        _8a4184001585=_7e9018d39fe1 if _c5a85ca873ff == "gpu" else "auto",
        _f460ffb917db=1,
        _d62164463983=_d62164463983,
        _ca7ef06b883b=0,
        _a8d992de4f7e=_1cfaa47edaac,
        _ef177633fb3a=_1cfaa47edaac,
        _4465f6bf22ae=_668364b7222e,
        _5b40aa73d585=_1cfaa47edaac,
    )

    _7e5c6cb32030 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.batch_size", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Batch size for training"
    )

    _e4b0a08dc6a2 = _88789e59437c(
        _ff56055c841e=_ff56055c841e,
        _d8545a124327=_7e5c6cb32030,
        _d7de7d5d5d75=_74c9376782b8._3233a4c61181,
        _019a31db9dbb=_019a31db9dbb,
        _65e6055fa265=_8476f1faf605,
        _25e1a5544290=_25e1a5544290,
    )

    _fa89d3d1fba3 = 0.0
    _aa238e589af1 = [{}]
    _76514fadc972 = "SUCCESS"
    try:
        _aa238e589af1 = _9188dcf03b6f._06f23812c084(_12d68a1b5965._f45be68cc3b7(_5d88ddcdd444._2dbc590a6cb2), _a04e622752ee=_e4b0a08dc6a2)
        _fa89d3d1fba3 = _aa238e589af1[0]._b411d07c23e2("test_accuracy", 0.0)
    except _9cb8b429af51 as _a5b8903d5501:
        _8cf760759c38._d40e84c96e20(f"Exception during testing: {_a5b8903d5501}")
        _76514fadc972 = _06cfcd6520f7(_a5b8903d5501)

    # Log test metrics to CSV
    _833ce8078a87 = f"metrics/{_b40d7c7a97d8}"
    os._02c7f6c496a5(_833ce8078a87, _2add86bbc04b=_668364b7222e)
    _42cb25b59634 = "finetune_results.csv"
    _79a92b1773f5 = os._e1116d9ab641._ff6b8afeac6d(_833ce8078a87, _42cb25b59634)
    _e9b7d784f4f8 = _c35664564dfa.copy()
    _e9b7d784f4f8._2d365719dfdf("pretrained_embedding_model", _897774774bf9)
    _e9b7d784f4f8._2d365719dfdf("tokenizer", _897774774bf9)
    _e9b7d784f4f8._2d365719dfdf("device_dict", _897774774bf9)
    _a874cd06547c = _09eba5ed324f()
    _46f9dae3b53d, _e30f8d84ec1f, _9f6a332c1337 = _a874cd06547c._21f593b43af3(_1ac1e91bbed8(_786a861e26d9 * 1000))
    _b02edb980f1d = f"{_46f9dae3b53d} hours, {_e30f8d84ec1f} minutes and {_9f6a332c1337} seconds"
    _3608c43222d7 = "{ " + ", "._ff6b8afeac6d(f"{_51d85062b475}: {_a954a3d1259b}" for _51d85062b475, _a954a3d1259b in _e9b7d784f4f8._5ad911059bb3()) + " }"
    _fe5e76d8f982 = {
        'accuracy': _fa89d3d1fba3,
        'params': _3608c43222d7,
        'execution_time': _786a861e26d9,
        'readable_time': _b02edb980f1d,
        'failure_reason': _76514fadc972,
        'other_metrics': json._6c7be7dc4739(_aa238e589af1[0])
    }
    with _7b98d316409b(_79a92b1773f5, 'a+', _e42ab53467ce="utf8") as _d35528e66027:
        _96229b395304 = _7648c75c4980._9deec9fe7940(_d35528e66027, _31b865fc8290=_fe5e76d8f982._09cfa1188a58())
        if os._e1116d9ab641._0936ec6ca0e1(_79a92b1773f5) == 0:
            _96229b395304._2fa14e69cb4a()
        _96229b395304._1e49cb5a315d(_fe5e76d8f982)
    _8cf760759c38._b47d3e75126d(f"Test accuracy: {_fa89d3d1fba3}")

    try:
        if _8857e71d5b46(_12d68a1b5965, 'peft_config') or _c3afb80cdbfc(_12d68a1b5965, _cbdb35de4ee2):
            _8cf760759c38._b47d3e75126d("PEFT/LoRA detected. Merging adapters...")
            try:
                _12d68a1b5965 = _12d68a1b5965._30a1f9e8c39f()
                _8cf760759c38._b47d3e75126d("LoRA adapters merged successfully.")
            except _9cb8b429af51 as _d2e7a2148641:
                _8cf760759c38._a61d57862e21(f"LoRA merge failed: {_d2e7a2148641}. Proceeding without merge.")
        else:
            _8cf760759c38._b47d3e75126d("No PEFT/LoRA detected. Skipping merge.")

        if _af8e680dfa0b:
            _8cf760759c38._b47d3e75126d("Dequantizing for CPU save...")
            _12d68a1b5965 = _12d68a1b5965._f45be68cc3b7(_627226216ac6="cuda" if _5d88ddcdd444._2ab833a74284._fddc86e146c8() else "cpu")
            try:
                _12d68a1b5965 = _16a1d3838dde(_12d68a1b5965)
            except _9cb8b429af51 as _c5484e5b5356:
                _8cf760759c38._a61d57862e21(f"dequantize_bnb_model failed, using manual_dequantize: {_c5484e5b5356}")
                _12d68a1b5965 = _dd76cf17db5b(_12d68a1b5965)
            _12d68a1b5965 = _12d68a1b5965._bbdbf3bd1ca4()
            if _5d88ddcdd444._b3a91ee4a2e2._014db6a95ff3():
                _5d88ddcdd444._b3a91ee4a2e2._bb5536370504()
            _98331ae6ada8 = _12d68a1b5965._f45be68cc3b7(_78da8ebbcb40=_5d88ddcdd444._2dbc590a6cb2, _627226216ac6="cpu")
            _87556051c37d = "saved_models"
            os._02c7f6c496a5(_87556051c37d, _2add86bbc04b=_668364b7222e)
            _37315c1e8ea2 = os._e1116d9ab641._ff6b8afeac6d(_87556051c37d, "finetuned_model.pt")
            _5d88ddcdd444._91c4a52907f6(_98331ae6ada8._86950b824d74(), _37315c1e8ea2)
            _8cf760759c38._b47d3e75126d(f"Saved lightweight checkpoint at {_37315c1e8ea2}")
    except _9cb8b429af51 as _a5b8903d5501:
        _8cf760759c38._d40e84c96e20(f"Exception during model saving: {_a5b8903d5501}")
        _76514fadc972 += " ; Model saving failed: " + _06cfcd6520f7(_a5b8903d5501)
        # Update the CSV with updated failure_reason if needed, but since it's already written, perhaps append another row or update


def _5682a28cefd0(_74c9376782b8: _48c48a447abf._30809889d045) -> _897774774bf9:
    _38f2f5e527ca()
    _5cfe8941b7dd = _3c705456c323()
    _703660960005 = _5cfe8941b7dd._79a7361619fc(_74c9376782b8._7c6cd9dfa251)
    _07efe5ca25f9 = _ca1a11f4de84()
    _8cf760759c38 = _07efe5ca25f9._5115498ff670(_703660960005)
    _2a2c661c1c79 = _d90ef3c1c995()
    _a874cd06547c = _09eba5ed324f()

    _ab38417f9372 = time.time()

    _25e1a5544290 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="app.random_seed", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Seed for reproducibility under app.random_seed"
    )
    _f839a5a8c2ee.random._9def3a77e493(_25e1a5544290)
    random._9def3a77e493(_25e1a5544290)
    _165eaca90fb0._e4a7e9f68c61(_25e1a5544290, _c807c2cd73dc=_668364b7222e)
    _5d88ddcdd444._92f37ccb1ce8(_25e1a5544290)
    if _5d88ddcdd444._2ab833a74284._fddc86e146c8():
        _5d88ddcdd444._2ab833a74284._c02548427a2e(_25e1a5544290)

    _12815de3260d = 0
    if _5d88ddcdd444._2ab833a74284._fddc86e146c8():
        _5b61d033af10 = _1ac1e91bbed8(os._902afdb47993._b411d07c23e2('RANK', '0'))
        _9bbe0f7f6c12 = _1ac1e91bbed8(os._902afdb47993._b411d07c23e2('WORLD_SIZE', '1'))
        try:
            if not _5d88ddcdd444._b3a91ee4a2e2._014db6a95ff3():
                _5d88ddcdd444._b3a91ee4a2e2._2d76de1801bb(
                    _44fc6b6d2771=_74c9376782b8._44fc6b6d2771, _12815de3260d=_5b61d033af10, _9bbe0f7f6c12=_9bbe0f7f6c12,
                    _14f8d332d3ac=_7fbe1d0ff3e5(_d018bf632221=600)
                )
        except _9cb8b429af51:
            pass
    if _5d88ddcdd444._b3a91ee4a2e2._014db6a95ff3():
        try:
            _12815de3260d = _5d88ddcdd444._b3a91ee4a2e2._6595c6d5d03f()
        except _9cb8b429af51:
            _12815de3260d = _0039e1cd49fd(_74c9376782b8, "local_rank", 0)

    _b40d7c7a97d8 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="app.model_config_name", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Model config name under app.model_config_name"
    )
    _833ce8078a87 = f"metrics/{_b40d7c7a97d8}"
    os._02c7f6c496a5(_833ce8078a87, _2add86bbc04b=_668364b7222e)

    _5598dbe3a29a = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.pretrained_embedding", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _033d97d1dcb0 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="app.pretrained_embeddings_dir", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _287cf3777a6d = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.pretrained_embedding_overwrite_old", _78da8ebbcb40=_55ac509dba47, _0bf7e5963c48=_1cfaa47edaac, _e2efd850e7fb=_1cfaa47edaac,
        _b6f1236abbbe="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _af8e680dfa0b = _1cfaa47edaac
    _0a08100e76d9 = _897774774bf9
    _019a31db9dbb = _1cfaa47edaac
    _ab20a0cbe2b7 = _897774774bf9
    if _e961e7dd79e5:
        try:
            _0a08100e76d9 = _8644cacb823a(
                _641560dbb956=_668364b7222e,
                _fe0180f48c35=_182eba580fa1(),
                _f14160b115b8=_668364b7222e,
                _c3ed6061d9be="nf4",
            )
            _af8e680dfa0b = _668364b7222e
        except _9cb8b429af51:
            _0a08100e76d9 = _897774774bf9

    _4335090e8865 = os._e1116d9ab641._ff6b8afeac6d(
        _033d97d1dcb0,
        _5598dbe3a29a + ("_quantized" if _e961e7dd79e5 else "_fp32")
    )

    _2a2c661c1c79._f4e2f808eeda(_4335090e8865, _b679887d46c8=_287cf3777a6d)
    if _2a2c661c1c79._d88657edf16b(_4335090e8865):
        _8cf760759c38._b47d3e75126d(f"Downloading pretrained embedding {_5598dbe3a29a}")
        try:
            from _41cf59c2daaf import _e829024e99f4, _e0b2a1d5f474
            _57988fdb1c43 = _e829024e99f4()
            _c1c0ce00ea8e = _57988fdb1c43._c1c0ce00ea8e(_5598dbe3a29a)
            _681fc300f600 = _0039e1cd49fd(_c1c0ce00ea8e, "sha", _897774774bf9) or _897774774bf9
            if "llama" in _5598dbe3a29a._669c7c248610():
                _93caba4f4684 = os._8dca48b0a963("HF_LLAMA3B_TOKEN")
                if _93caba4f4684:
                    _e0b2a1d5f474(token=_93caba4f4684)
                else:
                    raise _6ec6340596e1("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _9cb8b429af51:
            _681fc300f600 = _897774774bf9
        from _90f5849b033e import _0d5d7868685c
        _be026772fa3a = _0d5d7868685c._1a7a5981108e(_5598dbe3a29a, _681fc300f600=_681fc300f600)
        _8cf760759c38._b47d3e75126d(f"config of pretrained embedding used {_be026772fa3a}")
        if "llama" in _5598dbe3a29a._669c7c248610():
            from _90f5849b033e import _2eddfdaeaafe, _1cd777abb0ad
            _4e5ea11dedc9 = _2eddfdaeaafe._1a7a5981108e(
                _5598dbe3a29a, _681fc300f600=_681fc300f600,
                _f23b81a3b00b=_0a08100e76d9 if (_e961e7dd79e5 and _0a08100e76d9) else _897774774bf9
            )
            _8476f1faf605 = _1cd777abb0ad._1a7a5981108e(_5598dbe3a29a, _681fc300f600=_681fc300f600, _a41e056e3474=_1cfaa47edaac)
            _019a31db9dbb = _668364b7222e
            _ab20a0cbe2b7 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _90f5849b033e import _4f23b2911405, _1cd777abb0ad
            _4e5ea11dedc9 = _4f23b2911405._1a7a5981108e(_5598dbe3a29a, _681fc300f600=_681fc300f600)
            _8476f1faf605 = _1cd777abb0ad._1a7a5981108e(_5598dbe3a29a, _681fc300f600=_681fc300f600)
            _019a31db9dbb = _1cfaa47edaac
        try:
            with _7b98d316409b(os._e1116d9ab641._ff6b8afeac6d(_4335090e8865, 'revision.txt'), 'w') as _0a71ba35717e:
                _0a71ba35717e._f64c1be0efdd(_681fc300f600)
            _4e5ea11dedc9._540fbffb1aa1(_4335090e8865)
            _8476f1faf605._540fbffb1aa1(_4335090e8865)
        except _9cb8b429af51:
            _8cf760759c38._a61d57862e21("Saving pretrained embedding locally failed; continuing.")
    else:
        _8cf760759c38._b47d3e75126d(f"Loading pretrained embedding from {_4335090e8865}")
        from _90f5849b033e import _0d5d7868685c
        _be026772fa3a = _0d5d7868685c._1a7a5981108e(_4335090e8865)
        _8cf760759c38._b47d3e75126d(f"Config of pretrained embedding used {_be026772fa3a}")
        if "llama" in _5598dbe3a29a._669c7c248610():
            from _90f5849b033e import _2eddfdaeaafe, _1cd777abb0ad
            _4e5ea11dedc9 = _2eddfdaeaafe._1a7a5981108e(
                _4335090e8865,
                _f23b81a3b00b=_0a08100e76d9 if (_e961e7dd79e5 and _0a08100e76d9) else _897774774bf9
            )
            _8476f1faf605 = _1cd777abb0ad._1a7a5981108e(_4335090e8865, _a41e056e3474=_1cfaa47edaac)
            _019a31db9dbb = _668364b7222e
            _ab20a0cbe2b7 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _90f5849b033e import _4f23b2911405, _1cd777abb0ad
            _4e5ea11dedc9 = _4f23b2911405._1a7a5981108e(_4335090e8865)
            _8476f1faf605 = _1cd777abb0ad._1a7a5981108e(_4335090e8865)
            _019a31db9dbb = _1cfaa47edaac

    _27ab11b36962 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.max_seq_len", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Maximum sequence length for training"
    )
    _7e5c6cb32030 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.batch_size", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Batch size for training"
    )
    _380d8bd1df68 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.data_sample_share", _78da8ebbcb40=_bbdbf3bd1ca4, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Proportion of dataset used for sampling"
    )
    _bc86c3d94bc4 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.optimizer", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Optimizer type under run_config.optimizer"
    )
    _dfffa60a2c08 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.learning_rate", _78da8ebbcb40=_bbdbf3bd1ca4, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Learning rate for optimizer"
    )
    _27b36d95b6bf = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.num_backbone_model_units_unfrozen", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Number of backbone model units unfrozen during training"
    )
    _341e926cf071 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.loss_type", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Loss function type under run_config.loss_type"
    )
    _65e6e3459249 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.num_fc_layers_in_classifier_head", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Number of FC layers in classifier head"
    )
    _d0f63bab824f = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.activation_function_for_layer", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Activation function for layer under run_config.activation_function_for_layer"
    )
    _e436626fc2b9 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.add_dropout_after_embedding", _78da8ebbcb40=_55ac509dba47, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _4279925e6f08 = _1cfaa47edaac if _27b36d95b6bf == 0 else _668364b7222e

    _c35664564dfa: _faa26acb1d94[_06cfcd6520f7, _c6149b3c45ff] = {
        "device_dict": _71cd5f8918b1(),
        "pretrained_embedding_model": _4e5ea11dedc9,
        "optimizer": _bc86c3d94bc4,
        "num_backbone_model_units_unfrozen": _27b36d95b6bf,
        "loss_type": _341e926cf071,
        "lr": _dfffa60a2c08,
        "is_train": _668364b7222e,
        "tokenizer": _8476f1faf605,
        "random_seed": _25e1a5544290,
        "num_fc_layers": _65e6e3459249,
        "activation_function_for_layer": _d0f63bab824f,
        "add_dropout_after_embedding": _e436626fc2b9,
    }
    _c35664564dfa._f325fb443a36({"pretrained_model_embedding_name": _5598dbe3a29a})
    if _019a31db9dbb:
        _c35664564dfa._f325fb443a36({"prompt_length": _27ab11b36962})

    _559d365361f4 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="app.data_dir", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Base data directory under app.data_dir"
    )
    _54522828a6b7 = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="dataset.data_source_dir",
        _78da8ebbcb40=_06cfcd6520f7,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Base data source directory under data."
    )
    _9d0a58c28f0e = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="dataset.train.data_dir", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Subdirectory for training data under dataset.train.data_dir"
    )
    _f5b48bda52cf = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="dataset.val.data_dir", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Subdirectory for validation data under dataset.val.data_dir"
    )
    _830a3a706b3d = os._e1116d9ab641._ff6b8afeac6d(_559d365361f4, _54522828a6b7, _9d0a58c28f0e)
    _f163ecb3b728 = os._e1116d9ab641._ff6b8afeac6d(_559d365361f4, _54522828a6b7, _f5b48bda52cf)
    _9d463dd8201f = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="dataset.files_have_header", _78da8ebbcb40=_55ac509dba47, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Whether dataset files have header"
    )
    _1b257c7f7e28 = f"config/{_b40d7c7a97d8}/finetune/classes_config.json"
    _2a2c661c1c79._f4e2f808eeda(os._e1116d9ab641._3e89cd797b45(_1b257c7f7e28))

    _6a3e43efe729 = _7f24fd7ec938(
        _559d365361f4=_830a3a706b3d, _9d463dd8201f=_9d463dd8201f, _8cf760759c38=_8cf760759c38,
        _8476f1faf605=_8476f1faf605, _526b6311fa7d=_27ab11b36962,
        _1b257c7f7e28=_1b257c7f7e28, _9de24b389b8b=_668364b7222e, _3e19a9b83c4c=_1cfaa47edaac,
        _25e1a5544290=_25e1a5544290, _3272a58bc6f3=_380d8bd1df68,
        _d7de7d5d5d75=_74c9376782b8._3233a4c61181, _019a31db9dbb=_019a31db9dbb, _ab20a0cbe2b7=_ab20a0cbe2b7,
    )
    _4134d2963a2f = _7f24fd7ec938(
        _559d365361f4=_f163ecb3b728, _9d463dd8201f=_9d463dd8201f, _8cf760759c38=_8cf760759c38,
        _8476f1faf605=_8476f1faf605, _526b6311fa7d=_27ab11b36962,
        _1b257c7f7e28=_1b257c7f7e28, _9de24b389b8b=_1cfaa47edaac, _3e19a9b83c4c=_1cfaa47edaac,
        _25e1a5544290=_25e1a5544290, _3272a58bc6f3=_380d8bd1df68,
        _d7de7d5d5d75=_74c9376782b8._3233a4c61181, _019a31db9dbb=_019a31db9dbb, _ab20a0cbe2b7=_ab20a0cbe2b7,
    )
    _8cf760759c38._b47d3e75126d(f"Number of training data samples {_6a3e43efe729._f7cb0e0dfe83()} with {_0039e1cd49fd(_6a3e43efe729, 'label_sample_counter', 'NA')} labels and {_0039e1cd49fd(_6a3e43efe729, 'actual_dataset_length', 'NA')} unique samples with {_0039e1cd49fd(_6a3e43efe729, 'actual_num_of_labels', 'NA')} unique labels")
    _8cf760759c38._b47d3e75126d(f"Number of validation data samples {_4134d2963a2f._f7cb0e0dfe83()} with {_0039e1cd49fd(_4134d2963a2f, 'label_sample_counter', 'NA')} labels and {_0039e1cd49fd(_4134d2963a2f, 'actual_dataset_length', 'NA')} unique samples with {_0039e1cd49fd(_4134d2963a2f, 'actual_num_of_labels', 'NA')} unique labels.")

    _5c754910c951 = _6a3e43efe729._05d0adbc9c4c()
    _50de96b87e90 = [_6a3e43efe729._bf8ce9705af2(_69de919312a6) for _69de919312a6 in _6a3e43efe729._789449b5e927._09cfa1188a58()]
    _dc0623929b19 = _6a3e43efe729._dc0623929b19
    _79550ddcbd6f = {}
    for _312f52b3a24b, (_d067a8501903, _0eddf4b2303a) in _ee8e75f75369(_48524e9cd98f(_50de96b87e90, _dc0623929b19)):
        _ef9d4082b73b = _8476f1faf605(_d067a8501903, _c8f819d28cac=_1cfaa47edaac)["input_ids"] if _019a31db9dbb else [_312f52b3a24b]
        if _ef9d4082b73b:
            _79550ddcbd6f[_d067a8501903] = [_ef9d4082b73b, _0eddf4b2303a]
    _9384a339a5d0(f"Class Weights Generated {_79550ddcbd6f}")
    _8cf760759c38._b47d3e75126d(f"{_5c754910c951} classes in training data with classes {_50de96b87e90} and weights {_dc0623929b19}")
    _c35664564dfa._f325fb443a36({"class_weights": _79550ddcbd6f, 
                   "class_names": _50de96b87e90,
                   "model_config_name": _b40d7c7a97d8})

    if "llama" in _5598dbe3a29a and _019a31db9dbb:
        _12d68a1b5965 = _390c12fc7ede(**_c35664564dfa)
    else:
        _12d68a1b5965 = _d35997a5f5c0(**_c35664564dfa)

    _35e27572d822 = _2215936c6098(
        _703660960005=_703660960005,
        _220fd3e3424d="operation_mode",
        _78da8ebbcb40=_06cfcd6520f7,
        _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _da482ea9657c = _897774774bf9
    if _35e27572d822 == "model_finetune":
        _da482ea9657c = _2215936c6098(
            _703660960005=_703660960005, _220fd3e3424d="run_config.finetuned_model_path", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_1cfaa47edaac,
            _b6f1236abbbe="Optional path to pretrained model checkpoint for finetuning"
        )
        if _da482ea9657c:
            _bd39449b4682(_12d68a1b5965, _da482ea9657c, _92a6efb31cee="cpu")
            _8cf760759c38._b47d3e75126d(f"Loaded finetuned model from {_da482ea9657c}")

    _1812bd9a0ae8 = []
    if _4279925e6f08:
        if _af8e680dfa0b:
            _0153e26218cb = lambda _9d5fc5e383c8: (
                _8857e71d5b46(_9d5fc5e383c8, "weight") and
                _c3afb80cdbfc(_9d5fc5e383c8._0eddf4b2303a, _5d88ddcdd444._fb27b18bfafd) and
                _9d5fc5e383c8._0eddf4b2303a._cf5a8dd86b5f() > 64 and
                not _c3afb80cdbfc(_9d5fc5e383c8, (_7668f055d4fb._2e303dc0f368._0b170cbfc388, _7668f055d4fb._2e303dc0f368._01d06221652d, _7668f055d4fb._2e303dc0f368._e05214689a53))
            )
        else:
            _0153e26218cb = lambda _9d5fc5e383c8: (
                _8857e71d5b46(_9d5fc5e383c8, "weight") and
                _c3afb80cdbfc(_9d5fc5e383c8._0eddf4b2303a, _5d88ddcdd444._fb27b18bfafd) and
                _9d5fc5e383c8._0eddf4b2303a._cf5a8dd86b5f() > 64
            )
        _5ce631acb74f = _12d68a1b5965._d0f45acbf69b
        _5fb3f7792974 = _76f99b44ea47(_5ce631acb74f, _0153e26218cb=_0153e26218cb, _1c7e26b8e378=_897774774bf9, _2c90a9202260=_897774774bf9)
        try:
            _b764f9792a2f = _99c452a195fd._1320994fa637 if _019a31db9dbb else _99c452a195fd._548e7c94173e
            _5c6727543644 = _8d1ccefcac4a(_897774774bf9, _5fb3f7792974, _b764f9792a2f)
        except _9cb8b429af51:
            _5c6727543644 = _fc0f247db53b(
                _695c1c1997c7=8, _cfbe7c177aed=32, _12dabed36637=0.1,
                _5fb3f7792974=_339488fc64dc(_5fb3f7792974._09cfa1188a58()) if _5fb3f7792974 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _22654f4af963=_99c452a195fd._1320994fa637 if _019a31db9dbb else _99c452a195fd._548e7c94173e
            )
        _8cf760759c38._b47d3e75126d(f"Target Module trainable parameters before applying LORA is {_6d92a6132702(_5ce631acb74f)} and size is {_1687a7e0f4a1(_5ce631acb74f)} GB")
        _5ce631acb74f = _4bf357c628ab(_5ce631acb74f, _5c6727543644)
        for _220fd3e3424d, _c5acedf71875 in _12d68a1b5965._4703d13d8bd3():
            if not _c5acedf71875._16314ade7ca8:
                _c5acedf71875 = _c5acedf71875._1c06874598d4()
            if "encoder" in _220fd3e3424d and "lora" not in _220fd3e3424d:
                _c5acedf71875._e05c23c9a1f2 = _1cfaa47edaac
            elif "embedding" in _220fd3e3424d:
                _c5acedf71875._e05c23c9a1f2 = "lora" in _220fd3e3424d
        _8cf760759c38._b47d3e75126d(f"Target Module trainable parameters after applying LORA is {_6d92a6132702(_5ce631acb74f)} and size is {_1687a7e0f4a1(_5ce631acb74f)} GB")

    _c1906bf18fbf = _1ac1e91bbed8(_71b3fbd2d52f())
    _c5a85ca873ff = 'gpu' if _5d88ddcdd444._2ab833a74284._fddc86e146c8() else 'cpu'
    _d6a543fae36d = f"cuda:{_c1906bf18fbf}" if _c5a85ca873ff == 'gpu' else 'cpu'
    if _98bcfb6df346._72fea19dd882() is _1cfaa47edaac:
        _8cf760759c38._b47d3e75126d(f"Setting model to {_d6a543fae36d}")
        _12d68a1b5965 = _12d68a1b5965._f45be68cc3b7(_78da8ebbcb40=_5d88ddcdd444._2dbc590a6cb2, _627226216ac6=_d6a543fae36d)

    _3967bd5a2922 = {}
    _3967bd5a2922['model_name'] = _b40d7c7a97d8
    _f460ffb917db = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="model.max_epochs", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Maximum number of epochs under model.max_epochs"
    )
    _3967bd5a2922['max_epochs'] = _f460ffb917db
    _5a0b7170be58 = _06ffd9b122c8._c6d873daaded(_b86980dff05c=2)
    _349362ecec06 = "epoch_training_metrics.csv"
    _ed28201c1751 = "model_training_summary_metrics.csv"
    _bfa0478e2a3a = _8bbc4fe348f0(_8cf760759c38,
                                       _5a0b7170be58=_5a0b7170be58,
                                       _3967bd5a2922=_3967bd5a2922,
                                       _4b73f606e41f=_833ce8078a87,
                                       _0ef54f6b1d73=_349362ecec06,
                                       _8ba80fdb8f9b=_ed28201c1751,
                                       _f60ef259d1d0=_897774774bf9)
    _ba92b750b7e3 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="app.checkpoints_dir", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _8cc672b396ac = os._e1116d9ab641._ff6b8afeac6d(_ba92b750b7e3, _b40d7c7a97d8, "finetune")
    os._02c7f6c496a5(_8cc672b396ac, _2add86bbc04b=_668364b7222e)
    _9d7e1a4302e1 = _06ffd9b122c8._767e4f3adac0(_826dcd028327=_8cc672b396ac, _8e211000272d="intermediate",
        _07c226a18429=1, _8c9097c227dc=1000, _315c3eb42ddf=_1cfaa47edaac)
    _942585070cf7 = _06ffd9b122c8._767e4f3adac0(_826dcd028327=_8cc672b396ac, _8e211000272d="last", _07c226a18429=1,
        _315c3eb42ddf=_668364b7222e, _407f1ce8df09="val_loss", _71d5e25dba36="min")
    _34dde61b0c91 = _06ffd9b122c8._cf5cdb6826e9(_407f1ce8df09="val_accuracy", _0b57a40c5107=3, _71d5e25dba36="max", _b61b54d3b152=_668364b7222e)
    _27c8b8945259 = _06ffd9b122c8._3b54d3743826(_16e65416b42d='step')

    for _220fd3e3424d, _fbcdd60ff7e2 in _12d68a1b5965._4703d13d8bd3():
        if not _fbcdd60ff7e2._e05c23c9a1f2:
            _1812bd9a0ae8._61833690e68f(_fbcdd60ff7e2)
    _7e9018d39fe1 = _1cb95ab170a0(_181c9eafaed2=_1812bd9a0ae8) if _c5a85ca873ff == "gpu" else "auto"
    _e92ad53e1f8f = _74c9376782b8._e92ad53e1f8f

    _f7b70a5e9f02 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.accumulate_grad_batches", _78da8ebbcb40=_1ac1e91bbed8, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _e676cb4abd00 = _2215936c6098(
        _703660960005=_703660960005, _220fd3e3424d="run_config.training_precision_type", _78da8ebbcb40=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e,
        _b6f1236abbbe="Training precision type under run_config.training_precision_type"
    )
    _06289612b6dd = _78b7b55ecb2b(
        _fac3225b4887=_c5a85ca873ff, _bcd01f216b1b=_0ebb9ed9a860(_c5a85ca873ff),
        _e92ad53e1f8f=_e92ad53e1f8f, _8a4184001585=_7e9018d39fe1 if _c5a85ca873ff == "gpu" else "auto",
        _f460ffb917db=_f460ffb917db, _a8d992de4f7e=_1cfaa47edaac, _f6ede53eb360=_668364b7222e,
        _4465f6bf22ae=_668364b7222e, _5b40aa73d585=_1cfaa47edaac,
        _f7b70a5e9f02=_f7b70a5e9f02,
        _d62164463983=_e676cb4abd00,
        _06ffd9b122c8=[_bfa0478e2a3a, _9d7e1a4302e1, _942585070cf7, _34dde61b0c91, _27c8b8945259],
    )

    _2d70fc058255 = _88789e59437c(
        _6a3e43efe729=_6a3e43efe729, _4134d2963a2f=_4134d2963a2f,
        _b7442023844e=_668364b7222e, _65e6055fa265=_8476f1faf605,
        _d8545a124327=_7e5c6cb32030, _d7de7d5d5d75=_74c9376782b8._3233a4c61181,
        _019a31db9dbb=_019a31db9dbb, _25e1a5544290=_25e1a5544290
    )

    if _c1906bf18fbf == 0:
        _11301f0276d7 = _ecfb24ff70c1(_12d68a1b5965)
        _8cf760759c38._b47d3e75126d(f"Model Summary before fit is {_11301f0276d7}")
        _8cf760759c38._b47d3e75126d(f"Model structure is {_12d68a1b5965}")

    _bf417c022198 = os._e1116d9ab641._ff6b8afeac6d(_8cc672b396ac, "intermediate.ckpt")
    if os._e1116d9ab641._e2588cd4fc58(_bf417c022198):
        _06289612b6dd._267df965a0f5(_12d68a1b5965, _a04e622752ee=_2d70fc058255, _f878cc391eae=_bf417c022198)
    else:
        _06289612b6dd._267df965a0f5(_12d68a1b5965, _a04e622752ee=_2d70fc058255)

    if _5d88ddcdd444._b3a91ee4a2e2._014db6a95ff3():
        _5d88ddcdd444._b3a91ee4a2e2._bb5536370504()
    _b7bd9e678936 = _942585070cf7._ddd08490f30f
    if _b7bd9e678936:
        _8cf760759c38._b47d3e75126d(f"Best checkpoint saved at {_b7bd9e678936}")

    _786a861e26d9 = time.time() - _ab38417f9372
    # Run test set
    _4a114d44c092(_74c9376782b8, _703660960005, _c35664564dfa, _b7bd9e678936, _8476f1faf605, _4e5ea11dedc9, _27ab11b36962, _019a31db9dbb, _ab20a0cbe2b7, _4279925e6f08, _8cf760759c38, _d62164463983=_e676cb4abd00, _786a861e26d9=_786a861e26d9)

    _8cf760759c38._b47d3e75126d("Finetuning completed successfully.")


def _1e4968cb430c():
    _b19998be39a6 = _48c48a447abf._b6124c41257b(_3c9b60d65edd='Fine-tune a language identification model (single run)')
    _b19998be39a6._6bb3155a0238('--config_file_path', _972af1e69193=_06cfcd6520f7, _0bf7e5963c48=_668364b7222e)
    _b19998be39a6._6bb3155a0238('--num_nodes', _972af1e69193=_1ac1e91bbed8, _e2efd850e7fb=1)
    _b19998be39a6._6bb3155a0238('--cpu_cores', _972af1e69193=_1ac1e91bbed8, _e2efd850e7fb=1)
    _b19998be39a6._6bb3155a0238('--local-rank', _972af1e69193=_1ac1e91bbed8)
    _b19998be39a6._6bb3155a0238('--backend', _972af1e69193=_06cfcd6520f7, _e2efd850e7fb="gloo", _58ac27c0e71e=['gloo', 'mpi', 'nccl'])
    _b19998be39a6._6bb3155a0238('--run_timestamp', _972af1e69193=_bbdbf3bd1ca4, _e2efd850e7fb=_897774774bf9)
    _74c9376782b8 = _b19998be39a6._b7e37b75efb8()
    if _74c9376782b8._f9b2e79e95b3 is _897774774bf9:
        _74c9376782b8._f9b2e79e95b3 = time.time()
    _5a075cc74fce(_74c9376782b8)


if __name__ == "__main__":
    _3656b16b4300()