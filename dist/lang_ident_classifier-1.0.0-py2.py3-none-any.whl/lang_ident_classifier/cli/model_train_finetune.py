# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:59 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from __future__ import _46ea8cabd497
from _a3a9def96f45 import _bc5b47e5ffb8
import _485683b36c77, _4fe8fcfddcdf, json, os, random, _560a2419327e, sys, time, _830b4405bb08
from _fb7825e6f831 import _1d88715d392f
from typing import _514de1916267, _80c7bd989f6e, _df0afabca34d
import _a78004d01fd3 as _de8077c14dd9, _1a2b12d0060a, _9a8e097a6f6e as _7192a60ef22d
from _9a8e097a6f6e import _0b6b8bf1298f
from _9a8e097a6f6e._a217b8a488ac import _b7e94a1e095b
from _9a8e097a6f6e._a217b8a488ac._b97df09de837._609ae0f26e07 import _d2a8ada6fbf0
from _456679741532 import _6479d4c31c73, _c3b578489d96, _3b48af9b9ea5
from _92929913d8ca._e35fe869eea3._d9349b6d999a._fb01ad507930 import _e536d0a256a8
from _92929913d8ca._e35fe869eea3._d9349b6d999a._e82ebc689fe1 import _d755ec4669ca
from _92929913d8ca._e35fe869eea3._d9349b6d999a._36aef3b8e2d2 import _c5bde786c0a6
from _92929913d8ca._e35fe869eea3._d9349b6d999a._9dd4e84ebd07 import _8d00080b1af9
from _92929913d8ca._e35fe869eea3._a9b360e26fd1._3a53db9a7a2b import _ec7f6cba5d65
from _92929913d8ca._e35fe869eea3._a9b360e26fd1._d83f2ea45fcc import _64e52b141c50
from _92929913d8ca._e35fe869eea3._3d17adb30963._e4f98fdeb652 import _d0db9f6ef8be
from _92929913d8ca._e35fe869eea3._3d17adb30963._321d8f10ea83 import _4085db40467b
from _92929913d8ca._e35fe869eea3._b7e94a1e095b._4be4bedcf5fa import _c0cce5da7ce8
from _92929913d8ca._e35fe869eea3._d9349b6d999a._76a291f97c14 import _1e03ca2810f6
from _92929913d8ca._e35fe869eea3._d9349b6d999a._76a291f97c14 import (
    _13a894931e8f, _915274dfb8ed, _0a3def023d46,
    _0f717e2fbd0d, _10328da260de, _d1602e7c1f8a,
    _2ff86360a625, _8bf12f773c3d, _5e8926bad324,
    _649b9a87b541, _5d90539a961b, _fcfe81c5f8ee,
    _519e74bc5a8f, _d94eeaa7864e
)

os._4a2539c23f62["TOKENIZERS_PARALLELISM"] = "True"
_4ab507153f69 = _1a2b12d0060a._ae874fa92e02._730ac1f94a39() and _1a2b12d0060a._ae874fa92e02._cea410f3ac46() > 0
if _4ab507153f69:
    try:
        from _d1f989acccca import _1440d6cf61d2
        import _900c1d57aaec as _ac624b274672
    except _51b0375893f5:
        _ac624b274672 = _0d2bc6c67339


def _021c383866cd(_fea59ef1d7ba: _1a2b12d0060a._68bdfdd343d5._72531bc88ad1, _e9cb061b27f3: _1e0559c00049, _16c485e03912: _df0afabca34d[_1e0559c00049] = _0d2bc6c67339) -> _0d2bc6c67339:
    if not os._9128251cc3e7._2105cf946a0c(_e9cb061b27f3):
        raise _34c3b5c013ee(f"Finetuned model path not found: {_e9cb061b27f3}")
    if _e9cb061b27f3._c3b69c222970((".pt", ".pth")):
        _1ebdfdbda2f0 = _16c485e03912 or ("cpu" if not _1a2b12d0060a._ae874fa92e02._730ac1f94a39() else _0d2bc6c67339)
        _2a011075e879 = _1a2b12d0060a._810a890626ba(_e9cb061b27f3, _16c485e03912=_1ebdfdbda2f0)
        _f8b11278b4ef = _2a011075e879._af53e12df5e6("state_dict", _2a011075e879._af53e12df5e6("model_state_dict", _2a011075e879)) if _a63f28f352ab(_2a011075e879, _b006d824e92a) else _2a011075e879
        if not _a63f28f352ab(_f8b11278b4ef, _b006d824e92a):
            raise _4a5c82041e8e(f"Loaded .pt file does not contain state_dict mapping: {_e9cb061b27f3}")
        _fea59ef1d7ba._8574fa939fb8(_f8b11278b4ef, _313a0f2a1050=_23de24905655)
    elif _e9cb061b27f3._c3b69c222970(".ckpt"):
        try:
            if _520ecd4460a0(_fea59ef1d7ba._272f6571300c, "load_from_checkpoint"):
                _c8e421428378 = _fea59ef1d7ba._272f6571300c._1cd91d286248(_e9cb061b27f3, **{})
                _fea59ef1d7ba._8574fa939fb8(_c8e421428378._c5e8e55890eb(), _313a0f2a1050=_23de24905655)
                return
            _2a011075e879 = _1a2b12d0060a._810a890626ba(_e9cb061b27f3, _16c485e03912="cpu")
            _f8b11278b4ef = _2a011075e879._af53e12df5e6("state_dict", _2a011075e879)
            if not _a63f28f352ab(_f8b11278b4ef, _b006d824e92a):
                raise _4a5c82041e8e("Lightning checkpoint did not contain a recognizable state_dict.")
            _fea59ef1d7ba._8574fa939fb8(_f8b11278b4ef, _313a0f2a1050=_23de24905655)
        except _51b0375893f5 as _61f9abd6495a:
            raise _4a5c82041e8e(f"Failed to load .ckpt into model: {_61f9abd6495a}") from _61f9abd6495a
    else:
        raise _329f78555f90("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _01c47613d3e6(_93deb9ebebed: _485683b36c77._5a898e43ac1a, _21dcbdd537b4: _514de1916267, _f466b5589263: _80c7bd989f6e[_1e0559c00049, _514de1916267], _7ccad1b278e1: _1e0559c00049, _4b4156a51b33: _514de1916267, _219c4f00c306: _514de1916267, _3452840f8b53: _5ada83d1e1ee, _593221415ff1: _62ebad0006cd, _6515f45dcb62: _514de1916267, _1c3108c4dab7: _62ebad0006cd, _a6277937f5f9: _bc5b47e5ffb8, _adcf02783180: _1e0559c00049 = "32", _e7512f365420: _2a3dac76ff5c = 0.0):
    """
    Compute test accuracy using the best checkpoint.
    """
    _7ce792509a67 = _23de24905655
    _40678c147770 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="app.model_config_name",
        _c44e03fdf05f=_1e0559c00049,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )

    if _4ab507153f69:
        _6f1c6a3d89ea = _1440d6cf61d2(
            _4ecdf1dfa7e8=_0d003313e595,
            _97756f642ae8=_0a3def023d46(),
            _bb81f89b8da1=_0d003313e595,
            _31ad73d79d0c="nf4",
        )
        _7ce792509a67 = _0d003313e595

    _eca4ffdc8767 = 'gpu' if _1a2b12d0060a._ae874fa92e02._730ac1f94a39() else 'cpu'
    _0d5db68f2e31 = 'cpu'
    if _eca4ffdc8767 == 'gpu':
        _6ac126a5f51b = _1a2b12d0060a._4b9c11695d5a._e5b92026da35() if _1a2b12d0060a._4b9c11695d5a._bf9ea21654b3() else 0
        _0d5db68f2e31 = f"cuda:{_6ac126a5f51b}"
    else:
        _6ac126a5f51b = -1

    _7e9712e59a5d = _f466b5589263._af53e12df5e6("pretrained_model_embedding_name")

    _f466b5589263._7e9a069e4e9f({
        "tokenizer": _4b4156a51b33,
        "pretrained_embedding_model": _219c4f00c306,
        "device_dict": _915274dfb8ed(),
        "model_config_name": _40678c147770,
    })

    if not _7ccad1b278e1:
        _a6277937f5f9._16cb933dd2c9("No best checkpoint found. Proceeding with current model weights.")
    else:
        _a6277937f5f9._16cb933dd2c9(f"Testing with best checkpoint: {_7ccad1b278e1}")

    if "llama" in (_7e9712e59a5d or ""):
        _fea59ef1d7ba = _4085db40467b(**_f466b5589263)
        _593221415ff1 = _0d003313e595
    else:
        _fea59ef1d7ba = _d0db9f6ef8be(**_f466b5589263)

    if _1c3108c4dab7:
        if _7ce792509a67:
            _1aa065faca61 = lambda _34118ad50350: (
                _520ecd4460a0(_34118ad50350, "weight") and _a63f28f352ab(_34118ad50350._ad373fe26739, _1a2b12d0060a._4640806afea0) and _34118ad50350._ad373fe26739._ad7b2d91ba1b() > 64 and
                not _a63f28f352ab(_34118ad50350, (_ac624b274672._68bdfdd343d5._77f6a7fe39a9, _ac624b274672._68bdfdd343d5._b1dc02d64cba, _2421fd837705(_ac624b274672._68bdfdd343d5, "LinearNF4", _ba846e279bae(_0d2bc6c67339))))
            )
        else:
            _1aa065faca61 = lambda _34118ad50350: (
                _520ecd4460a0(_34118ad50350, "weight") and _a63f28f352ab(_34118ad50350._ad373fe26739, _1a2b12d0060a._4640806afea0) and _34118ad50350._ad373fe26739._ad7b2d91ba1b() > 64
            )
        _6f4dbc92795d = _fea59ef1d7ba._7f33db98d789
        _977daa819b03 = _0f717e2fbd0d(_6f4dbc92795d, _1aa065faca61=_1aa065faca61, _38724a5664d2=_0d2bc6c67339, _f4b4078843ed=_0d2bc6c67339)
        _99c47baaa9e7 = _c3b578489d96(
            _168828c52d29=8,
            _77f8cdc397e7=32,
            _eb6d7ca8aea3=0.1,
            _977daa819b03=_222567c59f44(_977daa819b03._aae0c508f441()) if _977daa819b03 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _4c56dddaa861=_6479d4c31c73._9c11ec32fd15 if _593221415ff1 else _6479d4c31c73._8ef0dd355f20
        )
        _a6277937f5f9._16cb933dd2c9(f"In test Target Module trainable parameters before applying LORA: {_10328da260de(_6f4dbc92795d)}")
        _6f4dbc92795d = _d1602e7c1f8a(_6f4dbc92795d, _99c47baaa9e7)
        _a6277937f5f9._16cb933dd2c9(f"In test Target Module trainable parameters after applying LORA: {_10328da260de(_6f4dbc92795d)}")

    if _7ccad1b278e1:
        _a6277937f5f9._16cb933dd2c9(f"Loading checkpoint from: {_7ccad1b278e1}")
        try:
            _2a011075e879 = _1a2b12d0060a._810a890626ba(_7ccad1b278e1, _16c485e03912=_0d5db68f2e31)
            _f8b11278b4ef = _2a011075e879._af53e12df5e6("state_dict", _2a011075e879)
            # Strip prefixes
            _e4c5208cf5a5 = {}
            for _9af133737b3c, _8a3795ff482f in _f8b11278b4ef._8dba68cf2da7():
                _ec3a8bcfaf07 = _9af133737b3c
                while _ec3a8bcfaf07._8810707c2ff9('module.'):
                    _ec3a8bcfaf07 = _ec3a8bcfaf07[7:]
                while _ec3a8bcfaf07._8810707c2ff9('_forward_module.'):
                    _ec3a8bcfaf07 = _ec3a8bcfaf07[16:]
                _e4c5208cf5a5[_ec3a8bcfaf07] = _8a3795ff482f
            # Load with strict=False to handle potential extras
            _fea59ef1d7ba._8574fa939fb8(_e4c5208cf5a5, _313a0f2a1050=_23de24905655)
        except _51b0375893f5 as _61f9abd6495a:
            _a6277937f5f9._379eea1cfccd(f"Checkpoint load failed: {_61f9abd6495a}")
    else:
        _a6277937f5f9._379eea1cfccd("No best checkpoint found. Proceeding with in-memory model weights.")

    if _1a2b12d0060a._ae874fa92e02._730ac1f94a39():
        _6ac126a5f51b = _5ada83d1e1ee(_13a894931e8f())

    if _d2a8ada6fbf0._4b10a043ba03() is _23de24905655:
        _a6277937f5f9._16cb933dd2c9(f"Setting model to {_0d5db68f2e31}")
        _fea59ef1d7ba = _fea59ef1d7ba._6b513ae0d102(_c44e03fdf05f=_1a2b12d0060a._a52d17bd521a, _057bd3212fd5=_0d5db68f2e31)

    _995f2d3d766f = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="app.data_dir",
        _c44e03fdf05f=_1e0559c00049,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="data_dir under app specifies the base directory for datasets."
    )

    _fcd3d72daf24 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="dataset.data_source_dir",
        _c44e03fdf05f=_1e0559c00049,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Base data source directory under data."
    )

    _a05e3fa504aa = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="dataset.test.data_dir",
        _c44e03fdf05f=_1e0559c00049,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _631e181d05af = os._9128251cc3e7._801ebd91c46e(_995f2d3d766f,_fcd3d72daf24,_a05e3fa504aa)

    _1c3f4164fd27 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="dataset.files_have_header",
        _c44e03fdf05f=_62ebad0006cd,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _83803ca9e1b3 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="app.random_seed",
        _c44e03fdf05f=_5ada83d1e1ee,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _6485dcbe3067 = f"config/{_40678c147770}/finetune/classes_config.json"

    _d4784c14cb05 = _ec7f6cba5d65(
        _995f2d3d766f=_631e181d05af,
        _1c3f4164fd27=_1c3f4164fd27,
        _a6277937f5f9=_a6277937f5f9,
        _4b4156a51b33=_4b4156a51b33,
        _392807bb1379=_3452840f8b53,
        _6485dcbe3067=_6485dcbe3067,
        _444207a3049c=_23de24905655,
        _cb5eb1657652=_0d003313e595,
        _fdab6fdf7d92=_93deb9ebebed._39d64b4b4147,
        _593221415ff1=_593221415ff1,
        _6515f45dcb62=_6515f45dcb62,
        _83803ca9e1b3=_83803ca9e1b3,
    )
    _a6277937f5f9._16cb933dd2c9(f"Test samples: {_394e52343ab1(_d4784c14cb05)}, Labels: {_2421fd837705(_d4784c14cb05, 'actual_num_of_labels', 'NA')}")

    _8dae4ada751c = [_4139182b77a0 for _, _4139182b77a0 in _fea59ef1d7ba._f87bf4829a02() if not _4139182b77a0._e0f473595c5e]
    _4a9d72f44f49 = _519e74bc5a8f(_d4df7922b415=_8dae4ada751c) if _eca4ffdc8767 == "gpu" else "auto"

    _6c8f5bd6d19d = _0b6b8bf1298f(
        _644376fb429e=_eca4ffdc8767,
        _c53545024061=_8bf12f773c3d(_eca4ffdc8767=_eca4ffdc8767),
        _035bc1a457fc=1,
        _ff44199a8a4c=_4a9d72f44f49 if _eca4ffdc8767 == "gpu" else "auto",
        _d894ba077594=1,
        _adcf02783180=_adcf02783180,
        _162efcb5ea6d=0,
        _089e66a26589=_23de24905655,
        _f1f96a99c825=_23de24905655,
        _2bd94b2c5fd5=_0d003313e595,
        _02ef0f477cac=_23de24905655,
    )

    _4c8f1fdeaf33 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.batch_size", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Batch size for training"
    )

    _e78bc05b78cd = _64e52b141c50(
        _d4784c14cb05=_d4784c14cb05,
        _ed6b19dc04d3=_4c8f1fdeaf33,
        _fdab6fdf7d92=_93deb9ebebed._39d64b4b4147,
        _593221415ff1=_593221415ff1,
        _717b73383417=_4b4156a51b33,
        _83803ca9e1b3=_83803ca9e1b3,
    )

    _64ade7a85670 = 0.0
    _0e64364d0a73 = [{}]
    _dd32f137ea58 = "SUCCESS"
    try:
        _0e64364d0a73 = _6c8f5bd6d19d._6326b269b95d(_fea59ef1d7ba._6b513ae0d102(_1a2b12d0060a._a52d17bd521a), _d2db72fba597=_e78bc05b78cd)
        _64ade7a85670 = _0e64364d0a73[0]._af53e12df5e6("test_accuracy", 0.0)
    except _51b0375893f5 as _61f9abd6495a:
        _a6277937f5f9._790227b46bd4(f"Exception during testing: {_61f9abd6495a}")
        _dd32f137ea58 = _1e0559c00049(_61f9abd6495a)

    # Log test metrics to CSV
    _0c090755b7da = f"metrics/{_40678c147770}"
    os._e32c8c5eb906(_0c090755b7da, _c77d0643db60=_0d003313e595)
    _eee85ee5cbe2 = "finetune_results.csv"
    _4dafe756491c = os._9128251cc3e7._801ebd91c46e(_0c090755b7da, _eee85ee5cbe2)
    _00cc1ba6dd5c = _f466b5589263.copy()
    _00cc1ba6dd5c._9461239c6723("pretrained_embedding_model", _0d2bc6c67339)
    _00cc1ba6dd5c._9461239c6723("tokenizer", _0d2bc6c67339)
    _00cc1ba6dd5c._9461239c6723("device_dict", _0d2bc6c67339)
    _86cecb1d11d8 = _8d00080b1af9()
    _339d81e5f460, _86443047e7d9, _927825bfa50c = _86cecb1d11d8._1a44d1c91f64(_5ada83d1e1ee(_e7512f365420 * 1000))
    _ea8d688779ef = f"{_339d81e5f460} hours, {_86443047e7d9} minutes and {_927825bfa50c} seconds"
    _bc76ebcd3b5b = "{ " + ", "._801ebd91c46e(f"{_9af133737b3c}: {_8a3795ff482f}" for _9af133737b3c, _8a3795ff482f in _00cc1ba6dd5c._8dba68cf2da7()) + " }"
    _f8eaf9afc3b0 = {
        'accuracy': _64ade7a85670,
        'params': _bc76ebcd3b5b,
        'execution_time': _e7512f365420,
        'readable_time': _ea8d688779ef,
        'failure_reason': _dd32f137ea58,
        'other_metrics': json._4e6f989ab66c(_0e64364d0a73[0])
    }
    with _2a3cf57fbb75(_4dafe756491c, 'a+', _b7fd5e6f3be0="utf8") as _718154dadf8e:
        _9503c2c4893f = _4fe8fcfddcdf._e59058a56df7(_718154dadf8e, _bf63ad463c2f=_f8eaf9afc3b0._aae0c508f441())
        if os._9128251cc3e7._aff108681a34(_4dafe756491c) == 0:
            _9503c2c4893f._b764850c5071()
        _9503c2c4893f._7bf81afd715e(_f8eaf9afc3b0)
    _a6277937f5f9._16cb933dd2c9(f"Test accuracy: {_64ade7a85670}")

    try:
        if _520ecd4460a0(_fea59ef1d7ba, 'peft_config') or _a63f28f352ab(_fea59ef1d7ba, _3b48af9b9ea5):
            _a6277937f5f9._16cb933dd2c9("PEFT/LoRA detected. Merging adapters...")
            try:
                _fea59ef1d7ba = _fea59ef1d7ba._bfaa169602d7()
                _a6277937f5f9._16cb933dd2c9("LoRA adapters merged successfully.")
            except _51b0375893f5 as _f113017d114f:
                _a6277937f5f9._379eea1cfccd(f"LoRA merge failed: {_f113017d114f}. Proceeding without merge.")
        else:
            _a6277937f5f9._16cb933dd2c9("No PEFT/LoRA detected. Skipping merge.")

        if _7ce792509a67:
            _a6277937f5f9._16cb933dd2c9("Dequantizing for CPU save...")
            _fea59ef1d7ba = _fea59ef1d7ba._6b513ae0d102(_057bd3212fd5="cuda" if _1a2b12d0060a._ae874fa92e02._730ac1f94a39() else "cpu")
            try:
                _fea59ef1d7ba = _5d90539a961b(_fea59ef1d7ba)
            except _51b0375893f5 as _063a4f2b8e70:
                _a6277937f5f9._379eea1cfccd(f"dequantize_bnb_model failed, using manual_dequantize: {_063a4f2b8e70}")
                _fea59ef1d7ba = _649b9a87b541(_fea59ef1d7ba)
            _fea59ef1d7ba = _fea59ef1d7ba._2a3dac76ff5c()
            if _1a2b12d0060a._4b9c11695d5a._bf9ea21654b3():
                _1a2b12d0060a._4b9c11695d5a._65b8c61032de()
            _45f2e127ff0c = _fea59ef1d7ba._6b513ae0d102(_c44e03fdf05f=_1a2b12d0060a._a52d17bd521a, _057bd3212fd5="cpu")
            _f9e64c8929d4 = "saved_models"
            os._e32c8c5eb906(_f9e64c8929d4, _c77d0643db60=_0d003313e595)
            _b02c783348f3 = os._9128251cc3e7._801ebd91c46e(_f9e64c8929d4, "finetuned_model.pt")
            _1a2b12d0060a._316f4c93b4e5(_45f2e127ff0c._c5e8e55890eb(), _b02c783348f3)
            _a6277937f5f9._16cb933dd2c9(f"Saved lightweight checkpoint at {_b02c783348f3}")
    except _51b0375893f5 as _61f9abd6495a:
        _a6277937f5f9._790227b46bd4(f"Exception during model saving: {_61f9abd6495a}")
        _dd32f137ea58 += " ; Model saving failed: " + _1e0559c00049(_61f9abd6495a)
        # Update the CSV with updated failure_reason if needed, but since it's already written, perhaps append another row or update


def _3e7174688413(_93deb9ebebed: _485683b36c77._5a898e43ac1a) -> _0d2bc6c67339:
    _5e8926bad324()
    _fb1939df6569 = _e536d0a256a8()
    _21dcbdd537b4 = _fb1939df6569._6d98450a5260(_93deb9ebebed._596985207154)
    _4f6291369caf = _d755ec4669ca()
    _a6277937f5f9 = _4f6291369caf._3f24c1ceffc3(_21dcbdd537b4)
    _48cb90b6056c = _c5bde786c0a6()
    _86cecb1d11d8 = _8d00080b1af9()

    _1a1f06ca3b8c = time.time()

    _83803ca9e1b3 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="app.random_seed", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Seed for reproducibility under app.random_seed"
    )
    _de8077c14dd9.random._d7574d22036e(_83803ca9e1b3)
    random._d7574d22036e(_83803ca9e1b3)
    _7192a60ef22d._7ab0adbf5ab9(_83803ca9e1b3, _fa106b7c563f=_0d003313e595)
    _1a2b12d0060a._a262fbe92652(_83803ca9e1b3)
    if _1a2b12d0060a._ae874fa92e02._730ac1f94a39():
        _1a2b12d0060a._ae874fa92e02._7bb05574c377(_83803ca9e1b3)

    _1e7262b686e9 = 0
    if _1a2b12d0060a._ae874fa92e02._730ac1f94a39():
        _313d0f6e0adc = _5ada83d1e1ee(os._4a2539c23f62._af53e12df5e6('RANK', '0'))
        _99ef8c220a06 = _5ada83d1e1ee(os._4a2539c23f62._af53e12df5e6('WORLD_SIZE', '1'))
        try:
            if not _1a2b12d0060a._4b9c11695d5a._bf9ea21654b3():
                _1a2b12d0060a._4b9c11695d5a._714c0f25fc92(
                    _9eb0160c176c=_93deb9ebebed._9eb0160c176c, _1e7262b686e9=_313d0f6e0adc, _99ef8c220a06=_99ef8c220a06,
                    _7ff50bbc8078=_1d88715d392f(_ff2eb11f8f63=600)
                )
        except _51b0375893f5:
            pass
    if _1a2b12d0060a._4b9c11695d5a._bf9ea21654b3():
        try:
            _1e7262b686e9 = _1a2b12d0060a._4b9c11695d5a._e5b92026da35()
        except _51b0375893f5:
            _1e7262b686e9 = _2421fd837705(_93deb9ebebed, "local_rank", 0)

    _40678c147770 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="app.model_config_name", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Model config name under app.model_config_name"
    )
    _0c090755b7da = f"metrics/{_40678c147770}"
    os._e32c8c5eb906(_0c090755b7da, _c77d0643db60=_0d003313e595)

    _7e9712e59a5d = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.pretrained_embedding", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _3d73acd29c26 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="app.pretrained_embeddings_dir", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _67fe2f87bdf9 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.pretrained_embedding_overwrite_old", _c44e03fdf05f=_62ebad0006cd, _c756c21156d2=_23de24905655, _1e3c357cb552=_23de24905655,
        _6be0e2a0a3a9="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _7ce792509a67 = _23de24905655
    _6f1c6a3d89ea = _0d2bc6c67339
    _593221415ff1 = _23de24905655
    _6515f45dcb62 = _0d2bc6c67339
    if _4ab507153f69:
        try:
            _6f1c6a3d89ea = _1440d6cf61d2(
                _4ecdf1dfa7e8=_0d003313e595,
                _97756f642ae8=_0a3def023d46(),
                _bb81f89b8da1=_0d003313e595,
                _31ad73d79d0c="nf4",
            )
            _7ce792509a67 = _0d003313e595
        except _51b0375893f5:
            _6f1c6a3d89ea = _0d2bc6c67339

    _3a7fda7660e0 = os._9128251cc3e7._801ebd91c46e(
        _3d73acd29c26,
        _7e9712e59a5d + ("_quantized" if _4ab507153f69 else "_fp32")
    )

    _48cb90b6056c._3e1ec9832c80(_3a7fda7660e0, _b0139783060c=_67fe2f87bdf9)
    if _48cb90b6056c._4a8c5c8ba236(_3a7fda7660e0):
        _a6277937f5f9._16cb933dd2c9(f"Downloading pretrained embedding {_7e9712e59a5d}")
        try:
            from _0bd9e62f72ef import _dffd4819be9a, _618f4ad7908d
            _9b707939a8ef = _dffd4819be9a()
            _223511e17416 = _9b707939a8ef._223511e17416(_7e9712e59a5d)
            _adfa68b6c64a = _2421fd837705(_223511e17416, "sha", _0d2bc6c67339) or _0d2bc6c67339
            if "llama" in _7e9712e59a5d._61bb49703bcd():
                _ef113a361764 = os._5845f53534dd("HF_LLAMA3B_TOKEN")
                if _ef113a361764:
                    _618f4ad7908d(token=_ef113a361764)
                else:
                    raise _4a5c82041e8e("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _51b0375893f5:
            _adfa68b6c64a = _0d2bc6c67339
        from _d1f989acccca import _15f0e7844bb3
        _f105e53d2361 = _15f0e7844bb3._180624da0590(_7e9712e59a5d, _adfa68b6c64a=_adfa68b6c64a)
        _a6277937f5f9._16cb933dd2c9(f"config of pretrained embedding used {_f105e53d2361}")
        if "llama" in _7e9712e59a5d._61bb49703bcd():
            from _d1f989acccca import _e1c140bfd6f4, _16db017f6ab7
            _219c4f00c306 = _e1c140bfd6f4._180624da0590(
                _7e9712e59a5d, _adfa68b6c64a=_adfa68b6c64a,
                _fbd6550365da=_6f1c6a3d89ea if (_4ab507153f69 and _6f1c6a3d89ea) else _0d2bc6c67339
            )
            _4b4156a51b33 = _16db017f6ab7._180624da0590(_7e9712e59a5d, _adfa68b6c64a=_adfa68b6c64a, _1b17098b2f3a=_23de24905655)
            _593221415ff1 = _0d003313e595
            _6515f45dcb62 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _d1f989acccca import _2eef7dbb46eb, _16db017f6ab7
            _219c4f00c306 = _2eef7dbb46eb._180624da0590(_7e9712e59a5d, _adfa68b6c64a=_adfa68b6c64a)
            _4b4156a51b33 = _16db017f6ab7._180624da0590(_7e9712e59a5d, _adfa68b6c64a=_adfa68b6c64a)
            _593221415ff1 = _23de24905655
        try:
            with _2a3cf57fbb75(os._9128251cc3e7._801ebd91c46e(_3a7fda7660e0, 'revision.txt'), 'w') as _7825e4ccba9b:
                _7825e4ccba9b._a84d7a37b86a(_adfa68b6c64a)
            _219c4f00c306._8ec0a8bc0d85(_3a7fda7660e0)
            _4b4156a51b33._8ec0a8bc0d85(_3a7fda7660e0)
        except _51b0375893f5:
            _a6277937f5f9._379eea1cfccd("Saving pretrained embedding locally failed; continuing.")
    else:
        _a6277937f5f9._16cb933dd2c9(f"Loading pretrained embedding from {_3a7fda7660e0}")
        from _d1f989acccca import _15f0e7844bb3
        _f105e53d2361 = _15f0e7844bb3._180624da0590(_3a7fda7660e0)
        _a6277937f5f9._16cb933dd2c9(f"Config of pretrained embedding used {_f105e53d2361}")
        if "llama" in _7e9712e59a5d._61bb49703bcd():
            from _d1f989acccca import _e1c140bfd6f4, _16db017f6ab7
            _219c4f00c306 = _e1c140bfd6f4._180624da0590(
                _3a7fda7660e0,
                _fbd6550365da=_6f1c6a3d89ea if (_4ab507153f69 and _6f1c6a3d89ea) else _0d2bc6c67339
            )
            _4b4156a51b33 = _16db017f6ab7._180624da0590(_3a7fda7660e0, _1b17098b2f3a=_23de24905655)
            _593221415ff1 = _0d003313e595
            _6515f45dcb62 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _d1f989acccca import _2eef7dbb46eb, _16db017f6ab7
            _219c4f00c306 = _2eef7dbb46eb._180624da0590(_3a7fda7660e0)
            _4b4156a51b33 = _16db017f6ab7._180624da0590(_3a7fda7660e0)
            _593221415ff1 = _23de24905655

    _3452840f8b53 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.max_seq_len", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Maximum sequence length for training"
    )
    _4c8f1fdeaf33 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.batch_size", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Batch size for training"
    )
    _3ff1bbe16064 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.data_sample_share", _c44e03fdf05f=_2a3dac76ff5c, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Proportion of dataset used for sampling"
    )
    _b88915d470f5 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.optimizer", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Optimizer type under run_config.optimizer"
    )
    _f455972e5913 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.learning_rate", _c44e03fdf05f=_2a3dac76ff5c, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Learning rate for optimizer"
    )
    _d05e87a2759f = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.num_backbone_model_units_unfrozen", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Number of backbone model units unfrozen during training"
    )
    _68c67caedee2 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.loss_type", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Loss function type under run_config.loss_type"
    )
    _4d6bff6959a9 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.num_fc_layers_in_classifier_head", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Number of FC layers in classifier head"
    )
    _50b2f4834de9 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.activation_function_for_layer", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Activation function for layer under run_config.activation_function_for_layer"
    )
    _03c29a1a3117 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.add_dropout_after_embedding", _c44e03fdf05f=_62ebad0006cd, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _1c3108c4dab7 = _23de24905655 if _d05e87a2759f == 0 else _0d003313e595

    _f466b5589263: _80c7bd989f6e[_1e0559c00049, _514de1916267] = {
        "device_dict": _915274dfb8ed(),
        "pretrained_embedding_model": _219c4f00c306,
        "optimizer": _b88915d470f5,
        "num_backbone_model_units_unfrozen": _d05e87a2759f,
        "loss_type": _68c67caedee2,
        "lr": _f455972e5913,
        "is_train": _0d003313e595,
        "tokenizer": _4b4156a51b33,
        "random_seed": _83803ca9e1b3,
        "num_fc_layers": _4d6bff6959a9,
        "activation_function_for_layer": _50b2f4834de9,
        "add_dropout_after_embedding": _03c29a1a3117,
    }
    _f466b5589263._7e9a069e4e9f({"pretrained_model_embedding_name": _7e9712e59a5d})
    if _593221415ff1:
        _f466b5589263._7e9a069e4e9f({"prompt_length": _3452840f8b53})

    _995f2d3d766f = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="app.data_dir", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Base data directory under app.data_dir"
    )
    _fcd3d72daf24 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="dataset.data_source_dir",
        _c44e03fdf05f=_1e0559c00049,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Base data source directory under data."
    )
    _e61fac7727e7 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="dataset.train.data_dir", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Subdirectory for training data under dataset.train.data_dir"
    )
    _6b2875c72815 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="dataset.val.data_dir", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Subdirectory for validation data under dataset.val.data_dir"
    )
    _044f4eef30ae = os._9128251cc3e7._801ebd91c46e(_995f2d3d766f, _fcd3d72daf24, _e61fac7727e7)
    _c40178807c6a = os._9128251cc3e7._801ebd91c46e(_995f2d3d766f, _fcd3d72daf24, _6b2875c72815)
    _1c3f4164fd27 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="dataset.files_have_header", _c44e03fdf05f=_62ebad0006cd, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Whether dataset files have header"
    )
    _6485dcbe3067 = f"config/{_40678c147770}/finetune/classes_config.json"
    _48cb90b6056c._3e1ec9832c80(os._9128251cc3e7._8e3fb1d4b573(_6485dcbe3067))

    _a318d096730b = _ec7f6cba5d65(
        _995f2d3d766f=_044f4eef30ae, _1c3f4164fd27=_1c3f4164fd27, _a6277937f5f9=_a6277937f5f9,
        _4b4156a51b33=_4b4156a51b33, _392807bb1379=_3452840f8b53,
        _6485dcbe3067=_6485dcbe3067, _444207a3049c=_0d003313e595, _cb5eb1657652=_23de24905655,
        _83803ca9e1b3=_83803ca9e1b3, _e86db318c934=_3ff1bbe16064,
        _fdab6fdf7d92=_93deb9ebebed._39d64b4b4147, _593221415ff1=_593221415ff1, _6515f45dcb62=_6515f45dcb62,
    )
    _e60f97f7c404 = _ec7f6cba5d65(
        _995f2d3d766f=_c40178807c6a, _1c3f4164fd27=_1c3f4164fd27, _a6277937f5f9=_a6277937f5f9,
        _4b4156a51b33=_4b4156a51b33, _392807bb1379=_3452840f8b53,
        _6485dcbe3067=_6485dcbe3067, _444207a3049c=_23de24905655, _cb5eb1657652=_23de24905655,
        _83803ca9e1b3=_83803ca9e1b3, _e86db318c934=_3ff1bbe16064,
        _fdab6fdf7d92=_93deb9ebebed._39d64b4b4147, _593221415ff1=_593221415ff1, _6515f45dcb62=_6515f45dcb62,
    )
    _a6277937f5f9._16cb933dd2c9(f"Number of training data samples {_a318d096730b._42b1164fb880()} with {_2421fd837705(_a318d096730b, 'label_sample_counter', 'NA')} labels and {_2421fd837705(_a318d096730b, 'actual_dataset_length', 'NA')} unique samples with {_2421fd837705(_a318d096730b, 'actual_num_of_labels', 'NA')} unique labels")
    _a6277937f5f9._16cb933dd2c9(f"Number of validation data samples {_e60f97f7c404._42b1164fb880()} with {_2421fd837705(_e60f97f7c404, 'label_sample_counter', 'NA')} labels and {_2421fd837705(_e60f97f7c404, 'actual_dataset_length', 'NA')} unique samples with {_2421fd837705(_e60f97f7c404, 'actual_num_of_labels', 'NA')} unique labels.")

    _2a2650921c10 = _a318d096730b._89af0b557e19()
    _03aa5e9895d8 = [_a318d096730b._d6147424b5fb(_e8db4c57af3c) for _e8db4c57af3c in _a318d096730b._1e2e927e53a1._aae0c508f441()]
    _083572e766ec = _a318d096730b._083572e766ec
    _31c0a24e5be7 = {}
    for _3958b5abc0db, (_11a626b7603b, _ad373fe26739) in _7af1816838aa(_dd973ee88e00(_03aa5e9895d8, _083572e766ec)):
        _39f340e55295 = _4b4156a51b33(_11a626b7603b, _791d0aa2e5e9=_23de24905655)["input_ids"] if _593221415ff1 else [_3958b5abc0db]
        if _39f340e55295:
            _31c0a24e5be7[_11a626b7603b] = [_39f340e55295, _ad373fe26739]
    _bc0815d427e5(f"Class Weights Generated {_31c0a24e5be7}")
    _a6277937f5f9._16cb933dd2c9(f"{_2a2650921c10} classes in training data with classes {_03aa5e9895d8} and weights {_083572e766ec}")
    _f466b5589263._7e9a069e4e9f({"class_weights": _31c0a24e5be7, 
                   "class_names": _03aa5e9895d8,
                   "model_config_name": _40678c147770})

    if "llama" in _7e9712e59a5d and _593221415ff1:
        _fea59ef1d7ba = _4085db40467b(**_f466b5589263)
    else:
        _fea59ef1d7ba = _d0db9f6ef8be(**_f466b5589263)

    _52bf03ca041a = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4,
        _ec3a8bcfaf07="operation_mode",
        _c44e03fdf05f=_1e0559c00049,
        _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _80cad56b263c = _0d2bc6c67339
    if _52bf03ca041a == "model_finetune":
        _80cad56b263c = _d94eeaa7864e(
            _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.finetuned_model_path", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_23de24905655,
            _6be0e2a0a3a9="Optional path to pretrained model checkpoint for finetuning"
        )
        if _80cad56b263c:
            _b3e3c00f37f1(_fea59ef1d7ba, _80cad56b263c, _16c485e03912="cpu")
            _a6277937f5f9._16cb933dd2c9(f"Loaded finetuned model from {_80cad56b263c}")

    _8dae4ada751c = []
    if _1c3108c4dab7:
        if _7ce792509a67:
            _1aa065faca61 = lambda _34118ad50350: (
                _520ecd4460a0(_34118ad50350, "weight") and
                _a63f28f352ab(_34118ad50350._ad373fe26739, _1a2b12d0060a._4640806afea0) and
                _34118ad50350._ad373fe26739._ad7b2d91ba1b() > 64 and
                not _a63f28f352ab(_34118ad50350, (_ac624b274672._68bdfdd343d5._77f6a7fe39a9, _ac624b274672._68bdfdd343d5._b1dc02d64cba, _ac624b274672._68bdfdd343d5._b5dded60aaff))
            )
        else:
            _1aa065faca61 = lambda _34118ad50350: (
                _520ecd4460a0(_34118ad50350, "weight") and
                _a63f28f352ab(_34118ad50350._ad373fe26739, _1a2b12d0060a._4640806afea0) and
                _34118ad50350._ad373fe26739._ad7b2d91ba1b() > 64
            )
        _6f4dbc92795d = _fea59ef1d7ba._7f33db98d789
        _977daa819b03 = _0f717e2fbd0d(_6f4dbc92795d, _1aa065faca61=_1aa065faca61, _38724a5664d2=_0d2bc6c67339, _f4b4078843ed=_0d2bc6c67339)
        try:
            _06a840a21835 = _6479d4c31c73._9c11ec32fd15 if _593221415ff1 else _6479d4c31c73._8ef0dd355f20
            _0ef6cfe5e510 = _1e03ca2810f6(_0d2bc6c67339, _977daa819b03, _06a840a21835)
        except _51b0375893f5:
            _0ef6cfe5e510 = _c3b578489d96(
                _168828c52d29=8, _77f8cdc397e7=32, _eb6d7ca8aea3=0.1,
                _977daa819b03=_222567c59f44(_977daa819b03._aae0c508f441()) if _977daa819b03 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _4c56dddaa861=_6479d4c31c73._9c11ec32fd15 if _593221415ff1 else _6479d4c31c73._8ef0dd355f20
            )
        _a6277937f5f9._16cb933dd2c9(f"Target Module trainable parameters before applying LORA is {_10328da260de(_6f4dbc92795d)} and size is {_fcfe81c5f8ee(_6f4dbc92795d)} GB")
        _6f4dbc92795d = _d1602e7c1f8a(_6f4dbc92795d, _0ef6cfe5e510)
        for _ec3a8bcfaf07, _240ed32e751e in _fea59ef1d7ba._f87bf4829a02():
            if not _240ed32e751e._f98c1fd04b2c:
                _240ed32e751e = _240ed32e751e._c8052d612925()
            if "encoder" in _ec3a8bcfaf07 and "lora" not in _ec3a8bcfaf07:
                _240ed32e751e._e0f473595c5e = _23de24905655
            elif "embedding" in _ec3a8bcfaf07:
                _240ed32e751e._e0f473595c5e = "lora" in _ec3a8bcfaf07
        _a6277937f5f9._16cb933dd2c9(f"Target Module trainable parameters after applying LORA is {_10328da260de(_6f4dbc92795d)} and size is {_fcfe81c5f8ee(_6f4dbc92795d)} GB")

    _6ac126a5f51b = _5ada83d1e1ee(_13a894931e8f())
    _eca4ffdc8767 = 'gpu' if _1a2b12d0060a._ae874fa92e02._730ac1f94a39() else 'cpu'
    _0d5db68f2e31 = f"cuda:{_6ac126a5f51b}" if _eca4ffdc8767 == 'gpu' else 'cpu'
    if _d2a8ada6fbf0._4b10a043ba03() is _23de24905655:
        _a6277937f5f9._16cb933dd2c9(f"Setting model to {_0d5db68f2e31}")
        _fea59ef1d7ba = _fea59ef1d7ba._6b513ae0d102(_c44e03fdf05f=_1a2b12d0060a._a52d17bd521a, _057bd3212fd5=_0d5db68f2e31)

    _39804dbc8130 = {}
    _39804dbc8130['model_name'] = _40678c147770
    _d894ba077594 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="model.max_epochs", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Maximum number of epochs under model.max_epochs"
    )
    _39804dbc8130['max_epochs'] = _d894ba077594
    _5f9a7a5e115d = _b7e94a1e095b._721e801048c5(_19dc5cefe1c3=2)
    _44361509fe32 = "epoch_training_metrics.csv"
    _90a12416d8e1 = "model_training_summary_metrics.csv"
    _ac60e157aba6 = _c0cce5da7ce8(_a6277937f5f9,
                                       _5f9a7a5e115d=_5f9a7a5e115d,
                                       _39804dbc8130=_39804dbc8130,
                                       _9782e4aacf25=_0c090755b7da,
                                       _acd60702b419=_44361509fe32,
                                       _fc0fb67bd7b7=_90a12416d8e1,
                                       _46c72a461493=_0d2bc6c67339)
    _f6489df03130 = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="app.checkpoints_dir", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _342871641b30 = os._9128251cc3e7._801ebd91c46e(_f6489df03130, _40678c147770, "finetune")
    os._e32c8c5eb906(_342871641b30, _c77d0643db60=_0d003313e595)
    _6d1fcd54f0b3 = _b7e94a1e095b._0cb097a6b15d(_d3f51d27e6b6=_342871641b30, _c4f2447a7048="intermediate",
        _02929aa6d48b=1, _a2eba22b1a42=1000, _bf63251c463b=_23de24905655)
    _5c3eb354269c = _b7e94a1e095b._0cb097a6b15d(_d3f51d27e6b6=_342871641b30, _c4f2447a7048="last", _02929aa6d48b=1,
        _bf63251c463b=_0d003313e595, _be30d3fb0990="val_loss", _7ffe55016067="min")
    _db87c3e0eed2 = _b7e94a1e095b._61cd4c7c9b48(_be30d3fb0990="val_accuracy", _5762e9d2d296=3, _7ffe55016067="max", _eb2cbd108326=_0d003313e595)
    _42ab1beabf6a = _b7e94a1e095b._ce3b763e7619(_7adf8e03fcca='step')

    for _ec3a8bcfaf07, _4139182b77a0 in _fea59ef1d7ba._f87bf4829a02():
        if not _4139182b77a0._e0f473595c5e:
            _8dae4ada751c._f216cbf756e0(_4139182b77a0)
    _4a9d72f44f49 = _519e74bc5a8f(_d4df7922b415=_8dae4ada751c) if _eca4ffdc8767 == "gpu" else "auto"
    _035bc1a457fc = _93deb9ebebed._035bc1a457fc

    _d481f0b8da9b = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.accumulate_grad_batches", _c44e03fdf05f=_5ada83d1e1ee, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _353351b6a6af = _d94eeaa7864e(
        _21dcbdd537b4=_21dcbdd537b4, _ec3a8bcfaf07="run_config.training_precision_type", _c44e03fdf05f=_1e0559c00049, _c756c21156d2=_0d003313e595,
        _6be0e2a0a3a9="Training precision type under run_config.training_precision_type"
    )
    _5a6981ea4c71 = _0b6b8bf1298f(
        _644376fb429e=_eca4ffdc8767, _c53545024061=_8bf12f773c3d(_eca4ffdc8767),
        _035bc1a457fc=_035bc1a457fc, _ff44199a8a4c=_4a9d72f44f49 if _eca4ffdc8767 == "gpu" else "auto",
        _d894ba077594=_d894ba077594, _089e66a26589=_23de24905655, _5a58cda7ed63=_0d003313e595,
        _2bd94b2c5fd5=_0d003313e595, _02ef0f477cac=_23de24905655,
        _d481f0b8da9b=_d481f0b8da9b,
        _adcf02783180=_353351b6a6af,
        _b7e94a1e095b=[_ac60e157aba6, _6d1fcd54f0b3, _5c3eb354269c, _db87c3e0eed2, _42ab1beabf6a],
    )

    _9795a5c5cce0 = _64e52b141c50(
        _a318d096730b=_a318d096730b, _e60f97f7c404=_e60f97f7c404,
        _ad53eec812f9=_0d003313e595, _717b73383417=_4b4156a51b33,
        _ed6b19dc04d3=_4c8f1fdeaf33, _fdab6fdf7d92=_93deb9ebebed._39d64b4b4147,
        _593221415ff1=_593221415ff1, _83803ca9e1b3=_83803ca9e1b3
    )

    if _6ac126a5f51b == 0:
        _3df7f98d33ea = _2ff86360a625(_fea59ef1d7ba)
        _a6277937f5f9._16cb933dd2c9(f"Model Summary before fit is {_3df7f98d33ea}")
        _a6277937f5f9._16cb933dd2c9(f"Model structure is {_fea59ef1d7ba}")

    _edfcadf68967 = os._9128251cc3e7._801ebd91c46e(_342871641b30, "intermediate.ckpt")
    if os._9128251cc3e7._2105cf946a0c(_edfcadf68967):
        _5a6981ea4c71._b6a4c819acdf(_fea59ef1d7ba, _d2db72fba597=_9795a5c5cce0, _e9cb061b27f3=_edfcadf68967)
    else:
        _5a6981ea4c71._b6a4c819acdf(_fea59ef1d7ba, _d2db72fba597=_9795a5c5cce0)

    if _1a2b12d0060a._4b9c11695d5a._bf9ea21654b3():
        _1a2b12d0060a._4b9c11695d5a._65b8c61032de()
    _d250a301c9d3 = _5c3eb354269c._972e949581b4
    if _d250a301c9d3:
        _a6277937f5f9._16cb933dd2c9(f"Best checkpoint saved at {_d250a301c9d3}")

    _e7512f365420 = time.time() - _1a1f06ca3b8c
    # Run test set
    _a07dfcc6927f(_93deb9ebebed, _21dcbdd537b4, _f466b5589263, _d250a301c9d3, _4b4156a51b33, _219c4f00c306, _3452840f8b53, _593221415ff1, _6515f45dcb62, _1c3108c4dab7, _a6277937f5f9, _adcf02783180=_353351b6a6af, _e7512f365420=_e7512f365420)

    _a6277937f5f9._16cb933dd2c9("Finetuning completed successfully.")


def _542492b38a4b():
    _3c670659eb06 = _485683b36c77._3095bdfa87ca(_17c88aa2b0da='Fine-tune a language identification model (single run)')
    _3c670659eb06._3abd6a9e4768('--config_file_path', _ba846e279bae=_1e0559c00049, _c756c21156d2=_0d003313e595)
    _3c670659eb06._3abd6a9e4768('--num_nodes', _ba846e279bae=_5ada83d1e1ee, _1e3c357cb552=1)
    _3c670659eb06._3abd6a9e4768('--cpu_cores', _ba846e279bae=_5ada83d1e1ee, _1e3c357cb552=1)
    _3c670659eb06._3abd6a9e4768('--local-rank', _ba846e279bae=_5ada83d1e1ee)
    _3c670659eb06._3abd6a9e4768('--backend', _ba846e279bae=_1e0559c00049, _1e3c357cb552="gloo", _2e64abcab19a=['gloo', 'mpi', 'nccl'])
    _3c670659eb06._3abd6a9e4768('--run_timestamp', _ba846e279bae=_2a3dac76ff5c, _1e3c357cb552=_0d2bc6c67339)
    _93deb9ebebed = _3c670659eb06._77a39f44e8a0()
    if _93deb9ebebed._0cf958d769e9 is _0d2bc6c67339:
        _93deb9ebebed._0cf958d769e9 = time.time()
    _7af2cc7499b9(_93deb9ebebed)


if __name__ == "__main__":
    _92a8f79bb131()