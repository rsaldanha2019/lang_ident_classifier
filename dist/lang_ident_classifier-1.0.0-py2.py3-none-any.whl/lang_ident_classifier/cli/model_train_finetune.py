# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:59 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from __future__ import _e9785719a263
from _8052048e2832 import _f1672344c70c
import _0e31561462da, _c6e3414ba896, json, os, random, _8798b8bc94ce, sys, time, _310974e96212
from _2cd00e739241 import _fe1fd6206aec
from typing import _b163d2bdb6b1, _95e4f353415c, _d22d02721834
import _139b01a81b5e as _675c291ec8c9, _94458ccee1a3, _2cd60a0787db as _63ad9723ab35
from _2cd60a0787db import _a6cb416e8d0f
from _2cd60a0787db._c787ffe74a20 import _da385ac6f57a
from _2cd60a0787db._c787ffe74a20._21293ffa500b._59439c41ef96 import _20ad7c95ad89
from _cf8a5f90c10e import _77cfb280d8df, _23b5a4e4a78d, _90c4eccc0613
from _da62f36732d9._8cafacba063d._516876e0fd12._a13f44c3618e import _60d46ff3a920
from _da62f36732d9._8cafacba063d._516876e0fd12._0afd093f0e7a import _0ff88feb0d94
from _da62f36732d9._8cafacba063d._516876e0fd12._c94d3c2f3f45 import _ee5776e31c2f
from _da62f36732d9._8cafacba063d._516876e0fd12._26b82b00a22e import _91b3cd2111fe
from _da62f36732d9._8cafacba063d._af2497d998c5._5a975dff2adf import _bf3617f51697
from _da62f36732d9._8cafacba063d._af2497d998c5._e0f2f308a7b5 import _de908988e6f5
from _da62f36732d9._8cafacba063d._67b29f7739da._12ce652ae413 import _c0752286b49d
from _da62f36732d9._8cafacba063d._67b29f7739da._a0ed6e9bcb89 import _24fc5417108a
from _da62f36732d9._8cafacba063d._da385ac6f57a._3fad94509ff0 import _e527d773966a
from _da62f36732d9._8cafacba063d._516876e0fd12._ff9437714d88 import _347fe5450762
from _da62f36732d9._8cafacba063d._516876e0fd12._ff9437714d88 import (
    _e8c984df5d49, _342f01505556, _93c169c4df2d,
    _807f849604c9, _220be11000f3, _fa3062994644,
    _7df145006db4, _ab26eb940dd5, _397a4cdefcb8,
    _a5d9ae6e5a51, _828501a82cea, _c12f60652326,
    _6b99850e4de9, _7b5526ec9f8f
)

os._9878b69c635e["TOKENIZERS_PARALLELISM"] = "True"
_d41a804c6044 = _94458ccee1a3._a40301094a9f._08153d2ad341() and _94458ccee1a3._a40301094a9f._d444aae5b024() > 0
if _d41a804c6044:
    try:
        from _bbcb6e28d1fa import _ee3e13c9236a
        import _1090596a728c as _d3c33a4faf48
    except _f1f2d26e4cd5:
        _d3c33a4faf48 = _c7fd1498ea70


def _13289f4f29cf(_580d85e3dfdb: _94458ccee1a3._6bcd13e9abe5._bbe6649c0dc2, _ac93f9480fdd: _11f908f43443, _d55c11e881be: _d22d02721834[_11f908f43443] = _c7fd1498ea70) -> _c7fd1498ea70:
    if not os._ee1e77b45f88._d389d77d75ab(_ac93f9480fdd):
        raise _86a18fcc4e5c(f"Finetuned model path not found: {_ac93f9480fdd}")
    if _ac93f9480fdd._2fcedb666a9a((".pt", ".pth")):
        _3cbd0403f81c = _d55c11e881be or ("cpu" if not _94458ccee1a3._a40301094a9f._08153d2ad341() else _c7fd1498ea70)
        _214571bc4dcc = _94458ccee1a3._f4d8b13eefdb(_ac93f9480fdd, _d55c11e881be=_3cbd0403f81c)
        _ae9bc84538fd = _214571bc4dcc._c95a45f4a171("state_dict", _214571bc4dcc._c95a45f4a171("model_state_dict", _214571bc4dcc)) if _8948f9279740(_214571bc4dcc, _86c7ce89fb20) else _214571bc4dcc
        if not _8948f9279740(_ae9bc84538fd, _86c7ce89fb20):
            raise _b93bb329d464(f"Loaded .pt file does not contain state_dict mapping: {_ac93f9480fdd}")
        _580d85e3dfdb._ef63e24af30f(_ae9bc84538fd, _a902b84fe035=_3421a83ffcd6)
    elif _ac93f9480fdd._2fcedb666a9a(".ckpt"):
        try:
            if _c916678e1919(_580d85e3dfdb._a92908c9e1b5, "load_from_checkpoint"):
                _a9440ac39375 = _580d85e3dfdb._a92908c9e1b5._49a97c178c2a(_ac93f9480fdd, **{})
                _580d85e3dfdb._ef63e24af30f(_a9440ac39375._8b9cdf7aaf01(), _a902b84fe035=_3421a83ffcd6)
                return
            _214571bc4dcc = _94458ccee1a3._f4d8b13eefdb(_ac93f9480fdd, _d55c11e881be="cpu")
            _ae9bc84538fd = _214571bc4dcc._c95a45f4a171("state_dict", _214571bc4dcc)
            if not _8948f9279740(_ae9bc84538fd, _86c7ce89fb20):
                raise _b93bb329d464("Lightning checkpoint did not contain a recognizable state_dict.")
            _580d85e3dfdb._ef63e24af30f(_ae9bc84538fd, _a902b84fe035=_3421a83ffcd6)
        except _f1f2d26e4cd5 as _609f586a82b6:
            raise _b93bb329d464(f"Failed to load .ckpt into model: {_609f586a82b6}") from _609f586a82b6
    else:
        raise _ecd7777e87e5("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _4acd57406751(_05302286c5cd: _0e31561462da._e164545f97c0, _c5447b25b620: _b163d2bdb6b1, _93e35dd4abdd: _95e4f353415c[_11f908f43443, _b163d2bdb6b1], _c716d191a47d: _11f908f43443, _77b3a5891890: _b163d2bdb6b1, _8f046f7aa5b6: _b163d2bdb6b1, _5d4ffca291f9: _b97a1b8b1a1e, _4cc096e701af: _e0271856c06d, _63f392f0d646: _b163d2bdb6b1, _ed9311825a1f: _e0271856c06d, _7ab6b40ee35e: _f1672344c70c, _b5f0463f3cf0: _11f908f43443 = "32", _a694ccf31520: _222de7de3ac0 = 0.0):
    """
    Compute test accuracy using the best checkpoint.
    """
    _f36b4eb20156 = _3421a83ffcd6
    _792455e551be = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="app.model_config_name",
        _a6967d689e7e=_11f908f43443,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )

    if _d41a804c6044:
        _b08d85820247 = _ee3e13c9236a(
            _8740be807d82=_d2fefb10bcb9,
            _d1eb95cfeb31=_93c169c4df2d(),
            _8305badf1ebc=_d2fefb10bcb9,
            _937fc9c8b091="nf4",
        )
        _f36b4eb20156 = _d2fefb10bcb9

    _5e89bf89a672 = 'gpu' if _94458ccee1a3._a40301094a9f._08153d2ad341() else 'cpu'
    _570a5457e70a = 'cpu'
    if _5e89bf89a672 == 'gpu':
        _4272259ebf51 = _94458ccee1a3._72a64e3fd3f5._1a0e64ebc14d() if _94458ccee1a3._72a64e3fd3f5._638456e5ee63() else 0
        _570a5457e70a = f"cuda:{_4272259ebf51}"
    else:
        _4272259ebf51 = -1

    _1be0395fb536 = _93e35dd4abdd._c95a45f4a171("pretrained_model_embedding_name")

    _93e35dd4abdd._caa024cfb668({
        "tokenizer": _77b3a5891890,
        "pretrained_embedding_model": _8f046f7aa5b6,
        "device_dict": _342f01505556(),
        "model_config_name": _792455e551be,
    })

    if not _c716d191a47d:
        _7ab6b40ee35e._77cf45ec3649("No best checkpoint found. Proceeding with current model weights.")
    else:
        _7ab6b40ee35e._77cf45ec3649(f"Testing with best checkpoint: {_c716d191a47d}")

    if "llama" in (_1be0395fb536 or ""):
        _580d85e3dfdb = _24fc5417108a(**_93e35dd4abdd)
        _4cc096e701af = _d2fefb10bcb9
    else:
        _580d85e3dfdb = _c0752286b49d(**_93e35dd4abdd)

    if _ed9311825a1f:
        if _f36b4eb20156:
            _aeb9315dacf9 = lambda _6b0b2d13c38c: (
                _c916678e1919(_6b0b2d13c38c, "weight") and _8948f9279740(_6b0b2d13c38c._d28cdd81fc14, _94458ccee1a3._6c2fed0ccb0f) and _6b0b2d13c38c._d28cdd81fc14._070250ee92af() > 64 and
                not _8948f9279740(_6b0b2d13c38c, (_d3c33a4faf48._6bcd13e9abe5._8a01025229e3, _d3c33a4faf48._6bcd13e9abe5._60f15b763d24, _417ef7da019f(_d3c33a4faf48._6bcd13e9abe5, "LinearNF4", _59cf9425aa51(_c7fd1498ea70))))
            )
        else:
            _aeb9315dacf9 = lambda _6b0b2d13c38c: (
                _c916678e1919(_6b0b2d13c38c, "weight") and _8948f9279740(_6b0b2d13c38c._d28cdd81fc14, _94458ccee1a3._6c2fed0ccb0f) and _6b0b2d13c38c._d28cdd81fc14._070250ee92af() > 64
            )
        _39d106b6b495 = _580d85e3dfdb._5e3e4a5de6bf
        _32ad4a117014 = _807f849604c9(_39d106b6b495, _aeb9315dacf9=_aeb9315dacf9, _ff1e5b684d1f=_c7fd1498ea70, _28a0b86d3c63=_c7fd1498ea70)
        _62515805d912 = _23b5a4e4a78d(
            _f9c91cb0417a=8,
            _b6987a2984de=32,
            _9a7f91244b71=0.1,
            _32ad4a117014=_607c676f6f21(_32ad4a117014._5b972974155c()) if _32ad4a117014 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _8625b07dfd46=_77cfb280d8df._f7cb349a0de8 if _4cc096e701af else _77cfb280d8df._b26b62067ffa
        )
        _7ab6b40ee35e._77cf45ec3649(f"In test Target Module trainable parameters before applying LORA: {_220be11000f3(_39d106b6b495)}")
        _39d106b6b495 = _fa3062994644(_39d106b6b495, _62515805d912)
        _7ab6b40ee35e._77cf45ec3649(f"In test Target Module trainable parameters after applying LORA: {_220be11000f3(_39d106b6b495)}")

    if _c716d191a47d:
        _7ab6b40ee35e._77cf45ec3649(f"Loading checkpoint from: {_c716d191a47d}")
        try:
            _214571bc4dcc = _94458ccee1a3._f4d8b13eefdb(_c716d191a47d, _d55c11e881be=_570a5457e70a)
            _ae9bc84538fd = _214571bc4dcc._c95a45f4a171("state_dict", _214571bc4dcc)
            # Strip prefixes
            _f2b24c142dc0 = {}
            for _4818e24f40fe, _f65cee4722c4 in _ae9bc84538fd._71b46940896d():
                _3d9c5ca95bdb = _4818e24f40fe
                while _3d9c5ca95bdb._16b2b1cab743('module.'):
                    _3d9c5ca95bdb = _3d9c5ca95bdb[7:]
                while _3d9c5ca95bdb._16b2b1cab743('_forward_module.'):
                    _3d9c5ca95bdb = _3d9c5ca95bdb[16:]
                _f2b24c142dc0[_3d9c5ca95bdb] = _f65cee4722c4
            # Load with strict=False to handle potential extras
            _580d85e3dfdb._ef63e24af30f(_f2b24c142dc0, _a902b84fe035=_3421a83ffcd6)
        except _f1f2d26e4cd5 as _609f586a82b6:
            _7ab6b40ee35e._19c678a59df2(f"Checkpoint load failed: {_609f586a82b6}")
    else:
        _7ab6b40ee35e._19c678a59df2("No best checkpoint found. Proceeding with in-memory model weights.")

    if _94458ccee1a3._a40301094a9f._08153d2ad341():
        _4272259ebf51 = _b97a1b8b1a1e(_e8c984df5d49())

    if _20ad7c95ad89._58d0551ea5d1() is _3421a83ffcd6:
        _7ab6b40ee35e._77cf45ec3649(f"Setting model to {_570a5457e70a}")
        _580d85e3dfdb = _580d85e3dfdb._e435a0efba3f(_a6967d689e7e=_94458ccee1a3._82007e46b445, _c4af3b8f2743=_570a5457e70a)

    _d95a380d6baa = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="app.data_dir",
        _a6967d689e7e=_11f908f43443,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="data_dir under app specifies the base directory for datasets."
    )

    _d61e63150cae = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="dataset.data_source_dir",
        _a6967d689e7e=_11f908f43443,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Base data source directory under data."
    )

    _89577bbc12e1 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="dataset.test.data_dir",
        _a6967d689e7e=_11f908f43443,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _120c376f6c6a = os._ee1e77b45f88._b9c777cde331(_d95a380d6baa,_d61e63150cae,_89577bbc12e1)

    _554d3968293b = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="dataset.files_have_header",
        _a6967d689e7e=_e0271856c06d,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _770bf289479c = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="app.random_seed",
        _a6967d689e7e=_b97a1b8b1a1e,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _6985fb314e87 = f"config/{_792455e551be}/finetune/classes_config.json"

    _9f729b554d74 = _bf3617f51697(
        _d95a380d6baa=_120c376f6c6a,
        _554d3968293b=_554d3968293b,
        _7ab6b40ee35e=_7ab6b40ee35e,
        _77b3a5891890=_77b3a5891890,
        _3670941b85fb=_5d4ffca291f9,
        _6985fb314e87=_6985fb314e87,
        _e9f1c81e45f4=_3421a83ffcd6,
        _02cc9c088d9c=_d2fefb10bcb9,
        _f3a2e3d43d25=_05302286c5cd._df5ab3e29300,
        _4cc096e701af=_4cc096e701af,
        _63f392f0d646=_63f392f0d646,
        _770bf289479c=_770bf289479c,
    )
    _7ab6b40ee35e._77cf45ec3649(f"Test samples: {_08ee0230934f(_9f729b554d74)}, Labels: {_417ef7da019f(_9f729b554d74, 'actual_num_of_labels', 'NA')}")

    _d983502c5e76 = [_b3e175c57eb6 for _, _b3e175c57eb6 in _580d85e3dfdb._12ebddea3091() if not _b3e175c57eb6._765e2bfbb0d7]
    _36fbe345344c = _6b99850e4de9(_f29260ea57a1=_d983502c5e76) if _5e89bf89a672 == "gpu" else "auto"

    _2d8e5a7b78f3 = _a6cb416e8d0f(
        _6b5e0fd0fd6e=_5e89bf89a672,
        _109ba5dbbad6=_ab26eb940dd5(_5e89bf89a672=_5e89bf89a672),
        _6c6e6ce0e6eb=1,
        _882da6384ad6=_36fbe345344c if _5e89bf89a672 == "gpu" else "auto",
        _97e946e45b0b=1,
        _b5f0463f3cf0=_b5f0463f3cf0,
        _a92be55d89f9=0,
        _3675ce72a5f4=_3421a83ffcd6,
        _dddae09be9a3=_3421a83ffcd6,
        _913b4ab89a9a=_d2fefb10bcb9,
        _ec507c1da3b4=_3421a83ffcd6,
    )

    _3b806a5c44fa = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.batch_size", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Batch size for training"
    )

    _cb6b439ac66a = _de908988e6f5(
        _9f729b554d74=_9f729b554d74,
        _b9bf566a1b12=_3b806a5c44fa,
        _f3a2e3d43d25=_05302286c5cd._df5ab3e29300,
        _4cc096e701af=_4cc096e701af,
        _9a83d7571b4b=_77b3a5891890,
        _770bf289479c=_770bf289479c,
    )

    _6dd5c1fafc96 = 0.0
    _dcdd6162a70c = [{}]
    _92c539491cb2 = "SUCCESS"
    try:
        _dcdd6162a70c = _2d8e5a7b78f3._03729f25e0dc(_580d85e3dfdb._e435a0efba3f(_94458ccee1a3._82007e46b445), _d3396530bd20=_cb6b439ac66a)
        _6dd5c1fafc96 = _dcdd6162a70c[0]._c95a45f4a171("test_accuracy", 0.0)
    except _f1f2d26e4cd5 as _609f586a82b6:
        _7ab6b40ee35e._80c756b48d2a(f"Exception during testing: {_609f586a82b6}")
        _92c539491cb2 = _11f908f43443(_609f586a82b6)

    # Log test metrics to CSV
    _c023f878e534 = f"metrics/{_792455e551be}"
    os._f3513d435fc3(_c023f878e534, _fc0b321b3de8=_d2fefb10bcb9)
    _8caf8a4cb822 = "finetune_results.csv"
    _2ed2a5067bdc = os._ee1e77b45f88._b9c777cde331(_c023f878e534, _8caf8a4cb822)
    _6a15cc00d7cf = _93e35dd4abdd.copy()
    _6a15cc00d7cf._6f1d12295f17("pretrained_embedding_model", _c7fd1498ea70)
    _6a15cc00d7cf._6f1d12295f17("tokenizer", _c7fd1498ea70)
    _6a15cc00d7cf._6f1d12295f17("device_dict", _c7fd1498ea70)
    _5cfdf01672fe = _91b3cd2111fe()
    _49da27b0e59e, _5513ee33b79b, _769c7e07b9f5 = _5cfdf01672fe._19f8b9580cd6(_b97a1b8b1a1e(_a694ccf31520 * 1000))
    _563fd3f6399c = f"{_49da27b0e59e} hours, {_5513ee33b79b} minutes and {_769c7e07b9f5} seconds"
    _5ce162e1d264 = "{ " + ", "._b9c777cde331(f"{_4818e24f40fe}: {_f65cee4722c4}" for _4818e24f40fe, _f65cee4722c4 in _6a15cc00d7cf._71b46940896d()) + " }"
    _054412647752 = {
        'accuracy': _6dd5c1fafc96,
        'params': _5ce162e1d264,
        'execution_time': _a694ccf31520,
        'readable_time': _563fd3f6399c,
        'failure_reason': _92c539491cb2,
        'other_metrics': json._4a6200d7a9bd(_dcdd6162a70c[0])
    }
    with _b8f3c211fca4(_2ed2a5067bdc, 'a+', _15863092c71e="utf8") as _e6d45670f7ea:
        _edf32f673361 = _c6e3414ba896._4f57caad360f(_e6d45670f7ea, _a15372686fbc=_054412647752._5b972974155c())
        if os._ee1e77b45f88._8ec6ba5de622(_2ed2a5067bdc) == 0:
            _edf32f673361._f3db98554ec9()
        _edf32f673361._c63ed6dd511d(_054412647752)
    _7ab6b40ee35e._77cf45ec3649(f"Test accuracy: {_6dd5c1fafc96}")

    try:
        if _c916678e1919(_580d85e3dfdb, 'peft_config') or _8948f9279740(_580d85e3dfdb, _90c4eccc0613):
            _7ab6b40ee35e._77cf45ec3649("PEFT/LoRA detected. Merging adapters...")
            try:
                _580d85e3dfdb = _580d85e3dfdb._58dd3209fdf8()
                _7ab6b40ee35e._77cf45ec3649("LoRA adapters merged successfully.")
            except _f1f2d26e4cd5 as _a636a69f21c2:
                _7ab6b40ee35e._19c678a59df2(f"LoRA merge failed: {_a636a69f21c2}. Proceeding without merge.")
        else:
            _7ab6b40ee35e._77cf45ec3649("No PEFT/LoRA detected. Skipping merge.")

        if _f36b4eb20156:
            _7ab6b40ee35e._77cf45ec3649("Dequantizing for CPU save...")
            _580d85e3dfdb = _580d85e3dfdb._e435a0efba3f(_c4af3b8f2743="cuda" if _94458ccee1a3._a40301094a9f._08153d2ad341() else "cpu")
            try:
                _580d85e3dfdb = _828501a82cea(_580d85e3dfdb)
            except _f1f2d26e4cd5 as _83220ed816f1:
                _7ab6b40ee35e._19c678a59df2(f"dequantize_bnb_model failed, using manual_dequantize: {_83220ed816f1}")
                _580d85e3dfdb = _a5d9ae6e5a51(_580d85e3dfdb)
            _580d85e3dfdb = _580d85e3dfdb._222de7de3ac0()
            if _94458ccee1a3._72a64e3fd3f5._638456e5ee63():
                _94458ccee1a3._72a64e3fd3f5._3a95983511c4()
            _4e89530718f6 = _580d85e3dfdb._e435a0efba3f(_a6967d689e7e=_94458ccee1a3._82007e46b445, _c4af3b8f2743="cpu")
            _ef165fb65831 = "saved_models"
            os._f3513d435fc3(_ef165fb65831, _fc0b321b3de8=_d2fefb10bcb9)
            _dd039095c9ba = os._ee1e77b45f88._b9c777cde331(_ef165fb65831, "finetuned_model.pt")
            _94458ccee1a3._d91d4bd77dd4(_4e89530718f6._8b9cdf7aaf01(), _dd039095c9ba)
            _7ab6b40ee35e._77cf45ec3649(f"Saved lightweight checkpoint at {_dd039095c9ba}")
    except _f1f2d26e4cd5 as _609f586a82b6:
        _7ab6b40ee35e._80c756b48d2a(f"Exception during model saving: {_609f586a82b6}")
        _92c539491cb2 += " ; Model saving failed: " + _11f908f43443(_609f586a82b6)
        # Update the CSV with updated failure_reason if needed, but since it's already written, perhaps append another row or update


def _01eb132dc5ec(_05302286c5cd: _0e31561462da._e164545f97c0) -> _c7fd1498ea70:
    _397a4cdefcb8()
    _fea73253fabb = _60d46ff3a920()
    _c5447b25b620 = _fea73253fabb._a9b9488315d1(_05302286c5cd._606b74b6e8c4)
    _5c88af105042 = _0ff88feb0d94()
    _7ab6b40ee35e = _5c88af105042._91eb12ff9159(_c5447b25b620)
    _8f51febbbda0 = _ee5776e31c2f()
    _5cfdf01672fe = _91b3cd2111fe()

    _69b0a4a2403f = time.time()

    _770bf289479c = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="app.random_seed", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Seed for reproducibility under app.random_seed"
    )
    _675c291ec8c9.random._d36f76312760(_770bf289479c)
    random._d36f76312760(_770bf289479c)
    _63ad9723ab35._c8bebdb8d721(_770bf289479c, _264aa0084364=_d2fefb10bcb9)
    _94458ccee1a3._ac59c5deed85(_770bf289479c)
    if _94458ccee1a3._a40301094a9f._08153d2ad341():
        _94458ccee1a3._a40301094a9f._5276aeaf6732(_770bf289479c)

    _f98bdcf671e9 = 0
    if _94458ccee1a3._a40301094a9f._08153d2ad341():
        _ca48af52ddb8 = _b97a1b8b1a1e(os._9878b69c635e._c95a45f4a171('RANK', '0'))
        _1a135afca373 = _b97a1b8b1a1e(os._9878b69c635e._c95a45f4a171('WORLD_SIZE', '1'))
        try:
            if not _94458ccee1a3._72a64e3fd3f5._638456e5ee63():
                _94458ccee1a3._72a64e3fd3f5._419c8fee8bde(
                    _4bc60686ff6a=_05302286c5cd._4bc60686ff6a, _f98bdcf671e9=_ca48af52ddb8, _1a135afca373=_1a135afca373,
                    _28658ba867d6=_fe1fd6206aec(_ba0c3e3baece=600)
                )
        except _f1f2d26e4cd5:
            pass
    if _94458ccee1a3._72a64e3fd3f5._638456e5ee63():
        try:
            _f98bdcf671e9 = _94458ccee1a3._72a64e3fd3f5._1a0e64ebc14d()
        except _f1f2d26e4cd5:
            _f98bdcf671e9 = _417ef7da019f(_05302286c5cd, "local_rank", 0)

    _792455e551be = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="app.model_config_name", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Model config name under app.model_config_name"
    )
    _c023f878e534 = f"metrics/{_792455e551be}"
    os._f3513d435fc3(_c023f878e534, _fc0b321b3de8=_d2fefb10bcb9)

    _1be0395fb536 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.pretrained_embedding", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _ac2362d4ff35 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="app.pretrained_embeddings_dir", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _b38c2d241e84 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.pretrained_embedding_overwrite_old", _a6967d689e7e=_e0271856c06d, _b8c4b7fd47fe=_3421a83ffcd6, _1521cacde25a=_3421a83ffcd6,
        _2fd6ffc9c223="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _f36b4eb20156 = _3421a83ffcd6
    _b08d85820247 = _c7fd1498ea70
    _4cc096e701af = _3421a83ffcd6
    _63f392f0d646 = _c7fd1498ea70
    if _d41a804c6044:
        try:
            _b08d85820247 = _ee3e13c9236a(
                _8740be807d82=_d2fefb10bcb9,
                _d1eb95cfeb31=_93c169c4df2d(),
                _8305badf1ebc=_d2fefb10bcb9,
                _937fc9c8b091="nf4",
            )
            _f36b4eb20156 = _d2fefb10bcb9
        except _f1f2d26e4cd5:
            _b08d85820247 = _c7fd1498ea70

    _b19913ce123c = os._ee1e77b45f88._b9c777cde331(
        _ac2362d4ff35,
        _1be0395fb536 + ("_quantized" if _d41a804c6044 else "_fp32")
    )

    _8f51febbbda0._8880633c6786(_b19913ce123c, _feaff5c8af52=_b38c2d241e84)
    if _8f51febbbda0._d2523475f589(_b19913ce123c):
        _7ab6b40ee35e._77cf45ec3649(f"Downloading pretrained embedding {_1be0395fb536}")
        try:
            from _30a2f7754449 import _3f4610e5b020, _2383f2a819f3
            _8000cd53e02c = _3f4610e5b020()
            _96618e590cf5 = _8000cd53e02c._96618e590cf5(_1be0395fb536)
            _732027879ba3 = _417ef7da019f(_96618e590cf5, "sha", _c7fd1498ea70) or _c7fd1498ea70
            if "llama" in _1be0395fb536._5db64091736a():
                _aee3d028e789 = os._4b0a0ee80709("HF_LLAMA3B_TOKEN")
                if _aee3d028e789:
                    _2383f2a819f3(token=_aee3d028e789)
                else:
                    raise _b93bb329d464("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _f1f2d26e4cd5:
            _732027879ba3 = _c7fd1498ea70
        from _bbcb6e28d1fa import _5c3c88671771
        _057620c4d84f = _5c3c88671771._0cd7f6113517(_1be0395fb536, _732027879ba3=_732027879ba3)
        _7ab6b40ee35e._77cf45ec3649(f"config of pretrained embedding used {_057620c4d84f}")
        if "llama" in _1be0395fb536._5db64091736a():
            from _bbcb6e28d1fa import _05cbd23a536c, _7c0ff336b21f
            _8f046f7aa5b6 = _05cbd23a536c._0cd7f6113517(
                _1be0395fb536, _732027879ba3=_732027879ba3,
                _72a0634b8eed=_b08d85820247 if (_d41a804c6044 and _b08d85820247) else _c7fd1498ea70
            )
            _77b3a5891890 = _7c0ff336b21f._0cd7f6113517(_1be0395fb536, _732027879ba3=_732027879ba3, _b8d90b0a2800=_3421a83ffcd6)
            _4cc096e701af = _d2fefb10bcb9
            _63f392f0d646 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _bbcb6e28d1fa import _7aae69a17f38, _7c0ff336b21f
            _8f046f7aa5b6 = _7aae69a17f38._0cd7f6113517(_1be0395fb536, _732027879ba3=_732027879ba3)
            _77b3a5891890 = _7c0ff336b21f._0cd7f6113517(_1be0395fb536, _732027879ba3=_732027879ba3)
            _4cc096e701af = _3421a83ffcd6
        try:
            with _b8f3c211fca4(os._ee1e77b45f88._b9c777cde331(_b19913ce123c, 'revision.txt'), 'w') as _de84a46d31f6:
                _de84a46d31f6._a6a838a3f142(_732027879ba3)
            _8f046f7aa5b6._5c7a850961bb(_b19913ce123c)
            _77b3a5891890._5c7a850961bb(_b19913ce123c)
        except _f1f2d26e4cd5:
            _7ab6b40ee35e._19c678a59df2("Saving pretrained embedding locally failed; continuing.")
    else:
        _7ab6b40ee35e._77cf45ec3649(f"Loading pretrained embedding from {_b19913ce123c}")
        from _bbcb6e28d1fa import _5c3c88671771
        _057620c4d84f = _5c3c88671771._0cd7f6113517(_b19913ce123c)
        _7ab6b40ee35e._77cf45ec3649(f"Config of pretrained embedding used {_057620c4d84f}")
        if "llama" in _1be0395fb536._5db64091736a():
            from _bbcb6e28d1fa import _05cbd23a536c, _7c0ff336b21f
            _8f046f7aa5b6 = _05cbd23a536c._0cd7f6113517(
                _b19913ce123c,
                _72a0634b8eed=_b08d85820247 if (_d41a804c6044 and _b08d85820247) else _c7fd1498ea70
            )
            _77b3a5891890 = _7c0ff336b21f._0cd7f6113517(_b19913ce123c, _b8d90b0a2800=_3421a83ffcd6)
            _4cc096e701af = _d2fefb10bcb9
            _63f392f0d646 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _bbcb6e28d1fa import _7aae69a17f38, _7c0ff336b21f
            _8f046f7aa5b6 = _7aae69a17f38._0cd7f6113517(_b19913ce123c)
            _77b3a5891890 = _7c0ff336b21f._0cd7f6113517(_b19913ce123c)
            _4cc096e701af = _3421a83ffcd6

    _5d4ffca291f9 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.max_seq_len", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Maximum sequence length for training"
    )
    _3b806a5c44fa = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.batch_size", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Batch size for training"
    )
    _54c54932a8b6 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.data_sample_share", _a6967d689e7e=_222de7de3ac0, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Proportion of dataset used for sampling"
    )
    _bf8838c522fc = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.optimizer", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Optimizer type under run_config.optimizer"
    )
    _5001d35e0289 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.learning_rate", _a6967d689e7e=_222de7de3ac0, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Learning rate for optimizer"
    )
    _ba58d2dfb01e = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.num_backbone_model_units_unfrozen", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Number of backbone model units unfrozen during training"
    )
    _d681c73d14d7 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.loss_type", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Loss function type under run_config.loss_type"
    )
    _eb3d0b05816e = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.num_fc_layers_in_classifier_head", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Number of FC layers in classifier head"
    )
    _3e6f7968f420 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.activation_function_for_layer", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Activation function for layer under run_config.activation_function_for_layer"
    )
    _87bbf1824b58 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.add_dropout_after_embedding", _a6967d689e7e=_e0271856c06d, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _ed9311825a1f = _3421a83ffcd6 if _ba58d2dfb01e == 0 else _d2fefb10bcb9

    _93e35dd4abdd: _95e4f353415c[_11f908f43443, _b163d2bdb6b1] = {
        "device_dict": _342f01505556(),
        "pretrained_embedding_model": _8f046f7aa5b6,
        "optimizer": _bf8838c522fc,
        "num_backbone_model_units_unfrozen": _ba58d2dfb01e,
        "loss_type": _d681c73d14d7,
        "lr": _5001d35e0289,
        "is_train": _d2fefb10bcb9,
        "tokenizer": _77b3a5891890,
        "random_seed": _770bf289479c,
        "num_fc_layers": _eb3d0b05816e,
        "activation_function_for_layer": _3e6f7968f420,
        "add_dropout_after_embedding": _87bbf1824b58,
    }
    _93e35dd4abdd._caa024cfb668({"pretrained_model_embedding_name": _1be0395fb536})
    if _4cc096e701af:
        _93e35dd4abdd._caa024cfb668({"prompt_length": _5d4ffca291f9})

    _d95a380d6baa = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="app.data_dir", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Base data directory under app.data_dir"
    )
    _d61e63150cae = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="dataset.data_source_dir",
        _a6967d689e7e=_11f908f43443,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Base data source directory under data."
    )
    _65fcc9cf972f = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="dataset.train.data_dir", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Subdirectory for training data under dataset.train.data_dir"
    )
    _5be482b6f0e3 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="dataset.val.data_dir", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Subdirectory for validation data under dataset.val.data_dir"
    )
    _314932974734 = os._ee1e77b45f88._b9c777cde331(_d95a380d6baa, _d61e63150cae, _65fcc9cf972f)
    _3bfd717f3644 = os._ee1e77b45f88._b9c777cde331(_d95a380d6baa, _d61e63150cae, _5be482b6f0e3)
    _554d3968293b = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="dataset.files_have_header", _a6967d689e7e=_e0271856c06d, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Whether dataset files have header"
    )
    _6985fb314e87 = f"config/{_792455e551be}/finetune/classes_config.json"
    _8f51febbbda0._8880633c6786(os._ee1e77b45f88._f34e97643a37(_6985fb314e87))

    _c5ae2a58caaa = _bf3617f51697(
        _d95a380d6baa=_314932974734, _554d3968293b=_554d3968293b, _7ab6b40ee35e=_7ab6b40ee35e,
        _77b3a5891890=_77b3a5891890, _3670941b85fb=_5d4ffca291f9,
        _6985fb314e87=_6985fb314e87, _e9f1c81e45f4=_d2fefb10bcb9, _02cc9c088d9c=_3421a83ffcd6,
        _770bf289479c=_770bf289479c, _d47f2a7dab36=_54c54932a8b6,
        _f3a2e3d43d25=_05302286c5cd._df5ab3e29300, _4cc096e701af=_4cc096e701af, _63f392f0d646=_63f392f0d646,
    )
    _8bbef55842ae = _bf3617f51697(
        _d95a380d6baa=_3bfd717f3644, _554d3968293b=_554d3968293b, _7ab6b40ee35e=_7ab6b40ee35e,
        _77b3a5891890=_77b3a5891890, _3670941b85fb=_5d4ffca291f9,
        _6985fb314e87=_6985fb314e87, _e9f1c81e45f4=_3421a83ffcd6, _02cc9c088d9c=_3421a83ffcd6,
        _770bf289479c=_770bf289479c, _d47f2a7dab36=_54c54932a8b6,
        _f3a2e3d43d25=_05302286c5cd._df5ab3e29300, _4cc096e701af=_4cc096e701af, _63f392f0d646=_63f392f0d646,
    )
    _7ab6b40ee35e._77cf45ec3649(f"Number of training data samples {_c5ae2a58caaa._df0620f75e24()} with {_417ef7da019f(_c5ae2a58caaa, 'label_sample_counter', 'NA')} labels and {_417ef7da019f(_c5ae2a58caaa, 'actual_dataset_length', 'NA')} unique samples with {_417ef7da019f(_c5ae2a58caaa, 'actual_num_of_labels', 'NA')} unique labels")
    _7ab6b40ee35e._77cf45ec3649(f"Number of validation data samples {_8bbef55842ae._df0620f75e24()} with {_417ef7da019f(_8bbef55842ae, 'label_sample_counter', 'NA')} labels and {_417ef7da019f(_8bbef55842ae, 'actual_dataset_length', 'NA')} unique samples with {_417ef7da019f(_8bbef55842ae, 'actual_num_of_labels', 'NA')} unique labels.")

    _d70dc443a15b = _c5ae2a58caaa._ee28413c9b05()
    _d144a132dbab = [_c5ae2a58caaa._ea2516a93d8f(_042c7677efe4) for _042c7677efe4 in _c5ae2a58caaa._c4b6c40a7c5b._5b972974155c()]
    _0c364b2264b8 = _c5ae2a58caaa._0c364b2264b8
    _1dd5129c5b3b = {}
    for _2f9a7d8ef9d5, (_455aa31db394, _d28cdd81fc14) in _0bf10a8e72da(_dac9a9ef640c(_d144a132dbab, _0c364b2264b8)):
        _8e3f2876f004 = _77b3a5891890(_455aa31db394, _319c135e14fd=_3421a83ffcd6)["input_ids"] if _4cc096e701af else [_2f9a7d8ef9d5]
        if _8e3f2876f004:
            _1dd5129c5b3b[_455aa31db394] = [_8e3f2876f004, _d28cdd81fc14]
    _52dbcb01b78c(f"Class Weights Generated {_1dd5129c5b3b}")
    _7ab6b40ee35e._77cf45ec3649(f"{_d70dc443a15b} classes in training data with classes {_d144a132dbab} and weights {_0c364b2264b8}")
    _93e35dd4abdd._caa024cfb668({"class_weights": _1dd5129c5b3b, 
                   "class_names": _d144a132dbab,
                   "model_config_name": _792455e551be})

    if "llama" in _1be0395fb536 and _4cc096e701af:
        _580d85e3dfdb = _24fc5417108a(**_93e35dd4abdd)
    else:
        _580d85e3dfdb = _c0752286b49d(**_93e35dd4abdd)

    _4d4420c8ba4a = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620,
        _3d9c5ca95bdb="operation_mode",
        _a6967d689e7e=_11f908f43443,
        _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _f4b29584102b = _c7fd1498ea70
    if _4d4420c8ba4a == "model_finetune":
        _f4b29584102b = _7b5526ec9f8f(
            _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.finetuned_model_path", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_3421a83ffcd6,
            _2fd6ffc9c223="Optional path to pretrained model checkpoint for finetuning"
        )
        if _f4b29584102b:
            _786ead851d35(_580d85e3dfdb, _f4b29584102b, _d55c11e881be="cpu")
            _7ab6b40ee35e._77cf45ec3649(f"Loaded finetuned model from {_f4b29584102b}")

    _d983502c5e76 = []
    if _ed9311825a1f:
        if _f36b4eb20156:
            _aeb9315dacf9 = lambda _6b0b2d13c38c: (
                _c916678e1919(_6b0b2d13c38c, "weight") and
                _8948f9279740(_6b0b2d13c38c._d28cdd81fc14, _94458ccee1a3._6c2fed0ccb0f) and
                _6b0b2d13c38c._d28cdd81fc14._070250ee92af() > 64 and
                not _8948f9279740(_6b0b2d13c38c, (_d3c33a4faf48._6bcd13e9abe5._8a01025229e3, _d3c33a4faf48._6bcd13e9abe5._60f15b763d24, _d3c33a4faf48._6bcd13e9abe5._e743c49193f0))
            )
        else:
            _aeb9315dacf9 = lambda _6b0b2d13c38c: (
                _c916678e1919(_6b0b2d13c38c, "weight") and
                _8948f9279740(_6b0b2d13c38c._d28cdd81fc14, _94458ccee1a3._6c2fed0ccb0f) and
                _6b0b2d13c38c._d28cdd81fc14._070250ee92af() > 64
            )
        _39d106b6b495 = _580d85e3dfdb._5e3e4a5de6bf
        _32ad4a117014 = _807f849604c9(_39d106b6b495, _aeb9315dacf9=_aeb9315dacf9, _ff1e5b684d1f=_c7fd1498ea70, _28a0b86d3c63=_c7fd1498ea70)
        try:
            _af1fa91a2a5f = _77cfb280d8df._f7cb349a0de8 if _4cc096e701af else _77cfb280d8df._b26b62067ffa
            _b01f5b793e38 = _347fe5450762(_c7fd1498ea70, _32ad4a117014, _af1fa91a2a5f)
        except _f1f2d26e4cd5:
            _b01f5b793e38 = _23b5a4e4a78d(
                _f9c91cb0417a=8, _b6987a2984de=32, _9a7f91244b71=0.1,
                _32ad4a117014=_607c676f6f21(_32ad4a117014._5b972974155c()) if _32ad4a117014 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _8625b07dfd46=_77cfb280d8df._f7cb349a0de8 if _4cc096e701af else _77cfb280d8df._b26b62067ffa
            )
        _7ab6b40ee35e._77cf45ec3649(f"Target Module trainable parameters before applying LORA is {_220be11000f3(_39d106b6b495)} and size is {_c12f60652326(_39d106b6b495)} GB")
        _39d106b6b495 = _fa3062994644(_39d106b6b495, _b01f5b793e38)
        for _3d9c5ca95bdb, _28e12f714e93 in _580d85e3dfdb._12ebddea3091():
            if not _28e12f714e93._358b69c5df62:
                _28e12f714e93 = _28e12f714e93._c13c4e305ba5()
            if "encoder" in _3d9c5ca95bdb and "lora" not in _3d9c5ca95bdb:
                _28e12f714e93._765e2bfbb0d7 = _3421a83ffcd6
            elif "embedding" in _3d9c5ca95bdb:
                _28e12f714e93._765e2bfbb0d7 = "lora" in _3d9c5ca95bdb
        _7ab6b40ee35e._77cf45ec3649(f"Target Module trainable parameters after applying LORA is {_220be11000f3(_39d106b6b495)} and size is {_c12f60652326(_39d106b6b495)} GB")

    _4272259ebf51 = _b97a1b8b1a1e(_e8c984df5d49())
    _5e89bf89a672 = 'gpu' if _94458ccee1a3._a40301094a9f._08153d2ad341() else 'cpu'
    _570a5457e70a = f"cuda:{_4272259ebf51}" if _5e89bf89a672 == 'gpu' else 'cpu'
    if _20ad7c95ad89._58d0551ea5d1() is _3421a83ffcd6:
        _7ab6b40ee35e._77cf45ec3649(f"Setting model to {_570a5457e70a}")
        _580d85e3dfdb = _580d85e3dfdb._e435a0efba3f(_a6967d689e7e=_94458ccee1a3._82007e46b445, _c4af3b8f2743=_570a5457e70a)

    _33f3bb0a1c05 = {}
    _33f3bb0a1c05['model_name'] = _792455e551be
    _97e946e45b0b = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="model.max_epochs", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Maximum number of epochs under model.max_epochs"
    )
    _33f3bb0a1c05['max_epochs'] = _97e946e45b0b
    _853c21026d39 = _da385ac6f57a._cab1a4699684(_15aa92dfc047=2)
    _88632161daa7 = "epoch_training_metrics.csv"
    _bb8000649e0c = "model_training_summary_metrics.csv"
    _d130bf94ea66 = _e527d773966a(_7ab6b40ee35e,
                                       _853c21026d39=_853c21026d39,
                                       _33f3bb0a1c05=_33f3bb0a1c05,
                                       _433076625173=_c023f878e534,
                                       _d01008c9dfd7=_88632161daa7,
                                       _f4713d1c0f55=_bb8000649e0c,
                                       _2beb0908e99a=_c7fd1498ea70)
    _dd3436653a1b = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="app.checkpoints_dir", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _43576e2b3f0e = os._ee1e77b45f88._b9c777cde331(_dd3436653a1b, _792455e551be, "finetune")
    os._f3513d435fc3(_43576e2b3f0e, _fc0b321b3de8=_d2fefb10bcb9)
    _542055999109 = _da385ac6f57a._a7cc0b9b1796(_a18b08dff40f=_43576e2b3f0e, _806dfcbfa05e="intermediate",
        _29f3b7a56cbb=1, _599d607052cb=1000, _eb2588474d44=_3421a83ffcd6)
    _f37fce79ee69 = _da385ac6f57a._a7cc0b9b1796(_a18b08dff40f=_43576e2b3f0e, _806dfcbfa05e="last", _29f3b7a56cbb=1,
        _eb2588474d44=_d2fefb10bcb9, _7dee5486265d="val_loss", _67a7b9e9d19e="min")
    _97e5b5f8a094 = _da385ac6f57a._d751dd2c2841(_7dee5486265d="val_accuracy", _a78241db94d4=3, _67a7b9e9d19e="max", _6a4394374c3b=_d2fefb10bcb9)
    _b2dd5e80c63a = _da385ac6f57a._1e01fb9a96fe(_a110926bbdd8='step')

    for _3d9c5ca95bdb, _b3e175c57eb6 in _580d85e3dfdb._12ebddea3091():
        if not _b3e175c57eb6._765e2bfbb0d7:
            _d983502c5e76._fda8ff71129b(_b3e175c57eb6)
    _36fbe345344c = _6b99850e4de9(_f29260ea57a1=_d983502c5e76) if _5e89bf89a672 == "gpu" else "auto"
    _6c6e6ce0e6eb = _05302286c5cd._6c6e6ce0e6eb

    _3f710e82c0ec = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.accumulate_grad_batches", _a6967d689e7e=_b97a1b8b1a1e, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _b87dc219bca4 = _7b5526ec9f8f(
        _c5447b25b620=_c5447b25b620, _3d9c5ca95bdb="run_config.training_precision_type", _a6967d689e7e=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9,
        _2fd6ffc9c223="Training precision type under run_config.training_precision_type"
    )
    _e6f49e6b2498 = _a6cb416e8d0f(
        _6b5e0fd0fd6e=_5e89bf89a672, _109ba5dbbad6=_ab26eb940dd5(_5e89bf89a672),
        _6c6e6ce0e6eb=_6c6e6ce0e6eb, _882da6384ad6=_36fbe345344c if _5e89bf89a672 == "gpu" else "auto",
        _97e946e45b0b=_97e946e45b0b, _3675ce72a5f4=_3421a83ffcd6, _c5cc5ad40c5b=_d2fefb10bcb9,
        _913b4ab89a9a=_d2fefb10bcb9, _ec507c1da3b4=_3421a83ffcd6,
        _3f710e82c0ec=_3f710e82c0ec,
        _b5f0463f3cf0=_b87dc219bca4,
        _da385ac6f57a=[_d130bf94ea66, _542055999109, _f37fce79ee69, _97e5b5f8a094, _b2dd5e80c63a],
    )

    _957cab729b28 = _de908988e6f5(
        _c5ae2a58caaa=_c5ae2a58caaa, _8bbef55842ae=_8bbef55842ae,
        _a9496d9df5d1=_d2fefb10bcb9, _9a83d7571b4b=_77b3a5891890,
        _b9bf566a1b12=_3b806a5c44fa, _f3a2e3d43d25=_05302286c5cd._df5ab3e29300,
        _4cc096e701af=_4cc096e701af, _770bf289479c=_770bf289479c
    )

    if _4272259ebf51 == 0:
        _fdb645cd8221 = _7df145006db4(_580d85e3dfdb)
        _7ab6b40ee35e._77cf45ec3649(f"Model Summary before fit is {_fdb645cd8221}")
        _7ab6b40ee35e._77cf45ec3649(f"Model structure is {_580d85e3dfdb}")

    _28a7f0975cf2 = os._ee1e77b45f88._b9c777cde331(_43576e2b3f0e, "intermediate.ckpt")
    if os._ee1e77b45f88._d389d77d75ab(_28a7f0975cf2):
        _e6f49e6b2498._dfb437063451(_580d85e3dfdb, _d3396530bd20=_957cab729b28, _ac93f9480fdd=_28a7f0975cf2)
    else:
        _e6f49e6b2498._dfb437063451(_580d85e3dfdb, _d3396530bd20=_957cab729b28)

    if _94458ccee1a3._72a64e3fd3f5._638456e5ee63():
        _94458ccee1a3._72a64e3fd3f5._3a95983511c4()
    _47e58c37f597 = _f37fce79ee69._ca0af46beb02
    if _47e58c37f597:
        _7ab6b40ee35e._77cf45ec3649(f"Best checkpoint saved at {_47e58c37f597}")

    _a694ccf31520 = time.time() - _69b0a4a2403f
    # Run test set
    _89a63ec2e190(_05302286c5cd, _c5447b25b620, _93e35dd4abdd, _47e58c37f597, _77b3a5891890, _8f046f7aa5b6, _5d4ffca291f9, _4cc096e701af, _63f392f0d646, _ed9311825a1f, _7ab6b40ee35e, _b5f0463f3cf0=_b87dc219bca4, _a694ccf31520=_a694ccf31520)

    _7ab6b40ee35e._77cf45ec3649("Finetuning completed successfully.")


def _06cbefe75d6a():
    _2e6a73e9d4cc = _0e31561462da._00526828c234(_47aa4d685593='Fine-tune a language identification model (single run)')
    _2e6a73e9d4cc._839ea4b4a4c5('--config_file_path', _59cf9425aa51=_11f908f43443, _b8c4b7fd47fe=_d2fefb10bcb9)
    _2e6a73e9d4cc._839ea4b4a4c5('--num_nodes', _59cf9425aa51=_b97a1b8b1a1e, _1521cacde25a=1)
    _2e6a73e9d4cc._839ea4b4a4c5('--cpu_cores', _59cf9425aa51=_b97a1b8b1a1e, _1521cacde25a=1)
    _2e6a73e9d4cc._839ea4b4a4c5('--local-rank', _59cf9425aa51=_b97a1b8b1a1e)
    _2e6a73e9d4cc._839ea4b4a4c5('--backend', _59cf9425aa51=_11f908f43443, _1521cacde25a="gloo", _862cb51e223e=['gloo', 'mpi', 'nccl'])
    _2e6a73e9d4cc._839ea4b4a4c5('--run_timestamp', _59cf9425aa51=_222de7de3ac0, _1521cacde25a=_c7fd1498ea70)
    _05302286c5cd = _2e6a73e9d4cc._2e3c3b712037()
    if _05302286c5cd._183768b2073c is _c7fd1498ea70:
        _05302286c5cd._183768b2073c = time.time()
    _fdd6f9fa247b(_05302286c5cd)


if __name__ == "__main__":
    _dfc1e91bc317()