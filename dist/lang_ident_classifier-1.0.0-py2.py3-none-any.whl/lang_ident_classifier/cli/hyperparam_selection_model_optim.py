# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : lang_ident_app
# @Time             : 18/12/23 8:59 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import csv
from datetime import datetime, timedelta
from functools import partial
import gc
import json
from logging import Logger
import pickle
import random
import re
import shutil
import socket
import sqlite3
import sys
import threading
import time
import traceback
import cpuinfo
import argparse
from collections import OrderedDict
import os
os.environ["TOKENIZERS_PARALLELISM"] = "True"
import multiprocessing as mp
from prettytable import PrettyTable
# Fix NCCL issues
# os.environ["NCCL_DEBUG"] = "INFO"
# os.environ["NCCL_BLOCKING_WAIT"] = "1"
# os.environ["NCCL_ASYNC_ERROR_HANDLING"] = "1"
# os.environ["PYTHONFAULTHANDLER"] = "1"
from typing import Any, Dict, Optional
from huggingface_hub import HfApi, login
from filelock import FileLock
import optuna.integration.pytorch_distributed
import psutil
from sklearn.metrics import accuracy_score
import torch
# torch.set_num_threads(1)
# to run compiled model
# import torch._dynamo
# torch._dynamo.config.suppress_errors = True
# Optional: Disable tokenizer use of threadpools internally
# os.environ["OMP_NUM_THREADS"] = "1"
# os.environ["MKL_NUM_THREADS"] = "1"

import torch.distributed
import torch.distributed.fsdp
from torch.distributed.fsdp import CPUOffload,MixedPrecision, ShardingStrategy
from torch.distributed.fsdp.wrap import transformer_auto_wrap_policy
from torch.distributed.fsdp.wrap import size_based_auto_wrap_policy
from lang_ident_classifier.language.callbacks.custom_log_callback import LoggingCallback
import lightning as pl
# from lightning.pytorch.callbacks import RichProgressBar
import numpy as np
from peft import peft_model, LoraConfig, get_peft_model, prepare_model_for_kbit_training, TaskType

from lang_ident_classifier.language.net.gen_llm_language_identification_classifier import GenLLMLanguageIdentificationClassifier

use_cuda = torch.cuda.is_available() and torch.cuda.device_count() > 0
if use_cuda:
    from transformers import BitsAndBytesConfig
    import bitsandbytes as bnb
    from transformers.quantizers.quantizer_bnb_4bit import Bnb4BitHfQuantizer
import optuna
from optuna.trial import TrialState
from torch import Tensor, tensor
from lightning import Trainer
from lightning.pytorch import callbacks
from transformers import AutoConfig, AutoModel, AutoTokenizer, ModernBertModel
from transformers import AutoModelForSeq2SeqLM, AutoModelForCausalLM, MT5Tokenizer, MBart50Tokenizer, MT5EncoderModel
from lightning.pytorch.strategies import FSDPStrategy
from torch.distributed.fsdp import FullyShardedDataParallel
from torch.distributed.fsdp import StateDictType, FullStateDictConfig
from torch.distributed.fsdp.api import FullOptimStateDictConfig
from torch.optim import Optimizer
from lightning.pytorch.plugins.environments import SLURMEnvironment
from lang_ident_classifier.language.dataset.language_identification_data_module import LanguageIdentificationDataModule
from lang_ident_classifier.language.net.language_identification_classifier import LanguageIdentificationClassifier
from lang_ident_classifier.language.net.language_identification_classifier_modernbert import ModernBERTLanguageIdentificationClassifier
from lang_ident_classifier.language.net.new_inference_language_identification_classifier import InferenceLanguageIdentificationClassifier
from lang_ident_classifier.language.utils.property_utils import PropertyUtils
from lang_ident_classifier.language.utils.log_utils import LogUtils
from lang_ident_classifier.language.utils.file_dir_utils import FileDirUtils
from lang_ident_classifier.language.utils.date_time_utils import DateTimeUtils
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset

# Set Optuna-specific logging level
optuna.logging.set_verbosity(optuna.logging.DEBUG)
torch.set_float32_matmul_precision("high")  # Speeds up training  

class OptunaLoggingCallback(pl.Callback):
    def __init__(self, trial: optuna.trial.Trial):
        self.trial = trial

    def on_train_start(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
        # Add custom key-value pair
        trainer.callback_metrics["trial_number"] = tensor(self.trial.number)

class GPUUsagePruneCallback(pl.Callback):
    def __init__(self, trial, threshold=0.90):
        """
        Args:
            trial (optuna.trial.Trial): Optuna trial object to prune.
            threshold (float): Fraction of GPU memory usage to trigger pruning.
        """
        self.trial = trial
        self.threshold = threshold

    def _check_gpu_usage(self, trainer):
        # Only rank 0 checks and decides
        if not torch.cuda.is_available():
            return False

        if trainer.is_global_zero:
            for gpu_id in range(torch.cuda.device_count()):
                total = torch.cuda.get_device_properties(gpu_id).total_memory
                reserved = torch.cuda.memory_reserved(gpu_id)
                usage = reserved / total
                
                if usage >= self.threshold:
                    print(f"[GPU Monitor] GPU {gpu_id} usage excceded: {usage*100:.1f}%")
                    return True
        return False

    def _broadcast_prune_flag(self, flag):
        tensor_flag = torch.tensor([int(flag)], device='cuda')
        if torch.distributed.is_initialized():
            torch.distributed.broadcast(tensor_flag, src=0)
        return tensor_flag.item() == 1

    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx, dataloader_idx=0):
        if not use_cuda:
            return # for cpu alone
        should_prune = self._check_gpu_usage(trainer)
        # Broadcast decision so all ranks agree
        should_prune = self._broadcast_prune_flag(should_prune)

        if should_prune:
            if trainer.is_global_zero:
                print("[GPUUsagePruneCallback] GPU memory exceeded threshold. Pruning trial.")
            raise optuna.TrialPruned("GPU memory exceeded threshold")


# class TimeLimitedEarlyStopping(callbacks.EarlyStopping):
#     def __init__(self, max_duration_hours: float, trial: optuna.trial.Trial,**kwargs):
#         super().__init__(**kwargs)
#         self.trial = trial
#         self.max_duration_seconds = max_duration_hours * 3600
#         self.start_time = trial.user_attrs.get("trial_start_time", time.time())

#     def on_validation_end(self, trainer: pl.Trainer, pl_module: pl.LightningModule):
#         # Check runtime condition
#         elapsed_time = time.time() - self.start_time
#         if elapsed_time > self.max_duration_seconds:
#             trainer.should_stop = True
#             print(f"Stopping early due to time limit: {self.max_duration_seconds / 3600} hours reached.")
#         else:
#             # Call parent class functionality for regular early stopping
#             super().on_validation_end(trainer, pl_module)
def custom_wrap_policy(min_num_params=1_000_000):
    def wrap_policy(module, recurse, nonwrapped_numel):
        return size_based_auto_wrap_policy(
            module=module,
            recurse=recurse,
            nonwrapped_numel=nonwrapped_numel,
            min_num_params=min_num_params
        )
    return wrap_policy

class CustomFSDPStrategy(FSDPStrategy):
    def __init__(self, ig_params, ig_modules=None):
        super().__init__(sharding_strategy="FULL_SHARD",
                         cpu_offload=CPUOffload(offload_params=True),  # Explicit CPU offload  # Move non-trainable parameters to CPU
                        #  mixed_precision=MixedPrecision(param_dtype=torch.float16,   # Use bfloat16 for parameters
                        #                                 reduce_dtype=torch.float16,   # Keep reduction in float32 for stability
                        #                                 buffer_dtype=torch.float16,  # Buffers in bfloat16
                        #                                 ),
                         auto_wrap_policy="TRANSFORMER_BASED_WRAP",  # Auto-wrap transformer layers
                        #  auto_wrap_policy=transformer_auto_wrap_policy,
                        #  auto_wrap_policy=custom_wrap_policy(min_num_params=100_000),
                        #  state_dict_type="sharded" if torch.cuda.device_count() > 1 else "full",
                        **{"static_graph": True, # Lightning optimization hint
                           "forward_prefetch": True # Helps overlap compute/comm
                        }
                        )
        # self.cpu_offload = False
        # fsdp_args = {"use_orig_params": True, "ignored_parameters": ig_params}
        # fsdp_args = {"use_orig_params": True, "ignored_states": ig_params}
        fsdp_args = {
            "use_orig_params": True,  # Maintain original parameter references
            "ignored_states": ig_params,  # Ignore specific states (if defined)
        }
        if ig_modules:
            fsdp_args.update({"ignored_modules": ig_modules})
        self.kwargs = fsdp_args
# class CustomFSDPStrategy(FSDPStrategy):
#     def __init__(self, ig_params, ig_modules=None):
#         super().__init__(
#             sharding_strategy="FULL_SHARD",
#             cpu_offload=None,  # Turn CPU offload OFF for speed on PCIe
#             mixed_precision=MixedPrecision(
#                 param_dtype=torch.bfloat16,
#                 reduce_dtype=torch.bfloat16,
#                 buffer_dtype=torch.bfloat16,
#             ),
#             auto_wrap_policy="TRANSFORMER_BASED_WRAP",
#             forward_prefetch=True,  # Overlap comm and compute
#         )
#         fsdp_args = {
#             "use_orig_params": True,
#             "ignored_states": ig_params,
#         }
#         if ig_modules:
#             fsdp_args["ignored_modules"] = ig_modules
#         self.kwargs = fsdp_args

    @property
    def lightning_restore_optimizer(self) -> bool:
        """Override to disable Lightning restoring optimizers/schedulers.

        This is useful for plugins which manage restoring optimizers/schedulers.
        """
        return False

    def lightning_module_state_dict(self) -> Dict[str, Any]:
        assert self.model is not None

        with FullyShardedDataParallel.state_dict_type(
                module=self.model,
                state_dict_type=StateDictType.FULL_STATE_DICT,
                state_dict_config=FullStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
                optim_state_dict_config=FullOptimStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
        ):
            # state_dict = self.model.state_dict()
            state_dict = OrderedDict([(k.replace("_forward_module.",""), v) if k.__contains__('_forward_module') else (k, v)
                                      for k, v in self.model.state_dict().items()])

            # for key in state_dict:
            #     print(f"state dict {key} :: {state_dict[key].shape}")
            return state_dict

    def optimizer_state(self, optimizer: Optimizer) -> Dict[str, Tensor]:
        # old return FullyShardedDataParallel.full_optim_state_dict(self.model, optim=optimizer, rank0_only=True)
        """ Manually gathers the full optimizer state across all ranks in FullyShardedDataParallel. """
        # Get local (sharded) optimizer state using FullyShardedDataParallel
        optim_state = FullyShardedDataParallel.optim_state_dict(self.model, optim=optimizer)

        if torch.distributed.is_initialized():
            # Gather optimizer states from all ranks
            full_optim_state = [None] * torch.distributed.get_world_size()
            torch.distributed.all_gather_object(full_optim_state, optim_state)

            if torch.distributed.get_rank() == 0:
                # Merge optimizer states into a full dictionary
                merged_state = {"state": {}, "param_groups": full_optim_state[0]["param_groups"]}

                for state in full_optim_state:
                    for param_id, param_state in state["state"].items():
                        if param_id not in merged_state["state"]:
                            merged_state["state"][param_id] = param_state
                        else:
                            # Merge optimizer state parameters (e.g., momentum buffers)
                            for key in param_state:
                                if isinstance(param_state[key], list):
                                    merged_state["state"][param_id][key].extend(param_state[key])
                                else:
                                    merged_state["state"][param_id][key] = param_state[key]  # Overwrite

                return merged_state  # Full optimizer state for checkpointing
            else:
                return {}  # Empty dictionary for non-rank 0
        else:
            return optim_state  # Single-process training, return directly

def adjust_local_gpu_rank() -> int:
    """
    Adjust local GPU rank based on CUDA_VISIBLE_DEVICES, LOCAL_RANK, and RANK.

    Returns:
        int: local GPU rank inside visible devices (0-based).
             Returns -1 if CUDA not available (CPU).
    """
    if not torch.cuda.is_available():
        print("[adjust_local_gpu_rank] CUDA not available, using CPU (-1)", flush=True)
        return -1  # CPU fallback

    visible_devices_str = os.environ.get("CUDA_VISIBLE_DEVICES", "")
    if visible_devices_str == "":
        # No filtering: all GPUs visible
        visible_devices = [str(i) for i in range(torch.cuda.device_count())]
    else:
        # For MIG UUIDs or indices, keep as string list (don't cast to int)
        visible_devices = [x.strip() for x in visible_devices_str.split(",") if x.strip() != ""]

    local_rank_env = os.environ.get("LOCAL_RANK")
    rank_env = os.environ.get("RANK")

    if local_rank_env is not None:
        local_rank = int(local_rank_env)
        print(f"[adjust_local_gpu_rank] Using LOCAL_RANK={local_rank}", flush=True)
    elif rank_env is not None:
        local_rank = int(rank_env)
        print(f"[adjust_local_gpu_rank] LOCAL_RANK not set, using RANK={local_rank}", flush=True)
    else:
        local_rank = 0
        print("[adjust_local_gpu_rank] LOCAL_RANK and RANK not set, defaulting to 0", flush=True)

    if local_rank >= len(visible_devices):
        raise ValueError(
            f"[adjust_local_gpu_rank] local_rank ({local_rank}) >= number of visible GPUs ({len(visible_devices)}).", flush=True)

    # Now instead of returning an int index, return the device identifier (UUID or index string)
    # device_id = visible_devices[local_rank]
    device_id = local_rank
    print(f"[adjust_local_gpu_rank] CUDA_VISIBLE_DEVICES={visible_devices}, selected device={device_id}", flush=True)

    return device_id


def get_device_info() -> dict:
    """
    Generates Device information like CPU , GPU data for logging

    Returns:
        dict: device information as a dictionary
    """
    device_dict = dict()
    if torch.cuda.is_available():
        device_dict['gpu_world_size'] = str(os.environ.get('WORLD_SIZE', '1')) # get WORLD_SIZE or set value to 1
        device_dict['gpu_global_rank'] = str(os.environ.get('RANK', '0'))
        device_dict['gpu_local_rank'] = str(adjust_local_gpu_rank())
    # if SLURMEnvironment.detect() and torch.cuda.is_available():
    #     device_dict['gpu_world_size'] = str(SLURMEnvironment.world_size(pl))
    #     device_dict['gpu_global_rank'] = str(SLURMEnvironment.global_rank(pl))
    #     device_dict['gpu_local_rank'] = str(SLURMEnvironment.local_rank(pl))
    # elif SLURMEnvironment.detect() is False and torch.cuda.is_available():
    #     device_dict['gpu_world_size'] = str(os.environ.get('WORLD_SIZE', '1')) # get WORLD_SIZE or set value to 1
    #     device_dict['gpu_global_rank'] = str(os.environ.get('RANK', '0'))
    #     device_dict['gpu_local_rank'] = str(adjust_local_gpu_rank())
    elif SLURMEnvironment.detect() and torch.cuda.is_available() is False:
        device_dict['gpu_world_size'] = str(SLURMEnvironment.world_size(pl))
        device_dict['gpu_global_rank'] = str(SLURMEnvironment.global_rank(pl))
        device_dict['gpu_local_rank'] = -1
    else:
        device_dict['gpu_world_size'] = -1
        device_dict['gpu_global_rank'] = -1
        device_dict['gpu_local_rank'] = -1
    device_dict['node_name'] = socket.gethostname()
    device_dict['cpu_info'] = "CPU :: {} COUNT :: {}".format(cpuinfo.get_cpu_info()['brand_raw'], os.cpu_count())
    return device_dict

def remove_files_except(directory: str, file_to_keep: str, log: Logger):
    """
    Deletes files in specified directory except the one specified

    Args:
        directory (str): target directory to search for files to be deleted
        file_to_keep (str): file path to retain
        log (Logger): logging instance
    """
    for filename in os.listdir(directory):
        file_path = os.path.join(directory, filename)
        if os.path.isfile(file_path) and filename != file_to_keep:
            log.info(f"Removing checkpoint: {file_path}")
            os.remove(file_path)

def clear_checkpoints(log: Logger, model_config_name: str, study: optuna.Study, trial: optuna.trial.Trial):
    """
    Clears checkpoints during the recently executed Trial

    Args:
        log (Logger): logging instance
        model_config_name (str): name of the model configuration
        study (optuna.Study): instance of optuna Study
        trial (optuna.trial.Trial): instance of study trial
    """
    base_dir = f"checkpoints/{model_config_name}/trial_{trial.number}"
    ckpt_to_retain = f"{base_dir}/last-v{trial.number}.ckpt"
    
    # If the directory is empty, we can remove it
    if os.path.isdir(base_dir):
        if not os.listdir(base_dir):  # Check if empty
            os.rmdir(base_dir)  # Remove only if empty
            log.info(f"Removed empty directory: {base_dir}")
        else:
            # Check if the directory does not belong to the current trial and remove it
            trial_dirs = os.listdir(f"checkpoints/{model_config_name}")
            for dir_name in trial_dirs:
                match = re.match(r"trial_(\d+)", dir_name)
                if match:
                    trial_number = int(match.group(1))
                    if trial_number != trial.number:
                        old_dir = f"checkpoints/{model_config_name}/{dir_name}"
                        if os.path.exists(old_dir):
                            log.info(f"Removing outdated trial directory: {old_dir}")
                            shutil.rmtree(old_dir)


def study_early_stopping(study: optuna.Study, trial: optuna.trial.Trial, log):
    """
    Custom early stopping callback for Optuna study trials, with global patience.
    Handles safe access to best_trial and ensures proper distributed shutdown.
    """
    global best_trial, no_improvement_count, patience

    # Get all completed trials
    completed_trials = [t for t in study.trials if t.state == optuna.trial.TrialState.COMPLETE]
    if not completed_trials:
        log.warning("No completed trials yet, skipping early stopping check.")
        return

    try:
        best_trial_in_study = study.best_trial
    except Exception as e:
        log.warning(f"Could not fetch best_trial safely: {e}")
        return

    # Get the latest completed trial
    latest_completed_trial = completed_trials[-1]
    latest_value = latest_completed_trial.value

    if best_trial is None:
        best_trial = latest_completed_trial
    elif ((study.direction.name == 'MAXIMIZE' and latest_value > best_trial_in_study.value) or
          (study.direction.name == 'MINIMIZE' and latest_value < best_trial_in_study.value)):
        best_trial = latest_completed_trial
        no_improvement_count = 0
        log.info("Trial No Improvement Counter Reset")
    else:
        no_improvement_count += 1  # increment when no improvement
        log.info(f"Trial No Improvement Counter: {no_improvement_count} with max patience {patience}")

        if no_improvement_count >= patience:
            log.info("Stopping study since there is no improvement")
            study.stop()

            if torch.distributed.is_initialized():
                log.info("Stopping distributed job")
                try:
                    torch.distributed.barrier()
                    torch.distributed.destroy_process_group()
                    log.info("Stopped distributed job")
                except Exception as e:
                    log.warning(f"Distributed shutdown failed: {e}")

def get_study_stats(study: optuna.Study) -> str:
    """
    Takes an instance of an Optuna Study and returns the study statistics.

    Args:
        study (optuna.Study): Instance of the Optuna study.

    Returns:
        str: Study statistics for trial states.
    """
    pruned_trials = study.get_trials(deepcopy=False, states=[TrialState.PRUNED])
    complete_trials = study.get_trials(deepcopy=False, states=[TrialState.COMPLETE])
    failed_trials = study.get_trials(deepcopy=False, states=[TrialState.FAIL])
    waiting_trials = study.get_trials(deepcopy=False, states=[TrialState.WAITING])
    running_trials = study.get_trials(deepcopy=False, states=[TrialState.RUNNING])

    # Safely attempt to access best trial
    try:
        best_trial = study.best_trial
        best_trial_number = best_trial.number
        best_params = str(best_trial.params)
        best_value = str(best_trial.value)
    except (ValueError, AttributeError):  # No best trial found or study is empty
        best_trial_number = "NA"
        best_params = "NA"
        best_value = "NA"

    study_statistics = (
        f"Study {study.study_name} statistics:\n"
        f"  Number of finished trials: {len(study.trials)}\n"
        f"  Number of pruned trials: {len(pruned_trials)}\n"
        f"  Number of complete trials: {len(complete_trials)}\n"
        f"  Number of failed trials: {len(failed_trials)}\n"
        f"  Number of waiting trials: {len(waiting_trials)}\n"
        f"  Number of running trials: {len(running_trials)}\n"
        f"  Best Trial: {best_trial_number}\n"
        f"  Best hyperparameters: {best_params}\n"
        f"  Best Accuracy: {best_value}"
    )

    return study_statistics


def load_checkpoint_with_fsdp(model, fsdp_model, checkpoint_path):
    """
    Load a checkpoint into the original model when using FSDP.
    Args:
        model: The original model instance (unwrapped).
        fsdp_model: The FSDP-wrapped model instance.
        checkpoint_path: Path to the checkpoint file.
    """
    # Access the original model
    original_model = fsdp_model.module

    # Load the checkpoint
    checkpoint = torch.load(checkpoint_path)

    # Load full state dict into the original model
    with torch.distributed.fsdp.FullStateDictConfig(fsdp_model):
        original_model.load_state_dict(checkpoint, strict=True)
    return original_model

def get_lora_config(trial: optuna.trial.Trial, target_modules: dict, lora_task_type: Any):
    # Define the range for rank
    lora_rank = trial.suggest_int("lora_rank", 4, 16, step=4)

    # Dynamically calculate scaling factor based on rank
    # The formula ensures that alpha decreases as rank increases
    # scaling_factor = trial.suggest_categorical("lora_alpha_scaling_factor",[int(64 * (rank / 4))])  # Scale down as rank increases
    # scaling_factor = int(64 * (rank / 4)) # Scale down as rank increases
    # trial.set_user_attr("lora_alpha_scaling_factor", scaling_factor)
    lora_alpha=trial.suggest_int("lora_alpha_scaling_factor", 8, 32, step=4),  # Reduced scaling factor
    # Add dropout options for LoRA
    lora_dropout = trial.suggest_categorical("lora_dropout", [0.0, 0.1, 0.2])

    return LoraConfig(
        r=lora_rank[0] if isinstance(lora_rank, tuple) else lora_rank, # These checks are to ensure some tuple values are avoided
        lora_alpha= lora_alpha[0] if isinstance(lora_alpha, tuple) else lora_alpha, 
        lora_dropout= lora_dropout[0] if isinstance(lora_dropout, tuple) else lora_dropout, 
        target_modules=target_modules.keys() if target_modules else None,
        task_type=lora_task_type
    )


def dequantize_bnb_model(model):
    for module_name, module in model.named_modules():
        for child_name, child in list(module.named_children()):
            if isinstance(child, (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt)):
                try:
                    # Try to get the dequantized weights
                    weight_fp32 = child.weight.dequantize()  # shape: [out_features, in_features]
                except AttributeError:
                    # If dequantize() is not available, fallback to .data and cast
                    weight_fp32 = child.weight.data.to(torch.float32)

                bias_fp32 = child.bias.data.to(torch.float32) if child.bias is not None else None

                out_features, in_features = weight_fp32.shape

                # Create standard torch.nn.Linear with matching shape
                new_linear = torch.nn.Linear(in_features, out_features)
                new_linear.weight.data.copy_(weight_fp32)

                if bias_fp32 is not None:
                    new_linear.bias.data.copy_(bias_fp32)

                # Replace the quantized module with standard Linear
                setattr(module, child_name, new_linear)

    return model

def testset_from_best_checkpoint_callback(args, study: optuna.Study, trial: optuna.Trial, prompt_template:Any = None):
    """
    Callback to compute test accuracy using the best checkpoint across all ranks.
    """
    is_quantized = False
    # If trial is None (non-rank 0), we wait for it to be assigned (synchronize ranks)
    if trial is None:
        if torch.distributed.is_initialized():
            torch.distributed.barrier()  # Wait until the trial is assigned to rank 0
        return
    
    # Proceed if the trial is not None
    pu = PropertyUtils()
    lu = LogUtils()
    props = pu.get_yaml_config_properties(args.config_file_path)
    log = lu.get_time_rotated_log(props)
    
    # Initialize the model and checkpoint based on trial parameters
    best_checkpoint_path = trial.user_attrs.get("best_checkpoint_path", None)
    config = trial.user_attrs.get("config", None)
    pretrained_embedding_name = trial.params["pretrained_embedding_name"]
    suggested_seq_len = trial.params["max_seq_len"]
    is_gen_llm = False
    if use_cuda:
        bnb_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=get_supported_compute_dtype(),
            bnb_4bit_use_double_quant=True,
            bnb_4bit_quant_type="nf4",
            )
        is_quantized = True
        
        # bnb_config = BitsAndBytesConfig(
        #     load_in_8bit=True,  # Use 8-bit quantization (better for V100)
        #     llm_int8_threshold=6.0,  # Default threshold for mixed precision
        #     llm_int8_enable_fp32_cpu_offload=True,  # Offload to CPU to reduce memory usage
        #     llm_int8_has_fp16_weight=True,  # Ensure weights are in FP16 for efficiency
        #     )
    pretrained_embedding_model_dir_path = os.path.join(
        props.app.pretrained_embeddings_dir,
        pretrained_embedding_name + ("_quantized" if use_cuda else "_fp32")
    )
    if "ModernBERT" in pretrained_embedding_name:
        pretrained_embedding = ModernBertModel.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)
        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)
    elif "mt5" in pretrained_embedding_name:
        if use_cuda:
            pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_model_dir_path,
                                                                        quantization_config=bnb_config)
        else:
            pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_model_dir_path)
        # pretrained_embedding = MT5EncoderModel.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)
        pretrained_embedding_tokenizer = MT5Tokenizer.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)
    elif "mbart" in pretrained_embedding_name:
        pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)
        pretrained_embedding_tokenizer = MBart50Tokenizer.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)
    elif "llama" in pretrained_embedding_name:
        if use_cuda:
            pretrained_embedding = AutoModelForCausalLM.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name,
                                                                        quantization_config=bnb_config,)
        else:
            pretrained_embedding = AutoModelForCausalLM.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name,)
        # pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name, 
        #                                                                use_fast=False)
        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name,
                                                                       use_fast=False)
        is_gen_llm = True
    else:
        pretrained_embedding = AutoModel.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)
        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(pretrained_model_name_or_path=pretrained_embedding_name)

    config.update({"tokenizer": pretrained_embedding_tokenizer})
    config.update({"pretrained_embedding_model": pretrained_embedding})
    config.update({"device_dict": get_device_info()})
    # if not best_checkpoint_path:
    #     log.info("No best checkpoint found for the best trial.")
    #     return

    # log.info(f"Testing with best checkpoint: {best_checkpoint_path}")
    if not best_checkpoint_path:
        log.info("No best checkpoint found for the best trial. Proceeding with current model weights.")
    else:
        log.info(f"Testing with best checkpoint: {best_checkpoint_path}")

    if ("lora_choice" in trial.params) and (trial.params["lora_choice"]):
        if "llama" in pretrained_embedding_name:
            model = GenLLMLanguageIdentificationClassifier(**config)
            is_gen_llm = True
        else:
            model = LanguageIdentificationClassifier(**config)
        
        if is_quantized:
            attribute_filter = lambda module: (
                hasattr(module, "weight") and
                isinstance(module.weight, torch.Tensor) and
                module.weight.numel() > 64 and
                not isinstance(module, (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt, bnb.nn.LinearNF4))  # Exclude quantized layers
            )
        else:
            attribute_filter = lambda module: (
                hasattr(module, "weight") and
                isinstance(module.weight, torch.Tensor) and
                module.weight.numel() > 64
            )
        # name_filter = lambda name: "embedding" in name
        # custom_filter = lambda name, module: name.startswith("model") and hasattr(module, "bias")

        # Get target modules
        if "mt5" in pretrained_embedding_name:
            target_embedding_module = model.embedding.encoder
        elif "mbart" in pretrained_embedding_name:
            target_embedding_module = model.embedding.model.encoder
        else:
            target_embedding_module = model.embedding
        target_modules = get_target_modules(
            # model.embedding,
            target_embedding_module,
            attribute_filter=attribute_filter,
            name_filter=None,
            custom_filter=None
        )

        lora_config = LoraConfig(
            r=trial.params["lora_rank"],  # Rank for low-rank matrices
            lora_alpha=trial.params["lora_alpha_scaling_factor"],  # Reduced scaling factor
            lora_dropout=trial.params["lora_dropout"],  # Dropout for LoRA layers
            target_modules=target_modules.keys() if target_modules else None,
            task_type=TaskType.CAUSAL_LM if is_gen_llm else TaskType.TOKEN_CLS
        )

        # Step 2: Apply LoRA BEFORE loading checkpoint
        try:
            log.info(f"In test Target Module trainable parameters before applying LORA is {get_trainable_parameters(target_embedding_module)}")
            target_embedding_module = get_peft_model(target_embedding_module, lora_config)
            # target_embedding_module = prepare_model_for_kbit_training(target_embedding_module)
            # target_embedding_module = torch.quantization.quantize_dynamic(model, dtype=torch.qint8)
            log.info(f"In test Target Module trainable parameters after applying LORA is {get_trainable_parameters(target_embedding_module)}")
        except Exception as e:
            print(f"In test Exception as {e}")
        # Step 3: Load the trained checkpoint
        # ckpt = torch.load(best_checkpoint_path, map_location="cpu")
        # model.load_state_dict(ckpt["state_dict"])
        # Safely load checkpoint if available
        if best_checkpoint_path:
            log.info(f"Loading checkpoint from: {best_checkpoint_path}")
            ckpt = torch.load(best_checkpoint_path, map_location="cpu")
            model.load_state_dict(ckpt["state_dict"])
        else:
            log.warning("No best checkpoint found. Proceeding with in-memory model weights.")
    else:
        # if "llama" in pretrained_embedding_name:
        #     model = GenLLMLanguageIdentificationClassifier.load_from_checkpoint(best_checkpoint_path, **config)
        #     is_gen_llm = True
        # else:
        #     model = LanguageIdentificationClassifier.load_from_checkpoint(best_checkpoint_path, **config)
        if best_checkpoint_path:
            log.info(f"Loading checkpoint from: {best_checkpoint_path}")
            if "llama" in pretrained_embedding_name:
                model = GenLLMLanguageIdentificationClassifier.load_from_checkpoint(best_checkpoint_path, **config)
                is_gen_llm = True
            else:
                model = LanguageIdentificationClassifier.load_from_checkpoint(best_checkpoint_path, **config)
        else:
            log.warning("No best checkpoint found. Instantiating fresh model with in-memory weights.")
            if "llama" in pretrained_embedding_name:
                model = GenLLMLanguageIdentificationClassifier(**config)
                is_gen_llm = True
            else:
                model = LanguageIdentificationClassifier(**config)
    # Apply bitsandbytes quantization safely
    # for name, module in model.named_modules():
    #     if isinstance(module, torch.nn.Linear) and "embedding" not in name and "classifier" not in name:
    #         module.weight = bnb.nn.Params4bit(module.weight, requires_grad=False)
    # Handle device setup
    DEVICE = 'gpu' if torch.cuda.is_available() else 'cpu'
    local_rank = torch.distributed.get_rank() if torch.distributed.is_initialized() else 0
    if torch.cuda.is_available():
        local_rank = int(adjust_local_gpu_rank())
    
    # Set model to the appropriate device (GPU/CPU)
    if SLURMEnvironment.detect() is False:
        if torch.cuda.is_available():
            log.info(f"Setting model to cuda:{local_rank}")
            model = model.to(dtype=torch.float32, device=f"cuda:{local_rank}")
        else:
            log.info(f"Setting model to cpu with rank {local_rank}")
            model = model.to(dtype=torch.float32, device=f"cpu")

    # Paths and Dataset Setup
    test_data_dir = os.path.join(props.app.data_dir, props.dataset.test.data_dir)
    files_have_header = props.dataset.files_have_header
    classes_config_path = f"config/{props.app.model_config_name}/trial_{trial.number}/classes_config.json"

    # Create the test dataset
    test_dataset = LanguageIdentificationDataset(
        data_dir=test_data_dir,
        files_have_header=files_have_header,
        log=log,
        pretrained_embedding_tokenizer=pretrained_embedding_tokenizer,
        max_seq_length=suggested_seq_len,
        classes_config_path=classes_config_path,
        is_train=False,
        num_workers=args.cpu_cores,
        is_gen_llm=is_gen_llm,
        prompt_template=prompt_template,
        random_seed=props.app.random_seed
    )

    log.info(f"Number of test samples {test_dataset.__len__()} with {test_dataset.label_sample_counter} labels")
    
    # Initialize test trainer
    # DEVICE='cpu'
    test_trainer = Trainer(accelerator=DEVICE,
                            devices=get_devices_for_trainer(DEVICE=DEVICE),
                            num_nodes=1,
                            strategy="ddp" if DEVICE == "gpu" else "auto",
                            max_epochs=1,
                            precision=32,
                            num_sanity_val_steps=0,
                            # limit_test_batches=80,
                            use_distributed_sampler=False,
                            enable_checkpointing=False,
                            enable_progress_bar=True,
                            enable_model_summary=False)
    
    test_trainer.strategy.num_nodes=1

    suggested_batch_size = trial.params["batch_size"]
    lang_ident_data_module = LanguageIdentificationDataModule(
        test_dataset=test_dataset,
        batch_size=suggested_batch_size,
        num_workers=args.cpu_cores,
        is_gen_llm=is_gen_llm,
        tokenizer=pretrained_embedding_tokenizer,
        random_seed=props.app.random_seed
    )

    try:
        # use this to dequantize and test later on cpu
        # if is_quantized:
        #     quantizer = Bnb4BitHfQuantizer(quantization_config=bnb_config)
        #     dequantized_model = quantizer._dequantize(model)
        #     model = dequantized_model
        #     model = model.float()
        # If quantized, dequantize before testing
        if is_quantized:
            log.info("Dequantizing quantized model for CPU test + save...")
            quantizer = Bnb4BitHfQuantizer(quantization_config=bnb_config)
            model = quantizer._dequantize(model)
            model = model.float()

        # Run test on fp32 model
        test_result = test_trainer.test(model.to(torch.float32), datamodule=lang_ident_data_module)
        test_accuracy = test_result[0].get("test_accuracy", 0.0)
        trial.set_user_attr("test_accuracy", test_accuracy)

        # Save directory
        save_dir = "saved_models"
        os.makedirs(save_dir, exist_ok=True)
        lightweight_ckpt_path = os.path.join(save_dir, f"trial_{trial.number}.pt")

        # Model is already fp32 and on CPU after dequantization
        model_cpu = model.to(dtype=torch.float32, device="cpu")
        torch.save(model_cpu.state_dict(), lightweight_ckpt_path)
        log.info(f"Saved lightweight checkpoint at {lightweight_ckpt_path}")


    except Exception as e:
        log.error(f"Exception is {e}")
        raise

def get_trainable_parameters(model):
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return trainable_params  # Ensure this returns an integer

def get_target_modules(model, attribute_filter=None, name_filter=None, custom_filter=None):
    """
    Identify target modules in a PyTorch or Lightning model based on configurable criteria.

    Args:
        model (nn.Module or LightningModule): The model to analyze.
        attribute_filter (callable, optional): Function to filter modules by attributes 
            (e.g., lambda module: hasattr(module, "weight") and module.weight.numel() > 64).
        name_filter (callable, optional): Function to filter modules by name 
            (e.g., lambda name: "fc" in name).
        custom_filter (callable, optional): Function to filter modules by any custom logic 
            (e.g., lambda name, module: name.startswith("layer") and hasattr(module, "bias")).

    Returns:
        dict: Dictionary where keys are module names and values are the corresponding module objects.
    """
    target_modules = {}
    for name, module in model.named_modules():
        # Exclude LayerNorm and other unsupported layers
        # if isinstance(module, torch.nn.LayerNorm):
        #     continue
        # Exclude any module whose class name contains 'Norm'
        if "Norm" in module.__class__.__name__:
            continue

         # Skip frozen layers (requires_grad=False)
        if not any(param.requires_grad for param in module.parameters()):
            continue  # Skip this module if all its parameters are frozen

        if (
            (attribute_filter is None or attribute_filter(module)) and
            (name_filter is None or name_filter(name)) and
            (custom_filter is None or custom_filter(name, module))
        ):
            target_modules[name] = module  # Store the module in the dictionary with its name as key
    return target_modules

def clear_gpu_and_cpu_resources():
    """Safely clears GPU and CPU memory without disrupting distributed processes."""
    
    # Run garbage collection to free CPU memory.
    gc.collect()

    if torch.cuda.is_available():
        # Clear CUDA memory cache.
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
        
        # Ensure all pending CUDA operations are finished.
        torch.cuda.synchronize()

        # Print memory stats before reset (optional).
        current_reserved = torch.cuda.memory_reserved()
        current_allocated = torch.cuda.memory_allocated()
        print(f"Before reset: Reserved = {current_reserved}, Allocated = {current_allocated}")

        # Reset memory tracking (useful for debugging).
        torch.cuda.reset_peak_memory_stats()

    # Print current process memory usage.
    process = psutil.Process(os.getpid())
    mem_info = process.memory_info()
    print(f"Cleared GPU and CPU memory. Current process memory usage: {mem_info.rss / 1024**2:.2f} MB")

    # Ensure all distributed processes are synchronized before proceeding.
    if torch.distributed.is_initialized():
        torch.distributed.barrier()


def calculate_model_size_in_gb(model):
    """
    Calculate model size in GB by including all parameters across all layers and submodules,
    ensuring no duplication.

    Args:
        model (torch.nn.Module): PyTorch model.

    Returns:
        float: Model size in GB.
    """
    total_size = 0  # Size in bytes
    counted_params = set()  # Set to track counted parameters by their unique IDs

    # Recursive function to sum the size of parameters in all submodules
    def get_parameters_size(module):
        nonlocal total_size
        for param in module.parameters():
            param_id = id(param)  # Unique identifier for the parameter
            if param_id not in counted_params:  # Ensure each parameter is counted only once
                dtype_size = param.element_size()  # Size of one element in bytes
                total_size += param.numel() * dtype_size  # Total memory in bytes
                counted_params.add(param_id)  # Mark parameter as counted

    # Loop through all submodules (including nested ones)
    model.apply(lambda module: get_parameters_size(module))

    size_in_GB = float(total_size) / (1024 ** 3)  # Convert to GB
    return size_in_GB

def get_model_summary(model: pl.LightningModule, depth: int = 1):
    table = PrettyTable()
    table.field_names = ["Layer Name", "Type", "Params", "Trainable", "Non-Trainable"]

    total_params = 0
    trainable_params = 0
    non_trainable_params = 0

    visited_params = set()  # Track parameters to prevent duplicate counting

    def count_params(module):
        """Helper function to count trainable/non-trainable parameters uniquely."""
        params = list(module.parameters())
        unique_params = [p for p in params if id(p) not in visited_params]
        
        visited_params.update(id(p) for p in unique_params)  # Mark parameters as counted
        
        total = sum(p.numel() for p in unique_params)
        trainable = sum(p.numel() for p in unique_params if p.requires_grad)
        non_trainable = total - trainable
        
        return total, trainable, non_trainable

    for name, module in model.named_modules():
        if name == "" or name.count('.') >= depth:  # Skip root module and limit depth
            continue

        params, trainable, non_trainable = count_params(module)

        if params > 0:  # Only add layers with parameters
            table.add_row([name, module.__class__.__name__, f"{params:,}", f"{trainable:,}", f"{non_trainable:,}"])

        total_params += params
        trainable_params += trainable
        non_trainable_params += non_trainable

    model_size_gb = calculate_model_size_in_gb(model)

    summary = "\n" + table.get_string()
    summary += f"\nTotal params: {total_params:,}\n"
    summary += f"Trainable params: {trainable_params:,}\n"
    summary += f"Non-Trainable params: {non_trainable_params:,}\n"
    summary += f"Model size: {model_size_gb:.2f} GB\n"

    return summary

def get_devices_for_trainer(DEVICE):
    if DEVICE == "cpu":
        return 1

    if DEVICE == "gpu":
        visible_gpus = os.environ.get("CUDA_VISIBLE_DEVICES")
        is_distributed = torch.distributed.is_available() and torch.distributed.is_initialized()

        if is_distributed:
            return -1  # Let Lightning handle all

        # Inside non-distributed
        if visible_gpus:
            visible_list = [int(x.strip()) for x in visible_gpus.split(",")]
            local_rank_env = os.environ.get('LOCAL_RANK') or os.environ.get('RANK')

            if local_rank_env is not None:
                local_rank = int(local_rank_env)
                if local_rank >= len(visible_list):
                    raise ValueError(f"LOCAL_RANK {local_rank} out of bounds for visible GPUs {visible_list}")
                return [local_rank]  # single target

            # No rank set, fallback to all visible
            return list(range(len(visible_list)))
        else:
            # No CUDA_VISIBLE_DEVICES → use all available
            return list(range(torch.cuda.device_count()))

    return 1  # fallback for safety
def get_supported_compute_dtype():
    if torch.cuda.is_available():
        major, minor = torch.cuda.get_device_capability()
        # Ampere (8.0+) supports bfloat16
        if major >= 8:
            return torch.bfloat16
    return torch.float16

def objective(trial: optuna.trial.Trial, args: Any, continue_optimization: bool, study: optuna.Study) -> Any:
    """
    This is the objective function used in an Optuna Study's Trial 
    where the specified combination of parameters are experimented on and 
    the monitored parameter value is returned

    Args:
        trial (optuna.trial.Trial): An instance of an optuna Trial
        args (Any): arguments passed to the main function

    Returns:
        Any: Value of the metric monitored during the Trial
    """
    try:
        is_quantized = False
        is_gen_llm = False
        clear_gpu_and_cpu_resources()
        pu = PropertyUtils()
        lu = LogUtils()
        fdu = FileDirUtils()
        dtu = DateTimeUtils()
        props = pu.get_yaml_config_properties(args.config_file_path)
        log = lu.get_time_rotated_log(props)
        random_seed = props.app.random_seed
        np.random.seed(random_seed)
        random.seed(random_seed)
        pl.seed_everything(random_seed, workers=True)
        torch.manual_seed(random_seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(random_seed)
            # torch.backends.cudnn.deterministic = True
            # torch.backends.cudnn.benchmark = False 
        if continue_optimization:
            trial = optuna.integration.TorchDistributedTrial(trial) if torch.distributed.is_initialized() else trial
            local_rank = 0
            if torch.cuda.is_available():
                local_rank = int(adjust_local_gpu_rank())

            pretrained_embedding_tokenizer = None
            pretrained_embedding = None
            device_dict = get_device_info()
            num_nodes = args.num_nodes
            log.info(f"App initialized!! on {device_dict}")
            
            # Load pretrained embedding
            # pretrained_embedding_names = ['FacebookAI/xlm-roberta-base', 
            #                               'ai4bharat/IndicBERTv2-MLM-only', 
            #                               'google-bert/bert-base-multilingual-cased', 
            #                               'google/muril-base-cased',]
            # pretrained_embedding_names = ['ai4bharat/IndicBERTv2-MLM-only']
            # pretrained_embedding_names = ['google/mt5-large',
            #                               'facebook/mbart-large-50']
            # pretrained_embedding_names = ['meta-llama/Llama-3.2-3B-Instruct']
            # pretrained_embedding_names = ['google/mt5-large']
            pretrained_embedding_names = props.run_config.pretrained_embedding_names
            
            # pretrained embedding name from the choices in trials
            pretrained_embedding_name = trial.suggest_categorical("pretrained_embedding_name", pretrained_embedding_names)
            # pretrained_embedding_name = props.model.pretrained_embedding_name
            pretrained_embedding_model_dir_path = os.path.join(
                props.app.pretrained_embeddings_dir,
                pretrained_embedding_name + ("_quantized" if use_cuda else "_fp32")
            )
            if use_cuda:
                bnb_config = BitsAndBytesConfig(
                    load_in_4bit=True,
                    bnb_4bit_compute_dtype=get_supported_compute_dtype(),
                    bnb_4bit_use_double_quant=True,
                    bnb_4bit_quant_type="nf4",
                    )
                is_quantized = True
                
                # bnb_config = BitsAndBytesConfig(
                #     load_in_8bit=True,  # Use 8-bit quantization (better for V100)
                #     llm_int8_threshold=6.0,  # Default threshold for mixed precision
                #     llm_int8_enable_fp32_cpu_offload=True,  # Offload to CPU to reduce memory usage
                #     llm_int8_has_fp16_weight=True,  # Ensure weights are in FP16 for efficiency
                #     )
            fdu.create_dir(pretrained_embedding_model_dir_path, force_write=props.run_config.pretrained_embedding_overwrite_old)
            if pretrained_embedding_name:
                if fdu.is_dir_empty(pretrained_embedding_model_dir_path):
                    # Access the revision/version (if available)
                    hfapi = HfApi()
                    # Fetch model information
                    model_info = hfapi.model_info(pretrained_embedding_name)

                    # Extract the `sha` (commit hash) or `revision`
                    revision = model_info.sha  # This gives the exact commit hash used
                    log.info(f"Embedding Model: {pretrained_embedding_name} Revision: {revision}")
                    if "llama" in pretrained_embedding_name.lower():
                        hf_token = os.getenv("HF_LLAMA3B_TOKEN")
                        if hf_token:
                            login(token=hf_token)
                        else:
                            raise RuntimeError("No HF token set.In ENV VARIABLE HF_LLAMA3B_TOKEN")
            
                    pretrained_embedding_config = AutoConfig.from_pretrained(pretrained_embedding_name,
                                                                             revision=revision)
                    log.info(f"config of pretrained embedding used {pretrained_embedding_config}")
                    log.info(f"Downloading {pretrained_embedding_name} embeddings from transformers package")
                    if "ModernBERT" in pretrained_embedding_name:
                        pretrained_embedding = ModernBertModel.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision)
                        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision)
                        max_layers = len(pretrained_embedding.layers)
                    elif "mt5" in pretrained_embedding_name:
                        if use_cuda:
                            pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_name,
                                revision=revision,
                                quantization_config=bnb_config)
                        else:
                            pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_name,
                                revision=revision)
                        # pretrained_embedding = MT5EncoderModel.from_pretrained(
                        #     pretrained_model_name_or_path=pretrained_embedding_name,
                        #     revision=revision)
                        config = pretrained_embedding.config

                        # If the tokenizer class is incorrect, manually adjust it
                        if config.tokenizer_class != "MT5Tokenizer":
                            config.tokenizer_class = "MT5Tokenizer"
                        pretrained_embedding_tokenizer = MT5Tokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision, use_fast=False)
                        max_layers = len(pretrained_embedding.encoder.block)
                    elif "mbart" in pretrained_embedding_name:
                        pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision)
                        pretrained_embedding_tokenizer = MBart50Tokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision)
                        max_layers = len(pretrained_embedding.model.encoder.layers)
                    elif "llama" in pretrained_embedding_name:
                        if use_cuda:
                            pretrained_embedding = AutoModelForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_name,
                                revision=revision,
                                quantization_config=bnb_config,
                            )
                        else:
                            pretrained_embedding = AutoModelForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_name,
                                revision=revision,
                            )
                        max_layers = len(pretrained_embedding.model.layers)

                        # pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                        #     pretrained_model_name_or_path=pretrained_embedding_name,
                        #     revision=revision,
                        #     use_fast=False  # Often safer for LLaMA-based models
                        # )
                        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision,
                            use_fast=False
                        )
                        is_gen_llm = True
                    else:
                        pretrained_embedding = AutoModel.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision)
                        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_name,
                            revision=revision)
                        max_layers = len(pretrained_embedding.encoder.layer)
                    # Save the revision (commit SHA) in a text file in the version directory
                    with open(os.path.join(pretrained_embedding_model_dir_path, 'revision.txt'), 'w') as f:
                        f.write(revision)
                    
                    pretrained_embedding.save_pretrained(pretrained_embedding_model_dir_path)
                    pretrained_embedding_tokenizer.save_pretrained(pretrained_embedding_model_dir_path)
                else:
                    pretrained_embedding_config = AutoConfig.from_pretrained(pretrained_embedding_model_dir_path)
                    log.info(f"Config of pretrained embedding used {pretrained_embedding_config}")
                    log.info(f"Loading {pretrained_embedding_name} embeddings from {pretrained_embedding_model_dir_path}")
                    if "ModernBERT" in pretrained_embedding_name:
                        pretrained_embedding = ModernBertModel.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path,)
                        max_layers = len(pretrained_embedding.layers)
                        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path)
                    elif "mt5" in pretrained_embedding_name:
                        if use_cuda:
                            pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_model_dir_path,
                                quantization_config=bnb_config)
                        else:
                            pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_model_dir_path)
                        max_layers = len(pretrained_embedding.encoder.block)
                        pretrained_embedding_tokenizer = MT5Tokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path)
                    elif "mbart" in pretrained_embedding_name:
                        pretrained_embedding = AutoModelForSeq2SeqLM.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path,)
                        max_layers = len(pretrained_embedding.model.encoder.layers)
                        pretrained_embedding_tokenizer = MBart50Tokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path)
                    elif "llama" in pretrained_embedding_name:
                        if use_cuda:
                            pretrained_embedding = AutoModelForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_model_dir_path,
                                quantization_config=bnb_config,
                            )
                        else:
                            pretrained_embedding = AutoModelForCausalLM.from_pretrained(
                                pretrained_model_name_or_path=pretrained_embedding_model_dir_path,
                            )
                        max_layers = len(pretrained_embedding.model.layers)
                        # pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                        #     pretrained_model_name_or_path=pretrained_embedding_model_dir_path,
                        #     use_fast=False  # Often safer for LLaMA-based models
                        # )
                        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path,
                            use_fast=False
                        )
                        is_gen_llm =True
                    else:
                        pretrained_embedding = AutoModel.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path,)
                        max_layers = len(pretrained_embedding.encoder.layer)
                        pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                            pretrained_model_name_or_path=pretrained_embedding_model_dir_path)

            # suggested_seq_len = trial.suggest_int("max_output_length", 100, 500, step=50)
            suggested_seq_len = trial.suggest_categorical("max_seq_len", props.run_config.max_seq_len) # long seq is slow
            # Trial suggested batch_size
            # suggested_batch_size = trial.suggest_categorical("batch_size", [8, 16, 32, 64])
            # suggested_batch_size = trial.suggest_categorical("batch_size", [1, 2, 4])
            suggested_batch_size = trial.suggest_categorical("batch_size", props.run_config.batch_size)
            # suggested_batch_size = 4
            # Trial suggested dataset fraction
            # suggested_sample_dataset_share = trial.suggest_categorical('sample_dataset_share', [0.01, 0.05, 0.1]) # 1% to 10%
            suggested_sample_dataset_share = trial.suggest_categorical('sample_dataset_share', props.run_config.data_sample_share) # 1% to 10%

            # from transformers import BertForSequenceClassification
            config = {
                "device_dict": device_dict,
                "pretrained_embedding_model": pretrained_embedding,
                # "optimizer": trial.suggest_categorical("optimizer", ['adam','adamax','adamw']),
                "optimizer": trial.suggest_categorical("optimizer", props.run_config.optimizer),
                # "num_backbone_model_units_unfrozen": 20,
                # "num_backbone_model_units_unfrozen": trial.suggest_int("num_backbone_model_units_unfrozen", 0, max_layers, step=1),
                # "num_backbone_model_units_unfrozen": trial.suggest_int("num_backbone_model_units_unfrozen", 0, 4, step=1),
                "num_backbone_model_units_unfrozen": trial.suggest_categorical("num_backbone_model_units_unfrozen", props.run_config.num_backbone_model_units_unfrozen),
                # "num_backbone_model_units_unfrozen": trial.suggest_int("num_backbone_model_units_unfrozen", 0, 0),
                # "loss_type": trial.suggest_categorical("loss_type", ["cross_entropy",
                #                                                     "class_weighted_cross_entropy_loss",
                #                                                     "focal_loss",
                #                                                     "class_weighted_focal_loss",
                #                                                     "class_weighted_focal_loss_with_adaptive_focus_type1",
                #                                                     "class_weighted_focal_loss_with_adaptive_focus_type2",
                #                                                     "class_weighted_focal_loss_with_adaptive_focus_type3"]),
                "loss_type": trial.suggest_categorical("loss_type", props.run_config.loss_type),
                # "lr": trial.suggest_float("lr", 1e-5, 1e-1, log=True),
                # "lr" : trial.suggest_categorical("lr", [1e-5, 1e-4, 1e-3, 1e-2, 1e-1]),
                # "lr" : trial.suggest_categorical("lr", [1e-3, 1e-2, 1e-1]),
                "lr" : trial.suggest_categorical("lr", props.run_config.learning_rate),
                "is_train": True,
                "tokenizer": pretrained_embedding_tokenizer,
                "random_seed": props.app.random_seed
            }

            if is_gen_llm == False:
                config.update(
                    {
                        # "num_fc_layers": trial.suggest_int("num_fc_layers",1, 5, step=1),
                        "num_fc_layers": trial.suggest_categorical("num_fc_layers",props.run_config.num_fc_layers_in_classifier_head),
                        # "activation_function_for_layer": trial.suggest_categorical("activation_function_for_layer", ['relu',
                        #                                                                                             'parametric_relu',
                        #                                                                                             'leaky_relu']),
                        "activation_function_for_layer": trial.suggest_categorical("activation_function_for_layer", ['parametric_relu']),
                        "add_dropout_after_embedding": trial.suggest_categorical("add_dropout_after_embedding", [True,False]),
                    }
                )



            config.update({"pretrained_model_embedding_name": pretrained_embedding_name})

            if config["num_backbone_model_units_unfrozen"] == 0:
                lora_choice = False
            else:
                # lora_choice = trial.suggest_categorical("lora_choice", [True, False])
                lora_choice = trial.suggest_categorical("lora_choice", [True])
            
            # Test Dataset
            train_data_dir = os.path.join(props.app.data_dir, props.dataset.train.data_dir)
            val_data_dir = os.path.join(props.app.data_dir, props.dataset.val.data_dir)
            files_have_header = props.dataset.files_have_header
            classes_config_path = f"config/{props.app.model_config_name}/trial_{trial.number}/classes_config.json"
            fdu.create_dir(f"config/{props.app.model_config_name}/trial_{trial.number}")
            # # Trial suggested dataset fraction
            # suggested_sample_dataset_share = trial.suggest_categorical('sample_dataset_share', [0.01, 0.05, 0.1, 0.2])
            prompt_template = None
            is_gen_llm = False
            if "llama" in pretrained_embedding_name:
                prompt_template = (
                    "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                    "You are a helpful assistant.<|eot_id|>\n"
                    "<|start_header_id|>user<|end_header_id|>\n"
                    "Identify the language of each word in the following sentence.\n"
                    "Respond with only space separated language labels.\n"
                    "Do not include any explanation or extra text.\n"
                    "<|eot_id|>"
                )
                # prompt_template = """### Instruction:
                # Identify the language of each word in the following sentence.
                # Respond with only space separated language labels.
                # Do not include any explanation or extra text.
                # """
                is_gen_llm = True
            train_dataset = LanguageIdentificationDataset(data_dir=train_data_dir, files_have_header=files_have_header,
                                                        log=log, pretrained_embedding_tokenizer=pretrained_embedding_tokenizer,
                                                        max_seq_length=suggested_seq_len,
                                                        classes_config_path=classes_config_path,
                                                        is_train=True, random_seed=props.app.random_seed,
                                                        sample_dataset_share=suggested_sample_dataset_share,
                                                        num_workers=args.cpu_cores,
                                                        is_gen_llm=is_gen_llm, prompt_template=prompt_template,)
                                                        # use_disk_store=True)
                                                        # sample_dataset_share=props.dataset.train_dataset_sample_share)
            val_dataset = LanguageIdentificationDataset(data_dir=val_data_dir, files_have_header=files_have_header,
                                                        log=log, pretrained_embedding_tokenizer=pretrained_embedding_tokenizer,
                                                        max_seq_length=suggested_seq_len,
                                                        classes_config_path=classes_config_path,
                                                        is_train=False, random_seed=props.app.random_seed,
                                                        sample_dataset_share=suggested_sample_dataset_share,
                                                        num_workers=args.cpu_cores,
                                                        is_gen_llm=is_gen_llm, prompt_template=prompt_template,)
                                                        # use_disk_store=True)
                                                        # sample_dataset_share=props.dataset.val_dataset_sample_share)
            log.info(f"Number of training data samples {train_dataset.__len__()}  with {train_dataset.label_sample_counter} labels")
            log.info(f"Number of validation data samples {val_dataset.__len__()}  with {val_dataset.label_sample_counter} labels")
            # log.info(f"Number of training data samples {train_dataset.estimated_len}")
            # log.info(f"Number of validation data samples {val_dataset.estimated_len}")

            num_classes = train_dataset.get_num_classes()
            class_names = [train_dataset._get_lang_code_from_class_id(key) for key in train_dataset.classes.keys()]
            class_weights = train_dataset.class_weights
            class_weights_dict = {}

            for idx, (class_name, weight) in enumerate(zip(class_names, class_weights)):
                if is_gen_llm:
                    token_ids = pretrained_embedding_tokenizer(class_name, add_special_tokens=False)["input_ids"]
                else:
                    token_ids = [idx]

                if token_ids:  # skip if tokenizer returns empty
                    class_weights_dict[class_name] = [token_ids, weight]

            print(f"Class Weights Generated {class_weights_dict}")
            if "llama" in pretrained_embedding_name:
                vocab_size = pretrained_embedding.config.vocab_size
                # class_token_ids = pretrained_embedding_tokenizer.convert_tokens_to_ids(classes)
                # print(f"Class token ids {class_token_ids} and vocab size {vocab_size}")
                # new_class_weights = torch.ones(vocab_size)
                # for token_id, weight in zip(class_token_ids, class_weights):
                #     new_class_weights[token_id] = weight
                # class_weights = new_class_weights
                # num_classes = pretrained_embedding.config.vocab_size
                
            log.info(f"{num_classes} classes in training data with classes {class_names} and weights {class_weights}")

            lang_ident_data_module = LanguageIdentificationDataModule(train_dataset=train_dataset,
                                                                    val_dataset=val_dataset,
                                                                    train_data_shuffle=True,
                                                                    tokenizer=pretrained_embedding_tokenizer,
                                                                    batch_size=suggested_batch_size,
                                                                    num_workers=args.cpu_cores,
                                                                    is_gen_llm=is_gen_llm,
                                                                    random_seed=props.app.random_seed) # setting train data shuffle to maintain consistency for optuna
            # invalid_entries = []
            # shapes = set()
            # labels_list = []

            # for idx, sample in enumerate(val_dataset):
            #     embedding = sample["input_ids"]
            #     label = sample["labels"]

            #     if embedding is None or not isinstance(embedding, torch.Tensor) or embedding.dim() != 1:
            #         invalid_entries.append(idx)
            #     else:
            #         shapes.add(embedding.shape)

            #     labels_list.append(label)

            # print(f"Total invalid entries: {len(invalid_entries)}")
            # print(f"Indices of invalid entries: {invalid_entries}")
            # print(f"Unique embedding shapes: {shapes}")
            # print(f"Unique labels: {set(labels_list)}")


            # TODO Test llama
            # if "llama" in pretrained_embedding_name:
            #     input_ids, attn_mask, target_ids = train_dataset.__getitem__(idx=0) 
            #     print(f"input_ids {input_ids}")
            #     print(f"attn_mask {attn_mask}")
            #     print(f"target_ids {target_ids}")
            #     print(f"exiting now")
            #     decoded_text = pretrained_embedding_tokenizer.decode(input_ids)
            #     print(f"Decoded text is {decoded_text}")
            #     sys.exit(1)


            # Define the hyperparameters to search over
            config.update({
                "class_names": class_names,
                "class_weights": class_weights_dict,
                })

            model_config_name = props.app.model_config_name
            # Create an instance of the CustomMetricsCallback
            DEVICE = 'gpu' if torch.cuda.is_available() else 'cpu'
            metrics_summary_dict = {}
            # model_config_name = props.app.model_config_name
            metrics_summary_dict['model_name'] = model_config_name
            # metrics_summary_dict['config'] = yaml_config_data
            metrics_summary_dict['max_epochs'] = props.model.max_epochs
            model_summary_callback = callbacks.ModelSummary(max_depth=2)
            METRICS_DIR = "metrics/{}".format(model_config_name)
            MODEL_EPOCH_METRICS_FILE = "epoch_training_metrics.csv"
            MODEL_METRICS_SUMMARY_FILE = "model_training_summary_metrics.csv"
            logging_callback = LoggingCallback(log,
                                        model_summary_callback=model_summary_callback,
                                        metrics_summary_dict=metrics_summary_dict,
                                        metrics_dir=METRICS_DIR,
                                        model_epoch_metrics_file=MODEL_EPOCH_METRICS_FILE,
                                        model_metrics_summary_file=MODEL_METRICS_SUMMARY_FILE,
                                        trial=trial)
            # early_stopping_callback = TimeLimitedEarlyStopping(
            #                             max_duration_hours=6, #0.25 means 15mins
            #                             trial=trial,
            #                             monitor="val_loss",
            #                             mode="min",
            #                             min_delta=0.001,
            #                             patience=5)
            early_stopping_callback = callbacks.EarlyStopping(
                                        monitor="val_accuracy",   # or your desired metric
                                        patience=3,           # stop after 3 epochs of no improvement
                                        mode="max",           # use "max" if monitoring accuracy or similar
                                        verbose=True)
            lr_monitor_callback = callbacks.LearningRateMonitor(logging_interval='step')
            CKPTS_DIR = os.path.join(props.app.checkpoints_dir, model_config_name, f"trial_{trial.number}")
            model_ckpt_callback = callbacks.ModelCheckpoint(dirpath=CKPTS_DIR,
                                                            filename="last",
                                                            save_top_k=1,
                                                            save_last=True,
                                                            monitor="val_loss",
                                                            mode="min")
            optuna_trial_number_callback = OptunaLoggingCallback(trial)
            gpu_usage_callback = GPUUsagePruneCallback(trial, threshold=0.95)
            config.update({
                    "trial_number": trial.number
                })
            if "llama" in pretrained_embedding_name:
                config.update({"prompt_length": suggested_seq_len})
                model = GenLLMLanguageIdentificationClassifier(**config)
            # elif "mt5"
            else:
                model = LanguageIdentificationClassifier(**config)
            # Apply bitsandbytes quantization safely
            # for name, module in model.named_modules():
            #     if isinstance(module, torch.nn.Linear) and "embedding" not in name and "classifier" not in name:
            #         module.weight = bnb.nn.Params4bit(module.weight, requires_grad=False)
            ignored_params = list()
            # ignored_modules = list()
            if lora_choice:
                if is_quantized:
                    attribute_filter = lambda module: (
                        hasattr(module, "weight") and
                        isinstance(module.weight, torch.Tensor) and
                        module.weight.numel() > 64 and
                        not isinstance(module, (bnb.nn.Linear4bit, bnb.nn.Linear8bitLt, bnb.nn.LinearNF4))  # Exclude quantized layers
                    )
                else:
                    attribute_filter = lambda module: (
                        hasattr(module, "weight") and
                        isinstance(module.weight, torch.Tensor) and
                        module.weight.numel() > 64
                    )
                # name_filter = lambda name: "embedding" in name
                # custom_filter = lambda name, module: name.startswith("model") and hasattr(module, "bias")

                # Get target modules
                if "mt5" in pretrained_embedding_name:
                    target_embedding_module = model.embedding.encoder
                elif "mbart" in pretrained_embedding_name:
                    target_embedding_module = model.embedding.model.encoder
                else:
                    target_embedding_module = model.embedding
                
                target_modules = get_target_modules(
                    # model.embedding,
                    target_embedding_module,
                    attribute_filter=attribute_filter,
                    name_filter=None,
                    custom_filter=None
                )
                try:
                    lora_task_type = TaskType.CAUSAL_LM if is_gen_llm else TaskType.TOKEN_CLS
                    lora_config = get_lora_config(trial, target_modules, lora_task_type)
                except Exception as e:
                    print(f"Get LORA Exception {e}")
                    raise

            log.info(f"Trial Ready Config for Trial {trial.number} with params {trial.params}")
            
            if SLURMEnvironment.detect() is False:
                if torch.cuda.is_available():
                    log.info(f"Setting model to cuda:{local_rank}")
                    model = model.to(device=f"cuda:{local_rank}")
                else:
                    log.info(f"Setting model to cpu with rank {local_rank}")
                    model = model.to(device=f"cpu")
            
            if lora_choice:
                try:
                    log.info(f"Target Module trainable parameters {target_embedding_module} before applying LORA is {get_trainable_parameters(target_embedding_module)} and size is {calculate_model_size_in_gb(target_embedding_module)} GB")
                    target_embedding_module = get_peft_model(target_embedding_module, lora_config)
                    # target_embedding_module = prepare_model_for_kbit_training(target_embedding_module)
                    # target_embedding_module = torch.quantization.quantize_dynamic(model, dtype=torch.qint8)
                    for name, param in model.named_parameters():
                        if not param.is_leaf:
                            param = param.detach()
                        if "encoder" in name and "lora" not in name:  # Freeze non-LoRA transformer layers
                            param.requires_grad = False
                        elif "embedding" in name:  # Handle embedding layers
                            if "lora" in name:  # Keep LoRA embedding layers trainable
                                param.requires_grad = True
                                # print(f"Unfreezing lora layer {name}")
                            else:  # Freeze non-LoRA embedding layers
                                param.requires_grad = False
                                # print(f"Freezing non-lora layer {name}")
                    log.info(f"Target Module trainable parameters after applying LORA is {get_trainable_parameters(target_embedding_module)} and size is {calculate_model_size_in_gb(target_embedding_module)} GB")
                except Exception as e:
                    log.error(f"Exception while converting to PEFT: {e}\n{traceback.format_exc()}")
                    raise # rethrow the exception
            
            for name, p in model.named_parameters():
                # print(f"Param {name} and param {p} device {p.data.get_device()}")
                if not p.requires_grad:
                    ignored_params.append(p)
            # for name, module in model.named_modules():
            #     if isinstance(module, torch.nn.Sequential):
            #         ignored_params.extend(list(module.parameters()))  # Ignore the entire Sequential module

            custom_fsdp = CustomFSDPStrategy(ig_params=ignored_params)
            try:
                from pytorch_lightning.profilers import AdvancedProfiler, PyTorchProfiler
                # profiler = AdvancedProfiler(dirpath="profiling_logs", filename="profile.txt")
                profiler = PyTorchProfiler(
                    dirpath="profiler_logs",
                    filename="trace.json",
                    export_to_chrome=True,
                )
                trainer = Trainer(accelerator=DEVICE,
                                devices=get_devices_for_trainer(DEVICE),
                                num_nodes=num_nodes,
                                # profiler=profiler,
                                # strategy="deepspeed_stage_2",
                                strategy=custom_fsdp if DEVICE == "gpu" else "auto",
                                # strategy=pl.pytorch.strategies.DDPStrategy(find_unused_parameters=True),
                                max_epochs=props.model.max_epochs,
                                # max_epochs=1,
                                deterministic=True,
                                enable_progress_bar=True,
                                enable_model_summary=False,
                                accumulate_grad_batches=8,
                                # limit_train_batches=80,
                                # limit_val_batches=80,
                                # precision="32",
                                # precision='bf16-mixed',
                                precision=props.run_config.training_precision_type,
                                callbacks=[optuna_trial_number_callback, logging_callback, 
                                        gpu_usage_callback, model_ckpt_callback, early_stopping_callback, 
                                        lr_monitor_callback],
                                )
            except Exception as e:
                print(f"[ERROR] Training crashed: {e}")
                traceback.print_exc()
                raise
            finally:
                clear_gpu_and_cpu_resources()
            
            trainer.strategy.num_nodes=num_nodes # fault in torch lightning library if multi gpus strategy loses context hence work around
            trial_details = ""
            trial_details = f"Now Running Trial {trial.number} : " + \
            "Trial Config Params: {"
            for key, value in trial.params.items():
                trial_details += f"{key}: {value} ,"
            log.info(trial_details+"}")
            trial.set_user_attr('trial_start_time', time.time())

            if local_rank == 0:
                model_summary = get_model_summary(model)
                log.info(f"Model Summary before fit is {model_summary}")
                log.info(f"Model structure is {model}")
            
            # compiled_model = torch.compile(model, mode="default")
            trainer.fit(model, datamodule=lang_ident_data_module)
            # if gpu_usage_callback.should_prune:
            #     print("[Optuna] GPU usage exceeded threshold, pruning trial.")
            #     raise torch.cuda.OutOfMemoryError()
            if torch.distributed.is_initialized():
                torch.distributed.barrier()
            ckpth_path = trainer.checkpoint_callback.best_model_path
            # Load the checkpoint state dict
            trial.set_user_attr(key="best_checkpoint_path", value=ckpth_path)
            popped_key_tokenizer = config.pop("tokenizer", None)
            popped_key_model = config.pop("pretrained_embedding_model", None)
            popped_key_device = config.pop("device_dict", None)
            trial.set_user_attr(key="config", value=config)
            if torch.distributed.is_initialized():
                torch.distributed.barrier()
            # popping pretrained and device dict since callback cant process non serializable objects
            if is_gen_llm:
                testset_from_best_checkpoint_callback(args, study, trial, prompt_template)
            else:
                testset_from_best_checkpoint_callback(args, study, trial)
            # raise Exception("Test here")
            return trial.user_attrs.get("test_accuracy", 0.0)
    except optuna.exceptions.TrialPruned as e:
        print(f"[Optuna] Trial pruned due to GPU memory: {e}")
        trial.set_user_attr("test_accuracy", 0.0)
        clear_gpu_and_cpu_resources()
        raise  # re-raise to mark trial pruned in Optuna
    except torch.cuda.OutOfMemoryError as e:
        # Convert error message to lowercase for general matching
        error_message = str(e).lower()

        # Check for Out-Of-Memory (OOM) errors (GPU or CPU)
        if "cuda out of memory" in error_message or "cublas" in error_message or "out of memory" in error_message:
            clear_gpu_and_cpu_resources()
            log.warning(f"OOM error encountered. Freeing memory and skipping this trial. Details :: {e}")
            exception_info = {"type": type(e).__name__, "message": str(e)}
            trial.set_user_attr("exception", exception_info)
            # Ensure all processes are synchronized before pruning
            trial.set_user_attr("test_accuracy", 0.0)  # Fallback value
            raise optuna.exceptions.TrialPruned()
    except Exception as e:
        # If an exception occurs during execution, mark the trial as failed
        # Extract relevant information from the exception
        clear_gpu_and_cpu_resources()
        exception_info = {"type": type(e).__name__, "message": str(e)}
        
        # Serialize the exception information as a JSON string
        exception_json = json.dumps(exception_info)
        
        # Set the serialized exception as a user attribute
        trial.set_user_attr("exception", exception_json)
        raise #Rethrow the exception


def log_trial_results(model_config_name: str, log: Logger, 
                      study: optuna.Study, trial: optuna.trial.Trial,
                      metrics_dir: str, trial_metrics_filename: str) -> None:
    """
    Logs the results of an Optuna trial for a given study.

    Args:
        model_config_name (str): Model name or config identifier.
        log (Logger): Logger instance.
        study (optuna.Study): Optuna Study instance.
        trial (optuna.trial.Trial): Current Trial instance.
        metrics_dir (str): Directory to store metrics.
        trial_metrics_filename (str): Filename for the trial metrics.
    """
    dtu = DateTimeUtils()

    trial_accuracy = trial.value if trial.value is not None else 0
    trial_execution_time = (time.time() - trial.user_attrs.get('trial_start_time', 0)) if trial.user_attrs.get('trial_start_time') else 0
    trial_status = trial.state if trial.state else "UNKNOWN"
    trial_failure_reason = trial.user_attrs.get('exception', "NA")

    trial_params = "{ " + ", ".join(f"{k}: {v}" for k, v in trial.params.items()) + " }"

    trial_number = trial.number
    best_trial_number = "NA"
    best_trial_accuracy = "NA"
    best_trial_params = "NA"

    # Safely determine best trial (only if at least one completed trial with value exists)
    complete_trials = [
        t for t in study.trials
        if t.state == optuna.trial.TrialState.COMPLETE and t.value is not None
    ]
    if complete_trials:
        best_trial = study.best_trial
        best_trial_number = best_trial.number
        best_trial_accuracy = best_trial.value
        best_trial_params = best_trial.params

    log.info(f"Study {study.study_name} Trial {trial_number} Results: "
             f"Monitored Value: {trial_accuracy} "
             f"Params: {trial_params} "
             f"Best Trial {best_trial_number} with accuracy {best_trial_accuracy} "
             f"and params {best_trial_params}")

    optim_dir = f"optim_studies/{model_config_name}"
    os.makedirs(optim_dir, exist_ok=True)
    with open(f"{optim_dir}/sampler.pkl", "wb") as fout:
        pickle.dump(study.sampler, fout)
    with open(f"{optim_dir}/pruner.pkl", "wb") as fout:
        pickle.dump(study.pruner, fout)

    # Save trial metrics
    os.makedirs(metrics_dir, exist_ok=True)
    metrics_file_path = os.path.join(metrics_dir, trial_metrics_filename)
    hr, mins, secs = dtu.get_hms_from_milliseconds(int(trial_execution_time * 1000))
    readable_trial_exec_time = f"{hr} hours, {mins} minutes and {secs} seconds"

    trial_metrics_dict = {
        'study': study.study_name,
        'trial': trial_number,
        'accuracy': trial_accuracy,
        'trial_params': trial_params,
        'trial_status': str(trial_status),
        'trial_execution_time': trial_execution_time,
        'trial_readable_time': readable_trial_exec_time,
        'trial_failure_reason': trial_failure_reason
    }

    with open(metrics_file_path, 'a+', encoding="utf8") as mdl_metrics_file:
        writer = csv.DictWriter(mdl_metrics_file, fieldnames=trial_metrics_dict.keys())
        if os.path.getsize(metrics_file_path) == 0:
            writer.writeheader()
        writer.writerow(trial_metrics_dict)

def is_duplicate(trial, study):
    # Get the current trial parameters
    current_params = trial.params
    
    # Check all completed trials for duplicates
    for past_trial in study.get_trials(states=(optuna.trial.TrialState.COMPLETE,
                                               optuna.trial.TrialState.RUNNING,
                                               optuna.trial.TrialState.FAIL)):
        if past_trial.params == current_params:
            return True
    return False

class NoDuplicateSampler(optuna.samplers.BaseSampler):
    def __init__(self, base_sampler: optuna.samplers.BaseSampler):
        self.base_sampler = base_sampler  # Use TPESampler or any other sampler

    # Override and delegate infer_relative_search_space to the base sampler
    def infer_relative_search_space(self, study, trial):
        return self.base_sampler.infer_relative_search_space(study, trial)
    
    # Override and delegate sample_relative to the base sampler
    def sample_relative(self, study, trial, search_space):
        return self.base_sampler.sample_relative(study, trial, search_space)

    # Override sample_independent to check for duplicates
    def sample_independent(self, study, trial, param_name, param_distribution):
        while True:
            # Sample a set of hyperparameters using the base sampler (TPESampler)
            param = self.base_sampler.sample_independent(study, trial, param_name, param_distribution)
            
            # Temporarily assign the parameter to the trial for comparison
            trial.params[param_name] = param
            
            # Check if this parameter set (with the current params) is a duplicate
            if not is_duplicate(trial, study):
                return param  # If not duplicate, return the parameter
            
            # If it's a duplicate, continue sampling new parameters until a unique one is found

def resume_study_trial_execution(props: Any, log: Logger, study: optuna.Study, storage: str|Any, run_timestamp: float, resume_from_trial_number: Optional[int] = None) -> optuna.Study:
    """
    A custom implementation to handle failures for interrupted Study.
    Ensures the study is resumed with trials that are freshly created (within 5 minutes)
    or already complete. Deletes the old study and creates a new one.

    Args:
        props (Any): Properties object loaded from a YAML config file.
        log (Logger): Python logger object.
        study (optuna.Study): Optuna Study loaded from specified storage.
        storage (str|Any): Name of the storage location.

    Returns:
        optuna.Study: Instance of Optuna Study with all required trials loaded.
    """    

    curr_timestamp = run_timestamp
    study_name = f"{props.app.model_config_name}"
    print(f"Resuming study from trial {resume_from_trial_number}")
    # Load latest version of the study
    study = optuna.load_study(study_name=study_name, storage=storage)
    if study:
        study_id = study._storage.get_study_id_from_name(study.study_name)
        study_direction = study.direction
    optim_dir = f"optim_studies/{props.app.model_config_name}"

    # Restoring the sampler from the saved file using pickle
    if os.path.exists(f"{optim_dir}/sampler.pkl"):
        with open(f"{optim_dir}/sampler.pkl", "rb") as rest_sampler_file:
            restored_sampler: optuna.samplers.TPESampler = pickle.load(rest_sampler_file)
    else:
        restored_sampler = study.sampler

    # Restoring the pruner from the saved file using pickle
    if os.path.exists(f"{optim_dir}/pruner.pkl"):
        with open(f"{optim_dir}/pruner.pkl", "rb") as rest_pruner_file:
            restored_pruner = pickle.load(rest_pruner_file)
    else:
        restored_pruner = study.pruner

    # Time threshold for filtering fresh trials (less than 5 minutes old)
    time_threshold = 300  # 5 minutes = 300 seconds

    # Filter complete trials and freshly running trials (created < 5 mins ago)
    valid_trials = []
    running_counter = 0
    all_study_summaries = optuna.study.get_all_study_summaries(storage=storage)

    # Filter study names that match the pattern
    matching_studies = [summary for summary in all_study_summaries if summary.study_name.startswith(props.app.model_config_name)]
    study_start_time = matching_studies[0].datetime_start.timestamp()
    last_incomplete_trial = None
    # sorted trials from study
    target_trial = None
    for trial in sorted(study.trials, key=lambda t: t.number):
        # resume from a particular trial
        if resume_from_trial_number is not None and trial.number >= resume_from_trial_number:
            target_trial = trial
            break
        trial_start_time = trial.datetime_start.timestamp()
        trial_age = curr_timestamp - trial_start_time
        # trial_age = study_start_time - trial_start_time

        log.info(f"Trial {trial.number} age {trial_age} seconds with trial_start_time {trial.datetime_start}")
        log.info(f"Trial time {trial_start_time} and current {curr_timestamp} and study {study_start_time} and trial {trial.params}")

        if trial.state in {optuna.trial.TrialState.COMPLETE, optuna.trial.TrialState.PRUNED}:
            valid_trials.append(trial)
        # elif trial.state in [optuna.trial.TrialState.RUNNING] and trial.params.get('lr') and trial_start_time >= study_start_time and trial_start_time >= curr_timestamp:  # trial belongs to current study
        elif trial.state in [optuna.trial.TrialState.RUNNING] and trial_start_time >= study_start_time and trial_start_time >= curr_timestamp:  # trial belongs to current study
            # if running_counter < 1:
            #     running_counter += 1
            # if trial.number == 0:
            #     break 
            valid_trials.append(trial) # Not skipping trials that are less than a minute old
            log.info(f"Adding Running Trial {trial.number} to study with params {trial.params} and status {trial.state.name}")
        else:
            log.info(f"Skipping trial {trial.number} with state {trial.state.name} and age {trial_age} seconds.")
            last_incomplete_trial = trial
            break

    log.info(f"Deleting old study {study.study_name} having study id {study_id} with {len(study.trials)} trials .")
    study._storage.delete_study(study_id=study_id)
    # tpe_sampler = optuna.samplers.TPESampler(seed=props.app.random_seed, gamma=0.5, n_startup_trials=20) 
    # restored_sampler = NoDuplicateSampler(tpe_sampler)
    # for trial in valid_trials:
    #     restored_sampler.before_trial(study, trial)
    #     restored_sampler.after_trial(study, trial, trial.state, trial.values)
    # for trial in valid_trials:
    #     restored_sampler = restored_sampler.before_trial()
    # log.info(f"Study direction {study_direction}") #maximize shows number 2
    if not valid_trials:
        tpe_sampler = optuna.samplers.TPESampler(seed=props.app.random_seed, multivariate=True, gamma=gamma_for_tpe_sampler, n_startup_trials=20) 
        restored_sampler = NoDuplicateSampler(tpe_sampler)
        # Reseed sampler reseed to get unique sampler config and replicate old states after termination
        # restored_sampler.reseed_rng()
        restored_pruner = optuna.pruners.HyperbandPruner(min_resource=1, max_resource='auto', reduction_factor=3)
        log.info("No valid trials found. Creating a new empty study.")
        new_study = optuna.create_study(study_name=study_name,
                                        storage=storage,
                                        direction=study_direction,
                                        sampler=restored_sampler,
                                        pruner=restored_pruner,
                                        load_if_exists=True)
        return new_study
        

    # Create a new study
    new_study = optuna.create_study(study_name=study_name,
                                    storage=storage,
                                    direction=study_direction,
                                    sampler=restored_sampler,
                                    pruner=restored_pruner,
                                    load_if_exists=True)

    running_counter = 0
    for trial in valid_trials:
        new_study.add_trial(trial)
        log.info(f"Added trial number {trial.number} with params {trial.params} to the new study.")

    # Enqueue trial
    if target_trial:
        new_study.enqueue_trial(params=target_trial.params, skip_if_exists=True)
    elif last_incomplete_trial:
        new_study.enqueue_trial(params=last_incomplete_trial.params, skip_if_exists=True)
    # Reseed sampler reseed to get unique sampler config and replicate old states after termination
    # new_study.sampler.reseed_rng()

    return new_study


def gamma_for_tpe_sampler(n):
    # top 10% of n completed trials
    return min(25, int(0.1 * n))

def create_new_study(props: Any, 
                     log: Any, 
                     lang_study_storage: optuna.storages.BaseStorage, 
                     hyperparam_sampler: optuna.samplers.BaseSampler, 
                     study_pruner: optuna.pruners.BasePruner):
    study_name = f"{props.app.model_config_name}"
    study = optuna.create_study(direction="maximize",
                                storage= lang_study_storage,
                                sampler = hyperparam_sampler,
                                study_name=study_name,
                                load_if_exists = True,
                                pruner= study_pruner,) # prune unpromising trials
    log.info(f"Created new study {study.study_name}")
    return study


def run_app(args) -> Any:
    """
    Launch method for the lang ident classifier app
    :param args: takes command line arguments
    :return: Any
    """
    global continue_optimization
    global study
    pu = PropertyUtils()
    props = pu.get_yaml_config_properties(args.config_file_path)
    run_timestamp = args.run_timestamp
    lu = LogUtils()
    log = lu.get_time_rotated_log(props)
    fdu = FileDirUtils()
    random_seed = props.app.random_seed
    np.random.seed(random_seed)
    random.seed(random_seed)
    pl.seed_everything(random_seed, workers=True)
    torch.manual_seed(random_seed)
    rank = 0 # Check to handle rank not initialized error
    if torch.cuda.is_available():
        global_rank = int(os.environ.get('RANK', '0'))
        world_size = int(os.environ.get('WORLD_SIZE', '1'))
        torch.cuda.manual_seed_all(random_seed)
        # torch.backends.cudnn.deterministic = True
        # torch.backends.cudnn.benchmark = False 
        if not torch.distributed.is_initialized():
            torch.distributed.init_process_group(backend=args.backend, 
                                                 rank=global_rank, 
                                                 world_size=world_size,
                                                 timeout=timedelta(seconds=600))
    if torch.distributed.is_initialized():
        rank = torch.distributed.get_rank()

    model_config_name = props.app.model_config_name
    METRICS_DIR = "metrics/{}".format(model_config_name)
    MODEL_TRIAL_METRICS_FILE = "trial_metrics.csv"
    
    optim_dir = f"optim_studies/{props.app.model_config_name}"
    fdu.create_dir(f"optim_studies/{props.app.model_config_name}")
    db_name = f"{optim_dir}/study.db"
    lock_file = f"{optim_dir}/study.lock"

    lock = FileLock(lock_file)

    with lock:
        # Create the RDBStorage with the SQLite URL
        lang_study_storage = optuna.storages.RDBStorage(
            url=f"sqlite:///{db_name}",  # Use your database path or URL
            # engine_kwargs={
            #     "connect_args": {
            #         "timeout": 300  # Set a timeout for SQLite connection to prevent lock issues
            #     }
            # }
        )

    # lang_study_storage = f"sqlite:///{db_name}"
    # hyperparam_sampler = optuna.samplers.TPESampler(seed=props.app.random_seed,
    #                                                 multivariate=True,
    #                                                 gamma=gamma_for_tpe_sampler) 
    tpe_sampler = optuna.samplers.TPESampler(seed=props.app.random_seed, multivariate=True, gamma=gamma_for_tpe_sampler, n_startup_trials=20) 
    hyperparam_sampler = NoDuplicateSampler(tpe_sampler)
    study_pruner = optuna.pruners.HyperbandPruner(min_resource=1, max_resource='auto', reduction_factor=3)
    
    # multivariate helps trial exploration with joint distribution like lr with batch size and so on
    # more gamma more exploration, but using lambda helps with dynamic gamma with each trial it increments
    n_trials = props.app.num_trials
    def log_study_results_callback(study, trial):
        log_trial_results(model_config_name, log, study, trial, METRICS_DIR, MODEL_TRIAL_METRICS_FILE)
    def clear_checkpoints_callback(study, trial):
        clear_checkpoints(log, model_config_name, study, trial)
    def study_early_stopping_callback(study, trial):
        study_early_stopping(study=study, trial=trial, log=log)
    def continue_optimization_callback(study, trial):
        global continue_optimization
        if study and len(study.trials) >= n_trials:
            continue_optimization = False
            log.info(f"Study stopped since max number of trials {len(study.trials)} reached.")
            study.stop()
            if torch.distributed.is_initialized():
                log.info("Stopping distributed job")
                torch.distributed.barrier() # synchronize all processes 
                torch.distributed.destroy_process_group() # destroy process group
                log.info("Stopped distributed job")

    if torch.distributed.is_initialized():
        torch.distributed.barrier() # synchronize processes for each device
    
    if rank == 0:
        if os.path.exists(db_name):
            all_study_summaries = optuna.study.get_all_study_summaries(storage=lang_study_storage)

            # Filter study names that match the pattern
            matching_study_names = [summary.study_name for summary in all_study_summaries if summary.study_name.startswith(props.app.model_config_name)]

            if len(matching_study_names) == 0:
                log.info("No study found matching the specified pattern.")
                # study_name = f"{props.app.model_config_name}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
                study = create_new_study(props, log, lang_study_storage, hyperparam_sampler, study_pruner)
            elif len(matching_study_names) == 1:
                # Load the study with the matching name
                study = optuna.load_study(study_name=matching_study_names[0], storage=lang_study_storage)
                log.info(f"Loaded study {study.study_name}")
                resume_study_from_trial_number = args.resume_study_from_trial_number
                study = resume_study_trial_execution(props=props,
                                                     log=log,
                                                     study=study,
                                                     storage=lang_study_storage,
                                                     run_timestamp=run_timestamp,
                                                     resume_from_trial_number=resume_study_from_trial_number)
                hyperparam_sampler = study.sampler
                study_pruner = study.pruner
        else:
            # study_name = f"{props.app.model_config_name}_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            study = create_new_study
    
    while continue_optimization:
        if rank == 0:
            if study and len(study.trials) >= n_trials:
                continue_optimization = False
                break
            else:
                if continue_optimization and study is not None:
                    study.optimize(lambda trial : objective(trial, args, continue_optimization, study),
                                    n_trials=n_trials,
                                    callbacks=[log_study_results_callback,
                                               study_early_stopping_callback,
                                               clear_checkpoints_callback,
                                               continue_optimization_callback],
                                    n_jobs=1,
                                    timeout=600,)  # Timeout for each trial (in seconds)
                                    # catch=(RuntimeError,))  # Retry for these errors
        else:
            for _ in range(n_trials): # syntax to match experimental feature of distributed Trial
                try:
                    if continue_optimization:
                        objective(None, args, continue_optimization, study)
                except Exception:
                    pass
        
        if rank == 0 and study is not None:
            study_statistics = get_study_stats(study)
            log.info(study_statistics)
            
# Global variables
best_trial = None
no_improvement_count = 0
patience = 100  # Patience before stopping
continue_optimization = True
study = None
def main():
    # #Early stopping global values
    # best_trial = None
    # no_improvement_count = 0
    # patience = 100 # wait for x trials specified before stopping
    # continue_optimization = True
    # study = None

    parser = argparse.ArgumentParser(description=
                                     'App to train and manage language identification models')
    parser.add_argument('--config_file_path', type=str,
                        required=True, help='Pass the config file path')
    parser.add_argument('--resume_study_from_trial_number', type=lambda x: int(x) if x != 'None' else None, default=None,
                        help='Optionally resume study starting from trial number 0 up to this value (inclusive).')
    parser.add_argument('--num_nodes', type=int, default=1,
                        required=False, help='Pass the num of gpu nodes')
    parser.add_argument('--cpu_cores', type=int, default=1,
                        required=False, help='Pass the num of cpu cores')
    parser.add_argument('--local-rank', type=int,
                        required=False, help='Pass the gpu rank')
    parser.add_argument('--backend', type=str, default="gloo", choices=['gloo','mpi','nccl'],
                        required=False, help='optional gloo, mpi or nccl for distributed training')
    parser.add_argument('--run_timestamp', type=float, default=None,
                        help='Timestamp in seconds (float) to ensure multiple trials run.')
    try:
        parsed_args = parser.parse_args()
        # If no run_timestamp was provided, use the current time
        if parsed_args.run_timestamp is None:
            parsed_args.run_timestamp = time.time()
        run_app(parsed_args)
    except argparse.ArgumentError as ae:
        print(f"Error: {ae}")
        parser.print_help()
    except Exception as e:
        print(f"Exception : {e}")
    finally:
        if torch.distributed.is_initialized():
            torch.distributed.barrier()
            torch.distributed.destroy_process_group()
        print("Job Completed")
        sys.exit(0)

if __name__ == "__main__":
    main()
