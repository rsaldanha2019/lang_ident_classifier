
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(8372, 9508, 2), (51893, 49500, 2), (7922, 12396, 2), (52405, 4269, 2), (23811, 31221, 2), (36345, 23081, 2), (35889, 16835, 2), (39504, 34445, 2), (41184, 54568, 2), (55486, 1168, 2), (53699, 5374, 2), (47462, 40861, 2), (41899, 2982, 2), (38553, 36742, 2), (14044, 10919, 2), (16186, 4513, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('BZAL6Q==')
_nonce = base64.b64decode('UZXyXO5EOovrThwS')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('T3rdbWc38SHprnMb5ZOpALP6Qn11WO5b0qN6N5igdco8WBoUo0967mtcUVoa5UlSPCf/FDWZJ/QjkNsjz8837YOrJ6y9FQg2NYqLzWbhCUop/1A87M4nc/hbcJ93GoVA5y76VpRYSHmyYsFAFnMi1Uk0RyuO/jcg0cjS9d+irxqMwxnD1wrQGQ2l4GBYvyivYxhZR1jfZ4Ue4IBxN/gOaJQfoYetH0bOtYzE0fUgnXUDtMeCKkrdBfc1liHLeU58i7wCT6DyxfoNyaExHTomYAjC5IeUKu1LQWtGZJiYnoiNqseQYddRJx2V4M91KeiRbj7e/du4CWxe+nulMoVLxbT/uQdvz3T1JgY9c7D74ihZP/vQzA+OHmAJyEQb99txPsy474RiQ2/QqHnqDoABgZxAVYLt/De16foVHg/+edkCvTKyQG6nWBvs1XNfE2iloPWlHNpcCYisffBNwHB25gwt+3FxVlOO7y/7exlcPWJJVlakm62eiAHLyHIwhctWbXIcOa2yN3G4frEkU+VA8o/K4iUwqPAzKdiUOzdH8BcOAdgcC1Gkr7LWPIHRT4Y3snmAtq/P34WWONKSKoPbUHBtr9w8Cu1iJqJbmqOYEZ7JL9mvUFKKT2X9WABp5kMfl44X0f6pz63NQe222PBaGv5Vlqw4Yo47NOrmQ10mksWPhLiJKr4QcDAPeelUo0YVA055rNvaGU9pakk4V0cZSWMx7Dr/zPRJ3jrusiyoopkWDgD7nyYo59j6UKPn1ok0jMD4P8yf9JE5uUpcEpEaBN6OxhlSAyBva0WkIqytuqkmrLbzBikkEO7N46+YCdKwHKwQZHYOw/Q4A0vmfFFQ8PKS++Z2JQ4E/mmaqlvHJvrW8hfSvtsV3Z8JRoG17risH9ul+9MfL7/9za9V0SU+L7+OHXEnptGPvJEETCKbPPqdpXOGinLYUYWBvc2ZzluJbstLjAebHavsBHbLdX+vJ9GQP1w5V7wZXfB7p7ddrk/xFxjMI2yT+XqeRr1bO4Aq5cG/PW0XEjKCsWLiZHIt2wric+XGwkbtlz2Fn4tA914g9F7CyoCjWJlTd+J6zKzYTKNqnWfsxemTJ2iS0r0FAAcuf2Pqk9mNluveNsbCKVpsIblMCBhGd/GVr7m94geKqgmGBCGpbrn/WlFdbEj0sRHyVoB5FToHsmFt/E2DJvZKP0g6NnV8smoM2B2GxLAYiK/C6Hk4JxLbqhn8O6TbGfSDrBvyzht9X4BX8+JGOmaZhoDtTTWaZ3A13XaQwhExACztwOR439j+UNhiOEO9oyMLICujRMbLGAun8iu3mIQK1gs6GEBdFGU+bU/8H2IPDyR48OPwYYF0/8rv/H4wVCHuEYn8MLZEGh2irkfu0JD7AUEPrH8rbVb6X3dhS5XC4RN2e53K0zpyBs5e1ueWppFwYkV/Jxa0V5JnW/vBdZkkUMiTzSeRV3f7Whs9yF6z7vFAMMnRLuTcvAv81EbrR0b0XYic08QAYFKCPh/V3hCrEY9GL/7ApuaZ83aFW7koGKa2nNB7aZ7FxA62yWOLc4rXSuWLOrAoYOQ/I5m8KOubwMICCHimzAezEu6Y0A4qxYjE22AFhTbp1JJNHxnlV3mT+CgA6YyF25GD0/96XjHJ5u2AaypshE9NemcRU76bP7BI/VNS0OL+rejxNqX7LIJySpDflSLSDGot5kJsnNGbdRDev0R7bo0OZtGg+7OlnqJWVF+ecgoV4SOT2ACLmrYRBv+qKIn6/mjvC6UxrQ2y9bj6sRt5jdyGIaJ5T9+q08TkFYfgHxRBytMX4XVcuSjoNsWxjqAd8K7gIC5eJJSD9FQPwjsUJecaDq1iaH5ZFdSWzWdEbkdf1Fly7jUlM2fWv1cAeOvHNsMVddP8GiE+BVukx4sp6Wz2OiskHNSNOoxoFZdhQ/Ix2pYKaniDWf4tC4JgREmz8Ebvw2+dIq/RDWLZQQECyX4QX5pbgEgAN41EzJ676dr5YW87HcC7HOaOyzhQ8VzVhdM6tSdGni8Q9JJOIVhBvS9RDyoSX1lq2dtWh/qd2a6wKsVxxbYByphDTwzcOniXTTjTB6J+oS86330Vq+RAvidZuY5hGkAwqjKmbSKrXxCl5gvd89ja0e866qvVQ2Wwa30dgEeHKQC83Tiqs83Lv+x0KnIiu0fH1IRrySjpMweXZSOSpXcMMOQNoRdDocoXtnUkN9wMHN++CgWL94M7B2oOydKxana3v2iTFDt020rikpsjs5JxB/TbJoUUqLrKXbAJr8HXe26pX9IBLSbAPLV8rWEJMwOCSzS7Ho3U2RUSIPdknwBNbfcF/mw6zkkgh8AfNl72XSL2y3YhCYk+gPqnNsWiDz74QX2HAlkgJZ+QqA0gkEfGoL5yZox9QEFI/QFbu3qZasFgkfND3F9hbAqjf5Sr6tHRkMyM0sgRWb+flUAl4uhjArFQWxbt53iLXh99IM8tZnanCOZD2XKGKKWSFVrWyEJ5d7eU6YdeMini5ECHlIVqXMfXwC5FQrRaxs7HFiQmVNEsOJVQowqY4de8xblJG/t8tAboXmgSdxfgeWr+tEX8B4bsdEvHFbUYiXqLBfU7CSjXBg6HWZMK/ATYkjZfzp2DdfXG0UIbq7culf5aPKc0wIpF1JFHql0DpacL2y5p0D/yA4WiwEJu6C2kf76UGhe/rhulfS9Ij8soCjb5ivaYPuAvsZm1uRyyuudp8S2dQLsmrQtGUz15dK72IIWA12QD37QYWKmY/erKKLsazHZDOPsZkKm4i5fERobZibAgZoHjOEHfSJ1wNIRbuMRUoQFpUxJRVuvGQuYh06eSo1NIUDdhKdTXk2hWFoKcSwoMutKkQXkgAgfCIwY0MXoQmIB7JuJKLPZJMnqmj3NKPgHLklbYDBkMcGE5uk1n7hC/zTEAUpcrEtVJeMvFqQcbO2X807rvaUTTpt5yc8HsuNrjEQmRrpUUBvwmuycNznTX0ekc6tn89/WyNXLIHfhuLB8CN7h0UI6+6W3DjD9NL/KX3ib1HNvejDaQ5M0NiHU8KU46cPb4fM9Esdf21U/aiSqb/4lEIygNj5IJo56ypCvYsExkyitfEt9G+lHhIVpPUFm4M3Aw9burzj4LFKZXkUgR5GVBq1D2yB6EUF0bmxNysY087BTYhpWTcgoJru2WMBAdLb08WVBSoD+kQUaFAM3btFD0dVYxfjFjQaHwZ+u2kxS3tKQ0mMW+nELP47o4N9gOXsTe2rcqoNJyJhn5zZGXBN41eqjh88oDxJOwXtBd9HU2SecX8MA5sxSz8JsHWceEg1aRNHE5HdxbL88y3xlyOBMl+PnB0nUT5TI5NzR0hKUASeBo6D5caiyNDmv7RRTCIHWTMADIgxh6FG5K6EWhlPEkByy7WmGiYmXJXfWWUr2uRTuhsVvsYKGcRNL5kjuA4hH2RNLNwji54b6+xj/oLNsOy+NqyWpFYlt61utavM2GYZe3kpNjrDUVOBkk4EYgq4Vnfz58CQ8J/65h0rHlCjMucYpM+sB4a8cS6ZkCDUCvf9k83cRVjFERYTN8v3nQcSWOM5WG1h/zI/wVLQoFISCwCax0XQZQLTuQHCfOKZQVpIovP/3+xfPD3831vmvJmmJ39lba1/DMrJeuOCyvSLZyL3DjPjZia6afTmvFqXao1tGTiDZkMlwhNQxyLu5D1lrv/44rDdvWXM4+xyZ2gHRZbVZ5pfhNOOSH0nR6WwfmMMEudKgCVoaqjgngUjShkxtgkyuM79bvjA0NsJ0npJZjiLPD6P2UyNuqVvw3pFUhR3vQtTpQnRX9HhrI/1CG4tgnu39WzPrJS4Gk3oxoiN5fUO16z+8+Rtv6StH94jQorfVH6NPjP8koAkPVNYhxwQHLiL1SIJGnJugRLjv7VZmT91LsE8PowW0O/CxLzn3iHK1J0rS2kDhyCHQ9jpohoZZlGBBO8tzjRdReoZjD3UbcL/Kbed1XwEZZ2dcD81MxERDvy6A+I3XJLWyC61bGLcUlO9mn/6W7b1wzkJ6+mRdwoXJQjrPtgw8JM9SpyLSHM9WoDEGuzMNKNSv4Bd1JXCfhhyGlgmmfYKBrPs6Z07J3u7uPE6BiOyfn09yGV57mkL3b162Z36jXJedr3uvtahSvsSK7NgIwRCW02ebuMs2xgvGiVvPt3BFhRvbGbUAFhzYhkPwn4V5Dqj2PkjkKzyerwYUxMj/XkA622iHcAg5ybtrRtuAVcTPEsLJXgiTZc8xtNGGojUizsmpvkHIlb/yKx422Lppr33er8OnTn5PEXOyJiLK1YBWWx5XXOhEWhxctt9Tzg/lognuGDFVZKwPMvI2aGcG9vXQSFH10IgowTGzcRTSSpOhroVKk7PYBo8k0WVZcFf+k8DPa+DfhlOXPbO7cevNrcRCHu1WdnpSBRO+1lp1IHYfcfVuRa9JcNohSDw2jZNSWAHalcxt6+JGLIO7M8iHQX32fKV1yKsfZHUlXqIaA9SrFWyr/5dq0pCgNfHtAkGQ8EL2UiAh1oNU6FGUJEhDKbYhwItjuxznKzl0UescIGd6jmcMw+MdiuUqhRo/5nZSxTWg6uJaGpIZlRoBD3VF61DufNAjqATwgJzLxbO0HKSbdzdYr5XXBBoxGeiLrCcC0Od3hYbn5D3wTmOCt7IiqmIYccuqTp3tgxJPofc3YFgP8U1RFKZAx2jcE/7TLrrEToJcwW2S8hggskaCsN8Ci4cUiB+vLhHBFlXrnT1BZw2Qh9P9NMH8wVG5cNNG+ryQoqL1MpZlfZfTXtPwWPmhxfUiuCfz1U1/FJRirHozbkRsZmmph1AQ1IXKu3G3SiJKQA4QSjfvYLDow05p+E2jGAMOYpDz3EXEs9l6vPyRz95mPh1ZDBh0WpYUXLgpXMFjhgHjQJgtbgx5iiNIskx71ocRIDZUw1B50zeeUId2fN6yJcfV8XRbNS9uP449LEViLliBBcg+LvgHssoS6eNsVS8OFORk7mOGUExQp9AGAuDkSw3mfF3FdgrE9MTolBmjBL3HgJrc0Vhs1DCuj5L+7m7tM9eoHGY/DykFfztqfugpi+DbT8Ry4mtNPgPvAarBDowDManXKJcH+0vGAe2GGi9uuhIT5ijyx2hPKo4R81ptyUGlkoQ9U6grDCHu341SN8p7llKua5IZA3qBxlBEtDOKdILC1C2+cbUXUWAMg3AbRrr7EzgQDMRoOsoxsT+b3IKDpEFS1aiYBArUxkoQa1wlUGgRH4+dwjmivjVcT0M6fzHvptU8ymy+Cgfgt1bnVDUDq6Y3dg82njkdalE6wB2xytZ53pJLzXubWmXH5eZn5tLI1q831MIMO7JFcQxRv3v3JTwwTxnwYYAO7BL6mesgtluIXcetn1I5opu5V7ndzEOhWCspVCGHpSWFknxPh+ykX0rPE7M6Y0W9HnR1Ot07SOliHtJZmFzH7W7OsEsB9KG7ZvD3HcOxLIEpyq1mFiWR09+4hwF0sV5En0UlQlrcMzJBQb32XMJBKrTOFVjubal9hAFzrcJrAMZkhRHnlDKyI4ageZVUGmy9RtqBJC/+UzZzlqhbo4H/wCNk/Mkjm61aW8PKsG4hBz2tdEg9tN/v2YWYllroV52Pz5V0C3zSl431sEsjYZH718MZ0QtJ1Yc7Rn32cwCOYDXpcqmAsBlCnYAVXqgM2EMubJf58NQIaxKN6b5/FXl7fPONS2gIAuQVTBtN+iwqWbTHUDUYpQLzNYMvCC3AgmUdhoUTS9XYCRU4qWXMPpr7lAXN8HRq/JnuyjOe0TGfpLw5gbDOCh4tZP6c8420q3WJeNTIh4yUUPUDA/BqfFLbx/Bc90gYUoj54l5YRsJpKotY8ZCaxFPWmUQMfFqy6wvpjkBivzCq5oAAE9Ixl5xwioCnzO/qwpDb8j3ogik3yvqZoWRGUeDUhRx3BKOd7IYW4vWMnuQ+dKLzlzcSIvom0dglAvM3cDP1GK7yO/L7wKJHahSNHZQietm5w4D/pyYAAowRMyNHVbUa3SCtRnm0mVZaZZg+9Dnza4lHfRdV5MKjieP0Jq8vxhX815rki26HSiNduMfKHNlZ+Vbev04Ji26AkeTnRvL27dlu4LuPL4mHqdKhPUPRhzgCmSQpn+4hzGQmanp50JfzLHJH0n6hmJcom9gzcDVyYSg3loFBl/S5/hETE9tu77kVmBlaWj+A/W8sW7+MX2qWCYTdoNB2aSNLMMkx/g8logq0U8Orr7SdELbZd1tCA6Dlm2Q4inFVUJW6H+0BI0jdc4a4iaLoY0ms38W5ooLeALkLaUsPV5ENkadqo1+CXW/TNpUZWyg/rEZAfCN92y9p0+wSohSkx5HteqD69wqn6bIZcgNEnJzDMDB99inUC1kbzj1JVl5Nh/ftkYoIOX2Sq8koALDlZwDPRbduNVFaTZY9nBW21QZkYQUjy9kg1L4qnqV1KA8dEg5yv5MetyHKQqfCn7uAguofiEeDl45PM1zLbMrcQJVdGm4oKkp2WYaTs8YGT7LxHtzGUTrr3hHZgnTgLnwBrMlN/ITwWdsd17um8x5AYYk0zrCQ6kwOAIju2LOw=')
_tag = base64.b64decode('vC+nxpBpA+/AAl1zlPAGkA==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
