# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : lang_ident_classifier_api.py
# @Time             : 2025-10-28 09:56 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

"""
Minimal YAML-driven CLI entrypoint — strictly pass-through.

Usage:
    python -m lang_ident_classifier.cli.lang_ident_classifier_api --config_file_path path/to/config.yaml [--other args...]
"""

from __future__ import _da860c8daf15

import _4a2ef16c2a6e
import inspect
import os
import sys
import time
import _6e96068d35e9
import types
from typing import _f56362301c62

# Module-level imports that the dispatcher may call. Keep these as modules so the dispatcher
# can inspect and call their existing entrypoints (run_app, run_finetune, run_train, run, cli_main, main, process).
# Note: process_bhasha_dataset is the new minimal dataset-processing module that exposes run_app(args).
from _0e34b7dd51f9._aac3a53535c0 import (
    _35b4259ab43f,
    _5d0a132655c6,
    # new minimal dataset processor module
    _486a181b9754,
)
from _0e34b7dd51f9._b990c65edbca._638b48d14aaa._b803f7cb70d1 import _6a27e699f67f
from _0e34b7dd51f9._b990c65edbca._638b48d14aaa._30270cc376e6 import _16d25e588f83
from _0e34b7dd51f9._b990c65edbca._638b48d14aaa._8e6a8324805a import _2e1d0ab96419


def _bc010114c7d1(_97e0db784686: _b76ca5883831, _d01829ccf081: _f56362301c62):
    if _d01829ccf081 is _fa959a6ee0c1:
        raise _caaaad9df440(f"Component '{_97e0db784686}' is not importable. Adjust import path or install module.")


def _973c4d44a35d(_ba4254e46b36: _f56362301c62, _9d332272df2d):
    """
    Call a component which may be:
      - A callable (function/class) -> call it with args if it accepts one argument, otherwise call without args.
      - A module object -> try common entrypoint function names inside the module.

    Entrypoint names tried (in order): run_app, run_finetune, run_train, run, cli_main, main, process
    """
    _3690d573a741 = _fa959a6ee0c1

    if _09eb6c98d87d(_ba4254e46b36) and not _60ed7c60fb2f(_ba4254e46b36, types._d15d500669be):
        _3690d573a741 = _ba4254e46b36
    elif _60ed7c60fb2f(_ba4254e46b36, types._d15d500669be):
        for _97e0db784686 in ("run_app", "run_finetune", "run_train", "run", "cli_main", "main", "process"):
            _1f1aed446c8e = _58be58453505(_ba4254e46b36, _97e0db784686, _fa959a6ee0c1)
            if _09eb6c98d87d(_1f1aed446c8e):
                _3690d573a741 = _1f1aed446c8e
                break
        if _3690d573a741 is _fa959a6ee0c1:
            raise _d9ebf61306f3(
                f"Module '{_ba4254e46b36.__name__}' does not expose a callable entrypoint. "
                "Expect one of: run_app, run_finetune, run_train, run, cli_main, main, process."
            )
    else:
        raise _d9ebf61306f3(f"Component {_ba4254e46b36!r} is not callable or importable module with known entrypoint.")

    # Inspect signature to decide whether to pass args
    try:
        _d415bb38061f = inspect._9134ebf7a6b2(_3690d573a741)
        _5f5aada99fd5 = _d415bb38061f._882f71514c1d
        if _b7f1e17e4d31(_5f5aada99fd5) == 0:
            return _3690d573a741()
        if _b7f1e17e4d31(_5f5aada99fd5) == 1:
            return _3690d573a741(_9d332272df2d)
        _459b840c38cb = [_7477c29b0c66 for _7477c29b0c66 in _5f5aada99fd5._11fa074d898e()]
        if _5b86c8054d79(_58a528b25797 in ("args", "argv", "parsed_args", "cli_args") for _58a528b25797 in _459b840c38cb):
            return _3690d573a741(_9d332272df2d)
        # Try safe no-arg call first, then with args
        try:
            return _3690d573a741()
        except _d9ebf61306f3:
            return _3690d573a741(_9d332272df2d)
    except (_9664efedd4c7, _d9ebf61306f3):
        # signature inspection failed for some C-implemented callables; fall back to trial
        try:
            return _3690d573a741(_9d332272df2d)
        except _d9ebf61306f3:
            return _3690d573a741()


def _9c43625096bf():
    _8841eeb089f4 = _4a2ef16c2a6e._d5967413c171(_d0da2d1d3bb2="Unified CLI for lang-ident tasks (YAML-driven, pass-through).")
    _8841eeb089f4._f1ed01a5b804("--config_file_path", _98b6042c485d=_b76ca5883831, _f5e5734edc70=_747514c8c69d, _8e327bca237a="Path to YAML config")
    _8841eeb089f4._f1ed01a5b804("--num_nodes", _98b6042c485d=_945fd5e60845, _0898f545c133=1, _f5e5734edc70=_e4a3f51f7b8d)
    _8841eeb089f4._f1ed01a5b804("--cpu_cores", _98b6042c485d=_945fd5e60845, _0898f545c133=1, _f5e5734edc70=_e4a3f51f7b8d)
    _8841eeb089f4._f1ed01a5b804("--local_rank", _98b6042c485d=_945fd5e60845, _f5e5734edc70=_e4a3f51f7b8d)
    _8841eeb089f4._f1ed01a5b804("--backend", _98b6042c485d=_b76ca5883831, _0898f545c133="gloo", _f5e5734edc70=_e4a3f51f7b8d, _c604bd1477e8=["gloo", "mpi", "nccl"])
    _8841eeb089f4._f1ed01a5b804("--run_timestamp", _98b6042c485d=_28f98555075d, _0898f545c133=_fa959a6ee0c1, _f5e5734edc70=_e4a3f51f7b8d)
    _9d332272df2d, _9e6e30e89302 = _8841eeb089f4._ad39c8850f1b()
    if _9e6e30e89302:
        _b06f96bf1dd6._848bae938e2f("Ignoring unknown CLI args passed to dispatcher: %s", _9e6e30e89302)

    # Ensure run_timestamp present so downstream code expecting it keeps parity
    if _9d332272df2d._ffb9f278680f is _fa959a6ee0c1:
        _9d332272df2d._ffb9f278680f = time.time()

    # Load YAML props
    _fed5aa31ffe7 = _16d25e588f83()
    _024853ba3bc5 = _fed5aa31ffe7._96ccf433bd92(_9d332272df2d._04c841586ab2)

    # Setup logging
    _18ceb895a1ca = _6a27e699f67f()
    _b06f96bf1dd6 = _18ceb895a1ca._ed5f7022f70a(_024853ba3bc5)

    _b06f96bf1dd6._848bae938e2f("Dispatcher starting; config: %s", _9d332272df2d._04c841586ab2)

    # Read operation_mode via property_validation (explicit, shows what's being passed)
    _10df6aae06b4 = _2e1d0ab96419(
        _024853ba3bc5=_024853ba3bc5,
        _97e0db784686="operation_mode",
        _924d09503925=_b76ca5883831,
        _f5e5734edc70=_747514c8c69d,
        _8e327bca237a="Top-level operation_mode (e.g. 'process_bhasha_dataset','model_hyperparameter_selection','model_train','model_finetune')."
    )

    # property_validation may return non-string (e.g., list) — normalize to string scalar
    if _60ed7c60fb2f(_10df6aae06b4, (_fe6844a53d7c, _f39b765f3def)):
        if _b7f1e17e4d31(_10df6aae06b4) == 0:
            raise _9664efedd4c7("operation_mode property is an empty list.")
        _4611a490ae8c = _b76ca5883831(_10df6aae06b4[0])._da18ed9adadf()
    else:
        _4611a490ae8c = _b76ca5883831(_10df6aae06b4)._da18ed9adadf()

    _b06f96bf1dd6._848bae938e2f("Operation mode: %s", _4611a490ae8c)

    # Dispatch to module-level objects already imported above (keeps behaviour non-intrusive)
    try:
        if _4611a490ae8c == "process_bhasha_dataset":
            _13ed94f500cd("process_bhasha_dataset", _486a181b9754)
            _a40bea86102f(_486a181b9754, _9d332272df2d)

        elif _4611a490ae8c == "model_hyperparameter_selection":
            _13ed94f500cd("model_hyperparameter_selection", _35b4259ab43f)
            _a40bea86102f(_35b4259ab43f, _9d332272df2d)

        elif _4611a490ae8c == "model_train":
            _13ed94f500cd("model_train_finetune", _5d0a132655c6)
            _a40bea86102f(_5d0a132655c6, _9d332272df2d)

        elif _4611a490ae8c == "model_finetune":
            _13ed94f500cd("model_train_finetune", _5d0a132655c6)
            _a40bea86102f(_5d0a132655c6, _9d332272df2d)

        else:
            raise _9664efedd4c7(f"Unknown operation_mode '{_4611a490ae8c}'. Expected one of: process_bhasha_dataset, model_hyperparameter_selection, model_train, model_finetune")

    except _120e3afc9980 as _7de08a015bd6:
        _b06f96bf1dd6._c897d24ccdc5("Operation failed: %s", _7de08a015bd6)
        _b06f96bf1dd6._c897d24ccdc5(_6e96068d35e9._0594da8c1687())
        # Best-effort distributed cleanup
        try:
            import _e72aabbc7e6e
            if _e72aabbc7e6e._6bcc2b481e99._605de3f5c2ec():
                try:
                    _e72aabbc7e6e._6bcc2b481e99._6511d5be5158()
                except _120e3afc9980:
                    pass
                try:
                    _e72aabbc7e6e._6bcc2b481e99._a5aa2e87d958()
                except _120e3afc9980:
                    pass
        except _120e3afc9980:
            pass
        raise

    finally:
        # cleanup (best-effort)
        try:
            import _e72aabbc7e6e
            if _e72aabbc7e6e._6bcc2b481e99._605de3f5c2ec():
                try:
                    _e72aabbc7e6e._6bcc2b481e99._6511d5be5158()
                except _120e3afc9980:
                    pass
                try:
                    _e72aabbc7e6e._6bcc2b481e99._a5aa2e87d958()
                except _120e3afc9980:
                    pass
        except _120e3afc9980:
            pass

    _b06f96bf1dd6._848bae938e2f("Dispatcher finished; exiting.")
    sys._78fc7f421a57(0)


if __name__ == "__main__":
    _6dd58250b927()
