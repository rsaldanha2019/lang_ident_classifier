# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : lang_ident_classifier_api.py
# @Time             : 2025-10-28 09:56 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

"""
Minimal YAML-driven CLI entrypoint — strictly pass-through.

Usage:
    python -m lang_ident_classifier.cli.lang_ident_classifier_api --config_file_path path/to/config.yaml [--other args...]
"""

from _aa012ca6f30f import _e187109bb769

import _ef82cae4b024
import _18cf7bf8a865
import _3a6203491d57
import _9d4c16830c6b
import _7ae77628c983
import _329438ba44f7
import _37aa6093cd61
from _eb7bf1679f89 import _dd921c53ef74

# Module-level imports that the dispatcher may call. Keep these as modules so the dispatcher
# can inspect and call their existing entrypoints (run_app, run_finetune, run_train, run, cli_main, main, process).
# Note: process_bhasha_dataset is the new minimal dataset-processing module that exposes run_app(args).
from _b99a3702fd98._9d221767c025 import (
    _8b6eca06eb72,
    _b464a5e2a529,
    # new minimal dataset processor module
    _d82d196d5f69,
)
from _b99a3702fd98._5398890cfca3._70680db298af._6a9a5c440d27 import _c36dc0214b86
from _b99a3702fd98._5398890cfca3._70680db298af._48d148f87252 import _a8bfb40e5c22
from _b99a3702fd98._5398890cfca3._70680db298af._098828bf5a73 import _5674478a0427


def _034abe2f1538(_f41a00fc78ff: _ddd585b3b2a7, _ad111b940d2a: _dd921c53ef74):
    if _ad111b940d2a is _516217c12611:
        raise _2bce628a3e68(f"Component '{_f41a00fc78ff}' is not importable. Adjust import path or install module.")


def _67126c7bcb8e(_3989288e476f: _dd921c53ef74, _5be0f3f9c6af):
    """
    Call a component which may be:
      - A callable (function/class) -> call it with args if it accepts one argument, otherwise call without args.
      - A module object -> try common entrypoint function names inside the module.

    Entrypoint names tried (in order): run_app, run_finetune, run_train, run, cli_main, main, process
    """
    _52eb8e21b1af = _516217c12611

    if _b113fb937a90(_3989288e476f) and not _2714b74361a7(_3989288e476f, _37aa6093cd61._eda8d5ab83f7):
        _52eb8e21b1af = _3989288e476f
    elif _2714b74361a7(_3989288e476f, _37aa6093cd61._eda8d5ab83f7):
        for _f41a00fc78ff in ("run_app", "run_finetune", "run_train", "run", "cli_main", "main", "process"):
            _36f1998fe2d6 = _85c1b35726ae(_3989288e476f, _f41a00fc78ff, _516217c12611)
            if _b113fb937a90(_36f1998fe2d6):
                _52eb8e21b1af = _36f1998fe2d6
                break
        if _52eb8e21b1af is _516217c12611:
            raise _060d608786ae(
                f"Module '{_3989288e476f.__name__}' does not expose a callable entrypoint. "
                "Expect one of: run_app, run_finetune, run_train, run, cli_main, main, process."
            )
    else:
        raise _060d608786ae(f"Component {_3989288e476f!r} is not callable or importable module with known entrypoint.")

    # Inspect signature to decide whether to pass args
    try:
        _44200c0c6fe8 = _18cf7bf8a865._e43b8624f559(_52eb8e21b1af)
        _6c4b8fbf28ad = _44200c0c6fe8._937838505b2b
        if _17b9063a0ad4(_6c4b8fbf28ad) == 0:
            return _52eb8e21b1af()
        if _17b9063a0ad4(_6c4b8fbf28ad) == 1:
            return _52eb8e21b1af(_5be0f3f9c6af)
        _a0ac888c36d7 = [_4e23e55969d7 for _4e23e55969d7 in _6c4b8fbf28ad._9ddb26015b2a()]
        if _dbfa77daf40e(_d285082c48ec in ("args", "argv", "parsed_args", "cli_args") for _d285082c48ec in _a0ac888c36d7):
            return _52eb8e21b1af(_5be0f3f9c6af)
        # Try safe no-arg call first, then with args
        try:
            return _52eb8e21b1af()
        except _060d608786ae:
            return _52eb8e21b1af(_5be0f3f9c6af)
    except (_ea718607d5e2, _060d608786ae):
        # signature inspection failed for some C-implemented callables; fall back to trial
        try:
            return _52eb8e21b1af(_5be0f3f9c6af)
        except _060d608786ae:
            return _52eb8e21b1af()


def _c7a6f42be274():
    _fffa93889383 = _ef82cae4b024._5781c05d1ad4(_dd42b9831c98="Unified CLI for lang-ident tasks (YAML-driven, pass-through).")
    _fffa93889383._caf526e25e94("--config_file_path", _2517b2d5e4a4=_ddd585b3b2a7, _b3ee174c8e27=_8094e7ba3e41, _3048c729b074="Path to YAML config")
    _fffa93889383._caf526e25e94("--num_nodes", _2517b2d5e4a4=_84f99918922a, _d13511017366=1, _b3ee174c8e27=_f5e0bbd45f60)
    _fffa93889383._caf526e25e94("--cpu_cores", _2517b2d5e4a4=_84f99918922a, _d13511017366=1, _b3ee174c8e27=_f5e0bbd45f60)
    _fffa93889383._caf526e25e94("--local_rank", _2517b2d5e4a4=_84f99918922a, _b3ee174c8e27=_f5e0bbd45f60)
    _fffa93889383._caf526e25e94("--backend", _2517b2d5e4a4=_ddd585b3b2a7, _d13511017366="gloo", _b3ee174c8e27=_f5e0bbd45f60, _82632651e1e3=["gloo", "mpi", "nccl"])
    _fffa93889383._caf526e25e94("--run_timestamp", _2517b2d5e4a4=_9c4a72ccd5b6, _d13511017366=_516217c12611, _b3ee174c8e27=_f5e0bbd45f60)
    _5be0f3f9c6af, _b824c090271d = _fffa93889383._891a4d51f8cb()
    if _b824c090271d:
        _efeec086c598._0f8b2f6ddcd9("Ignoring unknown CLI args passed to dispatcher: %s", _b824c090271d)

    # Ensure run_timestamp present so downstream code expecting it keeps parity
    if _5be0f3f9c6af._f0d8729b17ce is _516217c12611:
        _5be0f3f9c6af._f0d8729b17ce = _7ae77628c983._7ae77628c983()

    # Load YAML props
    _9abec1cd8fa0 = _a8bfb40e5c22()
    _9cb0ec586c39 = _9abec1cd8fa0._979f4618511f(_5be0f3f9c6af._e4fa13523285)

    # Setup logging
    _936b1b4da8c8 = _c36dc0214b86()
    _efeec086c598 = _936b1b4da8c8._161cbdc81383(_9cb0ec586c39)

    _efeec086c598._0f8b2f6ddcd9("Dispatcher starting; config: %s", _5be0f3f9c6af._e4fa13523285)

    # Read operation_mode via property_validation (explicit, shows what's being passed)
    _23d137d2f297 = _5674478a0427(
        _9cb0ec586c39=_9cb0ec586c39,
        _f41a00fc78ff="operation_mode",
        _23aa38ffcfc3=_ddd585b3b2a7,
        _b3ee174c8e27=_8094e7ba3e41,
        _3048c729b074="Top-level operation_mode (e.g. 'process_bhasha_dataset','model_hyperparameter_selection','model_train','model_finetune')."
    )

    # property_validation may return non-string (e.g., list) — normalize to string scalar
    if _2714b74361a7(_23d137d2f297, (_910e351b258c, _6471294d629c)):
        if _17b9063a0ad4(_23d137d2f297) == 0:
            raise _ea718607d5e2("operation_mode property is an empty list.")
        _271d455197e2 = _ddd585b3b2a7(_23d137d2f297[0])._e1004c7f7ba0()
    else:
        _271d455197e2 = _ddd585b3b2a7(_23d137d2f297)._e1004c7f7ba0()

    _efeec086c598._0f8b2f6ddcd9("Operation mode: %s", _271d455197e2)

    # Dispatch to module-level objects already imported above (keeps behaviour non-intrusive)
    try:
        if _271d455197e2 == "process_bhasha_dataset":
            _6715c7f85210("process_bhasha_dataset", _d82d196d5f69)
            _04fa388bfc20(_d82d196d5f69, _5be0f3f9c6af)

        elif _271d455197e2 == "model_hyperparameter_selection":
            _6715c7f85210("model_hyperparameter_selection", _8b6eca06eb72)
            _04fa388bfc20(_8b6eca06eb72, _5be0f3f9c6af)

        elif _271d455197e2 == "model_train":
            _6715c7f85210("model_train_finetune", _b464a5e2a529)
            _04fa388bfc20(_b464a5e2a529, _5be0f3f9c6af)

        elif _271d455197e2 == "model_finetune":
            _6715c7f85210("model_train_finetune", _b464a5e2a529)
            _04fa388bfc20(_b464a5e2a529, _5be0f3f9c6af)

        else:
            raise _ea718607d5e2(f"Unknown operation_mode '{_271d455197e2}'. Expected one of: process_bhasha_dataset, model_hyperparameter_selection, model_train, model_finetune")

    except _912ef51aafcf as _b3941bff50f2:
        _efeec086c598._25867f5357b7("Operation failed: %s", _b3941bff50f2)
        _efeec086c598._25867f5357b7(_329438ba44f7._1ba4e6cfd7d2())
        # Best-effort distributed cleanup
        try:
            import _bc94047c9221
            if _bc94047c9221._ba958abb0605._1d73f58d14a8():
                try:
                    _bc94047c9221._ba958abb0605._1e98af5738c6()
                except _912ef51aafcf:
                    pass
                try:
                    _bc94047c9221._ba958abb0605._6ba1a72af749()
                except _912ef51aafcf:
                    pass
        except _912ef51aafcf:
            pass
        raise

    finally:
        # cleanup (best-effort)
        try:
            import _bc94047c9221
            if _bc94047c9221._ba958abb0605._1d73f58d14a8():
                try:
                    _bc94047c9221._ba958abb0605._1e98af5738c6()
                except _912ef51aafcf:
                    pass
                try:
                    _bc94047c9221._ba958abb0605._6ba1a72af749()
                except _912ef51aafcf:
                    pass
        except _912ef51aafcf:
            pass

    _efeec086c598._0f8b2f6ddcd9("Dispatcher finished; exiting.")
    _9d4c16830c6b._bb235310f4a6(0)


if __name__ == "__main__":
    _24c5f6247532()
