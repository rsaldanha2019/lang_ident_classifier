# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from __future__ import _3de6a039df78
from _ce42c9643a0c import _7614f8ef8bd4
import _bbdd7a993075, _bdb2775d6abb, json, os, random, _2bdde31461ca, sys, time, _fe2d867096ff
from _dea684d6bf17 import _8f9c25327ee9
from typing import _f2e80282a30e, _a24f2ba43d10, _2e2e0814aa69
import _7d32d55b118a as _1b6eb82c15df, _18a43369caea, _1a6f70bb00db as _123faee15cd5
from _1a6f70bb00db import _47ef9836c489
from _1a6f70bb00db._f31fcdb6fa42 import _6131979f26c6
from _1a6f70bb00db._f31fcdb6fa42._6add8c94fca1._558190f8ee26 import _0b09df91bb64
from _ab822446c5da import _7197d068bb13, _f0621381956a, _72e0b217ae42
from _aff1b91790ba._91a1c4163574._6c69ff15ab81._9faabebeec89 import _7ac01c183962
from _aff1b91790ba._91a1c4163574._6c69ff15ab81._942675e11c81 import _74108b95cbcb
from _aff1b91790ba._91a1c4163574._6c69ff15ab81._b5ad49bb0e65 import _0f0d4b8a0f67
from _aff1b91790ba._91a1c4163574._6c69ff15ab81._257406a83762 import _36f87f8a6c5a
from _aff1b91790ba._91a1c4163574._7259f3b3d744._b4805e739a06 import _efa9be840fa5
from _aff1b91790ba._91a1c4163574._7259f3b3d744._35146d15ccb5 import _91a1dd54cb3f
from _aff1b91790ba._91a1c4163574._9fd3595fa937._4b40587b57ce import _611e52443ec8
from _aff1b91790ba._91a1c4163574._9fd3595fa937._0c342d277316 import _4db8aa6faecb
from _aff1b91790ba._91a1c4163574._6131979f26c6._e0d7829f9005 import _96e32965a32e
from _aff1b91790ba._91a1c4163574._6c69ff15ab81._aaebb67fe80d import _1e1ed1db437d
from _aff1b91790ba._91a1c4163574._6c69ff15ab81._aaebb67fe80d import (
    _b948e835d04f, _81b746f55527, _bc16dec66eea,
    _5835f460f364, _fdefaf53950d, _a69480e67acf,
    _c3fdb964e8b2, _29f6aa151d10, _bcc21475305f,
    _534b7c0479b0, _392e3463401f, _37f1b2f1e748,
    _9803f47676e1, _73f2569f9425
)

os._dd3c1568f5c8["TOKENIZERS_PARALLELISM"] = "True"
_a642f02c4e9b = _18a43369caea._32854782bdbd._1dc4ede5e2e5() and _18a43369caea._32854782bdbd._f580f2cde92d() > 0
if _a642f02c4e9b:
    try:
        from _6f0055df2aa5 import _6782ddb1a903
        import _1ccb6db632c6 as _49e4fab064e9
    except _cdc83e87a063:
        _49e4fab064e9 = _80a9167f8e3c


def _22fe90454125(_58563f78d084: _18a43369caea._ba34dcbdf335._6c50008fb5af, _c494db51be85: _4e93e8e4197f, _fe786efc2a31: _2e2e0814aa69[_4e93e8e4197f] = _80a9167f8e3c) -> _80a9167f8e3c:
    if not os._483237cbb4ae._ec36fa182450(_c494db51be85):
        raise _e2856f693ab5(f"Finetuned model path not found: {_c494db51be85}")
    if _c494db51be85._1ca99933a172((".pt", ".pth")):
        _596dd9dfc59f = _fe786efc2a31 or ("cpu" if not _18a43369caea._32854782bdbd._1dc4ede5e2e5() else _80a9167f8e3c)
        _a746485d0982 = _18a43369caea._08c82306d00d(_c494db51be85, _fe786efc2a31=_596dd9dfc59f)
        _bffcbeffe57a = _a746485d0982._56c94a0cf9a3("state_dict", _a746485d0982._56c94a0cf9a3("model_state_dict", _a746485d0982)) if _ace141fb358c(_a746485d0982, _1b9a02d53e24) else _a746485d0982
        if not _ace141fb358c(_bffcbeffe57a, _1b9a02d53e24):
            raise _b05f6ed198ad(f"Loaded .pt file does not contain state_dict mapping: {_c494db51be85}")
        _58563f78d084._695e6bd758b0(_bffcbeffe57a, _88023979806f=_0e818812e0d6)
    elif _c494db51be85._1ca99933a172(".ckpt"):
        try:
            if _0cb666c5d01a(_58563f78d084._522e11c66cb1, "load_from_checkpoint"):
                _7f231bac494c = _58563f78d084._522e11c66cb1._3e552c9fb01c(_c494db51be85, **{})
                _58563f78d084._695e6bd758b0(_7f231bac494c._32e4c6619aa9(), _88023979806f=_0e818812e0d6)
                return
            _a746485d0982 = _18a43369caea._08c82306d00d(_c494db51be85, _fe786efc2a31="cpu")
            _bffcbeffe57a = _a746485d0982._56c94a0cf9a3("state_dict", _a746485d0982)
            if not _ace141fb358c(_bffcbeffe57a, _1b9a02d53e24):
                raise _b05f6ed198ad("Lightning checkpoint did not contain a recognizable state_dict.")
            _58563f78d084._695e6bd758b0(_bffcbeffe57a, _88023979806f=_0e818812e0d6)
        except _cdc83e87a063 as _9cbd3caba668:
            raise _b05f6ed198ad(f"Failed to load .ckpt into model: {_9cbd3caba668}") from _9cbd3caba668
    else:
        raise _5064a3bd0074("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _851fa271ca3b(_d2c8652dc95c: _bbdd7a993075._f221f9b7b19a, _a6fadc572383: _f2e80282a30e, _7ff9d1e4917d: _a24f2ba43d10[_4e93e8e4197f, _f2e80282a30e], _8c874679786b: _4e93e8e4197f, _7b6d5119f18a: _f2e80282a30e, _47671f55f76e: _f2e80282a30e, _eae8eba08653: _20696f7f0207, _fa866b2bdf91: _7c62b9d9f892, _230ee383730a: _f2e80282a30e, _4716af07414e: _7c62b9d9f892, _f0b2c2072221: _7614f8ef8bd4, _df5aec41c7ae: _4e93e8e4197f = "32"):
    """
    Compute test accuracy using the best checkpoint.
    """
    _22bc2611a585 = _0e818812e0d6
    if _a642f02c4e9b:
        _ff80f97b8c44 = _6782ddb1a903(
            _da11d3031340=_492e6844f5a6,
            _cf644ff73e7a=_bc16dec66eea(),
            _c1a7fe6440e2=_492e6844f5a6,
            _af60876205f2="nf4",
        )
        _22bc2611a585 = _492e6844f5a6

    _c9e6ab68f572 = 'gpu' if _18a43369caea._32854782bdbd._1dc4ede5e2e5() else 'cpu'
    _d05ab7d83157 = 'cpu'
    if _c9e6ab68f572 == 'gpu':
        _5d033c14f714 = _18a43369caea._b84988b8d674._e714bd97927a() if _18a43369caea._b84988b8d674._11f1c644c15e() else 0
        _d05ab7d83157 = f"cuda:{_5d033c14f714}"
    else:
        _5d033c14f714 = -1

    _57be73308c12 = _7ff9d1e4917d._56c94a0cf9a3("pretrained_model_embedding_name")

    _7ff9d1e4917d._a8f332b64b01({
        "tokenizer": _7b6d5119f18a,
        "pretrained_embedding_model": _47671f55f76e,
        "device_dict": _81b746f55527(),
    })

    if not _8c874679786b:
        _f0b2c2072221._8ea60af5264d("No best checkpoint found. Proceeding with current model weights.")
    else:
        _f0b2c2072221._8ea60af5264d(f"Testing with best checkpoint: {_8c874679786b}")

    if "llama" in (_57be73308c12 or ""):
        _58563f78d084 = _4db8aa6faecb(**_7ff9d1e4917d)
        _fa866b2bdf91 = _492e6844f5a6
    else:
        _58563f78d084 = _611e52443ec8(**_7ff9d1e4917d)

    if _4716af07414e:
        if _22bc2611a585:
            _cb162b82f696 = lambda _2d399c125b93: (
                _0cb666c5d01a(_2d399c125b93, "weight") and _ace141fb358c(_2d399c125b93._ee722f451b57, _18a43369caea._9f558c4e5250) and _2d399c125b93._ee722f451b57._a1cd99aa81e1() > 64 and
                not _ace141fb358c(_2d399c125b93, (_49e4fab064e9._ba34dcbdf335._c4d022a58fa4, _49e4fab064e9._ba34dcbdf335._8d245ddf7002, _39979da782ab(_49e4fab064e9._ba34dcbdf335, "LinearNF4", _22385b47a00c(_80a9167f8e3c))))
            )
        else:
            _cb162b82f696 = lambda _2d399c125b93: (
                _0cb666c5d01a(_2d399c125b93, "weight") and _ace141fb358c(_2d399c125b93._ee722f451b57, _18a43369caea._9f558c4e5250) and _2d399c125b93._ee722f451b57._a1cd99aa81e1() > 64
            )
        _6937beac5840 = _58563f78d084._3e60105f733a
        _91183fb0b40d = _5835f460f364(_6937beac5840, _cb162b82f696=_cb162b82f696, _c40ba5210048=_80a9167f8e3c, _cc68e019c2bc=_80a9167f8e3c)
        _fb706a373f63 = _f0621381956a(
            _d26084ecc096=8,
            _c49eafa45702=32,
            _ea7df6450371=0.1,
            _91183fb0b40d=_98f0d84d9eb3(_91183fb0b40d._b77374afdf6d()) if _91183fb0b40d else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _405482d5dcb7=_7197d068bb13._bf2a4426193e if _fa866b2bdf91 else _7197d068bb13._64d07dd38a2a
        )
        _f0b2c2072221._8ea60af5264d(f"In test Target Module trainable parameters before applying LORA: {_fdefaf53950d(_6937beac5840)}")
        _6937beac5840 = _a69480e67acf(_6937beac5840, _fb706a373f63)
        _f0b2c2072221._8ea60af5264d(f"In test Target Module trainable parameters after applying LORA: {_fdefaf53950d(_6937beac5840)}")

    if _8c874679786b:
        _f0b2c2072221._8ea60af5264d(f"Loading checkpoint from: {_8c874679786b}")
        try:
            _a746485d0982 = _18a43369caea._08c82306d00d(_8c874679786b, _fe786efc2a31=_d05ab7d83157)
            _bffcbeffe57a = _a746485d0982._56c94a0cf9a3("state_dict", _a746485d0982)
            # Strip prefixes
            _8d41a2e7a6e8 = {}
            for _94636c05dadc, _42d12689ea53 in _bffcbeffe57a._7bad04a64cf6():
                _a2994a79c411 = _94636c05dadc
                while _a2994a79c411._ffaa49d2240b('module.'):
                    _a2994a79c411 = _a2994a79c411[7:]
                while _a2994a79c411._ffaa49d2240b('_forward_module.'):
                    _a2994a79c411 = _a2994a79c411[16:]
                _8d41a2e7a6e8[_a2994a79c411] = _42d12689ea53
            # Load with strict=False to handle potential extras
            _58563f78d084._695e6bd758b0(_8d41a2e7a6e8, _88023979806f=_0e818812e0d6)
        except _cdc83e87a063 as _9cbd3caba668:
            _f0b2c2072221._78df41ecac43(f"Checkpoint load failed: {_9cbd3caba668}")
    else:
        _f0b2c2072221._78df41ecac43("No best checkpoint found. Proceeding with in-memory model weights.")

    if _18a43369caea._32854782bdbd._1dc4ede5e2e5():
        _5d033c14f714 = _20696f7f0207(_b948e835d04f())

    if _0b09df91bb64._5bc54f9068b4() is _0e818812e0d6:
        _f0b2c2072221._8ea60af5264d(f"Setting model to {_d05ab7d83157}")
        _58563f78d084 = _58563f78d084._66e7bfc49fa9(_82a1671642f1=_18a43369caea._60a203c90e5c, _c08ee2fb74d0=_d05ab7d83157)

    _86885f17cd57 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383,
        _a2994a79c411="app.model_config_name",
        _82a1671642f1=_4e93e8e4197f,
        _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )
    _711e93aa6f1e = _73f2569f9425(
        _a6fadc572383=_a6fadc572383,
        _a2994a79c411="app.data_dir",
        _82a1671642f1=_4e93e8e4197f,
        _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="data_dir under app specifies the base directory for datasets."
    )

    _0dbb2e1df063 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383,
        _a2994a79c411="dataset.test.data_dir",
        _82a1671642f1=_4e93e8e4197f,
        _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _3e15bfbbf414 = os._483237cbb4ae._1537d848396a(_711e93aa6f1e, _0dbb2e1df063)

    _97b0607a0f4a = _73f2569f9425(
        _a6fadc572383=_a6fadc572383,
        _a2994a79c411="dataset.files_have_header",
        _82a1671642f1=_7c62b9d9f892,
        _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _be502c15e5b4 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383,
        _a2994a79c411="app.random_seed",
        _82a1671642f1=_20696f7f0207,
        _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _ef3098cb0a0c = f"config/{_86885f17cd57}/finetune/classes_config.json"

    _b85cdacb12e3 = _efa9be840fa5(
        _711e93aa6f1e=_3e15bfbbf414,
        _97b0607a0f4a=_97b0607a0f4a,
        _f0b2c2072221=_f0b2c2072221,
        _7b6d5119f18a=_7b6d5119f18a,
        _808bb45d776a=_eae8eba08653,
        _ef3098cb0a0c=_ef3098cb0a0c,
        _d19e430e668f=_0e818812e0d6,
        _fd1fc9acb47a=_492e6844f5a6,
        _8661b800defb=_d2c8652dc95c._6beeb97a6349,
        _fa866b2bdf91=_fa866b2bdf91,
        _230ee383730a=_230ee383730a,
        _be502c15e5b4=_be502c15e5b4,
    )
    _f0b2c2072221._8ea60af5264d(f"Test samples: {_54e4eab46789(_b85cdacb12e3)}, Labels: {_39979da782ab(_b85cdacb12e3, 'actual_num_of_labels', 'NA')}")

    _71db42d76ac8 = [_60cf0cc161de for _, _60cf0cc161de in _58563f78d084._48b4045f52a9() if not _60cf0cc161de._200517b95acb]
    _e8653a2a39b6 = _9803f47676e1(_31556f819087=_71db42d76ac8) if _c9e6ab68f572 == "gpu" else "auto"

    _187ed6745949 = _47ef9836c489(
        _6cce2bae1417=_c9e6ab68f572,
        _29e58fe2cf7b=_29f6aa151d10(_c9e6ab68f572=_c9e6ab68f572),
        _9e9503cd74b7=1,
        _c17f908a7bd9=_e8653a2a39b6 if _c9e6ab68f572 == "gpu" else "auto",
        _a8acccee71a5=1,
        _df5aec41c7ae=_df5aec41c7ae,
        _36db9a00edd5=0,
        _58cb2e8d9805=_0e818812e0d6,
        _b6957b05aadd=_0e818812e0d6,
        _9bfdc88887fc=_492e6844f5a6,
        _c7aa952e34d2=_0e818812e0d6,
    )

    _69f147759fa7 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.batch_size", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Batch size for training"
    )

    _ecde67253906 = _91a1dd54cb3f(
        _b85cdacb12e3=_b85cdacb12e3,
        _65b787127f1d=_69f147759fa7,
        _8661b800defb=_d2c8652dc95c._6beeb97a6349,
        _fa866b2bdf91=_fa866b2bdf91,
        _4cfd2eafa92c=_7b6d5119f18a,
        _be502c15e5b4=_be502c15e5b4,
    )

    _a086742a5bcc = 0.0
    _a17e174230ae = [{}]
    try:
        _a17e174230ae = _187ed6745949._e35643b292fa(_58563f78d084._66e7bfc49fa9(_18a43369caea._60a203c90e5c), _7c5870a87e8d=_ecde67253906)
        _a086742a5bcc = _a17e174230ae[0]._56c94a0cf9a3("test_accuracy", 0.0)
    except _cdc83e87a063 as _9cbd3caba668:
        _f0b2c2072221._f2b3aa1d3100(f"Exception during testing: {_9cbd3caba668}")

    # Log test metrics
    _f90583590cdb = f"metrics/{_86885f17cd57}"
    os._afe9007f250a(_f90583590cdb, _83521a86ae4b=_492e6844f5a6)
    _535147739880 = "test_set_metrics.csv"
    _7b151654a6b8 = os._483237cbb4ae._1537d848396a(_f90583590cdb, _535147739880)
    _1d0a06c700ac = _7ff9d1e4917d.copy()
    _1d0a06c700ac._11fcc250d6d8("pretrained_embedding_model", _80a9167f8e3c)
    _1d0a06c700ac._11fcc250d6d8("tokenizer", _80a9167f8e3c)
    _1d0a06c700ac._11fcc250d6d8("device_dict", _80a9167f8e3c)
    _6e62ac7eb960 = {
        'config': json._7dbc25bd1d9f(_1d0a06c700ac),
        'test_accuracy': _a086742a5bcc,
        'other_metrics': json._7dbc25bd1d9f(_a17e174230ae[0])
    }
    with _8cf74e2588cc(_7b151654a6b8, 'a+', _3bc1274419b5="utf8") as _2e3716e26830:
        _a07216bb10c9 = _bdb2775d6abb._376016fd008d(_2e3716e26830, _0ecd329d14c2=_6e62ac7eb960._b77374afdf6d())
        if os._483237cbb4ae._08f7c65b73c5(_7b151654a6b8) == 0:
            _a07216bb10c9._6b5b9d882118()
        _a07216bb10c9._dcdbf419795d(_6e62ac7eb960)
    _f0b2c2072221._8ea60af5264d(f"Test accuracy: {_a086742a5bcc}")

    try:
        if _0cb666c5d01a(_58563f78d084, 'peft_config') or _ace141fb358c(_58563f78d084, _72e0b217ae42):
            _f0b2c2072221._8ea60af5264d("PEFT/LoRA detected. Merging adapters...")
            try:
                _58563f78d084 = _58563f78d084._a01999dfb579()
                _f0b2c2072221._8ea60af5264d("LoRA adapters merged successfully.")
            except _cdc83e87a063 as _cd3cf7e95a48:
                _f0b2c2072221._78df41ecac43(f"LoRA merge failed: {_cd3cf7e95a48}. Proceeding without merge.")
        else:
            _f0b2c2072221._8ea60af5264d("No PEFT/LoRA detected. Skipping merge.")

        if _22bc2611a585:
            _f0b2c2072221._8ea60af5264d("Dequantizing for CPU save...")
            _58563f78d084 = _58563f78d084._66e7bfc49fa9(_c08ee2fb74d0="cuda" if _18a43369caea._32854782bdbd._1dc4ede5e2e5() else "cpu")
            try:
                _58563f78d084 = _392e3463401f(_58563f78d084)
            except _cdc83e87a063 as _a43fe03dcc89:
                _f0b2c2072221._78df41ecac43(f"dequantize_bnb_model failed, using manual_dequantize: {_a43fe03dcc89}")
                _58563f78d084 = _534b7c0479b0(_58563f78d084)
            _58563f78d084 = _58563f78d084._c7bc2343331c()
            if _18a43369caea._b84988b8d674._11f1c644c15e():
                _18a43369caea._b84988b8d674._405618752339()
            _df04d658b984 = _58563f78d084._66e7bfc49fa9(_82a1671642f1=_18a43369caea._60a203c90e5c, _c08ee2fb74d0="cpu")
            _2ca719d3a5b9 = "saved_models"
            os._afe9007f250a(_2ca719d3a5b9, _83521a86ae4b=_492e6844f5a6)
            _6f99a36d4d2a = os._483237cbb4ae._1537d848396a(_2ca719d3a5b9, "finetuned_model.pt")
            _18a43369caea._dd747eefc367(_df04d658b984._32e4c6619aa9(), _6f99a36d4d2a)
            _f0b2c2072221._8ea60af5264d(f"Saved lightweight checkpoint at {_6f99a36d4d2a}")
    except _cdc83e87a063 as _9cbd3caba668:
        _f0b2c2072221._f2b3aa1d3100(f"Exception during model saving: {_9cbd3caba668}")


def _5300fe0f1a0e(_d2c8652dc95c: _bbdd7a993075._f221f9b7b19a) -> _80a9167f8e3c:
    _bcc21475305f()
    _26542bf428e8 = _7ac01c183962()
    _a6fadc572383 = _26542bf428e8._b26a19616b39(_d2c8652dc95c._0fad0a79b7e9)
    _a5aba7cedbee = _74108b95cbcb()
    _f0b2c2072221 = _a5aba7cedbee._97fd54251999(_a6fadc572383)
    _e32618466cb1 = _0f0d4b8a0f67()
    _39dbf33ecfa4 = _36f87f8a6c5a()

    _be502c15e5b4 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="app.random_seed", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Seed for reproducibility under app.random_seed"
    )
    _1b6eb82c15df.random._e6f1b867771e(_be502c15e5b4)
    random._e6f1b867771e(_be502c15e5b4)
    _123faee15cd5._d76f2bb6413c(_be502c15e5b4, _bbc1f737e656=_492e6844f5a6)
    _18a43369caea._bd92fd7617cf(_be502c15e5b4)
    if _18a43369caea._32854782bdbd._1dc4ede5e2e5():
        _18a43369caea._32854782bdbd._1c8f3479a477(_be502c15e5b4)

    _393abba932a4 = 0
    if _18a43369caea._32854782bdbd._1dc4ede5e2e5():
        _cbefa009f5e1 = _20696f7f0207(os._dd3c1568f5c8._56c94a0cf9a3('RANK', '0'))
        _8ad14f348b6d = _20696f7f0207(os._dd3c1568f5c8._56c94a0cf9a3('WORLD_SIZE', '1'))
        try:
            if not _18a43369caea._b84988b8d674._11f1c644c15e():
                _18a43369caea._b84988b8d674._099e56a0ec5c(
                    _ed7b842c895d=_d2c8652dc95c._ed7b842c895d, _393abba932a4=_cbefa009f5e1, _8ad14f348b6d=_8ad14f348b6d,
                    _2fe09211af10=_8f9c25327ee9(_6396311d277d=600)
                )
        except _cdc83e87a063:
            pass
    if _18a43369caea._b84988b8d674._11f1c644c15e():
        try:
            _393abba932a4 = _18a43369caea._b84988b8d674._e714bd97927a()
        except _cdc83e87a063:
            _393abba932a4 = _39979da782ab(_d2c8652dc95c, "local_rank", 0)

    _86885f17cd57 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="app.model_config_name", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Model config name under app.model_config_name"
    )
    _f90583590cdb = f"metrics/{_86885f17cd57}"
    os._afe9007f250a(_f90583590cdb, _83521a86ae4b=_492e6844f5a6)

    _57be73308c12 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.pretrained_embedding", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _d3e4a0bcd741 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="app.pretrained_embeddings_dir", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _0b4add36d2bf = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.pretrained_embedding_overwrite_old", _82a1671642f1=_7c62b9d9f892, _979057f5b8d0=_0e818812e0d6, _b10600885cfc=_0e818812e0d6,
        _a3395b910fe6="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _22bc2611a585 = _0e818812e0d6
    _ff80f97b8c44 = _80a9167f8e3c
    _fa866b2bdf91 = _0e818812e0d6
    _230ee383730a = _80a9167f8e3c
    if _a642f02c4e9b:
        try:
            _ff80f97b8c44 = _6782ddb1a903(
                _da11d3031340=_492e6844f5a6,
                _cf644ff73e7a=_bc16dec66eea(),
                _c1a7fe6440e2=_492e6844f5a6,
                _af60876205f2="nf4",
            )
            _22bc2611a585 = _492e6844f5a6
        except _cdc83e87a063:
            _ff80f97b8c44 = _80a9167f8e3c

    _b9b19a54ca3a = os._483237cbb4ae._1537d848396a(
        _d3e4a0bcd741,
        _57be73308c12 + ("_quantized" if _a642f02c4e9b else "_fp32")
    )

    _e32618466cb1._63303877fe8b(_b9b19a54ca3a, _9d9e3f7fe1e8=_0b4add36d2bf)
    if _e32618466cb1._9376ff2333e3(_b9b19a54ca3a):
        _f0b2c2072221._8ea60af5264d(f"Downloading pretrained embedding {_57be73308c12}")
        try:
            from _c1e232e8013e import _59f201925a2a, _e1cb4c1300a9
            _438e9631d79d = _59f201925a2a()
            _ddbdc592f2ea = _438e9631d79d._ddbdc592f2ea(_57be73308c12)
            _d14472e12254 = _39979da782ab(_ddbdc592f2ea, "sha", _80a9167f8e3c) or _80a9167f8e3c
            if "llama" in _57be73308c12._2bf3dac6f56d():
                _88969ab1b972 = os._074678588f00("HF_LLAMA3B_TOKEN")
                if _88969ab1b972:
                    _e1cb4c1300a9(token=_88969ab1b972)
                else:
                    raise _b05f6ed198ad("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _cdc83e87a063:
            _d14472e12254 = _80a9167f8e3c
        from _6f0055df2aa5 import _72627a0d5bb6
        _b5bfb5ec638c = _72627a0d5bb6._3da7454aa751(_57be73308c12, _d14472e12254=_d14472e12254)
        _f0b2c2072221._8ea60af5264d(f"config of pretrained embedding used {_b5bfb5ec638c}")
        if "llama" in _57be73308c12._2bf3dac6f56d():
            from _6f0055df2aa5 import _0f784d5808a6, _eb8497504440
            _47671f55f76e = _0f784d5808a6._3da7454aa751(
                _57be73308c12, _d14472e12254=_d14472e12254,
                _d73294edcb77=_ff80f97b8c44 if (_a642f02c4e9b and _ff80f97b8c44) else _80a9167f8e3c
            )
            _7b6d5119f18a = _eb8497504440._3da7454aa751(_57be73308c12, _d14472e12254=_d14472e12254, _5661b13a778c=_0e818812e0d6)
            _fa866b2bdf91 = _492e6844f5a6
            _230ee383730a = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _6f0055df2aa5 import _3b0f2f1be05b, _eb8497504440
            _47671f55f76e = _3b0f2f1be05b._3da7454aa751(_57be73308c12, _d14472e12254=_d14472e12254)
            _7b6d5119f18a = _eb8497504440._3da7454aa751(_57be73308c12, _d14472e12254=_d14472e12254)
            _fa866b2bdf91 = _0e818812e0d6
        try:
            with _8cf74e2588cc(os._483237cbb4ae._1537d848396a(_b9b19a54ca3a, 'revision.txt'), 'w') as _b376c619e098:
                _b376c619e098._73d7eb83db5a(_d14472e12254)
            _47671f55f76e._2600e902b299(_b9b19a54ca3a)
            _7b6d5119f18a._2600e902b299(_b9b19a54ca3a)
        except _cdc83e87a063:
            _f0b2c2072221._78df41ecac43("Saving pretrained embedding locally failed; continuing.")
    else:
        _f0b2c2072221._8ea60af5264d(f"Loading pretrained embedding from {_b9b19a54ca3a}")
        from _6f0055df2aa5 import _72627a0d5bb6
        _b5bfb5ec638c = _72627a0d5bb6._3da7454aa751(_b9b19a54ca3a)
        _f0b2c2072221._8ea60af5264d(f"Config of pretrained embedding used {_b5bfb5ec638c}")
        if "llama" in _57be73308c12._2bf3dac6f56d():
            from _6f0055df2aa5 import _0f784d5808a6, _eb8497504440
            _47671f55f76e = _0f784d5808a6._3da7454aa751(
                _b9b19a54ca3a,
                _d73294edcb77=_ff80f97b8c44 if (_a642f02c4e9b and _ff80f97b8c44) else _80a9167f8e3c
            )
            _7b6d5119f18a = _eb8497504440._3da7454aa751(_b9b19a54ca3a, _5661b13a778c=_0e818812e0d6)
            _fa866b2bdf91 = _492e6844f5a6
            _230ee383730a = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _6f0055df2aa5 import _3b0f2f1be05b, _eb8497504440
            _47671f55f76e = _3b0f2f1be05b._3da7454aa751(_b9b19a54ca3a)
            _7b6d5119f18a = _eb8497504440._3da7454aa751(_b9b19a54ca3a)
            _fa866b2bdf91 = _0e818812e0d6

    _eae8eba08653 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.max_seq_len", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Maximum sequence length for training"
    )
    _69f147759fa7 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.batch_size", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Batch size for training"
    )
    _e7d58e70f1dd = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.data_sample_share", _82a1671642f1=_c7bc2343331c, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Proportion of dataset used for sampling"
    )
    _5d117b10c296 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.optimizer", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Optimizer type under run_config.optimizer"
    )
    _19f2a21f2909 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.learning_rate", _82a1671642f1=_c7bc2343331c, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Learning rate for optimizer"
    )
    _6222bdff81e5 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.num_backbone_model_units_unfrozen", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Number of backbone model units unfrozen during training"
    )
    _5cc57d6b96d0 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.loss_type", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Loss function type under run_config.loss_type"
    )
    _baf60f5f2537 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.num_fc_layers_in_classifier_head", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Number of FC layers in classifier head"
    )
    _3c24bf7006d5 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.activation_function_for_layer", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Activation function for layer under run_config.activation_function_for_layer"
    )
    _0c451260ac5a = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.add_dropout_after_embedding", _82a1671642f1=_7c62b9d9f892, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _4716af07414e = _0e818812e0d6 if _6222bdff81e5 == 0 else _492e6844f5a6

    _7ff9d1e4917d: _a24f2ba43d10[_4e93e8e4197f, _f2e80282a30e] = {
        "device_dict": _81b746f55527(),
        "pretrained_embedding_model": _47671f55f76e,
        "optimizer": _5d117b10c296,
        "num_backbone_model_units_unfrozen": _6222bdff81e5,
        "loss_type": _5cc57d6b96d0,
        "lr": _19f2a21f2909,
        "is_train": _492e6844f5a6,
        "tokenizer": _7b6d5119f18a,
        "random_seed": _be502c15e5b4,
        "num_fc_layers": _baf60f5f2537,
        "activation_function_for_layer": _3c24bf7006d5,
        "add_dropout_after_embedding": _0c451260ac5a,
    }
    _7ff9d1e4917d._a8f332b64b01({"pretrained_model_embedding_name": _57be73308c12})
    if _fa866b2bdf91:
        _7ff9d1e4917d._a8f332b64b01({"prompt_length": _eae8eba08653})

    _711e93aa6f1e = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="app.data_dir", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Base data directory under app.data_dir"
    )
    _206015feac99 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="dataset.train.data_dir", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Subdirectory for training data under dataset.train.data_dir"
    )
    _3f3489cf5650 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="dataset.val.data_dir", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Subdirectory for validation data under dataset.val.data_dir"
    )
    _a8123b41e15e = os._483237cbb4ae._1537d848396a(_711e93aa6f1e, _206015feac99)
    _77699d162778 = os._483237cbb4ae._1537d848396a(_711e93aa6f1e, _3f3489cf5650)
    _97b0607a0f4a = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="dataset.files_have_header", _82a1671642f1=_7c62b9d9f892, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Whether dataset files have header"
    )
    _ef3098cb0a0c = f"config/{_86885f17cd57}/finetune/classes_config.json"
    _e32618466cb1._63303877fe8b(os._483237cbb4ae._cf96184fda18(_ef3098cb0a0c))

    _4c640fd3c0d8 = _efa9be840fa5(
        _711e93aa6f1e=_a8123b41e15e, _97b0607a0f4a=_97b0607a0f4a, _f0b2c2072221=_f0b2c2072221,
        _7b6d5119f18a=_7b6d5119f18a, _808bb45d776a=_eae8eba08653,
        _ef3098cb0a0c=_ef3098cb0a0c, _d19e430e668f=_492e6844f5a6, _fd1fc9acb47a=_0e818812e0d6,
        _be502c15e5b4=_be502c15e5b4, _77497e5ab899=_e7d58e70f1dd,
        _8661b800defb=_d2c8652dc95c._6beeb97a6349, _fa866b2bdf91=_fa866b2bdf91, _230ee383730a=_230ee383730a,
    )
    _5283d98c34ed = _efa9be840fa5(
        _711e93aa6f1e=_77699d162778, _97b0607a0f4a=_97b0607a0f4a, _f0b2c2072221=_f0b2c2072221,
        _7b6d5119f18a=_7b6d5119f18a, _808bb45d776a=_eae8eba08653,
        _ef3098cb0a0c=_ef3098cb0a0c, _d19e430e668f=_0e818812e0d6, _fd1fc9acb47a=_0e818812e0d6,
        _be502c15e5b4=_be502c15e5b4, _77497e5ab899=_e7d58e70f1dd,
        _8661b800defb=_d2c8652dc95c._6beeb97a6349, _fa866b2bdf91=_fa866b2bdf91, _230ee383730a=_230ee383730a,
    )
    _f0b2c2072221._8ea60af5264d(f"Number of training data samples {_4c640fd3c0d8._b183ae840e2e()} with {_39979da782ab(_4c640fd3c0d8, 'label_sample_counter', 'NA')} labels and {_39979da782ab(_4c640fd3c0d8, 'actual_dataset_length', 'NA')} unique samples with {_39979da782ab(_4c640fd3c0d8, 'actual_num_of_labels', 'NA')} unique labels")
    _f0b2c2072221._8ea60af5264d(f"Number of validation data samples {_5283d98c34ed._b183ae840e2e()} with {_39979da782ab(_5283d98c34ed, 'label_sample_counter', 'NA')} labels and {_39979da782ab(_5283d98c34ed, 'actual_dataset_length', 'NA')} unique samples with {_39979da782ab(_5283d98c34ed, 'actual_num_of_labels', 'NA')} unique labels.")

    _1f6187630767 = _4c640fd3c0d8._7f5535ab7164()
    _78ca0a7e9d53 = [_4c640fd3c0d8._515078520852(_ed1eb5fa739b) for _ed1eb5fa739b in _4c640fd3c0d8._66cf9257baa9._b77374afdf6d()]
    _9a284d4fef5e = _4c640fd3c0d8._9a284d4fef5e
    _f14f27107209 = {}
    for _0ad277575568, (_5c397afb71d2, _ee722f451b57) in _602141d0d9b3(_9bf54947dc24(_78ca0a7e9d53, _9a284d4fef5e)):
        _6eaf7bae0eef = _7b6d5119f18a(_5c397afb71d2, _3c2975ac642f=_0e818812e0d6)["input_ids"] if _fa866b2bdf91 else [_0ad277575568]
        if _6eaf7bae0eef:
            _f14f27107209[_5c397afb71d2] = [_6eaf7bae0eef, _ee722f451b57]
    _ea5aca936653(f"Class Weights Generated {_f14f27107209}")
    _f0b2c2072221._8ea60af5264d(f"{_1f6187630767} classes in training data with classes {_78ca0a7e9d53} and weights {_9a284d4fef5e}")
    _7ff9d1e4917d._a8f332b64b01({"class_weights": _f14f27107209, "class_names": _78ca0a7e9d53})

    if "llama" in _57be73308c12 and _fa866b2bdf91:
        _58563f78d084 = _4db8aa6faecb(**_7ff9d1e4917d)
    else:
        _58563f78d084 = _611e52443ec8(**_7ff9d1e4917d)

    _3c5df7ecc559 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383,
        _a2994a79c411="operation_mode",
        _82a1671642f1=_4e93e8e4197f,
        _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _cf313678452d = _80a9167f8e3c
    if _3c5df7ecc559 == "model_finetune":
        _cf313678452d = _73f2569f9425(
            _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.finetuned_model_path", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_0e818812e0d6,
            _a3395b910fe6="Optional path to pretrained model checkpoint for finetuning"
        )
        if _cf313678452d:
            _aa8d6bff6c1a(_58563f78d084, _cf313678452d, _fe786efc2a31="cpu")
            _f0b2c2072221._8ea60af5264d(f"Loaded finetuned model from {_cf313678452d}")

    _71db42d76ac8 = []
    if _4716af07414e:
        if _22bc2611a585:
            _cb162b82f696 = lambda _2d399c125b93: (
                _0cb666c5d01a(_2d399c125b93, "weight") and
                _ace141fb358c(_2d399c125b93._ee722f451b57, _18a43369caea._9f558c4e5250) and
                _2d399c125b93._ee722f451b57._a1cd99aa81e1() > 64 and
                not _ace141fb358c(_2d399c125b93, (_49e4fab064e9._ba34dcbdf335._c4d022a58fa4, _49e4fab064e9._ba34dcbdf335._8d245ddf7002, _49e4fab064e9._ba34dcbdf335._35bc825266ee))
            )
        else:
            _cb162b82f696 = lambda _2d399c125b93: (
                _0cb666c5d01a(_2d399c125b93, "weight") and
                _ace141fb358c(_2d399c125b93._ee722f451b57, _18a43369caea._9f558c4e5250) and
                _2d399c125b93._ee722f451b57._a1cd99aa81e1() > 64
            )
        _6937beac5840 = _58563f78d084._3e60105f733a
        _91183fb0b40d = _5835f460f364(_6937beac5840, _cb162b82f696=_cb162b82f696, _c40ba5210048=_80a9167f8e3c, _cc68e019c2bc=_80a9167f8e3c)
        try:
            _8f27b43bf9a9 = _7197d068bb13._bf2a4426193e if _fa866b2bdf91 else _7197d068bb13._64d07dd38a2a
            _7ce16ef46544 = _1e1ed1db437d(_80a9167f8e3c, _91183fb0b40d, _8f27b43bf9a9)
        except _cdc83e87a063:
            _7ce16ef46544 = _f0621381956a(
                _d26084ecc096=8, _c49eafa45702=32, _ea7df6450371=0.1,
                _91183fb0b40d=_98f0d84d9eb3(_91183fb0b40d._b77374afdf6d()) if _91183fb0b40d else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _405482d5dcb7=_7197d068bb13._bf2a4426193e if _fa866b2bdf91 else _7197d068bb13._64d07dd38a2a
            )
        _f0b2c2072221._8ea60af5264d(f"Target Module trainable parameters before applying LORA is {_fdefaf53950d(_6937beac5840)} and size is {_37f1b2f1e748(_6937beac5840)} GB")
        _6937beac5840 = _a69480e67acf(_6937beac5840, _7ce16ef46544)
        for _a2994a79c411, _4468c6d72f94 in _58563f78d084._48b4045f52a9():
            if not _4468c6d72f94._4d55a3aa3069:
                _4468c6d72f94 = _4468c6d72f94._c3b5dd8312dc()
            if "encoder" in _a2994a79c411 and "lora" not in _a2994a79c411:
                _4468c6d72f94._200517b95acb = _0e818812e0d6
            elif "embedding" in _a2994a79c411:
                _4468c6d72f94._200517b95acb = "lora" in _a2994a79c411
        _f0b2c2072221._8ea60af5264d(f"Target Module trainable parameters after applying LORA is {_fdefaf53950d(_6937beac5840)} and size is {_37f1b2f1e748(_6937beac5840)} GB")

    _5d033c14f714 = _20696f7f0207(_b948e835d04f())
    _c9e6ab68f572 = 'gpu' if _18a43369caea._32854782bdbd._1dc4ede5e2e5() else 'cpu'
    _d05ab7d83157 = f"cuda:{_5d033c14f714}" if _c9e6ab68f572 == 'gpu' else 'cpu'
    if _0b09df91bb64._5bc54f9068b4() is _0e818812e0d6:
        _f0b2c2072221._8ea60af5264d(f"Setting model to {_d05ab7d83157}")
        _58563f78d084 = _58563f78d084._66e7bfc49fa9(_82a1671642f1=_18a43369caea._60a203c90e5c, _c08ee2fb74d0=_d05ab7d83157)

    _58ad01db24d2 = {}
    _58ad01db24d2['model_name'] = _86885f17cd57
    _a8acccee71a5 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="model.max_epochs", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Maximum number of epochs under model.max_epochs"
    )
    _58ad01db24d2['max_epochs'] = _a8acccee71a5
    _7b02e300b720 = _6131979f26c6._b6435b83b22d(_6f41f49972e7=2)
    _90bf29c6d0e9 = "epoch_training_metrics.csv"
    _33115f75b9fa = "model_training_summary_metrics.csv"
    _2ae29b948749 = _96e32965a32e(_f0b2c2072221,
                                       _7b02e300b720=_7b02e300b720,
                                       _58ad01db24d2=_58ad01db24d2,
                                       _c93c4530f93d=_f90583590cdb,
                                       _f4a45b408e28=_90bf29c6d0e9,
                                       _881336ae97f5=_33115f75b9fa,
                                       _ec1349d3031e=_80a9167f8e3c)
    _4c352515c57e = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="app.checkpoints_dir", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _a0db7c31bb25 = os._483237cbb4ae._1537d848396a(_4c352515c57e, _86885f17cd57, "finetune")
    os._afe9007f250a(_a0db7c31bb25, _83521a86ae4b=_492e6844f5a6)
    _df775fd41f1c = _6131979f26c6._d34a65fcd6e4(_72a5b246c2c1=_a0db7c31bb25, _48e0692048a2="intermediate",
        _349e644827c8=1, _02b8304302ae=1000, _5b68e76b7646=_0e818812e0d6)
    _4cf18771d224 = _6131979f26c6._d34a65fcd6e4(_72a5b246c2c1=_a0db7c31bb25, _48e0692048a2="last", _349e644827c8=1,
        _5b68e76b7646=_492e6844f5a6, _f257c5b0cd11="val_loss", _373665bd983b="min")
    _0a0f54fb2210 = _6131979f26c6._72c2c0ef1f32(_f257c5b0cd11="val_accuracy", _6300af7a4fc2=3, _373665bd983b="max", _66bd3a11fb3b=_492e6844f5a6)
    _2a4384b9bf9b = _6131979f26c6._25a634314e82(_cbfd5aabf278='step')

    for _a2994a79c411, _60cf0cc161de in _58563f78d084._48b4045f52a9():
        if not _60cf0cc161de._200517b95acb:
            _71db42d76ac8._3b25ebcec75e(_60cf0cc161de)
    _e8653a2a39b6 = _9803f47676e1(_31556f819087=_71db42d76ac8) if _c9e6ab68f572 == "gpu" else "auto"
    _9e9503cd74b7 = _d2c8652dc95c._9e9503cd74b7

    _ffe92aa38aca = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.accumulate_grad_batches", _82a1671642f1=_20696f7f0207, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _82f7c3c81da5 = _73f2569f9425(
        _a6fadc572383=_a6fadc572383, _a2994a79c411="run_config.training_precision_type", _82a1671642f1=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6,
        _a3395b910fe6="Training precision type under run_config.training_precision_type"
    )
    _8eb4af5877af = _47ef9836c489(
        _6cce2bae1417=_c9e6ab68f572, _29e58fe2cf7b=_29f6aa151d10(_c9e6ab68f572),
        _9e9503cd74b7=_9e9503cd74b7, _c17f908a7bd9=_e8653a2a39b6 if _c9e6ab68f572 == "gpu" else "auto",
        _a8acccee71a5=_a8acccee71a5, _58cb2e8d9805=_0e818812e0d6, _ae02746c8dbf=_492e6844f5a6,
        _9bfdc88887fc=_492e6844f5a6, _c7aa952e34d2=_0e818812e0d6,
        _ffe92aa38aca=_ffe92aa38aca,
        _df5aec41c7ae=_82f7c3c81da5,
        _6131979f26c6=[_2ae29b948749, _df775fd41f1c, _4cf18771d224, _0a0f54fb2210, _2a4384b9bf9b],
    )

    _662abbab6c92 = _91a1dd54cb3f(
        _4c640fd3c0d8=_4c640fd3c0d8, _5283d98c34ed=_5283d98c34ed,
        _4c40df8a36e8=_492e6844f5a6, _4cfd2eafa92c=_7b6d5119f18a,
        _65b787127f1d=_69f147759fa7, _8661b800defb=_d2c8652dc95c._6beeb97a6349,
        _fa866b2bdf91=_fa866b2bdf91, _be502c15e5b4=_be502c15e5b4
    )

    if _5d033c14f714 == 0:
        _6ba4db4b5cb2 = _c3fdb964e8b2(_58563f78d084)
        _f0b2c2072221._8ea60af5264d(f"Model Summary before fit is {_6ba4db4b5cb2}")
        _f0b2c2072221._8ea60af5264d(f"Model structure is {_58563f78d084}")

    _0ad0ce4a280b = os._483237cbb4ae._1537d848396a(_a0db7c31bb25, "intermediate.ckpt")
    if os._483237cbb4ae._ec36fa182450(_0ad0ce4a280b):
        _8eb4af5877af._c6c4fd096beb(_58563f78d084, _7c5870a87e8d=_662abbab6c92, _c494db51be85=_0ad0ce4a280b)
    else:
        _8eb4af5877af._c6c4fd096beb(_58563f78d084, _7c5870a87e8d=_662abbab6c92)

    if _18a43369caea._b84988b8d674._11f1c644c15e():
        _18a43369caea._b84988b8d674._405618752339()
    _50f67b29433c = _4cf18771d224._82692d02c70d
    if _50f67b29433c:
        _f0b2c2072221._8ea60af5264d(f"Best checkpoint saved at {_50f67b29433c}")

    # Run test set
    _0e878d01e282(_d2c8652dc95c, _a6fadc572383, _7ff9d1e4917d, _50f67b29433c, _7b6d5119f18a, _47671f55f76e, _eae8eba08653, _fa866b2bdf91, _230ee383730a, _4716af07414e, _f0b2c2072221, _df5aec41c7ae=_82f7c3c81da5)

    _f0b2c2072221._8ea60af5264d("Finetuning completed successfully.")


def _9263e00ab05d():
    _d28c47782e90 = _bbdd7a993075._bc05cd8f8191(_a1b0675554ed='Fine-tune a language identification model (single run)')
    _d28c47782e90._f2dd27fddb9f('--config_file_path', _22385b47a00c=_4e93e8e4197f, _979057f5b8d0=_492e6844f5a6)
    _d28c47782e90._f2dd27fddb9f('--num_nodes', _22385b47a00c=_20696f7f0207, _b10600885cfc=1)
    _d28c47782e90._f2dd27fddb9f('--cpu_cores', _22385b47a00c=_20696f7f0207, _b10600885cfc=1)
    _d28c47782e90._f2dd27fddb9f('--local-rank', _22385b47a00c=_20696f7f0207)
    _d28c47782e90._f2dd27fddb9f('--backend', _22385b47a00c=_4e93e8e4197f, _b10600885cfc="gloo", _8adfe4974127=['gloo', 'mpi', 'nccl'])
    _d28c47782e90._f2dd27fddb9f('--run_timestamp', _22385b47a00c=_c7bc2343331c, _b10600885cfc=_80a9167f8e3c)
    _d2c8652dc95c = _d28c47782e90._217cef822633()
    if _d2c8652dc95c._d5b47e426737 is _80a9167f8e3c:
        _d2c8652dc95c._d5b47e426737 = time.time()
    _a8c586637c7e(_d2c8652dc95c)


if __name__ == "__main__":
    _bee62d516ea2()