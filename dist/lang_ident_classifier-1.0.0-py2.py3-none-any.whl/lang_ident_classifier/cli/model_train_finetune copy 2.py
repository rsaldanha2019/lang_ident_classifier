# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from _f925b05b45e9 import _e0eb337557d1
from _48026ec9a136 import _1eaadfaa9e56
import _b3b9425754f0, _ebb94c156de5, _ad48ac06766b, _4dda3c25f827, _8e0ef3dc6b0e, _1e25601a93e7, _8eb8f8dad12c, _cdc217d64884, _bf922ab03283
from _70c2d0952e46 import _17e81ba1e434
from _927263d2a361 import _5330e5e6a366, _334f22fb5b9e, _5add1ae52fd5
import _5de7d5bd0f73 as _098c131fb598, _be41f43c0c8f, _7e31c46df7b4 as _5e111b805b1f
from _7e31c46df7b4 import _48c6ed74876b
from _7e31c46df7b4._5ba496e89de2 import _b6292d716c18
from _7e31c46df7b4._5ba496e89de2._56e310a99901._c7c30083e2ab import _2fa05a98d924
from _41d2c0a309e0 import _58926a5f1c6e, _61c0cf0c8fc4, _392ae468e4d8
from _3df5099d73b5._2641e65f4bad._716c6baac783._2c47f4af7f97 import _9ccccb9d55fd
from _3df5099d73b5._2641e65f4bad._716c6baac783._27e5ebc00073 import _fea73ae6cf82
from _3df5099d73b5._2641e65f4bad._716c6baac783._1c651b4c71c8 import _51837be0e00f
from _3df5099d73b5._2641e65f4bad._716c6baac783._01150ec6b30f import _c89fec6f6795
from _3df5099d73b5._2641e65f4bad._59403bd54984._2d7f151b3fe5 import _0321b86f0c6f
from _3df5099d73b5._2641e65f4bad._59403bd54984._d2866514d986 import _4409fac43b10
from _3df5099d73b5._2641e65f4bad._e2a68d7264b5._f29da6b45a51 import _f286de6b4b5b
from _3df5099d73b5._2641e65f4bad._e2a68d7264b5._6e19996ff66e import _5db1cac54565
from _3df5099d73b5._2641e65f4bad._b6292d716c18._2a974474174c import _586692a825d5
from _3df5099d73b5._2641e65f4bad._716c6baac783._452d23649cb6 import _7668d7599549
from _3df5099d73b5._2641e65f4bad._716c6baac783._452d23649cb6 import (
    _465ec3497c71, _1271fa85eefb, _e80818063f1e,
    _c556a1b10dea, _f281803ca6ed, _9b40b24d3eb7,
    _4edb943d9af0, _7bb6bb69d897, _c68a379d8722,
    _001eeee348e8, _b3dcd44d0c9c, _cd83ad37f780,
    _41a5812cd864, _174534ada403
)

_4dda3c25f827._fc93cf4f1531["TOKENIZERS_PARALLELISM"] = "True"
_e42d23b73dd4 = _be41f43c0c8f._0ef28c7964b4._d7496485defb() and _be41f43c0c8f._0ef28c7964b4._3f6c56847793() > 0
if _e42d23b73dd4:
    try:
        from _89076ec8a643 import _138b1f221fa3
        import _6f6684cebf84 as _378226f1fc32
    except _9790ebedf728:
        _378226f1fc32 = _66971439b8f7


def _355d5811f324(_b876fab4785a: _be41f43c0c8f._36fe5912c5d2._d5cd291068fb, _20bd9b13a0b2: _d01a52b0597d, _5081f6154463: _5add1ae52fd5[_d01a52b0597d] = _66971439b8f7) -> _66971439b8f7:
    if not _4dda3c25f827._a7eda47347ba._fa6599e09fb1(_20bd9b13a0b2):
        raise _2f5dc7cb73c4(f"Finetuned model path not found: {_20bd9b13a0b2}")
    if _20bd9b13a0b2._0e9f6a08c885((".pt", ".pth")):
        _3902d81e186e = _5081f6154463 or ("cpu" if not _be41f43c0c8f._0ef28c7964b4._d7496485defb() else _66971439b8f7)
        _01da23c7b146 = _be41f43c0c8f._6bc1b1920934(_20bd9b13a0b2, _5081f6154463=_3902d81e186e)
        _121d5e5cabc5 = _01da23c7b146._d8311765a4c0("state_dict", _01da23c7b146._d8311765a4c0("model_state_dict", _01da23c7b146)) if _2f7415be3186(_01da23c7b146, _97cc74d5a5ab) else _01da23c7b146
        if not _2f7415be3186(_121d5e5cabc5, _97cc74d5a5ab):
            raise _f92f46a4cc3d(f"Loaded .pt file does not contain state_dict mapping: {_20bd9b13a0b2}")
        _b876fab4785a._b08413d6b125(_121d5e5cabc5, _027ee8761c3b=_4ea6019e52ba)
    elif _20bd9b13a0b2._0e9f6a08c885(".ckpt"):
        try:
            if _53c5cf33e454(_b876fab4785a._a23006df78f2, "load_from_checkpoint"):
                _1623d52298e7 = _b876fab4785a._a23006df78f2._4155e4def0b3(_20bd9b13a0b2, **{})
                _b876fab4785a._b08413d6b125(_1623d52298e7._58230910aa69(), _027ee8761c3b=_4ea6019e52ba)
                return
            _01da23c7b146 = _be41f43c0c8f._6bc1b1920934(_20bd9b13a0b2, _5081f6154463="cpu")
            _121d5e5cabc5 = _01da23c7b146._d8311765a4c0("state_dict", _01da23c7b146)
            if not _2f7415be3186(_121d5e5cabc5, _97cc74d5a5ab):
                raise _f92f46a4cc3d("Lightning checkpoint did not contain a recognizable state_dict.")
            _b876fab4785a._b08413d6b125(_121d5e5cabc5, _027ee8761c3b=_4ea6019e52ba)
        except _9790ebedf728 as _b53ac04b6278:
            raise _f92f46a4cc3d(f"Failed to load .ckpt into model: {_b53ac04b6278}") from _b53ac04b6278
    else:
        raise _3b42d3a4a3a4("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _8158796d4796(_e2b1d39e0454: _b3b9425754f0._775fdc7d3c44, _263893ffcc62: _5330e5e6a366, _833bec9fcde5: _334f22fb5b9e[_d01a52b0597d, _5330e5e6a366], _a16c2d7d78ab: _d01a52b0597d, _550eccd7f90f: _5330e5e6a366, _19279f229d0f: _5330e5e6a366, _4167e5ba3409: _66a306bb8464, _a2b1a2132c39: _966c9aed49b4, _d07d7db36eda: _5330e5e6a366, _a230d1a4ef76: _966c9aed49b4, _552891376f9d: _1eaadfaa9e56, _563d1732f1b4: _d01a52b0597d = "32"):
    """
    Compute test accuracy using the best checkpoint.
    """
    _9d9f1c2aee01 = _4ea6019e52ba
    if _e42d23b73dd4:
        _225b7fdaaff3 = _138b1f221fa3(
            _6ecd7d4094ea=_38862797c7bf,
            _bbf2fa33e936=_e80818063f1e(),
            _0be6a80d8ec1=_38862797c7bf,
            _4cb7f9aa81cb="nf4",
        )
        _9d9f1c2aee01 = _38862797c7bf

    _08cc6fefa06f = 'gpu' if _be41f43c0c8f._0ef28c7964b4._d7496485defb() else 'cpu'
    _5d2c46ad95ba = 'cpu'
    if _08cc6fefa06f == 'gpu':
        _3166ad8791a1 = _be41f43c0c8f._10e05cf294e8._c3b6daac92f2() if _be41f43c0c8f._10e05cf294e8._2cebc32d517e() else 0
        _5d2c46ad95ba = f"cuda:{_3166ad8791a1}"
    else:
        _3166ad8791a1 = -1

    _3a39c32263e7 = _833bec9fcde5._d8311765a4c0("pretrained_model_embedding_name")

    _833bec9fcde5._25e4d9c59bb8({
        "tokenizer": _550eccd7f90f,
        "pretrained_embedding_model": _19279f229d0f,
        "device_dict": _1271fa85eefb(),
    })

    if not _a16c2d7d78ab:
        _552891376f9d._6cf335471275("No best checkpoint found. Proceeding with current model weights.")
    else:
        _552891376f9d._6cf335471275(f"Testing with best checkpoint: {_a16c2d7d78ab}")

    if "llama" in (_3a39c32263e7 or ""):
        _b876fab4785a = _5db1cac54565(**_833bec9fcde5)
        _a2b1a2132c39 = _38862797c7bf
    else:
        _b876fab4785a = _f286de6b4b5b(**_833bec9fcde5)

    if _a230d1a4ef76:
        if _9d9f1c2aee01:
            _a7bde5592344 = lambda _91d489d16db3: (
                _53c5cf33e454(_91d489d16db3, "weight") and _2f7415be3186(_91d489d16db3._094413070e7c, _be41f43c0c8f._0ebebb338eb0) and _91d489d16db3._094413070e7c._1ba498087cbc() > 64 and
                not _2f7415be3186(_91d489d16db3, (_378226f1fc32._36fe5912c5d2._4fd80cf9ddbb, _378226f1fc32._36fe5912c5d2._d08ef6858820, _12552c995fd3(_378226f1fc32._36fe5912c5d2, "LinearNF4", _982d6d1001cc(_66971439b8f7))))
            )
        else:
            _a7bde5592344 = lambda _91d489d16db3: (
                _53c5cf33e454(_91d489d16db3, "weight") and _2f7415be3186(_91d489d16db3._094413070e7c, _be41f43c0c8f._0ebebb338eb0) and _91d489d16db3._094413070e7c._1ba498087cbc() > 64
            )
        _f91d81a7ec81 = _b876fab4785a._9f059bcbb077
        _a1a8ac0e6a3d = _c556a1b10dea(_f91d81a7ec81, _a7bde5592344=_a7bde5592344, _8cb0b8fc02a0=_66971439b8f7, _3060b4e8cb73=_66971439b8f7)
        _668799c7ec19 = _61c0cf0c8fc4(
            _c92c562bb9c6=8,
            _aa65718bcabe=32,
            _c3a4ffb73e38=0.1,
            _a1a8ac0e6a3d=_fc4094acf375(_a1a8ac0e6a3d._c9885c3aab67()) if _a1a8ac0e6a3d else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _8766483df83b=_58926a5f1c6e._c3b8310138bc if _a2b1a2132c39 else _58926a5f1c6e._0695c11f86e5
        )
        _552891376f9d._6cf335471275(f"In test Target Module trainable parameters before applying LORA: {_f281803ca6ed(_f91d81a7ec81)}")
        _f91d81a7ec81 = _9b40b24d3eb7(_f91d81a7ec81, _668799c7ec19)
        _552891376f9d._6cf335471275(f"In test Target Module trainable parameters after applying LORA: {_f281803ca6ed(_f91d81a7ec81)}")

    if _a16c2d7d78ab:
        _552891376f9d._6cf335471275(f"Loading checkpoint from: {_a16c2d7d78ab}")
        try:
            _01da23c7b146 = _be41f43c0c8f._6bc1b1920934(_a16c2d7d78ab, _5081f6154463=_5d2c46ad95ba)
            _121d5e5cabc5 = _01da23c7b146._d8311765a4c0("state_dict", _01da23c7b146)
            # Strip prefixes
            _aa32670f700a = {}
            for _44f0ac02bd1d, _aa75f5d45fd3 in _121d5e5cabc5._df335ed9ff8d():
                _deabb6a0e319 = _44f0ac02bd1d
                while _deabb6a0e319._524477e39445('module.'):
                    _deabb6a0e319 = _deabb6a0e319[7:]
                while _deabb6a0e319._524477e39445('_forward_module.'):
                    _deabb6a0e319 = _deabb6a0e319[16:]
                _aa32670f700a[_deabb6a0e319] = _aa75f5d45fd3
            # Load with strict=False to handle potential extras
            _b876fab4785a._b08413d6b125(_aa32670f700a, _027ee8761c3b=_4ea6019e52ba)
        except _9790ebedf728 as _b53ac04b6278:
            _552891376f9d._7d7e239d38b7(f"Checkpoint load failed: {_b53ac04b6278}")
    else:
        _552891376f9d._7d7e239d38b7("No best checkpoint found. Proceeding with in-memory model weights.")

    if _be41f43c0c8f._0ef28c7964b4._d7496485defb():
        _3166ad8791a1 = _66a306bb8464(_465ec3497c71())

    if _2fa05a98d924._3c6fe53c3575() is _4ea6019e52ba:
        _552891376f9d._6cf335471275(f"Setting model to {_5d2c46ad95ba}")
        _b876fab4785a = _b876fab4785a._902b99532bdc(_0ee45ba4cbd0=_be41f43c0c8f._b062ccff4984, _625268a99d40=_5d2c46ad95ba)

    _68e0ec6eb692 = _174534ada403(
        _263893ffcc62=_263893ffcc62,
        _deabb6a0e319="app.model_config_name",
        _0ee45ba4cbd0=_d01a52b0597d,
        _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )
    _626757f81c0b = _174534ada403(
        _263893ffcc62=_263893ffcc62,
        _deabb6a0e319="app.data_dir",
        _0ee45ba4cbd0=_d01a52b0597d,
        _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="data_dir under app specifies the base directory for datasets."
    )

    _4de0a550f7fd = _174534ada403(
        _263893ffcc62=_263893ffcc62,
        _deabb6a0e319="dataset.test.data_dir",
        _0ee45ba4cbd0=_d01a52b0597d,
        _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _ba15c05dae99 = _4dda3c25f827._a7eda47347ba._49613dfb13db(_626757f81c0b, _4de0a550f7fd)

    _fb8bc46636c4 = _174534ada403(
        _263893ffcc62=_263893ffcc62,
        _deabb6a0e319="dataset.files_have_header",
        _0ee45ba4cbd0=_966c9aed49b4,
        _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _0f9b507bbbe9 = _174534ada403(
        _263893ffcc62=_263893ffcc62,
        _deabb6a0e319="app.random_seed",
        _0ee45ba4cbd0=_66a306bb8464,
        _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _d9ca6ca242ed = f"config/{_68e0ec6eb692}/finetune/classes_config.json"

    _eddedfccc307 = _0321b86f0c6f(
        _626757f81c0b=_ba15c05dae99,
        _fb8bc46636c4=_fb8bc46636c4,
        _552891376f9d=_552891376f9d,
        _550eccd7f90f=_550eccd7f90f,
        _f33179c8f3e1=_4167e5ba3409,
        _d9ca6ca242ed=_d9ca6ca242ed,
        _beba459ba250=_4ea6019e52ba,
        _293effb40124=_38862797c7bf,
        _69e60b30ba59=_e2b1d39e0454._2ea7e6e36040,
        _a2b1a2132c39=_a2b1a2132c39,
        _d07d7db36eda=_d07d7db36eda,
        _0f9b507bbbe9=_0f9b507bbbe9,
    )
    _552891376f9d._6cf335471275(f"Test samples: {_ca9810353f5d(_eddedfccc307)}, Labels: {_12552c995fd3(_eddedfccc307, 'actual_num_of_labels', 'NA')}")

    _30d3b8f6a3c7 = [_1b5caf82cebe for _, _1b5caf82cebe in _b876fab4785a._3354cbd39553() if not _1b5caf82cebe._df195fd54343]
    _6d8dd18c8ce1 = _41a5812cd864(_ea7eb8b3ea0e=_30d3b8f6a3c7) if _08cc6fefa06f == "gpu" else "auto"

    _34f685e85a39 = _48c6ed74876b(
        _a7a2f417f0f7=_08cc6fefa06f,
        _521530747818=_7bb6bb69d897(_08cc6fefa06f=_08cc6fefa06f),
        _d5be4768e360=1,
        _c3dd22603901=_6d8dd18c8ce1 if _08cc6fefa06f == "gpu" else "auto",
        _b407408ead7f=1,
        _563d1732f1b4=_563d1732f1b4,
        _a6f293811d78=0,
        _bd0c9f5593a2=_4ea6019e52ba,
        _633a3d0067dd=_4ea6019e52ba,
        _a8406a8257ae=_38862797c7bf,
        _25c14d9c49d2=_4ea6019e52ba,
    )

    _14dbe90df864 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.batch_size", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Batch size for training"
    )

    _1319cce4ed8e = _4409fac43b10(
        _eddedfccc307=_eddedfccc307,
        _972a7b5ee40b=_14dbe90df864,
        _69e60b30ba59=_e2b1d39e0454._2ea7e6e36040,
        _a2b1a2132c39=_a2b1a2132c39,
        _96ebde491c40=_550eccd7f90f,
        _0f9b507bbbe9=_0f9b507bbbe9,
    )

    _3e097722d003 = 0.0
    _c592d05be72c = [{}]
    try:
        _c592d05be72c = _34f685e85a39._443689f7e3bf(_b876fab4785a._902b99532bdc(_be41f43c0c8f._b062ccff4984), _09dc550a6460=_1319cce4ed8e)
        _3e097722d003 = _c592d05be72c[0]._d8311765a4c0("test_accuracy", 0.0)
    except _9790ebedf728 as _b53ac04b6278:
        _552891376f9d._f94aa1c5b536(f"Exception during testing: {_b53ac04b6278}")

    # Log test metrics
    _d6b79e8dff29 = f"metrics/{_68e0ec6eb692}"
    _4dda3c25f827._b95f2d16e72f(_d6b79e8dff29, _afbdd29315d7=_38862797c7bf)
    _7b4610fcfe71 = "test_set_metrics.csv"
    _25103714467a = _4dda3c25f827._a7eda47347ba._49613dfb13db(_d6b79e8dff29, _7b4610fcfe71)
    _dfd2045a9e12 = _833bec9fcde5._e1deb4b8e521()
    _dfd2045a9e12._50dcccab2dfb("pretrained_embedding_model", _66971439b8f7)
    _dfd2045a9e12._50dcccab2dfb("tokenizer", _66971439b8f7)
    _dfd2045a9e12._50dcccab2dfb("device_dict", _66971439b8f7)
    _d22841b4c339 = {
        'config': _ad48ac06766b._e346588ec179(_dfd2045a9e12),
        'test_accuracy': _3e097722d003,
        'other_metrics': _ad48ac06766b._e346588ec179(_c592d05be72c[0])
    }
    with _8ac5098d9788(_25103714467a, 'a+', _ae8bab3c1025="utf8") as _59b0c22dca7b:
        _bcfc026b9eee = _ebb94c156de5._9dd4b2eaa166(_59b0c22dca7b, _c0885550a955=_d22841b4c339._c9885c3aab67())
        if _4dda3c25f827._a7eda47347ba._0ecd3709b217(_25103714467a) == 0:
            _bcfc026b9eee._c1c3142f3e98()
        _bcfc026b9eee._f365fb60bfac(_d22841b4c339)
    _552891376f9d._6cf335471275(f"Test accuracy: {_3e097722d003}")

    try:
        if _53c5cf33e454(_b876fab4785a, 'peft_config') or _2f7415be3186(_b876fab4785a, _392ae468e4d8):
            _552891376f9d._6cf335471275("PEFT/LoRA detected. Merging adapters...")
            try:
                _b876fab4785a = _b876fab4785a._814f09dbd655()
                _552891376f9d._6cf335471275("LoRA adapters merged successfully.")
            except _9790ebedf728 as _3be73a225f5a:
                _552891376f9d._7d7e239d38b7(f"LoRA merge failed: {_3be73a225f5a}. Proceeding without merge.")
        else:
            _552891376f9d._6cf335471275("No PEFT/LoRA detected. Skipping merge.")

        if _9d9f1c2aee01:
            _552891376f9d._6cf335471275("Dequantizing for CPU save...")
            _b876fab4785a = _b876fab4785a._902b99532bdc(_625268a99d40="cuda" if _be41f43c0c8f._0ef28c7964b4._d7496485defb() else "cpu")
            try:
                _b876fab4785a = _b3dcd44d0c9c(_b876fab4785a)
            except _9790ebedf728 as _09ab0a69e4fc:
                _552891376f9d._7d7e239d38b7(f"dequantize_bnb_model failed, using manual_dequantize: {_09ab0a69e4fc}")
                _b876fab4785a = _001eeee348e8(_b876fab4785a)
            _b876fab4785a = _b876fab4785a._e3a5072de527()
            if _be41f43c0c8f._10e05cf294e8._2cebc32d517e():
                _be41f43c0c8f._10e05cf294e8._67e340c1f1d7()
            _eef1fd104df6 = _b876fab4785a._902b99532bdc(_0ee45ba4cbd0=_be41f43c0c8f._b062ccff4984, _625268a99d40="cpu")
            _68d2360ff28d = "saved_models"
            _4dda3c25f827._b95f2d16e72f(_68d2360ff28d, _afbdd29315d7=_38862797c7bf)
            _03a24d5861fc = _4dda3c25f827._a7eda47347ba._49613dfb13db(_68d2360ff28d, "finetuned_model.pt")
            _be41f43c0c8f._a10cd263f9d1(_eef1fd104df6._58230910aa69(), _03a24d5861fc)
            _552891376f9d._6cf335471275(f"Saved lightweight checkpoint at {_03a24d5861fc}")
    except _9790ebedf728 as _b53ac04b6278:
        _552891376f9d._f94aa1c5b536(f"Exception during model saving: {_b53ac04b6278}")


def _df60b02c2e98(_e2b1d39e0454: _b3b9425754f0._775fdc7d3c44) -> _66971439b8f7:
    _c68a379d8722()
    _278c4cf9b323 = _9ccccb9d55fd()
    _263893ffcc62 = _278c4cf9b323._f93e2ccc7de7(_e2b1d39e0454._0825f1ff88d4)
    _1e71d8006f57 = _fea73ae6cf82()
    _552891376f9d = _1e71d8006f57._d707d6988f4b(_263893ffcc62)
    _0353738707d3 = _51837be0e00f()
    _1fbf1629b500 = _c89fec6f6795()

    _0f9b507bbbe9 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="app.random_seed", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Seed for reproducibility under app.random_seed"
    )
    _098c131fb598._8e0ef3dc6b0e._ebf359bec78d(_0f9b507bbbe9)
    _8e0ef3dc6b0e._ebf359bec78d(_0f9b507bbbe9)
    _5e111b805b1f._7222bc4740d1(_0f9b507bbbe9, _0f7d9ce2d8ac=_38862797c7bf)
    _be41f43c0c8f._878a257a2c69(_0f9b507bbbe9)
    if _be41f43c0c8f._0ef28c7964b4._d7496485defb():
        _be41f43c0c8f._0ef28c7964b4._afc19f0ddae0(_0f9b507bbbe9)

    _4d90813eaad7 = 0
    if _be41f43c0c8f._0ef28c7964b4._d7496485defb():
        _fa854bf4a7a5 = _66a306bb8464(_4dda3c25f827._fc93cf4f1531._d8311765a4c0('RANK', '0'))
        _02d913f69dab = _66a306bb8464(_4dda3c25f827._fc93cf4f1531._d8311765a4c0('WORLD_SIZE', '1'))
        try:
            if not _be41f43c0c8f._10e05cf294e8._2cebc32d517e():
                _be41f43c0c8f._10e05cf294e8._16176f64ac9c(
                    _7162daacac45=_e2b1d39e0454._7162daacac45, _4d90813eaad7=_fa854bf4a7a5, _02d913f69dab=_02d913f69dab,
                    _7e761a5aa0fd=_17e81ba1e434(_48c1db31ffbb=600)
                )
        except _9790ebedf728:
            pass
    if _be41f43c0c8f._10e05cf294e8._2cebc32d517e():
        try:
            _4d90813eaad7 = _be41f43c0c8f._10e05cf294e8._c3b6daac92f2()
        except _9790ebedf728:
            _4d90813eaad7 = _12552c995fd3(_e2b1d39e0454, "local_rank", 0)

    _68e0ec6eb692 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="app.model_config_name", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Model config name under app.model_config_name"
    )
    _d6b79e8dff29 = f"metrics/{_68e0ec6eb692}"
    _4dda3c25f827._b95f2d16e72f(_d6b79e8dff29, _afbdd29315d7=_38862797c7bf)

    _3a39c32263e7 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.pretrained_embedding", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _de7642510d32 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="app.pretrained_embeddings_dir", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _0b5fa0436a29 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.pretrained_embedding_overwrite_old", _0ee45ba4cbd0=_966c9aed49b4, _47b62c512c1a=_4ea6019e52ba, _6ae135728541=_4ea6019e52ba,
        _1c02ce522bdb="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _9d9f1c2aee01 = _4ea6019e52ba
    _225b7fdaaff3 = _66971439b8f7
    _a2b1a2132c39 = _4ea6019e52ba
    _d07d7db36eda = _66971439b8f7
    if _e42d23b73dd4:
        try:
            _225b7fdaaff3 = _138b1f221fa3(
                _6ecd7d4094ea=_38862797c7bf,
                _bbf2fa33e936=_e80818063f1e(),
                _0be6a80d8ec1=_38862797c7bf,
                _4cb7f9aa81cb="nf4",
            )
            _9d9f1c2aee01 = _38862797c7bf
        except _9790ebedf728:
            _225b7fdaaff3 = _66971439b8f7

    _d58e2094b87b = _4dda3c25f827._a7eda47347ba._49613dfb13db(
        _de7642510d32,
        _3a39c32263e7 + ("_quantized" if _e42d23b73dd4 else "_fp32")
    )

    _0353738707d3._088d526212b0(_d58e2094b87b, _a8e87d0a82b0=_0b5fa0436a29)
    if _0353738707d3._c775a2a4d05a(_d58e2094b87b):
        _552891376f9d._6cf335471275(f"Downloading pretrained embedding {_3a39c32263e7}")
        try:
            from _f53dcbf6d6dd import _c698bcd85a98, _e122ccd56f7a
            _9860bf9886ae = _c698bcd85a98()
            _d3f5fbb7c35f = _9860bf9886ae._d3f5fbb7c35f(_3a39c32263e7)
            _6450a2a6bfb3 = _12552c995fd3(_d3f5fbb7c35f, "sha", _66971439b8f7) or _66971439b8f7
            if "llama" in _3a39c32263e7._51fe6341e496():
                _40534ab6e2b4 = _4dda3c25f827._38bcdcc4246f("HF_LLAMA3B_TOKEN")
                if _40534ab6e2b4:
                    _e122ccd56f7a(_6d641a7cb986=_40534ab6e2b4)
                else:
                    raise _f92f46a4cc3d("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _9790ebedf728:
            _6450a2a6bfb3 = _66971439b8f7
        from _89076ec8a643 import _329160087e11
        _43cc0b5c3d56 = _329160087e11._90969c361256(_3a39c32263e7, _6450a2a6bfb3=_6450a2a6bfb3)
        _552891376f9d._6cf335471275(f"config of pretrained embedding used {_43cc0b5c3d56}")
        if "llama" in _3a39c32263e7._51fe6341e496():
            from _89076ec8a643 import _78e374642d53, _3670ab861629
            _19279f229d0f = _78e374642d53._90969c361256(
                _3a39c32263e7, _6450a2a6bfb3=_6450a2a6bfb3,
                _736dbd6e880f=_225b7fdaaff3 if (_e42d23b73dd4 and _225b7fdaaff3) else _66971439b8f7
            )
            _550eccd7f90f = _3670ab861629._90969c361256(_3a39c32263e7, _6450a2a6bfb3=_6450a2a6bfb3, _4571d76d88f4=_4ea6019e52ba)
            _a2b1a2132c39 = _38862797c7bf
            _d07d7db36eda = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _89076ec8a643 import _c8f3898e2bc6, _3670ab861629
            _19279f229d0f = _c8f3898e2bc6._90969c361256(_3a39c32263e7, _6450a2a6bfb3=_6450a2a6bfb3)
            _550eccd7f90f = _3670ab861629._90969c361256(_3a39c32263e7, _6450a2a6bfb3=_6450a2a6bfb3)
            _a2b1a2132c39 = _4ea6019e52ba
        try:
            with _8ac5098d9788(_4dda3c25f827._a7eda47347ba._49613dfb13db(_d58e2094b87b, 'revision.txt'), 'w') as _d3c92fabf133:
                _d3c92fabf133._88a6b333e7ab(_6450a2a6bfb3)
            _19279f229d0f._4cc0279b3fa5(_d58e2094b87b)
            _550eccd7f90f._4cc0279b3fa5(_d58e2094b87b)
        except _9790ebedf728:
            _552891376f9d._7d7e239d38b7("Saving pretrained embedding locally failed; continuing.")
    else:
        _552891376f9d._6cf335471275(f"Loading pretrained embedding from {_d58e2094b87b}")
        from _89076ec8a643 import _329160087e11
        _43cc0b5c3d56 = _329160087e11._90969c361256(_d58e2094b87b)
        _552891376f9d._6cf335471275(f"Config of pretrained embedding used {_43cc0b5c3d56}")
        if "llama" in _3a39c32263e7._51fe6341e496():
            from _89076ec8a643 import _78e374642d53, _3670ab861629
            _19279f229d0f = _78e374642d53._90969c361256(
                _d58e2094b87b,
                _736dbd6e880f=_225b7fdaaff3 if (_e42d23b73dd4 and _225b7fdaaff3) else _66971439b8f7
            )
            _550eccd7f90f = _3670ab861629._90969c361256(_d58e2094b87b, _4571d76d88f4=_4ea6019e52ba)
            _a2b1a2132c39 = _38862797c7bf
            _d07d7db36eda = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _89076ec8a643 import _c8f3898e2bc6, _3670ab861629
            _19279f229d0f = _c8f3898e2bc6._90969c361256(_d58e2094b87b)
            _550eccd7f90f = _3670ab861629._90969c361256(_d58e2094b87b)
            _a2b1a2132c39 = _4ea6019e52ba

    _4167e5ba3409 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.max_seq_len", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Maximum sequence length for training"
    )
    _14dbe90df864 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.batch_size", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Batch size for training"
    )
    _66966e08a9cd = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.data_sample_share", _0ee45ba4cbd0=_e3a5072de527, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Proportion of dataset used for sampling"
    )
    _a61949a25678 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.optimizer", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Optimizer type under run_config.optimizer"
    )
    _4167bfd1ad6a = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.learning_rate", _0ee45ba4cbd0=_e3a5072de527, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Learning rate for optimizer"
    )
    _c488db72d1c5 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.num_backbone_model_units_unfrozen", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Number of backbone model units unfrozen during training"
    )
    _b8a2397f5214 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.loss_type", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Loss function type under run_config.loss_type"
    )
    _e7e39b345add = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.num_fc_layers_in_classifier_head", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Number of FC layers in classifier head"
    )
    _2b39b91b4a4d = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.activation_function_for_layer", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Activation function for layer under run_config.activation_function_for_layer"
    )
    _a2fb59fe688b = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.add_dropout_after_embedding", _0ee45ba4cbd0=_966c9aed49b4, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _a230d1a4ef76 = _4ea6019e52ba if _c488db72d1c5 == 0 else _38862797c7bf

    _833bec9fcde5: _334f22fb5b9e[_d01a52b0597d, _5330e5e6a366] = {
        "device_dict": _1271fa85eefb(),
        "pretrained_embedding_model": _19279f229d0f,
        "optimizer": _a61949a25678,
        "num_backbone_model_units_unfrozen": _c488db72d1c5,
        "loss_type": _b8a2397f5214,
        "lr": _4167bfd1ad6a,
        "is_train": _38862797c7bf,
        "tokenizer": _550eccd7f90f,
        "random_seed": _0f9b507bbbe9,
        "num_fc_layers": _e7e39b345add,
        "activation_function_for_layer": _2b39b91b4a4d,
        "add_dropout_after_embedding": _a2fb59fe688b,
    }
    _833bec9fcde5._25e4d9c59bb8({"pretrained_model_embedding_name": _3a39c32263e7})
    if _a2b1a2132c39:
        _833bec9fcde5._25e4d9c59bb8({"prompt_length": _4167e5ba3409})

    _626757f81c0b = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="app.data_dir", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Base data directory under app.data_dir"
    )
    _067ec5b78f04 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="dataset.train.data_dir", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Subdirectory for training data under dataset.train.data_dir"
    )
    _933583537347 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="dataset.val.data_dir", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Subdirectory for validation data under dataset.val.data_dir"
    )
    _fde747c048eb = _4dda3c25f827._a7eda47347ba._49613dfb13db(_626757f81c0b, _067ec5b78f04)
    _e5c30b8190a3 = _4dda3c25f827._a7eda47347ba._49613dfb13db(_626757f81c0b, _933583537347)
    _fb8bc46636c4 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="dataset.files_have_header", _0ee45ba4cbd0=_966c9aed49b4, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Whether dataset files have header"
    )
    _d9ca6ca242ed = f"config/{_68e0ec6eb692}/finetune/classes_config.json"
    _0353738707d3._088d526212b0(_4dda3c25f827._a7eda47347ba._64dfd7261c55(_d9ca6ca242ed))

    _230df627f58a = _0321b86f0c6f(
        _626757f81c0b=_fde747c048eb, _fb8bc46636c4=_fb8bc46636c4, _552891376f9d=_552891376f9d,
        _550eccd7f90f=_550eccd7f90f, _f33179c8f3e1=_4167e5ba3409,
        _d9ca6ca242ed=_d9ca6ca242ed, _beba459ba250=_38862797c7bf, _293effb40124=_4ea6019e52ba,
        _0f9b507bbbe9=_0f9b507bbbe9, _2bc3498c99d4=_66966e08a9cd,
        _69e60b30ba59=_e2b1d39e0454._2ea7e6e36040, _a2b1a2132c39=_a2b1a2132c39, _d07d7db36eda=_d07d7db36eda,
    )
    _891adc22c2ce = _0321b86f0c6f(
        _626757f81c0b=_e5c30b8190a3, _fb8bc46636c4=_fb8bc46636c4, _552891376f9d=_552891376f9d,
        _550eccd7f90f=_550eccd7f90f, _f33179c8f3e1=_4167e5ba3409,
        _d9ca6ca242ed=_d9ca6ca242ed, _beba459ba250=_4ea6019e52ba, _293effb40124=_4ea6019e52ba,
        _0f9b507bbbe9=_0f9b507bbbe9, _2bc3498c99d4=_66966e08a9cd,
        _69e60b30ba59=_e2b1d39e0454._2ea7e6e36040, _a2b1a2132c39=_a2b1a2132c39, _d07d7db36eda=_d07d7db36eda,
    )
    _552891376f9d._6cf335471275(f"Number of training data samples {_230df627f58a._32519c94541a()} with {_12552c995fd3(_230df627f58a, 'label_sample_counter', 'NA')} labels and {_12552c995fd3(_230df627f58a, 'actual_dataset_length', 'NA')} unique samples with {_12552c995fd3(_230df627f58a, 'actual_num_of_labels', 'NA')} unique labels")
    _552891376f9d._6cf335471275(f"Number of validation data samples {_891adc22c2ce._32519c94541a()} with {_12552c995fd3(_891adc22c2ce, 'label_sample_counter', 'NA')} labels and {_12552c995fd3(_891adc22c2ce, 'actual_dataset_length', 'NA')} unique samples with {_12552c995fd3(_891adc22c2ce, 'actual_num_of_labels', 'NA')} unique labels.")

    _995d3084dffc = _230df627f58a._88841b4da93f()
    _7a874d6adadf = [_230df627f58a._8ea70c3bc0d7(_8c5b1b487f1c) for _8c5b1b487f1c in _230df627f58a._f91b5ffc99b0._c9885c3aab67()]
    _0a71167a6ac9 = _230df627f58a._0a71167a6ac9
    _6ca5bf27144f = {}
    for _c910c1c91047, (_3ee6904ada88, _094413070e7c) in _71486aa3a436(_5ad035481f2b(_7a874d6adadf, _0a71167a6ac9)):
        _18c0fb152200 = _550eccd7f90f(_3ee6904ada88, _b96c22f990a3=_4ea6019e52ba)["input_ids"] if _a2b1a2132c39 else [_c910c1c91047]
        if _18c0fb152200:
            _6ca5bf27144f[_3ee6904ada88] = [_18c0fb152200, _094413070e7c]
    _524f75633e06(f"Class Weights Generated {_6ca5bf27144f}")
    _552891376f9d._6cf335471275(f"{_995d3084dffc} classes in training data with classes {_7a874d6adadf} and weights {_0a71167a6ac9}")
    _833bec9fcde5._25e4d9c59bb8({"class_weights": _6ca5bf27144f, "class_names": _7a874d6adadf})

    if "llama" in _3a39c32263e7 and _a2b1a2132c39:
        _b876fab4785a = _5db1cac54565(**_833bec9fcde5)
    else:
        _b876fab4785a = _f286de6b4b5b(**_833bec9fcde5)

    _66f5c502a6f8 = _174534ada403(
        _263893ffcc62=_263893ffcc62,
        _deabb6a0e319="operation_mode",
        _0ee45ba4cbd0=_d01a52b0597d,
        _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _f8e005ccabb5 = _66971439b8f7
    if _66f5c502a6f8 == "model_finetune":
        _f8e005ccabb5 = _174534ada403(
            _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.finetuned_model_path", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_4ea6019e52ba,
            _1c02ce522bdb="Optional path to pretrained model checkpoint for finetuning"
        )
        if _f8e005ccabb5:
            _b87d233de81b(_b876fab4785a, _f8e005ccabb5, _5081f6154463="cpu")
            _552891376f9d._6cf335471275(f"Loaded finetuned model from {_f8e005ccabb5}")

    _30d3b8f6a3c7 = []
    if _a230d1a4ef76:
        if _9d9f1c2aee01:
            _a7bde5592344 = lambda _91d489d16db3: (
                _53c5cf33e454(_91d489d16db3, "weight") and
                _2f7415be3186(_91d489d16db3._094413070e7c, _be41f43c0c8f._0ebebb338eb0) and
                _91d489d16db3._094413070e7c._1ba498087cbc() > 64 and
                not _2f7415be3186(_91d489d16db3, (_378226f1fc32._36fe5912c5d2._4fd80cf9ddbb, _378226f1fc32._36fe5912c5d2._d08ef6858820, _378226f1fc32._36fe5912c5d2._6822898b65ab))
            )
        else:
            _a7bde5592344 = lambda _91d489d16db3: (
                _53c5cf33e454(_91d489d16db3, "weight") and
                _2f7415be3186(_91d489d16db3._094413070e7c, _be41f43c0c8f._0ebebb338eb0) and
                _91d489d16db3._094413070e7c._1ba498087cbc() > 64
            )
        _f91d81a7ec81 = _b876fab4785a._9f059bcbb077
        _a1a8ac0e6a3d = _c556a1b10dea(_f91d81a7ec81, _a7bde5592344=_a7bde5592344, _8cb0b8fc02a0=_66971439b8f7, _3060b4e8cb73=_66971439b8f7)
        try:
            _c4622edaed73 = _58926a5f1c6e._c3b8310138bc if _a2b1a2132c39 else _58926a5f1c6e._0695c11f86e5
            _d3a4c116955d = _7668d7599549(_66971439b8f7, _a1a8ac0e6a3d, _c4622edaed73)
        except _9790ebedf728:
            _d3a4c116955d = _61c0cf0c8fc4(
                _c92c562bb9c6=8, _aa65718bcabe=32, _c3a4ffb73e38=0.1,
                _a1a8ac0e6a3d=_fc4094acf375(_a1a8ac0e6a3d._c9885c3aab67()) if _a1a8ac0e6a3d else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _8766483df83b=_58926a5f1c6e._c3b8310138bc if _a2b1a2132c39 else _58926a5f1c6e._0695c11f86e5
            )
        _552891376f9d._6cf335471275(f"Target Module trainable parameters before applying LORA is {_f281803ca6ed(_f91d81a7ec81)} and size is {_cd83ad37f780(_f91d81a7ec81)} GB")
        _f91d81a7ec81 = _9b40b24d3eb7(_f91d81a7ec81, _d3a4c116955d)
        for _deabb6a0e319, _757667541752 in _b876fab4785a._3354cbd39553():
            if not _757667541752._b09c93440690:
                _757667541752 = _757667541752._4e2fe39bd810()
            if "encoder" in _deabb6a0e319 and "lora" not in _deabb6a0e319:
                _757667541752._df195fd54343 = _4ea6019e52ba
            elif "embedding" in _deabb6a0e319:
                _757667541752._df195fd54343 = "lora" in _deabb6a0e319
        _552891376f9d._6cf335471275(f"Target Module trainable parameters after applying LORA is {_f281803ca6ed(_f91d81a7ec81)} and size is {_cd83ad37f780(_f91d81a7ec81)} GB")

    _3166ad8791a1 = _66a306bb8464(_465ec3497c71())
    _08cc6fefa06f = 'gpu' if _be41f43c0c8f._0ef28c7964b4._d7496485defb() else 'cpu'
    _5d2c46ad95ba = f"cuda:{_3166ad8791a1}" if _08cc6fefa06f == 'gpu' else 'cpu'
    if _2fa05a98d924._3c6fe53c3575() is _4ea6019e52ba:
        _552891376f9d._6cf335471275(f"Setting model to {_5d2c46ad95ba}")
        _b876fab4785a = _b876fab4785a._902b99532bdc(_0ee45ba4cbd0=_be41f43c0c8f._b062ccff4984, _625268a99d40=_5d2c46ad95ba)

    _51a0122de30d = {}
    _51a0122de30d['model_name'] = _68e0ec6eb692
    _b407408ead7f = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="model.max_epochs", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Maximum number of epochs under model.max_epochs"
    )
    _51a0122de30d['max_epochs'] = _b407408ead7f
    _3e53f18d87c4 = _b6292d716c18._3e2f8d153fa1(_bda5e5ed1f31=2)
    _b97b393bb7bf = "epoch_training_metrics.csv"
    _5a328238a564 = "model_training_summary_metrics.csv"
    _619e3bb142bb = _586692a825d5(_552891376f9d,
                                       _3e53f18d87c4=_3e53f18d87c4,
                                       _51a0122de30d=_51a0122de30d,
                                       _1fa38c131bd8=_d6b79e8dff29,
                                       _3c35b851aedf=_b97b393bb7bf,
                                       _28743708ce39=_5a328238a564,
                                       _3c2f645f33aa=_66971439b8f7)
    _6281f99a77e8 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="app.checkpoints_dir", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _c65fa7654fff = _4dda3c25f827._a7eda47347ba._49613dfb13db(_6281f99a77e8, _68e0ec6eb692, "finetune")
    _4dda3c25f827._b95f2d16e72f(_c65fa7654fff, _afbdd29315d7=_38862797c7bf)
    _5511a1557a6f = _b6292d716c18._a48adc84076c(_40764e0dadd6=_c65fa7654fff, _56a78d33b06a="intermediate",
        _31b30096f1d0=1, _5a1c04e66300=1000, _2b9789cb8c02=_4ea6019e52ba)
    _c8c7d8fa1e75 = _b6292d716c18._a48adc84076c(_40764e0dadd6=_c65fa7654fff, _56a78d33b06a="last", _31b30096f1d0=1,
        _2b9789cb8c02=_38862797c7bf, _7a347a2a9ace="val_loss", _a2e44f381482="min")
    _664c1ffe5842 = _b6292d716c18._24db6d64b524(_7a347a2a9ace="val_accuracy", _cedb3c625afa=3, _a2e44f381482="max", _ad21c69048c9=_38862797c7bf)
    _b807bba551c4 = _b6292d716c18._a8e505bbcfeb(_bdf4c1048b1e='step')

    for _deabb6a0e319, _1b5caf82cebe in _b876fab4785a._3354cbd39553():
        if not _1b5caf82cebe._df195fd54343:
            _30d3b8f6a3c7._abc48211eaf1(_1b5caf82cebe)
    _6d8dd18c8ce1 = _41a5812cd864(_ea7eb8b3ea0e=_30d3b8f6a3c7) if _08cc6fefa06f == "gpu" else "auto"
    _d5be4768e360 = _e2b1d39e0454._d5be4768e360

    _30a9ffbd5e5b = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.accumulate_grad_batches", _0ee45ba4cbd0=_66a306bb8464, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _72c2b06359b7 = _174534ada403(
        _263893ffcc62=_263893ffcc62, _deabb6a0e319="run_config.training_precision_type", _0ee45ba4cbd0=_d01a52b0597d, _47b62c512c1a=_38862797c7bf,
        _1c02ce522bdb="Training precision type under run_config.training_precision_type"
    )
    _89bddf3dd62c = _48c6ed74876b(
        _a7a2f417f0f7=_08cc6fefa06f, _521530747818=_7bb6bb69d897(_08cc6fefa06f),
        _d5be4768e360=_d5be4768e360, _c3dd22603901=_6d8dd18c8ce1 if _08cc6fefa06f == "gpu" else "auto",
        _b407408ead7f=_b407408ead7f, _bd0c9f5593a2=_4ea6019e52ba, _a14fd359cdff=_38862797c7bf,
        _a8406a8257ae=_38862797c7bf, _25c14d9c49d2=_4ea6019e52ba,
        _30a9ffbd5e5b=_30a9ffbd5e5b,
        _563d1732f1b4=_72c2b06359b7,
        _b6292d716c18=[_619e3bb142bb, _5511a1557a6f, _c8c7d8fa1e75, _664c1ffe5842, _b807bba551c4],
    )

    _8c4c1e350adc = _4409fac43b10(
        _230df627f58a=_230df627f58a, _891adc22c2ce=_891adc22c2ce,
        _23194f3e0bb5=_38862797c7bf, _96ebde491c40=_550eccd7f90f,
        _972a7b5ee40b=_14dbe90df864, _69e60b30ba59=_e2b1d39e0454._2ea7e6e36040,
        _a2b1a2132c39=_a2b1a2132c39, _0f9b507bbbe9=_0f9b507bbbe9
    )

    if _3166ad8791a1 == 0:
        _d20b6b47236f = _4edb943d9af0(_b876fab4785a)
        _552891376f9d._6cf335471275(f"Model Summary before fit is {_d20b6b47236f}")
        _552891376f9d._6cf335471275(f"Model structure is {_b876fab4785a}")

    _fa03ac06eff2 = _4dda3c25f827._a7eda47347ba._49613dfb13db(_c65fa7654fff, "intermediate.ckpt")
    if _4dda3c25f827._a7eda47347ba._fa6599e09fb1(_fa03ac06eff2):
        _89bddf3dd62c._8c150d2d4df9(_b876fab4785a, _09dc550a6460=_8c4c1e350adc, _20bd9b13a0b2=_fa03ac06eff2)
    else:
        _89bddf3dd62c._8c150d2d4df9(_b876fab4785a, _09dc550a6460=_8c4c1e350adc)

    if _be41f43c0c8f._10e05cf294e8._2cebc32d517e():
        _be41f43c0c8f._10e05cf294e8._67e340c1f1d7()
    _d5e569cd7104 = _c8c7d8fa1e75._af1993918283
    if _d5e569cd7104:
        _552891376f9d._6cf335471275(f"Best checkpoint saved at {_d5e569cd7104}")

    # Run test set
    _dcf156c87c09(_e2b1d39e0454, _263893ffcc62, _833bec9fcde5, _d5e569cd7104, _550eccd7f90f, _19279f229d0f, _4167e5ba3409, _a2b1a2132c39, _d07d7db36eda, _a230d1a4ef76, _552891376f9d, _563d1732f1b4=_72c2b06359b7)

    _552891376f9d._6cf335471275("Finetuning completed successfully.")


def _2ea6311f2fe5():
    _04ab0f5035a9 = _b3b9425754f0._ac857d831b2b(_53214850f7c5='Fine-tune a language identification model (single run)')
    _04ab0f5035a9._324ea2209627('--config_file_path', _982d6d1001cc=_d01a52b0597d, _47b62c512c1a=_38862797c7bf)
    _04ab0f5035a9._324ea2209627('--num_nodes', _982d6d1001cc=_66a306bb8464, _6ae135728541=1)
    _04ab0f5035a9._324ea2209627('--cpu_cores', _982d6d1001cc=_66a306bb8464, _6ae135728541=1)
    _04ab0f5035a9._324ea2209627('--local-rank', _982d6d1001cc=_66a306bb8464)
    _04ab0f5035a9._324ea2209627('--backend', _982d6d1001cc=_d01a52b0597d, _6ae135728541="gloo", _d7dd265933a7=['gloo', 'mpi', 'nccl'])
    _04ab0f5035a9._324ea2209627('--run_timestamp', _982d6d1001cc=_e3a5072de527, _6ae135728541=_66971439b8f7)
    _e2b1d39e0454 = _04ab0f5035a9._b19d90a0f6f3()
    if _e2b1d39e0454._79837812804a is _66971439b8f7:
        _e2b1d39e0454._79837812804a = _cdc217d64884._cdc217d64884()
    _eb91c67ce121(_e2b1d39e0454)


if __name__ == "__main__":
    _84cbf6096a17()