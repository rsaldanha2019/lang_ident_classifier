# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from __future__ import _c48e74e00226
from _5ef4e3be905c import _adeefa1137d4
import _2ef9649b649e, _e685103c1966, json, os, random, _fdd4dec0a574, sys, time, _92df6c98075c
from _a719cbbb8d19 import _5d1d20811077
from typing import _c01ddad0a0bb, _0cb38a67e766, _c7067bea80f9
import _8186e15f073c as _cc2f87cf80d7, _bc57609896eb, _b829a9936ed6 as _4abacb98c198
from _b829a9936ed6 import _058248395ba1
from _b829a9936ed6._f3e54640aeb2 import _5c1bb1cfc055
from _b829a9936ed6._f3e54640aeb2._8afb39ea075a._484c56c9881c import _f1ac34d69102
from _4680a7c8f249 import _4379e5c7a3f8, _17f1aac8128c, _dda0d1bc27b0
from _456b8523116c._3260e6d366b3._748312cf0419._936e44d8c2b4 import _5ab7efc93c18
from _456b8523116c._3260e6d366b3._748312cf0419._8cc8a0fed9c7 import _d290b23234fc
from _456b8523116c._3260e6d366b3._748312cf0419._f991c485fac4 import _f15b67de400f
from _456b8523116c._3260e6d366b3._748312cf0419._914b980db966 import _5cfa06576b39
from _456b8523116c._3260e6d366b3._d14e3bc1daba._33ca7a87e306 import _f008b2a99a93
from _456b8523116c._3260e6d366b3._d14e3bc1daba._5c295fad75e7 import _6b72af64db55
from _456b8523116c._3260e6d366b3._b1850b2f38bd._ea57be3eb908 import _b658929e4034
from _456b8523116c._3260e6d366b3._b1850b2f38bd._d7f764ca5760 import _981f579a163a
from _456b8523116c._3260e6d366b3._5c1bb1cfc055._0025650ddc3c import _dcad7c13b290
from _456b8523116c._3260e6d366b3._748312cf0419._5f679fdbe6e4 import _fe06364b2902
from _456b8523116c._3260e6d366b3._748312cf0419._5f679fdbe6e4 import (
    _aed87f909ef1, _396c11cfe06c, _b349f8014965,
    _870a410a10d0, _2f3c89f5c40a, _f00cf139b23c,
    _0de346cc580a, _90e88e7fbf6c, _cf4cbba7fb12,
    _c68a165d7f86, _12666f1a6d87, _815a68eeafce,
    _70e151b4c741, _dbd84b00bdd4
)

os._654c8625a502["TOKENIZERS_PARALLELISM"] = "True"
_fce40536241b = _bc57609896eb._390e70e70929._4a204332950e() and _bc57609896eb._390e70e70929._db3e40a21888() > 0
if _fce40536241b:
    try:
        from _cc5bfbc99082 import _0dbc97ab13be
        import _ba859cd01bd9 as _eeac45f487cf
    except _9db1c88e5079:
        _eeac45f487cf = _b2721ed20e04


def _8882813784b4(_c1742f006be1: _bc57609896eb._b9efbda0cd0c._66423b56702a, _243c5f30665d: _8552537ce591, _183c12085e4f: _c7067bea80f9[_8552537ce591] = _b2721ed20e04) -> _b2721ed20e04:
    if not os._9404eac31579._13bb3efb4549(_243c5f30665d):
        raise _7dbedd1d0a35(f"Finetuned model path not found: {_243c5f30665d}")
    if _243c5f30665d._c3b7c8304f28((".pt", ".pth")):
        _740d2d7abd38 = _183c12085e4f or ("cpu" if not _bc57609896eb._390e70e70929._4a204332950e() else _b2721ed20e04)
        _0a789d21d141 = _bc57609896eb._244b67be3b60(_243c5f30665d, _183c12085e4f=_740d2d7abd38)
        _a63540b89b02 = _0a789d21d141._d320236fd145("state_dict", _0a789d21d141._d320236fd145("model_state_dict", _0a789d21d141)) if _1ee96b1f49e1(_0a789d21d141, _1aa9f98dd59b) else _0a789d21d141
        if not _1ee96b1f49e1(_a63540b89b02, _1aa9f98dd59b):
            raise _7ce02921e35a(f"Loaded .pt file does not contain state_dict mapping: {_243c5f30665d}")
        _c1742f006be1._787ca4dece53(_a63540b89b02, _b79534a91375=_6b5bc520a64e)
    elif _243c5f30665d._c3b7c8304f28(".ckpt"):
        try:
            if _79c1c4a4e4d6(_c1742f006be1._bceac19775a1, "load_from_checkpoint"):
                _e870fe461e59 = _c1742f006be1._bceac19775a1._9ed69a5570db(_243c5f30665d, **{})
                _c1742f006be1._787ca4dece53(_e870fe461e59._0701a9e32233(), _b79534a91375=_6b5bc520a64e)
                return
            _0a789d21d141 = _bc57609896eb._244b67be3b60(_243c5f30665d, _183c12085e4f="cpu")
            _a63540b89b02 = _0a789d21d141._d320236fd145("state_dict", _0a789d21d141)
            if not _1ee96b1f49e1(_a63540b89b02, _1aa9f98dd59b):
                raise _7ce02921e35a("Lightning checkpoint did not contain a recognizable state_dict.")
            _c1742f006be1._787ca4dece53(_a63540b89b02, _b79534a91375=_6b5bc520a64e)
        except _9db1c88e5079 as _356045d0a58f:
            raise _7ce02921e35a(f"Failed to load .ckpt into model: {_356045d0a58f}") from _356045d0a58f
    else:
        raise _2b1a4f595348("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _1584850fcf9f(_109171277fb8: _2ef9649b649e._96160a3579b6, _0761c093f9ce: _c01ddad0a0bb, _acb545d4ee61: _0cb38a67e766[_8552537ce591, _c01ddad0a0bb], _dc6b18e5680a: _8552537ce591, _352270ade455: _c01ddad0a0bb, _3dca73dc8ab6: _c01ddad0a0bb, _e325331ee285: _98094ebc3637, _5d4d8d161810: _e93e958c4538, _2c76648e1817: _c01ddad0a0bb, _211d8fad75cb: _e93e958c4538, _82dc7cf78e90: _adeefa1137d4, _69caa85f218e: _8552537ce591 = "32"):
    """
    Compute test accuracy using the best checkpoint.
    """
    _aa3c8266ba7b = _6b5bc520a64e
    if _fce40536241b:
        _12ec33ae2913 = _0dbc97ab13be(
            _e6223cf5a3bc=_4bb832c91ab5,
            _2d8bc3edf148=_b349f8014965(),
            _ae5154592a21=_4bb832c91ab5,
            _3fcaf8e360de="nf4",
        )
        _aa3c8266ba7b = _4bb832c91ab5

    _ebb62bd2fe8a = 'gpu' if _bc57609896eb._390e70e70929._4a204332950e() else 'cpu'
    _08d2018a2258 = 'cpu'
    if _ebb62bd2fe8a == 'gpu':
        _00dcaa01190e = _bc57609896eb._173f683425f6._eb2bdc5eefb1() if _bc57609896eb._173f683425f6._a0b14d59555f() else 0
        _08d2018a2258 = f"cuda:{_00dcaa01190e}"
    else:
        _00dcaa01190e = -1

    _86d0b9408f7c = _acb545d4ee61._d320236fd145("pretrained_model_embedding_name")

    _acb545d4ee61._0c66f7fb9275({
        "tokenizer": _352270ade455,
        "pretrained_embedding_model": _3dca73dc8ab6,
        "device_dict": _396c11cfe06c(),
    })

    if not _dc6b18e5680a:
        _82dc7cf78e90._a63828fd1928("No best checkpoint found. Proceeding with current model weights.")
    else:
        _82dc7cf78e90._a63828fd1928(f"Testing with best checkpoint: {_dc6b18e5680a}")

    if "llama" in (_86d0b9408f7c or ""):
        _c1742f006be1 = _981f579a163a(**_acb545d4ee61)
        _5d4d8d161810 = _4bb832c91ab5
    else:
        _c1742f006be1 = _b658929e4034(**_acb545d4ee61)

    if _211d8fad75cb:
        if _aa3c8266ba7b:
            _6ccafd5b1663 = lambda _f16bfdcd7f40: (
                _79c1c4a4e4d6(_f16bfdcd7f40, "weight") and _1ee96b1f49e1(_f16bfdcd7f40._0fe9acadd46b, _bc57609896eb._4ab485cf3731) and _f16bfdcd7f40._0fe9acadd46b._2567563e512b() > 64 and
                not _1ee96b1f49e1(_f16bfdcd7f40, (_eeac45f487cf._b9efbda0cd0c._412bdd12a5ab, _eeac45f487cf._b9efbda0cd0c._84212cf22ae6, _b340dbddf2af(_eeac45f487cf._b9efbda0cd0c, "LinearNF4", _04e451ac7412(_b2721ed20e04))))
            )
        else:
            _6ccafd5b1663 = lambda _f16bfdcd7f40: (
                _79c1c4a4e4d6(_f16bfdcd7f40, "weight") and _1ee96b1f49e1(_f16bfdcd7f40._0fe9acadd46b, _bc57609896eb._4ab485cf3731) and _f16bfdcd7f40._0fe9acadd46b._2567563e512b() > 64
            )
        _b0c8af7eb61c = _c1742f006be1._57d0ff56a24a
        _9f9280f4678c = _870a410a10d0(_b0c8af7eb61c, _6ccafd5b1663=_6ccafd5b1663, _8b59a4371a05=_b2721ed20e04, _d75d1caefab1=_b2721ed20e04)
        _8c7d62279055 = _17f1aac8128c(
            _cf4443ee5dcf=8,
            _d0ce45578b41=32,
            _9af094552119=0.1,
            _9f9280f4678c=_3b85fd866ebe(_9f9280f4678c._b8de4dd5b95c()) if _9f9280f4678c else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _01c2e8e36b6d=_4379e5c7a3f8._43db7a44802b if _5d4d8d161810 else _4379e5c7a3f8._e7cc7d1696b2
        )
        _82dc7cf78e90._a63828fd1928(f"In test Target Module trainable parameters before applying LORA: {_2f3c89f5c40a(_b0c8af7eb61c)}")
        _b0c8af7eb61c = _f00cf139b23c(_b0c8af7eb61c, _8c7d62279055)
        _82dc7cf78e90._a63828fd1928(f"In test Target Module trainable parameters after applying LORA: {_2f3c89f5c40a(_b0c8af7eb61c)}")

    if _dc6b18e5680a:
        _82dc7cf78e90._a63828fd1928(f"Loading checkpoint from: {_dc6b18e5680a}")
        try:
            _0a789d21d141 = _bc57609896eb._244b67be3b60(_dc6b18e5680a, _183c12085e4f=_08d2018a2258)
            _a63540b89b02 = _0a789d21d141._d320236fd145("state_dict", _0a789d21d141)
            # Strip prefixes
            _f88a0d47835c = {}
            for _207d6504f995, _439a5df75394 in _a63540b89b02._a2b139c9a2f6():
                _02c8eb00bb48 = _207d6504f995
                while _02c8eb00bb48._78ee45ff3137('module.'):
                    _02c8eb00bb48 = _02c8eb00bb48[7:]
                while _02c8eb00bb48._78ee45ff3137('_forward_module.'):
                    _02c8eb00bb48 = _02c8eb00bb48[16:]
                _f88a0d47835c[_02c8eb00bb48] = _439a5df75394
            # Load with strict=False to handle potential extras
            _c1742f006be1._787ca4dece53(_f88a0d47835c, _b79534a91375=_6b5bc520a64e)
        except _9db1c88e5079 as _356045d0a58f:
            _82dc7cf78e90._541bca7a46aa(f"Checkpoint load failed: {_356045d0a58f}")
    else:
        _82dc7cf78e90._541bca7a46aa("No best checkpoint found. Proceeding with in-memory model weights.")

    if _bc57609896eb._390e70e70929._4a204332950e():
        _00dcaa01190e = _98094ebc3637(_aed87f909ef1())

    if _f1ac34d69102._578a97f53314() is _6b5bc520a64e:
        _82dc7cf78e90._a63828fd1928(f"Setting model to {_08d2018a2258}")
        _c1742f006be1 = _c1742f006be1._93644d48d3ae(_934c06d95193=_bc57609896eb._3cc8500554e5, _21d45cccd8ed=_08d2018a2258)

    _736e6c1271c0 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce,
        _02c8eb00bb48="app.model_config_name",
        _934c06d95193=_8552537ce591,
        _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )
    _5b4e317f93e8 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce,
        _02c8eb00bb48="app.data_dir",
        _934c06d95193=_8552537ce591,
        _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="data_dir under app specifies the base directory for datasets."
    )

    _3d63f2b5d6ba = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce,
        _02c8eb00bb48="dataset.test.data_dir",
        _934c06d95193=_8552537ce591,
        _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _c15e4eb1b34e = os._9404eac31579._ed8ccc93f59c(_5b4e317f93e8, _3d63f2b5d6ba)

    _dd1df51d6ac0 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce,
        _02c8eb00bb48="dataset.files_have_header",
        _934c06d95193=_e93e958c4538,
        _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _3be3bc0e53f2 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce,
        _02c8eb00bb48="app.random_seed",
        _934c06d95193=_98094ebc3637,
        _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _4eefd228df82 = f"config/{_736e6c1271c0}/finetune/classes_config.json"

    _96d7cc65220c = _f008b2a99a93(
        _5b4e317f93e8=_c15e4eb1b34e,
        _dd1df51d6ac0=_dd1df51d6ac0,
        _82dc7cf78e90=_82dc7cf78e90,
        _352270ade455=_352270ade455,
        _17a4e3e17a76=_e325331ee285,
        _4eefd228df82=_4eefd228df82,
        _9214c0ab9192=_6b5bc520a64e,
        _cab4f8b94474=_4bb832c91ab5,
        _6be2e63c238e=_109171277fb8._cb6b3cf56dba,
        _5d4d8d161810=_5d4d8d161810,
        _2c76648e1817=_2c76648e1817,
        _3be3bc0e53f2=_3be3bc0e53f2,
    )
    _82dc7cf78e90._a63828fd1928(f"Test samples: {_d933c402e954(_96d7cc65220c)}, Labels: {_b340dbddf2af(_96d7cc65220c, 'actual_num_of_labels', 'NA')}")

    _293f7e205029 = [_12268cf9b114 for _, _12268cf9b114 in _c1742f006be1._ddd2aa71345a() if not _12268cf9b114._7beb176dc5f7]
    _494bb4dbc4ea = _70e151b4c741(_7c866457e904=_293f7e205029) if _ebb62bd2fe8a == "gpu" else "auto"

    _b1e276123802 = _058248395ba1(
        _92ecb51ce9df=_ebb62bd2fe8a,
        _db3b14d1264c=_90e88e7fbf6c(_ebb62bd2fe8a=_ebb62bd2fe8a),
        _368929bc5ac4=1,
        _0e09973a79d8=_494bb4dbc4ea if _ebb62bd2fe8a == "gpu" else "auto",
        _9636016cd025=1,
        _69caa85f218e=_69caa85f218e,
        _a5b92fb173fa=0,
        _261c09bd3250=_6b5bc520a64e,
        _0afc4820ecbc=_6b5bc520a64e,
        _61dc94161501=_4bb832c91ab5,
        _68568e864f88=_6b5bc520a64e,
    )

    _fda32d45ed40 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.batch_size", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Batch size for training"
    )

    _57047764581b = _6b72af64db55(
        _96d7cc65220c=_96d7cc65220c,
        _2b22c072dc12=_fda32d45ed40,
        _6be2e63c238e=_109171277fb8._cb6b3cf56dba,
        _5d4d8d161810=_5d4d8d161810,
        _3a2d9b98683e=_352270ade455,
        _3be3bc0e53f2=_3be3bc0e53f2,
    )

    _431a414c151d = 0.0
    _17167d2e4b80 = [{}]
    try:
        _17167d2e4b80 = _b1e276123802._f19aec46fb97(_c1742f006be1._93644d48d3ae(_bc57609896eb._3cc8500554e5), _9e7800f12d8d=_57047764581b)
        _431a414c151d = _17167d2e4b80[0]._d320236fd145("test_accuracy", 0.0)
    except _9db1c88e5079 as _356045d0a58f:
        _82dc7cf78e90._f891652e169f(f"Exception during testing: {_356045d0a58f}")

    # Log test metrics
    _025ab2b7f1a2 = f"metrics/{_736e6c1271c0}"
    os._b2f172746ccb(_025ab2b7f1a2, _28adffd29525=_4bb832c91ab5)
    _f9d061306b76 = "test_set_metrics.csv"
    _d6d3841d9eec = os._9404eac31579._ed8ccc93f59c(_025ab2b7f1a2, _f9d061306b76)
    _b61897f273ec = _acb545d4ee61.copy()
    _b61897f273ec._7ccd82894831("pretrained_embedding_model", _b2721ed20e04)
    _b61897f273ec._7ccd82894831("tokenizer", _b2721ed20e04)
    _b61897f273ec._7ccd82894831("device_dict", _b2721ed20e04)
    _7893b9691388 = {
        'config': json._902d54e80af7(_b61897f273ec),
        'test_accuracy': _431a414c151d,
        'other_metrics': json._902d54e80af7(_17167d2e4b80[0])
    }
    with _ed05a1c8cb96(_d6d3841d9eec, 'a+', _a01cee51d1fe="utf8") as _660a97edbd36:
        _54eb437ee75b = _e685103c1966._e8edf4336a05(_660a97edbd36, _dcdf805317f6=_7893b9691388._b8de4dd5b95c())
        if os._9404eac31579._b7a45cff8457(_d6d3841d9eec) == 0:
            _54eb437ee75b._fdd3006f1d6e()
        _54eb437ee75b._12954c0efb76(_7893b9691388)
    _82dc7cf78e90._a63828fd1928(f"Test accuracy: {_431a414c151d}")

    try:
        if _79c1c4a4e4d6(_c1742f006be1, 'peft_config') or _1ee96b1f49e1(_c1742f006be1, _dda0d1bc27b0):
            _82dc7cf78e90._a63828fd1928("PEFT/LoRA detected. Merging adapters...")
            try:
                _c1742f006be1 = _c1742f006be1._fd17dbfef576()
                _82dc7cf78e90._a63828fd1928("LoRA adapters merged successfully.")
            except _9db1c88e5079 as _ceccc2c15053:
                _82dc7cf78e90._541bca7a46aa(f"LoRA merge failed: {_ceccc2c15053}. Proceeding without merge.")
        else:
            _82dc7cf78e90._a63828fd1928("No PEFT/LoRA detected. Skipping merge.")

        if _aa3c8266ba7b:
            _82dc7cf78e90._a63828fd1928("Dequantizing for CPU save...")
            _c1742f006be1 = _c1742f006be1._93644d48d3ae(_21d45cccd8ed="cuda" if _bc57609896eb._390e70e70929._4a204332950e() else "cpu")
            try:
                _c1742f006be1 = _12666f1a6d87(_c1742f006be1)
            except _9db1c88e5079 as _ca2776b52e15:
                _82dc7cf78e90._541bca7a46aa(f"dequantize_bnb_model failed, using manual_dequantize: {_ca2776b52e15}")
                _c1742f006be1 = _c68a165d7f86(_c1742f006be1)
            _c1742f006be1 = _c1742f006be1._11d16ed9e092()
            if _bc57609896eb._173f683425f6._a0b14d59555f():
                _bc57609896eb._173f683425f6._161cecb8fecd()
            _6d8b692f02af = _c1742f006be1._93644d48d3ae(_934c06d95193=_bc57609896eb._3cc8500554e5, _21d45cccd8ed="cpu")
            _0cc35dc58f56 = "saved_models"
            os._b2f172746ccb(_0cc35dc58f56, _28adffd29525=_4bb832c91ab5)
            _7176be722939 = os._9404eac31579._ed8ccc93f59c(_0cc35dc58f56, "finetuned_model.pt")
            _bc57609896eb._9f47611b10f3(_6d8b692f02af._0701a9e32233(), _7176be722939)
            _82dc7cf78e90._a63828fd1928(f"Saved lightweight checkpoint at {_7176be722939}")
    except _9db1c88e5079 as _356045d0a58f:
        _82dc7cf78e90._f891652e169f(f"Exception during model saving: {_356045d0a58f}")


def _d9fa1e046091(_109171277fb8: _2ef9649b649e._96160a3579b6) -> _b2721ed20e04:
    _cf4cbba7fb12()
    _001fd0e52a98 = _5ab7efc93c18()
    _0761c093f9ce = _001fd0e52a98._01e37bbc1ba4(_109171277fb8._d21ff6fdfd95)
    _b39bcdea7b7a = _d290b23234fc()
    _82dc7cf78e90 = _b39bcdea7b7a._ee3879a2c532(_0761c093f9ce)
    _854d3c6edf8b = _f15b67de400f()
    _0c137370bcc3 = _5cfa06576b39()

    _3be3bc0e53f2 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="app.random_seed", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Seed for reproducibility under app.random_seed"
    )
    _cc2f87cf80d7.random._c282c1ed41cc(_3be3bc0e53f2)
    random._c282c1ed41cc(_3be3bc0e53f2)
    _4abacb98c198._2f3071cb60c2(_3be3bc0e53f2, _df27a5da6a94=_4bb832c91ab5)
    _bc57609896eb._148887a6ee56(_3be3bc0e53f2)
    if _bc57609896eb._390e70e70929._4a204332950e():
        _bc57609896eb._390e70e70929._82527edb0f3c(_3be3bc0e53f2)

    _da3dd23d11b0 = 0
    if _bc57609896eb._390e70e70929._4a204332950e():
        _a40797ee8262 = _98094ebc3637(os._654c8625a502._d320236fd145('RANK', '0'))
        _0790508a9555 = _98094ebc3637(os._654c8625a502._d320236fd145('WORLD_SIZE', '1'))
        try:
            if not _bc57609896eb._173f683425f6._a0b14d59555f():
                _bc57609896eb._173f683425f6._23d673ece954(
                    _af55fb32f483=_109171277fb8._af55fb32f483, _da3dd23d11b0=_a40797ee8262, _0790508a9555=_0790508a9555,
                    _c1e3f225cabb=_5d1d20811077(_c81dbf13e316=600)
                )
        except _9db1c88e5079:
            pass
    if _bc57609896eb._173f683425f6._a0b14d59555f():
        try:
            _da3dd23d11b0 = _bc57609896eb._173f683425f6._eb2bdc5eefb1()
        except _9db1c88e5079:
            _da3dd23d11b0 = _b340dbddf2af(_109171277fb8, "local_rank", 0)

    _736e6c1271c0 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="app.model_config_name", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Model config name under app.model_config_name"
    )
    _025ab2b7f1a2 = f"metrics/{_736e6c1271c0}"
    os._b2f172746ccb(_025ab2b7f1a2, _28adffd29525=_4bb832c91ab5)

    _86d0b9408f7c = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.pretrained_embedding", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _160ec3af1c1a = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="app.pretrained_embeddings_dir", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _93219b37d6eb = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.pretrained_embedding_overwrite_old", _934c06d95193=_e93e958c4538, _0437916a3122=_6b5bc520a64e, _17206c41b16b=_6b5bc520a64e,
        _c45f1e10c9d5="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _aa3c8266ba7b = _6b5bc520a64e
    _12ec33ae2913 = _b2721ed20e04
    _5d4d8d161810 = _6b5bc520a64e
    _2c76648e1817 = _b2721ed20e04
    if _fce40536241b:
        try:
            _12ec33ae2913 = _0dbc97ab13be(
                _e6223cf5a3bc=_4bb832c91ab5,
                _2d8bc3edf148=_b349f8014965(),
                _ae5154592a21=_4bb832c91ab5,
                _3fcaf8e360de="nf4",
            )
            _aa3c8266ba7b = _4bb832c91ab5
        except _9db1c88e5079:
            _12ec33ae2913 = _b2721ed20e04

    _f1a963991f52 = os._9404eac31579._ed8ccc93f59c(
        _160ec3af1c1a,
        _86d0b9408f7c + ("_quantized" if _fce40536241b else "_fp32")
    )

    _854d3c6edf8b._932113f1f02f(_f1a963991f52, _c5b4ae2f78b1=_93219b37d6eb)
    if _854d3c6edf8b._cb8e6e8f38c6(_f1a963991f52):
        _82dc7cf78e90._a63828fd1928(f"Downloading pretrained embedding {_86d0b9408f7c}")
        try:
            from _4ddbb1b9c972 import _a97da839fd06, _92476b392748
            _758796d3c90b = _a97da839fd06()
            _362c66c8106f = _758796d3c90b._362c66c8106f(_86d0b9408f7c)
            _93df1dd7c946 = _b340dbddf2af(_362c66c8106f, "sha", _b2721ed20e04) or _b2721ed20e04
            if "llama" in _86d0b9408f7c._e9263e96372f():
                _b9f244514eea = os._943347554dfd("HF_LLAMA3B_TOKEN")
                if _b9f244514eea:
                    _92476b392748(token=_b9f244514eea)
                else:
                    raise _7ce02921e35a("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _9db1c88e5079:
            _93df1dd7c946 = _b2721ed20e04
        from _cc5bfbc99082 import _2a44b3e72f1c
        _7cc2fb088961 = _2a44b3e72f1c._5a332d20be73(_86d0b9408f7c, _93df1dd7c946=_93df1dd7c946)
        _82dc7cf78e90._a63828fd1928(f"config of pretrained embedding used {_7cc2fb088961}")
        if "llama" in _86d0b9408f7c._e9263e96372f():
            from _cc5bfbc99082 import _69701fe1fc97, _d725659b7778
            _3dca73dc8ab6 = _69701fe1fc97._5a332d20be73(
                _86d0b9408f7c, _93df1dd7c946=_93df1dd7c946,
                _76e03b402596=_12ec33ae2913 if (_fce40536241b and _12ec33ae2913) else _b2721ed20e04
            )
            _352270ade455 = _d725659b7778._5a332d20be73(_86d0b9408f7c, _93df1dd7c946=_93df1dd7c946, _7623fb66e1a0=_6b5bc520a64e)
            _5d4d8d161810 = _4bb832c91ab5
            _2c76648e1817 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _cc5bfbc99082 import _8a0e500146c6, _d725659b7778
            _3dca73dc8ab6 = _8a0e500146c6._5a332d20be73(_86d0b9408f7c, _93df1dd7c946=_93df1dd7c946)
            _352270ade455 = _d725659b7778._5a332d20be73(_86d0b9408f7c, _93df1dd7c946=_93df1dd7c946)
            _5d4d8d161810 = _6b5bc520a64e
        try:
            with _ed05a1c8cb96(os._9404eac31579._ed8ccc93f59c(_f1a963991f52, 'revision.txt'), 'w') as _39c9391086f1:
                _39c9391086f1._d25e745f6467(_93df1dd7c946)
            _3dca73dc8ab6._0d59e70b983b(_f1a963991f52)
            _352270ade455._0d59e70b983b(_f1a963991f52)
        except _9db1c88e5079:
            _82dc7cf78e90._541bca7a46aa("Saving pretrained embedding locally failed; continuing.")
    else:
        _82dc7cf78e90._a63828fd1928(f"Loading pretrained embedding from {_f1a963991f52}")
        from _cc5bfbc99082 import _2a44b3e72f1c
        _7cc2fb088961 = _2a44b3e72f1c._5a332d20be73(_f1a963991f52)
        _82dc7cf78e90._a63828fd1928(f"Config of pretrained embedding used {_7cc2fb088961}")
        if "llama" in _86d0b9408f7c._e9263e96372f():
            from _cc5bfbc99082 import _69701fe1fc97, _d725659b7778
            _3dca73dc8ab6 = _69701fe1fc97._5a332d20be73(
                _f1a963991f52,
                _76e03b402596=_12ec33ae2913 if (_fce40536241b and _12ec33ae2913) else _b2721ed20e04
            )
            _352270ade455 = _d725659b7778._5a332d20be73(_f1a963991f52, _7623fb66e1a0=_6b5bc520a64e)
            _5d4d8d161810 = _4bb832c91ab5
            _2c76648e1817 = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _cc5bfbc99082 import _8a0e500146c6, _d725659b7778
            _3dca73dc8ab6 = _8a0e500146c6._5a332d20be73(_f1a963991f52)
            _352270ade455 = _d725659b7778._5a332d20be73(_f1a963991f52)
            _5d4d8d161810 = _6b5bc520a64e

    _e325331ee285 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.max_seq_len", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Maximum sequence length for training"
    )
    _fda32d45ed40 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.batch_size", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Batch size for training"
    )
    _7bd220308a82 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.data_sample_share", _934c06d95193=_11d16ed9e092, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Proportion of dataset used for sampling"
    )
    _83c3a683edac = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.optimizer", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Optimizer type under run_config.optimizer"
    )
    _4d022bbd5634 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.learning_rate", _934c06d95193=_11d16ed9e092, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Learning rate for optimizer"
    )
    _3405157dc9b1 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.num_backbone_model_units_unfrozen", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Number of backbone model units unfrozen during training"
    )
    _92dbc40db358 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.loss_type", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Loss function type under run_config.loss_type"
    )
    _f6bf60cccacf = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.num_fc_layers_in_classifier_head", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Number of FC layers in classifier head"
    )
    _c02960108942 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.activation_function_for_layer", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Activation function for layer under run_config.activation_function_for_layer"
    )
    _e254f1aed477 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.add_dropout_after_embedding", _934c06d95193=_e93e958c4538, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _211d8fad75cb = _6b5bc520a64e if _3405157dc9b1 == 0 else _4bb832c91ab5

    _acb545d4ee61: _0cb38a67e766[_8552537ce591, _c01ddad0a0bb] = {
        "device_dict": _396c11cfe06c(),
        "pretrained_embedding_model": _3dca73dc8ab6,
        "optimizer": _83c3a683edac,
        "num_backbone_model_units_unfrozen": _3405157dc9b1,
        "loss_type": _92dbc40db358,
        "lr": _4d022bbd5634,
        "is_train": _4bb832c91ab5,
        "tokenizer": _352270ade455,
        "random_seed": _3be3bc0e53f2,
        "num_fc_layers": _f6bf60cccacf,
        "activation_function_for_layer": _c02960108942,
        "add_dropout_after_embedding": _e254f1aed477,
    }
    _acb545d4ee61._0c66f7fb9275({"pretrained_model_embedding_name": _86d0b9408f7c})
    if _5d4d8d161810:
        _acb545d4ee61._0c66f7fb9275({"prompt_length": _e325331ee285})

    _5b4e317f93e8 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="app.data_dir", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Base data directory under app.data_dir"
    )
    _3cd55c678ff7 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="dataset.train.data_dir", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Subdirectory for training data under dataset.train.data_dir"
    )
    _b246924937ea = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="dataset.val.data_dir", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Subdirectory for validation data under dataset.val.data_dir"
    )
    _0960f995d843 = os._9404eac31579._ed8ccc93f59c(_5b4e317f93e8, _3cd55c678ff7)
    _e48e9d680d19 = os._9404eac31579._ed8ccc93f59c(_5b4e317f93e8, _b246924937ea)
    _dd1df51d6ac0 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="dataset.files_have_header", _934c06d95193=_e93e958c4538, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Whether dataset files have header"
    )
    _4eefd228df82 = f"config/{_736e6c1271c0}/finetune/classes_config.json"
    _854d3c6edf8b._932113f1f02f(os._9404eac31579._c674c885ab67(_4eefd228df82))

    _831a6102f784 = _f008b2a99a93(
        _5b4e317f93e8=_0960f995d843, _dd1df51d6ac0=_dd1df51d6ac0, _82dc7cf78e90=_82dc7cf78e90,
        _352270ade455=_352270ade455, _17a4e3e17a76=_e325331ee285,
        _4eefd228df82=_4eefd228df82, _9214c0ab9192=_4bb832c91ab5, _cab4f8b94474=_6b5bc520a64e,
        _3be3bc0e53f2=_3be3bc0e53f2, _d8b9fb36f267=_7bd220308a82,
        _6be2e63c238e=_109171277fb8._cb6b3cf56dba, _5d4d8d161810=_5d4d8d161810, _2c76648e1817=_2c76648e1817,
    )
    _d3853a4d0c11 = _f008b2a99a93(
        _5b4e317f93e8=_e48e9d680d19, _dd1df51d6ac0=_dd1df51d6ac0, _82dc7cf78e90=_82dc7cf78e90,
        _352270ade455=_352270ade455, _17a4e3e17a76=_e325331ee285,
        _4eefd228df82=_4eefd228df82, _9214c0ab9192=_6b5bc520a64e, _cab4f8b94474=_6b5bc520a64e,
        _3be3bc0e53f2=_3be3bc0e53f2, _d8b9fb36f267=_7bd220308a82,
        _6be2e63c238e=_109171277fb8._cb6b3cf56dba, _5d4d8d161810=_5d4d8d161810, _2c76648e1817=_2c76648e1817,
    )
    _82dc7cf78e90._a63828fd1928(f"Number of training data samples {_831a6102f784._20ed7b70cb81()} with {_b340dbddf2af(_831a6102f784, 'label_sample_counter', 'NA')} labels and {_b340dbddf2af(_831a6102f784, 'actual_dataset_length', 'NA')} unique samples with {_b340dbddf2af(_831a6102f784, 'actual_num_of_labels', 'NA')} unique labels")
    _82dc7cf78e90._a63828fd1928(f"Number of validation data samples {_d3853a4d0c11._20ed7b70cb81()} with {_b340dbddf2af(_d3853a4d0c11, 'label_sample_counter', 'NA')} labels and {_b340dbddf2af(_d3853a4d0c11, 'actual_dataset_length', 'NA')} unique samples with {_b340dbddf2af(_d3853a4d0c11, 'actual_num_of_labels', 'NA')} unique labels.")

    _a2a7b07280d2 = _831a6102f784._5fb264df9040()
    _db903a1dcf8e = [_831a6102f784._a5fbff7ce72e(_13060dc10c91) for _13060dc10c91 in _831a6102f784._f483d29ad73a._b8de4dd5b95c()]
    _9f94c1b1c385 = _831a6102f784._9f94c1b1c385
    _2d779305ec4b = {}
    for _8dbe13f55b05, (_23f1212b761e, _0fe9acadd46b) in _bb942ad40f04(_9d758b2f3087(_db903a1dcf8e, _9f94c1b1c385)):
        _f277d09ce3da = _352270ade455(_23f1212b761e, _18d131438b24=_6b5bc520a64e)["input_ids"] if _5d4d8d161810 else [_8dbe13f55b05]
        if _f277d09ce3da:
            _2d779305ec4b[_23f1212b761e] = [_f277d09ce3da, _0fe9acadd46b]
    _cac689e75cb4(f"Class Weights Generated {_2d779305ec4b}")
    _82dc7cf78e90._a63828fd1928(f"{_a2a7b07280d2} classes in training data with classes {_db903a1dcf8e} and weights {_9f94c1b1c385}")
    _acb545d4ee61._0c66f7fb9275({"class_weights": _2d779305ec4b, "class_names": _db903a1dcf8e})

    if "llama" in _86d0b9408f7c and _5d4d8d161810:
        _c1742f006be1 = _981f579a163a(**_acb545d4ee61)
    else:
        _c1742f006be1 = _b658929e4034(**_acb545d4ee61)

    _ae7b55840478 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce,
        _02c8eb00bb48="operation_mode",
        _934c06d95193=_8552537ce591,
        _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _41185438bf20 = _b2721ed20e04
    if _ae7b55840478 == "model_finetune":
        _41185438bf20 = _dbd84b00bdd4(
            _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.finetuned_model_path", _934c06d95193=_8552537ce591, _0437916a3122=_6b5bc520a64e,
            _c45f1e10c9d5="Optional path to pretrained model checkpoint for finetuning"
        )
        if _41185438bf20:
            _42633a08ace1(_c1742f006be1, _41185438bf20, _183c12085e4f="cpu")
            _82dc7cf78e90._a63828fd1928(f"Loaded finetuned model from {_41185438bf20}")

    _293f7e205029 = []
    if _211d8fad75cb:
        if _aa3c8266ba7b:
            _6ccafd5b1663 = lambda _f16bfdcd7f40: (
                _79c1c4a4e4d6(_f16bfdcd7f40, "weight") and
                _1ee96b1f49e1(_f16bfdcd7f40._0fe9acadd46b, _bc57609896eb._4ab485cf3731) and
                _f16bfdcd7f40._0fe9acadd46b._2567563e512b() > 64 and
                not _1ee96b1f49e1(_f16bfdcd7f40, (_eeac45f487cf._b9efbda0cd0c._412bdd12a5ab, _eeac45f487cf._b9efbda0cd0c._84212cf22ae6, _eeac45f487cf._b9efbda0cd0c._afa645d136e3))
            )
        else:
            _6ccafd5b1663 = lambda _f16bfdcd7f40: (
                _79c1c4a4e4d6(_f16bfdcd7f40, "weight") and
                _1ee96b1f49e1(_f16bfdcd7f40._0fe9acadd46b, _bc57609896eb._4ab485cf3731) and
                _f16bfdcd7f40._0fe9acadd46b._2567563e512b() > 64
            )
        _b0c8af7eb61c = _c1742f006be1._57d0ff56a24a
        _9f9280f4678c = _870a410a10d0(_b0c8af7eb61c, _6ccafd5b1663=_6ccafd5b1663, _8b59a4371a05=_b2721ed20e04, _d75d1caefab1=_b2721ed20e04)
        try:
            _d4da75b42c9c = _4379e5c7a3f8._43db7a44802b if _5d4d8d161810 else _4379e5c7a3f8._e7cc7d1696b2
            _6b226b6a850b = _fe06364b2902(_b2721ed20e04, _9f9280f4678c, _d4da75b42c9c)
        except _9db1c88e5079:
            _6b226b6a850b = _17f1aac8128c(
                _cf4443ee5dcf=8, _d0ce45578b41=32, _9af094552119=0.1,
                _9f9280f4678c=_3b85fd866ebe(_9f9280f4678c._b8de4dd5b95c()) if _9f9280f4678c else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _01c2e8e36b6d=_4379e5c7a3f8._43db7a44802b if _5d4d8d161810 else _4379e5c7a3f8._e7cc7d1696b2
            )
        _82dc7cf78e90._a63828fd1928(f"Target Module trainable parameters before applying LORA is {_2f3c89f5c40a(_b0c8af7eb61c)} and size is {_815a68eeafce(_b0c8af7eb61c)} GB")
        _b0c8af7eb61c = _f00cf139b23c(_b0c8af7eb61c, _6b226b6a850b)
        for _02c8eb00bb48, _ede732e23055 in _c1742f006be1._ddd2aa71345a():
            if not _ede732e23055._0d3afb551982:
                _ede732e23055 = _ede732e23055._d05953dd34c1()
            if "encoder" in _02c8eb00bb48 and "lora" not in _02c8eb00bb48:
                _ede732e23055._7beb176dc5f7 = _6b5bc520a64e
            elif "embedding" in _02c8eb00bb48:
                _ede732e23055._7beb176dc5f7 = "lora" in _02c8eb00bb48
        _82dc7cf78e90._a63828fd1928(f"Target Module trainable parameters after applying LORA is {_2f3c89f5c40a(_b0c8af7eb61c)} and size is {_815a68eeafce(_b0c8af7eb61c)} GB")

    _00dcaa01190e = _98094ebc3637(_aed87f909ef1())
    _ebb62bd2fe8a = 'gpu' if _bc57609896eb._390e70e70929._4a204332950e() else 'cpu'
    _08d2018a2258 = f"cuda:{_00dcaa01190e}" if _ebb62bd2fe8a == 'gpu' else 'cpu'
    if _f1ac34d69102._578a97f53314() is _6b5bc520a64e:
        _82dc7cf78e90._a63828fd1928(f"Setting model to {_08d2018a2258}")
        _c1742f006be1 = _c1742f006be1._93644d48d3ae(_934c06d95193=_bc57609896eb._3cc8500554e5, _21d45cccd8ed=_08d2018a2258)

    _b74e8e84c5ca = {}
    _b74e8e84c5ca['model_name'] = _736e6c1271c0
    _9636016cd025 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="model.max_epochs", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Maximum number of epochs under model.max_epochs"
    )
    _b74e8e84c5ca['max_epochs'] = _9636016cd025
    _0a8fca515b91 = _5c1bb1cfc055._1f4e75a33a48(_52077526993f=2)
    _f663612d9f94 = "epoch_training_metrics.csv"
    _c149af6190a5 = "model_training_summary_metrics.csv"
    _b523c3f902be = _dcad7c13b290(_82dc7cf78e90,
                                       _0a8fca515b91=_0a8fca515b91,
                                       _b74e8e84c5ca=_b74e8e84c5ca,
                                       _3cc064b31292=_025ab2b7f1a2,
                                       _f752365a35bc=_f663612d9f94,
                                       _83e9df8f18b0=_c149af6190a5,
                                       _0ade62bf6e62=_b2721ed20e04)
    _79f99d35103e = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="app.checkpoints_dir", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _492605630529 = os._9404eac31579._ed8ccc93f59c(_79f99d35103e, _736e6c1271c0, "finetune")
    os._b2f172746ccb(_492605630529, _28adffd29525=_4bb832c91ab5)
    _aabbbd82c5a9 = _5c1bb1cfc055._ff3475fd132c(_13652d0a5dc5=_492605630529, _617fa06094fb="intermediate",
        _2306f418f6b6=1, _45097080cc1c=1000, _6be1fdd67830=_6b5bc520a64e)
    _976412599ce8 = _5c1bb1cfc055._ff3475fd132c(_13652d0a5dc5=_492605630529, _617fa06094fb="last", _2306f418f6b6=1,
        _6be1fdd67830=_4bb832c91ab5, _ddda56ba9e1b="val_loss", _6d794a5e0253="min")
    _2da1e1b26019 = _5c1bb1cfc055._6431de627e8d(_ddda56ba9e1b="val_accuracy", _50c3c2fe99bd=3, _6d794a5e0253="max", _b854e2f86eb6=_4bb832c91ab5)
    _0c4ba964ffcc = _5c1bb1cfc055._2595ec1756cf(_1068e6ca2f85='step')

    for _02c8eb00bb48, _12268cf9b114 in _c1742f006be1._ddd2aa71345a():
        if not _12268cf9b114._7beb176dc5f7:
            _293f7e205029._9409d48ce549(_12268cf9b114)
    _494bb4dbc4ea = _70e151b4c741(_7c866457e904=_293f7e205029) if _ebb62bd2fe8a == "gpu" else "auto"
    _368929bc5ac4 = _109171277fb8._368929bc5ac4

    _d8687a70dffb = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.accumulate_grad_batches", _934c06d95193=_98094ebc3637, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _a8f209f4f674 = _dbd84b00bdd4(
        _0761c093f9ce=_0761c093f9ce, _02c8eb00bb48="run_config.training_precision_type", _934c06d95193=_8552537ce591, _0437916a3122=_4bb832c91ab5,
        _c45f1e10c9d5="Training precision type under run_config.training_precision_type"
    )
    _dd083af2ec95 = _058248395ba1(
        _92ecb51ce9df=_ebb62bd2fe8a, _db3b14d1264c=_90e88e7fbf6c(_ebb62bd2fe8a),
        _368929bc5ac4=_368929bc5ac4, _0e09973a79d8=_494bb4dbc4ea if _ebb62bd2fe8a == "gpu" else "auto",
        _9636016cd025=_9636016cd025, _261c09bd3250=_6b5bc520a64e, _407f99c39f18=_4bb832c91ab5,
        _61dc94161501=_4bb832c91ab5, _68568e864f88=_6b5bc520a64e,
        _d8687a70dffb=_d8687a70dffb,
        _69caa85f218e=_a8f209f4f674,
        _5c1bb1cfc055=[_b523c3f902be, _aabbbd82c5a9, _976412599ce8, _2da1e1b26019, _0c4ba964ffcc],
    )

    _4e58314cd37e = _6b72af64db55(
        _831a6102f784=_831a6102f784, _d3853a4d0c11=_d3853a4d0c11,
        _2904b663cade=_4bb832c91ab5, _3a2d9b98683e=_352270ade455,
        _2b22c072dc12=_fda32d45ed40, _6be2e63c238e=_109171277fb8._cb6b3cf56dba,
        _5d4d8d161810=_5d4d8d161810, _3be3bc0e53f2=_3be3bc0e53f2
    )

    if _00dcaa01190e == 0:
        _749be102dea8 = _0de346cc580a(_c1742f006be1)
        _82dc7cf78e90._a63828fd1928(f"Model Summary before fit is {_749be102dea8}")
        _82dc7cf78e90._a63828fd1928(f"Model structure is {_c1742f006be1}")

    _3c85b289585c = os._9404eac31579._ed8ccc93f59c(_492605630529, "intermediate.ckpt")
    if os._9404eac31579._13bb3efb4549(_3c85b289585c):
        _dd083af2ec95._90acb5facca6(_c1742f006be1, _9e7800f12d8d=_4e58314cd37e, _243c5f30665d=_3c85b289585c)
    else:
        _dd083af2ec95._90acb5facca6(_c1742f006be1, _9e7800f12d8d=_4e58314cd37e)

    if _bc57609896eb._173f683425f6._a0b14d59555f():
        _bc57609896eb._173f683425f6._161cecb8fecd()
    _09381f321dc4 = _976412599ce8._bce32404195b
    if _09381f321dc4:
        _82dc7cf78e90._a63828fd1928(f"Best checkpoint saved at {_09381f321dc4}")

    # Run test set
    _1083d5ac9624(_109171277fb8, _0761c093f9ce, _acb545d4ee61, _09381f321dc4, _352270ade455, _3dca73dc8ab6, _e325331ee285, _5d4d8d161810, _2c76648e1817, _211d8fad75cb, _82dc7cf78e90, _69caa85f218e=_a8f209f4f674)

    _82dc7cf78e90._a63828fd1928("Finetuning completed successfully.")


def _e16bdc8c82af():
    _645fa33e19f9 = _2ef9649b649e._c2441aa7b0b3(_3ce7992540b0='Fine-tune a language identification model (single run)')
    _645fa33e19f9._bf363ecd043b('--config_file_path', _04e451ac7412=_8552537ce591, _0437916a3122=_4bb832c91ab5)
    _645fa33e19f9._bf363ecd043b('--num_nodes', _04e451ac7412=_98094ebc3637, _17206c41b16b=1)
    _645fa33e19f9._bf363ecd043b('--cpu_cores', _04e451ac7412=_98094ebc3637, _17206c41b16b=1)
    _645fa33e19f9._bf363ecd043b('--local-rank', _04e451ac7412=_98094ebc3637)
    _645fa33e19f9._bf363ecd043b('--backend', _04e451ac7412=_8552537ce591, _17206c41b16b="gloo", _0c5ab8c40b26=['gloo', 'mpi', 'nccl'])
    _645fa33e19f9._bf363ecd043b('--run_timestamp', _04e451ac7412=_11d16ed9e092, _17206c41b16b=_b2721ed20e04)
    _109171277fb8 = _645fa33e19f9._fc417cedb78a()
    if _109171277fb8._d679c572e0e7 is _b2721ed20e04:
        _109171277fb8._d679c572e0e7 = time.time()
    _273e21747621(_109171277fb8)


if __name__ == "__main__":
    _53772884c702()