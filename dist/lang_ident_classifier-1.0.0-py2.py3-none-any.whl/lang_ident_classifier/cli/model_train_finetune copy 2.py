# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-28 15:30 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

from __future__ import _3d484fe6f8bb
from _054c89e9afd5 import _37a26c166a74
import _fb47f7f69168, _9dc103da4449, json, os, random, _8a92c56b1c35, sys, time, _923e7fef101b
from _7ea9b08e74e8 import _44f90a116e01
from typing import _f82ef63a8eb6, _176b77df5027, _509da2b6f0cc
import _b75a41144c93 as _9f70e5f775b0, _72803bae8443, _fea6b05334af as _c0b520802a3d
from _fea6b05334af import _7578ddd8a345
from _fea6b05334af._a98274195933 import _fe0128266c6e
from _fea6b05334af._a98274195933._131def528ee2._7f3aa97b58eb import _8bb337840ece
from _7b7d47ae662a import _f462967c8966, _b0706753b0f1, _b403b7dde9fa
from _375f34b106d6._fc8c4394ad08._d241deb35c3f._be21125f67fc import _00e6bed259c1
from _375f34b106d6._fc8c4394ad08._d241deb35c3f._283a8095f459 import _9df7014616e2
from _375f34b106d6._fc8c4394ad08._d241deb35c3f._aabb01f2f1e5 import _18a81c8bfb2a
from _375f34b106d6._fc8c4394ad08._d241deb35c3f._5e1e9bf47f28 import _1a6895eb1f8b
from _375f34b106d6._fc8c4394ad08._efb7cac02b44._cb93eaf6a4ac import _c9a3dfa3c660
from _375f34b106d6._fc8c4394ad08._efb7cac02b44._d3d22b94ffe2 import _0c8b9a9ed4bc
from _375f34b106d6._fc8c4394ad08._d701545f528f._e130acc28067 import _f3fe4b16c2f3
from _375f34b106d6._fc8c4394ad08._d701545f528f._489925c9b447 import _0e7b3bd38872
from _375f34b106d6._fc8c4394ad08._fe0128266c6e._1dafe1a4357f import _6d51aee88e11
from _375f34b106d6._fc8c4394ad08._d241deb35c3f._70101971113d import _2339b9448d10
from _375f34b106d6._fc8c4394ad08._d241deb35c3f._70101971113d import (
    _3a1633a9d616, _9388b070599e, _a3383c63cfba,
    _f53cf6e82cbd, _5a73b1ba13c2, _79f0f07d46ce,
    _7bb95bb35bde, _adc5e3a296ce, _81d26b55a7c5,
    _faed57f3334c, _c65f8731f127, _7fe4aa164157,
    _5abd107a3858, _c9b937e0ca1c
)

os._0a309317f377["TOKENIZERS_PARALLELISM"] = "True"
_6117fe80cfc2 = _72803bae8443._9492734a6a0b._e4a6b66ed5e1() and _72803bae8443._9492734a6a0b._7d840853b96b() > 0
if _6117fe80cfc2:
    try:
        from _cc18f2c5ef78 import _35e86a195226
        import _2cfcb0ec3f2f as _44215dd57a2c
    except _b620fcfe0af5:
        _44215dd57a2c = _e3acddd49c6d


def _dbf23742d915(_167d1da5403f: _72803bae8443._cb96edad3f2d._817151903222, _a2a9e6a38c86: _da49b11ccf21, _caa2b36245a8: _509da2b6f0cc[_da49b11ccf21] = _e3acddd49c6d) -> _e3acddd49c6d:
    if not os._8ad894ed64a2._3cf1bf173950(_a2a9e6a38c86):
        raise _930fde7dcf3f(f"Finetuned model path not found: {_a2a9e6a38c86}")
    if _a2a9e6a38c86._a0f2b6324984((".pt", ".pth")):
        _4ccc692b3393 = _caa2b36245a8 or ("cpu" if not _72803bae8443._9492734a6a0b._e4a6b66ed5e1() else _e3acddd49c6d)
        _44b6b845010d = _72803bae8443._befece3befba(_a2a9e6a38c86, _caa2b36245a8=_4ccc692b3393)
        _cbdcf1563ba4 = _44b6b845010d._4e73499b969c("state_dict", _44b6b845010d._4e73499b969c("model_state_dict", _44b6b845010d)) if _ea5ee2245d3d(_44b6b845010d, _ceffe5dd2325) else _44b6b845010d
        if not _ea5ee2245d3d(_cbdcf1563ba4, _ceffe5dd2325):
            raise _ee9ded8f2f40(f"Loaded .pt file does not contain state_dict mapping: {_a2a9e6a38c86}")
        _167d1da5403f._68abcd0a6171(_cbdcf1563ba4, _ade6a7c41a0f=_0f324a110c5f)
    elif _a2a9e6a38c86._a0f2b6324984(".ckpt"):
        try:
            if _f16032987f5c(_167d1da5403f._5613a4e68602, "load_from_checkpoint"):
                _45854701d8e6 = _167d1da5403f._5613a4e68602._c23a9a5c4b73(_a2a9e6a38c86, **{})
                _167d1da5403f._68abcd0a6171(_45854701d8e6._bd57240cec41(), _ade6a7c41a0f=_0f324a110c5f)
                return
            _44b6b845010d = _72803bae8443._befece3befba(_a2a9e6a38c86, _caa2b36245a8="cpu")
            _cbdcf1563ba4 = _44b6b845010d._4e73499b969c("state_dict", _44b6b845010d)
            if not _ea5ee2245d3d(_cbdcf1563ba4, _ceffe5dd2325):
                raise _ee9ded8f2f40("Lightning checkpoint did not contain a recognizable state_dict.")
            _167d1da5403f._68abcd0a6171(_cbdcf1563ba4, _ade6a7c41a0f=_0f324a110c5f)
        except _b620fcfe0af5 as _4a64208c5491:
            raise _ee9ded8f2f40(f"Failed to load .ckpt into model: {_4a64208c5491}") from _4a64208c5491
    else:
        raise _27554ad9d6d4("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _cd4e95143fd8(_fff967836612: _fb47f7f69168._347098154ebe, _db9349300a14: _f82ef63a8eb6, _d66e9fca9c5a: _176b77df5027[_da49b11ccf21, _f82ef63a8eb6], _edf592b0aa2d: _da49b11ccf21, _c71f1c93af52: _f82ef63a8eb6, _afc411991134: _f82ef63a8eb6, _c1fb7f533f58: _78ac04ff003d, _4b7fcf603973: _c4dfea7219ae, _4776b7316d9d: _f82ef63a8eb6, _8ea671725fe8: _c4dfea7219ae, _4b8de5503acb: _37a26c166a74, _f0f036d7206e: _da49b11ccf21 = "32"):
    """
    Compute test accuracy using the best checkpoint.
    """
    _e4692dd6d098 = _0f324a110c5f
    if _6117fe80cfc2:
        _bfda5ab6cf08 = _35e86a195226(
            _2dcdf3fb1892=_739dd88c8ba9,
            _4b0edfe005b7=_a3383c63cfba(),
            _7fc58f5c7758=_739dd88c8ba9,
            _b144f195a721="nf4",
        )
        _e4692dd6d098 = _739dd88c8ba9

    _5c9a21c6a260 = 'gpu' if _72803bae8443._9492734a6a0b._e4a6b66ed5e1() else 'cpu'
    _bba2728b1d69 = 'cpu'
    if _5c9a21c6a260 == 'gpu':
        _f1b89aa6022d = _72803bae8443._faccd48eedad._78ed2172aa76() if _72803bae8443._faccd48eedad._f788153c9bf8() else 0
        _bba2728b1d69 = f"cuda:{_f1b89aa6022d}"
    else:
        _f1b89aa6022d = -1

    _db9d972c68cb = _d66e9fca9c5a._4e73499b969c("pretrained_model_embedding_name")

    _d66e9fca9c5a._2de5b0f0f33f({
        "tokenizer": _c71f1c93af52,
        "pretrained_embedding_model": _afc411991134,
        "device_dict": _9388b070599e(),
    })

    if not _edf592b0aa2d:
        _4b8de5503acb._6d593d7fa90b("No best checkpoint found. Proceeding with current model weights.")
    else:
        _4b8de5503acb._6d593d7fa90b(f"Testing with best checkpoint: {_edf592b0aa2d}")

    if "llama" in (_db9d972c68cb or ""):
        _167d1da5403f = _0e7b3bd38872(**_d66e9fca9c5a)
        _4b7fcf603973 = _739dd88c8ba9
    else:
        _167d1da5403f = _f3fe4b16c2f3(**_d66e9fca9c5a)

    if _8ea671725fe8:
        if _e4692dd6d098:
            _63c19e1e5359 = lambda _a360f222260e: (
                _f16032987f5c(_a360f222260e, "weight") and _ea5ee2245d3d(_a360f222260e._7236af5d3948, _72803bae8443._c77615a3b6c3) and _a360f222260e._7236af5d3948._60f2ab8dd57d() > 64 and
                not _ea5ee2245d3d(_a360f222260e, (_44215dd57a2c._cb96edad3f2d._29f61b66fc00, _44215dd57a2c._cb96edad3f2d._8913519167cd, _5d907d866120(_44215dd57a2c._cb96edad3f2d, "LinearNF4", _31cfff658bf3(_e3acddd49c6d))))
            )
        else:
            _63c19e1e5359 = lambda _a360f222260e: (
                _f16032987f5c(_a360f222260e, "weight") and _ea5ee2245d3d(_a360f222260e._7236af5d3948, _72803bae8443._c77615a3b6c3) and _a360f222260e._7236af5d3948._60f2ab8dd57d() > 64
            )
        _0d0952e96f8f = _167d1da5403f._4fda0a1b75f9
        _4006cd1193d6 = _f53cf6e82cbd(_0d0952e96f8f, _63c19e1e5359=_63c19e1e5359, _b9d1747026ef=_e3acddd49c6d, _2364bd7c367b=_e3acddd49c6d)
        _77aed762ef19 = _b0706753b0f1(
            _28dd4b4859e6=8,
            _c268224ca2f8=32,
            _072563d3d989=0.1,
            _4006cd1193d6=_bfe50b5b3c9a(_4006cd1193d6._56ed4e06ad01()) if _4006cd1193d6 else ["q_proj", "v_proj", "k_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
            _6bc61eac23d9=_f462967c8966._951371690385 if _4b7fcf603973 else _f462967c8966._e98726c7943f
        )
        _4b8de5503acb._6d593d7fa90b(f"In test Target Module trainable parameters before applying LORA: {_5a73b1ba13c2(_0d0952e96f8f)}")
        _0d0952e96f8f = _79f0f07d46ce(_0d0952e96f8f, _77aed762ef19)
        _4b8de5503acb._6d593d7fa90b(f"In test Target Module trainable parameters after applying LORA: {_5a73b1ba13c2(_0d0952e96f8f)}")

    if _edf592b0aa2d:
        _4b8de5503acb._6d593d7fa90b(f"Loading checkpoint from: {_edf592b0aa2d}")
        try:
            _44b6b845010d = _72803bae8443._befece3befba(_edf592b0aa2d, _caa2b36245a8=_bba2728b1d69)
            _cbdcf1563ba4 = _44b6b845010d._4e73499b969c("state_dict", _44b6b845010d)
            # Strip prefixes
            _baf9895f70a4 = {}
            for _061bf899ed89, _ca43dfe9c407 in _cbdcf1563ba4._2911a2c4926d():
                _89916f950147 = _061bf899ed89
                while _89916f950147._538b48c1901f('module.'):
                    _89916f950147 = _89916f950147[7:]
                while _89916f950147._538b48c1901f('_forward_module.'):
                    _89916f950147 = _89916f950147[16:]
                _baf9895f70a4[_89916f950147] = _ca43dfe9c407
            # Load with strict=False to handle potential extras
            _167d1da5403f._68abcd0a6171(_baf9895f70a4, _ade6a7c41a0f=_0f324a110c5f)
        except _b620fcfe0af5 as _4a64208c5491:
            _4b8de5503acb._60abb7fc80b9(f"Checkpoint load failed: {_4a64208c5491}")
    else:
        _4b8de5503acb._60abb7fc80b9("No best checkpoint found. Proceeding with in-memory model weights.")

    if _72803bae8443._9492734a6a0b._e4a6b66ed5e1():
        _f1b89aa6022d = _78ac04ff003d(_3a1633a9d616())

    if _8bb337840ece._791bad393182() is _0f324a110c5f:
        _4b8de5503acb._6d593d7fa90b(f"Setting model to {_bba2728b1d69}")
        _167d1da5403f = _167d1da5403f._59a99308c154(_c642191323a9=_72803bae8443._bc29660135c0, _99c417c4be0c=_bba2728b1d69)

    _3e1967926564 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14,
        _89916f950147="app.model_config_name",
        _c642191323a9=_da49b11ccf21,
        _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="model_config_name under app defines the model configuration subdirectory or experiment name. Must be a non-empty string."
    )
    _b7f2a7e1c3ba = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14,
        _89916f950147="app.data_dir",
        _c642191323a9=_da49b11ccf21,
        _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="data_dir under app specifies the base directory for datasets."
    )

    _f301f7cc64e1 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14,
        _89916f950147="dataset.test.data_dir",
        _c642191323a9=_da49b11ccf21,
        _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="dataset.test.data_dir specifies the relative subdirectory for test data under the base data_dir."
    )

    _b6221440faf5 = os._8ad894ed64a2._ffcf714b6600(_b7f2a7e1c3ba, _f301f7cc64e1)

    _53a908ae41d3 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14,
        _89916f950147="dataset.files_have_header",
        _c642191323a9=_c4dfea7219ae,
        _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="dataset.files_have_header specifies whether dataset files include a header row. Must be a boolean."
    )

    _d8a47907e553 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14,
        _89916f950147="app.random_seed",
        _c642191323a9=_78ac04ff003d,
        _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="random_seed under app sets the reproducibility seed for all frameworks (NumPy, PyTorch, Lightning). Must be an integer."
    )


    _104ed156b2b2 = f"config/{_3e1967926564}/finetune/classes_config.json"

    _52a8e8cfaeec = _c9a3dfa3c660(
        _b7f2a7e1c3ba=_b6221440faf5,
        _53a908ae41d3=_53a908ae41d3,
        _4b8de5503acb=_4b8de5503acb,
        _c71f1c93af52=_c71f1c93af52,
        _2a3e104b9b20=_c1fb7f533f58,
        _104ed156b2b2=_104ed156b2b2,
        _484dbc5f9ab3=_0f324a110c5f,
        _686cff26bab7=_739dd88c8ba9,
        _8c2755ca4771=_fff967836612._834ad8ab3d67,
        _4b7fcf603973=_4b7fcf603973,
        _4776b7316d9d=_4776b7316d9d,
        _d8a47907e553=_d8a47907e553,
    )
    _4b8de5503acb._6d593d7fa90b(f"Test samples: {_1a1849119089(_52a8e8cfaeec)}, Labels: {_5d907d866120(_52a8e8cfaeec, 'actual_num_of_labels', 'NA')}")

    _a845619f0bba = [_0f72adff8052 for _, _0f72adff8052 in _167d1da5403f._6e32f4f6a23d() if not _0f72adff8052._1cf86075e0c9]
    _2dc7f40b6acb = _5abd107a3858(_ddae5f882b37=_a845619f0bba) if _5c9a21c6a260 == "gpu" else "auto"

    _bbf1dea4dd31 = _7578ddd8a345(
        _bab5041f0991=_5c9a21c6a260,
        _c59cc0417c65=_adc5e3a296ce(_5c9a21c6a260=_5c9a21c6a260),
        _01d5f526e6e8=1,
        _05f74372d549=_2dc7f40b6acb if _5c9a21c6a260 == "gpu" else "auto",
        _f2ba1d875d84=1,
        _f0f036d7206e=_f0f036d7206e,
        _969184ee4b9c=0,
        _35ac93400f5b=_0f324a110c5f,
        _7a1cbb0147e4=_0f324a110c5f,
        _024a328891df=_739dd88c8ba9,
        _0020f471ef03=_0f324a110c5f,
    )

    _604bc57d5fc2 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.batch_size", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Batch size for training"
    )

    _def65c40aa2d = _0c8b9a9ed4bc(
        _52a8e8cfaeec=_52a8e8cfaeec,
        _a77200491a1e=_604bc57d5fc2,
        _8c2755ca4771=_fff967836612._834ad8ab3d67,
        _4b7fcf603973=_4b7fcf603973,
        _e074ab71f674=_c71f1c93af52,
        _d8a47907e553=_d8a47907e553,
    )

    _b09ed2d9e042 = 0.0
    _b6f29f48fea2 = [{}]
    try:
        _b6f29f48fea2 = _bbf1dea4dd31._e8d9294bbdf2(_167d1da5403f._59a99308c154(_72803bae8443._bc29660135c0), _5be64551c44f=_def65c40aa2d)
        _b09ed2d9e042 = _b6f29f48fea2[0]._4e73499b969c("test_accuracy", 0.0)
    except _b620fcfe0af5 as _4a64208c5491:
        _4b8de5503acb._e356c8f26139(f"Exception during testing: {_4a64208c5491}")

    # Log test metrics
    _a275ea0a5fbb = f"metrics/{_3e1967926564}"
    os._cbebc432109e(_a275ea0a5fbb, _2459a37ffe48=_739dd88c8ba9)
    _433a9207c5b7 = "test_set_metrics.csv"
    _44c1b844bc62 = os._8ad894ed64a2._ffcf714b6600(_a275ea0a5fbb, _433a9207c5b7)
    _27614ce115ea = _d66e9fca9c5a.copy()
    _27614ce115ea._2f18448cb317("pretrained_embedding_model", _e3acddd49c6d)
    _27614ce115ea._2f18448cb317("tokenizer", _e3acddd49c6d)
    _27614ce115ea._2f18448cb317("device_dict", _e3acddd49c6d)
    _df4d688dc128 = {
        'config': json._d0505e07de58(_27614ce115ea),
        'test_accuracy': _b09ed2d9e042,
        'other_metrics': json._d0505e07de58(_b6f29f48fea2[0])
    }
    with _0c09f66e6652(_44c1b844bc62, 'a+', _a64f1fb29312="utf8") as _425ffb0626ac:
        _457b17cf373b = _9dc103da4449._5994ea2e63b0(_425ffb0626ac, _e96f96678406=_df4d688dc128._56ed4e06ad01())
        if os._8ad894ed64a2._20cb6a78d460(_44c1b844bc62) == 0:
            _457b17cf373b._7f4a9dee97bc()
        _457b17cf373b._df2a6dd9d55c(_df4d688dc128)
    _4b8de5503acb._6d593d7fa90b(f"Test accuracy: {_b09ed2d9e042}")

    try:
        if _f16032987f5c(_167d1da5403f, 'peft_config') or _ea5ee2245d3d(_167d1da5403f, _b403b7dde9fa):
            _4b8de5503acb._6d593d7fa90b("PEFT/LoRA detected. Merging adapters...")
            try:
                _167d1da5403f = _167d1da5403f._0e11287d4fe7()
                _4b8de5503acb._6d593d7fa90b("LoRA adapters merged successfully.")
            except _b620fcfe0af5 as _40e8ceaa618b:
                _4b8de5503acb._60abb7fc80b9(f"LoRA merge failed: {_40e8ceaa618b}. Proceeding without merge.")
        else:
            _4b8de5503acb._6d593d7fa90b("No PEFT/LoRA detected. Skipping merge.")

        if _e4692dd6d098:
            _4b8de5503acb._6d593d7fa90b("Dequantizing for CPU save...")
            _167d1da5403f = _167d1da5403f._59a99308c154(_99c417c4be0c="cuda" if _72803bae8443._9492734a6a0b._e4a6b66ed5e1() else "cpu")
            try:
                _167d1da5403f = _c65f8731f127(_167d1da5403f)
            except _b620fcfe0af5 as _30f77e2a5704:
                _4b8de5503acb._60abb7fc80b9(f"dequantize_bnb_model failed, using manual_dequantize: {_30f77e2a5704}")
                _167d1da5403f = _faed57f3334c(_167d1da5403f)
            _167d1da5403f = _167d1da5403f._5d66fb2e52a4()
            if _72803bae8443._faccd48eedad._f788153c9bf8():
                _72803bae8443._faccd48eedad._e1c02f5d057a()
            _833d43f4894b = _167d1da5403f._59a99308c154(_c642191323a9=_72803bae8443._bc29660135c0, _99c417c4be0c="cpu")
            _84f9bf55d4ed = "saved_models"
            os._cbebc432109e(_84f9bf55d4ed, _2459a37ffe48=_739dd88c8ba9)
            _f5f43f4d2706 = os._8ad894ed64a2._ffcf714b6600(_84f9bf55d4ed, "finetuned_model.pt")
            _72803bae8443._320c25f000be(_833d43f4894b._bd57240cec41(), _f5f43f4d2706)
            _4b8de5503acb._6d593d7fa90b(f"Saved lightweight checkpoint at {_f5f43f4d2706}")
    except _b620fcfe0af5 as _4a64208c5491:
        _4b8de5503acb._e356c8f26139(f"Exception during model saving: {_4a64208c5491}")


def _d20f2fe9966e(_fff967836612: _fb47f7f69168._347098154ebe) -> _e3acddd49c6d:
    _81d26b55a7c5()
    _98712906d8c2 = _00e6bed259c1()
    _db9349300a14 = _98712906d8c2._ac510c50a39c(_fff967836612._8142e050464a)
    _dc75fdaf7663 = _9df7014616e2()
    _4b8de5503acb = _dc75fdaf7663._6d363e429bb0(_db9349300a14)
    _6f1ba1d01a27 = _18a81c8bfb2a()
    _6a26f2680f97 = _1a6895eb1f8b()

    _d8a47907e553 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="app.random_seed", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Seed for reproducibility under app.random_seed"
    )
    _9f70e5f775b0.random._37396f190b63(_d8a47907e553)
    random._37396f190b63(_d8a47907e553)
    _c0b520802a3d._c2ded78fac40(_d8a47907e553, _5a828232424d=_739dd88c8ba9)
    _72803bae8443._d338cf80741f(_d8a47907e553)
    if _72803bae8443._9492734a6a0b._e4a6b66ed5e1():
        _72803bae8443._9492734a6a0b._3b50b87e760e(_d8a47907e553)

    _418bb46cc21b = 0
    if _72803bae8443._9492734a6a0b._e4a6b66ed5e1():
        _159e72a65252 = _78ac04ff003d(os._0a309317f377._4e73499b969c('RANK', '0'))
        _fb53889dc2ae = _78ac04ff003d(os._0a309317f377._4e73499b969c('WORLD_SIZE', '1'))
        try:
            if not _72803bae8443._faccd48eedad._f788153c9bf8():
                _72803bae8443._faccd48eedad._1c228da86e21(
                    _96456d278560=_fff967836612._96456d278560, _418bb46cc21b=_159e72a65252, _fb53889dc2ae=_fb53889dc2ae,
                    _4d0aeea9c2be=_44f90a116e01(_6cae90f37b28=600)
                )
        except _b620fcfe0af5:
            pass
    if _72803bae8443._faccd48eedad._f788153c9bf8():
        try:
            _418bb46cc21b = _72803bae8443._faccd48eedad._78ed2172aa76()
        except _b620fcfe0af5:
            _418bb46cc21b = _5d907d866120(_fff967836612, "local_rank", 0)

    _3e1967926564 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="app.model_config_name", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Model config name under app.model_config_name"
    )
    _a275ea0a5fbb = f"metrics/{_3e1967926564}"
    os._cbebc432109e(_a275ea0a5fbb, _2459a37ffe48=_739dd88c8ba9)

    _db9d972c68cb = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.pretrained_embedding", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _3a441f832b8e = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="app.pretrained_embeddings_dir", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _b2e8d7edac9d = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.pretrained_embedding_overwrite_old", _c642191323a9=_c4dfea7219ae, _6576d619a84a=_0f324a110c5f, _316c2deb43bb=_0f324a110c5f,
        _b9840b068e2a="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _e4692dd6d098 = _0f324a110c5f
    _bfda5ab6cf08 = _e3acddd49c6d
    _4b7fcf603973 = _0f324a110c5f
    _4776b7316d9d = _e3acddd49c6d
    if _6117fe80cfc2:
        try:
            _bfda5ab6cf08 = _35e86a195226(
                _2dcdf3fb1892=_739dd88c8ba9,
                _4b0edfe005b7=_a3383c63cfba(),
                _7fc58f5c7758=_739dd88c8ba9,
                _b144f195a721="nf4",
            )
            _e4692dd6d098 = _739dd88c8ba9
        except _b620fcfe0af5:
            _bfda5ab6cf08 = _e3acddd49c6d

    _7ac6f86ab47e = os._8ad894ed64a2._ffcf714b6600(
        _3a441f832b8e,
        _db9d972c68cb + ("_quantized" if _6117fe80cfc2 else "_fp32")
    )

    _6f1ba1d01a27._c25359449c44(_7ac6f86ab47e, _ca284bc6fd1c=_b2e8d7edac9d)
    if _6f1ba1d01a27._0f86769c072f(_7ac6f86ab47e):
        _4b8de5503acb._6d593d7fa90b(f"Downloading pretrained embedding {_db9d972c68cb}")
        try:
            from _33d651317699 import _a842b65826d9, _15ae47c32c74
            _845758f178ee = _a842b65826d9()
            _3ad40967fac9 = _845758f178ee._3ad40967fac9(_db9d972c68cb)
            _227a4a80c191 = _5d907d866120(_3ad40967fac9, "sha", _e3acddd49c6d) or _e3acddd49c6d
            if "llama" in _db9d972c68cb._2b4572f666b0():
                _08eacbc34e91 = os._660020877e70("HF_LLAMA3B_TOKEN")
                if _08eacbc34e91:
                    _15ae47c32c74(token=_08eacbc34e91)
                else:
                    raise _ee9ded8f2f40("No HF token set. In ENV VARIABLE HF_LLAMA3B_TOKEN")
        except _b620fcfe0af5:
            _227a4a80c191 = _e3acddd49c6d
        from _cc18f2c5ef78 import _16c109adbb98
        _4a7891da8e65 = _16c109adbb98._7de64ca51aae(_db9d972c68cb, _227a4a80c191=_227a4a80c191)
        _4b8de5503acb._6d593d7fa90b(f"config of pretrained embedding used {_4a7891da8e65}")
        if "llama" in _db9d972c68cb._2b4572f666b0():
            from _cc18f2c5ef78 import _499ec1ae0015, _0be85e100b00
            _afc411991134 = _499ec1ae0015._7de64ca51aae(
                _db9d972c68cb, _227a4a80c191=_227a4a80c191,
                _26d4e530a885=_bfda5ab6cf08 if (_6117fe80cfc2 and _bfda5ab6cf08) else _e3acddd49c6d
            )
            _c71f1c93af52 = _0be85e100b00._7de64ca51aae(_db9d972c68cb, _227a4a80c191=_227a4a80c191, _838f627bfddc=_0f324a110c5f)
            _4b7fcf603973 = _739dd88c8ba9
            _4776b7316d9d = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _cc18f2c5ef78 import _5fc917b7d47b, _0be85e100b00
            _afc411991134 = _5fc917b7d47b._7de64ca51aae(_db9d972c68cb, _227a4a80c191=_227a4a80c191)
            _c71f1c93af52 = _0be85e100b00._7de64ca51aae(_db9d972c68cb, _227a4a80c191=_227a4a80c191)
            _4b7fcf603973 = _0f324a110c5f
        try:
            with _0c09f66e6652(os._8ad894ed64a2._ffcf714b6600(_7ac6f86ab47e, 'revision.txt'), 'w') as _2c9fc3c561c0:
                _2c9fc3c561c0._751a624ceae8(_227a4a80c191)
            _afc411991134._07b8896fe8db(_7ac6f86ab47e)
            _c71f1c93af52._07b8896fe8db(_7ac6f86ab47e)
        except _b620fcfe0af5:
            _4b8de5503acb._60abb7fc80b9("Saving pretrained embedding locally failed; continuing.")
    else:
        _4b8de5503acb._6d593d7fa90b(f"Loading pretrained embedding from {_7ac6f86ab47e}")
        from _cc18f2c5ef78 import _16c109adbb98
        _4a7891da8e65 = _16c109adbb98._7de64ca51aae(_7ac6f86ab47e)
        _4b8de5503acb._6d593d7fa90b(f"Config of pretrained embedding used {_4a7891da8e65}")
        if "llama" in _db9d972c68cb._2b4572f666b0():
            from _cc18f2c5ef78 import _499ec1ae0015, _0be85e100b00
            _afc411991134 = _499ec1ae0015._7de64ca51aae(
                _7ac6f86ab47e,
                _26d4e530a885=_bfda5ab6cf08 if (_6117fe80cfc2 and _bfda5ab6cf08) else _e3acddd49c6d
            )
            _c71f1c93af52 = _0be85e100b00._7de64ca51aae(_7ac6f86ab47e, _838f627bfddc=_0f324a110c5f)
            _4b7fcf603973 = _739dd88c8ba9
            _4776b7316d9d = (
                "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n"
                "You are a helpful assistant.<|eot_id|>\n"
                "<|start_header_id|>user<|end_header_id|>\n"
                "Identify the language of each word in the following sentence.\n"
                "Respond with only space separated language labels.\n"
                "Do not include any explanation or extra text.\n"
                "<|eot_id|>"
            )
        else:
            from _cc18f2c5ef78 import _5fc917b7d47b, _0be85e100b00
            _afc411991134 = _5fc917b7d47b._7de64ca51aae(_7ac6f86ab47e)
            _c71f1c93af52 = _0be85e100b00._7de64ca51aae(_7ac6f86ab47e)
            _4b7fcf603973 = _0f324a110c5f

    _c1fb7f533f58 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.max_seq_len", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Maximum sequence length for training"
    )
    _604bc57d5fc2 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.batch_size", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Batch size for training"
    )
    _ba3579fbf0e2 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.data_sample_share", _c642191323a9=_5d66fb2e52a4, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Proportion of dataset used for sampling"
    )
    _1350a66fe194 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.optimizer", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Optimizer type under run_config.optimizer"
    )
    _4b05d1f48d09 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.learning_rate", _c642191323a9=_5d66fb2e52a4, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Learning rate for optimizer"
    )
    _3c8e57dbb6e5 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.num_backbone_model_units_unfrozen", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Number of backbone model units unfrozen during training"
    )
    _777805bd21a2 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.loss_type", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Loss function type under run_config.loss_type"
    )
    _12f82091e058 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.num_fc_layers_in_classifier_head", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Number of FC layers in classifier head"
    )
    _f8fb782e7c39 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.activation_function_for_layer", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Activation function for layer under run_config.activation_function_for_layer"
    )
    _c33cdda8d06b = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.add_dropout_after_embedding", _c642191323a9=_c4dfea7219ae, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Whether to add dropout after embedding under run_config.add_dropout_after_embedding"
    )
    _8ea671725fe8 = _0f324a110c5f if _3c8e57dbb6e5 == 0 else _739dd88c8ba9

    _d66e9fca9c5a: _176b77df5027[_da49b11ccf21, _f82ef63a8eb6] = {
        "device_dict": _9388b070599e(),
        "pretrained_embedding_model": _afc411991134,
        "optimizer": _1350a66fe194,
        "num_backbone_model_units_unfrozen": _3c8e57dbb6e5,
        "loss_type": _777805bd21a2,
        "lr": _4b05d1f48d09,
        "is_train": _739dd88c8ba9,
        "tokenizer": _c71f1c93af52,
        "random_seed": _d8a47907e553,
        "num_fc_layers": _12f82091e058,
        "activation_function_for_layer": _f8fb782e7c39,
        "add_dropout_after_embedding": _c33cdda8d06b,
    }
    _d66e9fca9c5a._2de5b0f0f33f({"pretrained_model_embedding_name": _db9d972c68cb})
    if _4b7fcf603973:
        _d66e9fca9c5a._2de5b0f0f33f({"prompt_length": _c1fb7f533f58})

    _b7f2a7e1c3ba = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="app.data_dir", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Base data directory under app.data_dir"
    )
    _d29257d6cf27 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="dataset.train.data_dir", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Subdirectory for training data under dataset.train.data_dir"
    )
    _bca3c1e2ba74 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="dataset.val.data_dir", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Subdirectory for validation data under dataset.val.data_dir"
    )
    _363394e8a095 = os._8ad894ed64a2._ffcf714b6600(_b7f2a7e1c3ba, _d29257d6cf27)
    _fe982b0e1828 = os._8ad894ed64a2._ffcf714b6600(_b7f2a7e1c3ba, _bca3c1e2ba74)
    _53a908ae41d3 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="dataset.files_have_header", _c642191323a9=_c4dfea7219ae, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Whether dataset files have header"
    )
    _104ed156b2b2 = f"config/{_3e1967926564}/finetune/classes_config.json"
    _6f1ba1d01a27._c25359449c44(os._8ad894ed64a2._87ac8eb1572c(_104ed156b2b2))

    _2c3d0739ea8b = _c9a3dfa3c660(
        _b7f2a7e1c3ba=_363394e8a095, _53a908ae41d3=_53a908ae41d3, _4b8de5503acb=_4b8de5503acb,
        _c71f1c93af52=_c71f1c93af52, _2a3e104b9b20=_c1fb7f533f58,
        _104ed156b2b2=_104ed156b2b2, _484dbc5f9ab3=_739dd88c8ba9, _686cff26bab7=_0f324a110c5f,
        _d8a47907e553=_d8a47907e553, _713afe0a7833=_ba3579fbf0e2,
        _8c2755ca4771=_fff967836612._834ad8ab3d67, _4b7fcf603973=_4b7fcf603973, _4776b7316d9d=_4776b7316d9d,
    )
    _c3b192ce8859 = _c9a3dfa3c660(
        _b7f2a7e1c3ba=_fe982b0e1828, _53a908ae41d3=_53a908ae41d3, _4b8de5503acb=_4b8de5503acb,
        _c71f1c93af52=_c71f1c93af52, _2a3e104b9b20=_c1fb7f533f58,
        _104ed156b2b2=_104ed156b2b2, _484dbc5f9ab3=_0f324a110c5f, _686cff26bab7=_0f324a110c5f,
        _d8a47907e553=_d8a47907e553, _713afe0a7833=_ba3579fbf0e2,
        _8c2755ca4771=_fff967836612._834ad8ab3d67, _4b7fcf603973=_4b7fcf603973, _4776b7316d9d=_4776b7316d9d,
    )
    _4b8de5503acb._6d593d7fa90b(f"Number of training data samples {_2c3d0739ea8b._b8a2f3581fb5()} with {_5d907d866120(_2c3d0739ea8b, 'label_sample_counter', 'NA')} labels and {_5d907d866120(_2c3d0739ea8b, 'actual_dataset_length', 'NA')} unique samples with {_5d907d866120(_2c3d0739ea8b, 'actual_num_of_labels', 'NA')} unique labels")
    _4b8de5503acb._6d593d7fa90b(f"Number of validation data samples {_c3b192ce8859._b8a2f3581fb5()} with {_5d907d866120(_c3b192ce8859, 'label_sample_counter', 'NA')} labels and {_5d907d866120(_c3b192ce8859, 'actual_dataset_length', 'NA')} unique samples with {_5d907d866120(_c3b192ce8859, 'actual_num_of_labels', 'NA')} unique labels.")

    _40a1e4fbad93 = _2c3d0739ea8b._cc53fda5a74d()
    _159f6718b6a3 = [_2c3d0739ea8b._a7cd36b75606(_dacb72f7cc78) for _dacb72f7cc78 in _2c3d0739ea8b._8276fe254ab8._56ed4e06ad01()]
    _d2602fbaae11 = _2c3d0739ea8b._d2602fbaae11
    _a483cca762e0 = {}
    for _7c5a9f6fd330, (_e523087bb782, _7236af5d3948) in _cb43af42dd9f(_a77fa8094003(_159f6718b6a3, _d2602fbaae11)):
        _637d84113cb2 = _c71f1c93af52(_e523087bb782, _3e7dd91ac81a=_0f324a110c5f)["input_ids"] if _4b7fcf603973 else [_7c5a9f6fd330]
        if _637d84113cb2:
            _a483cca762e0[_e523087bb782] = [_637d84113cb2, _7236af5d3948]
    _851b9b0729fa(f"Class Weights Generated {_a483cca762e0}")
    _4b8de5503acb._6d593d7fa90b(f"{_40a1e4fbad93} classes in training data with classes {_159f6718b6a3} and weights {_d2602fbaae11}")
    _d66e9fca9c5a._2de5b0f0f33f({"class_weights": _a483cca762e0, "class_names": _159f6718b6a3})

    if "llama" in _db9d972c68cb and _4b7fcf603973:
        _167d1da5403f = _0e7b3bd38872(**_d66e9fca9c5a)
    else:
        _167d1da5403f = _f3fe4b16c2f3(**_d66e9fca9c5a)

    _43c26f7dd0e3 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14,
        _89916f950147="operation_mode",
        _c642191323a9=_da49b11ccf21,
        _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _d3a20acc3691 = _e3acddd49c6d
    if _43c26f7dd0e3 == "model_finetune":
        _d3a20acc3691 = _c9b937e0ca1c(
            _db9349300a14=_db9349300a14, _89916f950147="run_config.finetuned_model_path", _c642191323a9=_da49b11ccf21, _6576d619a84a=_0f324a110c5f,
            _b9840b068e2a="Optional path to pretrained model checkpoint for finetuning"
        )
        if _d3a20acc3691:
            _d7b53c327178(_167d1da5403f, _d3a20acc3691, _caa2b36245a8="cpu")
            _4b8de5503acb._6d593d7fa90b(f"Loaded finetuned model from {_d3a20acc3691}")

    _a845619f0bba = []
    if _8ea671725fe8:
        if _e4692dd6d098:
            _63c19e1e5359 = lambda _a360f222260e: (
                _f16032987f5c(_a360f222260e, "weight") and
                _ea5ee2245d3d(_a360f222260e._7236af5d3948, _72803bae8443._c77615a3b6c3) and
                _a360f222260e._7236af5d3948._60f2ab8dd57d() > 64 and
                not _ea5ee2245d3d(_a360f222260e, (_44215dd57a2c._cb96edad3f2d._29f61b66fc00, _44215dd57a2c._cb96edad3f2d._8913519167cd, _44215dd57a2c._cb96edad3f2d._e6170dec8536))
            )
        else:
            _63c19e1e5359 = lambda _a360f222260e: (
                _f16032987f5c(_a360f222260e, "weight") and
                _ea5ee2245d3d(_a360f222260e._7236af5d3948, _72803bae8443._c77615a3b6c3) and
                _a360f222260e._7236af5d3948._60f2ab8dd57d() > 64
            )
        _0d0952e96f8f = _167d1da5403f._4fda0a1b75f9
        _4006cd1193d6 = _f53cf6e82cbd(_0d0952e96f8f, _63c19e1e5359=_63c19e1e5359, _b9d1747026ef=_e3acddd49c6d, _2364bd7c367b=_e3acddd49c6d)
        try:
            _0c13ae37b70e = _f462967c8966._951371690385 if _4b7fcf603973 else _f462967c8966._e98726c7943f
            _e688ffed8584 = _2339b9448d10(_e3acddd49c6d, _4006cd1193d6, _0c13ae37b70e)
        except _b620fcfe0af5:
            _e688ffed8584 = _b0706753b0f1(
                _28dd4b4859e6=8, _c268224ca2f8=32, _072563d3d989=0.1,
                _4006cd1193d6=_bfe50b5b3c9a(_4006cd1193d6._56ed4e06ad01()) if _4006cd1193d6 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _6bc61eac23d9=_f462967c8966._951371690385 if _4b7fcf603973 else _f462967c8966._e98726c7943f
            )
        _4b8de5503acb._6d593d7fa90b(f"Target Module trainable parameters before applying LORA is {_5a73b1ba13c2(_0d0952e96f8f)} and size is {_7fe4aa164157(_0d0952e96f8f)} GB")
        _0d0952e96f8f = _79f0f07d46ce(_0d0952e96f8f, _e688ffed8584)
        for _89916f950147, _9aeb1e52849f in _167d1da5403f._6e32f4f6a23d():
            if not _9aeb1e52849f._bbfe334e8d73:
                _9aeb1e52849f = _9aeb1e52849f._33a49f72d164()
            if "encoder" in _89916f950147 and "lora" not in _89916f950147:
                _9aeb1e52849f._1cf86075e0c9 = _0f324a110c5f
            elif "embedding" in _89916f950147:
                _9aeb1e52849f._1cf86075e0c9 = "lora" in _89916f950147
        _4b8de5503acb._6d593d7fa90b(f"Target Module trainable parameters after applying LORA is {_5a73b1ba13c2(_0d0952e96f8f)} and size is {_7fe4aa164157(_0d0952e96f8f)} GB")

    _f1b89aa6022d = _78ac04ff003d(_3a1633a9d616())
    _5c9a21c6a260 = 'gpu' if _72803bae8443._9492734a6a0b._e4a6b66ed5e1() else 'cpu'
    _bba2728b1d69 = f"cuda:{_f1b89aa6022d}" if _5c9a21c6a260 == 'gpu' else 'cpu'
    if _8bb337840ece._791bad393182() is _0f324a110c5f:
        _4b8de5503acb._6d593d7fa90b(f"Setting model to {_bba2728b1d69}")
        _167d1da5403f = _167d1da5403f._59a99308c154(_c642191323a9=_72803bae8443._bc29660135c0, _99c417c4be0c=_bba2728b1d69)

    _34b62b5c05a3 = {}
    _34b62b5c05a3['model_name'] = _3e1967926564
    _f2ba1d875d84 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="model.max_epochs", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Maximum number of epochs under model.max_epochs"
    )
    _34b62b5c05a3['max_epochs'] = _f2ba1d875d84
    _a54c34e9496f = _fe0128266c6e._6fb4523425fb(_6d084e7ab7f0=2)
    _946507525ae9 = "epoch_training_metrics.csv"
    _6593a1518812 = "model_training_summary_metrics.csv"
    _7cbdd494d00e = _6d51aee88e11(_4b8de5503acb,
                                       _a54c34e9496f=_a54c34e9496f,
                                       _34b62b5c05a3=_34b62b5c05a3,
                                       _2568131f75ba=_a275ea0a5fbb,
                                       _31234583084d=_946507525ae9,
                                       _3887b56f9504=_6593a1518812,
                                       _e6db4e441e20=_e3acddd49c6d)
    _bb8f1fedc362 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="app.checkpoints_dir", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Directory where checkpoints are saved under app.checkpoints_dir"
    )
    _680c0f3d9055 = os._8ad894ed64a2._ffcf714b6600(_bb8f1fedc362, _3e1967926564, "finetune")
    os._cbebc432109e(_680c0f3d9055, _2459a37ffe48=_739dd88c8ba9)
    _12f153c0ff7a = _fe0128266c6e._e189a7333a54(_8f3038158f8d=_680c0f3d9055, _fde2a0f22cde="intermediate",
        _45f143344c9e=1, _ca513649a357=1000, _8c5c61ea951f=_0f324a110c5f)
    _56c296cd35d7 = _fe0128266c6e._e189a7333a54(_8f3038158f8d=_680c0f3d9055, _fde2a0f22cde="last", _45f143344c9e=1,
        _8c5c61ea951f=_739dd88c8ba9, _4572a8dbd5cc="val_loss", _686bca78895e="min")
    _6caa671d2376 = _fe0128266c6e._e3be61576573(_4572a8dbd5cc="val_accuracy", _f42af1e0caec=3, _686bca78895e="max", _b90876e569f2=_739dd88c8ba9)
    _371ee0b1c1ef = _fe0128266c6e._ac5afdd25dec(_b8ab2118aa20='step')

    for _89916f950147, _0f72adff8052 in _167d1da5403f._6e32f4f6a23d():
        if not _0f72adff8052._1cf86075e0c9:
            _a845619f0bba._15c5376ba784(_0f72adff8052)
    _2dc7f40b6acb = _5abd107a3858(_ddae5f882b37=_a845619f0bba) if _5c9a21c6a260 == "gpu" else "auto"
    _01d5f526e6e8 = _fff967836612._01d5f526e6e8

    _d825d26004be = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.accumulate_grad_batches", _c642191323a9=_78ac04ff003d, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Gradient accumulation batches under run_config.accumulate_grad_batches"
    )
    _25fac4011145 = _c9b937e0ca1c(
        _db9349300a14=_db9349300a14, _89916f950147="run_config.training_precision_type", _c642191323a9=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9,
        _b9840b068e2a="Training precision type under run_config.training_precision_type"
    )
    _aeef417d55df = _7578ddd8a345(
        _bab5041f0991=_5c9a21c6a260, _c59cc0417c65=_adc5e3a296ce(_5c9a21c6a260),
        _01d5f526e6e8=_01d5f526e6e8, _05f74372d549=_2dc7f40b6acb if _5c9a21c6a260 == "gpu" else "auto",
        _f2ba1d875d84=_f2ba1d875d84, _35ac93400f5b=_0f324a110c5f, _313c2af3a306=_739dd88c8ba9,
        _024a328891df=_739dd88c8ba9, _0020f471ef03=_0f324a110c5f,
        _d825d26004be=_d825d26004be,
        _f0f036d7206e=_25fac4011145,
        _fe0128266c6e=[_7cbdd494d00e, _12f153c0ff7a, _56c296cd35d7, _6caa671d2376, _371ee0b1c1ef],
    )

    _ea93a57f669d = _0c8b9a9ed4bc(
        _2c3d0739ea8b=_2c3d0739ea8b, _c3b192ce8859=_c3b192ce8859,
        _ef7d92b388d0=_739dd88c8ba9, _e074ab71f674=_c71f1c93af52,
        _a77200491a1e=_604bc57d5fc2, _8c2755ca4771=_fff967836612._834ad8ab3d67,
        _4b7fcf603973=_4b7fcf603973, _d8a47907e553=_d8a47907e553
    )

    if _f1b89aa6022d == 0:
        _fd09147ecfc5 = _7bb95bb35bde(_167d1da5403f)
        _4b8de5503acb._6d593d7fa90b(f"Model Summary before fit is {_fd09147ecfc5}")
        _4b8de5503acb._6d593d7fa90b(f"Model structure is {_167d1da5403f}")

    _3d9a1c872548 = os._8ad894ed64a2._ffcf714b6600(_680c0f3d9055, "intermediate.ckpt")
    if os._8ad894ed64a2._3cf1bf173950(_3d9a1c872548):
        _aeef417d55df._64a01ff91cd6(_167d1da5403f, _5be64551c44f=_ea93a57f669d, _a2a9e6a38c86=_3d9a1c872548)
    else:
        _aeef417d55df._64a01ff91cd6(_167d1da5403f, _5be64551c44f=_ea93a57f669d)

    if _72803bae8443._faccd48eedad._f788153c9bf8():
        _72803bae8443._faccd48eedad._e1c02f5d057a()
    _a00433346b82 = _56c296cd35d7._fb095f09554a
    if _a00433346b82:
        _4b8de5503acb._6d593d7fa90b(f"Best checkpoint saved at {_a00433346b82}")

    # Run test set
    _5ce19eb29830(_fff967836612, _db9349300a14, _d66e9fca9c5a, _a00433346b82, _c71f1c93af52, _afc411991134, _c1fb7f533f58, _4b7fcf603973, _4776b7316d9d, _8ea671725fe8, _4b8de5503acb, _f0f036d7206e=_25fac4011145)

    _4b8de5503acb._6d593d7fa90b("Finetuning completed successfully.")


def _ea9d2d208c62():
    _2a5a887efc64 = _fb47f7f69168._ccf273220192(_b362b68274f4='Fine-tune a language identification model (single run)')
    _2a5a887efc64._9618f8b70b8d('--config_file_path', _31cfff658bf3=_da49b11ccf21, _6576d619a84a=_739dd88c8ba9)
    _2a5a887efc64._9618f8b70b8d('--num_nodes', _31cfff658bf3=_78ac04ff003d, _316c2deb43bb=1)
    _2a5a887efc64._9618f8b70b8d('--cpu_cores', _31cfff658bf3=_78ac04ff003d, _316c2deb43bb=1)
    _2a5a887efc64._9618f8b70b8d('--local-rank', _31cfff658bf3=_78ac04ff003d)
    _2a5a887efc64._9618f8b70b8d('--backend', _31cfff658bf3=_da49b11ccf21, _316c2deb43bb="gloo", _65bc0600283f=['gloo', 'mpi', 'nccl'])
    _2a5a887efc64._9618f8b70b8d('--run_timestamp', _31cfff658bf3=_5d66fb2e52a4, _316c2deb43bb=_e3acddd49c6d)
    _fff967836612 = _2a5a887efc64._4168b1f6d833()
    if _fff967836612._bc7b5339a516 is _e3acddd49c6d:
        _fff967836612._bc7b5339a516 = time.time()
    _4b1072812010(_fff967836612)


if __name__ == "__main__":
    _3ae8b4c53266()