# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : bhasha_dataset_to_csv
# @Time             : 20/12/23 9:45 am IST
---------------------------------------------------------
"""
import _925ba8528c1b
import _5f9717bb94e1
import math
import os
from _01547c8b1d21 import _376aba10cdfd
from urllib._0dc2fa70452a import _b30ea1da417f
import _9609ff748fdd
from _723036fa87b0 import _723036fa87b0
import _7afc479bbf64 as _44ca5d4c778f
import json
import _c2dde3e939ab
from _8c07f9b6a568 import _d46aa8c6e0fd
from _59685d6a114d import _52f1dbbaf308
from _ac8af25d4153._c309002dab44._79f241d99c17._f2b4df2b4d34 import _44c2d060f2b0
from _ac8af25d4153._c309002dab44._79f241d99c17._0a7bfaf7ab11 import _8af71d0e5dc6
from _ac8af25d4153._c309002dab44._79f241d99c17._915dc6de2c32 import _151be86d7575

_ea8525cbe60c = {}

# def extract_lang_code(unique_id):
#     return "_".join(str(unique_id).split("_")[:-1])

def _614de7e8ad1b(_c309002dab44):
    _cb85095ee930 = _c309002dab44._b16301413ba8()._d98932615d99()

    # Split compound languages
    _2045d989ade3 = _cb85095ee930._2067b8a6b5d8("_")

    # Take first 3 letters of each part
    _2cab6229fe62 = [_bdfbcfeb3b5f[:3] for _bdfbcfeb3b5f in _2045d989ade3]
    _812daf76f7b3 = "_"._b523bea2bb64(_2cab6229fe62)
    _de92a812d5c4 = _812daf76f7b3
    _a1cdc3b14c50 = 1

    # If language already has a code, return it
    if _c309002dab44 in _ea8525cbe60c:
        return _ea8525cbe60c[_c309002dab44]

    # Find a unique code that isn't already assigned to a different language
    while _de92a812d5c4 in _ea8525cbe60c._1e764aedafbd():
        # Avoid reassigning same code to the same language
        if _927f0e081707(_93875b2fb95f != _c309002dab44 and _1d18ae2cebe3 == _de92a812d5c4 for _93875b2fb95f, _1d18ae2cebe3 in _ea8525cbe60c._9a7916aa3830()):
            _de92a812d5c4 = f"{_812daf76f7b3}{_a1cdc3b14c50}"
            _a1cdc3b14c50 += 1
        else:
            break

    _ea8525cbe60c[_c309002dab44] = _de92a812d5c4
    return _de92a812d5c4


def _57a8e43962cb(_613d8b7a0959, _e1a3a6e06351, _36087c8a71a0, _7f9a0d55b50e=20):
    def _b3c4ac82bcd0(_1b5a51e5750d):
        return _1b5a51e5750d._bbea46b058d9(_36087c8a71a0=_36087c8a71a0, _e4fc6158c2b0=_7f9a0d55b50e)

    def _ddcb6f909bcf(_1b5a51e5750d):
        return _1b5a51e5750d._09cced846138(f'{_e1a3a6e06351}_length', _3e1def163c2f=_4142889f4409)._e42dfbf11e70(_759d53b620af)

    return _613d8b7a0959._09cced846138('lang_code', _3e1def163c2f=_4142889f4409)._e42dfbf11e70(_ef17f5b60508)


class _87cc99560211:
    def _6ec85bd5f890(self, _8d44f296cce4: _376aba10cdfd, _203a64c20a2b: _44c2d060f2b0):
        self._2af46d9bce03 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/parallel_romanized_train_data.zip"
        self._8212291e44c0 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/bhasha-abhijnaanam_test_set.zip"
        self._8d44f296cce4 = _8d44f296cce4
        self._203a64c20a2b = _203a64c20a2b
        self._c565d90d0866 = self._3ba16e386030(self._2af46d9bce03, _7ddead2632f9="data/preprocessed/train")
        self._fdfcc255597a = self._3ba16e386030(self._8212291e44c0, _7ddead2632f9="data/preprocessed/test")
        self._6023fb26bef9 = _cfb9bc96ca6d(_cfb9bc96ca6d(self._203a64c20a2b, "dataset", _3b26fa5ba297), "dataset_share", 1.0)
        self._46090656121c = _cfb9bc96ca6d(_cfb9bc96ca6d(self._203a64c20a2b, "dataset", _3b26fa5ba297), "select_languages", [])
        self._16205d6980c6 = "data/filtered/native"
        self._f11bc9ca78da = "data/filtered/romanized"

        # Extract languages from JSON
        _9c086ded92c7 = self._6e749c15b0c0(self._c565d90d0866)

        # Extract languages from txt files
        _de3ffbec1454 = os._706430185536._b523bea2bb64("data", "native_script_train_valid_data", "Native_script_data")
        _e95254d19a88 = os._706430185536._b523bea2bb64("data", "roman_script_train_valid_data", "Roman_script_data")

        _9424b8eeb7de = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/native_script_train_valid_data.zip"
        _143a20c4442a = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/roman_script_train_valid_data.zip"

        _6d9268d4b98e = self._fa4271e7a9f0(_9424b8eeb7de, "data/native_script_train_valid_data")
        _ee2384268459 = self._fa4271e7a9f0(_143a20c4442a, "data/roman_script_train_valid_data")

        # Combine all txt languages
        _002aca697cc5 = _6d9268d4b98e._5de1d79b132b(_ee2384268459)

        if self._46090656121c:
            _002aca697cc5 = [_214898ce6ca3 for _214898ce6ca3 in self._46090656121c if _214898ce6ca3 in _002aca697cc5]
            _9c086ded92c7 = [_214898ce6ca3 for _214898ce6ca3 in self._46090656121c if _214898ce6ca3 in _9c086ded92c7]
        # Find missing languages in JSON compared to txt datasets
        _dccc4c232a65 = _01962f074198(_22a581482307(_002aca697cc5) - _22a581482307(_9c086ded92c7))
        self._8d44f296cce4._21506d1564b3(f"Languages in JSON: {_9c086ded92c7}")
        self._8d44f296cce4._21506d1564b3(f"Languages in TXT: {_002aca697cc5}")
        self._8d44f296cce4._21506d1564b3(f"Missing languages to load from TXT: {_dccc4c232a65}")

        # Now process only missing languages from TXT files
        if _dccc4c232a65:
            self._c14a63518546(_de3ffbec1454, "native", _dccc4c232a65, self._6023fb26bef9)
            self._c14a63518546(_e95254d19a88, "romanized", _dccc4c232a65, self._6023fb26bef9)

            # THIS needs correct paths inside
            self._eb64b26e4759(_dccc4c232a65)


        for _b4389f8dc0ef in ['train', 'test']:
            _3bad03c6e9b8 = self._c565d90d0866 if _b4389f8dc0ef == 'train' else self._fdfcc255597a
            _615cfadec55c = "train" if _b4389f8dc0ef == 'train' else "test"
            _c3fd7cf34198 = 0.8 if _b4389f8dc0ef == 'train' else 0.0
            self._8b8db9386ff9 = os._706430185536._e9d508c702c1(_3bad03c6e9b8)._2067b8a6b5d8(".")[0]
            self._edaef4e583d1 = os._706430185536._1429faf08347(_3bad03c6e9b8)
            self._615cfadec55c = _615cfadec55c
            for _e1a3a6e06351 in ["native", "romanized"]:
                self._09c650733b51(_e1a3a6e06351, _c3fd7cf34198, self._6023fb26bef9)

    def _1fd4eb48d476(self, _dccc4c232a65, _46090656121c=_3b26fa5ba297):
        _2b933d491dae = os._706430185536._b523bea2bb64("data", "original")

        for _cb85095ee930 in _dccc4c232a65:
            _1081705d23d3 = os._706430185536._b523bea2bb64(_2b933d491dae, _22cdcd53a04d(_cb85095ee930))
            if not os._706430185536._9284f1460c9f(_1081705d23d3):
                self._8d44f296cce4._117022f18cf5(f"Missing original data directory not found for language: {_cb85095ee930}")
                continue

            for _e1a3a6e06351 in ["native", "romanized"]:
                # Detect CSV files for this language
                for _c3981878bc76 in os._c11f72deb956(_1081705d23d3):
                    if not _c3981878bc76._6e0b9b18d788(".csv"):
                        continue
                    if _22cdcd53a04d(_cb85095ee930) not in _c3981878bc76 or _e1a3a6e06351 not in _c3981878bc76:
                        continue

                    # Determine destination based on CSV name (train or val)
                    _d683ee0ca55e = "train" if "train" in _c3981878bc76 else "val"
                    _8e51dbfc3454 = os._706430185536._b523bea2bb64("data", _d683ee0ca55e)

                    _598936deed3a = os._706430185536._b523bea2bb64(_1081705d23d3, _c3981878bc76)
                    _613d8b7a0959 = _44ca5d4c778f._1b9accca3f8a(_598936deed3a, _e7bcfc4e1b59=_5f9717bb94e1._a8f58cf1bc7c, _c77351e52213="\\")

                    _b71374d9bf1f = f"{_e1a3a6e06351} sentence"
                    if _b71374d9bf1f not in _613d8b7a0959._e1bb9f42cc3e:
                        self._8d44f296cce4._117022f18cf5(f"{_b71374d9bf1f} column missing in {_598936deed3a}, skipping.")
                        continue

                    _613d8b7a0959 = _613d8b7a0959[_613d8b7a0959[_b71374d9bf1f]._b89be56d8f3f(_fdaa01699ee7)._fdaa01699ee7._d98932615d99() != ""]
                    if _613d8b7a0959._cc5900f72ba1:
                        self._8d44f296cce4._117022f18cf5(f"No valid rows found for {_cb85095ee930} {_e1a3a6e06351} in {_598936deed3a}")
                        continue

                    _1216ab12071e = _613d8b7a0959["lang_code"]._c1179a6267ea[0]

                    _3f14c4183da0 = os._706430185536._b523bea2bb64(_8e51dbfc3454, _1216ab12071e)
                    os._60aebdbe6a19(_3f14c4183da0, _62713b703931=_17d1673a13eb)

                    _58faaaeae0da = os._706430185536._b523bea2bb64(_3f14c4183da0, "src")
                    _62e5edafaa64 = os._706430185536._b523bea2bb64(_3f14c4183da0, "tgt")
                    os._60aebdbe6a19(_58faaaeae0da, _62713b703931=_17d1673a13eb)
                    os._60aebdbe6a19(_62e5edafaa64, _62713b703931=_17d1673a13eb)

                    _f53e5ad5b071 = f"txt_{_e1a3a6e06351}"
                    _2896d85a8d45 = self._16205d6980c6 if _e1a3a6e06351._4303fd943dc3() == "native" else self._f11bc9ca78da
                    _6da961dcb068(f"MASTER DIR {_2896d85a8d45}")
                    os._60aebdbe6a19(_2896d85a8d45, _62713b703931=_17d1673a13eb)


                    _6084ad106a71 = os._706430185536._b523bea2bb64(_58faaaeae0da, f"{_1216ab12071e}_{_f53e5ad5b071}.src")
                    _7ad213dc06f0 = os._706430185536._b523bea2bb64(_62e5edafaa64, f"{_1216ab12071e}_{_f53e5ad5b071}.tgt")
                    _6af6533496b8 = "valid" if _d683ee0ca55e._4303fd943dc3() == "val" else _d683ee0ca55e
                    _824790b73c55 = os._706430185536._b523bea2bb64(_2896d85a8d45, f"{_6af6533496b8}_combine.txt")

                    with _dcad3a83311c(_6084ad106a71, "w", _40de9d50ff23="utf-8") as _f31f2fa366d6, \
                            _dcad3a83311c(_7ad213dc06f0, "w", _40de9d50ff23="utf-8") as _3724367c281f, \
                            _dcad3a83311c(_824790b73c55, "a+", _40de9d50ff23="utf-8") as _767f008c9a1a:
                        _f31f2fa366d6._aa74a2799b93("text\n")
                        _3724367c281f._aa74a2799b93("lang_code\n")

                        for _94760c439bf5 in _613d8b7a0959[_b71374d9bf1f]:
                            _94760c439bf5 = _fdaa01699ee7(_94760c439bf5)._d98932615d99()
                            if _94760c439bf5 and _94760c439bf5 != "\n":
                                _767f008c9a1a._aa74a2799b93(f"__label__{_cb85095ee930} {_94760c439bf5}\n")
                                _f31f2fa366d6._aa74a2799b93(f"{_94760c439bf5}\n")
                                _3724367c281f._aa74a2799b93(f"{_1216ab12071e}\n")

                    self._8d44f296cce4._21506d1564b3(f"Written {_91a0293a9778(_613d8b7a0959)} rows to {_6084ad106a71} and {_7ad213dc06f0}")

    def _2b957aa03da9(self, _3bad03c6e9b8):
        """
        Extract unique language names present in the JSON dataset.
        Args:
            json_file_path (str): Path to the JSON file
        Returns:
            Set[str]: Unique languages from the JSON data
        """
        with _dcad3a83311c(_3bad03c6e9b8, "r", _40de9d50ff23="utf-8") as _93a4fc473f66:
            _e40a5094f390 = json._53c5e1a860f6(_93a4fc473f66)
        _cd2eaa5fe70f = _22a581482307()
        for _7d6e71b0ea3f in _e40a5094f390._bfcde41558d5("data", []):
            _cb85095ee930 = _7d6e71b0ea3f._bfcde41558d5("language")
            if _cb85095ee930:
                _cd2eaa5fe70f._0c13a4caeed7(_cb85095ee930)
        return _cd2eaa5fe70f

    def _7e8e27be2950(self, _28684c540788, _e1a3a6e06351, _dccc4c232a65, _6023fb26bef9=1.0):
        """
        Process missing languages data from txt files by filtering lines matching missing languages.
        Creates separate CSVs for train and validation splits.
        
        Args:
            txt_dir (str): Directory containing train_combine.txt and valid_combine.txt
            script_type (str): 'native' or 'romanized'
            missing_languages (Set[str]): Languages missing in JSON but present in txt data
        """
        _980aee69dc43 = _151be86d7575()

        for _0214c30718b8, _98a991895dbb in [("train_combine.txt", "train"), ("valid_combine.txt", "val")]:
            _493670d0e49f = os._706430185536._b523bea2bb64(_28684c540788, _0214c30718b8)
            if not os._706430185536._9284f1460c9f(_493670d0e49f):
                self._8d44f296cce4._117022f18cf5(f"File {_493670d0e49f} not found, skipping.")
                continue

            _5bda602f2740 = []
            with _dcad3a83311c(_493670d0e49f, "r", _40de9d50ff23="utf-8") as _93a4fc473f66:
                for _3ceabb0f145b in _93a4fc473f66:
                    _3ceabb0f145b = _3ceabb0f145b._d98932615d99()
                    if not _3ceabb0f145b:
                        continue
                    _2045d989ade3 = _3ceabb0f145b._2067b8a6b5d8(_aff01e5104d0=1)
                    if _91a0293a9778(_2045d989ade3) < 2:
                        continue
                    _cd66c87f94a0, _94760c439bf5 = _2045d989ade3
                    if _cd66c87f94a0._efa638eea404("__label__"):
                        _cb85095ee930 = _cd66c87f94a0[_91a0293a9778("__label__"):]
                        if _cb85095ee930 in _dccc4c232a65:
                            _5bda602f2740._2702e6e9a737({
                                f"{_e1a3a6e06351} sentence": _94760c439bf5,
                                f"{_e1a3a6e06351}_length": _fdaa01699ee7(_94760c439bf5)._d98932615d99()._2067b8a6b5d8()._eceb69ffd605(),
                                "language": _cb85095ee930,
                                "lang_code": _22cdcd53a04d(_cb85095ee930),
                            })

            if not _5bda602f2740:
                self._8d44f296cce4._21506d1564b3(f"No missing language data found in {_493670d0e49f} for script {_e1a3a6e06351}.")
                continue

            _613d8b7a0959 = _44ca5d4c778f._e9b1543bc351(_5bda602f2740)
            _613d8b7a0959 = _613d8b7a0959[_613d8b7a0959[f"{_e1a3a6e06351} sentence"]._b89be56d8f3f(_fdaa01699ee7)._fdaa01699ee7._d98932615d99() != '']

            # Sample data if needed
            if _6023fb26bef9 not in [0.0, 1.0]:
                # df = df.sample(frac=data_sample_percent, random_state=self.props.app.random_seed)
                _613d8b7a0959 = _28f7197472d6(_613d8b7a0959=_613d8b7a0959, 
                                      _e1a3a6e06351=_e1a3a6e06351, 
                                      _36087c8a71a0=self._6023fb26bef9,
                                      _7f9a0d55b50e=self._203a64c20a2b._d3f60f474e98._7f9a0d55b50e)

            
            # Write separate CSV per language per split
            for _1216ab12071e, _c75bd4148fdf in _613d8b7a0959._09cced846138("lang_code"):
                # Skip if this group corresponds to English
                if _e1a3a6e06351._4303fd943dc3()=="romanized" and _c75bd4148fdf["language"]._c1179a6267ea[0] == "English":
                    continue
                _0782372de80c = f"data/original/{_1216ab12071e}"
                _980aee69dc43._1688f4310ef7(_0782372de80c=_0782372de80c)
                _dcfea825fa8c = f"{_0782372de80c}/txt_{_e1a3a6e06351}_{_1216ab12071e}_{_98a991895dbb}_original_data.csv"
                _c75bd4148fdf._2c2f1e2e2b04(
                    _dcfea825fa8c,
                    _276b563c09e4="w+",
                    _40de9d50ff23="utf8",
                    _06929bbd1b50=_4142889f4409,
                    _e7bcfc4e1b59=_5f9717bb94e1._a8f58cf1bc7c,
                    _c77351e52213="\\",
                )
                self._8d44f296cce4._21506d1564b3(f"Missing {_1216ab12071e} data ({_98a991895dbb}) written to {_dcfea825fa8c}")


    def _bf7e5bdb8a82(self, _feb2b09976ab, _7ddead2632f9, _98de4ea0a584=3, _22498c22696f=_4142889f4409):
        import time
        import _c2dde3e939ab, _9609ff748fdd, os
        from urllib._0dc2fa70452a import _b30ea1da417f

        self._8d44f296cce4._21506d1564b3(f"Preparing to download from {_feb2b09976ab} into {_7ddead2632f9}")
        os._60aebdbe6a19(_7ddead2632f9, _62713b703931=_17d1673a13eb)

        _51afc4f24985 = os._706430185536._e9d508c702c1(_b30ea1da417f(_feb2b09976ab)._706430185536)
        _d764c207c4e8 = os._706430185536._b523bea2bb64(_7ddead2632f9, _51afc4f24985)

        # Skip download if file exists and redownload is False
        if os._706430185536._9284f1460c9f(_d764c207c4e8) and not _22498c22696f:
            self._8d44f296cce4._21506d1564b3(f"File already exists, skipping download: {_d764c207c4e8}")
        else:
            for _f732a48ee5d1 in _c089cb606a78(_98de4ea0a584):
                try:
                    with _c2dde3e939ab._bfcde41558d5(_feb2b09976ab, _0f1fe5bd7344=_17d1673a13eb, _5f1f9638623c=30) as _fb5d42aba0b5:
                        _fb5d42aba0b5._29ad30553b71()
                        with _dcad3a83311c(_d764c207c4e8, "wb") as _93a4fc473f66:
                            for _39fbaffd7e5b in _fb5d42aba0b5._0a97689b3076(_69cfd2b33ad0=8192):
                                if _39fbaffd7e5b:
                                    _93a4fc473f66._aa74a2799b93(_39fbaffd7e5b)
                    self._8d44f296cce4._21506d1564b3(f"Download complete: {_d764c207c4e8}")
                    break
                except (_c2dde3e939ab._c8e1a705803e._b4d6adc25cb3,
                        _c2dde3e939ab._c8e1a705803e._7bdcf79bef1b,
                        _c2dde3e939ab._c8e1a705803e._aeca2aedf725) as _e6868d957ec9:
                    self._8d44f296cce4._117022f18cf5(f"Download attempt {_f732a48ee5d1+1} failed: {_e6868d957ec9}")
                    if _f732a48ee5d1 < _98de4ea0a584 - 1:
                        time._aca4e5585e19(5)  # wait before retrying
                    else:
                        raise _5f4b7e62041c(f"Failed to download {_feb2b09976ab} after {_98de4ea0a584} attempts")

        # Extract ZIP
        with _9609ff748fdd._ff928eaa9921(_d764c207c4e8, "r") as _ead5410ddaff:
            _ead5410ddaff._9fdfd40ee5a2(_7ddead2632f9)

        # Find extracted folder containing .txt files (Native or Romanized)
        _015ae4af2c79 = _3b26fa5ba297
        for _93a4fc473f66 in os._c11f72deb956(_7ddead2632f9):
            _f646bb9238e5 = os._706430185536._b523bea2bb64(_7ddead2632f9, _93a4fc473f66)
            if os._706430185536._a214148c9e6b(_f646bb9238e5) and _927f0e081707(_66fba29f7e65._6e0b9b18d788(".txt") for _66fba29f7e65 in os._c11f72deb956(_f646bb9238e5)):
                _015ae4af2c79 = _f646bb9238e5
                break

        if not _015ae4af2c79:
            raise _5549e658bf0a("Could not find extracted folder with txt files")

        self._8d44f296cce4._21506d1564b3(f"Extracted txt files folder: {_015ae4af2c79}")

        # Return set of unique languages in the extracted folder
        return self._a3f037958687(_015ae4af2c79)


    def _b5129351768c(self, _28684c540788):
        """
        Extract unique languages (labels) from txt dataset files (train + valid).
        """
        _cd2eaa5fe70f = _22a581482307()
        for _0214c30718b8 in ["train_combine.txt", "valid_combine.txt"]:
            _493670d0e49f = os._706430185536._b523bea2bb64(_28684c540788, _0214c30718b8)
            if not os._706430185536._9284f1460c9f(_493670d0e49f):
                continue
            with _dcad3a83311c(_493670d0e49f, "r", _40de9d50ff23="utf-8") as _93a4fc473f66:
                for _3ceabb0f145b in _93a4fc473f66:
                    _3ceabb0f145b = _3ceabb0f145b._d98932615d99()
                    if not _3ceabb0f145b:
                        continue
                    _cd66c87f94a0 = _3ceabb0f145b._2067b8a6b5d8()[0]
                    if _cd66c87f94a0._efa638eea404("__label__"):
                        _cb85095ee930 = _cd66c87f94a0[_91a0293a9778("__label__"):]
                        _cd2eaa5fe70f._0c13a4caeed7(_cb85095ee930)
        return _cd2eaa5fe70f

    def _d83a4639c97a(self, _feb2b09976ab, _7ddead2632f9, _98de4ea0a584=3, _22498c22696f=_4142889f4409):
        import time
        self._8d44f296cce4._21506d1564b3(f"Preparing to download from {_feb2b09976ab} into {_7ddead2632f9}")
        os._60aebdbe6a19(_7ddead2632f9, _62713b703931=_17d1673a13eb)

        _51afc4f24985 = os._706430185536._e9d508c702c1(_b30ea1da417f(_feb2b09976ab)._706430185536)
        _d764c207c4e8 = os._706430185536._b523bea2bb64(_7ddead2632f9, _51afc4f24985)

        # Skip download if file exists and redownload is False
        if os._706430185536._9284f1460c9f(_d764c207c4e8) and not _22498c22696f:
            self._8d44f296cce4._21506d1564b3(f"File already exists, skipping download: {_d764c207c4e8}")
        else:
            for _f732a48ee5d1 in _c089cb606a78(_98de4ea0a584):
                try:
                    with _c2dde3e939ab._bfcde41558d5(_feb2b09976ab, _0f1fe5bd7344=_17d1673a13eb, _5f1f9638623c=30) as _fb5d42aba0b5:
                        _fb5d42aba0b5._29ad30553b71()
                        with _dcad3a83311c(_d764c207c4e8, 'wb') as _93a4fc473f66:
                            for _39fbaffd7e5b in _fb5d42aba0b5._0a97689b3076(_69cfd2b33ad0=8192):
                                if _39fbaffd7e5b:
                                    _93a4fc473f66._aa74a2799b93(_39fbaffd7e5b)
                    self._8d44f296cce4._21506d1564b3(f"Download complete: {_d764c207c4e8}")
                    break
                except (_c2dde3e939ab._c8e1a705803e._b4d6adc25cb3,
                        _c2dde3e939ab._c8e1a705803e._7bdcf79bef1b,
                        _c2dde3e939ab._c8e1a705803e._aeca2aedf725) as _e6868d957ec9:
                    self._8d44f296cce4._117022f18cf5(f"Download attempt {_f732a48ee5d1+1} failed: {_e6868d957ec9}")
                    if _f732a48ee5d1 < _98de4ea0a584 - 1:
                        time._aca4e5585e19(5)  # wait before retrying
                    else:
                        raise _5f4b7e62041c(f"Failed to download {_feb2b09976ab} after {_98de4ea0a584} attempts")

        # Extract ZIP
        with _9609ff748fdd._ff928eaa9921(_d764c207c4e8, 'r') as _ead5410ddaff:
            _ead5410ddaff._9fdfd40ee5a2(_7ddead2632f9)

        # Return JSON file path
        for _ed249585c95f in os._c11f72deb956(_7ddead2632f9):
            if _ed249585c95f._6e0b9b18d788('.json'):
                _493670d0e49f = os._706430185536._b523bea2bb64(_7ddead2632f9, _ed249585c95f)
                self._8d44f296cce4._21506d1564b3(f"Extracted JSON file: {_493670d0e49f}")
                return _493670d0e49f

        raise _5549e658bf0a("No JSON file found in extracted content.")

    def _e9b4e48fce55(self, _0ce10c3e1550: _fdaa01699ee7):
        try:
            _cb85095ee930 = _52f1dbbaf308._bfcde41558d5(_0ce10c3e1550)
            return _cb85095ee930._8ccc6890d2d6()
        except _ac3448c38e16:
            _de92a812d5c4 = _fdaa01699ee7(_0ce10c3e1550)._b16301413ba8()[:2]
            _6c89e4fd541a = _de92a812d5c4
            while _17d1673a13eb:
                try:
                    _cb85095ee930 = _52f1dbbaf308._bfcde41558d5(_de92a812d5c4)
                    if _cb85095ee930:
                        _de92a812d5c4 += "x"
                    else:
                        return _de92a812d5c4[:2]
                except _64250821c2a6:
                    return _6c89e4fd541a[:3]

    def _cb8a68ce1502(self, _0ef525fc6504: _44ca5d4c778f._e9b1543bc351, _302a8e284a92: _e6149217cd07):
        if _302a8e284a92 < 1.0:
            _0ef525fc6504 = _0ef525fc6504._bbea46b058d9(_36087c8a71a0=1, _e4fc6158c2b0=self._203a64c20a2b._d3f60f474e98._7f9a0d55b50e)
        _1cbce4a1a2c9 = _ea1e84ffc77c(_302a8e284a92 * _91a0293a9778(_0ef525fc6504))
        return _0ef525fc6504[:_1cbce4a1a2c9], _0ef525fc6504[_1cbce4a1a2c9:]

    def _94833350f7d1(self, _dcb793675acd):
        _ca610d6cf934 = _dcb793675acd._2067b8a6b5d8("-")[-1][:4]  # first 4 letters of last part
        if _ca610d6cf934 == "Maye": # Special Case
            return "Mei"
        return _ca610d6cf934
    
    def _0a5bf2f7cd62(self, _a1f8341f540b):
        _2045d989ade3 = _a1f8341f540b['unique_identifier']._2067b8a6b5d8('_')
        if _91a0293a9778(_2045d989ade3) > 2:
            _c781f8aacf6a = self._1fedac9bf368(_a1f8341f540b['script'])
            return _a1f8341f540b['language'] + "_" + _c781f8aacf6a
        else:
            return _a1f8341f540b['language']
    
    def _a6afb61b4bc2(self, _a1f8341f540b):
        if "Romanized Kashmiri" in _a1f8341f540b['language'] and "Kashmiri" in _a1f8341f540b['language_label']:
            return "Kashmiri"
        return _a1f8341f540b['language_label']
        
    def _fe8bef1ee611(self, _e1a3a6e06351: _fdaa01699ee7, _302a8e284a92: _e6149217cd07 = 0.0, _6023fb26bef9: _e6149217cd07 = 1.0):
        _980aee69dc43 = _151be86d7575()
        _f53e5ad5b071 = self._8b8db9386ff9
        _6084ad106a71 = os._706430185536._b523bea2bb64(self._edaef4e583d1, self._8b8db9386ff9 + ".json")

        with _dcad3a83311c(_6084ad106a71, "r+", _40de9d50ff23="utf8") as _ed249585c95f:
            _e40a5094f390 = json._53c5e1a860f6(_ed249585c95f)

        _613d8b7a0959 = _44ca5d4c778f._4eb73c4b39b0(_e40a5094f390["data"])
        # df["lang_code"] = df["unique_identifier"].parallel_apply(extract_lang_code)
        _613d8b7a0959 = _613d8b7a0959[_613d8b7a0959["language"]._4be5b3f88f08(self._46090656121c)] if _cfb9bc96ca6d(self, "select_languages", _3b26fa5ba297) else _613d8b7a0959
        _613d8b7a0959["language_label"] = _613d8b7a0959._e42dfbf11e70(self._658fae6c8bb5, _1b6986e4adbb=1)
        if _e1a3a6e06351._4303fd943dc3() == "romanized":
            _613d8b7a0959["language"] = _613d8b7a0959["language"]._e42dfbf11e70(lambda _214898ce6ca3: "Romanized " + _fdaa01699ee7(_214898ce6ca3))
       
        _613d8b7a0959["language_label"] = _613d8b7a0959._e42dfbf11e70(self._806d87c03216, _1b6986e4adbb=1)
        _613d8b7a0959["lang_code"] = _613d8b7a0959["language_label"]._740dd4d804d4(_22cdcd53a04d)

        _980aee69dc43._1688f4310ef7(_0782372de80c="metrics/data")

        if _e1a3a6e06351._4303fd943dc3() == "romanized":
            _613d8b7a0959["lang_code"] = _613d8b7a0959["lang_code"]._e42dfbf11e70(lambda _214898ce6ca3: _fdaa01699ee7(_214898ce6ca3) + "_en")

        self._e457a985af98(_613d8b7a0959, _e1a3a6e06351, _6023fb26bef9, _4a5d6fe778dc="original")

        _8da0d1bbfdc8 = "romanized" if _e1a3a6e06351 == "native" else "native"
        _ee5ecb32262e = [_760f4e05cd35 for _760f4e05cd35 in _613d8b7a0959._e1bb9f42cc3e if _8da0d1bbfdc8 in _760f4e05cd35]
        _613d8b7a0959._2f6368e770af(_ee5ecb32262e, _1b6986e4adbb=1, _ebeb36679bc6=_17d1673a13eb)
        _613d8b7a0959 = _613d8b7a0959[_613d8b7a0959[f'{_e1a3a6e06351} sentence']._b89be56d8f3f(_fdaa01699ee7)._fdaa01699ee7._d98932615d99() != '']

        for _1216ab12071e, _c75bd4148fdf in _613d8b7a0959._09cced846138("lang_code"):
            _0782372de80c = f"data/original/{_1216ab12071e}"
            _980aee69dc43._1688f4310ef7(_0782372de80c=_0782372de80c)
            _dcfea825fa8c = f"{_0782372de80c}/{self._8b8db9386ff9}_{_1216ab12071e}_{_e1a3a6e06351}_original_data.csv"
            _c75bd4148fdf._2c2f1e2e2b04(
                _dcfea825fa8c,
                _276b563c09e4="w+",
                _40de9d50ff23="utf8",
                _06929bbd1b50=_4142889f4409,
                _e7bcfc4e1b59=_5f9717bb94e1._a8f58cf1bc7c,
                _c77351e52213="\\",
            )
            self._8d44f296cce4._21506d1564b3(f"{_1216ab12071e} data written to {_dcfea825fa8c}")

        if self._615cfadec55c == "train" and _6023fb26bef9 not in [0.0, 1.0]:
            _67a0efe0994c = _28f7197472d6(_613d8b7a0959, 
                                          _e1a3a6e06351, 
                                          _6023fb26bef9,
                                          _7f9a0d55b50e=self._203a64c20a2b._d3f60f474e98._7f9a0d55b50e
                                          )
            _613d8b7a0959 = _67a0efe0994c._762fbd688617(_2f6368e770af=_17d1673a13eb)

        self._e457a985af98(_613d8b7a0959, _e1a3a6e06351, _6023fb26bef9, _4a5d6fe778dc="processed")

        if _302a8e284a92 == 0:
            self._8d44f296cce4._21506d1564b3(f"Started Processing {self._8b8db9386ff9} for {_e1a3a6e06351} sentences for {self._615cfadec55c} data.")
            _8e51dbfc3454 = os._706430185536._b523bea2bb64("data", self._615cfadec55c)
            _51fbd3d7ee73 = "test"
            self._b1369b7934b8(_8e51dbfc3454, _613d8b7a0959, _f53e5ad5b071, _51fbd3d7ee73, _e1a3a6e06351)
            self._8d44f296cce4._21506d1564b3(f"Completed Processing {self._8b8db9386ff9} for {_e1a3a6e06351} sentences for {self._615cfadec55c} data.")
        else:
            _54f4576655ea, _3dba5a572f11 = self._27deeb874f85(_613d8b7a0959, _302a8e284a92)
            for _2590e0aa9b19, _51fbd3d7ee73 in [(_54f4576655ea, "train"), (_3dba5a572f11, "val")]:
                self._8d44f296cce4._21506d1564b3(f"Started Processing {self._8b8db9386ff9} for {_e1a3a6e06351} sentences for {_51fbd3d7ee73} data.")
                _8e51dbfc3454 = os._706430185536._b523bea2bb64("data", _51fbd3d7ee73)
                self._b1369b7934b8(_8e51dbfc3454, _2590e0aa9b19, _f53e5ad5b071, _51fbd3d7ee73, _e1a3a6e06351)
                self._8d44f296cce4._21506d1564b3(f"Completed Processing {self._8b8db9386ff9} for {_e1a3a6e06351} sentences for {_51fbd3d7ee73} data.")

    def _85d8aef7fbff(self, _613d8b7a0959, _e1a3a6e06351, _6023fb26bef9, _4a5d6fe778dc):
        _613d8b7a0959[f"{_e1a3a6e06351}_length"] = _613d8b7a0959[f"{_e1a3a6e06351} sentence"]._e42dfbf11e70(lambda _214898ce6ca3: _91a0293a9778(_fdaa01699ee7(_214898ce6ca3)._2067b8a6b5d8()))
        _af4b6cc709ed = _613d8b7a0959._09cced846138(["lang_code", "language"])._35496ddb1b8f({
            f"{_e1a3a6e06351}_length": [
                lambda _214898ce6ca3: _214898ce6ca3[_214898ce6ca3 != 0]._c6d3cf95e1ba() if (_214898ce6ca3 != 0)._927f0e081707() else 0,
                lambda _214898ce6ca3: _214898ce6ca3[_214898ce6ca3 != 0]._8cf78077c8b4() if (_214898ce6ca3 != 0)._927f0e081707() else 0,
                lambda _214898ce6ca3: (_214898ce6ca3 != 0)._c1384429583e(),
            ],
        })
        _af4b6cc709ed._e1bb9f42cc3e = [f"{_e1a3a6e06351}_mean", f"{_e1a3a6e06351}_median", f"{_e1a3a6e06351}_count"]
        _4fedab613f79 = f"metrics/data/{self._8b8db9386ff9}_{_e1a3a6e06351}_{_4a5d6fe778dc}_{_ea1e84ffc77c(_6023fb26bef9*100)}_data_file_metrics.csv"
        _af4b6cc709ed._2c2f1e2e2b04(_4fedab613f79, _276b563c09e4="w+", _40de9d50ff23="utf8")

    def _0c79ee662de2(self, _8e51dbfc3454, _613d8b7a0959, _f53e5ad5b071, _51fbd3d7ee73, _e1a3a6e06351):
        for _da6bce26bbbf in _613d8b7a0959["language_label"]._12401dd53d1f():
            self._8d44f296cce4._21506d1564b3(f"Now Processing {self._8b8db9386ff9} for {_da6bce26bbbf} language.")
            _29cfba424d5b = _613d8b7a0959["language_label"]._46bff5ffbedc(_da6bce26bbbf)._886979e1f1cb()
            _1216ab12071e = _613d8b7a0959._aba97f67bd2f[_29cfba424d5b, "lang_code"]
            _178ba0c61f30 = _613d8b7a0959._aba97f67bd2f[_29cfba424d5b, "language_label"]._2067b8a6b5d8()[-1]._d98932615d99()

            _3f14c4183da0 = os._706430185536._b523bea2bb64(_8e51dbfc3454, _1216ab12071e)
            os._60aebdbe6a19(_3f14c4183da0, _62713b703931=_17d1673a13eb)
            _52558dca2736 = _613d8b7a0959[_613d8b7a0959["lang_code"] == _1216ab12071e][f"{_e1a3a6e06351} sentence"]._e6be535026de()
            _52558dca2736 = _52558dca2736[_52558dca2736._b89be56d8f3f(_fdaa01699ee7)._fdaa01699ee7._d98932615d99() != ""]

            _58faaaeae0da = os._706430185536._b523bea2bb64(_3f14c4183da0, "src")
            _62e5edafaa64 = os._706430185536._b523bea2bb64(_3f14c4183da0, "tgt")
            _2896d85a8d45 = self._16205d6980c6 if _e1a3a6e06351._4303fd943dc3() == "native" else self._f11bc9ca78da
            
            os._60aebdbe6a19(_58faaaeae0da, _62713b703931=_17d1673a13eb)
            os._60aebdbe6a19(_62e5edafaa64, _62713b703931=_17d1673a13eb)
            os._60aebdbe6a19(_2896d85a8d45, _62713b703931=_17d1673a13eb)

            _6084ad106a71 = os._706430185536._b523bea2bb64(_58faaaeae0da, f"{_1216ab12071e}_{_f53e5ad5b071}.src")
            _7ad213dc06f0 = os._706430185536._b523bea2bb64(_62e5edafaa64, f"{_1216ab12071e}_{_f53e5ad5b071}.tgt")
            _6af6533496b8 = "valid" if _51fbd3d7ee73._4303fd943dc3() == "val" else _51fbd3d7ee73
            _824790b73c55 = os._706430185536._b523bea2bb64(_2896d85a8d45, f"{_6af6533496b8}_combine.txt")

            with _dcad3a83311c(_6084ad106a71, "w", _40de9d50ff23="utf8") as _f31f2fa366d6,\
                    _dcad3a83311c(_7ad213dc06f0, "w", _40de9d50ff23="utf8") as _3724367c281f,\
                    _dcad3a83311c(_824790b73c55, "a+", _40de9d50ff23="utf8") as _767f008c9a1a:
                _f31f2fa366d6._aa74a2799b93("text\n")
                _3724367c281f._aa74a2799b93("lang_code\n")
                for _e146d13dbe40 in _c089cb606a78(0, _91a0293a9778(_52558dca2736), 1000):
                    _c8e7920dad82 = _52558dca2736[_e146d13dbe40:_e146d13dbe40+1000]
                    _19ffa0334d73 = [_1216ab12071e] * _91a0293a9778(_c8e7920dad82)
                    _647bf29625fb = [f"__label__{_178ba0c61f30}"] * _91a0293a9778(_c8e7920dad82)
                    for _f35e8a5013ed, _602d2e2aa95e, _ba29694414f2 in _79504793afc4(_c8e7920dad82, _19ffa0334d73, _647bf29625fb):
                        _f35e8a5013ed = _fdaa01699ee7(_f35e8a5013ed)._d98932615d99()
                        if _f35e8a5013ed and _f35e8a5013ed != "\n":
                            _f31f2fa366d6._aa74a2799b93(f"{_f35e8a5013ed}\n")
                            _3724367c281f._aa74a2799b93(f"{_602d2e2aa95e}\n")
                            _767f008c9a1a._aa74a2799b93(f"{_ba29694414f2} {_f35e8a5013ed}\n")

            self._8d44f296cce4._21506d1564b3(f"Files {_6084ad106a71} and {_7ad213dc06f0} with {_91a0293a9778(_52558dca2736)} samples have been created.")


def _e21915f53aca():
    _723036fa87b0._93278ad70e42(_20fb41f6b92d=_6808e389845e(1, math._c48dc8007f1c(os._bbfaee3d68c2() * 0.25)))
    _bb4e8639f3b6 = _925ba8528c1b._cbc0d67d7c75(_66c17ee6b8bd="Process Bhasha Abhijanaanam Dataset")
    _bb4e8639f3b6._0b01a7572cdc(
        "--config_file_path",
        _53a562786e1d=_fdaa01699ee7,
        _3a0d2b2e3ee2=_17d1673a13eb,
        _4d460a6c288c="Pass the yaml config file path",
    )
    try:
        _ff4d661ffbbe = _bb4e8639f3b6._3360b02ba93c()
        _203a64c20a2b = _44c2d060f2b0()._6802fe69e480(_c716a3ad7856=_ff4d661ffbbe._9b13be6ebab9)
        _8d44f296cce4 = _8af71d0e5dc6()._e47ce01212a9(_203a64c20a2b)
        _fb70927f7c72(_8d44f296cce4=_8d44f296cce4, _203a64c20a2b=_203a64c20a2b)
    except _925ba8528c1b._4e8041e60c15 as _e6868d957ec9:
        _6da961dcb068(f"Error: {_e6868d957ec9}")
        _bb4e8639f3b6._84243d3790e5()


if __name__ == "__main__":
    _2ee6c33f1df4()