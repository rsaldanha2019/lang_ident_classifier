# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : bhasha_dataset_to_csv
# @Time             : 20/12/23 9:45 am IST
---------------------------------------------------------
"""
import argparse
import csv
import math
import os
from logging import Logger
from urllib.parse import urlparse
import zipfile
from pandarallel import pandarallel
import pandas as pd
import json
import requests
from transformers import AutoTokenizer
from langcodes import Language
from lang_ident_classifier.language.utils.property_utils import PropertyUtils
from lang_ident_classifier.language.utils.log_utils import LogUtils
from lang_ident_classifier.language.utils.file_dir_utils import FileDirUtils

def extract_lang_code(unique_id):
    return "_".join(str(unique_id).split("_")[:-1])

def group_and_sample(df, script_type, frac):
    def inner_group(group):
        return group.sample(frac=frac)

    def outer_group(group):
        return group.groupby(f'{script_type}_length', group_keys=False).apply(inner_group)

    return df.groupby('lang_code', group_keys=False).apply(outer_group)

class BhashaDatasetProcessing:
    def __init__(self, log: Logger, props: PropertyUtils):
        self.train_url = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/parallel_romanized_train_data.zip"
        self.test_url = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/bhasha-abhijnaanam_test_set.zip"
        self.log = log
        self.props = props
        self.train_json_path = self._download_and_extract_json(self.train_url, target_dir="data/preprocessed/train")
        self.test_json_path = self._download_and_extract_json(self.test_url, target_dir="data/preprocessed/test")

        for stage in ['train', 'test']:
            json_file_path = self.train_json_path if stage == 'train' else self.test_json_path
            target_data_dir = "train" if stage == 'train' else "test"
            val_split_ratio = 0.8 if stage == 'train' else 0.0
            self.source_name = os.path.basename(json_file_path).split(".")[0]
            self.src_data_dir = os.path.dirname(json_file_path)
            self.target_data_dir = target_data_dir
            for script_type in ["native", "romanized"]:
                self._process_bhasha_dataset(script_type, val_split_ratio)

    def _download_and_extract_json(self, url, target_dir):
        self.log.info(f"Downloading from {url} into {target_dir}")
        os.makedirs(target_dir, exist_ok=True)

        filename = os.path.basename(urlparse(url).path)
        zip_path = os.path.join(target_dir, filename)

        with requests.get(url, stream=True) as r:
            with open(zip_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(target_dir)

        for file in os.listdir(target_dir):
            if file.endswith('.json'):
                file_path = os.path.join(target_dir, file)
                self.log.info(f"Download complete. File path {file_path}")
                return file_path

        raise FileNotFoundError("No JSON file found in extracted content.")

    def _get_iso_code(self, language_name: str):
        try:
            lang = Language.get(language_name)
            return lang.to_alpha3()
        except Exception:
            code = str(language_name).lower()[:2]
            original_code = code
            while True:
                try:
                    lang = Language.get(code)
                    if lang:
                        code += "x"
                    else:
                        return code[:2]
                except ValueError:
                    return original_code[:3]

    def _split_dataframe(self, df_data: pd.DataFrame, split_ratio: float):
        if split_ratio < 1.0:
            df_data = df_data.sample(frac=1, random_state=self.props.app.random_seed)
        split_index = int(split_ratio * len(df_data))
        return df_data[:split_index], df_data[split_index:]

    def _remove_empty_sentences(self, df: pd.DataFrame, script_type: str) -> pd.DataFrame:
        """
        Removes rows where sentences are empty or only whitespace.
        """
        filtered_df = df[df[f'{script_type} sentence'].str.strip().astype(bool)]
        return filtered_df

    def _remove_duplicates(self, df: pd.DataFrame, script_type: str) -> pd.DataFrame:
        """
        Removes duplicate sentences within the same language and returns metrics about retained and dropped sentences.
        """
        before_count = len(df)
        # Use both 'language' and the sentence column to identify duplicates
        filtered_df = df.drop_duplicates(subset=['language', f'{script_type} sentence'])
        after_count = len(filtered_df)
        dropped = before_count - after_count
        retained = after_count
        metrics = {
            'duplicate_sentence_removal': {
                'retained': retained,
                'dropped': dropped
            }
        }
        return filtered_df, metrics


    def _remove_train_test_overlap(self, df_train: pd.DataFrame, df_test: pd.DataFrame, script_type: str) -> pd.DataFrame:
        """
        Removes sentences from the training set that overlap with the test set for the same language.
        """
        # Merge on both 'language' and sentence column to identify overlaps
        overlap = df_train.merge(
            df_test[[f'{script_type} sentence', 'language']],
            on=[f'{script_type} sentence', 'language'],
            how='inner'
        )

        # Remove overlapping rows from training set
        df_train_cleaned = df_train.merge(
            overlap,
            on=df_train.columns.tolist(),
            how='left',
            indicator=True
        ).query("_merge == 'left_only'").drop(columns=['_merge'])

        metrics = {
            'test_train_overlap_sentence_removal': {
                'overlap_count': len(overlap),
                'remaining_train': len(df_train_cleaned)
            }
        }
        return df_train_cleaned, metrics


    def _process_bhasha_dataset(self, script_type: str, split_ratio: float = 0.0, data_sample_percent: float = 1.0):
        fdu = FileDirUtils()
        prefix = self.source_name
        src_file_path = os.path.join(self.src_data_dir, self.source_name + ".json")

        with open(src_file_path, "r+", encoding="utf8") as file:
            json_data = json.load(file)

        df = pd.json_normalize(json_data["data"])
        df["lang_code"] = df["unique_identifier"].parallel_apply(extract_lang_code)

        fdu.create_dir(dir_path="metrics/data")

        if script_type.casefold() == "romanized":
            df["lang_code"] = df["lang_code"].apply(lambda x: str(x) + "_en")
            df["language"] = df["language"].apply(lambda x: "Romanized " + str(x))

        self._get_data_metrics(df, script_type, data_sample_percent, action="original")

        subsrting_to_drop = "romanized" if script_type == "native" else "native"
        columns_to_drop = [col for col in df.columns if subsrting_to_drop in col]
        df.drop(columns_to_drop, axis=1, inplace=True)

        # Task 1: Remove empty sentences
        df_no_empty = self._remove_empty_sentences(df,script_type)
        fdu.create_dir("data/processed")
        df_no_empty.to_csv(f"data/processed/{self.source_name}_{script_type}_no_empty.csv", index=False, escapechar='\\', quoting=csv.QUOTE_ALL)


        # Task 2: Remove duplicates
        df_no_duplicates, duplicate_metrics = self._remove_duplicates(df_no_empty, script_type=script_type)
        df_no_duplicates.to_csv(f"data/processed/{self.source_name}_{script_type}_no_duplicates.csv", index=False, escapechar='\\', quoting=csv.QUOTE_ALL)

        # Task 3: Remove overlapping entries between train and test datasets
        if self.target_data_dir == "train":
            df_test = pd.read_csv(self.test_json_path)  # Loading test data
            df_train_no_overlap, overlap_metrics = self._remove_train_test_overlap(df_no_duplicates, df_test, script_type=script_type)
            df_train_no_overlap.to_csv(f"data/processed/{self.source_name}_{script_type}_train_no_overlap.csv", index=False, escapechar='\\', quoting=csv.QUOTE_ALL)
            metrics = {**duplicate_metrics, **overlap_metrics}
        else:
            metrics = duplicate_metrics

        self._get_data_metrics(df_no_duplicates, script_type, data_sample_percent, action="processed")

        self._write_data_to_files(f"data/processed/{script_type}", df_no_duplicates, prefix, script_type)

        metrics_path = f"metrics/data/{self.source_name}_{script_type}_metrics.csv"
        metrics_df = pd.DataFrame(metrics)
        metrics_df.to_csv(metrics_path, index=False)

    def _get_data_metrics(self, df, script_type, data_sample_percent, action):
        df[f"{script_type}_length"] = df[f"{script_type} sentence"].apply(lambda x: len(str(x).split()))
        grouped_df = df.groupby(["lang_code", "language"]).agg({
            f"{script_type}_length": [
                lambda x: x[x != 0].mean() if (x != 0).any() else 0,
                lambda x: x[x != 0].median() if (x != 0).any() else 0,
                lambda x: (x != 0).sum(),
            ],
        })
        grouped_df.columns = [f"{script_type}_mean", f"{script_type}_median", f"{script_type}_count"]
        metrics_path = f"metrics/data/{self.source_name}_{script_type}_{action}_{int(data_sample_percent*100)}_data_file_metrics.csv"
        grouped_df.to_csv(metrics_path, mode="w+", encoding="utf8")

    def _write_data_to_files(self, dest_dir, df, prefix, script_type):
        for language in df["language"].unique():
            self.log.info(f"Now Processing {self.source_name} for {language} language.")
            first_idx = df["language"].eq(language).idxmax()
            lang_code = df.loc[first_idx, "lang_code"]

            lang_folder = os.path.join(dest_dir, lang_code)
            os.makedirs(lang_folder, exist_ok=True)
            filtered_data = df[df["lang_code"] == lang_code][f"{script_type} sentence"].dropna()
            filtered_data = filtered_data[filtered_data.astype(str).str.strip() != ""]

            src_dir = os.path.join(lang_folder, "src")
            tgt_dir = os.path.join(lang_folder, "tgt")
            os.makedirs(src_dir, exist_ok=True)
            os.makedirs(tgt_dir, exist_ok=True)

            src_file_path = os.path.join(src_dir, f"{lang_code}_{prefix}.src")
            tgt_file_path = os.path.join(tgt_dir, f"{lang_code}_{prefix}.tgt")

            with open(src_file_path, "w", encoding="utf8") as src_file, open(tgt_file_path, "w", encoding="utf8") as tgt_file:
                src_file.write("text\n")
                tgt_file.write("lang_code\n")
                for i in range(0, len(filtered_data), 1000):
                    chunk_src = filtered_data[i:i+1000]
                    chunk_tgt = [lang_code] * len(chunk_src)
                    for src_text, tgt_text in zip(chunk_src, chunk_tgt):
                        src_text = str(src_text).strip()
                        if src_text and src_text != "\n":
                            src_file.write(f"{src_text}\n")
                            tgt_file.write(f"{tgt_text}\n")

            self.log.info(f"Files {src_file_path} and {tgt_file_path} with {len(filtered_data)} samples have been created.")

def main():
    pandarallel.initialize(nb_workers=max(1, math.floor(os.cpu_count() * 0.25)))
    parser = argparse.ArgumentParser(description="Process Bhasha Abhijanaanam Dataset")
    parser.add_argument(
        "--config_file_path",
        type=str,
        required=True,
        help="Pass the yaml config file path",
    )
    try:
        args = parser.parse_args()
        props = PropertyUtils().get_yaml_config_properties(config_file=args.config_file_path)
        log = LogUtils().get_time_rotated_log(props)
        BhashaDatasetProcessing(log=log, props=props)
    except argparse.ArgumentError as e:
        print(f"Error: {e}")
        parser.print_help()

if __name__ == "__main__":
    main()
