# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : process_bhasha_dataset.py
# @Time             : 2025-10-31 09:09 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _e213a153b401
import _d75e19639b16
import math
import os
from _ddc720ee2f9f import _22447eaf23d0
from urllib._3b73503c11b2 import _13f29280b73d
import _5755d8504508
from _ff84b983ea05 import _ff84b983ea05
import _30209824ead7 as _6ae80e179d1a
import json
import _72ac738d965a
from _47c19b40b2ad import _cdf5dadff8fb
from _842c44543978 import _a3067fe67847
from _1eaa382ef182._a3bfc24bb131._bd6e000a6b37._104bef22484c import _3ceef10a65c3
from _1eaa382ef182._a3bfc24bb131._bd6e000a6b37._593066ceb624 import _1222c7f5f086
from _1eaa382ef182._a3bfc24bb131._bd6e000a6b37._9055c0cda12b import _78f21992428e
import hashlib

_84d2add6b094 = {}

# Function to extract language code
def _68d04b19ad37(_a3bfc24bb131):
    _aa3b072a9d93 = _a3bfc24bb131._042134b4272e()._1fab5a4fb21c()

    # Split compound languages
    _b67906b4ae9b = _aa3b072a9d93._20b005753fb4("_")

    # Take first 3 letters of each part
    _9d81944e8a1b = [_54d5dcca743b[:3] for _54d5dcca743b in _b67906b4ae9b]
    _bb681e9f5ca3 = "_"._2ed4b8af2418(_9d81944e8a1b)
    _eddec76167ba = _bb681e9f5ca3
    _4882b2335359 = 1

    # If language already has a code, return it
    if _a3bfc24bb131 in _84d2add6b094:
        return _84d2add6b094[_a3bfc24bb131]

    # Find a unique code that isn't already assigned to a different language
    while _eddec76167ba in _84d2add6b094._d2120f24b343():
        if _8e04ed84e62e(_ade3595046e5 != _a3bfc24bb131 and _0ed1f7fe9343 == _eddec76167ba for _ade3595046e5, _0ed1f7fe9343 in _84d2add6b094._a07bc57829f7()):
            _eddec76167ba = f"{_bb681e9f5ca3}{_4882b2335359}"
            _4882b2335359 += 1
        else:
            break

    _84d2add6b094[_a3bfc24bb131] = _eddec76167ba
    return _eddec76167ba

# Helper function for grouping and sampling
def _1595b7f6345e(_471f02575c32, _bd1ae5258013, _2645c2509282, _fe30528e7bcf=20):
    def _923f7805c032(_ad6f9b9fe905):
        return _ad6f9b9fe905._7a10165bffb1(_2645c2509282=_2645c2509282, _e9670a95e262=_fe30528e7bcf)

    def _1f19afac2b1b(_ad6f9b9fe905):
        return _ad6f9b9fe905._1f7d7e005229(f'{_bd1ae5258013}_length', _75dcf70dfe8e=_45770da360e5)._d2de0e9c910f(_29e443b2e6fb)

    return _471f02575c32._1f7d7e005229('lang_code', _75dcf70dfe8e=_45770da360e5)._d2de0e9c910f(_c90e9f82dd35)

# Class for dataset processing
class _5ce4005923d9:
    def _9289400f7e79(self, _683bcac7c407: _22447eaf23d0, _00a79e47252e: _3ceef10a65c3):
        self._28cac61f58ce = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/parallel_romanized_train_data.zip"
        self._1596e6419f7b = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/bhasha-abhijnaanam_test_set.zip"
        self._683bcac7c407 = _683bcac7c407
        self._00a79e47252e = _00a79e47252e
        self._72d44bb6fce9 = _0726e74cb320(_0726e74cb320(self._00a79e47252e, "dataset", _c42b725c4f49), "dataset_source_dir", "bhasha")
        self._7da4facccf4e = self._91feecf483a5(self._28cac61f58ce, _fca7dbec2dc4=f"data/{self._72d44bb6fce9}/preprocessed/train")
        self._7ab840995994 = self._91feecf483a5(self._1596e6419f7b, _fca7dbec2dc4=f"data/{self._72d44bb6fce9}/preprocessed/test")
        self._3a6751fccf51 = _0726e74cb320(_0726e74cb320(self._00a79e47252e, "dataset", _c42b725c4f49), "dataset_share", 1.0)
        self._5f461de203a1 = _0726e74cb320(_0726e74cb320(self._00a79e47252e, "dataset", _c42b725c4f49), "select_languages", [])
        self._7881742f88a3 = f"data/{self._72d44bb6fce9}/filtered/native"
        self._e5dd7276daeb = f"data/{self._72d44bb6fce9}/filtered/romanized"

        # Extract languages from JSON
        _2e4a9cac78d1 = self._14b8faf2308f(self._7da4facccf4e)

        # Extract languages from txt files
        _6331c2579355 = os._8e9639e9f94b._2ed4b8af2418("data", self._72d44bb6fce9, "native_script_train_valid_data", "Native_script_data")
        _ac021a72b7e0 = os._8e9639e9f94b._2ed4b8af2418("data", self._72d44bb6fce9, "roman_script_train_valid_data", "Roman_script_data")

        _50d32b8ad684 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/native_script_train_valid_data.zip"
        _82c3a9c37398 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/roman_script_train_valid_data.zip"

        _ebdb2eec8854 = self._7bd98b0dfd9a(_50d32b8ad684, f"data/{self._72d44bb6fce9}/native_script_train_valid_data")
        _0426434fd085 = self._7bd98b0dfd9a(_82c3a9c37398, f"data/{self._72d44bb6fce9}/roman_script_train_valid_data")

        # Combine all txt languages
        _6504e680537f = _ebdb2eec8854._610f7d91ba34(_0426434fd085)

        # === NEW: interpret select_languages empty or ['All'] as "use all languages" ===
        # normalize incoming select_languages
        try:
            _08ff9a8e4231 = self._5f461de203a1 if self._5f461de203a1 is not _c42b725c4f49 else []
        except _13200e8abd72:
            _08ff9a8e4231 = []
        # if user passed ['All'] (case-insensitive) or empty list -> set to all discovered languages (union of JSON + TXT)
        _6565b3656ec2 = _f95c703cfef3(_6504e680537f) | _f95c703cfef3(_2e4a9cac78d1)
        if (_bc48c67ec49d(_08ff9a8e4231, (_c769ae50d8c3, _6a4924210f36)) and _d8115e52957c(_08ff9a8e4231) == 1 and _0526d423f19f(_08ff9a8e4231[0])._1fab5a4fb21c()._042134b4272e() == "all") or (not _08ff9a8e4231):
            self._5f461de203a1 = _c7e5f74d692a(_6565b3656ec2)
            self._683bcac7c407._069eba56b4bc("select_languages was empty or ['All'] — using all discovered languages (%d).", _d8115e52957c(self._5f461de203a1))
        else:
            # otherwise keep only languages that actually exist in discovered sets
            self._5f461de203a1 = [_cdaaf365fe5e for _cdaaf365fe5e in _08ff9a8e4231 if _cdaaf365fe5e in _6565b3656ec2]
            self._683bcac7c407._069eba56b4bc("Using user-provided select_languages filtered to discovered languages (%d): %s", _d8115e52957c(self._5f461de203a1), self._5f461de203a1)

        # If user previously expected the old logic below (narrowing), keep it consistent:
        if self._5f461de203a1:
            _6504e680537f = [_cdaaf365fe5e for _cdaaf365fe5e in self._5f461de203a1 if _cdaaf365fe5e in _6504e680537f]
            _2e4a9cac78d1 = [_cdaaf365fe5e for _cdaaf365fe5e in self._5f461de203a1 if _cdaaf365fe5e in _2e4a9cac78d1]

        # Find missing languages in JSON compared to txt datasets
        _bab785bb1c08 = _c769ae50d8c3(_f95c703cfef3(_6504e680537f) - _f95c703cfef3(_2e4a9cac78d1))
        self._683bcac7c407._069eba56b4bc(f"Languages in JSON: {_2e4a9cac78d1}")
        self._683bcac7c407._069eba56b4bc(f"Languages in TXT: {_6504e680537f}")
        self._683bcac7c407._069eba56b4bc(f"Missing languages to load from TXT: {_bab785bb1c08}")

        # Now process only missing languages from TXT files
        if _bab785bb1c08:
            self._20418725aeca(_6331c2579355, "native", _bab785bb1c08, self._3a6751fccf51)
            self._20418725aeca(_ac021a72b7e0, "romanized", _bab785bb1c08, self._3a6751fccf51)

            self._34f09fa6b240(_bab785bb1c08)

        for _f66930f981f8 in ['train', 'test']:
            _e19b5dc59e95 = self._7da4facccf4e if _f66930f981f8 == 'train' else self._7ab840995994
            _4d4c4fd3564e = "train" if _f66930f981f8 == 'train' else "test"
            _1691bb73a527 = 0.8 if _f66930f981f8 == 'train' else 0.0
            self._fc1dd76f2854 = os._8e9639e9f94b._fb175782a757(_e19b5dc59e95)._20b005753fb4(".")[0]
            self._6a18bf4f2b5d = os._8e9639e9f94b._7bb0d93d4ddc(_e19b5dc59e95)
            self._4d4c4fd3564e = _4d4c4fd3564e
            for _bd1ae5258013 in ["native", "romanized"]:
                self._bb423ec8d991(_bd1ae5258013, _1691bb73a527, self._3a6751fccf51)

    # Process missing language CSVs
    def _6089a8022eea(self, _bab785bb1c08, _5f461de203a1=_c42b725c4f49):
        _aa57731cb049 = os._8e9639e9f94b._2ed4b8af2418("data", self._72d44bb6fce9 ,"original")

        for _aa3b072a9d93 in _bab785bb1c08:
            _c09dbd59ca25 = os._8e9639e9f94b._2ed4b8af2418(_aa57731cb049, _ed4f3d343580(_aa3b072a9d93))
            if not os._8e9639e9f94b._800bf5db4dfc(_c09dbd59ca25):
                self._683bcac7c407._05375f461d98(f"Missing original data directory not found for language: {_aa3b072a9d93}")
                continue

            for _bd1ae5258013 in ["native", "romanized"]:
                # Detect CSV files for this language
                for _7ccab070c837 in os._9f49499c98dd(_c09dbd59ca25):
                    if not _7ccab070c837._fc95cc047085(".csv"):
                        continue
                    if _ed4f3d343580(_aa3b072a9d93) not in _7ccab070c837 or _bd1ae5258013 not in _7ccab070c837:
                        continue

                    # Determine destination based on CSV name (train or val)
                    _ed8204c46057 = "train" if "train" in _7ccab070c837 else "val"
                    _d6b923ef646d = os._8e9639e9f94b._2ed4b8af2418("data", self._72d44bb6fce9, _ed8204c46057)

                    _39bc1799ee2b = os._8e9639e9f94b._2ed4b8af2418(_c09dbd59ca25, _7ccab070c837)
                    _471f02575c32 = _6ae80e179d1a._9700c602b4f2(_39bc1799ee2b, _1fd782f48bfb=_d75e19639b16._6d4f7bdc1213, _c5a13edc8682="\\")

                    _62c16587f6b6 = f"{_bd1ae5258013} sentence"
                    if _62c16587f6b6 not in _471f02575c32._f57aa2535da3:
                        self._683bcac7c407._05375f461d98(f"{_62c16587f6b6} column missing in {_39bc1799ee2b}, skipping.")
                        continue

                    _471f02575c32 = _471f02575c32[_471f02575c32[_62c16587f6b6]._bdddface4285(_0526d423f19f)._0526d423f19f._1fab5a4fb21c() != ""]
                    if _471f02575c32._5c178e6d157f:
                        self._683bcac7c407._05375f461d98(f"No valid rows found for {_aa3b072a9d93} {_bd1ae5258013} in {_39bc1799ee2b}")
                        continue

                    _e46c7d3b9a21 = _471f02575c32["lang_code"]._309b95cba8f1[0]

                    _026580f80ddf = os._8e9639e9f94b._2ed4b8af2418(_d6b923ef646d, _e46c7d3b9a21)
                    os._9806ee9bca9f(_026580f80ddf, _84e3dffb6038=_362bc6eeb2af)

                    _c66ad9e3008e = os._8e9639e9f94b._2ed4b8af2418(_026580f80ddf, "src")
                    _c2875ed7d2eb = os._8e9639e9f94b._2ed4b8af2418(_026580f80ddf, "tgt")
                    os._9806ee9bca9f(_c66ad9e3008e, _84e3dffb6038=_362bc6eeb2af)
                    os._9806ee9bca9f(_c2875ed7d2eb, _84e3dffb6038=_362bc6eeb2af)

                    _6951f8370a8a = f"txt_{_bd1ae5258013}"
                    _1ec4d57fa5c8 = self._7881742f88a3 if _bd1ae5258013._948fc04b9ea7() == "native" else self._e5dd7276daeb
                    os._9806ee9bca9f(_1ec4d57fa5c8, _84e3dffb6038=_362bc6eeb2af)

                    _1cba4c62bf34 = os._8e9639e9f94b._2ed4b8af2418(_c66ad9e3008e, f"{_e46c7d3b9a21}_{_6951f8370a8a}.src")
                    _234c82153309 = os._8e9639e9f94b._2ed4b8af2418(_c2875ed7d2eb, f"{_e46c7d3b9a21}_{_6951f8370a8a}.tgt")
                    _ac406dc28482 = "valid" if _ed8204c46057._948fc04b9ea7() == "val" else _ed8204c46057
                    _9521b2715a3f = os._8e9639e9f94b._2ed4b8af2418(_1ec4d57fa5c8, f"{_ac406dc28482}_combine.txt")

                    with _21d6d8241eeb(_1cba4c62bf34, "w", _634b7f7f2bee="utf-8") as _584e9a57d663, \
                            _21d6d8241eeb(_234c82153309, "w", _634b7f7f2bee="utf-8") as _a0e3b4af56c0, \
                            _21d6d8241eeb(_9521b2715a3f, "a+", _634b7f7f2bee="utf-8") as _3e087476bb13:
                        _584e9a57d663._e038b2ed0bb0("text\n")
                        _a0e3b4af56c0._e038b2ed0bb0("lang_code\n")

                        for _bbb2997ac8c9 in _471f02575c32[_62c16587f6b6]:
                            _bbb2997ac8c9 = _0526d423f19f(_bbb2997ac8c9)._1fab5a4fb21c()
                            if _bbb2997ac8c9 and _bbb2997ac8c9 != "\n":
                                _3e087476bb13._e038b2ed0bb0(f"__label__{_aa3b072a9d93} {_bbb2997ac8c9}\n")
                                _584e9a57d663._e038b2ed0bb0(f"{_bbb2997ac8c9}\n")
                                _a0e3b4af56c0._e038b2ed0bb0(f"{_e46c7d3b9a21}\n")

                    self._683bcac7c407._069eba56b4bc(f"Written {_d8115e52957c(_471f02575c32)} rows to {_1cba4c62bf34} and {_234c82153309}")

    # Extract languages from JSON file
    def _960d1e7fc553(self, _e19b5dc59e95):
        with _21d6d8241eeb(_e19b5dc59e95, "r", _634b7f7f2bee="utf-8") as _8c56e7d11250:
            _2e298b42ddc5 = json._8e84ec86ef11(_8c56e7d11250)
        _90edcfddc042 = _f95c703cfef3()
        for _7978813b1afe in _2e298b42ddc5._becdfe1fc05f("data", []):
            _aa3b072a9d93 = _7978813b1afe._becdfe1fc05f("language")
            if _aa3b072a9d93:
                _90edcfddc042._adb8a92cdde8(_aa3b072a9d93)
        return _90edcfddc042

    # Process missing languages from TXT files
    def _e7b4cc5349a7(self, _c93741728b2e, _bd1ae5258013, _bab785bb1c08, _3a6751fccf51=1.0):
        _da66b2ca4aec = _78f21992428e()

        for _3b264d578993, _ecf78574149d in [("train_combine.txt", "train"), ("valid_combine.txt", "val")]:
            _0b991f1b91e4 = os._8e9639e9f94b._2ed4b8af2418(_c93741728b2e, _3b264d578993)
            if not os._8e9639e9f94b._800bf5db4dfc(_0b991f1b91e4):
                self._683bcac7c407._05375f461d98(f"File {_0b991f1b91e4} not found, skipping.")
                continue

            _1eb0cb1c2396 = []
            with _21d6d8241eeb(_0b991f1b91e4, "r", _634b7f7f2bee="utf-8") as _8c56e7d11250:
                for _938bb16760e6 in _8c56e7d11250:
                    _938bb16760e6 = _938bb16760e6._1fab5a4fb21c()
                    if not _938bb16760e6:
                        continue
                    _b67906b4ae9b = _938bb16760e6._20b005753fb4(_83e248f8291b=1)
                    if _d8115e52957c(_b67906b4ae9b) < 2:
                        continue
                    _08e91ad2c6ef, _bbb2997ac8c9 = _b67906b4ae9b
                    if _08e91ad2c6ef._b7bbfc1b8418("__label__"):
                        _aa3b072a9d93 = _08e91ad2c6ef[_d8115e52957c("__label__"):]
                        if _aa3b072a9d93 in _bab785bb1c08:
                            _1eb0cb1c2396._23b607854449({
                                f"{_bd1ae5258013} sentence": _bbb2997ac8c9,
                                f"{_bd1ae5258013}_length": _0526d423f19f(_bbb2997ac8c9)._1fab5a4fb21c()._20b005753fb4()._225297b729b2(),
                                "language": _aa3b072a9d93,
                                "lang_code": _ed4f3d343580(_aa3b072a9d93),
                            })

            if not _1eb0cb1c2396:
                self._683bcac7c407._069eba56b4bc(f"No missing language data found in {_0b991f1b91e4} for script {_bd1ae5258013}.")
                continue

            _471f02575c32 = _6ae80e179d1a._57dd6da45043(_1eb0cb1c2396)
            _471f02575c32 = _471f02575c32[_471f02575c32[f"{_bd1ae5258013} sentence"]._bdddface4285(_0526d423f19f)._0526d423f19f._1fab5a4fb21c() != '']

            # Sample data if needed
            if _3a6751fccf51 not in [0.0, 1.0]:
                _471f02575c32 = _cd3de89f1fcb(_471f02575c32=_471f02575c32, 
                                      _bd1ae5258013=_bd1ae5258013, 
                                      _2645c2509282=self._3a6751fccf51,
                                      _fe30528e7bcf=self._00a79e47252e._54c4ceb37aca._fe30528e7bcf)

            # Write separate CSV per language per split
            for _e46c7d3b9a21, _56ce9a073abf in _471f02575c32._1f7d7e005229("lang_code"):
                # Skip if this group corresponds to English
                if _bd1ae5258013._948fc04b9ea7()=="romanized" and _56ce9a073abf["language"]._309b95cba8f1[0] == "English":
                    continue
                _5a9761190686 = f"data/{self._72d44bb6fce9}/original/{_e46c7d3b9a21}"
                _da66b2ca4aec._38c3e95cd2a9(_5a9761190686=_5a9761190686)
                _6687334f39c2 = f"{_5a9761190686}/txt_{_bd1ae5258013}_{_e46c7d3b9a21}_{_ecf78574149d}_original_data.csv"
                _56ce9a073abf._1235f3e6a1fc(
                    _6687334f39c2,
                    _f855cfafcfb6="w+",
                    _634b7f7f2bee="utf8",
                    _4589aa886280=_45770da360e5,
                    _1fd782f48bfb=_d75e19639b16._6d4f7bdc1213,
                    _c5a13edc8682="\\",
                )
                self._683bcac7c407._069eba56b4bc(f"Missing {_e46c7d3b9a21} data ({_ecf78574149d}) written to {_6687334f39c2}")

    # Download and extract languages from txt file
    def _82246c407545(self, _9f9ab823f187, _fca7dbec2dc4, _30f5eb29d81c=3, _f0541f93b325=_45770da360e5):
        import time
        import _72ac738d965a, _5755d8504508, os
        from urllib._3b73503c11b2 import _13f29280b73d

        self._683bcac7c407._069eba56b4bc(f"Preparing to download from {_9f9ab823f187} into {_fca7dbec2dc4}")
        os._9806ee9bca9f(_fca7dbec2dc4, _84e3dffb6038=_362bc6eeb2af)

        _5bf39a7f9e09 = os._8e9639e9f94b._fb175782a757(_13f29280b73d(_9f9ab823f187)._8e9639e9f94b)
        _70281fc703fc = os._8e9639e9f94b._2ed4b8af2418(_fca7dbec2dc4, _5bf39a7f9e09)

        # Skip download if file exists and redownload is False
        if os._8e9639e9f94b._800bf5db4dfc(_70281fc703fc) and not _f0541f93b325:
            self._683bcac7c407._069eba56b4bc(f"File already exists, skipping download: {_70281fc703fc}")
        else:
            for _4a80d6aad28a in _eea7255e3aea(_30f5eb29d81c):
                try:
                    with _72ac738d965a._becdfe1fc05f(_9f9ab823f187, _f5a711043453=_362bc6eeb2af, _eca287989f7e=30) as _d9998450e01d:
                        _d9998450e01d._b1f633d6180e()
                        with _21d6d8241eeb(_70281fc703fc, "wb") as _8c56e7d11250:
                            for _49880cf2b40d in _d9998450e01d._6aee03391c9b(_44315dd7f9a0=8192):
                                if _49880cf2b40d:
                                    _8c56e7d11250._e038b2ed0bb0(_49880cf2b40d)
                    self._683bcac7c407._069eba56b4bc(f"Download complete: {_70281fc703fc}")
                    break
                except (_72ac738d965a._632b3346d0c8._fe56cae8a0b0,
                        _72ac738d965a._632b3346d0c8._7b8330829e39,
                        _72ac738d965a._632b3346d0c8._0c95cb775d19) as _6d2d7ea298e3:
                    self._683bcac7c407._05375f461d98(f"Download attempt {_4a80d6aad28a+1} failed: {_6d2d7ea298e3}")
                    if _4a80d6aad28a < _30f5eb29d81c - 1:
                        time._52ce71dd5b2a(5)  # wait before retrying
                    else:
                        raise _630054f1913a(f"Failed to download {_9f9ab823f187} after {_30f5eb29d81c} attempts")

        # Extract ZIP
        with _5755d8504508._b60e4b7b91f5(_70281fc703fc, "r") as _857c57895efc:
            _857c57895efc._d1c36c9fc869(_fca7dbec2dc4)

        # Find extracted folder containing .txt files (Native or Romanized)
        _60651567b4cd = _c42b725c4f49
        for _8c56e7d11250 in os._9f49499c98dd(_fca7dbec2dc4):
            _d82049160449 = os._8e9639e9f94b._2ed4b8af2418(_fca7dbec2dc4, _8c56e7d11250)
            if os._8e9639e9f94b._8e2ba6178532(_d82049160449) and _8e04ed84e62e(_1563dc5f69d1._fc95cc047085(".txt") for _1563dc5f69d1 in os._9f49499c98dd(_d82049160449)):
                _60651567b4cd = _d82049160449
                break

        if not _60651567b4cd:
            raise _6166db9d637d("Could not find extracted folder with txt files")

        self._683bcac7c407._069eba56b4bc(f"Extracted txt files folder: {_60651567b4cd}")

        # Return set of unique languages in the extracted folder
        return self._8771479c2f30(_60651567b4cd)

    # Extract languages from a txt folder
    def _9042afecdbff(self, _c93741728b2e):
        _90edcfddc042 = _f95c703cfef3()
        for _3b264d578993 in ["train_combine.txt", "valid_combine.txt"]:
            _0b991f1b91e4 = os._8e9639e9f94b._2ed4b8af2418(_c93741728b2e, _3b264d578993)
            if not os._8e9639e9f94b._800bf5db4dfc(_0b991f1b91e4):
                continue
            with _21d6d8241eeb(_0b991f1b91e4, "r", _634b7f7f2bee="utf-8") as _8c56e7d11250:
                for _938bb16760e6 in _8c56e7d11250:
                    _938bb16760e6 = _938bb16760e6._1fab5a4fb21c()
                    if not _938bb16760e6:
                        continue
                    _08e91ad2c6ef = _938bb16760e6._20b005753fb4()[0]
                    if _08e91ad2c6ef._b7bbfc1b8418("__label__"):
                        _aa3b072a9d93 = _08e91ad2c6ef[_d8115e52957c("__label__"):]
                        _90edcfddc042._adb8a92cdde8(_aa3b072a9d93)
        return _90edcfddc042

    def _9bf8b607526b(self, _9f9ab823f187, _fca7dbec2dc4, _30f5eb29d81c=3, _f0541f93b325=_45770da360e5):
        import time
        self._683bcac7c407._069eba56b4bc(f"Preparing to download from {_9f9ab823f187} into {_fca7dbec2dc4}")
        os._9806ee9bca9f(_fca7dbec2dc4, _84e3dffb6038=_362bc6eeb2af)

        _5bf39a7f9e09 = os._8e9639e9f94b._fb175782a757(_13f29280b73d(_9f9ab823f187)._8e9639e9f94b)
        _70281fc703fc = os._8e9639e9f94b._2ed4b8af2418(_fca7dbec2dc4, _5bf39a7f9e09)

        # Skip download if file exists and redownload is False
        if os._8e9639e9f94b._800bf5db4dfc(_70281fc703fc) and not _f0541f93b325:
            self._683bcac7c407._069eba56b4bc(f"File already exists, skipping download: {_70281fc703fc}")
        else:
            for _4a80d6aad28a in _eea7255e3aea(_30f5eb29d81c):
                try:
                    with _72ac738d965a._becdfe1fc05f(_9f9ab823f187, _f5a711043453=_362bc6eeb2af, _eca287989f7e=30) as _d9998450e01d:
                        _d9998450e01d._b1f633d6180e()
                        with _21d6d8241eeb(_70281fc703fc, 'wb') as _8c56e7d11250:
                            for _49880cf2b40d in _d9998450e01d._6aee03391c9b(_44315dd7f9a0=8192):
                                if _49880cf2b40d:
                                    _8c56e7d11250._e038b2ed0bb0(_49880cf2b40d)
                    self._683bcac7c407._069eba56b4bc(f"Download complete: {_70281fc703fc}")
                    break
                except (_72ac738d965a._632b3346d0c8._fe56cae8a0b0,
                        _72ac738d965a._632b3346d0c8._7b8330829e39,
                        _72ac738d965a._632b3346d0c8._0c95cb775d19) as _6d2d7ea298e3:
                    self._683bcac7c407._05375f461d98(f"Download attempt {_4a80d6aad28a+1} failed: {_6d2d7ea298e3}")
                    if _4a80d6aad28a < _30f5eb29d81c - 1:
                        time._52ce71dd5b2a(5)  # wait before retrying
                    else:
                        raise _630054f1913a(f"Failed to download {_9f9ab823f187} after {_30f5eb29d81c} attempts")

        # Extract ZIP
        with _5755d8504508._b60e4b7b91f5(_70281fc703fc, 'r') as _857c57895efc:
            _857c57895efc._d1c36c9fc869(_fca7dbec2dc4)

        # Return JSON file path
        for _063272c309e8 in os._9f49499c98dd(_fca7dbec2dc4):
            if _063272c309e8._fc95cc047085('.json'):
                _0b991f1b91e4 = os._8e9639e9f94b._2ed4b8af2418(_fca7dbec2dc4, _063272c309e8)
                self._683bcac7c407._069eba56b4bc(f"Extracted JSON file: {_0b991f1b91e4}")
                return _0b991f1b91e4

        raise _6166db9d637d("No JSON file found in extracted content.")

    def _cc53f664982d(self, _03ff44cc7340: _0526d423f19f):
        try:
            _aa3b072a9d93 = _a3067fe67847._becdfe1fc05f(_03ff44cc7340)
            return _aa3b072a9d93._a773ee1147c0()
        except _13200e8abd72:
            _eddec76167ba = _0526d423f19f(_03ff44cc7340)._042134b4272e()[:2]
            _800b3c03db35 = _eddec76167ba
            while _362bc6eeb2af:
                try:
                    _aa3b072a9d93 = _a3067fe67847._becdfe1fc05f(_eddec76167ba)
                    if _aa3b072a9d93:
                        _eddec76167ba += "x"
                    else:
                        return _eddec76167ba[:2]
                except _e9b07beb9634:
                    return _800b3c03db35[:3]

    def _d66484cc3a3f(self, _18d3d23610ac: _6ae80e179d1a._57dd6da45043, _c8868ec2ea5c: _c2e0c9bcc6b8):
        if _c8868ec2ea5c < 1.0:
            _18d3d23610ac = _18d3d23610ac._7a10165bffb1(_2645c2509282=1, _e9670a95e262=self._00a79e47252e._54c4ceb37aca._fe30528e7bcf)
        _f330c23a7c31 = _9e3822a4d559(_c8868ec2ea5c * _d8115e52957c(_18d3d23610ac))
        return _18d3d23610ac[:_f330c23a7c31], _18d3d23610ac[_f330c23a7c31:]

    def _4f1322454680(self, _4979f4d2e354):
        _3c90687c146a = _4979f4d2e354._20b005753fb4("-")[-1][:4]  # first 4 letters of last part
        if _3c90687c146a == "Maye":  # Special Case
            return "Mei"
        return _3c90687c146a

    def _94c05844279a(self, _a378730934eb):
        _b67906b4ae9b = _a378730934eb['unique_identifier']._20b005753fb4('_')
        if _d8115e52957c(_b67906b4ae9b) > 2:
            _efa6af7b895e = self._e22bb77cb91d(_a378730934eb['script'])
            return _a378730934eb['language'] + "_" + _efa6af7b895e
        else:
            return _a378730934eb['language']

    def _188dff228eee(self, _a378730934eb):
        if "Romanized Kashmiri" in _a378730934eb['language'] and "Kashmiri" in _a378730934eb['language_label']:
            return "Kashmiri"
        return _a378730934eb['language_label']

    def _4299acc0d672(self, _bd1ae5258013: _0526d423f19f, _c8868ec2ea5c: _c2e0c9bcc6b8 = 0.0, _3a6751fccf51: _c2e0c9bcc6b8 = 1.0):
        _da66b2ca4aec = _78f21992428e()
        _6951f8370a8a = self._fc1dd76f2854
        _1cba4c62bf34 = os._8e9639e9f94b._2ed4b8af2418(self._6a18bf4f2b5d, self._fc1dd76f2854 + ".json")

        with _21d6d8241eeb(_1cba4c62bf34, "r+", _634b7f7f2bee="utf8") as _063272c309e8:
            _2e298b42ddc5 = json._8e84ec86ef11(_063272c309e8)

        _471f02575c32 = _6ae80e179d1a._9defe6a4edca(_2e298b42ddc5["data"])

        # Filter languages if provided
        _471f02575c32 = _471f02575c32[_471f02575c32["language"]._caa999bb9ab7(self._5f461de203a1)] if _0726e74cb320(self, "select_languages", _c42b725c4f49) else _471f02575c32
        _471f02575c32["language_label"] = _471f02575c32._d2de0e9c910f(self._6ab5122d3991, _585ca8026083=1)
        if _bd1ae5258013._948fc04b9ea7() == "romanized":
            _471f02575c32["language"] = _471f02575c32["language"]._d2de0e9c910f(lambda _cdaaf365fe5e: "Romanized " + _0526d423f19f(_cdaaf365fe5e))

        _471f02575c32["language_label"] = _471f02575c32._d2de0e9c910f(self._29c8bddf164f, _585ca8026083=1)
        _471f02575c32["lang_code"] = _471f02575c32["language_label"]._101eaa4dda14(_ed4f3d343580)

        _da66b2ca4aec._38c3e95cd2a9(_5a9761190686="metrics/data")

        if _bd1ae5258013._948fc04b9ea7() == "romanized":
            _471f02575c32["lang_code"] = _471f02575c32["lang_code"]._d2de0e9c910f(lambda _cdaaf365fe5e: _0526d423f19f(_cdaaf365fe5e) + "_en")

        self._1a80056e5465(_471f02575c32, _bd1ae5258013, _3a6751fccf51, _3c5d0338b66a="original")

        _3ee7405f63f4 = "romanized" if _bd1ae5258013 == "native" else "native"
        _c820edb1c4b8 = [_210524b94e20 for _210524b94e20 in _471f02575c32._f57aa2535da3 if _3ee7405f63f4 in _210524b94e20]
        _471f02575c32._677ba130d5ed(_c820edb1c4b8, _585ca8026083=1, _4b5ae65b9d41=_362bc6eeb2af)
        _471f02575c32 = _471f02575c32[_471f02575c32[f'{_bd1ae5258013} sentence']._bdddface4285(_0526d423f19f)._0526d423f19f._1fab5a4fb21c() != '']

        # Write per-language CSV files
        for _e46c7d3b9a21, _56ce9a073abf in _471f02575c32._1f7d7e005229("lang_code"):
            _5a9761190686 = f"data/{self._72d44bb6fce9}/original/{_e46c7d3b9a21}"
            _da66b2ca4aec._38c3e95cd2a9(_5a9761190686=_5a9761190686)
            _6687334f39c2 = f"{_5a9761190686}/{self._fc1dd76f2854}_{_e46c7d3b9a21}_{_bd1ae5258013}_original_data.csv"
            _56ce9a073abf._1235f3e6a1fc(
                _6687334f39c2,
                _f855cfafcfb6="w+",
                _634b7f7f2bee="utf8",
                _4589aa886280=_45770da360e5,
                _1fd782f48bfb=_d75e19639b16._6d4f7bdc1213,
                _c5a13edc8682="\\",
            )
            self._683bcac7c407._069eba56b4bc(f"{_e46c7d3b9a21} data written to {_6687334f39c2}")

        # Sample if needed for train set
        if self._4d4c4fd3564e == "train" and _3a6751fccf51 not in [0.0, 1.0]:
            _60253c909ec5 = _cd3de89f1fcb(_471f02575c32,
                                          _bd1ae5258013,
                                          _3a6751fccf51,
                                          _fe30528e7bcf=self._00a79e47252e._54c4ceb37aca._fe30528e7bcf
                                          )
            _471f02575c32 = _60253c909ec5._6e40a8c6986f(_677ba130d5ed=_362bc6eeb2af)

        self._1a80056e5465(_471f02575c32, _bd1ae5258013, _3a6751fccf51, _3c5d0338b66a="processed")

        if _c8868ec2ea5c == 0:
            self._683bcac7c407._069eba56b4bc(f"Started Processing {self._fc1dd76f2854} for {_bd1ae5258013} sentences for {self._4d4c4fd3564e} data.")
            _d6b923ef646d = os._8e9639e9f94b._2ed4b8af2418("data", self._72d44bb6fce9, self._4d4c4fd3564e)
            _b8ebb6f7cfd7 = "test"
            self._8c5945da9327(_d6b923ef646d, _471f02575c32, _6951f8370a8a, _b8ebb6f7cfd7, _bd1ae5258013)
            self._683bcac7c407._069eba56b4bc(f"Completed Processing {self._fc1dd76f2854} for {_bd1ae5258013} sentences for {self._4d4c4fd3564e} data.")
        else:
            _e08ea895fcbe, _edb47aaaed42 = self._c937c34ccfdd(_471f02575c32, _c8868ec2ea5c)
            for _e2e8e39833c1, _b8ebb6f7cfd7 in [(_e08ea895fcbe, "train"), (_edb47aaaed42, "val")]:
                self._683bcac7c407._069eba56b4bc(f"Started Processing {self._fc1dd76f2854} for {_bd1ae5258013} sentences for {_b8ebb6f7cfd7} data.")
                _d6b923ef646d = os._8e9639e9f94b._2ed4b8af2418("data", self._72d44bb6fce9, _b8ebb6f7cfd7)
                self._8c5945da9327(_d6b923ef646d, _e2e8e39833c1, _6951f8370a8a, _b8ebb6f7cfd7, _bd1ae5258013)
                self._683bcac7c407._069eba56b4bc(f"Completed Processing {self._fc1dd76f2854} for {_bd1ae5258013} sentences for {_b8ebb6f7cfd7} data.")

    def _8ae9c6b42863(self, _471f02575c32, _bd1ae5258013, _3a6751fccf51, _3c5d0338b66a):
        _471f02575c32[f"{_bd1ae5258013}_length"] = _471f02575c32[f"{_bd1ae5258013} sentence"]._d2de0e9c910f(lambda _cdaaf365fe5e: _d8115e52957c(_0526d423f19f(_cdaaf365fe5e)._20b005753fb4()))
        _cb5e3554421e = _471f02575c32._1f7d7e005229(["lang_code", "language"])._2c630b5ca8df({
            f"{_bd1ae5258013}_length": [
                lambda _cdaaf365fe5e: _cdaaf365fe5e[_cdaaf365fe5e != 0]._108f1213ea5e() if (_cdaaf365fe5e != 0)._8e04ed84e62e() else 0,
                lambda _cdaaf365fe5e: _cdaaf365fe5e[_cdaaf365fe5e != 0]._6499d3728844() if (_cdaaf365fe5e != 0)._8e04ed84e62e() else 0,
                lambda _cdaaf365fe5e: (_cdaaf365fe5e != 0)._98e7ef097cce(),
            ],
        })
        _cb5e3554421e._f57aa2535da3 = [f"{_bd1ae5258013}_mean", f"{_bd1ae5258013}_median", f"{_bd1ae5258013}_count"]
        _51df2c91cdec = f"metrics/data/{self._fc1dd76f2854}_{_bd1ae5258013}_{_3c5d0338b66a}_{_9e3822a4d559(_3a6751fccf51*100)}_data_file_metrics.csv"
        _cb5e3554421e._1235f3e6a1fc(_51df2c91cdec, _f855cfafcfb6="w+", _634b7f7f2bee="utf8")

    def _67aa2ffcf1c9(self, _d6b923ef646d, _471f02575c32, _6951f8370a8a, _b8ebb6f7cfd7, _bd1ae5258013):
        for _7499d659e3ea in _471f02575c32["language_label"]._b48787a9a996():
            self._683bcac7c407._069eba56b4bc(f"Now Processing {self._fc1dd76f2854} for {_7499d659e3ea} language.")
            _1b2edf0706ed = _471f02575c32["language_label"]._597c144e81c2(_7499d659e3ea)._324aef08bb73()
            _e46c7d3b9a21 = _471f02575c32._bfda168ab74d[_1b2edf0706ed, "lang_code"]
            _ed97af50cf9d = _471f02575c32._bfda168ab74d[_1b2edf0706ed, "language_label"]._20b005753fb4()[-1]._1fab5a4fb21c()

            _026580f80ddf = os._8e9639e9f94b._2ed4b8af2418(_d6b923ef646d, _e46c7d3b9a21)
            os._9806ee9bca9f(_026580f80ddf, _84e3dffb6038=_362bc6eeb2af)
            # Collect DF for this lang_code to allow source-only dedupe
            _802be4bce74a = _471f02575c32[_471f02575c32["lang_code"] == _e46c7d3b9a21].copy()
            _7e83fd6aa83e = f"{_bd1ae5258013} sentence"

            # Normalize whitespace for dedupe comparison
            _802be4bce74a["__norm_sent"] = _802be4bce74a[_7e83fd6aa83e]._bdddface4285(_0526d423f19f)._d2de0e9c910f(lambda _11cf89753416: " "._2ed4b8af2418(_0526d423f19f(_11cf89753416)._20b005753fb4()))
            _c2e7043fc75f = _d8115e52957c(_802be4bce74a)
            # dedupe only on normalized source sentences, keep first
            _3b298139e6c6 = _802be4bce74a._b534520b2f11(_76015ec26fc1=["__norm_sent"], _9fc4f22a5c55="first")
            _e2775fd6ebb5 = _9e3822a4d559(_3b298139e6c6._98e7ef097cce())
            _856d5c788534 = _c2e7043fc75f - _e2775fd6ebb5

            # get example unique_identifiers for removed rows if available
            _e2c66c103c05 = []
            if _e2775fd6ebb5 > 0:
                if "unique_identifier" in _802be4bce74a._f57aa2535da3:
                    _e2c66c103c05 = _c769ae50d8c3(_802be4bce74a._bfda168ab74d[_3b298139e6c6, "unique_identifier"]._4fb34b954a9c()._bdddface4285(_0526d423f19f)._b48787a9a996()[:10])
                else:
                    # fallback to short hash of removed sentences
                    _e2c66c103c05 = [hashlib._3ea7119bf33f(_11cf89753416._f4327c634f1d("utf8"))._fe149f08ca61()[:8] for _11cf89753416 in _802be4bce74a._bfda168ab74d[_3b298139e6c6, "__norm_sent"]._bdddface4285(_0526d423f19f)._b48787a9a996()[:10]]

            self._683bcac7c407._069eba56b4bc(f"Dedup (source only) for lang_code={_e46c7d3b9a21}, script={_bd1ae5258013}: before={_c2e7043fc75f} after={_856d5c788534} removed={_e2775fd6ebb5}")
            if _e2775fd6ebb5 > 0:
                self._683bcac7c407._069eba56b4bc(f"Example removed unique ids (up to 10) for {_e46c7d3b9a21}: {_e2c66c103c05}")

            # Keep only non-duplicate rows for writing
            _802be4bce74a = _802be4bce74a._bfda168ab74d[~_3b298139e6c6]._6e40a8c6986f(_677ba130d5ed=_362bc6eeb2af)
            # Make sure the sentence column uses normalized text
            _802be4bce74a[_7e83fd6aa83e] = _802be4bce74a["__norm_sent"]
            _802be4bce74a = _802be4bce74a[_802be4bce74a[_7e83fd6aa83e]._bdddface4285(_0526d423f19f)._0526d423f19f._1fab5a4fb21c() != ""]

            _c6c0746b1cf1 = _802be4bce74a[_7e83fd6aa83e]._4fb34b954a9c()

            _c66ad9e3008e = os._8e9639e9f94b._2ed4b8af2418(_026580f80ddf, "src")
            _c2875ed7d2eb = os._8e9639e9f94b._2ed4b8af2418(_026580f80ddf, "tgt")
            _1ec4d57fa5c8 = self._7881742f88a3 if _bd1ae5258013._948fc04b9ea7() == "native" else self._e5dd7276daeb
            
            os._9806ee9bca9f(_c66ad9e3008e, _84e3dffb6038=_362bc6eeb2af)
            os._9806ee9bca9f(_c2875ed7d2eb, _84e3dffb6038=_362bc6eeb2af)
            os._9806ee9bca9f(_1ec4d57fa5c8, _84e3dffb6038=_362bc6eeb2af)

            _1cba4c62bf34 = os._8e9639e9f94b._2ed4b8af2418(_c66ad9e3008e, f"{_e46c7d3b9a21}_{_6951f8370a8a}.src")
            _234c82153309 = os._8e9639e9f94b._2ed4b8af2418(_c2875ed7d2eb, f"{_e46c7d3b9a21}_{_6951f8370a8a}.tgt")
            _ac406dc28482 = "valid" if _b8ebb6f7cfd7._948fc04b9ea7() == "val" else _b8ebb6f7cfd7
            _9521b2715a3f = os._8e9639e9f94b._2ed4b8af2418(_1ec4d57fa5c8, f"{_ac406dc28482}_combine.txt")

            with _21d6d8241eeb(_1cba4c62bf34, "w", _634b7f7f2bee="utf8") as _584e9a57d663,\
                    _21d6d8241eeb(_234c82153309, "w", _634b7f7f2bee="utf8") as _a0e3b4af56c0,\
                    _21d6d8241eeb(_9521b2715a3f, "a+", _634b7f7f2bee="utf8") as _3e087476bb13:
                _584e9a57d663._e038b2ed0bb0("text\n")
                _a0e3b4af56c0._e038b2ed0bb0("lang_code\n")
                for _2bc494c2c145 in _eea7255e3aea(0, _d8115e52957c(_c6c0746b1cf1), 1000):
                    _7c607e36a91c = _c6c0746b1cf1[_2bc494c2c145:_2bc494c2c145+1000]
                    _63f2a8f68154 = [_e46c7d3b9a21] * _d8115e52957c(_7c607e36a91c)
                    _30a5fa539408 = [f"__label__{_ed97af50cf9d}"] * _d8115e52957c(_7c607e36a91c)
                    for _d41d1aa3ce7f, _b70c08607a44, _1289286a1cbc in _95cd24de3529(_7c607e36a91c, _63f2a8f68154, _30a5fa539408):
                        _d41d1aa3ce7f = _0526d423f19f(_d41d1aa3ce7f)._1fab5a4fb21c()
                        if _d41d1aa3ce7f and _d41d1aa3ce7f != "\n":
                            _584e9a57d663._e038b2ed0bb0(f"{_d41d1aa3ce7f}\n")
                            _a0e3b4af56c0._e038b2ed0bb0(f"{_b70c08607a44}\n")
                            _3e087476bb13._e038b2ed0bb0(f"{_1289286a1cbc} {_d41d1aa3ce7f}\n")

            self._683bcac7c407._069eba56b4bc(f"Files {_1cba4c62bf34} and {_234c82153309} with {_d8115e52957c(_c6c0746b1cf1)} samples have been created.")

# Main function
def _98231cc98fe3():
    _ff84b983ea05._0a74ffef5709(_a4b31069008f=_2112a0fdcc36(1, math._f3439ce96431(os._d61fe9165e8c() * 0.25)))
    _16d4cf8945d3 = _e213a153b401._2ed35c983dff(_8a01ff04d3ab="Process Bhasha Abhijnaanam Dataset")
    _16d4cf8945d3._5a61ed5c7d33(
        "--config_file_path",
        _e525658daa50=_0526d423f19f,
        _0745150e9331=_362bc6eeb2af,
        _15bfe9ecdd18="Pass the yaml config file path",
    )
    try:
        _d493a5d64307, _08f3839f5662 = _16d4cf8945d3._4669637fc7fc()
        _00a79e47252e = _3ceef10a65c3()._b3eea5e76153(_d78340c761c5=_d493a5d64307._5d3538877e20)
        _683bcac7c407 = _1222c7f5f086()._c88cb072d5b9(_00a79e47252e)
        _683bcac7c407._069eba56b4bc(f"Unknwon args {_08f3839f5662} hence ignored")
        _c52fbf5f4247(_683bcac7c407=_683bcac7c407, _00a79e47252e=_00a79e47252e)
    except _e213a153b401._b2be0c4b4435 as _6d2d7ea298e3:
        _f7a05ae5678d(f"Error: {_6d2d7ea298e3}")
        _16d4cf8945d3._7b3ad3ab0d14()

if __name__ == "__main__":
    _7ddbf9b3fcd7()
