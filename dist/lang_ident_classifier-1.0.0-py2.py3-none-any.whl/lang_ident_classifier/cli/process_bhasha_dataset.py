# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : process_bhasha_dataset.py
# @Time             : 2025-10-31 09:09 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _0cd66c62e6a8
import _3817df390b88
import math
import os
from _d0a94a49da99 import _6806d24cccc2
from urllib._fdacf4b6756f import _c7ae43665781
import _44bbdedc2257
from _4a8da57d341a import _4a8da57d341a
import _ca88c62f08f9 as _881257f336b3
import json
import _cbe32499ebf4
from _d93882c950ba import _c6841811dd10
from _70f570870c4f import _b62e040ff547
from _bc90424fdd94._8cdc6c9e01e2._3fb855c5bc42._f1281370bfc8 import _08576420e93e
from _bc90424fdd94._8cdc6c9e01e2._3fb855c5bc42._96535ae8cec4 import _29be9218abca
from _bc90424fdd94._8cdc6c9e01e2._3fb855c5bc42._aaf90cc8d8b1 import _96a6a2139131
import hashlib

_4761ef9c6067 = {}

# Function to extract language code
def _e978f43b02a4(_8cdc6c9e01e2):
    _7cc4603524e6 = _8cdc6c9e01e2._0a4dec5fd8db()._e6eaee4d07a1()

    # Split compound languages
    _0300fcaec8a9 = _7cc4603524e6._d35822fd3487("_")

    # Take first 3 letters of each part
    _ba4b51d8fabc = [_d4a0bb8b3675[:3] for _d4a0bb8b3675 in _0300fcaec8a9]
    _8e6914e168f7 = "_"._4c744a9d8371(_ba4b51d8fabc)
    _e87916a1331a = _8e6914e168f7
    _1586f058105e = 1

    # If language already has a code, return it
    if _8cdc6c9e01e2 in _4761ef9c6067:
        return _4761ef9c6067[_8cdc6c9e01e2]

    # Find a unique code that isn't already assigned to a different language
    while _e87916a1331a in _4761ef9c6067._6d44be256f76():
        if _9d5f87b6c6b7(_c70bc4f88711 != _8cdc6c9e01e2 and _50dc627f3c0e == _e87916a1331a for _c70bc4f88711, _50dc627f3c0e in _4761ef9c6067._fff699a5890e()):
            _e87916a1331a = f"{_8e6914e168f7}{_1586f058105e}"
            _1586f058105e += 1
        else:
            break

    _4761ef9c6067[_8cdc6c9e01e2] = _e87916a1331a
    return _e87916a1331a

# Helper function for grouping and sampling
def _6afad743e2a1(_8e558a2dd805, _d146b56e51c0, _50d59ffa1cfe, _b4064202653a=20):
    def _7603854c98c7(_badb07c0e877):
        return _badb07c0e877._ac264ca383b7(_50d59ffa1cfe=_50d59ffa1cfe, _fdccf855f379=_b4064202653a)

    def _b4445a6d56a6(_badb07c0e877):
        return _badb07c0e877._96bc081a2f88(f'{_d146b56e51c0}_length', _136ce5d14a88=_1d6458c88324)._60ce4ea444c8(_fa63986faa79)

    return _8e558a2dd805._96bc081a2f88('lang_code', _136ce5d14a88=_1d6458c88324)._60ce4ea444c8(_b205cf65900c)

# Class for dataset processing
class _e5f74fb81017:
    def _759e5e22db4b(self, _146a2f92fbbf: _6806d24cccc2, _2fe3a09844de: _08576420e93e):
        self._c6639ddbd33e = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/parallel_romanized_train_data.zip"
        self._1461c5fc8b44 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/bhasha-abhijnaanam_test_set.zip"
        self._146a2f92fbbf = _146a2f92fbbf
        self._2fe3a09844de = _2fe3a09844de
        self._6d4845f5c9f0 = _d8217cfcad93(_d8217cfcad93(self._2fe3a09844de, "dataset", _c0e2f7348d47), "dataset_source_dir", "bhasha")
        self._f8cd75c63fbf = self._a9b69b9d6b6e(self._c6639ddbd33e, _95dd848d2749=f"data/{self._6d4845f5c9f0}/preprocessed/train")
        self._90aaf186d880 = self._a9b69b9d6b6e(self._1461c5fc8b44, _95dd848d2749=f"data/{self._6d4845f5c9f0}/preprocessed/test")
        self._cf4c739c9c98 = _d8217cfcad93(_d8217cfcad93(self._2fe3a09844de, "dataset", _c0e2f7348d47), "dataset_share", 1.0)
        self._ac63ea61f80c = _d8217cfcad93(_d8217cfcad93(self._2fe3a09844de, "dataset", _c0e2f7348d47), "select_languages", [])
        self._2c9b109968f0 = f"data/{self._6d4845f5c9f0}/filtered/native"
        self._efeab8067f5d = f"data/{self._6d4845f5c9f0}/filtered/romanized"

        # Extract languages from JSON
        _a92ba78e06ec = self._7cdd36b16e06(self._f8cd75c63fbf)

        # Extract languages from txt files
        _950cc7baf657 = os._0f2b90d76d4c._4c744a9d8371("data", self._6d4845f5c9f0, "native_script_train_valid_data", "Native_script_data")
        _d87151714f3d = os._0f2b90d76d4c._4c744a9d8371("data", self._6d4845f5c9f0, "roman_script_train_valid_data", "Roman_script_data")

        _1fc78fe52c75 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/native_script_train_valid_data.zip"
        _b2304a85f35f = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/roman_script_train_valid_data.zip"

        _25fb06f30c0b = self._864fa0b8faa1(_1fc78fe52c75, f"data/{self._6d4845f5c9f0}/native_script_train_valid_data")
        _11f58ffdac80 = self._864fa0b8faa1(_b2304a85f35f, f"data/{self._6d4845f5c9f0}/roman_script_train_valid_data")

        # Combine all txt languages
        _8182fcec3e6d = _25fb06f30c0b._c310ad9d3073(_11f58ffdac80)

        # === NEW: interpret select_languages empty or ['All'] as "use all languages" ===
        # normalize incoming select_languages
        try:
            _d99ead38fcec = self._ac63ea61f80c if self._ac63ea61f80c is not _c0e2f7348d47 else []
        except _0b73318b7077:
            _d99ead38fcec = []
        # if user passed ['All'] (case-insensitive) or empty list -> set to all discovered languages (union of JSON + TXT)
        _05e61f08dce5 = _fe9a40ead8a3(_8182fcec3e6d) | _fe9a40ead8a3(_a92ba78e06ec)
        if (_9d81bb6733c6(_d99ead38fcec, (_0d9bbfa4e382, _d0271ea41446)) and _7ee434c96d7c(_d99ead38fcec) == 1 and _90aec66ae01b(_d99ead38fcec[0])._e6eaee4d07a1()._0a4dec5fd8db() == "all") or (not _d99ead38fcec):
            self._ac63ea61f80c = _1eb18bc2788c(_05e61f08dce5)
            self._146a2f92fbbf._16a9563cee22("select_languages was empty or ['All'] — using all discovered languages (%d).", _7ee434c96d7c(self._ac63ea61f80c))
        else:
            # otherwise keep only languages that actually exist in discovered sets
            self._ac63ea61f80c = [_95de70370baf for _95de70370baf in _d99ead38fcec if _95de70370baf in _05e61f08dce5]
            self._146a2f92fbbf._16a9563cee22("Using user-provided select_languages filtered to discovered languages (%d): %s", _7ee434c96d7c(self._ac63ea61f80c), self._ac63ea61f80c)

        # If user previously expected the old logic below (narrowing), keep it consistent:
        if self._ac63ea61f80c:
            _8182fcec3e6d = [_95de70370baf for _95de70370baf in self._ac63ea61f80c if _95de70370baf in _8182fcec3e6d]
            _a92ba78e06ec = [_95de70370baf for _95de70370baf in self._ac63ea61f80c if _95de70370baf in _a92ba78e06ec]

        # Find missing languages in JSON compared to txt datasets
        _d868e708f1c3 = _0d9bbfa4e382(_fe9a40ead8a3(_8182fcec3e6d) - _fe9a40ead8a3(_a92ba78e06ec))
        self._146a2f92fbbf._16a9563cee22(f"Languages in JSON: {_a92ba78e06ec}")
        self._146a2f92fbbf._16a9563cee22(f"Languages in TXT: {_8182fcec3e6d}")
        self._146a2f92fbbf._16a9563cee22(f"Missing languages to load from TXT: {_d868e708f1c3}")

        # Now process only missing languages from TXT files
        if _d868e708f1c3:
            self._0845a087f7f2(_950cc7baf657, "native", _d868e708f1c3, self._cf4c739c9c98)
            self._0845a087f7f2(_d87151714f3d, "romanized", _d868e708f1c3, self._cf4c739c9c98)

            self._99acb944019e(_d868e708f1c3)

        for _97895cb673d5 in ['train', 'test']:
            _45dec0d90778 = self._f8cd75c63fbf if _97895cb673d5 == 'train' else self._90aaf186d880
            _85a5d245e28c = "train" if _97895cb673d5 == 'train' else "test"
            _9bbbd5d25772 = 0.8 if _97895cb673d5 == 'train' else 0.0
            self._91c634f5b556 = os._0f2b90d76d4c._01b26e0437e7(_45dec0d90778)._d35822fd3487(".")[0]
            self._ddef43f9e240 = os._0f2b90d76d4c._e974c2e5f47d(_45dec0d90778)
            self._85a5d245e28c = _85a5d245e28c
            for _d146b56e51c0 in ["native", "romanized"]:
                self._1438dad4e0b2(_d146b56e51c0, _9bbbd5d25772, self._cf4c739c9c98)

    # Process missing language CSVs
    def _87e9475a3fcd(self, _d868e708f1c3, _ac63ea61f80c=_c0e2f7348d47):
        _a594ce2f7fd5 = os._0f2b90d76d4c._4c744a9d8371("data", self._6d4845f5c9f0 ,"original")

        for _7cc4603524e6 in _d868e708f1c3:
            _95dae39cc0f1 = os._0f2b90d76d4c._4c744a9d8371(_a594ce2f7fd5, _577c9b6f155a(_7cc4603524e6))
            if not os._0f2b90d76d4c._daf36892a734(_95dae39cc0f1):
                self._146a2f92fbbf._0ead48940c7c(f"Missing original data directory not found for language: {_7cc4603524e6}")
                continue

            for _d146b56e51c0 in ["native", "romanized"]:
                # Detect CSV files for this language
                for _122c1c8a585b in os._d700d304989a(_95dae39cc0f1):
                    if not _122c1c8a585b._8b21c91189a0(".csv"):
                        continue
                    if _577c9b6f155a(_7cc4603524e6) not in _122c1c8a585b or _d146b56e51c0 not in _122c1c8a585b:
                        continue

                    # Determine destination based on CSV name (train or val)
                    _0f636fe884ab = "train" if "train" in _122c1c8a585b else "val"
                    _4ac31b6df9e4 = os._0f2b90d76d4c._4c744a9d8371("data", self._6d4845f5c9f0, _0f636fe884ab)

                    _29c116669bbd = os._0f2b90d76d4c._4c744a9d8371(_95dae39cc0f1, _122c1c8a585b)
                    _8e558a2dd805 = _881257f336b3._150c990cefb6(_29c116669bbd, _637059e29bfb=_3817df390b88._6b68e5004af5, _7d7b48214d87="\\")

                    _db4a53094410 = f"{_d146b56e51c0} sentence"
                    if _db4a53094410 not in _8e558a2dd805._36ef3e8457d8:
                        self._146a2f92fbbf._0ead48940c7c(f"{_db4a53094410} column missing in {_29c116669bbd}, skipping.")
                        continue

                    _8e558a2dd805 = _8e558a2dd805[_8e558a2dd805[_db4a53094410]._fe8da73b4540(_90aec66ae01b)._90aec66ae01b._e6eaee4d07a1() != ""]
                    if _8e558a2dd805._c063b9192e6d:
                        self._146a2f92fbbf._0ead48940c7c(f"No valid rows found for {_7cc4603524e6} {_d146b56e51c0} in {_29c116669bbd}")
                        continue

                    _6138372fcd9b = _8e558a2dd805["lang_code"]._d5f357a98e8f[0]

                    _8ea4b15d18bc = os._0f2b90d76d4c._4c744a9d8371(_4ac31b6df9e4, _6138372fcd9b)
                    os._2557141ad036(_8ea4b15d18bc, _a3bedacdb855=_9458aabf0520)

                    _66d30e42cd5d = os._0f2b90d76d4c._4c744a9d8371(_8ea4b15d18bc, "src")
                    _81be57e41fee = os._0f2b90d76d4c._4c744a9d8371(_8ea4b15d18bc, "tgt")
                    os._2557141ad036(_66d30e42cd5d, _a3bedacdb855=_9458aabf0520)
                    os._2557141ad036(_81be57e41fee, _a3bedacdb855=_9458aabf0520)

                    _76af1444245d = f"txt_{_d146b56e51c0}"
                    _f6147f386c00 = self._2c9b109968f0 if _d146b56e51c0._520668d65abd() == "native" else self._efeab8067f5d
                    os._2557141ad036(_f6147f386c00, _a3bedacdb855=_9458aabf0520)

                    _6b635c8ed68f = os._0f2b90d76d4c._4c744a9d8371(_66d30e42cd5d, f"{_6138372fcd9b}_{_76af1444245d}.src")
                    _f0ddf992d63f = os._0f2b90d76d4c._4c744a9d8371(_81be57e41fee, f"{_6138372fcd9b}_{_76af1444245d}.tgt")
                    _ce13d90ae6c3 = "valid" if _0f636fe884ab._520668d65abd() == "val" else _0f636fe884ab
                    _f262e7f77314 = os._0f2b90d76d4c._4c744a9d8371(_f6147f386c00, f"{_ce13d90ae6c3}_combine.txt")

                    with _cb714f943761(_6b635c8ed68f, "w", _ec4fd1d538f5="utf-8") as _67af1969295e, \
                            _cb714f943761(_f0ddf992d63f, "w", _ec4fd1d538f5="utf-8") as _7777f1f2a37b, \
                            _cb714f943761(_f262e7f77314, "a+", _ec4fd1d538f5="utf-8") as _0db5988aa69c:
                        _67af1969295e._fa66da13f508("text\n")
                        _7777f1f2a37b._fa66da13f508("lang_code\n")

                        for _fd569f90eaf2 in _8e558a2dd805[_db4a53094410]:
                            _fd569f90eaf2 = _90aec66ae01b(_fd569f90eaf2)._e6eaee4d07a1()
                            if _fd569f90eaf2 and _fd569f90eaf2 != "\n":
                                _0db5988aa69c._fa66da13f508(f"__label__{_7cc4603524e6} {_fd569f90eaf2}\n")
                                _67af1969295e._fa66da13f508(f"{_fd569f90eaf2}\n")
                                _7777f1f2a37b._fa66da13f508(f"{_6138372fcd9b}\n")

                    self._146a2f92fbbf._16a9563cee22(f"Written {_7ee434c96d7c(_8e558a2dd805)} rows to {_6b635c8ed68f} and {_f0ddf992d63f}")

    # Extract languages from JSON file
    def _15d57b17a2a7(self, _45dec0d90778):
        with _cb714f943761(_45dec0d90778, "r", _ec4fd1d538f5="utf-8") as _2552271ed724:
            _4e48b82bf8d5 = json._f7bcf9c60b93(_2552271ed724)
        _bece117d9842 = _fe9a40ead8a3()
        for _850c3d3544b3 in _4e48b82bf8d5._9e5074498213("data", []):
            _7cc4603524e6 = _850c3d3544b3._9e5074498213("language")
            if _7cc4603524e6:
                _bece117d9842._b286776a9f8c(_7cc4603524e6)
        return _bece117d9842

    # Process missing languages from TXT files
    def _b5b3e613ee62(self, _da1b8eaf361a, _d146b56e51c0, _d868e708f1c3, _cf4c739c9c98=1.0):
        _dbe09ea52a45 = _96a6a2139131()

        for _780b4631f00f, _3f3ba912e746 in [("train_combine.txt", "train"), ("valid_combine.txt", "val")]:
            _d694aa5ecf4d = os._0f2b90d76d4c._4c744a9d8371(_da1b8eaf361a, _780b4631f00f)
            if not os._0f2b90d76d4c._daf36892a734(_d694aa5ecf4d):
                self._146a2f92fbbf._0ead48940c7c(f"File {_d694aa5ecf4d} not found, skipping.")
                continue

            _8bcb42391287 = []
            with _cb714f943761(_d694aa5ecf4d, "r", _ec4fd1d538f5="utf-8") as _2552271ed724:
                for _17f0aff960d0 in _2552271ed724:
                    _17f0aff960d0 = _17f0aff960d0._e6eaee4d07a1()
                    if not _17f0aff960d0:
                        continue
                    _0300fcaec8a9 = _17f0aff960d0._d35822fd3487(_1b4d23d173c8=1)
                    if _7ee434c96d7c(_0300fcaec8a9) < 2:
                        continue
                    _7aa56c61955b, _fd569f90eaf2 = _0300fcaec8a9
                    if _7aa56c61955b._64426eb76a85("__label__"):
                        _7cc4603524e6 = _7aa56c61955b[_7ee434c96d7c("__label__"):]
                        if _7cc4603524e6 in _d868e708f1c3:
                            _8bcb42391287._381aeb3a3135({
                                f"{_d146b56e51c0} sentence": _fd569f90eaf2,
                                f"{_d146b56e51c0}_length": _90aec66ae01b(_fd569f90eaf2)._e6eaee4d07a1()._d35822fd3487()._aaa9e523f24f(),
                                "language": _7cc4603524e6,
                                "lang_code": _577c9b6f155a(_7cc4603524e6),
                            })

            if not _8bcb42391287:
                self._146a2f92fbbf._16a9563cee22(f"No missing language data found in {_d694aa5ecf4d} for script {_d146b56e51c0}.")
                continue

            _8e558a2dd805 = _881257f336b3._724dd8d5ddd6(_8bcb42391287)
            _8e558a2dd805 = _8e558a2dd805[_8e558a2dd805[f"{_d146b56e51c0} sentence"]._fe8da73b4540(_90aec66ae01b)._90aec66ae01b._e6eaee4d07a1() != '']

            # Sample data if needed
            if _cf4c739c9c98 not in [0.0, 1.0]:
                _8e558a2dd805 = _56f43b2baf02(_8e558a2dd805=_8e558a2dd805, 
                                      _d146b56e51c0=_d146b56e51c0, 
                                      _50d59ffa1cfe=self._cf4c739c9c98,
                                      _b4064202653a=self._2fe3a09844de._7bf9caf7e0b6._b4064202653a)

            # Write separate CSV per language per split
            for _6138372fcd9b, _a5048e8015d2 in _8e558a2dd805._96bc081a2f88("lang_code"):
                # Skip if this group corresponds to English
                if _d146b56e51c0._520668d65abd()=="romanized" and _a5048e8015d2["language"]._d5f357a98e8f[0] == "English":
                    continue
                _91aea10b5c6d = f"data/{self._6d4845f5c9f0}/original/{_6138372fcd9b}"
                _dbe09ea52a45._af2d335ca210(_91aea10b5c6d=_91aea10b5c6d)
                _03b269c45c5d = f"{_91aea10b5c6d}/txt_{_d146b56e51c0}_{_6138372fcd9b}_{_3f3ba912e746}_original_data.csv"
                _a5048e8015d2._4672370188c6(
                    _03b269c45c5d,
                    _aef57b2ea36f="w+",
                    _ec4fd1d538f5="utf8",
                    _932f0ed2c0fc=_1d6458c88324,
                    _637059e29bfb=_3817df390b88._6b68e5004af5,
                    _7d7b48214d87="\\",
                )
                self._146a2f92fbbf._16a9563cee22(f"Missing {_6138372fcd9b} data ({_3f3ba912e746}) written to {_03b269c45c5d}")

    # Download and extract languages from txt file
    def _71a2546bc378(self, _6c2906f8a6af, _95dd848d2749, _8cd183b17ca7=3, _e2906b266153=_1d6458c88324):
        import time
        import _cbe32499ebf4, _44bbdedc2257, os
        from urllib._fdacf4b6756f import _c7ae43665781

        self._146a2f92fbbf._16a9563cee22(f"Preparing to download from {_6c2906f8a6af} into {_95dd848d2749}")
        os._2557141ad036(_95dd848d2749, _a3bedacdb855=_9458aabf0520)

        _3ffad3858a57 = os._0f2b90d76d4c._01b26e0437e7(_c7ae43665781(_6c2906f8a6af)._0f2b90d76d4c)
        _de4aabf592c5 = os._0f2b90d76d4c._4c744a9d8371(_95dd848d2749, _3ffad3858a57)

        # Skip download if file exists and redownload is False
        if os._0f2b90d76d4c._daf36892a734(_de4aabf592c5) and not _e2906b266153:
            self._146a2f92fbbf._16a9563cee22(f"File already exists, skipping download: {_de4aabf592c5}")
        else:
            for _9cf4784f0b2b in _a30e147dcb8d(_8cd183b17ca7):
                try:
                    with _cbe32499ebf4._9e5074498213(_6c2906f8a6af, _645e85ed3e56=_9458aabf0520, _79841266305a=30) as _e19022282fc7:
                        _e19022282fc7._8a2eaec78e76()
                        with _cb714f943761(_de4aabf592c5, "wb") as _2552271ed724:
                            for _2a31f60501b6 in _e19022282fc7._049649932cee(_6fdb1061f789=8192):
                                if _2a31f60501b6:
                                    _2552271ed724._fa66da13f508(_2a31f60501b6)
                    self._146a2f92fbbf._16a9563cee22(f"Download complete: {_de4aabf592c5}")
                    break
                except (_cbe32499ebf4._2c35d7f2e971._ef829e886b06,
                        _cbe32499ebf4._2c35d7f2e971._91cd2fdfe198,
                        _cbe32499ebf4._2c35d7f2e971._f760efc9961c) as _a72cbad7b46f:
                    self._146a2f92fbbf._0ead48940c7c(f"Download attempt {_9cf4784f0b2b+1} failed: {_a72cbad7b46f}")
                    if _9cf4784f0b2b < _8cd183b17ca7 - 1:
                        time._ac95b78e29f6(5)  # wait before retrying
                    else:
                        raise _cdded18e2dac(f"Failed to download {_6c2906f8a6af} after {_8cd183b17ca7} attempts")

        # Extract ZIP
        with _44bbdedc2257._dba16309daf2(_de4aabf592c5, "r") as _2650f8eae4a7:
            _2650f8eae4a7._2e86dc454650(_95dd848d2749)

        # Find extracted folder containing .txt files (Native or Romanized)
        _54ff70bbc9ba = _c0e2f7348d47
        for _2552271ed724 in os._d700d304989a(_95dd848d2749):
            _81018e67f4ae = os._0f2b90d76d4c._4c744a9d8371(_95dd848d2749, _2552271ed724)
            if os._0f2b90d76d4c._7068a22e63f8(_81018e67f4ae) and _9d5f87b6c6b7(_c9def1487fe6._8b21c91189a0(".txt") for _c9def1487fe6 in os._d700d304989a(_81018e67f4ae)):
                _54ff70bbc9ba = _81018e67f4ae
                break

        if not _54ff70bbc9ba:
            raise _a43a834eb199("Could not find extracted folder with txt files")

        self._146a2f92fbbf._16a9563cee22(f"Extracted txt files folder: {_54ff70bbc9ba}")

        # Return set of unique languages in the extracted folder
        return self._30a8458d685e(_54ff70bbc9ba)

    # Extract languages from a txt folder
    def _3045713413f7(self, _da1b8eaf361a):
        _bece117d9842 = _fe9a40ead8a3()
        for _780b4631f00f in ["train_combine.txt", "valid_combine.txt"]:
            _d694aa5ecf4d = os._0f2b90d76d4c._4c744a9d8371(_da1b8eaf361a, _780b4631f00f)
            if not os._0f2b90d76d4c._daf36892a734(_d694aa5ecf4d):
                continue
            with _cb714f943761(_d694aa5ecf4d, "r", _ec4fd1d538f5="utf-8") as _2552271ed724:
                for _17f0aff960d0 in _2552271ed724:
                    _17f0aff960d0 = _17f0aff960d0._e6eaee4d07a1()
                    if not _17f0aff960d0:
                        continue
                    _7aa56c61955b = _17f0aff960d0._d35822fd3487()[0]
                    if _7aa56c61955b._64426eb76a85("__label__"):
                        _7cc4603524e6 = _7aa56c61955b[_7ee434c96d7c("__label__"):]
                        _bece117d9842._b286776a9f8c(_7cc4603524e6)
        return _bece117d9842

    def _6f54842461b4(self, _6c2906f8a6af, _95dd848d2749, _8cd183b17ca7=3, _e2906b266153=_1d6458c88324):
        import time
        self._146a2f92fbbf._16a9563cee22(f"Preparing to download from {_6c2906f8a6af} into {_95dd848d2749}")
        os._2557141ad036(_95dd848d2749, _a3bedacdb855=_9458aabf0520)

        _3ffad3858a57 = os._0f2b90d76d4c._01b26e0437e7(_c7ae43665781(_6c2906f8a6af)._0f2b90d76d4c)
        _de4aabf592c5 = os._0f2b90d76d4c._4c744a9d8371(_95dd848d2749, _3ffad3858a57)

        # Skip download if file exists and redownload is False
        if os._0f2b90d76d4c._daf36892a734(_de4aabf592c5) and not _e2906b266153:
            self._146a2f92fbbf._16a9563cee22(f"File already exists, skipping download: {_de4aabf592c5}")
        else:
            for _9cf4784f0b2b in _a30e147dcb8d(_8cd183b17ca7):
                try:
                    with _cbe32499ebf4._9e5074498213(_6c2906f8a6af, _645e85ed3e56=_9458aabf0520, _79841266305a=30) as _e19022282fc7:
                        _e19022282fc7._8a2eaec78e76()
                        with _cb714f943761(_de4aabf592c5, 'wb') as _2552271ed724:
                            for _2a31f60501b6 in _e19022282fc7._049649932cee(_6fdb1061f789=8192):
                                if _2a31f60501b6:
                                    _2552271ed724._fa66da13f508(_2a31f60501b6)
                    self._146a2f92fbbf._16a9563cee22(f"Download complete: {_de4aabf592c5}")
                    break
                except (_cbe32499ebf4._2c35d7f2e971._ef829e886b06,
                        _cbe32499ebf4._2c35d7f2e971._91cd2fdfe198,
                        _cbe32499ebf4._2c35d7f2e971._f760efc9961c) as _a72cbad7b46f:
                    self._146a2f92fbbf._0ead48940c7c(f"Download attempt {_9cf4784f0b2b+1} failed: {_a72cbad7b46f}")
                    if _9cf4784f0b2b < _8cd183b17ca7 - 1:
                        time._ac95b78e29f6(5)  # wait before retrying
                    else:
                        raise _cdded18e2dac(f"Failed to download {_6c2906f8a6af} after {_8cd183b17ca7} attempts")

        # Extract ZIP
        with _44bbdedc2257._dba16309daf2(_de4aabf592c5, 'r') as _2650f8eae4a7:
            _2650f8eae4a7._2e86dc454650(_95dd848d2749)

        # Return JSON file path
        for _fc29e55efbd8 in os._d700d304989a(_95dd848d2749):
            if _fc29e55efbd8._8b21c91189a0('.json'):
                _d694aa5ecf4d = os._0f2b90d76d4c._4c744a9d8371(_95dd848d2749, _fc29e55efbd8)
                self._146a2f92fbbf._16a9563cee22(f"Extracted JSON file: {_d694aa5ecf4d}")
                return _d694aa5ecf4d

        raise _a43a834eb199("No JSON file found in extracted content.")

    def _38a3fcb1d794(self, _0cd9088a1819: _90aec66ae01b):
        try:
            _7cc4603524e6 = _b62e040ff547._9e5074498213(_0cd9088a1819)
            return _7cc4603524e6._0971671fe093()
        except _0b73318b7077:
            _e87916a1331a = _90aec66ae01b(_0cd9088a1819)._0a4dec5fd8db()[:2]
            _1974dbddf4e2 = _e87916a1331a
            while _9458aabf0520:
                try:
                    _7cc4603524e6 = _b62e040ff547._9e5074498213(_e87916a1331a)
                    if _7cc4603524e6:
                        _e87916a1331a += "x"
                    else:
                        return _e87916a1331a[:2]
                except _17ff5a209f1f:
                    return _1974dbddf4e2[:3]

    def _c0f375965a3d(self, _0b9a12722532: _881257f336b3._724dd8d5ddd6, _f6730948a4e3: _0d3d0cd17fb7):
        if _f6730948a4e3 < 1.0:
            _0b9a12722532 = _0b9a12722532._ac264ca383b7(_50d59ffa1cfe=1, _fdccf855f379=self._2fe3a09844de._7bf9caf7e0b6._b4064202653a)
        _c450a3e64ae0 = _8dbbd3248490(_f6730948a4e3 * _7ee434c96d7c(_0b9a12722532))
        return _0b9a12722532[:_c450a3e64ae0], _0b9a12722532[_c450a3e64ae0:]

    def _6544a820e3d7(self, _755c7ff79a63):
        _08374975ca32 = _755c7ff79a63._d35822fd3487("-")[-1][:4]  # first 4 letters of last part
        if _08374975ca32 == "Maye":  # Special Case
            return "Mei"
        return _08374975ca32

    def _4e7c16cfe528(self, _6955da6634ef):
        _0300fcaec8a9 = _6955da6634ef['unique_identifier']._d35822fd3487('_')
        if _7ee434c96d7c(_0300fcaec8a9) > 2:
            _687c10e66b32 = self._f5e0fb52ecc9(_6955da6634ef['script'])
            return _6955da6634ef['language'] + "_" + _687c10e66b32
        else:
            return _6955da6634ef['language']

    def _09e4ff989ede(self, _6955da6634ef):
        if "Romanized Kashmiri" in _6955da6634ef['language'] and "Kashmiri" in _6955da6634ef['language_label']:
            return "Kashmiri"
        return _6955da6634ef['language_label']

    def _4f1dc7d162f6(self, _d146b56e51c0: _90aec66ae01b, _f6730948a4e3: _0d3d0cd17fb7 = 0.0, _cf4c739c9c98: _0d3d0cd17fb7 = 1.0):
        _dbe09ea52a45 = _96a6a2139131()
        _76af1444245d = self._91c634f5b556
        _6b635c8ed68f = os._0f2b90d76d4c._4c744a9d8371(self._ddef43f9e240, self._91c634f5b556 + ".json")

        with _cb714f943761(_6b635c8ed68f, "r+", _ec4fd1d538f5="utf8") as _fc29e55efbd8:
            _4e48b82bf8d5 = json._f7bcf9c60b93(_fc29e55efbd8)

        _8e558a2dd805 = _881257f336b3._435ced0719ea(_4e48b82bf8d5["data"])

        # Filter languages if provided
        _8e558a2dd805 = _8e558a2dd805[_8e558a2dd805["language"]._30d5dd313073(self._ac63ea61f80c)] if _d8217cfcad93(self, "select_languages", _c0e2f7348d47) else _8e558a2dd805
        _8e558a2dd805["language_label"] = _8e558a2dd805._60ce4ea444c8(self._626417a3727a, _bba54eff5ccc=1)
        if _d146b56e51c0._520668d65abd() == "romanized":
            _8e558a2dd805["language"] = _8e558a2dd805["language"]._60ce4ea444c8(lambda _95de70370baf: "Romanized " + _90aec66ae01b(_95de70370baf))

        _8e558a2dd805["language_label"] = _8e558a2dd805._60ce4ea444c8(self._aecc8f15d70e, _bba54eff5ccc=1)
        _8e558a2dd805["lang_code"] = _8e558a2dd805["language_label"]._0ee70c3cc38e(_577c9b6f155a)

        _dbe09ea52a45._af2d335ca210(_91aea10b5c6d="metrics/data")

        if _d146b56e51c0._520668d65abd() == "romanized":
            _8e558a2dd805["lang_code"] = _8e558a2dd805["lang_code"]._60ce4ea444c8(lambda _95de70370baf: _90aec66ae01b(_95de70370baf) + "_en")

        self._cef415cdf1b8(_8e558a2dd805, _d146b56e51c0, _cf4c739c9c98, _fe989a31c706="original")

        _a4bd61d94c13 = "romanized" if _d146b56e51c0 == "native" else "native"
        _1d76875dfe7d = [_e27b6f0dd1e6 for _e27b6f0dd1e6 in _8e558a2dd805._36ef3e8457d8 if _a4bd61d94c13 in _e27b6f0dd1e6]
        _8e558a2dd805._1f9bf451540a(_1d76875dfe7d, _bba54eff5ccc=1, _f3d0302a790f=_9458aabf0520)
        _8e558a2dd805 = _8e558a2dd805[_8e558a2dd805[f'{_d146b56e51c0} sentence']._fe8da73b4540(_90aec66ae01b)._90aec66ae01b._e6eaee4d07a1() != '']

        # Write per-language CSV files
        for _6138372fcd9b, _a5048e8015d2 in _8e558a2dd805._96bc081a2f88("lang_code"):
            _91aea10b5c6d = f"data/{self._6d4845f5c9f0}/original/{_6138372fcd9b}"
            _dbe09ea52a45._af2d335ca210(_91aea10b5c6d=_91aea10b5c6d)
            _03b269c45c5d = f"{_91aea10b5c6d}/{self._91c634f5b556}_{_6138372fcd9b}_{_d146b56e51c0}_original_data.csv"
            _a5048e8015d2._4672370188c6(
                _03b269c45c5d,
                _aef57b2ea36f="w+",
                _ec4fd1d538f5="utf8",
                _932f0ed2c0fc=_1d6458c88324,
                _637059e29bfb=_3817df390b88._6b68e5004af5,
                _7d7b48214d87="\\",
            )
            self._146a2f92fbbf._16a9563cee22(f"{_6138372fcd9b} data written to {_03b269c45c5d}")

        # Sample if needed for train set
        if self._85a5d245e28c == "train" and _cf4c739c9c98 not in [0.0, 1.0]:
            _e683717d2dba = _56f43b2baf02(_8e558a2dd805,
                                          _d146b56e51c0,
                                          _cf4c739c9c98,
                                          _b4064202653a=self._2fe3a09844de._7bf9caf7e0b6._b4064202653a
                                          )
            _8e558a2dd805 = _e683717d2dba._cc08462ec1d4(_1f9bf451540a=_9458aabf0520)

        self._cef415cdf1b8(_8e558a2dd805, _d146b56e51c0, _cf4c739c9c98, _fe989a31c706="processed")

        if _f6730948a4e3 == 0:
            self._146a2f92fbbf._16a9563cee22(f"Started Processing {self._91c634f5b556} for {_d146b56e51c0} sentences for {self._85a5d245e28c} data.")
            _4ac31b6df9e4 = os._0f2b90d76d4c._4c744a9d8371("data", self._6d4845f5c9f0, self._85a5d245e28c)
            _7c9e2b4bc02f = "test"
            self._9fb2b9c2138d(_4ac31b6df9e4, _8e558a2dd805, _76af1444245d, _7c9e2b4bc02f, _d146b56e51c0)
            self._146a2f92fbbf._16a9563cee22(f"Completed Processing {self._91c634f5b556} for {_d146b56e51c0} sentences for {self._85a5d245e28c} data.")
        else:
            _728e1471ba24, _342f0b7d9bb7 = self._ad570f33dc09(_8e558a2dd805, _f6730948a4e3)
            for _338735cb20db, _7c9e2b4bc02f in [(_728e1471ba24, "train"), (_342f0b7d9bb7, "val")]:
                self._146a2f92fbbf._16a9563cee22(f"Started Processing {self._91c634f5b556} for {_d146b56e51c0} sentences for {_7c9e2b4bc02f} data.")
                _4ac31b6df9e4 = os._0f2b90d76d4c._4c744a9d8371("data", self._6d4845f5c9f0, _7c9e2b4bc02f)
                self._9fb2b9c2138d(_4ac31b6df9e4, _338735cb20db, _76af1444245d, _7c9e2b4bc02f, _d146b56e51c0)
                self._146a2f92fbbf._16a9563cee22(f"Completed Processing {self._91c634f5b556} for {_d146b56e51c0} sentences for {_7c9e2b4bc02f} data.")

    def _74829282fb4c(self, _8e558a2dd805, _d146b56e51c0, _cf4c739c9c98, _fe989a31c706):
        _8e558a2dd805[f"{_d146b56e51c0}_length"] = _8e558a2dd805[f"{_d146b56e51c0} sentence"]._60ce4ea444c8(lambda _95de70370baf: _7ee434c96d7c(_90aec66ae01b(_95de70370baf)._d35822fd3487()))
        _643183a261ad = _8e558a2dd805._96bc081a2f88(["lang_code", "language"])._166e79d4e0c9({
            f"{_d146b56e51c0}_length": [
                lambda _95de70370baf: _95de70370baf[_95de70370baf != 0]._31406d047e7e() if (_95de70370baf != 0)._9d5f87b6c6b7() else 0,
                lambda _95de70370baf: _95de70370baf[_95de70370baf != 0]._6fcd3c7b9131() if (_95de70370baf != 0)._9d5f87b6c6b7() else 0,
                lambda _95de70370baf: (_95de70370baf != 0)._60001c1d617a(),
            ],
        })
        _643183a261ad._36ef3e8457d8 = [f"{_d146b56e51c0}_mean", f"{_d146b56e51c0}_median", f"{_d146b56e51c0}_count"]
        _cad2b954d694 = f"metrics/data/{self._91c634f5b556}_{_d146b56e51c0}_{_fe989a31c706}_{_8dbbd3248490(_cf4c739c9c98*100)}_data_file_metrics.csv"
        _643183a261ad._4672370188c6(_cad2b954d694, _aef57b2ea36f="w+", _ec4fd1d538f5="utf8")

    def _1d17bd9deb9d(self, _4ac31b6df9e4, _8e558a2dd805, _76af1444245d, _7c9e2b4bc02f, _d146b56e51c0):
        for _f7615260ad7c in _8e558a2dd805["language_label"]._26212ee0947e():
            self._146a2f92fbbf._16a9563cee22(f"Now Processing {self._91c634f5b556} for {_f7615260ad7c} language.")
            _037090db4411 = _8e558a2dd805["language_label"]._077518c2975b(_f7615260ad7c)._4ef72a406a75()
            _6138372fcd9b = _8e558a2dd805._4b5db7dc670e[_037090db4411, "lang_code"]
            _c79f7b616ea8 = _8e558a2dd805._4b5db7dc670e[_037090db4411, "language_label"]._d35822fd3487()[-1]._e6eaee4d07a1()

            _8ea4b15d18bc = os._0f2b90d76d4c._4c744a9d8371(_4ac31b6df9e4, _6138372fcd9b)
            os._2557141ad036(_8ea4b15d18bc, _a3bedacdb855=_9458aabf0520)
            # Collect DF for this lang_code to allow source-only dedupe
            _d66fbb2dffe4 = _8e558a2dd805[_8e558a2dd805["lang_code"] == _6138372fcd9b].copy()
            _ce1e127df147 = f"{_d146b56e51c0} sentence"

            # Normalize whitespace for dedupe comparison
            _d66fbb2dffe4["__norm_sent"] = _d66fbb2dffe4[_ce1e127df147]._fe8da73b4540(_90aec66ae01b)._60ce4ea444c8(lambda _9f299f444a88: " "._4c744a9d8371(_90aec66ae01b(_9f299f444a88)._d35822fd3487()))
            _26204e63a54f = _7ee434c96d7c(_d66fbb2dffe4)
            # dedupe only on normalized source sentences, keep first
            _4b4d7902eab7 = _d66fbb2dffe4._902d49a0df4f(_b56203820674=["__norm_sent"], _089a177d1ffb="first")
            _b80c240fbc82 = _8dbbd3248490(_4b4d7902eab7._60001c1d617a())
            _dc3a4b5abf46 = _26204e63a54f - _b80c240fbc82

            # get example unique_identifiers for removed rows if available
            _b5f30599eb40 = []
            if _b80c240fbc82 > 0:
                if "unique_identifier" in _d66fbb2dffe4._36ef3e8457d8:
                    _b5f30599eb40 = _0d9bbfa4e382(_d66fbb2dffe4._4b5db7dc670e[_4b4d7902eab7, "unique_identifier"]._1bc6edcc32e1()._fe8da73b4540(_90aec66ae01b)._26212ee0947e()[:10])
                else:
                    # fallback to short hash of removed sentences
                    _b5f30599eb40 = [hashlib._b38f7827119e(_9f299f444a88._c7a5c83c4761("utf8"))._b0c03e5a1fb2()[:8] for _9f299f444a88 in _d66fbb2dffe4._4b5db7dc670e[_4b4d7902eab7, "__norm_sent"]._fe8da73b4540(_90aec66ae01b)._26212ee0947e()[:10]]

            self._146a2f92fbbf._16a9563cee22(f"Dedup (source only) for lang_code={_6138372fcd9b}, script={_d146b56e51c0}: before={_26204e63a54f} after={_dc3a4b5abf46} removed={_b80c240fbc82}")
            if _b80c240fbc82 > 0:
                self._146a2f92fbbf._16a9563cee22(f"Example removed unique ids (up to 10) for {_6138372fcd9b}: {_b5f30599eb40}")

            # Keep only non-duplicate rows for writing
            _d66fbb2dffe4 = _d66fbb2dffe4._4b5db7dc670e[~_4b4d7902eab7]._cc08462ec1d4(_1f9bf451540a=_9458aabf0520)
            # Make sure the sentence column uses normalized text
            _d66fbb2dffe4[_ce1e127df147] = _d66fbb2dffe4["__norm_sent"]
            _d66fbb2dffe4 = _d66fbb2dffe4[_d66fbb2dffe4[_ce1e127df147]._fe8da73b4540(_90aec66ae01b)._90aec66ae01b._e6eaee4d07a1() != ""]

            _a50e932f8e4d = _d66fbb2dffe4[_ce1e127df147]._1bc6edcc32e1()

            _66d30e42cd5d = os._0f2b90d76d4c._4c744a9d8371(_8ea4b15d18bc, "src")
            _81be57e41fee = os._0f2b90d76d4c._4c744a9d8371(_8ea4b15d18bc, "tgt")
            _f6147f386c00 = self._2c9b109968f0 if _d146b56e51c0._520668d65abd() == "native" else self._efeab8067f5d
            
            os._2557141ad036(_66d30e42cd5d, _a3bedacdb855=_9458aabf0520)
            os._2557141ad036(_81be57e41fee, _a3bedacdb855=_9458aabf0520)
            os._2557141ad036(_f6147f386c00, _a3bedacdb855=_9458aabf0520)

            _6b635c8ed68f = os._0f2b90d76d4c._4c744a9d8371(_66d30e42cd5d, f"{_6138372fcd9b}_{_76af1444245d}.src")
            _f0ddf992d63f = os._0f2b90d76d4c._4c744a9d8371(_81be57e41fee, f"{_6138372fcd9b}_{_76af1444245d}.tgt")
            _ce13d90ae6c3 = "valid" if _7c9e2b4bc02f._520668d65abd() == "val" else _7c9e2b4bc02f
            _f262e7f77314 = os._0f2b90d76d4c._4c744a9d8371(_f6147f386c00, f"{_ce13d90ae6c3}_combine.txt")

            with _cb714f943761(_6b635c8ed68f, "w", _ec4fd1d538f5="utf8") as _67af1969295e,\
                    _cb714f943761(_f0ddf992d63f, "w", _ec4fd1d538f5="utf8") as _7777f1f2a37b,\
                    _cb714f943761(_f262e7f77314, "a+", _ec4fd1d538f5="utf8") as _0db5988aa69c:
                _67af1969295e._fa66da13f508("text\n")
                _7777f1f2a37b._fa66da13f508("lang_code\n")
                for _d6163a449dd3 in _a30e147dcb8d(0, _7ee434c96d7c(_a50e932f8e4d), 1000):
                    _574871391afa = _a50e932f8e4d[_d6163a449dd3:_d6163a449dd3+1000]
                    _ec48eff608e5 = [_6138372fcd9b] * _7ee434c96d7c(_574871391afa)
                    _755ce43afb7e = [f"__label__{_c79f7b616ea8}"] * _7ee434c96d7c(_574871391afa)
                    for _e8f947322870, _b891989ee905, _d86a0d6dcfbd in _0021c04ffd27(_574871391afa, _ec48eff608e5, _755ce43afb7e):
                        _e8f947322870 = _90aec66ae01b(_e8f947322870)._e6eaee4d07a1()
                        if _e8f947322870 and _e8f947322870 != "\n":
                            _67af1969295e._fa66da13f508(f"{_e8f947322870}\n")
                            _7777f1f2a37b._fa66da13f508(f"{_b891989ee905}\n")
                            _0db5988aa69c._fa66da13f508(f"{_d86a0d6dcfbd} {_e8f947322870}\n")

            self._146a2f92fbbf._16a9563cee22(f"Files {_6b635c8ed68f} and {_f0ddf992d63f} with {_7ee434c96d7c(_a50e932f8e4d)} samples have been created.")

# Main function
def _2eded67c3228():
    _4a8da57d341a._437f2d2a3f25(_6e5cd334502a=_cebca20d2fcb(1, math._4f77bb32b051(os._14ba986be6c5() * 0.25)))
    _9c7248f05ebc = _0cd66c62e6a8._f7202af57424(_34d5a8abc84c="Process Bhasha Abhijnaanam Dataset")
    _9c7248f05ebc._92ef92014683(
        "--config_file_path",
        _4b43a52c4b38=_90aec66ae01b,
        _b85a9064788b=_9458aabf0520,
        _7a7237643f62="Pass the yaml config file path",
    )
    try:
        _7838efd5a7fb, _6ed54434fd26 = _9c7248f05ebc._01278558746b()
        _2fe3a09844de = _08576420e93e()._c8b534016545(_1196238593de=_7838efd5a7fb._67f938c179c5)
        _146a2f92fbbf = _29be9218abca()._353f154fbc30(_2fe3a09844de)
        _146a2f92fbbf._16a9563cee22(f"Unknwon args {_6ed54434fd26} hence ignored")
        _45f0a39a4be4(_146a2f92fbbf=_146a2f92fbbf, _2fe3a09844de=_2fe3a09844de)
    except _0cd66c62e6a8._eb301e5163cd as _a72cbad7b46f:
        _7c0478a704ff(f"Error: {_a72cbad7b46f}")
        _9c7248f05ebc._fb09354dc9d6()

if __name__ == "__main__":
    _595f07c54874()
