# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : bhasha_dataset_to_csv
# @Time             : 20/12/23 9:45 am IST
---------------------------------------------------------
"""
import argparse
import csv
import math
import os
from logging import Logger
from urllib.parse import urlparse
import zipfile
from pandarallel import pandarallel
import pandas as pd
import json
import requests
from transformers import AutoTokenizer
from langcodes import Language
from lang_ident_classifier.language.utils.property_utils import PropertyUtils
from lang_ident_classifier.language.utils.log_utils import LogUtils
from lang_ident_classifier.language.utils.file_dir_utils import FileDirUtils

LANG_CODE_DICT = {}

# def extract_lang_code(unique_id):
#     return "_".join(str(unique_id).split("_")[:-1])

def extract_lang_code(language):
    lang = language.lower().strip()

    # Split compound languages
    parts = lang.split("_")

    # Take first 3 letters of each part
    codes = [p[:3] for p in parts]
    base_code = "_".join(codes)
    code = base_code
    idx = 1

    # If language already has a code, return it
    if language in LANG_CODE_DICT:
        return LANG_CODE_DICT[language]

    # Find a unique code that isn't already assigned to a different language
    while code in LANG_CODE_DICT.values():
        # Avoid reassigning same code to the same language
        if any(k != language and v == code for k, v in LANG_CODE_DICT.items()):
            code = f"{base_code}{idx}"
            idx += 1
        else:
            break

    LANG_CODE_DICT[language] = code
    return code


def group_and_sample(df, script_type, frac):
    def inner_group(group):
        return group.sample(frac=frac)

    def outer_group(group):
        return group.groupby(f'{script_type}_length', group_keys=False).apply(inner_group)

    return df.groupby('lang_code', group_keys=False).apply(outer_group)


class BhashaDatasetProcessing:
    def __init__(self, log: Logger, props: PropertyUtils):
        self.train_url = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/parallel_romanized_train_data.zip"
        self.test_url = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/bhasha-abhijnaanam_test_set.zip"
        self.log = log
        self.props = props
        self.train_json_path = self._download_and_extract_json(self.train_url, target_dir="data/preprocessed/train")
        self.test_json_path = self._download_and_extract_json(self.test_url, target_dir="data/preprocessed/test")

        # Extract languages from JSON
        json_languages = self._get_languages_in_json(self.train_json_path)

        # Extract languages from txt files
        native_txt_dir = os.path.join("data", "native_script_train_valid_data", "Native_script_data")
        romanized_txt_dir = os.path.join("data", "roman_script_train_valid_data", "Roman_script_data")

        native_url = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/native_script_train_valid_data.zip"
        romanized_url = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/roman_script_train_valid_data.zip"

        native_txt_languages = self._download_extract_and_extract_languages_from_txt(native_url, "data/native_script_train_valid_data")
        romanized_txt_languages = self._download_extract_and_extract_languages_from_txt(romanized_url, "data/roman_script_train_valid_data")

        # Combine all txt languages
        all_txt_languages = native_txt_languages.union(romanized_txt_languages)

        # Find missing languages in JSON compared to txt datasets
        missing_languages = all_txt_languages - json_languages
        self.log.info(f"Languages in JSON: {json_languages}")
        self.log.info(f"Languages in TXT: {all_txt_languages}")
        self.log.info(f"Missing languages to load from TXT: {missing_languages}")

        # Now process only missing languages from TXT files

        self._process_missing_languages_from_txt(native_txt_dir, "native", missing_languages)
        self._process_missing_languages_from_txt(romanized_txt_dir, "romanized", missing_languages)

        # THIS needs correct paths inside
        self._process_missing_language_csvs_no_split(missing_languages)


        for stage in ['train', 'test']:
            json_file_path = self.train_json_path if stage == 'train' else self.test_json_path
            target_data_dir = "train" if stage == 'train' else "test"
            val_split_ratio = 0.8 if stage == 'train' else 0.0
            self.source_name = os.path.basename(json_file_path).split(".")[0]
            self.src_data_dir = os.path.dirname(json_file_path)
            self.target_data_dir = target_data_dir
            for script_type in ["native", "romanized"]:
                self._process_bhasha_dataset(script_type, val_split_ratio)

    def _process_missing_language_csvs_no_split(self, missing_languages):
        base_original_dir = os.path.join("data", "original")
        dest_dir = os.path.join("data", "train")

        for lang in missing_languages:
            lang_dir = os.path.join(base_original_dir, extract_lang_code(lang))
            if not os.path.exists(lang_dir):
                self.log.warning(f"Missing original data directory not found for language: {lang}")
                continue

            for script_type in ["native", "romanized"]:
                csv_pattern = f"txt_{script_type}_{lang}_{script_type}_original_data.csv"
                csv_path = os.path.join(lang_dir, csv_pattern)
                if not os.path.exists(csv_path):
                    self.log.info(f"No CSV found for {lang} {script_type} at {csv_path}")
                    continue

                df = pd.read_csv(csv_path, quoting=csv.QUOTE_ALL, escapechar="\\")

                # Ensure sentence column exists and is clean
                sentence_col = f"{script_type} sentence"
                if sentence_col not in df.columns:
                    self.log.warning(f"{sentence_col} column missing in {csv_path}, skipping.")
                    continue

                df = df[df[sentence_col].astype(str).str.strip() != ""]
                if df.empty:
                    self.log.warning(f"No valid rows found for {lang} {script_type} in {csv_path}")
                    continue

                # Get lang_code from column directly (same as other processing)
                lang_code = df["lang_code"].iloc[0]

                lang_folder = os.path.join(dest_dir, lang_code)
                os.makedirs(lang_folder, exist_ok=True)

                src_dir = os.path.join(lang_folder, "src")
                tgt_dir = os.path.join(lang_folder, "tgt")
                os.makedirs(src_dir, exist_ok=True)
                os.makedirs(tgt_dir, exist_ok=True)

                prefix = f"txt_{script_type}"

                src_file_path = os.path.join(src_dir, f"{lang_code}_{prefix}.src")
                tgt_file_path = os.path.join(tgt_dir, f"{lang_code}_{prefix}.tgt")

                with open(src_file_path, "w", encoding="utf-8") as src_file, open(tgt_file_path, "w", encoding="utf-8") as tgt_file:
                    src_file.write("text\n")
                    tgt_file.write("lang_code\n")

                    for sentence in df[sentence_col]:
                        sentence = str(sentence).strip()
                        if sentence and sentence != "\n":
                            src_file.write(f"{sentence}\n")
                            tgt_file.write(f"{lang_code}\n")

                self.log.info(f"Written {len(df)} rows to {src_file_path} and {tgt_file_path}")

    def _get_languages_in_json(self, json_file_path):
        """
        Extract unique language names present in the JSON dataset.
        Args:
            json_file_path (str): Path to the JSON file
        Returns:
            Set[str]: Unique languages from the JSON data
        """
        with open(json_file_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)
        languages = set()
        for item in json_data.get("data", []):
            lang = item.get("language")
            if lang:
                languages.add(lang)
        return languages

    def _process_missing_languages_from_txt(self, txt_dir, script_type, missing_languages):
        """
        Process missing languages data from txt files by filtering lines matching missing languages.
        Args:
            txt_dir (str): Directory containing train_combine.txt and valid_combine.txt
            script_type (str): 'native' or 'romanized'
            missing_languages (Set[str]): Languages missing in JSON but present in txt data
        """
        fdu = FileDirUtils()
        prefix = f"txt_{script_type}"

        all_data = []
        for split_file in ["train_combine.txt", "valid_combine.txt"]:
            file_path = os.path.join(txt_dir, split_file)
            if not os.path.exists(file_path):
                self.log.warning(f"File {file_path} not found, skipping.")
                continue
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    parts = line.split(maxsplit=1)
                    if len(parts) < 2:
                        continue
                    label_token, sentence = parts
                    if label_token.startswith("__label__"):
                        lang = label_token[len("__label__"):]
                        if lang in missing_languages:
                            all_data.append({
                                f"{script_type} sentence": sentence,
                                "language": lang,
                                "lang_code": extract_lang_code(lang)  # you can customize lang_code extraction if needed
                            })

        if not all_data:
            self.log.info(f"No missing language data found in {txt_dir} for script {script_type}.")
            return

        df = pd.DataFrame(all_data)

        # Filter out empty sentences
        df = df[df[f"{script_type} sentence"].astype(str).str.strip() != '']

        # Save to CSV per language like your existing method
        for lang_code, lang_group in df.groupby("lang_code"):
            dir_path = f"data/original/{lang_code}"
            fdu.create_dir(dir_path=dir_path)
            lang_tgt_file_path = f"{dir_path}/{prefix}_{lang_code}_{script_type}_original_data.csv"
            lang_group.to_csv(
                lang_tgt_file_path,
                mode="w+",
                encoding="utf8",
                index=False,
                quoting=csv.QUOTE_ALL,
                escapechar="\\",
            )
            self.log.info(f"Missing {lang_code} data written to {lang_tgt_file_path}")

    def _download_extract_and_extract_languages_from_txt(self, url, target_dir):
        import requests, zipfile, os
        from urllib.parse import urlparse

        self.log.info(f"Downloading from {url} into {target_dir}")
        os.makedirs(target_dir, exist_ok=True)

        filename = os.path.basename(urlparse(url).path)
        zip_path = os.path.join(target_dir, filename)

        # Download zip
        with requests.get(url, stream=True) as r:
            r.raise_for_status()
            with open(zip_path, "wb") as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

        # Extract zip
        with zipfile.ZipFile(zip_path, "r") as zip_ref:
            zip_ref.extractall(target_dir)

        # Now find extracted folder containing txt files (e.g., Native_script_data or Roman_script_data)
        extracted_folder = None
        for f in os.listdir(target_dir):
            full_path = os.path.join(target_dir, f)
            if os.path.isdir(full_path) and any(fname.endswith(".txt") for fname in os.listdir(full_path)):
                extracted_folder = full_path
                break

        if not extracted_folder:
            raise FileNotFoundError("Could not find extracted folder with txt files")

        self.log.info(f"Extracted txt files folder: {extracted_folder}")

        # Use your existing method on extracted folder
        return self._extract_languages_from_txt(extracted_folder)


    def _extract_languages_from_txt(self, txt_dir):
        """
        Extract unique languages (labels) from txt dataset files (train + valid).
        """
        languages = set()
        for split_file in ["train_combine.txt", "valid_combine.txt"]:
            file_path = os.path.join(txt_dir, split_file)
            if not os.path.exists(file_path):
                continue
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    label_token = line.split()[0]
                    if label_token.startswith("__label__"):
                        lang = label_token[len("__label__"):]
                        languages.add(lang)
        return languages

    def _download_and_extract_json(self, url, target_dir):
        self.log.info(f"Downloading from {url} into {target_dir}")
        os.makedirs(target_dir, exist_ok=True)

        filename = os.path.basename(urlparse(url).path)
        zip_path = os.path.join(target_dir, filename)

        with requests.get(url, stream=True) as r:
            with open(zip_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(target_dir)

        for file in os.listdir(target_dir):
            if file.endswith('.json'):
                file_path = os.path.join(target_dir, file)
                self.log.info(f"Download complete. File path {file_path}")
                return file_path

        raise FileNotFoundError("No JSON file found in extracted content.")

    def _get_iso_code(self, language_name: str):
        try:
            lang = Language.get(language_name)
            return lang.to_alpha3()
        except Exception:
            code = str(language_name).lower()[:2]
            original_code = code
            while True:
                try:
                    lang = Language.get(code)
                    if lang:
                        code += "x"
                    else:
                        return code[:2]
                except ValueError:
                    return original_code[:3]

    def _split_dataframe(self, df_data: pd.DataFrame, split_ratio: float):
        if split_ratio < 1.0:
            df_data = df_data.sample(frac=1, random_state=self.props.app.random_seed)
        split_index = int(split_ratio * len(df_data))
        return df_data[:split_index], df_data[split_index:]

    def _process_bhasha_dataset(self, script_type: str, split_ratio: float = 0.0, data_sample_percent: float = 1.0):
        fdu = FileDirUtils()
        prefix = self.source_name
        src_file_path = os.path.join(self.src_data_dir, self.source_name + ".json")

        with open(src_file_path, "r+", encoding="utf8") as file:
            json_data = json.load(file)

        df = pd.json_normalize(json_data["data"])
        # df["lang_code"] = df["unique_identifier"].parallel_apply(extract_lang_code)
        df["lang_code"] = df["language"].parallel_apply(extract_lang_code)

        fdu.create_dir(dir_path="metrics/data")

        if script_type.casefold() == "romanized":
            df["lang_code"] = df["lang_code"].apply(lambda x: str(x) + "_en")
            df["language"] = df["language"].apply(lambda x: "Romanized " + str(x))

        self._get_data_metrics(df, script_type, data_sample_percent, action="original")

        subsrting_to_drop = "romanized" if script_type == "native" else "native"
        columns_to_drop = [col for col in df.columns if subsrting_to_drop in col]
        df.drop(columns_to_drop, axis=1, inplace=True)
        df = df[df[f'{script_type} sentence'].astype(str).str.strip() != '']

        for lang_code, lang_group in df.groupby("lang_code"):
            dir_path = f"data/original/{lang_code}"
            fdu.create_dir(dir_path=dir_path)
            lang_tgt_file_path = f"{dir_path}/{self.source_name}_{lang_code}_{script_type}_original_data.csv"
            lang_group.to_csv(
                lang_tgt_file_path,
                mode="w+",
                encoding="utf8",
                index=False,
                quoting=csv.QUOTE_ALL,
                escapechar="\\",
            )
            self.log.info(f"{lang_code} data written to {lang_tgt_file_path}")

        if self.target_data_dir == "train" and data_sample_percent not in [0.0, 1.0]:
            sampled_df = group_and_sample(df, script_type, data_sample_percent)
            df = sampled_df.reset_index(drop=True)

        self._get_data_metrics(df, script_type, data_sample_percent, action="processed")

        if split_ratio == 0:
            self.log.info(f"Started Processing {self.source_name} for {script_type} sentences for {self.target_data_dir} data.")
            dest_dir = os.path.join("data", self.target_data_dir)
            self._write_data_to_files(dest_dir, df, prefix, script_type)
            self.log.info(f"Completed Processing {self.source_name} for {script_type} sentences for {self.target_data_dir} data.")
        else:
            df_train, df_val = self._split_dataframe(df, split_ratio)
            for stage_df, stage_name in [(df_train, "train"), (df_val, "val")]:
                self.log.info(f"Started Processing {self.source_name} for {script_type} sentences for {stage_name} data.")
                dest_dir = os.path.join("data", stage_name)
                self._write_data_to_files(dest_dir, stage_df, prefix, script_type)
                self.log.info(f"Completed Processing {self.source_name} for {script_type} sentences for {stage_name} data.")

    def _get_data_metrics(self, df, script_type, data_sample_percent, action):
        df[f"{script_type}_length"] = df[f"{script_type} sentence"].apply(lambda x: len(str(x).split()))
        grouped_df = df.groupby(["lang_code", "language"]).agg({
            f"{script_type}_length": [
                lambda x: x[x != 0].mean() if (x != 0).any() else 0,
                lambda x: x[x != 0].median() if (x != 0).any() else 0,
                lambda x: (x != 0).sum(),
            ],
        })
        grouped_df.columns = [f"{script_type}_mean", f"{script_type}_median", f"{script_type}_count"]
        metrics_path = f"metrics/data/{self.source_name}_{script_type}_{action}_{int(data_sample_percent*100)}_data_file_metrics.csv"
        grouped_df.to_csv(metrics_path, mode="w+", encoding="utf8")

    def _write_data_to_files(self, dest_dir, df, prefix, script_type):
        for language in df["language"].unique():
            self.log.info(f"Now Processing {self.source_name} for {language} language.")
            first_idx = df["language"].eq(language).idxmax()
            lang_code = df.loc[first_idx, "lang_code"]

            lang_folder = os.path.join(dest_dir, lang_code)
            os.makedirs(lang_folder, exist_ok=True)
            filtered_data = df[df["lang_code"] == lang_code][f"{script_type} sentence"].dropna()
            filtered_data = filtered_data[filtered_data.astype(str).str.strip() != ""]

            src_dir = os.path.join(lang_folder, "src")
            tgt_dir = os.path.join(lang_folder, "tgt")
            os.makedirs(src_dir, exist_ok=True)
            os.makedirs(tgt_dir, exist_ok=True)

            src_file_path = os.path.join(src_dir, f"{lang_code}_{prefix}.src")
            tgt_file_path = os.path.join(tgt_dir, f"{lang_code}_{prefix}.tgt")

            with open(src_file_path, "w", encoding="utf8") as src_file, open(tgt_file_path, "w", encoding="utf8") as tgt_file:
                src_file.write("text\n")
                tgt_file.write("lang_code\n")
                for i in range(0, len(filtered_data), 1000):
                    chunk_src = filtered_data[i:i+1000]
                    chunk_tgt = [lang_code] * len(chunk_src)
                    for src_text, tgt_text in zip(chunk_src, chunk_tgt):
                        src_text = str(src_text).strip()
                        if src_text and src_text != "\n":
                            src_file.write(f"{src_text}\n")
                            tgt_file.write(f"{tgt_text}\n")

            self.log.info(f"Files {src_file_path} and {tgt_file_path} with {len(filtered_data)} samples have been created.")


def main():
    pandarallel.initialize(nb_workers=max(1, math.floor(os.cpu_count() * 0.25)))
    parser = argparse.ArgumentParser(description="Process Bhasha Abhijanaanam Dataset")
    parser.add_argument(
        "--config_file_path",
        type=str,
        required=True,
        help="Pass the yaml config file path",
    )
    try:
        args = parser.parse_args()
        props = PropertyUtils().get_yaml_config_properties(config_file=args.config_file_path)
        log = LogUtils().get_time_rotated_log(props)
        BhashaDatasetProcessing(log=log, props=props)
    except argparse.ArgumentError as e:
        print(f"Error: {e}")
        parser.print_help()


if __name__ == "__main__":
    main()