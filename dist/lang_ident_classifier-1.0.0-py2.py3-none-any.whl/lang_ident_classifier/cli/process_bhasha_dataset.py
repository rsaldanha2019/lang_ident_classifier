# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : process_bhasha_dataset.py
# @Time             : 2025-10-31 09:09 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _93b5ccdd4749
import _6435c1ddaf10
import math
import os
from _f9da4923efea import _9466cf16bbd7
from urllib._79c00e140cc6 import _a2a78d8272d3
import _9d853802c5af
from _707f5dc262f2 import _707f5dc262f2
import _53bd2865783d as _1fd1b71cefcd
import json
import _74a2e9ac6379
from _a44502da38ab import _f5ce9d5722fa
from _f587b2adcdce import _957e417f9c2f
from _c9ed37e8fb1d._f35eba993019._93d8d6418c5e._179568c1128a import _2219ace3ecf6
from _c9ed37e8fb1d._f35eba993019._93d8d6418c5e._fc211d7d1476 import _4deebdb30f35
from _c9ed37e8fb1d._f35eba993019._93d8d6418c5e._44fc2d97fa1f import _541d9c5e516c
import hashlib

_9ab8f796cd15 = {}

# Function to extract language code
def _f045f8642a46(_f35eba993019):
    _024c1575d371 = _f35eba993019._6895ee9b2706()._684485ff126c()

    # Split compound languages
    _629294bc0945 = _024c1575d371._46755fb2bcc1("_")

    # Take first 3 letters of each part
    _4ae75b4b34b7 = [_7b3784170e2f[:3] for _7b3784170e2f in _629294bc0945]
    _db41d05ede75 = "_"._c72b549779e2(_4ae75b4b34b7)
    _f0903ef8f0eb = _db41d05ede75
    _27e71da509b1 = 1

    # If language already has a code, return it
    if _f35eba993019 in _9ab8f796cd15:
        return _9ab8f796cd15[_f35eba993019]

    # Find a unique code that isn't already assigned to a different language
    while _f0903ef8f0eb in _9ab8f796cd15._ea75565b3ad2():
        if _c7384d30e307(_7b5de116f424 != _f35eba993019 and _08f85e30de0a == _f0903ef8f0eb for _7b5de116f424, _08f85e30de0a in _9ab8f796cd15._d07a716f5153()):
            _f0903ef8f0eb = f"{_db41d05ede75}{_27e71da509b1}"
            _27e71da509b1 += 1
        else:
            break

    _9ab8f796cd15[_f35eba993019] = _f0903ef8f0eb
    return _f0903ef8f0eb

# Helper function for grouping and sampling
def _dee3f349cd89(_86d1ceb4ba24, _0aafcebd8403, _a1512d2f1443, _8feff2cbfa35=20):
    def _07bb8314a7ac(_e55d896923ed):
        return _e55d896923ed._2bd6cf857796(_a1512d2f1443=_a1512d2f1443, _2e57cde5a4ca=_8feff2cbfa35)

    def _7a7b756bed40(_e55d896923ed):
        return _e55d896923ed._1db113964fa0(f'{_0aafcebd8403}_length', _647167badd67=_b79ddeae9f20)._48bccea79c48(_e0d789877584)

    return _86d1ceb4ba24._1db113964fa0('lang_code', _647167badd67=_b79ddeae9f20)._48bccea79c48(_07dd0c19d87a)

# Class for dataset processing
class _e2c2c757e2ee:
    def _bc7456d84ae1(self, _14d35d84f999: _9466cf16bbd7, _f8a22e1aac75: _2219ace3ecf6):
        self._bca4de9b1937 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/parallel_romanized_train_data.zip"
        self._321915a2ab53 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/bhasha-abhijnaanam_test_set.zip"
        self._14d35d84f999 = _14d35d84f999
        self._f8a22e1aac75 = _f8a22e1aac75
        self._52b5cbeac77b = _f60f98d4715e(_f60f98d4715e(self._f8a22e1aac75, "dataset", _e5117124e3aa), "dataset_source_dir", "bhasha")
        self._0e8b7edcccc6 = self._1ae251505fa5(self._bca4de9b1937, _41bd841af120=f"data/{self._52b5cbeac77b}/preprocessed/train")
        self._70fc57c63fbf = self._1ae251505fa5(self._321915a2ab53, _41bd841af120=f"data/{self._52b5cbeac77b}/preprocessed/test")
        self._791987836f51 = _f60f98d4715e(_f60f98d4715e(self._f8a22e1aac75, "dataset", _e5117124e3aa), "dataset_share", 1.0)
        self._1af006ca157f = _f60f98d4715e(_f60f98d4715e(self._f8a22e1aac75, "dataset", _e5117124e3aa), "select_languages", [])
        self._05f7e80b1c0b = f"data/{self._52b5cbeac77b}/filtered/native"
        self._ae83dc781f6a = f"data/{self._52b5cbeac77b}/filtered/romanized"

        # Extract languages from JSON
        _355044fc4d8b = self._2522de4e83ba(self._0e8b7edcccc6)

        # Extract languages from txt files
        _6e2c4b2f9ead = os._848afa7e5702._c72b549779e2("data", self._52b5cbeac77b, "native_script_train_valid_data", "Native_script_data")
        _233d8a4e22bb = os._848afa7e5702._c72b549779e2("data", self._52b5cbeac77b, "roman_script_train_valid_data", "Roman_script_data")

        _f2cfcf17a56b = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/native_script_train_valid_data.zip"
        _d4e652df62bf = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/roman_script_train_valid_data.zip"

        _0924e550f14e = self._583c42633691(_f2cfcf17a56b, f"data/{self._52b5cbeac77b}/native_script_train_valid_data")
        _9cbdec5ab09d = self._583c42633691(_d4e652df62bf, f"data/{self._52b5cbeac77b}/roman_script_train_valid_data")

        # Combine all txt languages
        _11563fc4f40c = _0924e550f14e._6ca9805d0c72(_9cbdec5ab09d)

        # === NEW: interpret select_languages empty or ['All'] as "use all languages" ===
        # normalize incoming select_languages
        try:
            _771ac9edb431 = self._1af006ca157f if self._1af006ca157f is not _e5117124e3aa else []
        except _e1683ed9fc5c:
            _771ac9edb431 = []
        # if user passed ['All'] (case-insensitive) or empty list -> set to all discovered languages (union of JSON + TXT)
        _f47eda47464a = _e6706a844a7a(_11563fc4f40c) | _e6706a844a7a(_355044fc4d8b)
        if (_a1fd50ed3006(_771ac9edb431, (_f1e15b12ee7c, _d177e98dc4eb)) and _2fed25d9a60f(_771ac9edb431) == 1 and _644d05b9170a(_771ac9edb431[0])._684485ff126c()._6895ee9b2706() == "all") or (not _771ac9edb431):
            self._1af006ca157f = _c7d265a3e451(_f47eda47464a)
            self._14d35d84f999._8adb0d8a087b("select_languages was empty or ['All'] — using all discovered languages (%d).", _2fed25d9a60f(self._1af006ca157f))
        else:
            # otherwise keep only languages that actually exist in discovered sets
            self._1af006ca157f = [_727926c038c1 for _727926c038c1 in _771ac9edb431 if _727926c038c1 in _f47eda47464a]
            self._14d35d84f999._8adb0d8a087b("Using user-provided select_languages filtered to discovered languages (%d): %s", _2fed25d9a60f(self._1af006ca157f), self._1af006ca157f)

        # If user previously expected the old logic below (narrowing), keep it consistent:
        if self._1af006ca157f:
            _11563fc4f40c = [_727926c038c1 for _727926c038c1 in self._1af006ca157f if _727926c038c1 in _11563fc4f40c]
            _355044fc4d8b = [_727926c038c1 for _727926c038c1 in self._1af006ca157f if _727926c038c1 in _355044fc4d8b]

        # Find missing languages in JSON compared to txt datasets
        _e2c4c849fd43 = _f1e15b12ee7c(_e6706a844a7a(_11563fc4f40c) - _e6706a844a7a(_355044fc4d8b))
        self._14d35d84f999._8adb0d8a087b(f"Languages in JSON: {_355044fc4d8b}")
        self._14d35d84f999._8adb0d8a087b(f"Languages in TXT: {_11563fc4f40c}")
        self._14d35d84f999._8adb0d8a087b(f"Missing languages to load from TXT: {_e2c4c849fd43}")

        # Now process only missing languages from TXT files
        if _e2c4c849fd43:
            self._dbdb8208bb13(_6e2c4b2f9ead, "native", _e2c4c849fd43, self._791987836f51)
            self._dbdb8208bb13(_233d8a4e22bb, "romanized", _e2c4c849fd43, self._791987836f51)

            self._13a917cd1ff8(_e2c4c849fd43)

        for _4faec014d076 in ['train', 'test']:
            _f71007d46ed3 = self._0e8b7edcccc6 if _4faec014d076 == 'train' else self._70fc57c63fbf
            _f42147a1916c = "train" if _4faec014d076 == 'train' else "test"
            _06168bb55350 = 0.8 if _4faec014d076 == 'train' else 0.0
            self._9cfd5e63be48 = os._848afa7e5702._f3a7362e123a(_f71007d46ed3)._46755fb2bcc1(".")[0]
            self._039acd50a01f = os._848afa7e5702._a4c71d25c13f(_f71007d46ed3)
            self._f42147a1916c = _f42147a1916c
            for _0aafcebd8403 in ["native", "romanized"]:
                self._6ccb5c44e063(_0aafcebd8403, _06168bb55350, self._791987836f51)

    # Process missing language CSVs
    def _26997c0d083b(self, _e2c4c849fd43, _1af006ca157f=_e5117124e3aa):
        _90ec905e4a1c = os._848afa7e5702._c72b549779e2("data", self._52b5cbeac77b ,"original")

        for _024c1575d371 in _e2c4c849fd43:
            _970a57cb6897 = os._848afa7e5702._c72b549779e2(_90ec905e4a1c, _5d28e9e374e2(_024c1575d371))
            if not os._848afa7e5702._0f236713b3e2(_970a57cb6897):
                self._14d35d84f999._f717dfc8b17c(f"Missing original data directory not found for language: {_024c1575d371}")
                continue

            for _0aafcebd8403 in ["native", "romanized"]:
                # Detect CSV files for this language
                for _3dcbb61264d2 in os._2d1ad52d2c69(_970a57cb6897):
                    if not _3dcbb61264d2._63bcd86812fc(".csv"):
                        continue
                    if _5d28e9e374e2(_024c1575d371) not in _3dcbb61264d2 or _0aafcebd8403 not in _3dcbb61264d2:
                        continue

                    # Determine destination based on CSV name (train or val)
                    _8ceaea355534 = "train" if "train" in _3dcbb61264d2 else "val"
                    _311e1b446c6e = os._848afa7e5702._c72b549779e2("data", self._52b5cbeac77b, _8ceaea355534)

                    _584f8ca42186 = os._848afa7e5702._c72b549779e2(_970a57cb6897, _3dcbb61264d2)
                    _86d1ceb4ba24 = _1fd1b71cefcd._55b5c682d201(_584f8ca42186, _218dde795076=_6435c1ddaf10._65e87cd64467, _09c7199b4fd8="\\")

                    _8811d8fb55c0 = f"{_0aafcebd8403} sentence"
                    if _8811d8fb55c0 not in _86d1ceb4ba24._3fdae6393708:
                        self._14d35d84f999._f717dfc8b17c(f"{_8811d8fb55c0} column missing in {_584f8ca42186}, skipping.")
                        continue

                    _86d1ceb4ba24 = _86d1ceb4ba24[_86d1ceb4ba24[_8811d8fb55c0]._acf815b94663(_644d05b9170a)._644d05b9170a._684485ff126c() != ""]
                    if _86d1ceb4ba24._32ee2c2f4ceb:
                        self._14d35d84f999._f717dfc8b17c(f"No valid rows found for {_024c1575d371} {_0aafcebd8403} in {_584f8ca42186}")
                        continue

                    _d799a1f4ce06 = _86d1ceb4ba24["lang_code"]._881a91b1538e[0]

                    _9037408fd31f = os._848afa7e5702._c72b549779e2(_311e1b446c6e, _d799a1f4ce06)
                    os._4f177f3feb2d(_9037408fd31f, _c3098793f629=_93c553cf832e)

                    _adff7a4ddcf1 = os._848afa7e5702._c72b549779e2(_9037408fd31f, "src")
                    _0c21e232bc9c = os._848afa7e5702._c72b549779e2(_9037408fd31f, "tgt")
                    os._4f177f3feb2d(_adff7a4ddcf1, _c3098793f629=_93c553cf832e)
                    os._4f177f3feb2d(_0c21e232bc9c, _c3098793f629=_93c553cf832e)

                    _3d39d3d01bb0 = f"txt_{_0aafcebd8403}"
                    _372d2dd42e66 = self._05f7e80b1c0b if _0aafcebd8403._85ec35302777() == "native" else self._ae83dc781f6a
                    os._4f177f3feb2d(_372d2dd42e66, _c3098793f629=_93c553cf832e)

                    _6b4523dad430 = os._848afa7e5702._c72b549779e2(_adff7a4ddcf1, f"{_d799a1f4ce06}_{_3d39d3d01bb0}.src")
                    _da9ff4f407d9 = os._848afa7e5702._c72b549779e2(_0c21e232bc9c, f"{_d799a1f4ce06}_{_3d39d3d01bb0}.tgt")
                    _5d1ab522371e = "valid" if _8ceaea355534._85ec35302777() == "val" else _8ceaea355534
                    _cc7f43f1f0bd = os._848afa7e5702._c72b549779e2(_372d2dd42e66, f"{_5d1ab522371e}_combine.txt")

                    with _695bd05e85d9(_6b4523dad430, "w", _5693f1a677aa="utf-8") as _bc7bcb254178, \
                            _695bd05e85d9(_da9ff4f407d9, "w", _5693f1a677aa="utf-8") as _b4d9af4855f3, \
                            _695bd05e85d9(_cc7f43f1f0bd, "a+", _5693f1a677aa="utf-8") as _42a91740a8e6:
                        _bc7bcb254178._d1964ffa8115("text\n")
                        _b4d9af4855f3._d1964ffa8115("lang_code\n")

                        for _ed0be2800a38 in _86d1ceb4ba24[_8811d8fb55c0]:
                            _ed0be2800a38 = _644d05b9170a(_ed0be2800a38)._684485ff126c()
                            if _ed0be2800a38 and _ed0be2800a38 != "\n":
                                _42a91740a8e6._d1964ffa8115(f"__label__{_024c1575d371} {_ed0be2800a38}\n")
                                _bc7bcb254178._d1964ffa8115(f"{_ed0be2800a38}\n")
                                _b4d9af4855f3._d1964ffa8115(f"{_d799a1f4ce06}\n")

                    self._14d35d84f999._8adb0d8a087b(f"Written {_2fed25d9a60f(_86d1ceb4ba24)} rows to {_6b4523dad430} and {_da9ff4f407d9}")

    # Extract languages from JSON file
    def _aa55686bec58(self, _f71007d46ed3):
        with _695bd05e85d9(_f71007d46ed3, "r", _5693f1a677aa="utf-8") as _f42877381196:
            _d5843ed8d79d = json._54283487740f(_f42877381196)
        _00ba2305e5f8 = _e6706a844a7a()
        for _2ee46fbfd30b in _d5843ed8d79d._92e67a74d58a("data", []):
            _024c1575d371 = _2ee46fbfd30b._92e67a74d58a("language")
            if _024c1575d371:
                _00ba2305e5f8._6b2c65811fa5(_024c1575d371)
        return _00ba2305e5f8

    # Process missing languages from TXT files
    def _fe111f0e8dc3(self, _95fb17a5d9f4, _0aafcebd8403, _e2c4c849fd43, _791987836f51=1.0):
        _868ff16a24bc = _541d9c5e516c()

        for _9489f958ecdd, _7fb92180d8d9 in [("train_combine.txt", "train"), ("valid_combine.txt", "val")]:
            _c1e82b7a74a3 = os._848afa7e5702._c72b549779e2(_95fb17a5d9f4, _9489f958ecdd)
            if not os._848afa7e5702._0f236713b3e2(_c1e82b7a74a3):
                self._14d35d84f999._f717dfc8b17c(f"File {_c1e82b7a74a3} not found, skipping.")
                continue

            _590c52828ffd = []
            with _695bd05e85d9(_c1e82b7a74a3, "r", _5693f1a677aa="utf-8") as _f42877381196:
                for _a4b3a7e19283 in _f42877381196:
                    _a4b3a7e19283 = _a4b3a7e19283._684485ff126c()
                    if not _a4b3a7e19283:
                        continue
                    _629294bc0945 = _a4b3a7e19283._46755fb2bcc1(_de078e223167=1)
                    if _2fed25d9a60f(_629294bc0945) < 2:
                        continue
                    _3e558d68ce72, _ed0be2800a38 = _629294bc0945
                    if _3e558d68ce72._e23a70ed8593("__label__"):
                        _024c1575d371 = _3e558d68ce72[_2fed25d9a60f("__label__"):]
                        if _024c1575d371 in _e2c4c849fd43:
                            _590c52828ffd._0ab89a730e3a({
                                f"{_0aafcebd8403} sentence": _ed0be2800a38,
                                f"{_0aafcebd8403}_length": _644d05b9170a(_ed0be2800a38)._684485ff126c()._46755fb2bcc1()._5cfe27712f15(),
                                "language": _024c1575d371,
                                "lang_code": _5d28e9e374e2(_024c1575d371),
                            })

            if not _590c52828ffd:
                self._14d35d84f999._8adb0d8a087b(f"No missing language data found in {_c1e82b7a74a3} for script {_0aafcebd8403}.")
                continue

            _86d1ceb4ba24 = _1fd1b71cefcd._b105fcb9c92e(_590c52828ffd)
            _86d1ceb4ba24 = _86d1ceb4ba24[_86d1ceb4ba24[f"{_0aafcebd8403} sentence"]._acf815b94663(_644d05b9170a)._644d05b9170a._684485ff126c() != '']

            # Sample data if needed
            if _791987836f51 not in [0.0, 1.0]:
                _86d1ceb4ba24 = _57dc800ed288(_86d1ceb4ba24=_86d1ceb4ba24, 
                                      _0aafcebd8403=_0aafcebd8403, 
                                      _a1512d2f1443=self._791987836f51,
                                      _8feff2cbfa35=self._f8a22e1aac75._cd748a7d5fe8._8feff2cbfa35)

            # Write separate CSV per language per split
            for _d799a1f4ce06, _e62ec41da29c in _86d1ceb4ba24._1db113964fa0("lang_code"):
                # Skip if this group corresponds to English
                if _0aafcebd8403._85ec35302777()=="romanized" and _e62ec41da29c["language"]._881a91b1538e[0] == "English":
                    continue
                _457901bef101 = f"data/{self._52b5cbeac77b}/original/{_d799a1f4ce06}"
                _868ff16a24bc._90a66021dcae(_457901bef101=_457901bef101)
                _274dc35f0496 = f"{_457901bef101}/txt_{_0aafcebd8403}_{_d799a1f4ce06}_{_7fb92180d8d9}_original_data.csv"
                _e62ec41da29c._46e6da556116(
                    _274dc35f0496,
                    _2b922ebdb4d5="w+",
                    _5693f1a677aa="utf8",
                    _a43999926647=_b79ddeae9f20,
                    _218dde795076=_6435c1ddaf10._65e87cd64467,
                    _09c7199b4fd8="\\",
                )
                self._14d35d84f999._8adb0d8a087b(f"Missing {_d799a1f4ce06} data ({_7fb92180d8d9}) written to {_274dc35f0496}")

    # Download and extract languages from txt file
    def _0952f5203bf9(self, _fdb711abe3ba, _41bd841af120, _b4a57c82b778=3, _06dc91569ab6=_b79ddeae9f20):
        import time
        import _74a2e9ac6379, _9d853802c5af, os
        from urllib._79c00e140cc6 import _a2a78d8272d3

        self._14d35d84f999._8adb0d8a087b(f"Preparing to download from {_fdb711abe3ba} into {_41bd841af120}")
        os._4f177f3feb2d(_41bd841af120, _c3098793f629=_93c553cf832e)

        _18e916f2a253 = os._848afa7e5702._f3a7362e123a(_a2a78d8272d3(_fdb711abe3ba)._848afa7e5702)
        _1553dbaaa134 = os._848afa7e5702._c72b549779e2(_41bd841af120, _18e916f2a253)

        # Skip download if file exists and redownload is False
        if os._848afa7e5702._0f236713b3e2(_1553dbaaa134) and not _06dc91569ab6:
            self._14d35d84f999._8adb0d8a087b(f"File already exists, skipping download: {_1553dbaaa134}")
        else:
            for _aa678a32de10 in _811c352b4eb2(_b4a57c82b778):
                try:
                    with _74a2e9ac6379._92e67a74d58a(_fdb711abe3ba, _9a21186e1e33=_93c553cf832e, _ddf3fcd3dd90=30) as _a29c9d2ed0d4:
                        _a29c9d2ed0d4._d3b8046b577c()
                        with _695bd05e85d9(_1553dbaaa134, "wb") as _f42877381196:
                            for _4e845479cebc in _a29c9d2ed0d4._223bfabe9c61(_f9055631f755=8192):
                                if _4e845479cebc:
                                    _f42877381196._d1964ffa8115(_4e845479cebc)
                    self._14d35d84f999._8adb0d8a087b(f"Download complete: {_1553dbaaa134}")
                    break
                except (_74a2e9ac6379._29c18caaaa23._8563407b3720,
                        _74a2e9ac6379._29c18caaaa23._4b502fd160f8,
                        _74a2e9ac6379._29c18caaaa23._159d72732c5e) as _32b93c780ccd:
                    self._14d35d84f999._f717dfc8b17c(f"Download attempt {_aa678a32de10+1} failed: {_32b93c780ccd}")
                    if _aa678a32de10 < _b4a57c82b778 - 1:
                        time._7c9cef682feb(5)  # wait before retrying
                    else:
                        raise _aee7e0d4214c(f"Failed to download {_fdb711abe3ba} after {_b4a57c82b778} attempts")

        # Extract ZIP
        with _9d853802c5af._02cefe5e44ec(_1553dbaaa134, "r") as _5671ddea18aa:
            _5671ddea18aa._c4d0a71093c4(_41bd841af120)

        # Find extracted folder containing .txt files (Native or Romanized)
        _fc9aa2eb9cfc = _e5117124e3aa
        for _f42877381196 in os._2d1ad52d2c69(_41bd841af120):
            _59f7eb17d759 = os._848afa7e5702._c72b549779e2(_41bd841af120, _f42877381196)
            if os._848afa7e5702._45660425274b(_59f7eb17d759) and _c7384d30e307(_bf637e469c12._63bcd86812fc(".txt") for _bf637e469c12 in os._2d1ad52d2c69(_59f7eb17d759)):
                _fc9aa2eb9cfc = _59f7eb17d759
                break

        if not _fc9aa2eb9cfc:
            raise _d36507272546("Could not find extracted folder with txt files")

        self._14d35d84f999._8adb0d8a087b(f"Extracted txt files folder: {_fc9aa2eb9cfc}")

        # Return set of unique languages in the extracted folder
        return self._1d2c17361f6a(_fc9aa2eb9cfc)

    # Extract languages from a txt folder
    def _8b34b4582246(self, _95fb17a5d9f4):
        _00ba2305e5f8 = _e6706a844a7a()
        for _9489f958ecdd in ["train_combine.txt", "valid_combine.txt"]:
            _c1e82b7a74a3 = os._848afa7e5702._c72b549779e2(_95fb17a5d9f4, _9489f958ecdd)
            if not os._848afa7e5702._0f236713b3e2(_c1e82b7a74a3):
                continue
            with _695bd05e85d9(_c1e82b7a74a3, "r", _5693f1a677aa="utf-8") as _f42877381196:
                for _a4b3a7e19283 in _f42877381196:
                    _a4b3a7e19283 = _a4b3a7e19283._684485ff126c()
                    if not _a4b3a7e19283:
                        continue
                    _3e558d68ce72 = _a4b3a7e19283._46755fb2bcc1()[0]
                    if _3e558d68ce72._e23a70ed8593("__label__"):
                        _024c1575d371 = _3e558d68ce72[_2fed25d9a60f("__label__"):]
                        _00ba2305e5f8._6b2c65811fa5(_024c1575d371)
        return _00ba2305e5f8

    def _f5c958b84ba1(self, _fdb711abe3ba, _41bd841af120, _b4a57c82b778=3, _06dc91569ab6=_b79ddeae9f20):
        import time
        self._14d35d84f999._8adb0d8a087b(f"Preparing to download from {_fdb711abe3ba} into {_41bd841af120}")
        os._4f177f3feb2d(_41bd841af120, _c3098793f629=_93c553cf832e)

        _18e916f2a253 = os._848afa7e5702._f3a7362e123a(_a2a78d8272d3(_fdb711abe3ba)._848afa7e5702)
        _1553dbaaa134 = os._848afa7e5702._c72b549779e2(_41bd841af120, _18e916f2a253)

        # Skip download if file exists and redownload is False
        if os._848afa7e5702._0f236713b3e2(_1553dbaaa134) and not _06dc91569ab6:
            self._14d35d84f999._8adb0d8a087b(f"File already exists, skipping download: {_1553dbaaa134}")
        else:
            for _aa678a32de10 in _811c352b4eb2(_b4a57c82b778):
                try:
                    with _74a2e9ac6379._92e67a74d58a(_fdb711abe3ba, _9a21186e1e33=_93c553cf832e, _ddf3fcd3dd90=30) as _a29c9d2ed0d4:
                        _a29c9d2ed0d4._d3b8046b577c()
                        with _695bd05e85d9(_1553dbaaa134, 'wb') as _f42877381196:
                            for _4e845479cebc in _a29c9d2ed0d4._223bfabe9c61(_f9055631f755=8192):
                                if _4e845479cebc:
                                    _f42877381196._d1964ffa8115(_4e845479cebc)
                    self._14d35d84f999._8adb0d8a087b(f"Download complete: {_1553dbaaa134}")
                    break
                except (_74a2e9ac6379._29c18caaaa23._8563407b3720,
                        _74a2e9ac6379._29c18caaaa23._4b502fd160f8,
                        _74a2e9ac6379._29c18caaaa23._159d72732c5e) as _32b93c780ccd:
                    self._14d35d84f999._f717dfc8b17c(f"Download attempt {_aa678a32de10+1} failed: {_32b93c780ccd}")
                    if _aa678a32de10 < _b4a57c82b778 - 1:
                        time._7c9cef682feb(5)  # wait before retrying
                    else:
                        raise _aee7e0d4214c(f"Failed to download {_fdb711abe3ba} after {_b4a57c82b778} attempts")

        # Extract ZIP
        with _9d853802c5af._02cefe5e44ec(_1553dbaaa134, 'r') as _5671ddea18aa:
            _5671ddea18aa._c4d0a71093c4(_41bd841af120)

        # Return JSON file path
        for _ea819d238d1e in os._2d1ad52d2c69(_41bd841af120):
            if _ea819d238d1e._63bcd86812fc('.json'):
                _c1e82b7a74a3 = os._848afa7e5702._c72b549779e2(_41bd841af120, _ea819d238d1e)
                self._14d35d84f999._8adb0d8a087b(f"Extracted JSON file: {_c1e82b7a74a3}")
                return _c1e82b7a74a3

        raise _d36507272546("No JSON file found in extracted content.")

    def _2a637b060068(self, _654daec3f08a: _644d05b9170a):
        try:
            _024c1575d371 = _957e417f9c2f._92e67a74d58a(_654daec3f08a)
            return _024c1575d371._2bc15e43c159()
        except _e1683ed9fc5c:
            _f0903ef8f0eb = _644d05b9170a(_654daec3f08a)._6895ee9b2706()[:2]
            _5b9daf32f963 = _f0903ef8f0eb
            while _93c553cf832e:
                try:
                    _024c1575d371 = _957e417f9c2f._92e67a74d58a(_f0903ef8f0eb)
                    if _024c1575d371:
                        _f0903ef8f0eb += "x"
                    else:
                        return _f0903ef8f0eb[:2]
                except _50f130c87a2b:
                    return _5b9daf32f963[:3]

    def _b1edad4dc96d(self, _7a3a32c599f7: _1fd1b71cefcd._b105fcb9c92e, _dc8632562d1f: _0aea680f0014):
        if _dc8632562d1f < 1.0:
            _7a3a32c599f7 = _7a3a32c599f7._2bd6cf857796(_a1512d2f1443=1, _2e57cde5a4ca=self._f8a22e1aac75._cd748a7d5fe8._8feff2cbfa35)
        _be33364230fe = _9d47a95194d7(_dc8632562d1f * _2fed25d9a60f(_7a3a32c599f7))
        return _7a3a32c599f7[:_be33364230fe], _7a3a32c599f7[_be33364230fe:]

    def _47b013d61995(self, _9076781dedca):
        _56ef61456d4d = _9076781dedca._46755fb2bcc1("-")[-1][:4]  # first 4 letters of last part
        if _56ef61456d4d == "Maye":  # Special Case
            return "Mei"
        return _56ef61456d4d

    def _908085d7789a(self, _e0c6e0f3e9f5):
        _629294bc0945 = _e0c6e0f3e9f5['unique_identifier']._46755fb2bcc1('_')
        if _2fed25d9a60f(_629294bc0945) > 2:
            _3cd82906bc91 = self._34d5bc0742c5(_e0c6e0f3e9f5['script'])
            return _e0c6e0f3e9f5['language'] + "_" + _3cd82906bc91
        else:
            return _e0c6e0f3e9f5['language']

    def _9aea956d8e0c(self, _e0c6e0f3e9f5):
        if "Romanized Kashmiri" in _e0c6e0f3e9f5['language'] and "Kashmiri" in _e0c6e0f3e9f5['language_label']:
            return "Kashmiri"
        return _e0c6e0f3e9f5['language_label']

    def _8158b73830f0(self, _0aafcebd8403: _644d05b9170a, _dc8632562d1f: _0aea680f0014 = 0.0, _791987836f51: _0aea680f0014 = 1.0):
        _868ff16a24bc = _541d9c5e516c()
        _3d39d3d01bb0 = self._9cfd5e63be48
        _6b4523dad430 = os._848afa7e5702._c72b549779e2(self._039acd50a01f, self._9cfd5e63be48 + ".json")

        with _695bd05e85d9(_6b4523dad430, "r+", _5693f1a677aa="utf8") as _ea819d238d1e:
            _d5843ed8d79d = json._54283487740f(_ea819d238d1e)

        _86d1ceb4ba24 = _1fd1b71cefcd._33e83af7110a(_d5843ed8d79d["data"])

        # Filter languages if provided
        _86d1ceb4ba24 = _86d1ceb4ba24[_86d1ceb4ba24["language"]._9bd5f69530c6(self._1af006ca157f)] if _f60f98d4715e(self, "select_languages", _e5117124e3aa) else _86d1ceb4ba24
        _86d1ceb4ba24["language_label"] = _86d1ceb4ba24._48bccea79c48(self._0b7e9060e38f, _e2e74afbcc37=1)
        if _0aafcebd8403._85ec35302777() == "romanized":
            _86d1ceb4ba24["language"] = _86d1ceb4ba24["language"]._48bccea79c48(lambda _727926c038c1: "Romanized " + _644d05b9170a(_727926c038c1))

        _86d1ceb4ba24["language_label"] = _86d1ceb4ba24._48bccea79c48(self._5c7cc07a5ee3, _e2e74afbcc37=1)
        _86d1ceb4ba24["lang_code"] = _86d1ceb4ba24["language_label"]._14e4992f23ab(_5d28e9e374e2)

        _868ff16a24bc._90a66021dcae(_457901bef101="metrics/data")

        if _0aafcebd8403._85ec35302777() == "romanized":
            _86d1ceb4ba24["lang_code"] = _86d1ceb4ba24["lang_code"]._48bccea79c48(lambda _727926c038c1: _644d05b9170a(_727926c038c1) + "_en")

        self._e377f7c65e68(_86d1ceb4ba24, _0aafcebd8403, _791987836f51, _0cc1253c784f="original")

        _e1f71f4eb1f4 = "romanized" if _0aafcebd8403 == "native" else "native"
        _83ee73bb19de = [_edcaab5c5fd2 for _edcaab5c5fd2 in _86d1ceb4ba24._3fdae6393708 if _e1f71f4eb1f4 in _edcaab5c5fd2]
        _86d1ceb4ba24._ba5468c9f627(_83ee73bb19de, _e2e74afbcc37=1, _5428fb283519=_93c553cf832e)
        _86d1ceb4ba24 = _86d1ceb4ba24[_86d1ceb4ba24[f'{_0aafcebd8403} sentence']._acf815b94663(_644d05b9170a)._644d05b9170a._684485ff126c() != '']

        # Write per-language CSV files
        for _d799a1f4ce06, _e62ec41da29c in _86d1ceb4ba24._1db113964fa0("lang_code"):
            _457901bef101 = f"data/{self._52b5cbeac77b}/original/{_d799a1f4ce06}"
            _868ff16a24bc._90a66021dcae(_457901bef101=_457901bef101)
            _274dc35f0496 = f"{_457901bef101}/{self._9cfd5e63be48}_{_d799a1f4ce06}_{_0aafcebd8403}_original_data.csv"
            _e62ec41da29c._46e6da556116(
                _274dc35f0496,
                _2b922ebdb4d5="w+",
                _5693f1a677aa="utf8",
                _a43999926647=_b79ddeae9f20,
                _218dde795076=_6435c1ddaf10._65e87cd64467,
                _09c7199b4fd8="\\",
            )
            self._14d35d84f999._8adb0d8a087b(f"{_d799a1f4ce06} data written to {_274dc35f0496}")

        # Sample if needed for train set
        if self._f42147a1916c == "train" and _791987836f51 not in [0.0, 1.0]:
            _2f2b660357a1 = _57dc800ed288(_86d1ceb4ba24,
                                          _0aafcebd8403,
                                          _791987836f51,
                                          _8feff2cbfa35=self._f8a22e1aac75._cd748a7d5fe8._8feff2cbfa35
                                          )
            _86d1ceb4ba24 = _2f2b660357a1._46004c40caa0(_ba5468c9f627=_93c553cf832e)

        self._e377f7c65e68(_86d1ceb4ba24, _0aafcebd8403, _791987836f51, _0cc1253c784f="processed")

        if _dc8632562d1f == 0:
            self._14d35d84f999._8adb0d8a087b(f"Started Processing {self._9cfd5e63be48} for {_0aafcebd8403} sentences for {self._f42147a1916c} data.")
            _311e1b446c6e = os._848afa7e5702._c72b549779e2("data", self._52b5cbeac77b, self._f42147a1916c)
            _e8a0cc112a37 = "test"
            self._b7677199c86b(_311e1b446c6e, _86d1ceb4ba24, _3d39d3d01bb0, _e8a0cc112a37, _0aafcebd8403)
            self._14d35d84f999._8adb0d8a087b(f"Completed Processing {self._9cfd5e63be48} for {_0aafcebd8403} sentences for {self._f42147a1916c} data.")
        else:
            _9bb6574e13c1, _f5ac8f7e5904 = self._98d6182c94f9(_86d1ceb4ba24, _dc8632562d1f)
            for _b17ed564d962, _e8a0cc112a37 in [(_9bb6574e13c1, "train"), (_f5ac8f7e5904, "val")]:
                self._14d35d84f999._8adb0d8a087b(f"Started Processing {self._9cfd5e63be48} for {_0aafcebd8403} sentences for {_e8a0cc112a37} data.")
                _311e1b446c6e = os._848afa7e5702._c72b549779e2("data", self._52b5cbeac77b, _e8a0cc112a37)
                self._b7677199c86b(_311e1b446c6e, _b17ed564d962, _3d39d3d01bb0, _e8a0cc112a37, _0aafcebd8403)
                self._14d35d84f999._8adb0d8a087b(f"Completed Processing {self._9cfd5e63be48} for {_0aafcebd8403} sentences for {_e8a0cc112a37} data.")

    def _3c291b163ab7(self, _86d1ceb4ba24, _0aafcebd8403, _791987836f51, _0cc1253c784f):
        _86d1ceb4ba24[f"{_0aafcebd8403}_length"] = _86d1ceb4ba24[f"{_0aafcebd8403} sentence"]._48bccea79c48(lambda _727926c038c1: _2fed25d9a60f(_644d05b9170a(_727926c038c1)._46755fb2bcc1()))
        _8aeee0c7ed99 = _86d1ceb4ba24._1db113964fa0(["lang_code", "language"])._af0b06a850b6({
            f"{_0aafcebd8403}_length": [
                lambda _727926c038c1: _727926c038c1[_727926c038c1 != 0]._8eb66e307a2f() if (_727926c038c1 != 0)._c7384d30e307() else 0,
                lambda _727926c038c1: _727926c038c1[_727926c038c1 != 0]._c4c53e932b6d() if (_727926c038c1 != 0)._c7384d30e307() else 0,
                lambda _727926c038c1: (_727926c038c1 != 0)._bbdc992cce4a(),
            ],
        })
        _8aeee0c7ed99._3fdae6393708 = [f"{_0aafcebd8403}_mean", f"{_0aafcebd8403}_median", f"{_0aafcebd8403}_count"]
        _a21e1d2289df = f"metrics/data/{self._9cfd5e63be48}_{_0aafcebd8403}_{_0cc1253c784f}_{_9d47a95194d7(_791987836f51*100)}_data_file_metrics.csv"
        _8aeee0c7ed99._46e6da556116(_a21e1d2289df, _2b922ebdb4d5="w+", _5693f1a677aa="utf8")

    def _55152c55123a(self, _311e1b446c6e, _86d1ceb4ba24, _3d39d3d01bb0, _e8a0cc112a37, _0aafcebd8403):
        for _625f04f7ea3a in _86d1ceb4ba24["language_label"]._429e3da47df5():
            self._14d35d84f999._8adb0d8a087b(f"Now Processing {self._9cfd5e63be48} for {_625f04f7ea3a} language.")
            _a487ff10dfb5 = _86d1ceb4ba24["language_label"]._28b2e8fa2b9e(_625f04f7ea3a)._94d1ff04959c()
            _d799a1f4ce06 = _86d1ceb4ba24._b36916afc78b[_a487ff10dfb5, "lang_code"]
            _42cc35f51e4a = _86d1ceb4ba24._b36916afc78b[_a487ff10dfb5, "language_label"]._46755fb2bcc1()[-1]._684485ff126c()

            _9037408fd31f = os._848afa7e5702._c72b549779e2(_311e1b446c6e, _d799a1f4ce06)
            os._4f177f3feb2d(_9037408fd31f, _c3098793f629=_93c553cf832e)
            # Collect DF for this lang_code to allow source-only dedupe
            _50fec718792b = _86d1ceb4ba24[_86d1ceb4ba24["lang_code"] == _d799a1f4ce06].copy()
            _4ec2843eb034 = f"{_0aafcebd8403} sentence"

            # Normalize whitespace for dedupe comparison
            _50fec718792b["__norm_sent"] = _50fec718792b[_4ec2843eb034]._acf815b94663(_644d05b9170a)._48bccea79c48(lambda _ea286106038f: " "._c72b549779e2(_644d05b9170a(_ea286106038f)._46755fb2bcc1()))
            _df7a2f544460 = _2fed25d9a60f(_50fec718792b)
            # dedupe only on normalized source sentences, keep first
            _6cf5c2466f03 = _50fec718792b._cee81fc07221(_134e97c791d1=["__norm_sent"], _30e3ff0f09ad="first")
            _aff94876521a = _9d47a95194d7(_6cf5c2466f03._bbdc992cce4a())
            _9f92e07e0df2 = _df7a2f544460 - _aff94876521a

            # get example unique_identifiers for removed rows if available
            _dde6d040400f = []
            if _aff94876521a > 0:
                if "unique_identifier" in _50fec718792b._3fdae6393708:
                    _dde6d040400f = _f1e15b12ee7c(_50fec718792b._b36916afc78b[_6cf5c2466f03, "unique_identifier"]._3048df217c55()._acf815b94663(_644d05b9170a)._429e3da47df5()[:10])
                else:
                    # fallback to short hash of removed sentences
                    _dde6d040400f = [hashlib._ff435845521c(_ea286106038f._f21bf17c4b32("utf8"))._f30719a786bf()[:8] for _ea286106038f in _50fec718792b._b36916afc78b[_6cf5c2466f03, "__norm_sent"]._acf815b94663(_644d05b9170a)._429e3da47df5()[:10]]

            self._14d35d84f999._8adb0d8a087b(f"Dedup (source only) for lang_code={_d799a1f4ce06}, script={_0aafcebd8403}: before={_df7a2f544460} after={_9f92e07e0df2} removed={_aff94876521a}")
            if _aff94876521a > 0:
                self._14d35d84f999._8adb0d8a087b(f"Example removed unique ids (up to 10) for {_d799a1f4ce06}: {_dde6d040400f}")

            # Keep only non-duplicate rows for writing
            _50fec718792b = _50fec718792b._b36916afc78b[~_6cf5c2466f03]._46004c40caa0(_ba5468c9f627=_93c553cf832e)
            # Make sure the sentence column uses normalized text
            _50fec718792b[_4ec2843eb034] = _50fec718792b["__norm_sent"]
            _50fec718792b = _50fec718792b[_50fec718792b[_4ec2843eb034]._acf815b94663(_644d05b9170a)._644d05b9170a._684485ff126c() != ""]

            _387d323e1a42 = _50fec718792b[_4ec2843eb034]._3048df217c55()

            _adff7a4ddcf1 = os._848afa7e5702._c72b549779e2(_9037408fd31f, "src")
            _0c21e232bc9c = os._848afa7e5702._c72b549779e2(_9037408fd31f, "tgt")
            _372d2dd42e66 = self._05f7e80b1c0b if _0aafcebd8403._85ec35302777() == "native" else self._ae83dc781f6a
            
            os._4f177f3feb2d(_adff7a4ddcf1, _c3098793f629=_93c553cf832e)
            os._4f177f3feb2d(_0c21e232bc9c, _c3098793f629=_93c553cf832e)
            os._4f177f3feb2d(_372d2dd42e66, _c3098793f629=_93c553cf832e)

            _6b4523dad430 = os._848afa7e5702._c72b549779e2(_adff7a4ddcf1, f"{_d799a1f4ce06}_{_3d39d3d01bb0}.src")
            _da9ff4f407d9 = os._848afa7e5702._c72b549779e2(_0c21e232bc9c, f"{_d799a1f4ce06}_{_3d39d3d01bb0}.tgt")
            _5d1ab522371e = "valid" if _e8a0cc112a37._85ec35302777() == "val" else _e8a0cc112a37
            _cc7f43f1f0bd = os._848afa7e5702._c72b549779e2(_372d2dd42e66, f"{_5d1ab522371e}_combine.txt")

            with _695bd05e85d9(_6b4523dad430, "w", _5693f1a677aa="utf8") as _bc7bcb254178,\
                    _695bd05e85d9(_da9ff4f407d9, "w", _5693f1a677aa="utf8") as _b4d9af4855f3,\
                    _695bd05e85d9(_cc7f43f1f0bd, "a+", _5693f1a677aa="utf8") as _42a91740a8e6:
                _bc7bcb254178._d1964ffa8115("text\n")
                _b4d9af4855f3._d1964ffa8115("lang_code\n")
                for _9caacf076a8d in _811c352b4eb2(0, _2fed25d9a60f(_387d323e1a42), 1000):
                    _5005486faa98 = _387d323e1a42[_9caacf076a8d:_9caacf076a8d+1000]
                    _d5d7aa1e6580 = [_d799a1f4ce06] * _2fed25d9a60f(_5005486faa98)
                    _d4077553676b = [f"__label__{_42cc35f51e4a}"] * _2fed25d9a60f(_5005486faa98)
                    for _28b6ec7d80ba, _c8f229e0a3cc, _05cb32382659 in _7d2ae8df68ba(_5005486faa98, _d5d7aa1e6580, _d4077553676b):
                        _28b6ec7d80ba = _644d05b9170a(_28b6ec7d80ba)._684485ff126c()
                        if _28b6ec7d80ba and _28b6ec7d80ba != "\n":
                            _bc7bcb254178._d1964ffa8115(f"{_28b6ec7d80ba}\n")
                            _b4d9af4855f3._d1964ffa8115(f"{_c8f229e0a3cc}\n")
                            _42a91740a8e6._d1964ffa8115(f"{_05cb32382659} {_28b6ec7d80ba}\n")

            self._14d35d84f999._8adb0d8a087b(f"Files {_6b4523dad430} and {_da9ff4f407d9} with {_2fed25d9a60f(_387d323e1a42)} samples have been created.")

# Main function
def _ed462ce8eb22():
    _707f5dc262f2._db92b85e7070(_df98709e59b6=_4cea97129a37(1, math._57942cbb59b0(os._0f6754f2e8b5() * 0.25)))
    _40ce5f077663 = _93b5ccdd4749._fff99edcffec(_e04ff368ce5c="Process Bhasha Abhijnaanam Dataset")
    _40ce5f077663._949e567f0c87(
        "--config_file_path",
        _759e121c07eb=_644d05b9170a,
        _c7d253da2d4a=_93c553cf832e,
        _d52becb30468="Pass the yaml config file path",
    )
    try:
        _7b205e0c18b9, _7d56c383aa01 = _40ce5f077663._85ec963bdb91()
        _f8a22e1aac75 = _2219ace3ecf6()._0df811547cc3(_e542d630c77d=_7b205e0c18b9._7ebd14de9ae1)
        _14d35d84f999 = _4deebdb30f35()._376807e19b09(_f8a22e1aac75)
        _14d35d84f999._8adb0d8a087b(f"Unknwon args {_7d56c383aa01} hence ignored")
        _0470da4ccc1a(_14d35d84f999=_14d35d84f999, _f8a22e1aac75=_f8a22e1aac75)
    except _93b5ccdd4749._801da5140fef as _32b93c780ccd:
        _abadbb3035ee(f"Error: {_32b93c780ccd}")
        _40ce5f077663._f8d2ee132c1d()

if __name__ == "__main__":
    _a67d5776be47()
