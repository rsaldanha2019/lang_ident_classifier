# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : process_bhasha_dataset.py
# @Time             : 2025-10-31 09:09 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

import _9758a2eabd10
import _7c64f3b0858e
import _78f48d3a6483
import _474f0c6b5644
from _abd92e914964 import _4654ad49a8cf
from _15f50c150e8a._aec96e0975b3 import _974825bce0d4
import _ec2cce95e98b
from _0e93e8a53f49 import _0e93e8a53f49
import _ce9fca33d503 as _7609f56a82f6
import _a5e2dc209723
import _c87f550d0157
from _d79b1e9ca901 import _e5341333809f
from _dd5584eaa6cb import _a4075ce4d16b
from _722351c96075._1a255791e333._bfb42684f704._9ec768b256a9 import _6557c684951e
from _722351c96075._1a255791e333._bfb42684f704._9c6e4587e292 import _c9282304e7cf
from _722351c96075._1a255791e333._bfb42684f704._f4023ba1bad5 import _c191c193d3cf
import _50c703e865ef

_684f15436d4b = {}

# Function to extract language code
def _755263456e05(_1a255791e333):
    _15b787311920 = _1a255791e333._97a359019e6e()._d9ce41a6b96d()

    # Split compound languages
    _35593142465a = _15b787311920._41353d24bb76("_")

    # Take first 3 letters of each part
    _36f06cc663c5 = [_c28f9729f237[:3] for _c28f9729f237 in _35593142465a]
    _a6423a1a2472 = "_"._68c510cd02a4(_36f06cc663c5)
    _7c478244a7e4 = _a6423a1a2472
    _c3423f75e1df = 1

    # If language already has a code, return it
    if _1a255791e333 in _684f15436d4b:
        return _684f15436d4b[_1a255791e333]

    # Find a unique code that isn't already assigned to a different language
    while _7c478244a7e4 in _684f15436d4b._2b6fb49ef458():
        if _4dff4d21f769(_6a162f85cd18 != _1a255791e333 and _9ed26f9a43ee == _7c478244a7e4 for _6a162f85cd18, _9ed26f9a43ee in _684f15436d4b._13eef4cc2a1c()):
            _7c478244a7e4 = f"{_a6423a1a2472}{_c3423f75e1df}"
            _c3423f75e1df += 1
        else:
            break

    _684f15436d4b[_1a255791e333] = _7c478244a7e4
    return _7c478244a7e4

# Helper function for grouping and sampling
def _69d1b21e8155(_bd09ea28dc5e, _2958b816a061, _c599acb1320c, _117cda410664=20):
    def _8133306f0a27(_907fe5daef9f):
        return _907fe5daef9f._3375e39f24a1(_c599acb1320c=_c599acb1320c, _b438c45d5e09=_117cda410664)

    def _be7606be4cac(_907fe5daef9f):
        return _907fe5daef9f._4b9e5c6fb0d8(f'{_2958b816a061}_length', _fe57f700fb70=_cbaafab8b31a)._6890f5a18c4d(_e18e857a9dea)

    return _bd09ea28dc5e._4b9e5c6fb0d8('lang_code', _fe57f700fb70=_cbaafab8b31a)._6890f5a18c4d(_73efbe802173)

# Class for dataset processing
class _1f0a8844fa32:
    def _88383c7fe9a1(self, _1cf0cb2a571a: _4654ad49a8cf, _891b53ced00c: _6557c684951e):
        self._23242a6ed3b7 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/parallel_romanized_train_data.zip"
        self._7a4a32328e02 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/bhasha-abhijnaanam_test_set.zip"
        self._1cf0cb2a571a = _1cf0cb2a571a
        self._891b53ced00c = _891b53ced00c
        self._bfd26029d3d4 = _8c69c0ecfdab(_8c69c0ecfdab(self._891b53ced00c, "dataset", _43d52e0957a8), "dataset_source_dir", "bhasha")
        self._6c2f8adb74ce = self._77cef76432db(self._23242a6ed3b7, _2a7e102e44e2=f"data/{self._bfd26029d3d4}/preprocessed/train")
        self._f13347115b00 = self._77cef76432db(self._7a4a32328e02, _2a7e102e44e2=f"data/{self._bfd26029d3d4}/preprocessed/test")
        self._d7827d301d8c = _8c69c0ecfdab(_8c69c0ecfdab(self._891b53ced00c, "dataset", _43d52e0957a8), "dataset_share", 1.0)
        self._ad43d424fa7c = _8c69c0ecfdab(_8c69c0ecfdab(self._891b53ced00c, "dataset", _43d52e0957a8), "select_languages", [])
        self._20b67092734d = f"data/{self._bfd26029d3d4}/filtered/native"
        self._e2e31d782023 = f"data/{self._bfd26029d3d4}/filtered/romanized"

        # Extract languages from JSON
        _b8a22326f102 = self._27b6992088a9(self._6c2f8adb74ce)

        # Extract languages from txt files
        _64aee810ad31 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4("data", self._bfd26029d3d4, "native_script_train_valid_data", "Native_script_data")
        _1468c8f8c3da = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4("data", self._bfd26029d3d4, "roman_script_train_valid_data", "Roman_script_data")

        _76ef320400f8 = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/native_script_train_valid_data.zip"
        _ca78f3a25afe = "https://github.com/AI4Bharat/IndicLID/releases/download/v1.0/roman_script_train_valid_data.zip"

        _6405d1f73b7e = self._379479c91fcd(_76ef320400f8, f"data/{self._bfd26029d3d4}/native_script_train_valid_data")
        _54f1c178c4bf = self._379479c91fcd(_ca78f3a25afe, f"data/{self._bfd26029d3d4}/roman_script_train_valid_data")

        # Combine all txt languages
        _7161ce60d2a3 = _6405d1f73b7e._7437c0c251df(_54f1c178c4bf)

        # === NEW: interpret select_languages empty or ['All'] as "use all languages" ===
        # normalize incoming select_languages
        try:
            _726e8eecd1b5 = self._ad43d424fa7c if self._ad43d424fa7c is not _43d52e0957a8 else []
        except _0c78ead0ecad:
            _726e8eecd1b5 = []
        # if user passed ['All'] (case-insensitive) or empty list -> set to all discovered languages (union of JSON + TXT)
        _cf51418ccd78 = _3f396c7a6cb3(_7161ce60d2a3) | _3f396c7a6cb3(_b8a22326f102)
        if (_8f8e89e12708(_726e8eecd1b5, (_454a95094a47, _48214f389576)) and _2519037ae48d(_726e8eecd1b5) == 1 and _ae6483044297(_726e8eecd1b5[0])._d9ce41a6b96d()._97a359019e6e() == "all") or (not _726e8eecd1b5):
            self._ad43d424fa7c = _61f4b6e248db(_cf51418ccd78)
            self._1cf0cb2a571a._5b849fe5cc5f("select_languages was empty or ['All'] — using all discovered languages (%d).", _2519037ae48d(self._ad43d424fa7c))
        else:
            # otherwise keep only languages that actually exist in discovered sets
            self._ad43d424fa7c = [_10382a7ea865 for _10382a7ea865 in _726e8eecd1b5 if _10382a7ea865 in _cf51418ccd78]
            self._1cf0cb2a571a._5b849fe5cc5f("Using user-provided select_languages filtered to discovered languages (%d): %s", _2519037ae48d(self._ad43d424fa7c), self._ad43d424fa7c)

        # If user previously expected the old logic below (narrowing), keep it consistent:
        if self._ad43d424fa7c:
            _7161ce60d2a3 = [_10382a7ea865 for _10382a7ea865 in self._ad43d424fa7c if _10382a7ea865 in _7161ce60d2a3]
            _b8a22326f102 = [_10382a7ea865 for _10382a7ea865 in self._ad43d424fa7c if _10382a7ea865 in _b8a22326f102]

        # Find missing languages in JSON compared to txt datasets
        _2b8f0fe5b96c = _454a95094a47(_3f396c7a6cb3(_7161ce60d2a3) - _3f396c7a6cb3(_b8a22326f102))
        self._1cf0cb2a571a._5b849fe5cc5f(f"Languages in JSON: {_b8a22326f102}")
        self._1cf0cb2a571a._5b849fe5cc5f(f"Languages in TXT: {_7161ce60d2a3}")
        self._1cf0cb2a571a._5b849fe5cc5f(f"Missing languages to load from TXT: {_2b8f0fe5b96c}")

        # Now process only missing languages from TXT files
        if _2b8f0fe5b96c:
            self._b450f4eb8eb2(_64aee810ad31, "native", _2b8f0fe5b96c, self._d7827d301d8c)
            self._b450f4eb8eb2(_1468c8f8c3da, "romanized", _2b8f0fe5b96c, self._d7827d301d8c)

            self._9d4f4c818adf(_2b8f0fe5b96c)

        for _da075c28c898 in ['train', 'test']:
            _1d88fda56479 = self._6c2f8adb74ce if _da075c28c898 == 'train' else self._f13347115b00
            _018798ae239a = "train" if _da075c28c898 == 'train' else "test"
            _c1c032320109 = 0.8 if _da075c28c898 == 'train' else 0.0
            self._cf6661cb534e = _474f0c6b5644._4eb0b0d119f1._5f1b0e8e2075(_1d88fda56479)._41353d24bb76(".")[0]
            self._2a1d658eba04 = _474f0c6b5644._4eb0b0d119f1._05ac7927df01(_1d88fda56479)
            self._018798ae239a = _018798ae239a
            for _2958b816a061 in ["native", "romanized"]:
                self._92e9ff2fe5ba(_2958b816a061, _c1c032320109, self._d7827d301d8c)

    # Process missing language CSVs
    def _b98d0dd316c7(self, _2b8f0fe5b96c, _ad43d424fa7c=_43d52e0957a8):
        _062de437ead4 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4("data", self._bfd26029d3d4 ,"original")

        for _15b787311920 in _2b8f0fe5b96c:
            _3172081be340 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_062de437ead4, _40ec0c890928(_15b787311920))
            if not _474f0c6b5644._4eb0b0d119f1._d7f15df86951(_3172081be340):
                self._1cf0cb2a571a._f3be78cc2590(f"Missing original data directory not found for language: {_15b787311920}")
                continue

            for _2958b816a061 in ["native", "romanized"]:
                # Detect CSV files for this language
                for _658af1d3695a in _474f0c6b5644._e2ddf08b7477(_3172081be340):
                    if not _658af1d3695a._711820e692ce(".csv"):
                        continue
                    if _40ec0c890928(_15b787311920) not in _658af1d3695a or _2958b816a061 not in _658af1d3695a:
                        continue

                    # Determine destination based on CSV name (train or val)
                    _1d4ddb972f4d = "train" if "train" in _658af1d3695a else "val"
                    _1c2e8ee55394 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4("data", self._bfd26029d3d4, _1d4ddb972f4d)

                    _78b697103324 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_3172081be340, _658af1d3695a)
                    _bd09ea28dc5e = _7609f56a82f6._3726a7023a4a(_78b697103324, _7f05ed3c9849=_7c64f3b0858e._68dc4e34e9fe, _c185e2d8e7df="\\")

                    _9545a3cb2ba2 = f"{_2958b816a061} sentence"
                    if _9545a3cb2ba2 not in _bd09ea28dc5e._5d9af12af85f:
                        self._1cf0cb2a571a._f3be78cc2590(f"{_9545a3cb2ba2} column missing in {_78b697103324}, skipping.")
                        continue

                    _bd09ea28dc5e = _bd09ea28dc5e[_bd09ea28dc5e[_9545a3cb2ba2]._4c20456a5212(_ae6483044297)._ae6483044297._d9ce41a6b96d() != ""]
                    if _bd09ea28dc5e._114d1312357d:
                        self._1cf0cb2a571a._f3be78cc2590(f"No valid rows found for {_15b787311920} {_2958b816a061} in {_78b697103324}")
                        continue

                    _c3d8ca291498 = _bd09ea28dc5e["lang_code"]._21621c4e4bb4[0]

                    _7e67d8baf1ce = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_1c2e8ee55394, _c3d8ca291498)
                    _474f0c6b5644._4e42f00e51a5(_7e67d8baf1ce, _afa2ba99d81c=_97b73536af4e)

                    _d58ff6036fca = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_7e67d8baf1ce, "src")
                    _afd04fcce8fe = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_7e67d8baf1ce, "tgt")
                    _474f0c6b5644._4e42f00e51a5(_d58ff6036fca, _afa2ba99d81c=_97b73536af4e)
                    _474f0c6b5644._4e42f00e51a5(_afd04fcce8fe, _afa2ba99d81c=_97b73536af4e)

                    _7afdc423048d = f"txt_{_2958b816a061}"
                    _18a07da59d83 = self._20b67092734d if _2958b816a061._9c5701d8ca07() == "native" else self._e2e31d782023
                    _474f0c6b5644._4e42f00e51a5(_18a07da59d83, _afa2ba99d81c=_97b73536af4e)

                    _0cd2e9189648 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_d58ff6036fca, f"{_c3d8ca291498}_{_7afdc423048d}.src")
                    _eafe504759e9 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_afd04fcce8fe, f"{_c3d8ca291498}_{_7afdc423048d}.tgt")
                    _ed2c052d765d = "valid" if _1d4ddb972f4d._9c5701d8ca07() == "val" else _1d4ddb972f4d
                    _d89765a4ed16 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_18a07da59d83, f"{_ed2c052d765d}_combine.txt")

                    with _b98208d6071b(_0cd2e9189648, "w", _9962d230acc6="utf-8") as _da93ec534b0d, \
                            _b98208d6071b(_eafe504759e9, "w", _9962d230acc6="utf-8") as _f4d1ad77f78c, \
                            _b98208d6071b(_d89765a4ed16, "a+", _9962d230acc6="utf-8") as _af769f9b7fbf:
                        _da93ec534b0d._449b26686a57("text\n")
                        _f4d1ad77f78c._449b26686a57("lang_code\n")

                        for _de778bbf7367 in _bd09ea28dc5e[_9545a3cb2ba2]:
                            _de778bbf7367 = _ae6483044297(_de778bbf7367)._d9ce41a6b96d()
                            if _de778bbf7367 and _de778bbf7367 != "\n":
                                _af769f9b7fbf._449b26686a57(f"__label__{_15b787311920} {_de778bbf7367}\n")
                                _da93ec534b0d._449b26686a57(f"{_de778bbf7367}\n")
                                _f4d1ad77f78c._449b26686a57(f"{_c3d8ca291498}\n")

                    self._1cf0cb2a571a._5b849fe5cc5f(f"Written {_2519037ae48d(_bd09ea28dc5e)} rows to {_0cd2e9189648} and {_eafe504759e9}")

    # Extract languages from JSON file
    def _de8fab765e2d(self, _1d88fda56479):
        with _b98208d6071b(_1d88fda56479, "r", _9962d230acc6="utf-8") as _6db14c7caac5:
            _8d5695969383 = _a5e2dc209723._62d905991d24(_6db14c7caac5)
        _5c5fe30cfb3c = _3f396c7a6cb3()
        for _25baae02849f in _8d5695969383._4f4abfd2b264("data", []):
            _15b787311920 = _25baae02849f._4f4abfd2b264("language")
            if _15b787311920:
                _5c5fe30cfb3c._ce4f8b769f07(_15b787311920)
        return _5c5fe30cfb3c

    # Process missing languages from TXT files
    def _8f74b35b433d(self, _9cbcf0f66e65, _2958b816a061, _2b8f0fe5b96c, _d7827d301d8c=1.0):
        _774fde1c85d2 = _c191c193d3cf()

        for _b4305285d2dc, _09a5aa40f5a4 in [("train_combine.txt", "train"), ("valid_combine.txt", "val")]:
            _9b48f36e61bb = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_9cbcf0f66e65, _b4305285d2dc)
            if not _474f0c6b5644._4eb0b0d119f1._d7f15df86951(_9b48f36e61bb):
                self._1cf0cb2a571a._f3be78cc2590(f"File {_9b48f36e61bb} not found, skipping.")
                continue

            _efd0eba26b39 = []
            with _b98208d6071b(_9b48f36e61bb, "r", _9962d230acc6="utf-8") as _6db14c7caac5:
                for _040e66520913 in _6db14c7caac5:
                    _040e66520913 = _040e66520913._d9ce41a6b96d()
                    if not _040e66520913:
                        continue
                    _35593142465a = _040e66520913._41353d24bb76(_368ce1071759=1)
                    if _2519037ae48d(_35593142465a) < 2:
                        continue
                    _ab2e6c351350, _de778bbf7367 = _35593142465a
                    if _ab2e6c351350._f0578d9d0feb("__label__"):
                        _15b787311920 = _ab2e6c351350[_2519037ae48d("__label__"):]
                        if _15b787311920 in _2b8f0fe5b96c:
                            _efd0eba26b39._c9a64d03101f({
                                f"{_2958b816a061} sentence": _de778bbf7367,
                                f"{_2958b816a061}_length": _ae6483044297(_de778bbf7367)._d9ce41a6b96d()._41353d24bb76()._820034e22642(),
                                "language": _15b787311920,
                                "lang_code": _40ec0c890928(_15b787311920),
                            })

            if not _efd0eba26b39:
                self._1cf0cb2a571a._5b849fe5cc5f(f"No missing language data found in {_9b48f36e61bb} for script {_2958b816a061}.")
                continue

            _bd09ea28dc5e = _7609f56a82f6._cd4612c0d22e(_efd0eba26b39)
            _bd09ea28dc5e = _bd09ea28dc5e[_bd09ea28dc5e[f"{_2958b816a061} sentence"]._4c20456a5212(_ae6483044297)._ae6483044297._d9ce41a6b96d() != '']

            # Sample data if needed
            if _d7827d301d8c not in [0.0, 1.0]:
                _bd09ea28dc5e = _9d57f4a576c2(_bd09ea28dc5e=_bd09ea28dc5e, 
                                      _2958b816a061=_2958b816a061, 
                                      _c599acb1320c=self._d7827d301d8c,
                                      _117cda410664=self._891b53ced00c._67bac20fb79d._117cda410664)

            # Write separate CSV per language per split
            for _c3d8ca291498, _33022cf42292 in _bd09ea28dc5e._4b9e5c6fb0d8("lang_code"):
                # Skip if this group corresponds to English
                if _2958b816a061._9c5701d8ca07()=="romanized" and _33022cf42292["language"]._21621c4e4bb4[0] == "English":
                    continue
                _c16cb74c27f8 = f"data/{self._bfd26029d3d4}/original/{_c3d8ca291498}"
                _774fde1c85d2._1a9dd3cb6c96(_c16cb74c27f8=_c16cb74c27f8)
                _05ea457d46f6 = f"{_c16cb74c27f8}/txt_{_2958b816a061}_{_c3d8ca291498}_{_09a5aa40f5a4}_original_data.csv"
                _33022cf42292._037fcfbb377e(
                    _05ea457d46f6,
                    _a73710d0a6d7="w+",
                    _9962d230acc6="utf8",
                    _ac047230b33c=_cbaafab8b31a,
                    _7f05ed3c9849=_7c64f3b0858e._68dc4e34e9fe,
                    _c185e2d8e7df="\\",
                )
                self._1cf0cb2a571a._5b849fe5cc5f(f"Missing {_c3d8ca291498} data ({_09a5aa40f5a4}) written to {_05ea457d46f6}")

    # Download and extract languages from txt file
    def _111d82b78ffd(self, _6dd06e226dde, _2a7e102e44e2, _c5e40530176f=3, _71bb0f7f63be=_cbaafab8b31a):
        import _49ccb4f7a580
        import _c87f550d0157, _ec2cce95e98b, _474f0c6b5644
        from _15f50c150e8a._aec96e0975b3 import _974825bce0d4

        self._1cf0cb2a571a._5b849fe5cc5f(f"Preparing to download from {_6dd06e226dde} into {_2a7e102e44e2}")
        _474f0c6b5644._4e42f00e51a5(_2a7e102e44e2, _afa2ba99d81c=_97b73536af4e)

        _fd87c3aea797 = _474f0c6b5644._4eb0b0d119f1._5f1b0e8e2075(_974825bce0d4(_6dd06e226dde)._4eb0b0d119f1)
        _8d38e4950546 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_2a7e102e44e2, _fd87c3aea797)

        # Skip download if file exists and redownload is False
        if _474f0c6b5644._4eb0b0d119f1._d7f15df86951(_8d38e4950546) and not _71bb0f7f63be:
            self._1cf0cb2a571a._5b849fe5cc5f(f"File already exists, skipping download: {_8d38e4950546}")
        else:
            for _7c115cb14efd in _718355788e1d(_c5e40530176f):
                try:
                    with _c87f550d0157._4f4abfd2b264(_6dd06e226dde, _b798fc6799b1=_97b73536af4e, _a3ce9a417ce2=30) as _572e40050b09:
                        _572e40050b09._11c68c43ea5b()
                        with _b98208d6071b(_8d38e4950546, "wb") as _6db14c7caac5:
                            for _f413140a5629 in _572e40050b09._86bc160784ea(_a2ea4b1f34d8=8192):
                                if _f413140a5629:
                                    _6db14c7caac5._449b26686a57(_f413140a5629)
                    self._1cf0cb2a571a._5b849fe5cc5f(f"Download complete: {_8d38e4950546}")
                    break
                except (_c87f550d0157._88ca7f06cec0._20503855699c,
                        _c87f550d0157._88ca7f06cec0._de8d1f832679,
                        _c87f550d0157._88ca7f06cec0._5fbd014d019f) as _991bf518944d:
                    self._1cf0cb2a571a._f3be78cc2590(f"Download attempt {_7c115cb14efd+1} failed: {_991bf518944d}")
                    if _7c115cb14efd < _c5e40530176f - 1:
                        _49ccb4f7a580._4a32e8cb39b8(5)  # wait before retrying
                    else:
                        raise _f934453ee84a(f"Failed to download {_6dd06e226dde} after {_c5e40530176f} attempts")

        # Extract ZIP
        with _ec2cce95e98b._d108d633735c(_8d38e4950546, "r") as _cec45f3662db:
            _cec45f3662db._9655eaabe974(_2a7e102e44e2)

        # Find extracted folder containing .txt files (Native or Romanized)
        _0180c11e2e18 = _43d52e0957a8
        for _6db14c7caac5 in _474f0c6b5644._e2ddf08b7477(_2a7e102e44e2):
            _6d0e2368a0be = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_2a7e102e44e2, _6db14c7caac5)
            if _474f0c6b5644._4eb0b0d119f1._d8587bbdadc4(_6d0e2368a0be) and _4dff4d21f769(_d764ac48ec94._711820e692ce(".txt") for _d764ac48ec94 in _474f0c6b5644._e2ddf08b7477(_6d0e2368a0be)):
                _0180c11e2e18 = _6d0e2368a0be
                break

        if not _0180c11e2e18:
            raise _60d74b8f5d94("Could not find extracted folder with txt files")

        self._1cf0cb2a571a._5b849fe5cc5f(f"Extracted txt files folder: {_0180c11e2e18}")

        # Return set of unique languages in the extracted folder
        return self._afe48fe78ce7(_0180c11e2e18)

    # Extract languages from a txt folder
    def _d4e8ac6d1096(self, _9cbcf0f66e65):
        _5c5fe30cfb3c = _3f396c7a6cb3()
        for _b4305285d2dc in ["train_combine.txt", "valid_combine.txt"]:
            _9b48f36e61bb = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_9cbcf0f66e65, _b4305285d2dc)
            if not _474f0c6b5644._4eb0b0d119f1._d7f15df86951(_9b48f36e61bb):
                continue
            with _b98208d6071b(_9b48f36e61bb, "r", _9962d230acc6="utf-8") as _6db14c7caac5:
                for _040e66520913 in _6db14c7caac5:
                    _040e66520913 = _040e66520913._d9ce41a6b96d()
                    if not _040e66520913:
                        continue
                    _ab2e6c351350 = _040e66520913._41353d24bb76()[0]
                    if _ab2e6c351350._f0578d9d0feb("__label__"):
                        _15b787311920 = _ab2e6c351350[_2519037ae48d("__label__"):]
                        _5c5fe30cfb3c._ce4f8b769f07(_15b787311920)
        return _5c5fe30cfb3c

    def _df97afac867f(self, _6dd06e226dde, _2a7e102e44e2, _c5e40530176f=3, _71bb0f7f63be=_cbaafab8b31a):
        import _49ccb4f7a580
        self._1cf0cb2a571a._5b849fe5cc5f(f"Preparing to download from {_6dd06e226dde} into {_2a7e102e44e2}")
        _474f0c6b5644._4e42f00e51a5(_2a7e102e44e2, _afa2ba99d81c=_97b73536af4e)

        _fd87c3aea797 = _474f0c6b5644._4eb0b0d119f1._5f1b0e8e2075(_974825bce0d4(_6dd06e226dde)._4eb0b0d119f1)
        _8d38e4950546 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_2a7e102e44e2, _fd87c3aea797)

        # Skip download if file exists and redownload is False
        if _474f0c6b5644._4eb0b0d119f1._d7f15df86951(_8d38e4950546) and not _71bb0f7f63be:
            self._1cf0cb2a571a._5b849fe5cc5f(f"File already exists, skipping download: {_8d38e4950546}")
        else:
            for _7c115cb14efd in _718355788e1d(_c5e40530176f):
                try:
                    with _c87f550d0157._4f4abfd2b264(_6dd06e226dde, _b798fc6799b1=_97b73536af4e, _a3ce9a417ce2=30) as _572e40050b09:
                        _572e40050b09._11c68c43ea5b()
                        with _b98208d6071b(_8d38e4950546, 'wb') as _6db14c7caac5:
                            for _f413140a5629 in _572e40050b09._86bc160784ea(_a2ea4b1f34d8=8192):
                                if _f413140a5629:
                                    _6db14c7caac5._449b26686a57(_f413140a5629)
                    self._1cf0cb2a571a._5b849fe5cc5f(f"Download complete: {_8d38e4950546}")
                    break
                except (_c87f550d0157._88ca7f06cec0._20503855699c,
                        _c87f550d0157._88ca7f06cec0._de8d1f832679,
                        _c87f550d0157._88ca7f06cec0._5fbd014d019f) as _991bf518944d:
                    self._1cf0cb2a571a._f3be78cc2590(f"Download attempt {_7c115cb14efd+1} failed: {_991bf518944d}")
                    if _7c115cb14efd < _c5e40530176f - 1:
                        _49ccb4f7a580._4a32e8cb39b8(5)  # wait before retrying
                    else:
                        raise _f934453ee84a(f"Failed to download {_6dd06e226dde} after {_c5e40530176f} attempts")

        # Extract ZIP
        with _ec2cce95e98b._d108d633735c(_8d38e4950546, 'r') as _cec45f3662db:
            _cec45f3662db._9655eaabe974(_2a7e102e44e2)

        # Return JSON file path
        for _462d06c13b44 in _474f0c6b5644._e2ddf08b7477(_2a7e102e44e2):
            if _462d06c13b44._711820e692ce('.json'):
                _9b48f36e61bb = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_2a7e102e44e2, _462d06c13b44)
                self._1cf0cb2a571a._5b849fe5cc5f(f"Extracted JSON file: {_9b48f36e61bb}")
                return _9b48f36e61bb

        raise _60d74b8f5d94("No JSON file found in extracted content.")

    def _c7ba1223faff(self, _43a416f9c0e4: _ae6483044297):
        try:
            _15b787311920 = _a4075ce4d16b._4f4abfd2b264(_43a416f9c0e4)
            return _15b787311920._558782da9da7()
        except _0c78ead0ecad:
            _7c478244a7e4 = _ae6483044297(_43a416f9c0e4)._97a359019e6e()[:2]
            _7130864dfa38 = _7c478244a7e4
            while _97b73536af4e:
                try:
                    _15b787311920 = _a4075ce4d16b._4f4abfd2b264(_7c478244a7e4)
                    if _15b787311920:
                        _7c478244a7e4 += "x"
                    else:
                        return _7c478244a7e4[:2]
                except _bd3f42e990e1:
                    return _7130864dfa38[:3]

    def _7b70c4b5019f(self, _3aeff354f5ef: _7609f56a82f6._cd4612c0d22e, _7ba5931d4997: _69f7d8691184):
        if _7ba5931d4997 < 1.0:
            _3aeff354f5ef = _3aeff354f5ef._3375e39f24a1(_c599acb1320c=1, _b438c45d5e09=self._891b53ced00c._67bac20fb79d._117cda410664)
        _bfb50e6b6936 = _ba40e1e297cc(_7ba5931d4997 * _2519037ae48d(_3aeff354f5ef))
        return _3aeff354f5ef[:_bfb50e6b6936], _3aeff354f5ef[_bfb50e6b6936:]

    def _d320bbf9aea0(self, _876b9a8dcd52):
        _1c86d9ba7176 = _876b9a8dcd52._41353d24bb76("-")[-1][:4]  # first 4 letters of last part
        if _1c86d9ba7176 == "Maye":  # Special Case
            return "Mei"
        return _1c86d9ba7176

    def _b6eab562ffaf(self, _abb2f5ef38cd):
        _35593142465a = _abb2f5ef38cd['unique_identifier']._41353d24bb76('_')
        if _2519037ae48d(_35593142465a) > 2:
            _e659bab92fd8 = self._23873ba6e868(_abb2f5ef38cd['script'])
            return _abb2f5ef38cd['language'] + "_" + _e659bab92fd8
        else:
            return _abb2f5ef38cd['language']

    def _71f1bb716a71(self, _abb2f5ef38cd):
        if "Romanized Kashmiri" in _abb2f5ef38cd['language'] and "Kashmiri" in _abb2f5ef38cd['language_label']:
            return "Kashmiri"
        return _abb2f5ef38cd['language_label']

    def _cff64f43e4ab(self, _2958b816a061: _ae6483044297, _7ba5931d4997: _69f7d8691184 = 0.0, _d7827d301d8c: _69f7d8691184 = 1.0):
        _774fde1c85d2 = _c191c193d3cf()
        _7afdc423048d = self._cf6661cb534e
        _0cd2e9189648 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(self._2a1d658eba04, self._cf6661cb534e + ".json")

        with _b98208d6071b(_0cd2e9189648, "r+", _9962d230acc6="utf8") as _462d06c13b44:
            _8d5695969383 = _a5e2dc209723._62d905991d24(_462d06c13b44)

        _bd09ea28dc5e = _7609f56a82f6._ad427acb88d9(_8d5695969383["data"])

        # Filter languages if provided
        _bd09ea28dc5e = _bd09ea28dc5e[_bd09ea28dc5e["language"]._b3d30420320a(self._ad43d424fa7c)] if _8c69c0ecfdab(self, "select_languages", _43d52e0957a8) else _bd09ea28dc5e
        _bd09ea28dc5e["language_label"] = _bd09ea28dc5e._6890f5a18c4d(self._f46bcb821f34, _3698fa6620dc=1)
        if _2958b816a061._9c5701d8ca07() == "romanized":
            _bd09ea28dc5e["language"] = _bd09ea28dc5e["language"]._6890f5a18c4d(lambda _10382a7ea865: "Romanized " + _ae6483044297(_10382a7ea865))

        _bd09ea28dc5e["language_label"] = _bd09ea28dc5e._6890f5a18c4d(self._f36d401cbe05, _3698fa6620dc=1)
        _bd09ea28dc5e["lang_code"] = _bd09ea28dc5e["language_label"]._004ce55c3041(_40ec0c890928)

        _774fde1c85d2._1a9dd3cb6c96(_c16cb74c27f8="metrics/data")

        if _2958b816a061._9c5701d8ca07() == "romanized":
            _bd09ea28dc5e["lang_code"] = _bd09ea28dc5e["lang_code"]._6890f5a18c4d(lambda _10382a7ea865: _ae6483044297(_10382a7ea865) + "_en")

        self._92f67510f901(_bd09ea28dc5e, _2958b816a061, _d7827d301d8c, _c6ab9e191095="original")

        _492e7cadb245 = "romanized" if _2958b816a061 == "native" else "native"
        _6a41be33a0db = [_16361b26779f for _16361b26779f in _bd09ea28dc5e._5d9af12af85f if _492e7cadb245 in _16361b26779f]
        _bd09ea28dc5e._4d2e50a6608a(_6a41be33a0db, _3698fa6620dc=1, _89e390fe7fdc=_97b73536af4e)
        _bd09ea28dc5e = _bd09ea28dc5e[_bd09ea28dc5e[f'{_2958b816a061} sentence']._4c20456a5212(_ae6483044297)._ae6483044297._d9ce41a6b96d() != '']

        # Write per-language CSV files
        for _c3d8ca291498, _33022cf42292 in _bd09ea28dc5e._4b9e5c6fb0d8("lang_code"):
            _c16cb74c27f8 = f"data/{self._bfd26029d3d4}/original/{_c3d8ca291498}"
            _774fde1c85d2._1a9dd3cb6c96(_c16cb74c27f8=_c16cb74c27f8)
            _05ea457d46f6 = f"{_c16cb74c27f8}/{self._cf6661cb534e}_{_c3d8ca291498}_{_2958b816a061}_original_data.csv"
            _33022cf42292._037fcfbb377e(
                _05ea457d46f6,
                _a73710d0a6d7="w+",
                _9962d230acc6="utf8",
                _ac047230b33c=_cbaafab8b31a,
                _7f05ed3c9849=_7c64f3b0858e._68dc4e34e9fe,
                _c185e2d8e7df="\\",
            )
            self._1cf0cb2a571a._5b849fe5cc5f(f"{_c3d8ca291498} data written to {_05ea457d46f6}")

        # Sample if needed for train set
        if self._018798ae239a == "train" and _d7827d301d8c not in [0.0, 1.0]:
            _4fb4ace978d9 = _9d57f4a576c2(_bd09ea28dc5e,
                                          _2958b816a061,
                                          _d7827d301d8c,
                                          _117cda410664=self._891b53ced00c._67bac20fb79d._117cda410664
                                          )
            _bd09ea28dc5e = _4fb4ace978d9._eb95b0428b3b(_4d2e50a6608a=_97b73536af4e)

        self._92f67510f901(_bd09ea28dc5e, _2958b816a061, _d7827d301d8c, _c6ab9e191095="processed")

        if _7ba5931d4997 == 0:
            self._1cf0cb2a571a._5b849fe5cc5f(f"Started Processing {self._cf6661cb534e} for {_2958b816a061} sentences for {self._018798ae239a} data.")
            _1c2e8ee55394 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4("data", self._bfd26029d3d4, self._018798ae239a)
            _fa78be5b9bd8 = "test"
            self._4086be7a84f9(_1c2e8ee55394, _bd09ea28dc5e, _7afdc423048d, _fa78be5b9bd8, _2958b816a061)
            self._1cf0cb2a571a._5b849fe5cc5f(f"Completed Processing {self._cf6661cb534e} for {_2958b816a061} sentences for {self._018798ae239a} data.")
        else:
            _e680ca3feaf6, _0856a76d6f14 = self._ecf45e6fdc87(_bd09ea28dc5e, _7ba5931d4997)
            for _cae045bbe22e, _fa78be5b9bd8 in [(_e680ca3feaf6, "train"), (_0856a76d6f14, "val")]:
                self._1cf0cb2a571a._5b849fe5cc5f(f"Started Processing {self._cf6661cb534e} for {_2958b816a061} sentences for {_fa78be5b9bd8} data.")
                _1c2e8ee55394 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4("data", self._bfd26029d3d4, _fa78be5b9bd8)
                self._4086be7a84f9(_1c2e8ee55394, _cae045bbe22e, _7afdc423048d, _fa78be5b9bd8, _2958b816a061)
                self._1cf0cb2a571a._5b849fe5cc5f(f"Completed Processing {self._cf6661cb534e} for {_2958b816a061} sentences for {_fa78be5b9bd8} data.")

    def _56ed93e295a5(self, _bd09ea28dc5e, _2958b816a061, _d7827d301d8c, _c6ab9e191095):
        _bd09ea28dc5e[f"{_2958b816a061}_length"] = _bd09ea28dc5e[f"{_2958b816a061} sentence"]._6890f5a18c4d(lambda _10382a7ea865: _2519037ae48d(_ae6483044297(_10382a7ea865)._41353d24bb76()))
        _345c54874014 = _bd09ea28dc5e._4b9e5c6fb0d8(["lang_code", "language"])._783f7fd45756({
            f"{_2958b816a061}_length": [
                lambda _10382a7ea865: _10382a7ea865[_10382a7ea865 != 0]._2ba720b56b74() if (_10382a7ea865 != 0)._4dff4d21f769() else 0,
                lambda _10382a7ea865: _10382a7ea865[_10382a7ea865 != 0]._62fd76d87385() if (_10382a7ea865 != 0)._4dff4d21f769() else 0,
                lambda _10382a7ea865: (_10382a7ea865 != 0)._3fdebca4366d(),
            ],
        })
        _345c54874014._5d9af12af85f = [f"{_2958b816a061}_mean", f"{_2958b816a061}_median", f"{_2958b816a061}_count"]
        _40e7393d4c1c = f"metrics/data/{self._cf6661cb534e}_{_2958b816a061}_{_c6ab9e191095}_{_ba40e1e297cc(_d7827d301d8c*100)}_data_file_metrics.csv"
        _345c54874014._037fcfbb377e(_40e7393d4c1c, _a73710d0a6d7="w+", _9962d230acc6="utf8")

    def _83417fc911c1(self, _1c2e8ee55394, _bd09ea28dc5e, _7afdc423048d, _fa78be5b9bd8, _2958b816a061):
        for _c0a0ea9c4edb in _bd09ea28dc5e["language_label"]._ac0d9c49071e():
            self._1cf0cb2a571a._5b849fe5cc5f(f"Now Processing {self._cf6661cb534e} for {_c0a0ea9c4edb} language.")
            _4f5d10c6ce87 = _bd09ea28dc5e["language_label"]._3792b0b129e4(_c0a0ea9c4edb)._63b3e87f1efd()
            _c3d8ca291498 = _bd09ea28dc5e._50606d31ea49[_4f5d10c6ce87, "lang_code"]
            _ce6a9e45b247 = _bd09ea28dc5e._50606d31ea49[_4f5d10c6ce87, "language_label"]._41353d24bb76()[-1]._d9ce41a6b96d()

            _7e67d8baf1ce = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_1c2e8ee55394, _c3d8ca291498)
            _474f0c6b5644._4e42f00e51a5(_7e67d8baf1ce, _afa2ba99d81c=_97b73536af4e)
            # Collect DF for this lang_code to allow source-only dedupe
            _62a1160c43aa = _bd09ea28dc5e[_bd09ea28dc5e["lang_code"] == _c3d8ca291498]._eefa2fc60132()
            _a764dd72c49f = f"{_2958b816a061} sentence"

            # Normalize whitespace for dedupe comparison
            _62a1160c43aa["__norm_sent"] = _62a1160c43aa[_a764dd72c49f]._4c20456a5212(_ae6483044297)._6890f5a18c4d(lambda _aefc0b939cf5: " "._68c510cd02a4(_ae6483044297(_aefc0b939cf5)._41353d24bb76()))
            _48fb62439bf7 = _2519037ae48d(_62a1160c43aa)
            # dedupe only on normalized source sentences, keep first
            _10ec67efbee6 = _62a1160c43aa._40e4cd05f758(_b320bb44e9ae=["__norm_sent"], _efcd046f7fe4="first")
            _4b4d8348d832 = _ba40e1e297cc(_10ec67efbee6._3fdebca4366d())
            _51fa91e93bb5 = _48fb62439bf7 - _4b4d8348d832

            # get example unique_identifiers for removed rows if available
            _5899a8f2ca72 = []
            if _4b4d8348d832 > 0:
                if "unique_identifier" in _62a1160c43aa._5d9af12af85f:
                    _5899a8f2ca72 = _454a95094a47(_62a1160c43aa._50606d31ea49[_10ec67efbee6, "unique_identifier"]._2849a9be4ea9()._4c20456a5212(_ae6483044297)._ac0d9c49071e()[:10])
                else:
                    # fallback to short hash of removed sentences
                    _5899a8f2ca72 = [_50c703e865ef._bc17e7dd40b0(_aefc0b939cf5._24597ade99ee("utf8"))._2dce383ba86b()[:8] for _aefc0b939cf5 in _62a1160c43aa._50606d31ea49[_10ec67efbee6, "__norm_sent"]._4c20456a5212(_ae6483044297)._ac0d9c49071e()[:10]]

            self._1cf0cb2a571a._5b849fe5cc5f(f"Dedup (source only) for lang_code={_c3d8ca291498}, script={_2958b816a061}: before={_48fb62439bf7} after={_51fa91e93bb5} removed={_4b4d8348d832}")
            if _4b4d8348d832 > 0:
                self._1cf0cb2a571a._5b849fe5cc5f(f"Example removed unique ids (up to 10) for {_c3d8ca291498}: {_5899a8f2ca72}")

            # Keep only non-duplicate rows for writing
            _62a1160c43aa = _62a1160c43aa._50606d31ea49[~_10ec67efbee6]._eb95b0428b3b(_4d2e50a6608a=_97b73536af4e)
            # Make sure the sentence column uses normalized text
            _62a1160c43aa[_a764dd72c49f] = _62a1160c43aa["__norm_sent"]
            _62a1160c43aa = _62a1160c43aa[_62a1160c43aa[_a764dd72c49f]._4c20456a5212(_ae6483044297)._ae6483044297._d9ce41a6b96d() != ""]

            _88ce35c3ba8f = _62a1160c43aa[_a764dd72c49f]._2849a9be4ea9()

            _d58ff6036fca = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_7e67d8baf1ce, "src")
            _afd04fcce8fe = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_7e67d8baf1ce, "tgt")
            _18a07da59d83 = self._20b67092734d if _2958b816a061._9c5701d8ca07() == "native" else self._e2e31d782023
            
            _474f0c6b5644._4e42f00e51a5(_d58ff6036fca, _afa2ba99d81c=_97b73536af4e)
            _474f0c6b5644._4e42f00e51a5(_afd04fcce8fe, _afa2ba99d81c=_97b73536af4e)
            _474f0c6b5644._4e42f00e51a5(_18a07da59d83, _afa2ba99d81c=_97b73536af4e)

            _0cd2e9189648 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_d58ff6036fca, f"{_c3d8ca291498}_{_7afdc423048d}.src")
            _eafe504759e9 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_afd04fcce8fe, f"{_c3d8ca291498}_{_7afdc423048d}.tgt")
            _ed2c052d765d = "valid" if _fa78be5b9bd8._9c5701d8ca07() == "val" else _fa78be5b9bd8
            _d89765a4ed16 = _474f0c6b5644._4eb0b0d119f1._68c510cd02a4(_18a07da59d83, f"{_ed2c052d765d}_combine.txt")

            with _b98208d6071b(_0cd2e9189648, "w", _9962d230acc6="utf8") as _da93ec534b0d,\
                    _b98208d6071b(_eafe504759e9, "w", _9962d230acc6="utf8") as _f4d1ad77f78c,\
                    _b98208d6071b(_d89765a4ed16, "a+", _9962d230acc6="utf8") as _af769f9b7fbf:
                _da93ec534b0d._449b26686a57("text\n")
                _f4d1ad77f78c._449b26686a57("lang_code\n")
                for _7a28ee79d710 in _718355788e1d(0, _2519037ae48d(_88ce35c3ba8f), 1000):
                    _78f89dfda8ff = _88ce35c3ba8f[_7a28ee79d710:_7a28ee79d710+1000]
                    _a20759d7679c = [_c3d8ca291498] * _2519037ae48d(_78f89dfda8ff)
                    _74e97539b9ad = [f"__label__{_ce6a9e45b247}"] * _2519037ae48d(_78f89dfda8ff)
                    for _e7926193659a, _c695b00738c8, _c1015770ce94 in _b1365047c9e9(_78f89dfda8ff, _a20759d7679c, _74e97539b9ad):
                        _e7926193659a = _ae6483044297(_e7926193659a)._d9ce41a6b96d()
                        if _e7926193659a and _e7926193659a != "\n":
                            _da93ec534b0d._449b26686a57(f"{_e7926193659a}\n")
                            _f4d1ad77f78c._449b26686a57(f"{_c695b00738c8}\n")
                            _af769f9b7fbf._449b26686a57(f"{_c1015770ce94} {_e7926193659a}\n")

            self._1cf0cb2a571a._5b849fe5cc5f(f"Files {_0cd2e9189648} and {_eafe504759e9} with {_2519037ae48d(_88ce35c3ba8f)} samples have been created.")

# Main function
def _5a7ce828620e():
    _0e93e8a53f49._712d6637b0f2(_b49f3af41b89=_29eb2b6a6555(1, _78f48d3a6483._b2e81481605b(_474f0c6b5644._bf8fcd75e369() * 0.25)))
    _1a69e9434c4c = _9758a2eabd10._a6b9dc030511(_863de918861c="Process Bhasha Abhijnaanam Dataset")
    _1a69e9434c4c._1a41cd5fc837(
        "--config_file_path",
        _bc55319780ae=_ae6483044297,
        _9394c98ba8de=_97b73536af4e,
        _8cb2ca3a4e2b="Pass the yaml config file path",
    )
    try:
        _e0b899cdbd3f, _b9285b6f1f14 = _1a69e9434c4c._d437e02ca983()
        _891b53ced00c = _6557c684951e()._8dd5428a8061(_02dbd55c8210=_e0b899cdbd3f._647bb2cd2b09)
        _1cf0cb2a571a = _c9282304e7cf()._26871fcd85be(_891b53ced00c)
        _1cf0cb2a571a._5b849fe5cc5f(f"Unknwon args {_b9285b6f1f14} hence ignored")
        _358218235493(_1cf0cb2a571a=_1cf0cb2a571a, _891b53ced00c=_891b53ced00c)
    except _9758a2eabd10._cd122eb073af as _991bf518944d:
        _7744c4e179b9(f"Error: {_991bf518944d}")
        _1a69e9434c4c._735cb625ced6()

if __name__ == "__main__":
    _da053ace8324()
