# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune copy.py
# @Time             : 2025-10-28 13:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-27 13:25 IST
# ---------------------------------------------------------

from __future__ import _523c5ee682f2
import _1cc617873742, json, os, random, _a36522002fa2, sys, time, _05e182b7d5f1
from _f585c80bbc8c import _9cee89f6c6d5
from typing import _307117c498b3, _3461fb3fc46d, _a364838dfbd4
import _71a176dee454 as _0ef6a30be72e, _31cbc8fa81ff, _bd9b6e3e7eaf as _9935b1a42008
from _bd9b6e3e7eaf import _b8ab916b33da
from _bd9b6e3e7eaf._6d809eff6c55 import _97c01858fa08
from _bd9b6e3e7eaf._6d809eff6c55._be01d84d3834._17c5afbf6ac2 import _ad36d0e00208
from _0ca10adb278a._3924ee443f43._a59e108a63d6._a926264af3fa import _96ff7609ff8d
from _0ca10adb278a._3924ee443f43._a59e108a63d6._99305a33b2c1 import _ab9a15409ab5
from _0ca10adb278a._3924ee443f43._a59e108a63d6._542543c2a4d9 import _d45fb93ddcdc
from _0ca10adb278a._3924ee443f43._a59e108a63d6._659d0c2d6b9a import _893c1c9228f6
from _0ca10adb278a._3924ee443f43._ce2ea1b65deb._456f24108f41 import _e3ce99fdaee1
from _0ca10adb278a._3924ee443f43._ce2ea1b65deb._3c58bb0df6c5 import _6b69f1b9006d
from _0ca10adb278a._3924ee443f43._2e8691a71bc9._4ae5d6bf188f import _50272515b128
from _0ca10adb278a._3924ee443f43._2e8691a71bc9._a9e78b63e707 import _a6eb00f0a81c
from _0ca10adb278a._3924ee443f43._a59e108a63d6._aa51e08482a0 import _d176e52a5793
from _0ca10adb278a._3924ee443f43._a59e108a63d6._aa51e08482a0 import (
    _e201be25e61f, _bfe708c7588f, _71595db3320d,
    _f46655a96404, _d154b8b798d5, _f1f30d288ee3,
    _892ca7571018, _fa67c13ebb2b, _308fff73d84e,
    _cdd6fe082fce, _5ecbff14d96b, _166aaedd96e9,
    _aff787e14642, _05855fd3a3a5
)

os._6ece1bb6520f["TOKENIZERS_PARALLELISM"] = "True"
_64e0bed4cded = _31cbc8fa81ff._8797fc2484cb._3b006bc65e2d() and _31cbc8fa81ff._8797fc2484cb._5e217fc75730() > 0
if _64e0bed4cded:
    try:
        from _380104f7f7e4 import _6db0fc62d0a1
        import _e10b41c11ca7 as _7ecda667ecf8
    except _3434d233bba4:
        _7ecda667ecf8 = _f7c5483b95af


def _ca1d69e7f9ca(_223592eb75a5: _31cbc8fa81ff._eb34a7c2a62b._1ab2533c7b96, _7c842a472bcd: _3bacca9b0054, _8880e5b73ec5: _a364838dfbd4[_3bacca9b0054] = _f7c5483b95af) -> _f7c5483b95af:
    if not os._944351e8507b._d1e3e73f5994(_7c842a472bcd):
        raise _230ddc711dba(f"Finetuned model path not found: {_7c842a472bcd}")
    if _7c842a472bcd._a6fc226c13d5((".pt", ".pth")):
        _6c8333700f55 = _8880e5b73ec5 or ("cpu" if not _31cbc8fa81ff._8797fc2484cb._3b006bc65e2d() else _f7c5483b95af)
        _8499fa8253ba = _31cbc8fa81ff._66702da4baf6(_7c842a472bcd, _8880e5b73ec5=_6c8333700f55)
        _e5cc68f8cf50 = _8499fa8253ba._e989d68be6bb("state_dict", _8499fa8253ba._e989d68be6bb("model_state_dict", _8499fa8253ba)) if _08c105c03016(_8499fa8253ba, _b1587fe6e453) else _8499fa8253ba
        if not _08c105c03016(_e5cc68f8cf50, _b1587fe6e453):
            raise _25dfa50064f6(f"Loaded .pt file does not contain state_dict mapping: {_7c842a472bcd}")
        _223592eb75a5._5f9d5e1a5312(_e5cc68f8cf50, _623fcf5d1f8b=_580ce77e344f)
    elif _7c842a472bcd._a6fc226c13d5(".ckpt"):
        try:
            if _9ed7fde180da(_223592eb75a5._d02985b6bd22, "load_from_checkpoint"):
                _4da1bd619518 = _223592eb75a5._d02985b6bd22._95bedd16b489(_7c842a472bcd, **{})
                _223592eb75a5._5f9d5e1a5312(_4da1bd619518._ca411608d362(), _623fcf5d1f8b=_580ce77e344f)
                return
            _8499fa8253ba = _31cbc8fa81ff._66702da4baf6(_7c842a472bcd, _8880e5b73ec5="cpu")
            _e5cc68f8cf50 = _8499fa8253ba._e989d68be6bb("state_dict", _8499fa8253ba)
            if not _08c105c03016(_e5cc68f8cf50, _b1587fe6e453):
                raise _25dfa50064f6("Lightning checkpoint did not contain a recognizable state_dict.")
            _223592eb75a5._5f9d5e1a5312(_e5cc68f8cf50, _623fcf5d1f8b=_580ce77e344f)
        except _3434d233bba4 as _714c979a9982:
            raise _25dfa50064f6(f"Failed to load .ckpt into model: {_714c979a9982}") from _714c979a9982
    else:
        raise _aa3945640e4f("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _9de84d8a90c2(_b039d0309ed2: _1cc617873742._4da5e1290fd4) -> _f7c5483b95af:
    _4fecad347904 = _96ff7609ff8d()
    _2ea1cd19031e = _4fecad347904._b66961f03824(_b039d0309ed2._f43ee709c913)
    _57c274b98931 = _ab9a15409ab5()
    _a9610b29717a = _57c274b98931._69bcdadc820c(_2ea1cd19031e)
    _08ea90593787 = _d45fb93ddcdc()
    _92d281c72baf = _893c1c9228f6()

    _2efdcd1fbfd6 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="app.random_seed", _38ab1dd3432c=_83e17e90183e, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Seed for reproducibility under app.random_seed"
    )
    _0ef6a30be72e.random._f642bb5f265c(_2efdcd1fbfd6)
    random._f642bb5f265c(_2efdcd1fbfd6)
    _9935b1a42008._b0ea47781023(_2efdcd1fbfd6, _b093a9b85a86=_c1c9e203526f)
    _31cbc8fa81ff._6e1407d42857(_2efdcd1fbfd6)
    if _31cbc8fa81ff._8797fc2484cb._3b006bc65e2d():
        _31cbc8fa81ff._8797fc2484cb._2890b96bf792(_2efdcd1fbfd6)

    _ad36a63ce0fc = 0
    if _31cbc8fa81ff._8797fc2484cb._3b006bc65e2d():
        _ac56fee3ae56 = _83e17e90183e(os._6ece1bb6520f._e989d68be6bb('RANK', '0'))
        _4a175614518c = _83e17e90183e(os._6ece1bb6520f._e989d68be6bb('WORLD_SIZE', '1'))
        try:
            if not _31cbc8fa81ff._4064cf3cf856._34ebc8e5da3a():
                _31cbc8fa81ff._4064cf3cf856._d6b3f7ef59e7(
                    _e781f4265e51=_b039d0309ed2._e781f4265e51, _ad36a63ce0fc=_ac56fee3ae56, _4a175614518c=_4a175614518c,
                    _e3c7945832b8=_9cee89f6c6d5(_7526d3333e34=600)
                )
        except _3434d233bba4:
            pass
    if _31cbc8fa81ff._4064cf3cf856._34ebc8e5da3a():
        try:
            _ad36a63ce0fc = _31cbc8fa81ff._4064cf3cf856._60893de586de()
        except _3434d233bba4:
            _ad36a63ce0fc = _ebf2d5fc70ac(_b039d0309ed2, "local_rank", 0)

    _afdefa69af6c = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="app.model_config_name", _38ab1dd3432c=_3bacca9b0054, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Model config name under app.model_config_name"
    )
    _d03361754bd3 = f"metrics/{_afdefa69af6c}"
    os._51e23011e6c0(_d03361754bd3, _586548194a90=_c1c9e203526f)

    _15d9752b652f = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.pretrained_embedding", _38ab1dd3432c=_3bacca9b0054, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _a30b8b256ff8 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="app.pretrained_embeddings_dir", _38ab1dd3432c=_3bacca9b0054, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _30824d025729 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.pretrained_embedding_overwrite_old", _38ab1dd3432c=_648906fad51e, _31dc50629cca=_580ce77e344f,
        _a753d801f2ac="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _62c79f8656c4 = _580ce77e344f
    _eefe11c1e53e = _f7c5483b95af
    if _64e0bed4cded:
        try:
            _eefe11c1e53e = _6db0fc62d0a1(
                _4040d433ec01=_c1c9e203526f,
                _9f0da71d5017=_71595db3320d(),
                _dcac4c61c00b=_c1c9e203526f,
                _a3936e99ac07="nf4",
            )
            _62c79f8656c4 = _c1c9e203526f
        except _3434d233bba4:
            _eefe11c1e53e = _f7c5483b95af

    _b5d33711fceb = os._944351e8507b._3c64bd7187d2(
        _a30b8b256ff8,
        _15d9752b652f + ("_quantized" if _64e0bed4cded else "_fp32")
    )

    _08ea90593787._468948935c4c(_b5d33711fceb, _2e4a2593d4d7=_30824d025729)
    if _08ea90593787._3c2358194bd8(_b5d33711fceb):
        _a9610b29717a._db6f0ca9ef39(f"Downloading pretrained embedding {_15d9752b652f}")
        try:
            from _108b8b05a403 import _b278de2a515a
            _ee1d70aa3b07 = _b278de2a515a()
            _83631e5bc0ed = _ee1d70aa3b07._83631e5bc0ed(_15d9752b652f)
            _b37e55c2e3ba = _ebf2d5fc70ac(_83631e5bc0ed, "sha", _f7c5483b95af) or _f7c5483b95af
        except _3434d233bba4:
            _b37e55c2e3ba = _f7c5483b95af
        if "llama" in _15d9752b652f._52e1e14d895d():
            from _380104f7f7e4 import _7b9f66143cec, _4c7728edf3ba
            _1baf72c90133 = _7b9f66143cec._9e6cb389862a(
                _15d9752b652f, _b37e55c2e3ba=_b37e55c2e3ba,
                _9006c2450b5d=_eefe11c1e53e if (_64e0bed4cded and _eefe11c1e53e) else _f7c5483b95af
            )
            _541fb248696f = _4c7728edf3ba._9e6cb389862a(_15d9752b652f, _b37e55c2e3ba=_b37e55c2e3ba, _f715f819e28e=_580ce77e344f)
            _a7edfebf7a30 = _c1c9e203526f
        else:
            from _380104f7f7e4 import _1a2487c95a12, _4c7728edf3ba
            _1baf72c90133 = _1a2487c95a12._9e6cb389862a(_15d9752b652f, _b37e55c2e3ba=_b37e55c2e3ba)
            _541fb248696f = _4c7728edf3ba._9e6cb389862a(_15d9752b652f, _b37e55c2e3ba=_b37e55c2e3ba)
            _a7edfebf7a30 = _580ce77e344f
        try:
            _1baf72c90133._4cae9fb5fb3f(_b5d33711fceb)
            _541fb248696f._4cae9fb5fb3f(_b5d33711fceb)
        except _3434d233bba4:
            _a9610b29717a._5d13b63a6987("Saving pretrained embedding locally failed; continuing.")
    else:
        _a9610b29717a._db6f0ca9ef39(f"Loading pretrained embedding from {_b5d33711fceb}")
        if "llama" in _15d9752b652f._52e1e14d895d():
            from _380104f7f7e4 import _7b9f66143cec, _4c7728edf3ba
            _1baf72c90133 = _7b9f66143cec._9e6cb389862a(
                _b5d33711fceb,
                _9006c2450b5d=_eefe11c1e53e if (_64e0bed4cded and _eefe11c1e53e) else _f7c5483b95af
            )
            _541fb248696f = _4c7728edf3ba._9e6cb389862a(_b5d33711fceb, _f715f819e28e=_580ce77e344f)
            _a7edfebf7a30 = _c1c9e203526f
        else:
            from _380104f7f7e4 import _1a2487c95a12, _4c7728edf3ba
            _1baf72c90133 = _1a2487c95a12._9e6cb389862a(_b5d33711fceb)
            _541fb248696f = _4c7728edf3ba._9e6cb389862a(_b5d33711fceb)
            _a7edfebf7a30 = _580ce77e344f

    _d247f3d622c1 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.max_seq_len", _38ab1dd3432c=_83e17e90183e, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Maximum sequence length for training"
    )
    _d167bcadadb2 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.batch_size", _38ab1dd3432c=_83e17e90183e, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Batch size for training"
    )
    _bfbc580da4a2 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.data_sample_share", _38ab1dd3432c=_030d79b45cfc, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Proportion of dataset used for sampling"
    )
    _f3c4d5bda72c = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.optimizer", _38ab1dd3432c=_3bacca9b0054, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Optimizer type under run_config.optimizer"
    )
    _56e57c674f90 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.learning_rate", _38ab1dd3432c=_030d79b45cfc, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Learning rate for optimizer"
    )
    _dc2cd91789ee = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.num_backbone_model_units_unfrozen", _38ab1dd3432c=_83e17e90183e, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Number of backbone model units unfrozen during training"
    )
    _69d35007d544 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.loss_type", _38ab1dd3432c=_3bacca9b0054, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Loss function type under run_config.loss_type"
    )
    _9da20f41a9fc = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.num_fc_layers_in_classifier_head", _38ab1dd3432c=_83e17e90183e, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Number of FC layers in classifier head"
    )
    _342cc1ba951f = 'parametric_relu'
    _aab578ec669f = _c1c9e203526f
    _9e0e067f85a9 = _580ce77e344f if _dc2cd91789ee == 0 else _c1c9e203526f

    _aac8f5f77d8c: _3461fb3fc46d[_3bacca9b0054, _307117c498b3] = {
        "device_dict": _bfe708c7588f(),
        "pretrained_embedding_model": _1baf72c90133,
        "optimizer": _f3c4d5bda72c,
        "num_backbone_model_units_unfrozen": _dc2cd91789ee,
        "loss_type": _69d35007d544,
        "lr": _56e57c674f90,
        "is_train": _c1c9e203526f,
        "tokenizer": _541fb248696f,
        "random_seed": _2efdcd1fbfd6,
        "num_fc_layers": _9da20f41a9fc,
        "activation_function_for_layer": _342cc1ba951f,
        "add_dropout_after_embedding": _aab578ec669f,
    }
    _aac8f5f77d8c._dbe55c0d5270({"pretrained_model_embedding_name": _15d9752b652f})

    _1949cbd1ed24 = os._944351e8507b._3c64bd7187d2(_2ea1cd19031e._e75abb7dd992._6eb9f2cf9c68, _2ea1cd19031e._ce2ea1b65deb._43383f4d821f._6eb9f2cf9c68)
    _1d3beb6e3ab4 = os._944351e8507b._3c64bd7187d2(_2ea1cd19031e._e75abb7dd992._6eb9f2cf9c68, _2ea1cd19031e._ce2ea1b65deb._5bc50fd97e9a._6eb9f2cf9c68)
    _47b91d3a541a = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="dataset.files_have_header", _38ab1dd3432c=_648906fad51e, _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Whether dataset files have header"
    )
    _d48f52196e27 = f"config/{_afdefa69af6c}/finetune/classes_config.json"
    _08ea90593787._468948935c4c(os._944351e8507b._d8e9111de7ed(_d48f52196e27))

    _63c351305886 = _e3ce99fdaee1(
        _6eb9f2cf9c68=_1949cbd1ed24, _47b91d3a541a=_47b91d3a541a, _a9610b29717a=_a9610b29717a,
        _541fb248696f=_541fb248696f, _227746ed6f80=_d247f3d622c1,
        _d48f52196e27=_d48f52196e27, _bd3f7a20b391=_c1c9e203526f, _9a44645d92bc=_580ce77e344f,
        _2efdcd1fbfd6=_2efdcd1fbfd6, _e863cde07ec6=_bfbc580da4a2,
        _1d271d7d95b3=_b039d0309ed2._a7891004481c, _a7edfebf7a30=_a7edfebf7a30, _515ecd1fe3e1=_f7c5483b95af,
    )
    _30cfa60a2101 = _e3ce99fdaee1(
        _6eb9f2cf9c68=_1d3beb6e3ab4, _47b91d3a541a=_47b91d3a541a, _a9610b29717a=_a9610b29717a,
        _541fb248696f=_541fb248696f, _227746ed6f80=_d247f3d622c1,
        _d48f52196e27=_d48f52196e27, _bd3f7a20b391=_580ce77e344f, _9a44645d92bc=_580ce77e344f,
        _2efdcd1fbfd6=_2efdcd1fbfd6, _e863cde07ec6=_bfbc580da4a2,
        _1d271d7d95b3=_b039d0309ed2._a7891004481c, _a7edfebf7a30=_a7edfebf7a30, _515ecd1fe3e1=_f7c5483b95af,
    )

    _f81dedda7960 = _63c351305886._d5508e7bfb1a()
    _a82e9476a34f = [_63c351305886._d785ac79f385(_51f07bfeeed6) for _51f07bfeeed6 in _63c351305886._bb0e005845f5._a58075eadb6d()]
    _44ca93c82572 = _63c351305886._44ca93c82572
    _c8db5e98e82d = {}
    for _735de399d604, (_13f77bcd9c4d, _685b6593bdf6) in _4d0b593c1e17(_a2f9cdbef116(_a82e9476a34f, _44ca93c82572)):
        _58906f7b7dd3 = _541fb248696f(_13f77bcd9c4d, _bbaa0733367f=_580ce77e344f)["input_ids"] if _a7edfebf7a30 else [_735de399d604]
        if _58906f7b7dd3:
            _c8db5e98e82d[_13f77bcd9c4d] = [_58906f7b7dd3, _685b6593bdf6]
    _aac8f5f77d8c._dbe55c0d5270({"class_weights": _c8db5e98e82d, "class_names": _a82e9476a34f})

    if "llama" in _15d9752b652f and _a7edfebf7a30:
        _223592eb75a5 = _a6eb00f0a81c(**_aac8f5f77d8c)
    else:
        _223592eb75a5 = _50272515b128(**_aac8f5f77d8c)

    _bb5343cde780 = _05855fd3a3a5(
        _2ea1cd19031e=_2ea1cd19031e,
        _dc873f239174="operation_mode",
        _38ab1dd3432c=_3bacca9b0054,
        _31dc50629cca=_c1c9e203526f,
        _a753d801f2ac="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _1a44402bb759 = _f7c5483b95af
    if _bb5343cde780 == "model_finetune":
        _1a44402bb759 = _05855fd3a3a5(
            _2ea1cd19031e=_2ea1cd19031e, _dc873f239174="run_config.finetuned_model_path", _38ab1dd3432c=_3bacca9b0054, _31dc50629cca=_580ce77e344f,
            _a753d801f2ac="Optional path to pretrained model checkpoint for finetuning"
        )
        if _1a44402bb759:
            _4744c4b08b41(_223592eb75a5, _1a44402bb759, _8880e5b73ec5="cpu")
            _a9610b29717a._db6f0ca9ef39(f"Loaded finetuned model from {_1a44402bb759}")

    _a6025c0835bd = []
    if _9e0e067f85a9:
        _b9199c3ab73e = lambda _c18df789eebe: _9ed7fde180da(_c18df789eebe, "weight") and _08c105c03016(_c18df789eebe._685b6593bdf6, _31cbc8fa81ff._d59982c0ca2f) and _c18df789eebe._685b6593bdf6._17322535c528() > 64
        _1efe3a0ea8c2 = _223592eb75a5._410382941832
        _ad563fc9c351 = _f46655a96404(_1efe3a0ea8c2, _b9199c3ab73e=_b9199c3ab73e, _82e7bd11470e=_f7c5483b95af, _80a9a674daee=_f7c5483b95af)
        try:
            _4026fb4a4f20 = _d176e52a5793(_f7c5483b95af, _ad563fc9c351, _f7c5483b95af)
        except _3434d233bba4:
            from _cf43f6532b38 import _7401c8cafdbf, _0877958f6f63 as _7759c7853ece
            _4026fb4a4f20 = _7401c8cafdbf(
                _b357b85798ab=8, _a53a53c5875b=32, _93007d8e1302=0.1,
                _ad563fc9c351=_d9f27ad0698b(_ad563fc9c351._a58075eadb6d()) if _ad563fc9c351 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _c2ab2b3e4060=_7759c7853ece._6189efb5be33 if _a7edfebf7a30 else _7759c7853ece._ce56bd8a706d
            )
        _1efe3a0ea8c2 = _f1f30d288ee3(_1efe3a0ea8c2, _4026fb4a4f20)
        for _dc873f239174, _1bb4a290e056 in _223592eb75a5._9a89a2ea0176():
            if not _1bb4a290e056._b1a267132e81:
                _1bb4a290e056 = _1bb4a290e056._7bbf72109a6b()
            if "encoder" in _dc873f239174 and "lora" not in _dc873f239174:
                _1bb4a290e056._008692f69f9a = _580ce77e344f
            elif "embedding" in _dc873f239174:
                _1bb4a290e056._008692f69f9a = "lora" in _dc873f239174
        _a9610b29717a._db6f0ca9ef39(f"Applied PEFT/LoRA config. Trainable parameters: {_d154b8b798d5(_1efe3a0ea8c2)}")

    try:
        _cad26716bd65 = _31cbc8fa81ff._4064cf3cf856._60893de586de() if _31cbc8fa81ff._8797fc2484cb._3b006bc65e2d() and _31cbc8fa81ff._4064cf3cf856._34ebc8e5da3a() else -1
    except _3434d233bba4:
        _cad26716bd65 = -1
    if _ad36d0e00208._0a68ce4d8ec4() is _580ce77e344f:
        if _31cbc8fa81ff._8797fc2484cb._3b006bc65e2d():
            _223592eb75a5 = _223592eb75a5._602ea5a6edf2(_38ab1dd3432c=_31cbc8fa81ff._e5cfcbac7f40, _0af47fcd7a91=f"cuda:{_cad26716bd65}")
        else:
            _223592eb75a5 = _223592eb75a5._602ea5a6edf2(_38ab1dd3432c=_31cbc8fa81ff._e5cfcbac7f40, _0af47fcd7a91="cpu")

    _6adac8c42276 = 'gpu' if _31cbc8fa81ff._8797fc2484cb._3b006bc65e2d() else 'cpu'
    _fcfc9ddd475f = _97c01858fa08._4286b2d4cafc(_d7437e4669aa=2)
    _ebc8fed1ec35 = os._944351e8507b._3c64bd7187d2(_2ea1cd19031e._e75abb7dd992._cd7efcdfa5d1, _afdefa69af6c, "finetune")
    os._51e23011e6c0(_ebc8fed1ec35, _586548194a90=_c1c9e203526f)
    _73a7f2d1419a = _97c01858fa08._223156904e51(_42000f28dc07=_ebc8fed1ec35, _bec58e1a14c4="intermediate",
        _1b5d8e0525b9=1, _4398c95e1364=1000, _dc89b9047d97=_580ce77e344f)
    _60195b604bbd = _97c01858fa08._223156904e51(_42000f28dc07=_ebc8fed1ec35, _bec58e1a14c4="last", _1b5d8e0525b9=1,
        _dc89b9047d97=_c1c9e203526f, _2f8017954335="val_loss", _f6b350084a49="min")
    _a21ffec61207 = _97c01858fa08._a1b5dc2fc35f(_2f8017954335="val_accuracy", _969cfbf4eed9=3, _f6b350084a49="max", _4064016c20ba=_c1c9e203526f)
    _f8cfe8dcf539 = _97c01858fa08._7375fd0e4bdd(_1b007ca73295='step')

    for _dc873f239174, _2efab73a3943 in _223592eb75a5._9a89a2ea0176():
        if not _2efab73a3943._008692f69f9a:
            _a6025c0835bd._2425dd2286f7(_2efab73a3943)
    _6d1fda4b404c = _aff787e14642(_8e6b42671af4=_a6025c0835bd) if _6adac8c42276 == "gpu" else "auto"
    _da57d4d8bf35 = _b039d0309ed2._da57d4d8bf35

    _e886f27aac29 = _b8ab916b33da(
        _c37a9621b6a5=_6adac8c42276, _4cbfbc8f748c=_fa67c13ebb2b(_6adac8c42276),
        _da57d4d8bf35=_da57d4d8bf35, _f8ad14b65c54=_6d1fda4b404c if _6adac8c42276 == "gpu" else "auto",
        _6571ab911f00=_2ea1cd19031e._223592eb75a5._6571ab911f00, _c3a99f533e7f=_580ce77e344f, _294ccba7dc57=_c1c9e203526f,
        _63abf601fb00=_c1c9e203526f, _66208e487f0b=_580ce77e344f,
        _53aa396994a7=_2ea1cd19031e._8b7e9be4c34d._53aa396994a7,
        _ee1bf457de00=_2ea1cd19031e._8b7e9be4c34d._02e772fe7e8b,
        _97c01858fa08=[_73a7f2d1419a, _60195b604bbd, _a21ffec61207, _f8cfe8dcf539],
    )

    _c6a17704cc02 = _6b69f1b9006d(
        _63c351305886=_63c351305886, _30cfa60a2101=_30cfa60a2101,
        _9f4c476e7c76=_c1c9e203526f, _503fdf472883=_541fb248696f,
        _88237683ac79=_d167bcadadb2, _1d271d7d95b3=_b039d0309ed2._a7891004481c,
        _a7edfebf7a30=_a7edfebf7a30, _2efdcd1fbfd6=_2efdcd1fbfd6
    )

    _fbafd4285bf7 = os._944351e8507b._3c64bd7187d2(_ebc8fed1ec35, "intermediate.ckpt")
    if os._944351e8507b._d1e3e73f5994(_fbafd4285bf7):
        _e886f27aac29._ad33d1a32dda(_223592eb75a5, _94baa00f7a0e=_c6a17704cc02, _7c842a472bcd=_fbafd4285bf7)
    else:
        _e886f27aac29._ad33d1a32dda(_223592eb75a5, _94baa00f7a0e=_c6a17704cc02)

    if _31cbc8fa81ff._4064cf3cf856._34ebc8e5da3a():
        _31cbc8fa81ff._4064cf3cf856._0c919fa21f22()
    _b9cfc18d4f4f = _60195b604bbd._eab30e0643a1
    if _b9cfc18d4f4f:
        _a9610b29717a._db6f0ca9ef39(f"Best checkpoint saved at {_b9cfc18d4f4f}")
    try:
        from _cf43f6532b38 import _13925cf66ec7
        if _9ed7fde180da(_223592eb75a5, 'peft_config') or _08c105c03016(_223592eb75a5, _13925cf66ec7):
            _223592eb75a5 = _223592eb75a5._d504e496dce5()
    except _3434d233bba4:
        pass
    if _62c79f8656c4:
        _223592eb75a5 = _cdd6fe082fce(_223592eb75a5)
        _223592eb75a5 = _223592eb75a5._030d79b45cfc()
    _b7b8e7407c7a = "saved_models"
    os._51e23011e6c0(_b7b8e7407c7a, _586548194a90=_c1c9e203526f)
    _c4a5e2d54f0a = os._944351e8507b._3c64bd7187d2(_b7b8e7407c7a, "finetuned_model.pt")
    _ca411608d362 = _223592eb75a5._ca411608d362()
    _31cbc8fa81ff._8c4c76968039(_ca411608d362, _c4a5e2d54f0a)
    _a9610b29717a._db6f0ca9ef39(f"Saved finetuned state_dict to {_c4a5e2d54f0a}")
    _a9610b29717a._db6f0ca9ef39("Finetuning completed successfully.")


def _ed115a0abd7c():
    _0fa774eed2f3 = _1cc617873742._566c0aac5f87(_729f1775fadf='Fine-tune a language identification model (single run)')
    _0fa774eed2f3._6aa91c5aafe4('--config_file_path', _0ff8cdea258d=_3bacca9b0054, _31dc50629cca=_c1c9e203526f)
    _0fa774eed2f3._6aa91c5aafe4('--num_nodes', _0ff8cdea258d=_83e17e90183e, _23901f2260a8=1)
    _0fa774eed2f3._6aa91c5aafe4('--cpu_cores', _0ff8cdea258d=_83e17e90183e, _23901f2260a8=1)
    _0fa774eed2f3._6aa91c5aafe4('--local-rank', _0ff8cdea258d=_83e17e90183e)
    _0fa774eed2f3._6aa91c5aafe4('--backend', _0ff8cdea258d=_3bacca9b0054, _23901f2260a8="gloo", _6a359afdc458=['gloo', 'mpi', 'nccl'])
    _0fa774eed2f3._6aa91c5aafe4('--run_timestamp', _0ff8cdea258d=_030d79b45cfc, _23901f2260a8=_f7c5483b95af)
    _b039d0309ed2 = _0fa774eed2f3._0caf95934c1e()
    if _b039d0309ed2._db2b3a6f6556 is _f7c5483b95af:
        _b039d0309ed2._db2b3a6f6556 = time.time()
    _d5db9ae28d94(_b039d0309ed2)


if __name__ == "__main__":
    _e0c99ddf8631()
