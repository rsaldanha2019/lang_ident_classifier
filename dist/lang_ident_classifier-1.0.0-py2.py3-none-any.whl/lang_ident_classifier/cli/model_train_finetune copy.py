# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune copy.py
# @Time             : 2025-10-28 13:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-27 13:25 IST
# ---------------------------------------------------------

from __future__ import _1a4b1e20e2e9
import _3ea116c3ae3b, json, os, random, _0e0b3fe00215, sys, time, _e65aa00543af
from _3a802ef8deb7 import _518cfd47228a
from typing import _1ed313c0dd7a, _93e6ab4eb4b5, _d21dd991ed9e
import _813b578412f4 as _d5f745d8b4b3, _7fbba7a04f70, _6a344ddc673d as _e57a6c5d7464
from _6a344ddc673d import _4517e6ff9c15
from _6a344ddc673d._f387cab5550c import _f7028342f957
from _6a344ddc673d._f387cab5550c._fececfc971fb._fb84c5654e2e import _154e4e89e270
from _6db6dec08e6d._d8b3c79d4788._0d2f7bfb8703._797d2620f2a7 import _a6fba0c32309
from _6db6dec08e6d._d8b3c79d4788._0d2f7bfb8703._08a0d7fe8407 import _2653ce4495cf
from _6db6dec08e6d._d8b3c79d4788._0d2f7bfb8703._37bad52b6509 import _7f1fa4ed2197
from _6db6dec08e6d._d8b3c79d4788._0d2f7bfb8703._00969876e2c7 import _ef557bf70064
from _6db6dec08e6d._d8b3c79d4788._812d61639fdc._f3331672eb75 import _286fae200417
from _6db6dec08e6d._d8b3c79d4788._812d61639fdc._b3b7c9fd4ca5 import _fa055cea81ef
from _6db6dec08e6d._d8b3c79d4788._0fad7d4b2313._6ee6a50c5eef import _a582e95d42c0
from _6db6dec08e6d._d8b3c79d4788._0fad7d4b2313._6e9d05e6bf91 import _cf6a48eeeb52
from _6db6dec08e6d._d8b3c79d4788._0d2f7bfb8703._f8325d68aaa1 import _63715f609849
from _6db6dec08e6d._d8b3c79d4788._0d2f7bfb8703._f8325d68aaa1 import (
    _003d553850be, _8e0b7d7dc209, _a7236e09e1d4,
    _765b31a60377, _8c9f91c07fe9, _353f5c9572f9,
    _e941e1bd8a0c, _8d7dd4c5ad73, _d0836115fae0,
    _8c1c6d8522ad, _36c294ebaaed, _47f4362ab298,
    _959857439de9, _0a6d46f7ad81
)

os._0f38b2e57633["TOKENIZERS_PARALLELISM"] = "True"
_7127680ba451 = _7fbba7a04f70._81ba2053a3e2._14445a5c852f() and _7fbba7a04f70._81ba2053a3e2._f77b2ab5226a() > 0
if _7127680ba451:
    try:
        from _d7cf7ea19b51 import _9195e5a82301
        import _05e55c1c97ad as _339802bb82fc
    except _ff0103a678d4:
        _339802bb82fc = _ca6c176b8d86


def _4f050f1706d6(_c5df2fdd9d9b: _7fbba7a04f70._d11b02f33358._38f9e9ae3060, _3b043000ac3a: _56e1401282d4, _a71abe57e5b0: _d21dd991ed9e[_56e1401282d4] = _ca6c176b8d86) -> _ca6c176b8d86:
    if not os._d49dca8dc3a3._e78674ceef8b(_3b043000ac3a):
        raise _d9ed51b6ca15(f"Finetuned model path not found: {_3b043000ac3a}")
    if _3b043000ac3a._30e30b45d2ae((".pt", ".pth")):
        _cd2543bd7ef2 = _a71abe57e5b0 or ("cpu" if not _7fbba7a04f70._81ba2053a3e2._14445a5c852f() else _ca6c176b8d86)
        _b6c94e445e4d = _7fbba7a04f70._61c498c88c1c(_3b043000ac3a, _a71abe57e5b0=_cd2543bd7ef2)
        _80efbe514e4a = _b6c94e445e4d._aa5a0e6cd969("state_dict", _b6c94e445e4d._aa5a0e6cd969("model_state_dict", _b6c94e445e4d)) if _b0e2b8b7593a(_b6c94e445e4d, _fd776b6888d0) else _b6c94e445e4d
        if not _b0e2b8b7593a(_80efbe514e4a, _fd776b6888d0):
            raise _ad071192441b(f"Loaded .pt file does not contain state_dict mapping: {_3b043000ac3a}")
        _c5df2fdd9d9b._0aa55809cf6b(_80efbe514e4a, _bcb47f193521=_0b78aab900d5)
    elif _3b043000ac3a._30e30b45d2ae(".ckpt"):
        try:
            if _552660c69a2d(_c5df2fdd9d9b._b94e19194c15, "load_from_checkpoint"):
                _d20f496177b9 = _c5df2fdd9d9b._b94e19194c15._c1cc90cb243b(_3b043000ac3a, **{})
                _c5df2fdd9d9b._0aa55809cf6b(_d20f496177b9._7882903afe16(), _bcb47f193521=_0b78aab900d5)
                return
            _b6c94e445e4d = _7fbba7a04f70._61c498c88c1c(_3b043000ac3a, _a71abe57e5b0="cpu")
            _80efbe514e4a = _b6c94e445e4d._aa5a0e6cd969("state_dict", _b6c94e445e4d)
            if not _b0e2b8b7593a(_80efbe514e4a, _fd776b6888d0):
                raise _ad071192441b("Lightning checkpoint did not contain a recognizable state_dict.")
            _c5df2fdd9d9b._0aa55809cf6b(_80efbe514e4a, _bcb47f193521=_0b78aab900d5)
        except _ff0103a678d4 as _963d62bfaf11:
            raise _ad071192441b(f"Failed to load .ckpt into model: {_963d62bfaf11}") from _963d62bfaf11
    else:
        raise _8a7db0b0ccb2("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _a824868695dc(_0dc7e14449f6: _3ea116c3ae3b._3154f35cfe83) -> _ca6c176b8d86:
    _65f828b3c10d = _a6fba0c32309()
    _9fc262ae11ec = _65f828b3c10d._a686011812da(_0dc7e14449f6._8e66ee1b99d2)
    _f2240962ccd0 = _2653ce4495cf()
    _484c7d7931c7 = _f2240962ccd0._cf059f90f1f8(_9fc262ae11ec)
    _4adb0656d5db = _7f1fa4ed2197()
    _3a9bf43e07d3 = _ef557bf70064()

    _4fd3c1a67f22 = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="app.random_seed", _e298802acdd8=_5eec69a95137, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Seed for reproducibility under app.random_seed"
    )
    _d5f745d8b4b3.random._c5a4e031288d(_4fd3c1a67f22)
    random._c5a4e031288d(_4fd3c1a67f22)
    _e57a6c5d7464._b426d8d17f91(_4fd3c1a67f22, _76489008d819=_67519fc4825e)
    _7fbba7a04f70._c704b4547739(_4fd3c1a67f22)
    if _7fbba7a04f70._81ba2053a3e2._14445a5c852f():
        _7fbba7a04f70._81ba2053a3e2._b08b9f3a5dca(_4fd3c1a67f22)

    _8bbbc8c52eaf = 0
    if _7fbba7a04f70._81ba2053a3e2._14445a5c852f():
        _118c20a6844d = _5eec69a95137(os._0f38b2e57633._aa5a0e6cd969('RANK', '0'))
        _be05ff5a779c = _5eec69a95137(os._0f38b2e57633._aa5a0e6cd969('WORLD_SIZE', '1'))
        try:
            if not _7fbba7a04f70._0117fe91ba9a._677b260754ac():
                _7fbba7a04f70._0117fe91ba9a._9322f8ec767b(
                    _56165ed2f05a=_0dc7e14449f6._56165ed2f05a, _8bbbc8c52eaf=_118c20a6844d, _be05ff5a779c=_be05ff5a779c,
                    _27c1c30c4f82=_518cfd47228a(_51a4a2882d93=600)
                )
        except _ff0103a678d4:
            pass
    if _7fbba7a04f70._0117fe91ba9a._677b260754ac():
        try:
            _8bbbc8c52eaf = _7fbba7a04f70._0117fe91ba9a._f7a3e27f98bd()
        except _ff0103a678d4:
            _8bbbc8c52eaf = _aa5db98be91e(_0dc7e14449f6, "local_rank", 0)

    _b36a7787948d = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="app.model_config_name", _e298802acdd8=_56e1401282d4, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Model config name under app.model_config_name"
    )
    _72ae523ee617 = f"metrics/{_b36a7787948d}"
    os._788adac09fec(_72ae523ee617, _8244a3729cfd=_67519fc4825e)

    _28aa28a47139 = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.pretrained_embedding", _e298802acdd8=_56e1401282d4, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _36dd237d0b3b = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="app.pretrained_embeddings_dir", _e298802acdd8=_56e1401282d4, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _4da9b47b737c = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.pretrained_embedding_overwrite_old", _e298802acdd8=_a22c3b5ecf4d, _dd1a0e25a530=_0b78aab900d5,
        _fd95a06ccda6="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _e1d6380cf433 = _0b78aab900d5
    _1343c7fa61c2 = _ca6c176b8d86
    if _7127680ba451:
        try:
            _1343c7fa61c2 = _9195e5a82301(
                _069cb5280e0c=_67519fc4825e,
                _41cc1d9c0e4e=_a7236e09e1d4(),
                _27542327a0cb=_67519fc4825e,
                _727899271ff8="nf4",
            )
            _e1d6380cf433 = _67519fc4825e
        except _ff0103a678d4:
            _1343c7fa61c2 = _ca6c176b8d86

    _02e955ffd346 = os._d49dca8dc3a3._f75f55a45690(
        _36dd237d0b3b,
        _28aa28a47139 + ("_quantized" if _7127680ba451 else "_fp32")
    )

    _4adb0656d5db._9e45d3f392b2(_02e955ffd346, _094741735bf8=_4da9b47b737c)
    if _4adb0656d5db._582e490cd2cb(_02e955ffd346):
        _484c7d7931c7._65a6ac39b458(f"Downloading pretrained embedding {_28aa28a47139}")
        try:
            from _28c537cf3534 import _16d7e7c6aad1
            _a39c8b676878 = _16d7e7c6aad1()
            _d210c59fe7fd = _a39c8b676878._d210c59fe7fd(_28aa28a47139)
            _d052ab8eee5c = _aa5db98be91e(_d210c59fe7fd, "sha", _ca6c176b8d86) or _ca6c176b8d86
        except _ff0103a678d4:
            _d052ab8eee5c = _ca6c176b8d86
        if "llama" in _28aa28a47139._2bb2a9edec73():
            from _d7cf7ea19b51 import _d5df1eeee6db, _35631369c1c9
            _b3b2a3fd5aff = _d5df1eeee6db._17bfe1e10faf(
                _28aa28a47139, _d052ab8eee5c=_d052ab8eee5c,
                _56597f87948f=_1343c7fa61c2 if (_7127680ba451 and _1343c7fa61c2) else _ca6c176b8d86
            )
            _86b9b5d5b323 = _35631369c1c9._17bfe1e10faf(_28aa28a47139, _d052ab8eee5c=_d052ab8eee5c, _70c1f200acc2=_0b78aab900d5)
            _13f7f385314d = _67519fc4825e
        else:
            from _d7cf7ea19b51 import _35efc7e69dc4, _35631369c1c9
            _b3b2a3fd5aff = _35efc7e69dc4._17bfe1e10faf(_28aa28a47139, _d052ab8eee5c=_d052ab8eee5c)
            _86b9b5d5b323 = _35631369c1c9._17bfe1e10faf(_28aa28a47139, _d052ab8eee5c=_d052ab8eee5c)
            _13f7f385314d = _0b78aab900d5
        try:
            _b3b2a3fd5aff._e94a434f31a2(_02e955ffd346)
            _86b9b5d5b323._e94a434f31a2(_02e955ffd346)
        except _ff0103a678d4:
            _484c7d7931c7._78d52887b7d5("Saving pretrained embedding locally failed; continuing.")
    else:
        _484c7d7931c7._65a6ac39b458(f"Loading pretrained embedding from {_02e955ffd346}")
        if "llama" in _28aa28a47139._2bb2a9edec73():
            from _d7cf7ea19b51 import _d5df1eeee6db, _35631369c1c9
            _b3b2a3fd5aff = _d5df1eeee6db._17bfe1e10faf(
                _02e955ffd346,
                _56597f87948f=_1343c7fa61c2 if (_7127680ba451 and _1343c7fa61c2) else _ca6c176b8d86
            )
            _86b9b5d5b323 = _35631369c1c9._17bfe1e10faf(_02e955ffd346, _70c1f200acc2=_0b78aab900d5)
            _13f7f385314d = _67519fc4825e
        else:
            from _d7cf7ea19b51 import _35efc7e69dc4, _35631369c1c9
            _b3b2a3fd5aff = _35efc7e69dc4._17bfe1e10faf(_02e955ffd346)
            _86b9b5d5b323 = _35631369c1c9._17bfe1e10faf(_02e955ffd346)
            _13f7f385314d = _0b78aab900d5

    _d6767776c3a5 = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.max_seq_len", _e298802acdd8=_5eec69a95137, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Maximum sequence length for training"
    )
    _1a6f0210b24c = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.batch_size", _e298802acdd8=_5eec69a95137, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Batch size for training"
    )
    _381ed0cfe5f8 = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.data_sample_share", _e298802acdd8=_bd30c81b97d7, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Proportion of dataset used for sampling"
    )
    _4b4c7711ef5d = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.optimizer", _e298802acdd8=_56e1401282d4, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Optimizer type under run_config.optimizer"
    )
    _dec16e6e295e = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.learning_rate", _e298802acdd8=_bd30c81b97d7, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Learning rate for optimizer"
    )
    _52a8a48c1cdf = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.num_backbone_model_units_unfrozen", _e298802acdd8=_5eec69a95137, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Number of backbone model units unfrozen during training"
    )
    _f12b15d663db = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.loss_type", _e298802acdd8=_56e1401282d4, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Loss function type under run_config.loss_type"
    )
    _4663a341f5d7 = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.num_fc_layers_in_classifier_head", _e298802acdd8=_5eec69a95137, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Number of FC layers in classifier head"
    )
    _7ad66b254503 = 'parametric_relu'
    _be9c496accbb = _67519fc4825e
    _337212c7c269 = _0b78aab900d5 if _52a8a48c1cdf == 0 else _67519fc4825e

    _5025e513cd8f: _93e6ab4eb4b5[_56e1401282d4, _1ed313c0dd7a] = {
        "device_dict": _8e0b7d7dc209(),
        "pretrained_embedding_model": _b3b2a3fd5aff,
        "optimizer": _4b4c7711ef5d,
        "num_backbone_model_units_unfrozen": _52a8a48c1cdf,
        "loss_type": _f12b15d663db,
        "lr": _dec16e6e295e,
        "is_train": _67519fc4825e,
        "tokenizer": _86b9b5d5b323,
        "random_seed": _4fd3c1a67f22,
        "num_fc_layers": _4663a341f5d7,
        "activation_function_for_layer": _7ad66b254503,
        "add_dropout_after_embedding": _be9c496accbb,
    }
    _5025e513cd8f._a55da63ff273({"pretrained_model_embedding_name": _28aa28a47139})

    _ba2311d479ef = os._d49dca8dc3a3._f75f55a45690(_9fc262ae11ec._f6289095069e._bcb04f28fa6f, _9fc262ae11ec._812d61639fdc._013f9b7f3595._bcb04f28fa6f)
    _455c108fdc3b = os._d49dca8dc3a3._f75f55a45690(_9fc262ae11ec._f6289095069e._bcb04f28fa6f, _9fc262ae11ec._812d61639fdc._4ff286849735._bcb04f28fa6f)
    _4a5d492ca09e = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="dataset.files_have_header", _e298802acdd8=_a22c3b5ecf4d, _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Whether dataset files have header"
    )
    _3d56d827be63 = f"config/{_b36a7787948d}/finetune/classes_config.json"
    _4adb0656d5db._9e45d3f392b2(os._d49dca8dc3a3._892bc027e1b5(_3d56d827be63))

    _e3d0bf80f20f = _286fae200417(
        _bcb04f28fa6f=_ba2311d479ef, _4a5d492ca09e=_4a5d492ca09e, _484c7d7931c7=_484c7d7931c7,
        _86b9b5d5b323=_86b9b5d5b323, _c1575b2fad04=_d6767776c3a5,
        _3d56d827be63=_3d56d827be63, _8989b98697c4=_67519fc4825e, _ee0b8dd0be4f=_0b78aab900d5,
        _4fd3c1a67f22=_4fd3c1a67f22, _ffc57edc89a0=_381ed0cfe5f8,
        _6b58c60abef8=_0dc7e14449f6._05ecd6dc4bc4, _13f7f385314d=_13f7f385314d, _27d3133f2aea=_ca6c176b8d86,
    )
    _14fe152ee2ec = _286fae200417(
        _bcb04f28fa6f=_455c108fdc3b, _4a5d492ca09e=_4a5d492ca09e, _484c7d7931c7=_484c7d7931c7,
        _86b9b5d5b323=_86b9b5d5b323, _c1575b2fad04=_d6767776c3a5,
        _3d56d827be63=_3d56d827be63, _8989b98697c4=_0b78aab900d5, _ee0b8dd0be4f=_0b78aab900d5,
        _4fd3c1a67f22=_4fd3c1a67f22, _ffc57edc89a0=_381ed0cfe5f8,
        _6b58c60abef8=_0dc7e14449f6._05ecd6dc4bc4, _13f7f385314d=_13f7f385314d, _27d3133f2aea=_ca6c176b8d86,
    )

    _a6b3168a8621 = _e3d0bf80f20f._98e74190be7b()
    _15f91d2dc7a0 = [_e3d0bf80f20f._8a6252aff1df(_793d83d1dac2) for _793d83d1dac2 in _e3d0bf80f20f._1dca50fd3583._9097836a99c8()]
    _7a6e1815e9fa = _e3d0bf80f20f._7a6e1815e9fa
    _ce3c0e1829f2 = {}
    for _c43c599f2e11, (_ba902a5655cd, _ca9ff1f58b77) in _18d0979ba1b3(_0ad3f0a46221(_15f91d2dc7a0, _7a6e1815e9fa)):
        _42e37d99cef8 = _86b9b5d5b323(_ba902a5655cd, _cacfc2a2e417=_0b78aab900d5)["input_ids"] if _13f7f385314d else [_c43c599f2e11]
        if _42e37d99cef8:
            _ce3c0e1829f2[_ba902a5655cd] = [_42e37d99cef8, _ca9ff1f58b77]
    _5025e513cd8f._a55da63ff273({"class_weights": _ce3c0e1829f2, "class_names": _15f91d2dc7a0})

    if "llama" in _28aa28a47139 and _13f7f385314d:
        _c5df2fdd9d9b = _cf6a48eeeb52(**_5025e513cd8f)
    else:
        _c5df2fdd9d9b = _a582e95d42c0(**_5025e513cd8f)

    _1b833a75d34b = _0a6d46f7ad81(
        _9fc262ae11ec=_9fc262ae11ec,
        _5def9c77b81c="operation_mode",
        _e298802acdd8=_56e1401282d4,
        _dd1a0e25a530=_67519fc4825e,
        _fd95a06ccda6="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _8a578e19cc61 = _ca6c176b8d86
    if _1b833a75d34b == "model_finetune":
        _8a578e19cc61 = _0a6d46f7ad81(
            _9fc262ae11ec=_9fc262ae11ec, _5def9c77b81c="run_config.finetuned_model_path", _e298802acdd8=_56e1401282d4, _dd1a0e25a530=_0b78aab900d5,
            _fd95a06ccda6="Optional path to pretrained model checkpoint for finetuning"
        )
        if _8a578e19cc61:
            _11aba96e1ff7(_c5df2fdd9d9b, _8a578e19cc61, _a71abe57e5b0="cpu")
            _484c7d7931c7._65a6ac39b458(f"Loaded finetuned model from {_8a578e19cc61}")

    _13a0182a2dd8 = []
    if _337212c7c269:
        _ca1567c29ab4 = lambda _dd50182d1a54: _552660c69a2d(_dd50182d1a54, "weight") and _b0e2b8b7593a(_dd50182d1a54._ca9ff1f58b77, _7fbba7a04f70._bdf85d428441) and _dd50182d1a54._ca9ff1f58b77._7b3fdc0a2aa1() > 64
        _f7ef24bf8ac3 = _c5df2fdd9d9b._8d7142079778
        _834178f62f68 = _765b31a60377(_f7ef24bf8ac3, _ca1567c29ab4=_ca1567c29ab4, _c1c36f9c1e36=_ca6c176b8d86, _5bebe501705b=_ca6c176b8d86)
        try:
            _d16c73059640 = _63715f609849(_ca6c176b8d86, _834178f62f68, _ca6c176b8d86)
        except _ff0103a678d4:
            from _a8660eb61eba import _5356eec4d333, _424db6c33718 as _6cc2259d65b0
            _d16c73059640 = _5356eec4d333(
                _27c962bc594a=8, _24d588294bae=32, _2ff4cae43f75=0.1,
                _834178f62f68=_b181d371b588(_834178f62f68._9097836a99c8()) if _834178f62f68 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _79823dd61df4=_6cc2259d65b0._4492d6603947 if _13f7f385314d else _6cc2259d65b0._2c9d3710be26
            )
        _f7ef24bf8ac3 = _353f5c9572f9(_f7ef24bf8ac3, _d16c73059640)
        for _5def9c77b81c, _f74c96e0fae3 in _c5df2fdd9d9b._59d4f36b13e6():
            if not _f74c96e0fae3._38f6fce0f4a0:
                _f74c96e0fae3 = _f74c96e0fae3._cfeb5ee3ab42()
            if "encoder" in _5def9c77b81c and "lora" not in _5def9c77b81c:
                _f74c96e0fae3._838c9afb866b = _0b78aab900d5
            elif "embedding" in _5def9c77b81c:
                _f74c96e0fae3._838c9afb866b = "lora" in _5def9c77b81c
        _484c7d7931c7._65a6ac39b458(f"Applied PEFT/LoRA config. Trainable parameters: {_8c9f91c07fe9(_f7ef24bf8ac3)}")

    try:
        _dbf47e99337e = _7fbba7a04f70._0117fe91ba9a._f7a3e27f98bd() if _7fbba7a04f70._81ba2053a3e2._14445a5c852f() and _7fbba7a04f70._0117fe91ba9a._677b260754ac() else -1
    except _ff0103a678d4:
        _dbf47e99337e = -1
    if _154e4e89e270._715026b7959a() is _0b78aab900d5:
        if _7fbba7a04f70._81ba2053a3e2._14445a5c852f():
            _c5df2fdd9d9b = _c5df2fdd9d9b._23df17c60437(_e298802acdd8=_7fbba7a04f70._5d65581beae2, _f4e3acb593ab=f"cuda:{_dbf47e99337e}")
        else:
            _c5df2fdd9d9b = _c5df2fdd9d9b._23df17c60437(_e298802acdd8=_7fbba7a04f70._5d65581beae2, _f4e3acb593ab="cpu")

    _9775f1dc5c8f = 'gpu' if _7fbba7a04f70._81ba2053a3e2._14445a5c852f() else 'cpu'
    _9416605a165b = _f7028342f957._bac3727516e0(_af5eba2d548e=2)
    _fe2ddaf530d1 = os._d49dca8dc3a3._f75f55a45690(_9fc262ae11ec._f6289095069e._221e66bee8cc, _b36a7787948d, "finetune")
    os._788adac09fec(_fe2ddaf530d1, _8244a3729cfd=_67519fc4825e)
    _ff8663e46535 = _f7028342f957._ce2639e1e24a(_33c248c5c5bc=_fe2ddaf530d1, _c69a575ae0a5="intermediate",
        _f7bea61e5d3a=1, _90e146552003=1000, _bfeeae575baa=_0b78aab900d5)
    _bd717b96cc32 = _f7028342f957._ce2639e1e24a(_33c248c5c5bc=_fe2ddaf530d1, _c69a575ae0a5="last", _f7bea61e5d3a=1,
        _bfeeae575baa=_67519fc4825e, _e77ad8e036cc="val_loss", _a34358fe20b7="min")
    _836bc2e60db7 = _f7028342f957._6155578978cd(_e77ad8e036cc="val_accuracy", _752d721322d1=3, _a34358fe20b7="max", _57e7c5511eea=_67519fc4825e)
    _21a854c60dd9 = _f7028342f957._4d77dfa752fa(_20d871e2bbcf='step')

    for _5def9c77b81c, _ba2883273b7c in _c5df2fdd9d9b._59d4f36b13e6():
        if not _ba2883273b7c._838c9afb866b:
            _13a0182a2dd8._188b7e38832e(_ba2883273b7c)
    _5376ca6373b9 = _959857439de9(_c020e19104ab=_13a0182a2dd8) if _9775f1dc5c8f == "gpu" else "auto"
    _db59ac7b2c88 = _0dc7e14449f6._db59ac7b2c88

    _b70df718aaf4 = _4517e6ff9c15(
        _b5d41ed4f396=_9775f1dc5c8f, _f1760ba01efe=_8d7dd4c5ad73(_9775f1dc5c8f),
        _db59ac7b2c88=_db59ac7b2c88, _f972738b0087=_5376ca6373b9 if _9775f1dc5c8f == "gpu" else "auto",
        _b38c94562b3c=_9fc262ae11ec._c5df2fdd9d9b._b38c94562b3c, _c65c31e33148=_0b78aab900d5, _d2369bb0c49b=_67519fc4825e,
        _cfd8c9a65ede=_67519fc4825e, _d47559948540=_0b78aab900d5,
        _6b4ac21de8f2=_9fc262ae11ec._bcc64e7d4969._6b4ac21de8f2,
        _d4e17c438f30=_9fc262ae11ec._bcc64e7d4969._e82193a3f9de,
        _f7028342f957=[_ff8663e46535, _bd717b96cc32, _836bc2e60db7, _21a854c60dd9],
    )

    _d54187302539 = _fa055cea81ef(
        _e3d0bf80f20f=_e3d0bf80f20f, _14fe152ee2ec=_14fe152ee2ec,
        _897f7dbbe276=_67519fc4825e, _110b85568e1b=_86b9b5d5b323,
        _ee10bd7ce44b=_1a6f0210b24c, _6b58c60abef8=_0dc7e14449f6._05ecd6dc4bc4,
        _13f7f385314d=_13f7f385314d, _4fd3c1a67f22=_4fd3c1a67f22
    )

    _aff97f4c992c = os._d49dca8dc3a3._f75f55a45690(_fe2ddaf530d1, "intermediate.ckpt")
    if os._d49dca8dc3a3._e78674ceef8b(_aff97f4c992c):
        _b70df718aaf4._3252e227620f(_c5df2fdd9d9b, _e96f8f9d6f41=_d54187302539, _3b043000ac3a=_aff97f4c992c)
    else:
        _b70df718aaf4._3252e227620f(_c5df2fdd9d9b, _e96f8f9d6f41=_d54187302539)

    if _7fbba7a04f70._0117fe91ba9a._677b260754ac():
        _7fbba7a04f70._0117fe91ba9a._0c056bbdc248()
    _daade905bdec = _bd717b96cc32._984680f1c73b
    if _daade905bdec:
        _484c7d7931c7._65a6ac39b458(f"Best checkpoint saved at {_daade905bdec}")
    try:
        from _a8660eb61eba import _b7d612684423
        if _552660c69a2d(_c5df2fdd9d9b, 'peft_config') or _b0e2b8b7593a(_c5df2fdd9d9b, _b7d612684423):
            _c5df2fdd9d9b = _c5df2fdd9d9b._1da35bc6402b()
    except _ff0103a678d4:
        pass
    if _e1d6380cf433:
        _c5df2fdd9d9b = _8c1c6d8522ad(_c5df2fdd9d9b)
        _c5df2fdd9d9b = _c5df2fdd9d9b._bd30c81b97d7()
    _2ec265e510cd = "saved_models"
    os._788adac09fec(_2ec265e510cd, _8244a3729cfd=_67519fc4825e)
    _9ba2bea482a6 = os._d49dca8dc3a3._f75f55a45690(_2ec265e510cd, "finetuned_model.pt")
    _7882903afe16 = _c5df2fdd9d9b._7882903afe16()
    _7fbba7a04f70._1c278d74e166(_7882903afe16, _9ba2bea482a6)
    _484c7d7931c7._65a6ac39b458(f"Saved finetuned state_dict to {_9ba2bea482a6}")
    _484c7d7931c7._65a6ac39b458("Finetuning completed successfully.")


def _465820af5149():
    _250cf777b68a = _3ea116c3ae3b._82d44e7ee750(_fb18aff2ac7a='Fine-tune a language identification model (single run)')
    _250cf777b68a._4aee8f4299e3('--config_file_path', _bbc804ddaa34=_56e1401282d4, _dd1a0e25a530=_67519fc4825e)
    _250cf777b68a._4aee8f4299e3('--num_nodes', _bbc804ddaa34=_5eec69a95137, _1d69e19fcc86=1)
    _250cf777b68a._4aee8f4299e3('--cpu_cores', _bbc804ddaa34=_5eec69a95137, _1d69e19fcc86=1)
    _250cf777b68a._4aee8f4299e3('--local-rank', _bbc804ddaa34=_5eec69a95137)
    _250cf777b68a._4aee8f4299e3('--backend', _bbc804ddaa34=_56e1401282d4, _1d69e19fcc86="gloo", _4b6cac4f6c44=['gloo', 'mpi', 'nccl'])
    _250cf777b68a._4aee8f4299e3('--run_timestamp', _bbc804ddaa34=_bd30c81b97d7, _1d69e19fcc86=_ca6c176b8d86)
    _0dc7e14449f6 = _250cf777b68a._b1f52455c31a()
    if _0dc7e14449f6._0a97f097831e is _ca6c176b8d86:
        _0dc7e14449f6._0a97f097831e = time.time()
    _260a5d78664e(_0dc7e14449f6)


if __name__ == "__main__":
    _0138b6f775f3()
