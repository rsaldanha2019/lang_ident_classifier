# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune copy.py
# @Time             : 2025-10-28 13:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-27 13:25 IST
# ---------------------------------------------------------

from _8ee016fbab81 import _eeb01a26a231
import _3b2609f6bf40, _97f1659cab03, _0152c0f6c724, _7e860c51f8db, _5c3e71409fa2, _9e27ca806557, _ccf109c1e02a, _85f194809e99
from _dd4a7353925f import _3f8ead56d558
from _fbfb42146738 import _784f05fc9045, _29a1f7e6b78f, _0b570b3eff39
import _ca9048668049 as _c6a04fcc6d34, _20ad76e28114, _78946c20c65c as _e20e989caf58
from _78946c20c65c import _b3acfb6e0fa9
from _78946c20c65c._3c4a862a40e3 import _a4cd1622e508
from _78946c20c65c._3c4a862a40e3._e0a8e14ca2e5._679873cb8411 import _3db65f124cbb
from _1403bb1a0bc6._51e8d8f4ac4e._4d5ae02c97f2._970d10a9d639 import _b6c369da5675
from _1403bb1a0bc6._51e8d8f4ac4e._4d5ae02c97f2._96430e895737 import _9bee9866c552
from _1403bb1a0bc6._51e8d8f4ac4e._4d5ae02c97f2._edff57338b28 import _bf1c0a9b09cb
from _1403bb1a0bc6._51e8d8f4ac4e._4d5ae02c97f2._7136d3a7de0d import _267001a6db1e
from _1403bb1a0bc6._51e8d8f4ac4e._3648a60aeda7._86a0231739da import _f21c2891ef8b
from _1403bb1a0bc6._51e8d8f4ac4e._3648a60aeda7._216d778260d7 import _0db22ea7ff6b
from _1403bb1a0bc6._51e8d8f4ac4e._ed565b8063b2._81ed0ec8813d import _ecc04d88c84f
from _1403bb1a0bc6._51e8d8f4ac4e._ed565b8063b2._3b9096cccc1d import _61683425493b
from _1403bb1a0bc6._51e8d8f4ac4e._4d5ae02c97f2._220dafd3bbab import _d9f2600118ff
from _1403bb1a0bc6._51e8d8f4ac4e._4d5ae02c97f2._220dafd3bbab import (
    _91a38f238d96, _2158960937b6, _6818a113499f,
    _3be0549e4616, _c3c1ecc2606c, _0a9fa3764733,
    _c0a53d6ebbe3, _2caf6f997fdd, _8f46039be106,
    _6131761bb480, _ac5a701b1b73, _3c1370602325,
    _a7f847271156, _9818143c3275
)

_0152c0f6c724._97d689a0bb4a["TOKENIZERS_PARALLELISM"] = "True"
_c5f01cbce5de = _20ad76e28114._0012d148e6b1._bfa07781ee6f() and _20ad76e28114._0012d148e6b1._ccac6dd67ae0() > 0
if _c5f01cbce5de:
    try:
        from _8b257cfc8542 import _66e3ac44102c
        import _bccba3485788 as _1d0ec49cf7c3
    except _446f76d0e60e:
        _1d0ec49cf7c3 = _49cfeb9e76c1


def _b9127569e26b(_92fca64a3944: _20ad76e28114._a324b4277361._23f4a18e3111, _414bb0820815: _0d5a01de2433, _f30e77970e51: _0b570b3eff39[_0d5a01de2433] = _49cfeb9e76c1) -> _49cfeb9e76c1:
    if not _0152c0f6c724._37908e929887._aba331b04891(_414bb0820815):
        raise _bf555d29a6df(f"Finetuned model path not found: {_414bb0820815}")
    if _414bb0820815._02b94e46022c((".pt", ".pth")):
        _e32c57ce3b58 = _f30e77970e51 or ("cpu" if not _20ad76e28114._0012d148e6b1._bfa07781ee6f() else _49cfeb9e76c1)
        _45faea1c68e3 = _20ad76e28114._8cdfc80233a6(_414bb0820815, _f30e77970e51=_e32c57ce3b58)
        _5520c90165c8 = _45faea1c68e3._c7ba7344345f("state_dict", _45faea1c68e3._c7ba7344345f("model_state_dict", _45faea1c68e3)) if _1cb6c70f069e(_45faea1c68e3, _f3da4eadb10b) else _45faea1c68e3
        if not _1cb6c70f069e(_5520c90165c8, _f3da4eadb10b):
            raise _685021f72942(f"Loaded .pt file does not contain state_dict mapping: {_414bb0820815}")
        _92fca64a3944._01514372fe47(_5520c90165c8, _e3bda0b0fb85=_a0dfcf4fb64d)
    elif _414bb0820815._02b94e46022c(".ckpt"):
        try:
            if _e71e185875b7(_92fca64a3944._382c1164a2c0, "load_from_checkpoint"):
                _213cb4a235ad = _92fca64a3944._382c1164a2c0._c714fc9fd5bc(_414bb0820815, **{})
                _92fca64a3944._01514372fe47(_213cb4a235ad._4c28da16fdae(), _e3bda0b0fb85=_a0dfcf4fb64d)
                return
            _45faea1c68e3 = _20ad76e28114._8cdfc80233a6(_414bb0820815, _f30e77970e51="cpu")
            _5520c90165c8 = _45faea1c68e3._c7ba7344345f("state_dict", _45faea1c68e3)
            if not _1cb6c70f069e(_5520c90165c8, _f3da4eadb10b):
                raise _685021f72942("Lightning checkpoint did not contain a recognizable state_dict.")
            _92fca64a3944._01514372fe47(_5520c90165c8, _e3bda0b0fb85=_a0dfcf4fb64d)
        except _446f76d0e60e as _42997531bbd4:
            raise _685021f72942(f"Failed to load .ckpt into model: {_42997531bbd4}") from _42997531bbd4
    else:
        raise _8640570889ce("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _a0b1d5ca43a2(_e9de749296f9: _3b2609f6bf40._924197dabfd3) -> _49cfeb9e76c1:
    _3dd23c15470b = _b6c369da5675()
    _810b195b5f4c = _3dd23c15470b._2277d9d2763c(_e9de749296f9._8c4eba754a58)
    _f0af013c2030 = _9bee9866c552()
    _4a99ca34ca97 = _f0af013c2030._814263054c84(_810b195b5f4c)
    _e46624a3b3a9 = _bf1c0a9b09cb()
    _7501bf7e344d = _267001a6db1e()

    _49ffd885463d = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="app.random_seed", _bbcc1f2d45b6=_a1eb27723202, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Seed for reproducibility under app.random_seed"
    )
    _c6a04fcc6d34._7e860c51f8db._3950cc65d9e5(_49ffd885463d)
    _7e860c51f8db._3950cc65d9e5(_49ffd885463d)
    _e20e989caf58._e4cfab8c3b6d(_49ffd885463d, _f806c20dd823=_c001caae5560)
    _20ad76e28114._375bdb63c53b(_49ffd885463d)
    if _20ad76e28114._0012d148e6b1._bfa07781ee6f():
        _20ad76e28114._0012d148e6b1._c0794fb71683(_49ffd885463d)

    _8da4fbb06e47 = 0
    if _20ad76e28114._0012d148e6b1._bfa07781ee6f():
        _04e7f620aa85 = _a1eb27723202(_0152c0f6c724._97d689a0bb4a._c7ba7344345f('RANK', '0'))
        _9a62fd82f25d = _a1eb27723202(_0152c0f6c724._97d689a0bb4a._c7ba7344345f('WORLD_SIZE', '1'))
        try:
            if not _20ad76e28114._9aaec9c8baf2._57cd8fb94edc():
                _20ad76e28114._9aaec9c8baf2._298c32e4acc5(
                    _b3f3a8abc577=_e9de749296f9._b3f3a8abc577, _8da4fbb06e47=_04e7f620aa85, _9a62fd82f25d=_9a62fd82f25d,
                    _acae2bed4424=_3f8ead56d558(_436cd0920b0a=600)
                )
        except _446f76d0e60e:
            pass
    if _20ad76e28114._9aaec9c8baf2._57cd8fb94edc():
        try:
            _8da4fbb06e47 = _20ad76e28114._9aaec9c8baf2._3656b9b8d243()
        except _446f76d0e60e:
            _8da4fbb06e47 = _a282fdec16e4(_e9de749296f9, "local_rank", 0)

    _546972e5bf59 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="app.model_config_name", _bbcc1f2d45b6=_0d5a01de2433, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Model config name under app.model_config_name"
    )
    _cf0232ec4367 = f"metrics/{_546972e5bf59}"
    _0152c0f6c724._7c1be975bbef(_cf0232ec4367, _62cca6b76880=_c001caae5560)

    _b6abe3a5a1dc = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.pretrained_embedding", _bbcc1f2d45b6=_0d5a01de2433, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _4429dd9e01a1 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="app.pretrained_embeddings_dir", _bbcc1f2d45b6=_0d5a01de2433, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _f35ee75010d0 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.pretrained_embedding_overwrite_old", _bbcc1f2d45b6=_927ab6ea9b75, _78d95367969e=_a0dfcf4fb64d,
        _35792c48dc8c="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _cf28c804a01a = _a0dfcf4fb64d
    _031b45d7e7c8 = _49cfeb9e76c1
    if _c5f01cbce5de:
        try:
            _031b45d7e7c8 = _66e3ac44102c(
                _dd78251f2611=_c001caae5560,
                _8962a84e7130=_6818a113499f(),
                _69db4d417b95=_c001caae5560,
                _a6f72ca3d112="nf4",
            )
            _cf28c804a01a = _c001caae5560
        except _446f76d0e60e:
            _031b45d7e7c8 = _49cfeb9e76c1

    _32f9b761bf4b = _0152c0f6c724._37908e929887._08c7c1867db7(
        _4429dd9e01a1,
        _b6abe3a5a1dc + ("_quantized" if _c5f01cbce5de else "_fp32")
    )

    _e46624a3b3a9._52ce510fba5b(_32f9b761bf4b, _b9c341f8dfe7=_f35ee75010d0)
    if _e46624a3b3a9._09b453cb8c04(_32f9b761bf4b):
        _4a99ca34ca97._c0b926405bda(f"Downloading pretrained embedding {_b6abe3a5a1dc}")
        try:
            from _11c7d4c9ac87 import _8b8036cde6fe
            _ab9954307e66 = _8b8036cde6fe()
            _406c296a0b37 = _ab9954307e66._406c296a0b37(_b6abe3a5a1dc)
            _65c18b460288 = _a282fdec16e4(_406c296a0b37, "sha", _49cfeb9e76c1) or _49cfeb9e76c1
        except _446f76d0e60e:
            _65c18b460288 = _49cfeb9e76c1
        if "llama" in _b6abe3a5a1dc._aaf7e7191ba8():
            from _8b257cfc8542 import _237f0dcc56fd, _aef6c4e76ac8
            _ea16f61b365d = _237f0dcc56fd._54ac979a4a37(
                _b6abe3a5a1dc, _65c18b460288=_65c18b460288,
                _c1e9fb349a1d=_031b45d7e7c8 if (_c5f01cbce5de and _031b45d7e7c8) else _49cfeb9e76c1
            )
            _82b0426fa516 = _aef6c4e76ac8._54ac979a4a37(_b6abe3a5a1dc, _65c18b460288=_65c18b460288, _b368c9d85a3e=_a0dfcf4fb64d)
            _23a8bcef0c36 = _c001caae5560
        else:
            from _8b257cfc8542 import _66d2dffce370, _aef6c4e76ac8
            _ea16f61b365d = _66d2dffce370._54ac979a4a37(_b6abe3a5a1dc, _65c18b460288=_65c18b460288)
            _82b0426fa516 = _aef6c4e76ac8._54ac979a4a37(_b6abe3a5a1dc, _65c18b460288=_65c18b460288)
            _23a8bcef0c36 = _a0dfcf4fb64d
        try:
            _ea16f61b365d._089505e2fd3f(_32f9b761bf4b)
            _82b0426fa516._089505e2fd3f(_32f9b761bf4b)
        except _446f76d0e60e:
            _4a99ca34ca97._50f8816fbcfc("Saving pretrained embedding locally failed; continuing.")
    else:
        _4a99ca34ca97._c0b926405bda(f"Loading pretrained embedding from {_32f9b761bf4b}")
        if "llama" in _b6abe3a5a1dc._aaf7e7191ba8():
            from _8b257cfc8542 import _237f0dcc56fd, _aef6c4e76ac8
            _ea16f61b365d = _237f0dcc56fd._54ac979a4a37(
                _32f9b761bf4b,
                _c1e9fb349a1d=_031b45d7e7c8 if (_c5f01cbce5de and _031b45d7e7c8) else _49cfeb9e76c1
            )
            _82b0426fa516 = _aef6c4e76ac8._54ac979a4a37(_32f9b761bf4b, _b368c9d85a3e=_a0dfcf4fb64d)
            _23a8bcef0c36 = _c001caae5560
        else:
            from _8b257cfc8542 import _66d2dffce370, _aef6c4e76ac8
            _ea16f61b365d = _66d2dffce370._54ac979a4a37(_32f9b761bf4b)
            _82b0426fa516 = _aef6c4e76ac8._54ac979a4a37(_32f9b761bf4b)
            _23a8bcef0c36 = _a0dfcf4fb64d

    _79552d025f0f = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.max_seq_len", _bbcc1f2d45b6=_a1eb27723202, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Maximum sequence length for training"
    )
    _0bcf251291ae = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.batch_size", _bbcc1f2d45b6=_a1eb27723202, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Batch size for training"
    )
    _7447b44931d3 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.data_sample_share", _bbcc1f2d45b6=_20862b2ec4de, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Proportion of dataset used for sampling"
    )
    _c1fc14b8062b = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.optimizer", _bbcc1f2d45b6=_0d5a01de2433, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Optimizer type under run_config.optimizer"
    )
    _89894afd9823 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.learning_rate", _bbcc1f2d45b6=_20862b2ec4de, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Learning rate for optimizer"
    )
    _959ba00cd9cd = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.num_backbone_model_units_unfrozen", _bbcc1f2d45b6=_a1eb27723202, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Number of backbone model units unfrozen during training"
    )
    _4cf842d8ebe3 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.loss_type", _bbcc1f2d45b6=_0d5a01de2433, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Loss function type under run_config.loss_type"
    )
    _45701b32c800 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.num_fc_layers_in_classifier_head", _bbcc1f2d45b6=_a1eb27723202, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Number of FC layers in classifier head"
    )
    _80f980fe4653 = 'parametric_relu'
    _7eb85f2c00ab = _c001caae5560
    _ec6f3bc61879 = _a0dfcf4fb64d if _959ba00cd9cd == 0 else _c001caae5560

    _4c784a793fde: _29a1f7e6b78f[_0d5a01de2433, _784f05fc9045] = {
        "device_dict": _2158960937b6(),
        "pretrained_embedding_model": _ea16f61b365d,
        "optimizer": _c1fc14b8062b,
        "num_backbone_model_units_unfrozen": _959ba00cd9cd,
        "loss_type": _4cf842d8ebe3,
        "lr": _89894afd9823,
        "is_train": _c001caae5560,
        "tokenizer": _82b0426fa516,
        "random_seed": _49ffd885463d,
        "num_fc_layers": _45701b32c800,
        "activation_function_for_layer": _80f980fe4653,
        "add_dropout_after_embedding": _7eb85f2c00ab,
    }
    _4c784a793fde._d67f6e91dacf({"pretrained_model_embedding_name": _b6abe3a5a1dc})

    _fe8982f6d3cf = _0152c0f6c724._37908e929887._08c7c1867db7(_810b195b5f4c._b2ceefccc8a6._d82ad5d78f51, _810b195b5f4c._3648a60aeda7._50003ed707b6._d82ad5d78f51)
    _0d665330db84 = _0152c0f6c724._37908e929887._08c7c1867db7(_810b195b5f4c._b2ceefccc8a6._d82ad5d78f51, _810b195b5f4c._3648a60aeda7._7716009755f6._d82ad5d78f51)
    _1cff90e74a0c = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="dataset.files_have_header", _bbcc1f2d45b6=_927ab6ea9b75, _78d95367969e=_c001caae5560,
        _35792c48dc8c="Whether dataset files have header"
    )
    _478d43ace109 = f"config/{_546972e5bf59}/finetune/classes_config.json"
    _e46624a3b3a9._52ce510fba5b(_0152c0f6c724._37908e929887._6118fb6c6091(_478d43ace109))

    _795e846d32d1 = _f21c2891ef8b(
        _d82ad5d78f51=_fe8982f6d3cf, _1cff90e74a0c=_1cff90e74a0c, _4a99ca34ca97=_4a99ca34ca97,
        _82b0426fa516=_82b0426fa516, _81775f8a54d9=_79552d025f0f,
        _478d43ace109=_478d43ace109, _8df89d3de81d=_c001caae5560, _e8c4f34d8493=_a0dfcf4fb64d,
        _49ffd885463d=_49ffd885463d, _3b920f008e50=_7447b44931d3,
        _57ecf8635eac=_e9de749296f9._338d1acccf3f, _23a8bcef0c36=_23a8bcef0c36, _185f81ca33d8=_49cfeb9e76c1,
    )
    _aa8f007f6099 = _f21c2891ef8b(
        _d82ad5d78f51=_0d665330db84, _1cff90e74a0c=_1cff90e74a0c, _4a99ca34ca97=_4a99ca34ca97,
        _82b0426fa516=_82b0426fa516, _81775f8a54d9=_79552d025f0f,
        _478d43ace109=_478d43ace109, _8df89d3de81d=_a0dfcf4fb64d, _e8c4f34d8493=_a0dfcf4fb64d,
        _49ffd885463d=_49ffd885463d, _3b920f008e50=_7447b44931d3,
        _57ecf8635eac=_e9de749296f9._338d1acccf3f, _23a8bcef0c36=_23a8bcef0c36, _185f81ca33d8=_49cfeb9e76c1,
    )

    _2d5f9930c289 = _795e846d32d1._abc8be2805d7()
    _880aefe9deba = [_795e846d32d1._efdcff3a78b0(_43fdbe7d8883) for _43fdbe7d8883 in _795e846d32d1._4159cea61e87._b5f49d3ecbb8()]
    _0e604c214225 = _795e846d32d1._0e604c214225
    _c448764436c7 = {}
    for _87008fdd5b05, (_7a9cf135a92f, _8beeb2578358) in _ffff8341c2cb(_dd59308702ac(_880aefe9deba, _0e604c214225)):
        _98bbfde171ca = _82b0426fa516(_7a9cf135a92f, _47428b80f585=_a0dfcf4fb64d)["input_ids"] if _23a8bcef0c36 else [_87008fdd5b05]
        if _98bbfde171ca:
            _c448764436c7[_7a9cf135a92f] = [_98bbfde171ca, _8beeb2578358]
    _4c784a793fde._d67f6e91dacf({"class_weights": _c448764436c7, "class_names": _880aefe9deba})

    if "llama" in _b6abe3a5a1dc and _23a8bcef0c36:
        _92fca64a3944 = _61683425493b(**_4c784a793fde)
    else:
        _92fca64a3944 = _ecc04d88c84f(**_4c784a793fde)

    _4ae960a434f7 = _9818143c3275(
        _810b195b5f4c=_810b195b5f4c,
        _0d6196c0d2fb="operation_mode",
        _bbcc1f2d45b6=_0d5a01de2433,
        _78d95367969e=_c001caae5560,
        _35792c48dc8c="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _ff08fe15656b = _49cfeb9e76c1
    if _4ae960a434f7 == "model_finetune":
        _ff08fe15656b = _9818143c3275(
            _810b195b5f4c=_810b195b5f4c, _0d6196c0d2fb="run_config.finetuned_model_path", _bbcc1f2d45b6=_0d5a01de2433, _78d95367969e=_a0dfcf4fb64d,
            _35792c48dc8c="Optional path to pretrained model checkpoint for finetuning"
        )
        if _ff08fe15656b:
            _5b434455d404(_92fca64a3944, _ff08fe15656b, _f30e77970e51="cpu")
            _4a99ca34ca97._c0b926405bda(f"Loaded finetuned model from {_ff08fe15656b}")

    _fc8ef10e3be6 = []
    if _ec6f3bc61879:
        _e559b0cb5c73 = lambda _4869acdc2ea2: _e71e185875b7(_4869acdc2ea2, "weight") and _1cb6c70f069e(_4869acdc2ea2._8beeb2578358, _20ad76e28114._cc5d472c65b1) and _4869acdc2ea2._8beeb2578358._220aeffbae84() > 64
        _8569ef735197 = _92fca64a3944._fd4129602274
        _e36edb401576 = _3be0549e4616(_8569ef735197, _e559b0cb5c73=_e559b0cb5c73, _e5b8a306e56e=_49cfeb9e76c1, _2dad13e2e7ac=_49cfeb9e76c1)
        try:
            _f3b6a1ca9100 = _d9f2600118ff(_49cfeb9e76c1, _e36edb401576, _49cfeb9e76c1)
        except _446f76d0e60e:
            from _ab7ea1e6ff86 import _72b99e87a2b5, _7290f1705ad1 as _312bc61acd03
            _f3b6a1ca9100 = _72b99e87a2b5(
                _2452637ab806=8, _ea5964103788=32, _2a34c94c7cce=0.1,
                _e36edb401576=_8b251a4ed009(_e36edb401576._b5f49d3ecbb8()) if _e36edb401576 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _5f90c25d0d8c=_312bc61acd03._6cf4fd1c5edb if _23a8bcef0c36 else _312bc61acd03._6404626bd54f
            )
        _8569ef735197 = _0a9fa3764733(_8569ef735197, _f3b6a1ca9100)
        for _0d6196c0d2fb, _5e0b8b1a5f3b in _92fca64a3944._0752ee004d47():
            if not _5e0b8b1a5f3b._664e91762e55:
                _5e0b8b1a5f3b = _5e0b8b1a5f3b._6ce31b4eae8d()
            if "encoder" in _0d6196c0d2fb and "lora" not in _0d6196c0d2fb:
                _5e0b8b1a5f3b._26d6fbe8db73 = _a0dfcf4fb64d
            elif "embedding" in _0d6196c0d2fb:
                _5e0b8b1a5f3b._26d6fbe8db73 = "lora" in _0d6196c0d2fb
        _4a99ca34ca97._c0b926405bda(f"Applied PEFT/LoRA config. Trainable parameters: {_c3c1ecc2606c(_8569ef735197)}")

    try:
        _9c2ea93f3a90 = _20ad76e28114._9aaec9c8baf2._3656b9b8d243() if _20ad76e28114._0012d148e6b1._bfa07781ee6f() and _20ad76e28114._9aaec9c8baf2._57cd8fb94edc() else -1
    except _446f76d0e60e:
        _9c2ea93f3a90 = -1
    if _3db65f124cbb._d8bae274e235() is _a0dfcf4fb64d:
        if _20ad76e28114._0012d148e6b1._bfa07781ee6f():
            _92fca64a3944 = _92fca64a3944._783f824dc2f1(_bbcc1f2d45b6=_20ad76e28114._981de1963c83, _3abb91643efa=f"cuda:{_9c2ea93f3a90}")
        else:
            _92fca64a3944 = _92fca64a3944._783f824dc2f1(_bbcc1f2d45b6=_20ad76e28114._981de1963c83, _3abb91643efa="cpu")

    _9a51267f8298 = 'gpu' if _20ad76e28114._0012d148e6b1._bfa07781ee6f() else 'cpu'
    _c062163e0dcd = _a4cd1622e508._72710581e805(_a066791cbb40=2)
    _be7d6554924f = _0152c0f6c724._37908e929887._08c7c1867db7(_810b195b5f4c._b2ceefccc8a6._2919b55854e1, _546972e5bf59, "finetune")
    _0152c0f6c724._7c1be975bbef(_be7d6554924f, _62cca6b76880=_c001caae5560)
    _b3d2093e1af0 = _a4cd1622e508._d130a3296a54(_1a2cc832d7a3=_be7d6554924f, _3b59d49ee3b9="intermediate",
        _0e5897e168bd=1, _a7111ee6d00c=1000, _e5f1b7ce45a3=_a0dfcf4fb64d)
    _36afb1d408d8 = _a4cd1622e508._d130a3296a54(_1a2cc832d7a3=_be7d6554924f, _3b59d49ee3b9="last", _0e5897e168bd=1,
        _e5f1b7ce45a3=_c001caae5560, _805ccca6b0f6="val_loss", _6d799893e242="min")
    _1c0e34ee374d = _a4cd1622e508._2852cca6b9b6(_805ccca6b0f6="val_accuracy", _e2045388cdb3=3, _6d799893e242="max", _f0c87927c2c4=_c001caae5560)
    _f5b2b681e8b9 = _a4cd1622e508._544c8828f2c2(_7d955087e5fb='step')

    for _0d6196c0d2fb, _0705c2f1a8cc in _92fca64a3944._0752ee004d47():
        if not _0705c2f1a8cc._26d6fbe8db73:
            _fc8ef10e3be6._cdb70ff91d0e(_0705c2f1a8cc)
    _ba8f31a943ca = _a7f847271156(_cdaee8704353=_fc8ef10e3be6) if _9a51267f8298 == "gpu" else "auto"
    _23a0323a8358 = _e9de749296f9._23a0323a8358

    _dfa0a2e797b6 = _b3acfb6e0fa9(
        _53ca483504e0=_9a51267f8298, _6a629b1c6cf3=_2caf6f997fdd(_9a51267f8298),
        _23a0323a8358=_23a0323a8358, _af2d6b174859=_ba8f31a943ca if _9a51267f8298 == "gpu" else "auto",
        _1495c73a4e5a=_810b195b5f4c._92fca64a3944._1495c73a4e5a, _e6e69cc47a91=_a0dfcf4fb64d, _26a89d8dea11=_c001caae5560,
        _bbb764d2e0a1=_c001caae5560, _4b752dfaaabb=_a0dfcf4fb64d,
        _25dc16a09528=_810b195b5f4c._7f1b811da48e._25dc16a09528,
        _0f41bb65d4a0=_810b195b5f4c._7f1b811da48e._b687ec366053,
        _a4cd1622e508=[_b3d2093e1af0, _36afb1d408d8, _1c0e34ee374d, _f5b2b681e8b9],
    )

    _1ddd361378ee = _0db22ea7ff6b(
        _795e846d32d1=_795e846d32d1, _aa8f007f6099=_aa8f007f6099,
        _a5d0e7ed925a=_c001caae5560, _4a50a6bcc5ec=_82b0426fa516,
        _c7bb6edfa706=_0bcf251291ae, _57ecf8635eac=_e9de749296f9._338d1acccf3f,
        _23a8bcef0c36=_23a8bcef0c36, _49ffd885463d=_49ffd885463d
    )

    _345459eb1ee9 = _0152c0f6c724._37908e929887._08c7c1867db7(_be7d6554924f, "intermediate.ckpt")
    if _0152c0f6c724._37908e929887._aba331b04891(_345459eb1ee9):
        _dfa0a2e797b6._8faa0783c4d3(_92fca64a3944, _f8b932ef45a0=_1ddd361378ee, _414bb0820815=_345459eb1ee9)
    else:
        _dfa0a2e797b6._8faa0783c4d3(_92fca64a3944, _f8b932ef45a0=_1ddd361378ee)

    if _20ad76e28114._9aaec9c8baf2._57cd8fb94edc():
        _20ad76e28114._9aaec9c8baf2._8864d8b36621()
    _9e1707d217d0 = _36afb1d408d8._8a863e0584d0
    if _9e1707d217d0:
        _4a99ca34ca97._c0b926405bda(f"Best checkpoint saved at {_9e1707d217d0}")
    try:
        from _ab7ea1e6ff86 import _62fc976286f5
        if _e71e185875b7(_92fca64a3944, 'peft_config') or _1cb6c70f069e(_92fca64a3944, _62fc976286f5):
            _92fca64a3944 = _92fca64a3944._fc8eb143a39d()
    except _446f76d0e60e:
        pass
    if _cf28c804a01a:
        _92fca64a3944 = _6131761bb480(_92fca64a3944)
        _92fca64a3944 = _92fca64a3944._20862b2ec4de()
    _aa1822f41e9d = "saved_models"
    _0152c0f6c724._7c1be975bbef(_aa1822f41e9d, _62cca6b76880=_c001caae5560)
    _e73d616edc9c = _0152c0f6c724._37908e929887._08c7c1867db7(_aa1822f41e9d, "finetuned_model.pt")
    _4c28da16fdae = _92fca64a3944._4c28da16fdae()
    _20ad76e28114._fa0a1ad6fac4(_4c28da16fdae, _e73d616edc9c)
    _4a99ca34ca97._c0b926405bda(f"Saved finetuned state_dict to {_e73d616edc9c}")
    _4a99ca34ca97._c0b926405bda("Finetuning completed successfully.")


def _e71bf83b2b43():
    _0516218ed9ee = _3b2609f6bf40._4c3e322c2404(_b22077d33522='Fine-tune a language identification model (single run)')
    _0516218ed9ee._ca3638809abc('--config_file_path', _5f41e3afd37a=_0d5a01de2433, _78d95367969e=_c001caae5560)
    _0516218ed9ee._ca3638809abc('--num_nodes', _5f41e3afd37a=_a1eb27723202, _be90684c7bff=1)
    _0516218ed9ee._ca3638809abc('--cpu_cores', _5f41e3afd37a=_a1eb27723202, _be90684c7bff=1)
    _0516218ed9ee._ca3638809abc('--local-rank', _5f41e3afd37a=_a1eb27723202)
    _0516218ed9ee._ca3638809abc('--backend', _5f41e3afd37a=_0d5a01de2433, _be90684c7bff="gloo", _e7411e1e17f0=['gloo', 'mpi', 'nccl'])
    _0516218ed9ee._ca3638809abc('--run_timestamp', _5f41e3afd37a=_20862b2ec4de, _be90684c7bff=_49cfeb9e76c1)
    _e9de749296f9 = _0516218ed9ee._af789566d9c9()
    if _e9de749296f9._26798c212a35 is _49cfeb9e76c1:
        _e9de749296f9._26798c212a35 = _ccf109c1e02a._ccf109c1e02a()
    _d064db5b6327(_e9de749296f9)


if __name__ == "__main__":
    _4f08c0f886ec()
