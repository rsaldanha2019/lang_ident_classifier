# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune copy.py
# @Time             : 2025-10-28 13:06 IST
# @CodeCheck        :
# 14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author through email on the github README
# if you intend to use this package for commercial purposes
# ---------------------------------------------------------

# -*- coding: utf-8 -*-
# ---------------------------------------------------------
# @File             : model_train_finetune.py
# @Time             : 2025-10-27 13:25 IST
# ---------------------------------------------------------

from __future__ import _055539d2e949
import _7cec2d5b3f83, json, os, random, _9897373ae26f, sys, time, _e1bc5b2bc5c1
from _4e71e8feeaf7 import _f9e899f9596a
from typing import _0a4cc20b0a20, _353cc51c9415, _71e4cb23e5b3
import _ffa0a5730177 as _03866ab7b477, _1f3bb723746d, _d1be58416105 as _9b0b3ae80fe8
from _d1be58416105 import _769d5265cf60
from _d1be58416105._bd44ee6384b1 import _aa349d24da01
from _d1be58416105._bd44ee6384b1._53744517a2bb._e5fef88b5a97 import _2334006248f0
from _365dec949d0c._33e7cda173b8._5634b8d750be._9356aa0207ea import _b1032f05bdbf
from _365dec949d0c._33e7cda173b8._5634b8d750be._76bc34089125 import _c65b2194e50f
from _365dec949d0c._33e7cda173b8._5634b8d750be._24ec15edea98 import _2590f601ca88
from _365dec949d0c._33e7cda173b8._5634b8d750be._7f8c903fef5f import _6f8bd16d9d0c
from _365dec949d0c._33e7cda173b8._e1cc19657d3a._c45d5441ebf8 import _f5c7731210f0
from _365dec949d0c._33e7cda173b8._e1cc19657d3a._d83f73f1cddb import _50b740cdf4fa
from _365dec949d0c._33e7cda173b8._dbe7196a92dc._de8b653b7255 import _65bec2ef17cc
from _365dec949d0c._33e7cda173b8._dbe7196a92dc._e8f18f26124b import _e719a171bcdc
from _365dec949d0c._33e7cda173b8._5634b8d750be._5aac45e0a118 import _7ee3fa12c51c
from _365dec949d0c._33e7cda173b8._5634b8d750be._5aac45e0a118 import (
    _2bdf5f117f0a, _ae3cda2486de, _532a52045e29,
    _bdf995d8770d, _93dc403b5f09, _348445463b86,
    _f92e61f3acbe, _fb0fcd86587e, _9c8bb6532c04,
    _0892281f4866, _78cb74dfc2bb, _fa74a9ae92c4,
    _7e17d6b3069a, _bc33bd8cb4d0
)

os._4f4a500d2129["TOKENIZERS_PARALLELISM"] = "True"
_28c4072e08ce = _1f3bb723746d._21312ccc7e8a._ed62085e1921() and _1f3bb723746d._21312ccc7e8a._bb17e422ab33() > 0
if _28c4072e08ce:
    try:
        from _ce7846c69b3c import _55f5dfe1be1d
        import _c6361f6ec9cf as _5d217a226455
    except _cad8a2d9e106:
        _5d217a226455 = _3602ae0a1562


def _4bf33131bc0e(_0334ebd21161: _1f3bb723746d._abaf34b4e9bb._3fe2cafb951c, _2b5b3b6fefef: _faf51797fd8f, _7b5ea2aa6245: _71e4cb23e5b3[_faf51797fd8f] = _3602ae0a1562) -> _3602ae0a1562:
    if not os._9b766b11afd4._8e8ae44441eb(_2b5b3b6fefef):
        raise _cc6ae81bf495(f"Finetuned model path not found: {_2b5b3b6fefef}")
    if _2b5b3b6fefef._a1960a8f3a03((".pt", ".pth")):
        _e48c05ce504e = _7b5ea2aa6245 or ("cpu" if not _1f3bb723746d._21312ccc7e8a._ed62085e1921() else _3602ae0a1562)
        _e39dbdad8c52 = _1f3bb723746d._27ad7cea391a(_2b5b3b6fefef, _7b5ea2aa6245=_e48c05ce504e)
        _0789240a5910 = _e39dbdad8c52._0777997c1941("state_dict", _e39dbdad8c52._0777997c1941("model_state_dict", _e39dbdad8c52)) if _06a8de79a025(_e39dbdad8c52, _eee247b936f8) else _e39dbdad8c52
        if not _06a8de79a025(_0789240a5910, _eee247b936f8):
            raise _027ab0e9c8ed(f"Loaded .pt file does not contain state_dict mapping: {_2b5b3b6fefef}")
        _0334ebd21161._d075367e6a64(_0789240a5910, _99b2658b896f=_73b5957789b8)
    elif _2b5b3b6fefef._a1960a8f3a03(".ckpt"):
        try:
            if _cb90ed232e06(_0334ebd21161._67109588f745, "load_from_checkpoint"):
                _8db8bed32193 = _0334ebd21161._67109588f745._e8dc5d51fec8(_2b5b3b6fefef, **{})
                _0334ebd21161._d075367e6a64(_8db8bed32193._46e07e732c8c(), _99b2658b896f=_73b5957789b8)
                return
            _e39dbdad8c52 = _1f3bb723746d._27ad7cea391a(_2b5b3b6fefef, _7b5ea2aa6245="cpu")
            _0789240a5910 = _e39dbdad8c52._0777997c1941("state_dict", _e39dbdad8c52)
            if not _06a8de79a025(_0789240a5910, _eee247b936f8):
                raise _027ab0e9c8ed("Lightning checkpoint did not contain a recognizable state_dict.")
            _0334ebd21161._d075367e6a64(_0789240a5910, _99b2658b896f=_73b5957789b8)
        except _cad8a2d9e106 as _5a3fb4460ef8:
            raise _027ab0e9c8ed(f"Failed to load .ckpt into model: {_5a3fb4460ef8}") from _5a3fb4460ef8
    else:
        raise _4b9963eaffe2("Unsupported finetuned model extension. Supported: .pt, .pth, .ckpt")


def _2e6d20d3fca6(_be9ea9b6011f: _7cec2d5b3f83._767e48201ba1) -> _3602ae0a1562:
    _47e8edb464da = _b1032f05bdbf()
    _fb9a6f1ee3c6 = _47e8edb464da._61df0d698641(_be9ea9b6011f._3b5b8a162b30)
    _8311913cb091 = _c65b2194e50f()
    _a25a2a9b0941 = _8311913cb091._727526bdcc36(_fb9a6f1ee3c6)
    _e3f5291f8a18 = _2590f601ca88()
    _22967ab1e29e = _6f8bd16d9d0c()

    _42776effcee3 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="app.random_seed", _609c183e299a=_9e04b2195062, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Seed for reproducibility under app.random_seed"
    )
    _03866ab7b477.random._6e1d9ae2d29c(_42776effcee3)
    random._6e1d9ae2d29c(_42776effcee3)
    _9b0b3ae80fe8._fa7740237961(_42776effcee3, _263c007b4120=_af8be009581c)
    _1f3bb723746d._9b9ed0b323ea(_42776effcee3)
    if _1f3bb723746d._21312ccc7e8a._ed62085e1921():
        _1f3bb723746d._21312ccc7e8a._e3efc9e2895e(_42776effcee3)

    _363d3e3be5eb = 0
    if _1f3bb723746d._21312ccc7e8a._ed62085e1921():
        _61893e072d1a = _9e04b2195062(os._4f4a500d2129._0777997c1941('RANK', '0'))
        _2c23a9002b96 = _9e04b2195062(os._4f4a500d2129._0777997c1941('WORLD_SIZE', '1'))
        try:
            if not _1f3bb723746d._80db5e63d78e._52b5dcadb6d3():
                _1f3bb723746d._80db5e63d78e._fb6d479946c2(
                    _63d9e8588fe7=_be9ea9b6011f._63d9e8588fe7, _363d3e3be5eb=_61893e072d1a, _2c23a9002b96=_2c23a9002b96,
                    _c05cc4de6a09=_f9e899f9596a(_a9097d1ea506=600)
                )
        except _cad8a2d9e106:
            pass
    if _1f3bb723746d._80db5e63d78e._52b5dcadb6d3():
        try:
            _363d3e3be5eb = _1f3bb723746d._80db5e63d78e._1e77f049a0a8()
        except _cad8a2d9e106:
            _363d3e3be5eb = _03d5c0714c8f(_be9ea9b6011f, "local_rank", 0)

    _44de7b50bc20 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="app.model_config_name", _609c183e299a=_faf51797fd8f, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Model config name under app.model_config_name"
    )
    _9f21449bf831 = f"metrics/{_44de7b50bc20}"
    os._8c1f3515c897(_9f21449bf831, _9ea4bbe58511=_af8be009581c)

    _efd562c7f1fc = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.pretrained_embedding", _609c183e299a=_faf51797fd8f, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Pretrained embedding model name under run_config.pretrained_embedding"
    )
    _0dc1e71c3d8c = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="app.pretrained_embeddings_dir", _609c183e299a=_faf51797fd8f, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Directory where pretrained embeddings are stored under app.pretrained_embeddings_dir"
    )

    _32e5c234756d = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.pretrained_embedding_overwrite_old", _609c183e299a=_eaa883b156ff, _afc9d5dd322b=_73b5957789b8,
        _9cac15cf20c9="Whether to overwrite existing pretrained embedding folder if exists"
    )

    _465a476c74a3 = _73b5957789b8
    _bf125c07e879 = _3602ae0a1562
    if _28c4072e08ce:
        try:
            _bf125c07e879 = _55f5dfe1be1d(
                _dab6b8f0c763=_af8be009581c,
                _1e01b12a45c6=_532a52045e29(),
                _5eabff28b610=_af8be009581c,
                _d07cb4887ef9="nf4",
            )
            _465a476c74a3 = _af8be009581c
        except _cad8a2d9e106:
            _bf125c07e879 = _3602ae0a1562

    _2acc6a33c219 = os._9b766b11afd4._ffded9247f61(
        _0dc1e71c3d8c,
        _efd562c7f1fc + ("_quantized" if _28c4072e08ce else "_fp32")
    )

    _e3f5291f8a18._a036599a24b3(_2acc6a33c219, _5ee74144c85f=_32e5c234756d)
    if _e3f5291f8a18._9dc39fd3025b(_2acc6a33c219):
        _a25a2a9b0941._8added52041d(f"Downloading pretrained embedding {_efd562c7f1fc}")
        try:
            from _55c4c8fea044 import _83cf79be8d84
            _2f8df2dec277 = _83cf79be8d84()
            _5b6a05bdb5f7 = _2f8df2dec277._5b6a05bdb5f7(_efd562c7f1fc)
            _6c6391d4326b = _03d5c0714c8f(_5b6a05bdb5f7, "sha", _3602ae0a1562) or _3602ae0a1562
        except _cad8a2d9e106:
            _6c6391d4326b = _3602ae0a1562
        if "llama" in _efd562c7f1fc._15c33171e503():
            from _ce7846c69b3c import _ef169072288a, _cf15e2a8a5e2
            _d2ecac7a86d6 = _ef169072288a._148ee9c91dfd(
                _efd562c7f1fc, _6c6391d4326b=_6c6391d4326b,
                _29a451cccd78=_bf125c07e879 if (_28c4072e08ce and _bf125c07e879) else _3602ae0a1562
            )
            _41c207f08752 = _cf15e2a8a5e2._148ee9c91dfd(_efd562c7f1fc, _6c6391d4326b=_6c6391d4326b, _7be308efe7d4=_73b5957789b8)
            _78dff1f518aa = _af8be009581c
        else:
            from _ce7846c69b3c import _af0793c8f0fb, _cf15e2a8a5e2
            _d2ecac7a86d6 = _af0793c8f0fb._148ee9c91dfd(_efd562c7f1fc, _6c6391d4326b=_6c6391d4326b)
            _41c207f08752 = _cf15e2a8a5e2._148ee9c91dfd(_efd562c7f1fc, _6c6391d4326b=_6c6391d4326b)
            _78dff1f518aa = _73b5957789b8
        try:
            _d2ecac7a86d6._d608c240e162(_2acc6a33c219)
            _41c207f08752._d608c240e162(_2acc6a33c219)
        except _cad8a2d9e106:
            _a25a2a9b0941._a1ba2a335090("Saving pretrained embedding locally failed; continuing.")
    else:
        _a25a2a9b0941._8added52041d(f"Loading pretrained embedding from {_2acc6a33c219}")
        if "llama" in _efd562c7f1fc._15c33171e503():
            from _ce7846c69b3c import _ef169072288a, _cf15e2a8a5e2
            _d2ecac7a86d6 = _ef169072288a._148ee9c91dfd(
                _2acc6a33c219,
                _29a451cccd78=_bf125c07e879 if (_28c4072e08ce and _bf125c07e879) else _3602ae0a1562
            )
            _41c207f08752 = _cf15e2a8a5e2._148ee9c91dfd(_2acc6a33c219, _7be308efe7d4=_73b5957789b8)
            _78dff1f518aa = _af8be009581c
        else:
            from _ce7846c69b3c import _af0793c8f0fb, _cf15e2a8a5e2
            _d2ecac7a86d6 = _af0793c8f0fb._148ee9c91dfd(_2acc6a33c219)
            _41c207f08752 = _cf15e2a8a5e2._148ee9c91dfd(_2acc6a33c219)
            _78dff1f518aa = _73b5957789b8

    _b256814cce7e = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.max_seq_len", _609c183e299a=_9e04b2195062, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Maximum sequence length for training"
    )
    _e78724132531 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.batch_size", _609c183e299a=_9e04b2195062, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Batch size for training"
    )
    _58793baf9c6d = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.data_sample_share", _609c183e299a=_80ca58168535, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Proportion of dataset used for sampling"
    )
    _0cb5f30ea5eb = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.optimizer", _609c183e299a=_faf51797fd8f, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Optimizer type under run_config.optimizer"
    )
    _364cd22401d6 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.learning_rate", _609c183e299a=_80ca58168535, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Learning rate for optimizer"
    )
    _76f4569e224a = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.num_backbone_model_units_unfrozen", _609c183e299a=_9e04b2195062, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Number of backbone model units unfrozen during training"
    )
    _ae603281b247 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.loss_type", _609c183e299a=_faf51797fd8f, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Loss function type under run_config.loss_type"
    )
    _4b83c3979987 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.num_fc_layers_in_classifier_head", _609c183e299a=_9e04b2195062, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Number of FC layers in classifier head"
    )
    _23da6da19a01 = 'parametric_relu'
    _38e9301324ef = _af8be009581c
    _7aac277e8360 = _73b5957789b8 if _76f4569e224a == 0 else _af8be009581c

    _ffee7de77958: _353cc51c9415[_faf51797fd8f, _0a4cc20b0a20] = {
        "device_dict": _ae3cda2486de(),
        "pretrained_embedding_model": _d2ecac7a86d6,
        "optimizer": _0cb5f30ea5eb,
        "num_backbone_model_units_unfrozen": _76f4569e224a,
        "loss_type": _ae603281b247,
        "lr": _364cd22401d6,
        "is_train": _af8be009581c,
        "tokenizer": _41c207f08752,
        "random_seed": _42776effcee3,
        "num_fc_layers": _4b83c3979987,
        "activation_function_for_layer": _23da6da19a01,
        "add_dropout_after_embedding": _38e9301324ef,
    }
    _ffee7de77958._d3cd627d1087({"pretrained_model_embedding_name": _efd562c7f1fc})

    _fa8ce9e7039c = os._9b766b11afd4._ffded9247f61(_fb9a6f1ee3c6._4392f422717c._5e7eaf057a17, _fb9a6f1ee3c6._e1cc19657d3a._39e410f8e31d._5e7eaf057a17)
    _49f18b1f6c2d = os._9b766b11afd4._ffded9247f61(_fb9a6f1ee3c6._4392f422717c._5e7eaf057a17, _fb9a6f1ee3c6._e1cc19657d3a._1e3d1109f673._5e7eaf057a17)
    _707fa57a7e41 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="dataset.files_have_header", _609c183e299a=_eaa883b156ff, _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Whether dataset files have header"
    )
    _740316e37756 = f"config/{_44de7b50bc20}/finetune/classes_config.json"
    _e3f5291f8a18._a036599a24b3(os._9b766b11afd4._21689c532e38(_740316e37756))

    _cb42f6ac4b36 = _f5c7731210f0(
        _5e7eaf057a17=_fa8ce9e7039c, _707fa57a7e41=_707fa57a7e41, _a25a2a9b0941=_a25a2a9b0941,
        _41c207f08752=_41c207f08752, _099ef0e6aded=_b256814cce7e,
        _740316e37756=_740316e37756, _9ed12da7f674=_af8be009581c, _89088e69e85c=_73b5957789b8,
        _42776effcee3=_42776effcee3, _91897968512c=_58793baf9c6d,
        _8f966e0a34cf=_be9ea9b6011f._6966aafd95f5, _78dff1f518aa=_78dff1f518aa, _ec4368e979cf=_3602ae0a1562,
    )
    _184330ab0b8a = _f5c7731210f0(
        _5e7eaf057a17=_49f18b1f6c2d, _707fa57a7e41=_707fa57a7e41, _a25a2a9b0941=_a25a2a9b0941,
        _41c207f08752=_41c207f08752, _099ef0e6aded=_b256814cce7e,
        _740316e37756=_740316e37756, _9ed12da7f674=_73b5957789b8, _89088e69e85c=_73b5957789b8,
        _42776effcee3=_42776effcee3, _91897968512c=_58793baf9c6d,
        _8f966e0a34cf=_be9ea9b6011f._6966aafd95f5, _78dff1f518aa=_78dff1f518aa, _ec4368e979cf=_3602ae0a1562,
    )

    _470358aeec5a = _cb42f6ac4b36._43b63f933abe()
    _def6d893cbfc = [_cb42f6ac4b36._f19f4b625d68(_f61add9cc6a0) for _f61add9cc6a0 in _cb42f6ac4b36._328d40a90907._af9077ef1b82()]
    _94fc7dc04f2c = _cb42f6ac4b36._94fc7dc04f2c
    _82b9611b7e09 = {}
    for _3f1ce10c5dd2, (_fa87ef3a8cc4, _571abfb4ee77) in _333217989d30(_7131bc82dad6(_def6d893cbfc, _94fc7dc04f2c)):
        _0c2ad283f57b = _41c207f08752(_fa87ef3a8cc4, _fa6a3df680f2=_73b5957789b8)["input_ids"] if _78dff1f518aa else [_3f1ce10c5dd2]
        if _0c2ad283f57b:
            _82b9611b7e09[_fa87ef3a8cc4] = [_0c2ad283f57b, _571abfb4ee77]
    _ffee7de77958._d3cd627d1087({"class_weights": _82b9611b7e09, "class_names": _def6d893cbfc})

    if "llama" in _efd562c7f1fc and _78dff1f518aa:
        _0334ebd21161 = _e719a171bcdc(**_ffee7de77958)
    else:
        _0334ebd21161 = _65bec2ef17cc(**_ffee7de77958)

    _3a1c49b66699 = _bc33bd8cb4d0(
        _fb9a6f1ee3c6=_fb9a6f1ee3c6,
        _d651cea59c2f="operation_mode",
        _609c183e299a=_faf51797fd8f,
        _afc9d5dd322b=_af8be009581c,
        _9cac15cf20c9="Specifies whether the current run is a 'model_train' or 'model_finetune' operation."
    )

    _139882297695 = _3602ae0a1562
    if _3a1c49b66699 == "model_finetune":
        _139882297695 = _bc33bd8cb4d0(
            _fb9a6f1ee3c6=_fb9a6f1ee3c6, _d651cea59c2f="run_config.finetuned_model_path", _609c183e299a=_faf51797fd8f, _afc9d5dd322b=_73b5957789b8,
            _9cac15cf20c9="Optional path to pretrained model checkpoint for finetuning"
        )
        if _139882297695:
            _e1bfb05e8002(_0334ebd21161, _139882297695, _7b5ea2aa6245="cpu")
            _a25a2a9b0941._8added52041d(f"Loaded finetuned model from {_139882297695}")

    _6a258b97bc20 = []
    if _7aac277e8360:
        _c6571b5d2771 = lambda _b3d3322632a6: _cb90ed232e06(_b3d3322632a6, "weight") and _06a8de79a025(_b3d3322632a6._571abfb4ee77, _1f3bb723746d._0b442e8f767c) and _b3d3322632a6._571abfb4ee77._3e82aa5a2fe3() > 64
        _4553d7a90a78 = _0334ebd21161._a2e899e2abd9
        _43b885d8c621 = _bdf995d8770d(_4553d7a90a78, _c6571b5d2771=_c6571b5d2771, _5311ff4ba8f1=_3602ae0a1562, _8f52a04cb258=_3602ae0a1562)
        try:
            _76f562268888 = _7ee3fa12c51c(_3602ae0a1562, _43b885d8c621, _3602ae0a1562)
        except _cad8a2d9e106:
            from _7b4827fbe7d9 import _6eab4f806534, _edab8b44a77f as _c519166b6c15
            _76f562268888 = _6eab4f806534(
                _9628b3fa6bbe=8, _8a10f109dca3=32, _a643b55c6de6=0.1,
                _43b885d8c621=_d623af356000(_43b885d8c621._af9077ef1b82()) if _43b885d8c621 else ["q_proj", "v_proj", "k_proj", "o_proj"],
                _5dd6b1444b81=_c519166b6c15._0096ce51fd53 if _78dff1f518aa else _c519166b6c15._8cd3094b078a
            )
        _4553d7a90a78 = _348445463b86(_4553d7a90a78, _76f562268888)
        for _d651cea59c2f, _7e297135d63d in _0334ebd21161._bea5bc42abe6():
            if not _7e297135d63d._f65f03d5f906:
                _7e297135d63d = _7e297135d63d._db3c2349a811()
            if "encoder" in _d651cea59c2f and "lora" not in _d651cea59c2f:
                _7e297135d63d._b284377110e6 = _73b5957789b8
            elif "embedding" in _d651cea59c2f:
                _7e297135d63d._b284377110e6 = "lora" in _d651cea59c2f
        _a25a2a9b0941._8added52041d(f"Applied PEFT/LoRA config. Trainable parameters: {_93dc403b5f09(_4553d7a90a78)}")

    try:
        _3d18b1ab8d97 = _1f3bb723746d._80db5e63d78e._1e77f049a0a8() if _1f3bb723746d._21312ccc7e8a._ed62085e1921() and _1f3bb723746d._80db5e63d78e._52b5dcadb6d3() else -1
    except _cad8a2d9e106:
        _3d18b1ab8d97 = -1
    if _2334006248f0._c673a6919bc0() is _73b5957789b8:
        if _1f3bb723746d._21312ccc7e8a._ed62085e1921():
            _0334ebd21161 = _0334ebd21161._bf2eae96b1a5(_609c183e299a=_1f3bb723746d._2d81c2040d5a, _fea4c325b873=f"cuda:{_3d18b1ab8d97}")
        else:
            _0334ebd21161 = _0334ebd21161._bf2eae96b1a5(_609c183e299a=_1f3bb723746d._2d81c2040d5a, _fea4c325b873="cpu")

    _c2a1037e37ea = 'gpu' if _1f3bb723746d._21312ccc7e8a._ed62085e1921() else 'cpu'
    _71c1639dd7c4 = _aa349d24da01._16c5da00be39(_14bd07ccf155=2)
    _a17b7c9e6fe6 = os._9b766b11afd4._ffded9247f61(_fb9a6f1ee3c6._4392f422717c._75903aa4d8a9, _44de7b50bc20, "finetune")
    os._8c1f3515c897(_a17b7c9e6fe6, _9ea4bbe58511=_af8be009581c)
    _c4bd542abe32 = _aa349d24da01._8e0ffa806a28(_f2a93fe30a20=_a17b7c9e6fe6, _da4662129eb1="intermediate",
        _11b24075c6e4=1, _9a1cfc5bdc05=1000, _c5a42dfe2786=_73b5957789b8)
    _75698b8590ca = _aa349d24da01._8e0ffa806a28(_f2a93fe30a20=_a17b7c9e6fe6, _da4662129eb1="last", _11b24075c6e4=1,
        _c5a42dfe2786=_af8be009581c, _05742518ae02="val_loss", _6c073bde4d00="min")
    _7a48b9b488e9 = _aa349d24da01._ce0fd2c43d35(_05742518ae02="val_accuracy", _c62a0ff6f40f=3, _6c073bde4d00="max", _1ff3d0c56ccb=_af8be009581c)
    _e260e07a8531 = _aa349d24da01._cc6d7f6e5ab1(_3d6042822ba8='step')

    for _d651cea59c2f, _b5b11deb9952 in _0334ebd21161._bea5bc42abe6():
        if not _b5b11deb9952._b284377110e6:
            _6a258b97bc20._7d3a1be429e9(_b5b11deb9952)
    _2a49f2b58ff5 = _7e17d6b3069a(_648f8193e9e5=_6a258b97bc20) if _c2a1037e37ea == "gpu" else "auto"
    _db42c158e329 = _be9ea9b6011f._db42c158e329

    _e0d795392c82 = _769d5265cf60(
        _7fb0dbff7f66=_c2a1037e37ea, _043e26716fcb=_fb0fcd86587e(_c2a1037e37ea),
        _db42c158e329=_db42c158e329, _f3b370981d85=_2a49f2b58ff5 if _c2a1037e37ea == "gpu" else "auto",
        _f699b00289d8=_fb9a6f1ee3c6._0334ebd21161._f699b00289d8, _8f9f1d75847b=_73b5957789b8, _912b48bd90f8=_af8be009581c,
        _dcf5d2461b5e=_af8be009581c, _eb0b6b732ea0=_73b5957789b8,
        _7b795f0a7a3a=_fb9a6f1ee3c6._1fd299b7e8a1._7b795f0a7a3a,
        _415745d38874=_fb9a6f1ee3c6._1fd299b7e8a1._b6e2ec8b6de8,
        _aa349d24da01=[_c4bd542abe32, _75698b8590ca, _7a48b9b488e9, _e260e07a8531],
    )

    _66d2818f98e0 = _50b740cdf4fa(
        _cb42f6ac4b36=_cb42f6ac4b36, _184330ab0b8a=_184330ab0b8a,
        _e0a08fccc8df=_af8be009581c, _4f7cab370b9d=_41c207f08752,
        _bbfe35faef22=_e78724132531, _8f966e0a34cf=_be9ea9b6011f._6966aafd95f5,
        _78dff1f518aa=_78dff1f518aa, _42776effcee3=_42776effcee3
    )

    _5174bd7298f9 = os._9b766b11afd4._ffded9247f61(_a17b7c9e6fe6, "intermediate.ckpt")
    if os._9b766b11afd4._8e8ae44441eb(_5174bd7298f9):
        _e0d795392c82._21ba8bee8dba(_0334ebd21161, _131cc4665f73=_66d2818f98e0, _2b5b3b6fefef=_5174bd7298f9)
    else:
        _e0d795392c82._21ba8bee8dba(_0334ebd21161, _131cc4665f73=_66d2818f98e0)

    if _1f3bb723746d._80db5e63d78e._52b5dcadb6d3():
        _1f3bb723746d._80db5e63d78e._bdbf03c275e9()
    _05264338685d = _75698b8590ca._79da0470c75d
    if _05264338685d:
        _a25a2a9b0941._8added52041d(f"Best checkpoint saved at {_05264338685d}")
    try:
        from _7b4827fbe7d9 import _ec67391ba023
        if _cb90ed232e06(_0334ebd21161, 'peft_config') or _06a8de79a025(_0334ebd21161, _ec67391ba023):
            _0334ebd21161 = _0334ebd21161._4d91a0f0649b()
    except _cad8a2d9e106:
        pass
    if _465a476c74a3:
        _0334ebd21161 = _0892281f4866(_0334ebd21161)
        _0334ebd21161 = _0334ebd21161._80ca58168535()
    _9ef3e7f692b6 = "saved_models"
    os._8c1f3515c897(_9ef3e7f692b6, _9ea4bbe58511=_af8be009581c)
    _2ecc1cf1ab82 = os._9b766b11afd4._ffded9247f61(_9ef3e7f692b6, "finetuned_model.pt")
    _46e07e732c8c = _0334ebd21161._46e07e732c8c()
    _1f3bb723746d._2e7e38a12e3d(_46e07e732c8c, _2ecc1cf1ab82)
    _a25a2a9b0941._8added52041d(f"Saved finetuned state_dict to {_2ecc1cf1ab82}")
    _a25a2a9b0941._8added52041d("Finetuning completed successfully.")


def _fed17eed00b9():
    _bfde7503bac6 = _7cec2d5b3f83._2bb70d4d4e91(_5fede559b0a0='Fine-tune a language identification model (single run)')
    _bfde7503bac6._4b7fedaa0dac('--config_file_path', _9cd4635926bb=_faf51797fd8f, _afc9d5dd322b=_af8be009581c)
    _bfde7503bac6._4b7fedaa0dac('--num_nodes', _9cd4635926bb=_9e04b2195062, _744128fe4a2d=1)
    _bfde7503bac6._4b7fedaa0dac('--cpu_cores', _9cd4635926bb=_9e04b2195062, _744128fe4a2d=1)
    _bfde7503bac6._4b7fedaa0dac('--local-rank', _9cd4635926bb=_9e04b2195062)
    _bfde7503bac6._4b7fedaa0dac('--backend', _9cd4635926bb=_faf51797fd8f, _744128fe4a2d="gloo", _173e5644662c=['gloo', 'mpi', 'nccl'])
    _bfde7503bac6._4b7fedaa0dac('--run_timestamp', _9cd4635926bb=_80ca58168535, _744128fe4a2d=_3602ae0a1562)
    _be9ea9b6011f = _bfde7503bac6._15d2dcd20c60()
    if _be9ea9b6011f._e7b10484c3d2 is _3602ae0a1562:
        _be9ea9b6011f._e7b10484c3d2 = time.time()
    _939d25d7ef2f(_be9ea9b6011f)


if __name__ == "__main__":
    _b6ea3cc5181f()
