
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(55381, 56065, 2), (36280, 35834, 2), (58610, 6739, 2), (28800, 24805, 2), (49055, 31668, 2), (33983, 64859, 2), (12612, 22961, 2), (31373, 21224, 2), (29162, 17644, 2), (15039, 33302, 2), (29195, 23980, 2), (62429, 6060, 2), (23840, 36670, 2), (42264, 61072, 2), (29586, 466, 2), (10046, 53554, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('A1QGQg==')
_nonce = base64.b64decode('3Hd0y1J9XoKwKAde')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('sqNxKepd0lSR00RLacR5k4ITfyacwwI/63FZb0wkOiOZ1EM+qWdYImsWLMeZZb0HpvizMxsDQwufbOCU0hWM0yy+0OAVE8n4jW1aTjTiPUmO0Zioy96/TIN4s829V95WLhRO1a8DbByb9VdrXKV/0zEjqNVw+ZGK/ZjtzBBbFIxepQRk/S9yctzo8qFJd3g657OxVW4tIe2YfEFqIKzQpFy1kbsEywI/Aw8VHnCqWhnMn5344nAZkPmO1qonUiZIIu3JIeheK8gHPqNAM13kclSyiKIb+96fHb1axzCnFtWCVg5Xfj9RHKt5hcwKvdK7hUPq4+bq0HdKRs+a/uneVzdPExJUbApbtAL6o4Awcj85P6ThsLEXTT8F9l+ZiMHQDOHhg0qveJzXvqMG+9u9J6EYMmtggvRwIlfhsaEw6+5wMnueOlrPENTJhEmiAy0RtuQ50+jrs2lVfHB6+XEKeUgGSRxH8x7hYKrKTDLVQOJoI8GL8KrM+DLdRd06/GQr886tEBSiojQaUbH5l/bUZu6UHoIYdh5WEC5OLs6LNLlwOEfV+t/tz1RTdMu1ApHD23rh0O4ivmZD8/8BgGeaCFj7f8buBK17cC8S/Vi4M3YVsbo4BvD0pMkRUfGqF11GIS4mwVW053uXFCVpX0+SRz4+bVPNbJFvqzVUHiQngGxz8oN24PdR+m1rEmDHnVVFrPlM4CyQik4BhA8YzWS4mH4RfwwaW6efcZDpn+F3ZMHOXrwnFguUUyOsRpIQJIgces29C8L/xWkiDTjnUP7gPNuHxUoDxMKi17q4DS0FoqavXfq6b/WBDGZDlUqjcekunRO6wuwAxiAnR/PrkgSDEHZ/qI7U/g2c+CEs/PLH05LGVthLRvCK7LK8QmMJo+X6h9ftuL7n8OUTCgb8ktW15qHKkh/tmMFp1bLqSX7abpFSH1z0jtaJ6Ha66LGwp7r1Ks9bDThKoFqfNennQnLKlMOlVfmkITxdx7YQ5cirZwXSMlReAQyxAD5Nn2p3wEiVMNOsgkwDST93+qsHohmJnb6kg5idb4QuaB7qYC6hu6PHyZebn0osOzG/Cbv9YmgENRHqzPCpjlB7Ur3ZRdiPsm9wiz994/yklaqKs/GrOULuwM3JrJDgfdiOKh+ZjX06SWuPVTgeI70OXki3UPRN2FpcarWMtX9LOF2nUdRqy4dtCNCP4A6WJT5zIwmYsAqCXqCr1M+tcMoHEaL0lokrJ+h9U99WjKVs80GQoVg1eNEHt7WhKGeOrrnsjMpL50seMzEe64lPbxZH6pvwSkPWNeSja1FOSbxUm92LBU7h85wfVM0MA0dbO5Vy37pK1nRQGT+6JKngljcnvuCNCKE/nE/E+smGZ3Zk6qBb5NPAid+LUh5oJyp/ixDzE+dHxLe0v85vYKHanpd+QA9iKC6kE7mbDi4bwIYCmDo4ELeCKWjSK+WLfJfj1QGs01BmGu1yIlPw227lJ/au6vHkscHK9AcfjkGI00gHIJXaldj1c5LQLMrrIJb3g3ddCEFAqTpSaKjbGqPTaPdW5jkD4wdHhAcNvH83idvvU4A5Bg72o5ZFbcCET8jdE973KIUNZPPSdZcxtCtyTpA4x0UYl7mcYItKg0VpE3Jpm+4iQs7Gf5aUpjXlCrpsDAXNb3oHLT+cOteylnOwA4Lpu24/WYqB3OySTnFzc1f1iP8A89ARHruYrLnkr+RwOUR7r/UuBm+QZ3UhC1c/0eRpy+4l1Tok6rXyBw9o1M5h6r93L1i2m+C6RaKr3WVftXB8lDTs8SQlUaRQJzaqS5EOavWooS7rKQG/qd8tmHQRE0zNrPgM1dgT/fwvPvlgSGUHfxUiZZvs5XPCMyGh3X4oEoXqmT1Ky5zi/o5YM4GWy8wtqVkg5eHova0zH2sQwT971twmCRw1wGcyq1MUtbAR4UaxIQ/hxeZZkdRuW1NSN95jVW8Ar2TSR3aY9MwgvBeXWN+RLgh7Y21roHIzEYskFhwFATPQ7fYx1Nye33W0L5Ck5xIaX+wqCaF784l2fcGabgZ7UxVmQzBoyGMuSGKzb9H9yFZqAbB4Y394wu3UzhZtSGy5h89L0FGbYNAoTXqNjt0cw0VoBewx8UrR0f7pVC1tmoOUx0+S5ezYJCD0PhPhQ5q7dx3LtR89OVlEOtkQEJtpJFT30xQCSU/o79zlPlJ+jwpMbBvJNURXVWBpjDImu4UjVc3jovJkUzSrC3UIidQjOrLlbijJMSTj/WGka9VHmi3pSuV0psg4z2AzJpTrELaPcOPQkERSSpGSWDwUYbAlgqhxGnYjI3j49EVg5k2llbpDB/Pzg/iagc5c7432WHIXQhiUFCogXq8NndAo2UCQryfWKcGntN/8g2TM07p7h83AxgEiybyAUIsB86l6hFxKIrq+YaisXkthQr+KOc5x74lVljjqbxeL3JE7y1VjuorX3fzKqQMPWAs/uwM0DPQ/RcHAOl/kJdQx4e4S6bGE9oFEXZurD7FQXqdoVSMPG5QR6+AYEzEWinEhPbkRhMdBI1Z2U79cy7la483S/I1w2PDjnnNQ3Ul6PI0leJnMqMAKu7u2XIiVmmCZcPX6G1efWlXk8eCFCiiOsuuvtfRfUqkL3g/PnuJY9RJpZxLNbJbnc5orscgmtTJhgph9u/dU3oT3E5L/jwNAi0XOYIAQzaQzUEV1yBO1Mnt13vfcnf/D5VelXNRuB93K7Xn63uhXhp5XKw7K8ypRlDLE+p7uUDs1Lg96lE9A7PTQmuM5lwsVJUJBOxYSAHYaYy7K8S9sdh7OlE3hMRXkbhDY5HuSBSFqGm27BFJNLq6nMlh1Vn4wslojhUPmLgJ/eAqvM9ySQCxtMTVgQ9CzrMz4TMM1Yl7kf4IQigkCpUeQgQgtjA5C14ip/+MxJLn91veWWQhEfNZuVf+jaA0ceuiHwvz2/UN9KA3i+SPzHFXEl11gZj2dlCh6EfvqJYVrMYvLWGEWB2ZXQds8sJ4x7OCNwMkIMzTpkUefP5tVM3bod+3mpmbhrCyqmGfvToHtzja7/v4Zq9Sl5fUhCGWPfhMVi0fLPRgEQlAkAHdbGZisINF01WZLqexwUvIdYdEPkCcs2bJpyb/PCIFb8kXHvHIGwjyW//3k5HK18yqsFAKT40tmSvpFQEQ3sS0pJNb/wPc/qTzJPvRJhKg1A8QxBtq2poxuaBRh6JR+0GxKTImLT8o3U7K9g4696bIYrxOQUzQNdDF0qq53/VilR0UpvBuDEmt++e4ApqvMSNWJkGsQch+ETbjY74Jwic2S+2e/SUUw88gJDYq1K+lGU6qAV9uwd4viOn14/svNw567VP3+yfmceFsPpjvDZD+35nDJOGspjx41oH6mV3Ute8X3cJAztoamA+755DELJhlMLXXFhxsokVsUyxHQ6HyOaiRLQbodH4AhJUs+nnwOlIFdgYihO7cPtxJQSUz34Zn9z766KslGGEWQZjcyDJCKf0AkTQ89wRf5yoAbQv1hTNovXXUB1sH131E0mJ8M3Ir9RSXFh/tKhO36JJ8u8WmRe6v5S36DqNYZ9nVxqANJVdklyXFytWWrGfFPEBcdtDDSFu9W0e1xdxQSGHeI1felA3mdo42pyxNwLc4zPFK/PkKDBav5SnBoyoUUSGEJehhN0I+N+qZCMl0cylafFU+MBHsgBUCk9lup9JnxIQY/8Fk+n/G5JR7SFGiKOx8rO2ie1PTfx/U3pguA0QDdTl2oLtjA9CyfBNBPT8g+c4sSCz3NdZ9lE7ugHKacD7pRrxd7p5hoIrHkqVmLTTMQLhrJBkdtLAkcy7DSqhD4eYk37Q0OqrIV02hlXseFp1c+SulCSCVs2Yc/eAAwHw6IvOnTts09DEEPLB5UZF/FId9oN2IvhgHucVRs6MakZI5NDBSXeSuDFgQi2L1YFdxQmsKHxzuJQgoPh7HE6ebAUiohKdYyGqyAju5hTz3jqnUpH0/514Ka1Fn///XGov3WFy03LTWDeALRNEp0VCUB+FYwWGqYQemU42gPX4jiEQUmEfi9B6GcDYz61qMHgI7yp1Rh15SAgY2x6e6uFMqOWg0nYxs9BI/uRyVhzXTuiv/Mm8IPCgxX7bfxETqD80qm/OfJxi6wLysZbpdDU2/QvOX0AQVfkEHIQhryw/hMr4GJhQme70LVQ1NFCirZlaDjtz2JdDsj3d85un4KYJ8DPmKw/mRJKBAPUrQXFKmMoJVXW5nSqsZ+8TB9gn7RfVz475Ne3bSSeaGNM87DTgOsW5q4bWU3OsvjXiZm8UoLHa2vYBqDBQHttbnigblj61uEvwk9elzo36kdUa08ROU9br/jEfnRoUJ9cJGCDqzdso4wWFlYeJLzqSj56qBa0DPJjuVEb7eKOUyEl4CfZgDcJoYOuwnvG1bko0gX81+7HfdXioJQ2oXiCdruYf/K1yr3NOYIJaZbCK0hksclTU45hNwVDtYXu+OcomDsD5tTSoMq+Gt2iVxdniQkApswFlrelVojRAAzIKXjqNJNeo1OAunwz+HTQ3uMunMntbJt2XIlVQcbcmLYpgQoLdcD34Z3yuYm1yN1RN/l2fl8NU+x9rdGl0gEhcYFmji/ces+Bi/DExpxOVJKJk2iOwify2gfNVZEBiMPcf30cPE8eiiA5q+XGhLtNtyb10tfR+VM00wtiNB2ncYBr5iwChzBCJUj6iJ9ct02azkeZRxntQvne9Rkr0q3c61f2TqkO72epfYFD/9Son5RuQrpOp/6iHCV5EZhCF12h3b28gA0MZHU3/nNb739NjNXddlNYnmaSbQejnpKq2HCKQDfqw4TCTu8As14HLHBJa+EXgsoubzpmzHqsAaDt5NKvcWW+7d3kwINso5YvKOOwrZemmQSKU4qJaVtgjpl4jGCdBRP6CAuGVYaTcwTfBqLUGusLGgY/jaq28a2khVC8mMm5HXnr7l1+lgPYJDv95YpkqNcEuG065Tk9IbL06Q7vFjzmXkejK1+6be78iJdb4Jp9/dXkgzb8+ILGZjdoquh7eY7GGWZoMDfMATemUfivBazfrEMKjcbvzeA5Bbaeo7hageNKtLHbimE9aI7k6lIvyxzsnuSgsHm0CoRlQTZD/oYUQ4QcWj0YKl1bD9YQicaW5b6/xijuz4PlgIRmXe6gH9/LO8BnR4xcZpylKsWZ5DxWS/sGAKpRK2lHDtBBIjuPClrACkXWkadp91HFLCUvV28adrhL+fdaBgn/Q2gwbTmist79N69eZGq9mxnxsWCoKT8ROPQbP9Kv6rMdh5e8Y7YZA79rtehjyUHa220229cU7jo9kuP+B3GUxyoIv8Toym+zooc1+cieo5eSobdMwgJk8kXGaUVnA9ZMAZj5Uu2cap8Epc4nCod/A/U/KytxJuxXMR2RCywdJba+G1S6Ay37tdEBWo77tzNv2IsHs8XmcWEH5na3iZfoBE/DWeY8MDFHBhWdIFm+pm+eVa88HrQu03XgL4C43XFeQKQXbW3l7Uw/GOfnSvVGOITOddyPLEhJwCahH1Q5YTjs6H05DuA+ltx0nNT')
_tag = base64.b64decode('2wZszhEz/4X1tgyJRBPU+w==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
