#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(32783, 44599, 2), (10222, 16526, 2), (12935, 28067, 2), (39948, 60400, 2), (252, 35732, 2), (8507, 30657, 2), (15778, 62307, 2), (49616, 9720, 2), (50556, 41910, 2), (6321, 61150, 2), (4936, 38231, 2), (47401, 22644, 2), (44691, 32337, 2), (10368, 81, 2), (61381, 26026, 2), (8698, 8903, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('LjhnYA==')
_nonce = base64.b64decode('olxdy7Idg52RVTbL')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('DU/jpdwJHd9S0cbRJeNbWaUgL8FujcaSKTWepUIwhkGDqIgsIZTniypEgmvbArpnAsGas48kSKjBa8YY+4DtuXb8Ng1FatXhNvdi8DoOx69MqY6O+w+zJOLfrs/aAGXrP0CVDo0Ff9gTw6vKW5cSTStCKO+WDQqb/t4hBBjrklH9RknM5JAw6ntiDxy+ycJWtVsIMreFyjnZaEoMRoZOx7QcDzsY+7mdgcE8Rltu3arVfW4sA1r/NcGVqMi/WM4ZJvaD3h/vzsobCpGYVq3yu+o8j87p42zCzzP23PuexqAWnVIHWX0DVL1536qCPMX5Tp0RnaylWaHUnng1XJPI8f6KIoRSzkKLiayJS8u/iIjs38yQOJaZbnhKbZbWADDr3GeECbJWdfHON2+YCzx2IeEvAHP81/YxJDNxleNAMpziZPp6w6SNOwlN5a9W3p7AuvaoNxmCO4FTAe0hzith2pPyN21mbDu8VB0vDPFWy+lRoP96EiWPjzoE3mahhhYO7+St5uNSMfKBsGgHooDDSBR38gGpob9I0flKglvSLukHh/G2jiXc6QvBpj+sBOhzCA8D1+cNio++2IK1q3mB5E0bmoICS9v+Vj+3qZ73aJ+A7Q6HBcDk8YhCZLMhFZgINfAx1WIqZ5L6I6eiOAu+zFCsUwga0LcOBZQiaSORrap/hC7eTaQIypGEKSRXmuEB7cL5QAfgMDWHFMT6t4Bjw34WzAK8M6Z2+VB3D2+csE6fR0pQVD5S7LipIq6FnH1ggunnaBHjeynjgpsJXNR/NLwFEWuPDrfs3ovQkqdShL/jI4B/d+WZl/jfKLSuDWE+oH+fWJI9vY5shvZNvHsSPeYt9EKPwVzzo959mm2N+FukLix4xegGHP7r/EFbzmVwKZA3Y+6DusaUM10wYJzpaUYqUMVz25wNdp7ZzH+lvkFQ5mQnkGKzEEYvtkFScHQfRYzGC0ohsQmo54YTQBGVrt3hxP5vAhVXyrmYI8b/u/NkuSQBdbbtx8S0GiZznudz/SwCSeMDo6PyddnbuvyHgZuU3WORS4Xa8wp/ev5H8zgqGNUbf8aUYGSQcAbpTis/qLMZ3IU2njC+MEOjj8IOGp8x+IN4JQ6iT5YUe+1P6zEKtXAEqfXq3oTwmVp4XfGctacDS5SjLXzw5zPP2Wx9H6nKg+ThXrwePD0CLUFa2eePnJyiymyGIPw6gLeuvjzLzV9zOIiGMsKJiwiUQeLfGSBejZr6xPwCr0KtRMoMxctueC0wBCAMPB0Ltks043aP0Eh4an8gyrWuR+QIq20fi2hVaxVSNHbFsMspmzjNP6iFsX0n4DCyKYkFwMivp5QAsXLVhIpdAO68aHIdL8nIQ+zDvWVwOBLf6d19+4UAb4Z93h9J04nZt7h6jfB5gxdKPiWFe5r+8wmmXxFg7lAYTghgd+J8yHfqGoTWWluEOKj+8PWfQ2allQLAQwiCK6JsnqZDzyf76JNEKM5HmJSYGkcwo1hVNpViMALWQqCTFV+Fl2F6HGBjjywxBTN75mor1B6GOWx9Jag03x+7Ga5aiHkWfIUlgGWJ2DgvGhgnk90ITYPGFtmHf6+Oct6ixkw+79eNR1wJx9rMgNvo1K+os1mOTzTTBIX/SHTzXW8lplKAkRScd7+v6qvX3jqzqhb622GQfuMKnS/FMRqrgj5GKyqdhEOulqSn4U0VFfYDUbCa9tZMK+E4aVQZMrNfUYMwVs3CTvQGTmF9KbWshRuAbO7b40EMQieEGErfAP0q4NkBIEDQvAPsasjosAM6x2RQrMru4wAuBViVIgdrQZJt9udN5ACVMeDIuDZZ0sA3Rrb6w8FiNP1QSOrx1JES+sHqB9BVSP5qgIqZgY/Qzoiel0BpOp/0BFInuaiX/OQAa0p0w1AQOKIug1GYT5Ru5i8wm/CnQj5IuFE84+XoImIrBxm/PguGJF3WQ1TKc7TQYVnrLjojZBmpdh5k05ex/HieS7UVEw4LBtnS/b8SJCPwLbPxzYvvfnhn+eRmjzJIZqIsFqqPIYd2JhECC2BCEqtz6j1mV+5mUgLLBIEbdy9HrGguytBQyPQLpCVByq0DmFHVpAR8+YZ4+KRDQMnHirn3cfXyX2fq8RXyiVfC5PFSSABRZmF0lH+eJ0J/47fhurXjA5BanOXTOj0nF0fI1JJbVgBAq904bPMzEEv3qowkGHE2/NfLwtXP5tdZDGAFWKF1hEWzwEpAnjTZMVVthm0PgDulG2jSWAUKIJtzN62Hn7Mojuq2T3tHbeXvGz+KnEzYdbLoPYr3woOGNXNdtG7+y9fcqKroqdX4dOEsgHkMT0U3s0ifP9+8FXZGRWi4z7Ww18++BDFZ+rhkYYklA3kKFXxu/2wwwe3PIqfGkUxRnmJYoeC19LRhpQYp6hAazan44qh0Dt1ltHksXX9cs6NlOwOjB5KpFJQlZHWwE4xf1iRacWH5adTT9sTzlpbaevxTIg2RsItOSeJ1sEWKQ2w5iaMKDJogrp8CiFSg+fOTjUxFK2amTr0qbTzfgwH+PcfdRloSnlmpBYA1yY1+gVXU+tw6QlIL3gsDcAIpmCsqsVrCw/ykuml7NMrYjY/Zav+8Lwv+On6gYVQSp+rNtMizCF5bUTpkY8yZdvPEiPRop3/xZJDu7vYzFIeXn1YYDFPBffUMrjJgNFauH+k+XGijLGW/4pWVYhUEuEICMNDuH5ebvtNHesulTxvCuMqoaHhszzb26Eqknyaj0PZNDWQP0d2wf85JwTFYaUDsK4CvUCf+tDXcatH8koUeGCJt6JMu4jKQBPOi5seVOVu0Fhh82CdLV04LEyCxsSx9WBqshqiRK7oqw+ttdXO1bVNZA6Zz2d4oV9kiWRnBCz7GNhP2LnoFA99Kec0jsla0Bqt7PNBMSDqWDBoZam/OA1WB8gahiQoiULnkSWnX/P95Q9jrvRBSJoaTEckVzVVjYjn2kjfGrBo3SRZP8+bvC7FTOCNneAkwqG0eYaFwsHCe7+TCm/rXpx0lgYg2lUEvPzrN3wqSOJpfZ9ByjjJiaix0gVynS8lJ4v/myO14z+9sgAGOiSTBJn2vcM1420wJVJIiaJaTfBEVCbFnH/PV21p83bKawYM/xYNXB9mHSB5l7VeBjXiH79Nahj4px3TWWM40YXlHKuo4Vf40czeBKnUk5i0Q6p/Fy3QNtEAR7AwbHrKutYQBUwydB6tlAsSdTK6tJZ0vp3rwhv2UN1r7M4h1P8V1olrTm4/imH4chrx39bb4PNzLalQT48E7qviEGjkrUjwF0UMBNESFFI90uhkebctspKVskHIozXA1aG81++02/UHj1fh/a1i4wZ6rSWRrikjuXoUKPNhJKcD6WUbR3jVKr9K/05fOx/JuHuE1ZgzyfKTO7pxi7fizV/EkUCASaAtC43yzSMMYoZt62lE+7FMpvgwe2BOCYLXsaatirR1Id/63LmV9vvvGD8LqfjGvm+6xhMGfrI7lDVTmpjAslANiSlhydkxEFetufMnuwdyCvXBBDTDOxuQceqG33XMzGx9ovSqm0fZ9LWVi9MbdxgC+AObnTamdGWHaaV1SwCWow0i3MwIdbWWm0q8msrez9pqbVJbyr9li8XTsQo7IvAI/uLgBW3yyN9UZ1g+9kDKYWmEMxCCCawe1Obx3v8y4Av54I0vQNU+A80cs6EbNciTdA+oHuJpPNX8ebWCpney6gxdCuNNrCR+f9R7AZaKnbtW3jbHkWu8mPAJyq2T988u58PY7fOglB7BUhWwJHZRfU4Xjtp5rO8Efxh1bdeI8uJM/Rfh2oJ7WT+AWb7ZhS/ztms2Oet8GPvUVtMqAjEHPiQM+fzR6ufKyuumUIWZTd9zqfZAXoTxqeLb2CTRXbuVe2ZFxJDUUvJtmmntSi+zVmeVbo1N1sEi87NoL+7fN5qJzzSYXKJbWn5j3b7qfw7g3CNVoX+BuKuLyzf+CiGG7q0TDwYNDi7ErsIaaCI/3pKdXnpv1SrB1WBrlEsAp55SiT6J/4gCN4JBZAVT5c1x/4ssZY8penK5igu1A3+yyVIdiZQ0hYOBioHTSaFjNEtY6MIdvpzn7bo5i+XD6wv2mRbVVWnL52TUU2TjopQcrgQuLsHbAs4OSB7Fpp6mW2zl8k+dQIWCQCu0rBqLafh9MgDRbNmZUdywKYx21ecGGsP6xGf0l9Ay07tU4t6z34R4QTo+9Y/J8RZytLQLIzA0MVecKxucHMbTB1+20vtK5v03IVaAuCYUB8b46Mb7mFQn2krbijIwxRxUVmAZl+9XaI91NmArH7XTAyenN1lB4qL0XVZVU2dJt9oMYjyk7vSLxatn+H3su232slF2P7fs7dDsiTMzAkoKGmhBg+V0JxoWihcnxVXpe86aVdfb7KKh+s5a+elKV0ahtyDDqTbz5nOsUEW2LiImtn5+7knv+CEdSkyzsK8lTZdSZG7ft97gqdwZVQpFlXsDCuaDicnov50syFVllEEkvZDDA5Ei+3fxuAAS26+u6M8S7jqvjlB0TtORaK9FB268vykZERiXqrLvnf4yFWQFV/MWEcoVAQQgK4vy+Yv9ssOBTed4frctMhtoSE4OELKOjqH35UzLT02AS4Zsi/buCFmusELI+SLittE64FqiVfJIXCUenEgTqNVbHwTyHXktv2Np/LiY4Bf5+Dh6R3Vgj0oPJ2d3f6nqZHI+m9EvQ2GabqTTOAYGANIoP2NLW+YXX9t+ezs8zpfCnoApuHDaoI3ZvMoFg3dgaJc9By2QHxgrg2CldbxN8nKTQbE6VKjoM3fkyJQUFD6QXffwIZuqr/R/DoJvUYhzQ7ltrKm4wa8mzMjjO3nUu+tTJjoYEOqtAynzyAp7C7cpMiq9ht2Ylwads+mHnFrXIYuOGQOmeP3j5E+2XTpqg26RCnO8WOdft4XmbtaroAfmmiDxtg8cslyEXbOkppVCtPA9+Kbsamrk2fXESq9PgqYd7vhmn21kfXIE4K7VRAPwK4WncshLZZ8Cdj+UFbfQJ2w8snsBsGzqzHQ/QApG/VJE7VrCzVOYcqdBxbnCVA1qy8Xs7KVytO6DZizv1Uv54nHEwF7AVKEUO3KN1Ckv0ZTTSPZQ0q4wO66ibozpGYnKh79qjSRRjS+afnDseVn0jfvgFZXt9P5VidJBsfT10P8sDCUJjkqpXOSFTeVoKvR8Zc4jVlzoQTHaxdypUoe5qzIdxoV6iZ5NvgBp0kPD/5NDc7eyvkiVrE/Xo4Mjm6QJvuvlJKj5h9ABIa/t04tVTQz0LsnQCJGVXHe+aHBzIa0Aaw+hV00EuM4uz7DVyAPek+dAuUgfZl8/WrhMR7OGH1P7xMMckY++wcGhtTve0IGhpprFkv0Mo6iqmxRdK0mPri2RnK1XconhrN8PkXvJd5GW/Xae3lhGzydWXvogT1OCjxFWgykGK3JUbRhZRcUzaA07Yt8XMLS/yOWDx3hSZQA/ANC+DaL/Qm+uIT19i0g/x7lT9OQp4a+cfGZMTE3F2cauMywPTHIdzcik5nu2vibat/XWAtxlm4eL3QvMuhUAJ')
_tag = base64.b64decode('TnDevENoSVVIqIRDkTkSIQ==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
