# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : lang_ident_app
# @Time             : 18/12/23 8:59 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import _2599a9b5bbb7
import _636087f1f8e1
import _83aadc2d08ad
from _9382062b6b55 import _4f7361d5126a
import _4d9d4d048791
from _121255496559 import _195af8caba76, _f21068314146
from _6aacf01fc6d9._aa26a651744f._11e3c15f9375._ff31d1c920c8 import _974130564fc4
import _7ac2a0f65aeb as _e5e32a9e02e1
import _c449aabaa821
from _c449aabaa821 import _e42d0b9c1cef
from _7ac2a0f65aeb import _b123589b823f
from _7ac2a0f65aeb._53c59eb5da7c import _11e3c15f9375
from _2badb6cdddd9 import _70633a40467e, _53ba8bd82863, _9ccf570195ad
from _7ac2a0f65aeb._53c59eb5da7c._36a855c2d79a import _1c0361455792
from _7ac2a0f65aeb._53c59eb5da7c._36a855c2d79a._b3f8405ebbac import _d0fa87c915cf
from _c449aabaa821._9347e4ab154a._b3f8405ebbac import _27871ea664d4, _6acd314a66ac
from _c449aabaa821._9347e4ab154a._b3f8405ebbac._530a06dc158c import _a67dcd32ecf9
from _c449aabaa821._1c3b556c4fcf import _1132ca4f6b83
from _7ac2a0f65aeb._53c59eb5da7c._68d4985fcf3d._22dffba3e623 import _d6a3d7364d0e
from _6aacf01fc6d9._aa26a651744f._d4b27b881cd3._ef53375940ae import _b9faad6a8720
from _6aacf01fc6d9._aa26a651744f._7c07a65eeb09._5e4c75a77c83 import _b8e183bddbb5
from _6aacf01fc6d9._aa26a651744f._715354c6f9f1._5f11b7b238d2 import _2932ae77c35f
from _6aacf01fc6d9._aa26a651744f._715354c6f9f1._20bf4199b0f0 import _688c401b5424
from _6aacf01fc6d9._aa26a651744f._715354c6f9f1._d164c136c303 import _27db9776e5e6
from _6aacf01fc6d9._aa26a651744f._d4b27b881cd3._9924c3cd9b40 import _f0ec98472cb2
_e5e32a9e02e1._e802c9134344(20)

    
class _b954e6a0da74(_1c0361455792):
    def _960252fdffe8(self, _79f045414837):
        _1046f0a32793()._193dc1a39855()
        # self.cpu_offload = False
        self._12829ce85e51 = {"use_orig_params": _5bb0d663ed9d, "ignored_parameters": _79f045414837}

    @_58b97c033f77
    def _2e3c75e1410e(self) -> _11e5ec0b8419:
        """Override to disable Lightning restoring optimizers/schedulers.

        This is useful for plugins which manage restoring optimizers/schedulers.
        """
        return _6010bdd1f74f

    def _2571dedce1e4(self) -> _f21068314146[_b0af43ff3762, _195af8caba76]:
        assert self._aed5f1b0c444 is not _97b8b72ed424

        with _d0fa87c915cf._51aa2a2929bb(
                _7179db7d203a=self._aed5f1b0c444,
                _51aa2a2929bb=_27871ea664d4._2e8e8f0eda68,
                _25f9a6596d91=_6acd314a66ac(_5aba2f5f32fb=(self._abca33c1749e > 1), _fb208955aa42=_5bb0d663ed9d),
                _fdc2241ee7ae=_a67dcd32ecf9(_5aba2f5f32fb=(self._abca33c1749e > 1), _fb208955aa42=_5bb0d663ed9d),
        ):
            # state_dict = self.model.state_dict()
            _122ac44ec91e = _4f7361d5126a([(_8c87d259f563._f6550cbc426a("_forward_module.",""), _9efc88cccee9) if _8c87d259f563._13102d1ac056('_forward_module') else (_8c87d259f563, _9efc88cccee9)
                                      for _8c87d259f563, _9efc88cccee9 in self._aed5f1b0c444._122ac44ec91e()._daf209b51e05()])

            # for key in state_dict:
            #     print(f"state dict {key} :: {state_dict[key].shape}")
            return _122ac44ec91e

    def _4b739007c966(self, _aea3acb2619f: _1132ca4f6b83) -> _f21068314146[_b0af43ff3762, _e42d0b9c1cef]:
        return _d0fa87c915cf._2b50fb3a0691(self._aed5f1b0c444, _1c3b556c4fcf=_aea3acb2619f, _fb208955aa42=_5bb0d663ed9d)



def _f68b15edc131():
    _3213692bccff = _c449aabaa821._eab8839761ef._38ba338db3f5()
    _ad68da2afbd8 = 0
    if _3213692bccff == 1:
        _ad68da2afbd8 = _4d9d4d048791._b3fb6eb72783._3afa25ea8a19('CUDA_VISIBLE_DEVICES', 0)
    else:
        _ad68da2afbd8 = _4d9d4d048791._b3fb6eb72783._3afa25ea8a19('LOCAL_RANK', '0')
    return _ad68da2afbd8

def _07c4ebbf3dfa():
    _1768d933c13e = _9f21bcee38c8()
    _e21547f73132 = 1
    if _d6a3d7364d0e._0b9901939605() and _c449aabaa821._eab8839761ef._0b9fa0002682():
        _1768d933c13e['gpu_world_size'] = _b0af43ff3762(_d6a3d7364d0e._abca33c1749e(_e5e32a9e02e1))
        _1768d933c13e['gpu_global_rank'] = _b0af43ff3762(_d6a3d7364d0e._17b78dc16578(_e5e32a9e02e1))
        _1768d933c13e['gpu_local_rank'] = _b0af43ff3762(_d6a3d7364d0e._ad68da2afbd8(_e5e32a9e02e1))
    elif _d6a3d7364d0e._0b9901939605() is _6010bdd1f74f and _c449aabaa821._eab8839761ef._0b9fa0002682():
        _1768d933c13e['gpu_world_size'] = _b0af43ff3762(_4d9d4d048791._b3fb6eb72783._3afa25ea8a19('WORLD_SIZE', '1')) # get WORLD_SIZE or set value to 1
        _1768d933c13e['gpu_global_rank'] = _b0af43ff3762(_4d9d4d048791._b3fb6eb72783._3afa25ea8a19('RANK', '0'))
        _1768d933c13e['gpu_local_rank'] = _b0af43ff3762(_af745f1896f5())
    elif _d6a3d7364d0e._0b9901939605() and _c449aabaa821._eab8839761ef._0b9fa0002682() is _6010bdd1f74f:
        _1768d933c13e['gpu_world_size'] = _b0af43ff3762(_d6a3d7364d0e._abca33c1749e(_e5e32a9e02e1))
        _1768d933c13e['gpu_global_rank'] = _b0af43ff3762(_d6a3d7364d0e._17b78dc16578(_e5e32a9e02e1))
        _1768d933c13e['gpu_local_rank'] = -1
    else:
        _1768d933c13e['gpu_world_size'] = -1
        _1768d933c13e['gpu_global_rank'] = -1
        _1768d933c13e['gpu_local_rank'] = -1
    _1768d933c13e['node_name'] = _2599a9b5bbb7._395631a00d45()
    _1768d933c13e['cpu_info'] = "CPU :: {} COUNT :: {}"._4f4746241617(_636087f1f8e1._a33ccb390041()['brand_raw'], _4d9d4d048791._48b1910e3654())
    return _1768d933c13e


def _844642b4eea6(_3ba9bbe58ccb) -> _97b8b72ed424:
    """
    Launch method for the lang ident classifier app
    :param args: takes command line arguments
    :return: None
    """
    _ad68da2afbd8 = 0
    if _d6a3d7364d0e._0b9901939605() is _6010bdd1f74f and _c449aabaa821._eab8839761ef._0b9fa0002682():
        _ad68da2afbd8 = _c71e5d75826a(_af745f1896f5())
        _17b78dc16578 = _c71e5d75826a(_4d9d4d048791._b3fb6eb72783._3afa25ea8a19('RANK', '0'))
        _abca33c1749e = _c71e5d75826a(_4d9d4d048791._b3fb6eb72783._3afa25ea8a19('WORLD_SIZE', '1'))
        _c449aabaa821._9347e4ab154a._3e264d6077e5(_33d497b363c3=_3ba9bbe58ccb._33d497b363c3, _9ac320e27067=_17b78dc16578, _abca33c1749e=_abca33c1749e)
    _3736d81a96b7 = _97b8b72ed424
    _9609d93d1e3d = _97b8b72ed424
    _b41ae09448ed = _2932ae77c35f()
    _2be82cc59494 = _688c401b5424()
    _72cd7b82714e = _27db9776e5e6()
    _75b511bc5f71 = _b41ae09448ed._96d175495571(_3ba9bbe58ccb._44e848a80b17)
    _8feb959f6278 = _2be82cc59494._4cfaeab002da(_75b511bc5f71)
    _1768d933c13e = _9bf4c542f06f()
    _e21547f73132 = _3ba9bbe58ccb._e21547f73132
    _8feb959f6278._5e223b1e5910(f"App initialized!! on {_1768d933c13e}")

    # Load pretrained embedding
    _aaa4748622dd = _75b511bc5f71._aed5f1b0c444._aaa4748622dd
    _3c66015f6def = _4d9d4d048791._7c618f833860._e94cd8ef3294(_75b511bc5f71._f2d180f89f31._27e86cfe5c22,
                                                       _aaa4748622dd)
    _72cd7b82714e._2715444df2ef(_3c66015f6def)
    if _aaa4748622dd:
        if _72cd7b82714e._b93ffd5ac43b(_3c66015f6def):
            _69f786762087 = _70633a40467e._df1cf4e92baa(_3c66015f6def)
            _8feb959f6278._5e223b1e5910(f"Config of pretrained embedding used {_69f786762087}")
            _8feb959f6278._5e223b1e5910(f"Loading {_aaa4748622dd} embeddings from {_3c66015f6def}")
            _9609d93d1e3d = _53ba8bd82863._df1cf4e92baa(
                _9ed305aa50b0=_3c66015f6def)
            _3736d81a96b7 = _9ccf570195ad._df1cf4e92baa(
                _9ed305aa50b0=_3c66015f6def)
        else:
            _69f786762087 = _70633a40467e._df1cf4e92baa(_aaa4748622dd)
            _8feb959f6278._5e223b1e5910(f"config of pretrained embedding used {_69f786762087}")
            _8feb959f6278._5e223b1e5910(f"Downloading {_aaa4748622dd} embeddings from transformers package")
            _9609d93d1e3d = _53ba8bd82863._df1cf4e92baa(
                _9ed305aa50b0=_aaa4748622dd)
            _3736d81a96b7 = _9ccf570195ad._df1cf4e92baa(
                _9ed305aa50b0=_aaa4748622dd)
            _9609d93d1e3d._ed139312b277(_3c66015f6def)
            _3736d81a96b7._ed139312b277(_3c66015f6def)

    # Test Dataset
    _046661128ee0 = _4d9d4d048791._7c618f833860._e94cd8ef3294(_75b511bc5f71._f2d180f89f31._191263275ebe, _75b511bc5f71._d4b27b881cd3._e6a183bb984b._191263275ebe)
    _1c08af1bb617 = _4d9d4d048791._7c618f833860._e94cd8ef3294(_75b511bc5f71._f2d180f89f31._191263275ebe, _75b511bc5f71._d4b27b881cd3._afdf5dc544c1._191263275ebe)
    _ef324557118a = _4d9d4d048791._7c618f833860._e94cd8ef3294(_75b511bc5f71._f2d180f89f31._191263275ebe, _75b511bc5f71._d4b27b881cd3._f481766a8405._191263275ebe)
    _f3d916970d97 = _75b511bc5f71._d4b27b881cd3._f3d916970d97
    _5bd23c791477 = _f0ec98472cb2(_191263275ebe=_046661128ee0, _957377a7e1c6=_f3d916970d97,
                                                  _8feb959f6278=_8feb959f6278, _2ece13ab5001=_3736d81a96b7,
                                                  _5c20561b632b=300,
                                                  _0eda5b10cc7f="config/classes_config.json",
                                                  _bbda6f55d795=_5bb0d663ed9d)
    _e50227557248 = _f0ec98472cb2(_191263275ebe=_1c08af1bb617, _957377a7e1c6=_f3d916970d97,
                                                _8feb959f6278=_8feb959f6278, _2ece13ab5001=_3736d81a96b7,
                                                _5c20561b632b=300,
                                                _0eda5b10cc7f="config/classes_config.json",
                                                _bbda6f55d795=_6010bdd1f74f)
    _5c3ae2d7dcf1 = _f0ec98472cb2(_191263275ebe=_ef324557118a, _957377a7e1c6=_f3d916970d97,
                                                 _8feb959f6278=_8feb959f6278, _2ece13ab5001=_3736d81a96b7,
                                                 _5c20561b632b=300,
                                                 _0eda5b10cc7f="config/classes_config.json",
                                                 _bbda6f55d795=_6010bdd1f74f)

    _8feb959f6278._5e223b1e5910(f"Number of training data samples {_5bd23c791477._8220bd5a6322()}")
    _8feb959f6278._5e223b1e5910(f"Number of validation samples {_e50227557248._8220bd5a6322()}")
    _8feb959f6278._5e223b1e5910(f"Number of test samples {_5c3ae2d7dcf1._8220bd5a6322()}")

    _0e9033d42acf = _5bd23c791477._6037ef3b862e()
    _d8b291e76045 = [_5bd23c791477._8a00dc6355f6(_60be01f2bf80) for _60be01f2bf80 in _5bd23c791477._d8b291e76045._3547fdd7e08e()]
    _ec7ad574555d = _5bd23c791477._ec7ad574555d
    _8feb959f6278._5e223b1e5910(f"{_0e9033d42acf} classes in training data with classes {_d8b291e76045} and weights {_ec7ad574555d}")

    _5a3748659b90 = _b9faad6a8720(_65d928392251=_75b511bc5f71._aed5f1b0c444._65d928392251,
                                                              _5bd23c791477=_5bd23c791477,
                                                              _e50227557248=_e50227557248,
                                                              _5c3ae2d7dcf1=_5c3ae2d7dcf1)

    # Load Custom Model
    _aed5f1b0c444 = _b8e183bddbb5(_61131b5fd510=_9609d93d1e3d,
                                             _0e9033d42acf=_0e9033d42acf,
                                             _2d9873387d62=_75b511bc5f71._aed5f1b0c444._a70d16bc8bed,
                                             _aea3acb2619f=_75b511bc5f71._aed5f1b0c444._aea3acb2619f,
                                             _ec7ad574555d=_ec7ad574555d,
                                             _1768d933c13e=_1768d933c13e,
                                             _ee0d0aa2fbf7=2,
                                             _c93baa7fafc1="weighted_cross_entropy",
                                             _bb7340f852ae=3,
                                             _72e8d764248a="relu",
                                             _15feb1c5c563=_5bb0d663ed9d)
    if _d6a3d7364d0e._0b9901939605() is _6010bdd1f74f:
        _8feb959f6278._5e223b1e5910(f"Setting model to cuda:{_ad68da2afbd8}")
        _aed5f1b0c444 = _aed5f1b0c444._457e83c76280(_efc6cadf3138=f"cuda:{_ad68da2afbd8}")
    _eae6f24006c5 = _d0aa23c6f025()
    for _8c9a7596224c, _8a6bd9f97689 in _aed5f1b0c444._ffedb2a6ecfd():
        # print(f"Param {name} device {p.data.get_device()}")
        if not _8a6bd9f97689._bc9ee9272477:
            _eae6f24006c5._f6d867e9f7a7(_8a6bd9f97689)
    _f52c782d683a = _8afd1cd5cfa0(_79f045414837=_eae6f24006c5)
    # callbacks
    # fit model
    _f411ed32ca8c = _75b511bc5f71._f2d180f89f31._f411ed32ca8c
    # Create an instance of the CustomMetricsCallback
    _1c2be5602c9a = 'gpu' if _c449aabaa821._eab8839761ef._0b9fa0002682() else 'cpu'
    _981a4af08cb8 = {}
    # model_config_name = props.app.model_config_name
    _981a4af08cb8['model_name'] = _f411ed32ca8c
    # metrics_summary_dict['config'] = yaml_config_data
    _981a4af08cb8['max_epochs'] = _75b511bc5f71._aed5f1b0c444._1c40a129dcf3
    _a12ea5f0f524 = _11e3c15f9375._c4cba9b289ec(_dfaa45bcb912=1)
    _e627578e50a3 = "metrics/{}"._4f4746241617(_f411ed32ca8c)
    _5f2aa63561c6 = "epoch_training_metrics.csv"
    _51b34adb3c4e = "model_training_summary_metrics.csv"
    _3eddbf294c72 = _974130564fc4(_8feb959f6278,
                                   _a12ea5f0f524=_a12ea5f0f524,
                                   _981a4af08cb8=_981a4af08cb8,
                                   _96876f359d22=_e627578e50a3,
                                   _27d00b4d8f70=_5f2aa63561c6,
                                   _9866d2d69d1f=_51b34adb3c4e)
    _e2dc203dfe41 = _4d9d4d048791._7c618f833860._e94cd8ef3294(_75b511bc5f71._f2d180f89f31._e62b8b2a6678, _f411ed32ca8c)
    _29fc532fa888 = _11e3c15f9375._db9172ac0a74(_eb71b1ff9a1a=_e2dc203dfe41,
                                                    _761ad11c2508="{epoch}-{train_loss:.2f}-{val_loss:.2f}",
                                                    _615edbac53ac=2,
                                                    _d09eefcbec76=_5bb0d663ed9d,
                                                    _915b4c3e99e1="val_loss",
                                                    _d29a8f7b4ead="min")
    _ebb18f2db864 = _11e3c15f9375._e4690b32ccb3(_915b4c3e99e1="val_loss",
                                                      _d29a8f7b4ead="min",
                                                      _4d63b782eef8=0.001,
                                                      _cd1e481b7398=5)
    _fa836a49a96c = _11e3c15f9375._1135c6acb03d(_dea5bbdd9814='step')

    _85cad3a389f7 = _b123589b823f(_50bc28d051e7=_1c2be5602c9a,
                    _9c06d22fd336=-1 if _1c2be5602c9a == "gpu" else 1,
                    _e21547f73132=_e21547f73132,
                    _0b0c2423cf10=_f52c782d683a if _1c2be5602c9a == "gpu" else "auto",
                    # strategy="ddp",
                    _1c40a129dcf3=_75b511bc5f71._aed5f1b0c444._1c40a129dcf3,
                    _1b50d2a47cf5=_5bb0d663ed9d,
                    _18efe4314176=_5bb0d663ed9d,
                    _40c4e9a9a202=_5bb0d663ed9d,
                    _f79754360765=8,
                    _92f0420c9f7e=0.1,
                    _decd190a99fe=0.1,
                    _d65d79128c86='16-mixed',
                    _11e3c15f9375=[_3eddbf294c72, _29fc532fa888, _ebb18f2db864, _fa836a49a96c],
                    )
    
    _85cad3a389f7._0b0c2423cf10._e21547f73132=_e21547f73132

    _c35755f07d22 = _4d9d4d048791._7c618f833860._e94cd8ef3294(_e2dc203dfe41, "last.ckpt")
    _8feb959f6278._5e223b1e5910(f"Model : {_aed5f1b0c444}")

    
    if _4d9d4d048791._7c618f833860._982fea2b84b6(_c35755f07d22):
        _85cad3a389f7._9cd06c1a3c81(_aed5f1b0c444, _4a3f95af79f5=_5a3748659b90, _0ee961d1b7c2=_c35755f07d22, )
    else:
        _85cad3a389f7._9cd06c1a3c81(_aed5f1b0c444, _4a3f95af79f5=_5a3748659b90, )


if __name__ == "__main__":
    _dbd80b7724df = _83aadc2d08ad._8e89ee6cbd2b(_d786b0240643=
                                     'App to train and manage language identification models')
    _dbd80b7724df._d9a65cc4ff8a('--config_file_path', _15c486d9676c=_b0af43ff3762,
                        _18cbf36ca1fb=_5bb0d663ed9d, _bc2fb5a1ead0='Pass the config file path')
    _dbd80b7724df._d9a65cc4ff8a('--num_nodes', _15c486d9676c=_c71e5d75826a, _a082f5786737=1,
                        _18cbf36ca1fb=_6010bdd1f74f, _bc2fb5a1ead0='Pass the num gpus')
    _dbd80b7724df._d9a65cc4ff8a('--local-rank', _15c486d9676c=_c71e5d75826a,
                        _18cbf36ca1fb=_6010bdd1f74f, _bc2fb5a1ead0='Pass the gpu rank')
    _dbd80b7724df._d9a65cc4ff8a('--backend', _15c486d9676c=_b0af43ff3762, _a082f5786737="gloo", _34c9d5c4bbba=['gloo','mpi','nccl'],
                        _18cbf36ca1fb=_6010bdd1f74f, _bc2fb5a1ead0='optional gloo, mpi or nccl for distributed training')
    try:
        _196fb6d49062 = _dbd80b7724df._6fa621e8dfa9()
        _09d60565e8bf(_196fb6d49062)
    except _83aadc2d08ad._adea66cb17cd as _e6efecefec74:
        _c74cdee36593(f"Error: {_e6efecefec74}")
        _dbd80b7724df._a8fdad8f7f0f()
