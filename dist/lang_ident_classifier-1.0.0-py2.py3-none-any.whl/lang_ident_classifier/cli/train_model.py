# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : lang_ident_app
# @Time             : 18/12/23 8:59 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import _363a1eddfb1f
import _1cd5e94dedd8
import _4469c6d67701
from collections import _037d24412dce
import os
from typing import _e40cd9a5934a, _024a496a63fa
from _207b530d43de._81fddda06f53._e9f9e489e9ef._f3281b1919c8 import _444509219465
import _1377f45cec99 as _ee2ac7eb4d40
import _925f1f76aaf9
from _925f1f76aaf9 import _20d59d26a04e
from _1377f45cec99 import _4994f8a4d57b
from _1377f45cec99._82126ed84f55 import _e9f9e489e9ef
from _be5f4f1eb3e0 import _731956a3afa2, _7431afdc4688, _5e915a8ee701
from _1377f45cec99._82126ed84f55._937d951081b6 import _d9fd164047b2
from _1377f45cec99._82126ed84f55._937d951081b6._c163d8bf3d51 import _3848adc50d4a
from _925f1f76aaf9._ee997bf201ea._c163d8bf3d51 import _b2be9140c120, _6911bdf22386
from _925f1f76aaf9._ee997bf201ea._c163d8bf3d51._c123be3a8725 import _9f386681be0c
from _925f1f76aaf9._662d94be2685 import _5f0f86c00bb5
from _1377f45cec99._82126ed84f55._684812ae3cfe._0121537b7d2b import _016e478844cb
from _207b530d43de._81fddda06f53._61777f907671._7f57e1c13ed1 import _d1fbdafb6f41
from _207b530d43de._81fddda06f53._b4df30eed29d._a42f2fd08979 import _239b226546e7
from _207b530d43de._81fddda06f53._5c21f3c2945a._41463748d853 import _028901df5a30
from _207b530d43de._81fddda06f53._5c21f3c2945a._e40916d5af7d import _f44fbbac33ef
from _207b530d43de._81fddda06f53._5c21f3c2945a._a0677077d90b import _c24471e7a8b8
from _207b530d43de._81fddda06f53._61777f907671._a4006a43399d import _b0356fbc3422
_ee2ac7eb4d40._a828024a26ff(20)

    
class _06c38913d51c(_d9fd164047b2):
    def _a44f17870899(self, _6ba904e03159):
        _ad30fc8fc0f2()._70add80de2d7()
        # self.cpu_offload = False
        self._3cf8381cebaf = {"use_orig_params": _1a9a083024ea, "ignored_parameters": _6ba904e03159}

    @_6dd5f80a9601
    def _52cf05868158(self) -> _873026d9599e:
        """Override to disable Lightning restoring optimizers/schedulers.

        This is useful for plugins which manage restoring optimizers/schedulers.
        """
        return _1664fecf3e5a

    def _5ddb6b6aa08b(self) -> _024a496a63fa[_00ad9bda4540, _e40cd9a5934a]:
        assert self._27c9e09397b2 is not _26a15ecf82ef

        with _3848adc50d4a._31e78db93917(
                _0142d9cfc2fd=self._27c9e09397b2,
                _31e78db93917=_b2be9140c120._b99efc8efd93,
                _afae9df2894a=_6911bdf22386(_6d7ce2bfb342=(self._f2f698b0ef70 > 1), _f48a9a885dce=_1a9a083024ea),
                _5319b3df84a0=_9f386681be0c(_6d7ce2bfb342=(self._f2f698b0ef70 > 1), _f48a9a885dce=_1a9a083024ea),
        ):
            # state_dict = self.model.state_dict()
            _5d3fbfe8f5a4 = _037d24412dce([(_deea23bacd5a._8a8704b1d214("_forward_module.",""), _086ed9d0b3b9) if _deea23bacd5a._bbad746fabd1('_forward_module') else (_deea23bacd5a, _086ed9d0b3b9)
                                      for _deea23bacd5a, _086ed9d0b3b9 in self._27c9e09397b2._5d3fbfe8f5a4()._3c5f78ee1527()])

            # for key in state_dict:
            #     print(f"state dict {key} :: {state_dict[key].shape}")
            return _5d3fbfe8f5a4

    def _8f8320577949(self, _e57374f5f388: _5f0f86c00bb5) -> _024a496a63fa[_00ad9bda4540, _20d59d26a04e]:
        return _3848adc50d4a._0537e81df569(self._27c9e09397b2, _662d94be2685=_e57374f5f388, _f48a9a885dce=_1a9a083024ea)



def _2b95456c7913():
    _a2d0d3210761 = _925f1f76aaf9._98e53804cb2e._28685be20d50()
    _b61188d56ee0 = 0
    if _a2d0d3210761 == 1:
        _b61188d56ee0 = os._596037b30aaf._6cd0f43d4985('CUDA_VISIBLE_DEVICES', 0)
    else:
        _b61188d56ee0 = os._596037b30aaf._6cd0f43d4985('LOCAL_RANK', '0')
    return _b61188d56ee0

def _2f6084cba42d():
    _1b2d44871f99 = _d3faa813e4a6()
    _cc8786726a96 = 1
    if _016e478844cb._5e4b2ffe88e7() and _925f1f76aaf9._98e53804cb2e._61df33df7da6():
        _1b2d44871f99['gpu_world_size'] = _00ad9bda4540(_016e478844cb._f2f698b0ef70(_ee2ac7eb4d40))
        _1b2d44871f99['gpu_global_rank'] = _00ad9bda4540(_016e478844cb._2df1a003551c(_ee2ac7eb4d40))
        _1b2d44871f99['gpu_local_rank'] = _00ad9bda4540(_016e478844cb._b61188d56ee0(_ee2ac7eb4d40))
    elif _016e478844cb._5e4b2ffe88e7() is _1664fecf3e5a and _925f1f76aaf9._98e53804cb2e._61df33df7da6():
        _1b2d44871f99['gpu_world_size'] = _00ad9bda4540(os._596037b30aaf._6cd0f43d4985('WORLD_SIZE', '1')) # get WORLD_SIZE or set value to 1
        _1b2d44871f99['gpu_global_rank'] = _00ad9bda4540(os._596037b30aaf._6cd0f43d4985('RANK', '0'))
        _1b2d44871f99['gpu_local_rank'] = _00ad9bda4540(_9e8af2c2bdb6())
    elif _016e478844cb._5e4b2ffe88e7() and _925f1f76aaf9._98e53804cb2e._61df33df7da6() is _1664fecf3e5a:
        _1b2d44871f99['gpu_world_size'] = _00ad9bda4540(_016e478844cb._f2f698b0ef70(_ee2ac7eb4d40))
        _1b2d44871f99['gpu_global_rank'] = _00ad9bda4540(_016e478844cb._2df1a003551c(_ee2ac7eb4d40))
        _1b2d44871f99['gpu_local_rank'] = -1
    else:
        _1b2d44871f99['gpu_world_size'] = -1
        _1b2d44871f99['gpu_global_rank'] = -1
        _1b2d44871f99['gpu_local_rank'] = -1
    _1b2d44871f99['node_name'] = _363a1eddfb1f._e557abc2b890()
    _1b2d44871f99['cpu_info'] = "CPU :: {} COUNT :: {}"._6b51227b2608(_1cd5e94dedd8._165c9b8e952a()['brand_raw'], os._28b94457525d())
    return _1b2d44871f99


def _f726676fac99(_4b4d6c8cc891) -> _26a15ecf82ef:
    """
    Launch method for the lang ident classifier app
    :param args: takes command line arguments
    :return: None
    """
    _b61188d56ee0 = 0
    if _016e478844cb._5e4b2ffe88e7() is _1664fecf3e5a and _925f1f76aaf9._98e53804cb2e._61df33df7da6():
        _b61188d56ee0 = _677c17736e85(_9e8af2c2bdb6())
        _2df1a003551c = _677c17736e85(os._596037b30aaf._6cd0f43d4985('RANK', '0'))
        _f2f698b0ef70 = _677c17736e85(os._596037b30aaf._6cd0f43d4985('WORLD_SIZE', '1'))
        _925f1f76aaf9._ee997bf201ea._cf0e1f49bacd(_0b809316b967=_4b4d6c8cc891._0b809316b967, _ded8fd1afab5=_2df1a003551c, _f2f698b0ef70=_f2f698b0ef70)
    _a75288f5c140 = _26a15ecf82ef
    _43a4af1022e3 = _26a15ecf82ef
    _2f6cd8bf1204 = _028901df5a30()
    _a88bd2e7aaf5 = _f44fbbac33ef()
    _df353a9d06b2 = _c24471e7a8b8()
    _8a1b139ccf1f = _2f6cd8bf1204._4e13fcfc1419(_4b4d6c8cc891._eef552dd80b3)
    _378e847ce05c = _a88bd2e7aaf5._06f21a1a4031(_8a1b139ccf1f)
    _1b2d44871f99 = _1a3117ebdf59()
    _cc8786726a96 = _4b4d6c8cc891._cc8786726a96
    _378e847ce05c._c46a4b542655(f"App initialized!! on {_1b2d44871f99}")

    # Load pretrained embedding
    _b44b0afb1138 = _8a1b139ccf1f._27c9e09397b2._b44b0afb1138
    _1c8464628bf5 = os._b47a63e057e9._0131c5149bee(_8a1b139ccf1f._57ec39b8aa2e._11b8fa704f56,
                                                       _b44b0afb1138)
    _df353a9d06b2._d744fd8aa112(_1c8464628bf5)
    if _b44b0afb1138:
        if _df353a9d06b2._71bb3350b647(_1c8464628bf5):
            _d3888246e362 = _731956a3afa2._097dab600456(_1c8464628bf5)
            _378e847ce05c._c46a4b542655(f"Config of pretrained embedding used {_d3888246e362}")
            _378e847ce05c._c46a4b542655(f"Loading {_b44b0afb1138} embeddings from {_1c8464628bf5}")
            _43a4af1022e3 = _7431afdc4688._097dab600456(
                _21d4aace6d53=_1c8464628bf5)
            _a75288f5c140 = _5e915a8ee701._097dab600456(
                _21d4aace6d53=_1c8464628bf5)
        else:
            _d3888246e362 = _731956a3afa2._097dab600456(_b44b0afb1138)
            _378e847ce05c._c46a4b542655(f"config of pretrained embedding used {_d3888246e362}")
            _378e847ce05c._c46a4b542655(f"Downloading {_b44b0afb1138} embeddings from transformers package")
            _43a4af1022e3 = _7431afdc4688._097dab600456(
                _21d4aace6d53=_b44b0afb1138)
            _a75288f5c140 = _5e915a8ee701._097dab600456(
                _21d4aace6d53=_b44b0afb1138)
            _43a4af1022e3._305451b5a18d(_1c8464628bf5)
            _a75288f5c140._305451b5a18d(_1c8464628bf5)

    # Test Dataset
    _8dbcf37e8072 = os._b47a63e057e9._0131c5149bee(_8a1b139ccf1f._57ec39b8aa2e._1b1af1ea2780, _8a1b139ccf1f._61777f907671._fd0a2f68fe6d._1b1af1ea2780)
    _e67050d99a20 = os._b47a63e057e9._0131c5149bee(_8a1b139ccf1f._57ec39b8aa2e._1b1af1ea2780, _8a1b139ccf1f._61777f907671._890e8b5f42f5._1b1af1ea2780)
    _9c1cfeb4fadb = os._b47a63e057e9._0131c5149bee(_8a1b139ccf1f._57ec39b8aa2e._1b1af1ea2780, _8a1b139ccf1f._61777f907671._9248738534af._1b1af1ea2780)
    _35fcd7bb221b = _8a1b139ccf1f._61777f907671._35fcd7bb221b
    _bcd82edd39aa = _b0356fbc3422(_1b1af1ea2780=_8dbcf37e8072, _66cfdb9b0ccd=_35fcd7bb221b,
                                                  _378e847ce05c=_378e847ce05c, _605e18ba5bb7=_a75288f5c140,
                                                  _7d391650d643=300,
                                                  _c33582124bab="config/classes_config.json",
                                                  _21606b613b7c=_1a9a083024ea)
    _df15f3e7cc8e = _b0356fbc3422(_1b1af1ea2780=_e67050d99a20, _66cfdb9b0ccd=_35fcd7bb221b,
                                                _378e847ce05c=_378e847ce05c, _605e18ba5bb7=_a75288f5c140,
                                                _7d391650d643=300,
                                                _c33582124bab="config/classes_config.json",
                                                _21606b613b7c=_1664fecf3e5a)
    _06a620bc1515 = _b0356fbc3422(_1b1af1ea2780=_9c1cfeb4fadb, _66cfdb9b0ccd=_35fcd7bb221b,
                                                 _378e847ce05c=_378e847ce05c, _605e18ba5bb7=_a75288f5c140,
                                                 _7d391650d643=300,
                                                 _c33582124bab="config/classes_config.json",
                                                 _21606b613b7c=_1664fecf3e5a)

    _378e847ce05c._c46a4b542655(f"Number of training data samples {_bcd82edd39aa._1c33603d074c()}")
    _378e847ce05c._c46a4b542655(f"Number of validation samples {_df15f3e7cc8e._1c33603d074c()}")
    _378e847ce05c._c46a4b542655(f"Number of test samples {_06a620bc1515._1c33603d074c()}")

    _12be0d3e2a92 = _bcd82edd39aa._113a6f9027bd()
    _1e02c43bc098 = [_bcd82edd39aa._f19bf2fdf49a(_7b729b7a01d3) for _7b729b7a01d3 in _bcd82edd39aa._1e02c43bc098._15a6c2748c56()]
    _f3d3f0444a4d = _bcd82edd39aa._f3d3f0444a4d
    _378e847ce05c._c46a4b542655(f"{_12be0d3e2a92} classes in training data with classes {_1e02c43bc098} and weights {_f3d3f0444a4d}")

    _cf7d90d5e9bc = _d1fbdafb6f41(_4e9f76fb58a5=_8a1b139ccf1f._27c9e09397b2._4e9f76fb58a5,
                                                              _bcd82edd39aa=_bcd82edd39aa,
                                                              _df15f3e7cc8e=_df15f3e7cc8e,
                                                              _06a620bc1515=_06a620bc1515)

    # Load Custom Model
    _27c9e09397b2 = _239b226546e7(_95109021c37d=_43a4af1022e3,
                                             _12be0d3e2a92=_12be0d3e2a92,
                                             _b5dc8d653b18=_8a1b139ccf1f._27c9e09397b2._9cbf1f44cf31,
                                             _e57374f5f388=_8a1b139ccf1f._27c9e09397b2._e57374f5f388,
                                             _f3d3f0444a4d=_f3d3f0444a4d,
                                             _1b2d44871f99=_1b2d44871f99,
                                             _fe224270b448=2,
                                             _6d5327de4465="weighted_cross_entropy",
                                             _24c9c852cfec=3,
                                             _eb8175967055="relu",
                                             _a920b2c3b4a9=_1a9a083024ea)
    if _016e478844cb._5e4b2ffe88e7() is _1664fecf3e5a:
        _378e847ce05c._c46a4b542655(f"Setting model to cuda:{_b61188d56ee0}")
        _27c9e09397b2 = _27c9e09397b2._728584c89057(_6a24cf449723=f"cuda:{_b61188d56ee0}")
    _302f5dbb314b = _d7df18a8dc95()
    for _a8987eb8db75, _17a959498c97 in _27c9e09397b2._a8e29477a3bb():
        # print(f"Param {name} device {p.data.get_device()}")
        if not _17a959498c97._6caaa84ef03a:
            _302f5dbb314b._95ee71f4bd07(_17a959498c97)
    _4456a8fad403 = _71337e3bef9a(_6ba904e03159=_302f5dbb314b)
    # callbacks
    # fit model
    _10b354a0c44b = _8a1b139ccf1f._57ec39b8aa2e._10b354a0c44b
    # Create an instance of the CustomMetricsCallback
    _a9d022062b44 = 'gpu' if _925f1f76aaf9._98e53804cb2e._61df33df7da6() else 'cpu'
    _d8ff342d74f9 = {}
    # model_config_name = props.app.model_config_name
    _d8ff342d74f9['model_name'] = _10b354a0c44b
    # metrics_summary_dict['config'] = yaml_config_data
    _d8ff342d74f9['max_epochs'] = _8a1b139ccf1f._27c9e09397b2._1cb4c4a3c96f
    _a4210e7a9eab = _e9f9e489e9ef._488ade559b50(_df53c0b52375=1)
    _436d1f2487a3 = "metrics/{}"._6b51227b2608(_10b354a0c44b)
    _89e2d9148a35 = "epoch_training_metrics.csv"
    _67f473e998e5 = "model_training_summary_metrics.csv"
    _99c914931b48 = _444509219465(_378e847ce05c,
                                   _a4210e7a9eab=_a4210e7a9eab,
                                   _d8ff342d74f9=_d8ff342d74f9,
                                   _7541b24e1bd2=_436d1f2487a3,
                                   _d8e06a5acec5=_89e2d9148a35,
                                   _ae707d4d95c2=_67f473e998e5)
    _276c4edd5ed8 = os._b47a63e057e9._0131c5149bee(_8a1b139ccf1f._57ec39b8aa2e._fb7054d46d1b, _10b354a0c44b)
    _6f6bac544859 = _e9f9e489e9ef._6818a2164e60(_2634b2a7233c=_276c4edd5ed8,
                                                    _0ff995352aa6="{epoch}-{train_loss:.2f}-{val_loss:.2f}",
                                                    _180d9150a10b=2,
                                                    _67cb8078f6dc=_1a9a083024ea,
                                                    _40ead5f3614d="val_loss",
                                                    _e17e5e1b3aac="min")
    _f826adaacb2c = _e9f9e489e9ef._d9b8846afcb9(_40ead5f3614d="val_loss",
                                                      _e17e5e1b3aac="min",
                                                      _31748e766893=0.001,
                                                      _b9fb94d550a4=5)
    _340f50c65b6d = _e9f9e489e9ef._b8f50dcdda1f(_71709dee0487='step')

    _542a472f3c0c = _4994f8a4d57b(_3b49089cc5c9=_a9d022062b44,
                    _33e75c198e05=-1 if _a9d022062b44 == "gpu" else 1,
                    _cc8786726a96=_cc8786726a96,
                    _9a6639ee486e=_4456a8fad403 if _a9d022062b44 == "gpu" else "auto",
                    # strategy="ddp",
                    _1cb4c4a3c96f=_8a1b139ccf1f._27c9e09397b2._1cb4c4a3c96f,
                    _368970ae816b=_1a9a083024ea,
                    _a3f1dcd73b4e=_1a9a083024ea,
                    _c2f4715b7e53=_1a9a083024ea,
                    _2906e75c0348=8,
                    _1d5385b6888c=0.1,
                    _40a3bffb19b5=0.1,
                    _7308b4efe9e3='16-mixed',
                    _e9f9e489e9ef=[_99c914931b48, _6f6bac544859, _f826adaacb2c, _340f50c65b6d],
                    )
    
    _542a472f3c0c._9a6639ee486e._cc8786726a96=_cc8786726a96

    _f79cf1e79485 = os._b47a63e057e9._0131c5149bee(_276c4edd5ed8, "last.ckpt")
    _378e847ce05c._c46a4b542655(f"Model : {_27c9e09397b2}")

    
    if os._b47a63e057e9._3c33bd95a216(_f79cf1e79485):
        _542a472f3c0c._ef7a5fe7f873(_27c9e09397b2, _9f7360c60701=_cf7d90d5e9bc, _f1e1d8ceead6=_f79cf1e79485, )
    else:
        _542a472f3c0c._ef7a5fe7f873(_27c9e09397b2, _9f7360c60701=_cf7d90d5e9bc, )


if __name__ == "__main__":
    _482465934a9b = _4469c6d67701._fc9184e57cd4(_c3fa67faa12f=
                                     'App to train and manage language identification models')
    _482465934a9b._a42e383fe903('--config_file_path', _18c10261de75=_00ad9bda4540,
                        _17f5fee9cc32=_1a9a083024ea, _929978dc2a48='Pass the config file path')
    _482465934a9b._a42e383fe903('--num_nodes', _18c10261de75=_677c17736e85, _a0f84a12637a=1,
                        _17f5fee9cc32=_1664fecf3e5a, _929978dc2a48='Pass the num gpus')
    _482465934a9b._a42e383fe903('--local-rank', _18c10261de75=_677c17736e85,
                        _17f5fee9cc32=_1664fecf3e5a, _929978dc2a48='Pass the gpu rank')
    _482465934a9b._a42e383fe903('--backend', _18c10261de75=_00ad9bda4540, _a0f84a12637a="gloo", _0eca29e8a113=['gloo','mpi','nccl'],
                        _17f5fee9cc32=_1664fecf3e5a, _929978dc2a48='optional gloo, mpi or nccl for distributed training')
    try:
        _f28cb472a696 = _482465934a9b._673ebbda9071()
        _592f1a509ced(_f28cb472a696)
    except _4469c6d67701._d4aef916a9ed as _177a50b51168:
        _2f58910a591f(f"Error: {_177a50b51168}")
        _482465934a9b._1e448a11642a()
