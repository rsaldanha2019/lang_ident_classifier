# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : lang_ident_app
# @Time             : 18/12/23 8:59 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import _c916ebe69d06
import _a786967fd52c
import _ba69858c84e0
from collections import _b87c5b9c5e9a
import os
from typing import _6ea14d877c49, _d4a68f372578
from _023033dba49c._33c37ed89468._d0288ee50e07._a12746996059 import _4ff2a70e50ac
import _1d1ca00074bd as _044277f35068
import _f0577c765eb3
from _f0577c765eb3 import _077c18c736b9
from _1d1ca00074bd import _42795800b4ba
from _1d1ca00074bd._863023aab129 import _d0288ee50e07
from _bab055180574 import _c628641ef769, _c72b01caf957, _5a55be9533f3
from _1d1ca00074bd._863023aab129._86170ab104cd import _956dcefd5e11
from _1d1ca00074bd._863023aab129._86170ab104cd._1ce4a3eae802 import _87fd60038983
from _f0577c765eb3._2648f4deebce._1ce4a3eae802 import _7b872173296a, _5812357e2012
from _f0577c765eb3._2648f4deebce._1ce4a3eae802._fa6f79df766a import _ab2c1751d84b
from _f0577c765eb3._6f567654c0a2 import _e7e8a2e72da2
from _1d1ca00074bd._863023aab129._3d25d288fc61._03a9d2d1af23 import _042fc9057e28
from _023033dba49c._33c37ed89468._4889da4620fa._86fa0dc75092 import _64d2b07685db
from _023033dba49c._33c37ed89468._e210c2756730._881ba13646ec import _2fdabb7127a0
from _023033dba49c._33c37ed89468._6c4aa35de88e._1faa5760a3ca import _422982f9baff
from _023033dba49c._33c37ed89468._6c4aa35de88e._4bd9c681d03f import _f99492ca5fe7
from _023033dba49c._33c37ed89468._6c4aa35de88e._5eb8916ad222 import _e49435915afd
from _023033dba49c._33c37ed89468._4889da4620fa._4ce21d63430f import _4d3ccb78f590
_044277f35068._fbb732a256ea(20)

    
class _7a40cdd4d0a3(_956dcefd5e11):
    def _e26ebf590386(self, _3524ad8ab36e):
        _093fd75d3768()._a1adca53dbea()
        # self.cpu_offload = False
        self._61e9225a43b6 = {"use_orig_params": _6a20e858b0f9, "ignored_parameters": _3524ad8ab36e}

    @_570b07a38bdc
    def _89204d277202(self) -> _c677d7ba736f:
        """Override to disable Lightning restoring optimizers/schedulers.

        This is useful for plugins which manage restoring optimizers/schedulers.
        """
        return _e4217414592b

    def _3f2b4260cc45(self) -> _d4a68f372578[_369cccfc5f2a, _6ea14d877c49]:
        assert self._10bc379327a1 is not _7f69d13a31cb

        with _87fd60038983._56ced5535edc(
                _ce1bab3a70ee=self._10bc379327a1,
                _56ced5535edc=_7b872173296a._f1d5b8127862,
                _99af4d87f465=_5812357e2012(_7d66098c4836=(self._a195dccaf3f8 > 1), _ff6a4cf2c4ed=_6a20e858b0f9),
                _21aa273f5c9e=_ab2c1751d84b(_7d66098c4836=(self._a195dccaf3f8 > 1), _ff6a4cf2c4ed=_6a20e858b0f9),
        ):
            # state_dict = self.model.state_dict()
            _224f2fa0834c = _b87c5b9c5e9a([(_853f64d62963._ec3b068dea08("_forward_module.",""), _c80954f40d53) if _853f64d62963._b34581c4211b('_forward_module') else (_853f64d62963, _c80954f40d53)
                                      for _853f64d62963, _c80954f40d53 in self._10bc379327a1._224f2fa0834c()._687c2980fd6b()])

            # for key in state_dict:
            #     print(f"state dict {key} :: {state_dict[key].shape}")
            return _224f2fa0834c

    def _77743b53947d(self, _28db01476124: _e7e8a2e72da2) -> _d4a68f372578[_369cccfc5f2a, _077c18c736b9]:
        return _87fd60038983._7c4530805f05(self._10bc379327a1, _6f567654c0a2=_28db01476124, _ff6a4cf2c4ed=_6a20e858b0f9)



def _753bea68d240():
    _fb3a46f814d9 = _f0577c765eb3._db5d67da5031._c54e77c70007()
    _999176ed09e0 = 0
    if _fb3a46f814d9 == 1:
        _999176ed09e0 = os._8fd88afe0e53._eda0aea2406a('CUDA_VISIBLE_DEVICES', 0)
    else:
        _999176ed09e0 = os._8fd88afe0e53._eda0aea2406a('LOCAL_RANK', '0')
    return _999176ed09e0

def _6129958a36a3():
    _5bdee1e8c255 = _ccfa04e6dc7f()
    _b25616402d7f = 1
    if _042fc9057e28._60b68761a02a() and _f0577c765eb3._db5d67da5031._4b89cef3da17():
        _5bdee1e8c255['gpu_world_size'] = _369cccfc5f2a(_042fc9057e28._a195dccaf3f8(_044277f35068))
        _5bdee1e8c255['gpu_global_rank'] = _369cccfc5f2a(_042fc9057e28._c7181b1bac34(_044277f35068))
        _5bdee1e8c255['gpu_local_rank'] = _369cccfc5f2a(_042fc9057e28._999176ed09e0(_044277f35068))
    elif _042fc9057e28._60b68761a02a() is _e4217414592b and _f0577c765eb3._db5d67da5031._4b89cef3da17():
        _5bdee1e8c255['gpu_world_size'] = _369cccfc5f2a(os._8fd88afe0e53._eda0aea2406a('WORLD_SIZE', '1')) # get WORLD_SIZE or set value to 1
        _5bdee1e8c255['gpu_global_rank'] = _369cccfc5f2a(os._8fd88afe0e53._eda0aea2406a('RANK', '0'))
        _5bdee1e8c255['gpu_local_rank'] = _369cccfc5f2a(_6c5305006ccd())
    elif _042fc9057e28._60b68761a02a() and _f0577c765eb3._db5d67da5031._4b89cef3da17() is _e4217414592b:
        _5bdee1e8c255['gpu_world_size'] = _369cccfc5f2a(_042fc9057e28._a195dccaf3f8(_044277f35068))
        _5bdee1e8c255['gpu_global_rank'] = _369cccfc5f2a(_042fc9057e28._c7181b1bac34(_044277f35068))
        _5bdee1e8c255['gpu_local_rank'] = -1
    else:
        _5bdee1e8c255['gpu_world_size'] = -1
        _5bdee1e8c255['gpu_global_rank'] = -1
        _5bdee1e8c255['gpu_local_rank'] = -1
    _5bdee1e8c255['node_name'] = _c916ebe69d06._b79940b824c8()
    _5bdee1e8c255['cpu_info'] = "CPU :: {} COUNT :: {}"._5f76f536fe9a(_a786967fd52c._393e2380989e()['brand_raw'], os._03cf31c808be())
    return _5bdee1e8c255


def _37b96c7e2b71(_f95ea8fbf383) -> _7f69d13a31cb:
    """
    Launch method for the lang ident classifier app
    :param args: takes command line arguments
    :return: None
    """
    _999176ed09e0 = 0
    if _042fc9057e28._60b68761a02a() is _e4217414592b and _f0577c765eb3._db5d67da5031._4b89cef3da17():
        _999176ed09e0 = _bd0b04d1fa0d(_6c5305006ccd())
        _c7181b1bac34 = _bd0b04d1fa0d(os._8fd88afe0e53._eda0aea2406a('RANK', '0'))
        _a195dccaf3f8 = _bd0b04d1fa0d(os._8fd88afe0e53._eda0aea2406a('WORLD_SIZE', '1'))
        _f0577c765eb3._2648f4deebce._2485219c9b7f(_7f72ee55bd91=_f95ea8fbf383._7f72ee55bd91, _e612d34a7a6c=_c7181b1bac34, _a195dccaf3f8=_a195dccaf3f8)
    _8e2bbb5c8cad = _7f69d13a31cb
    _e2b481b280fe = _7f69d13a31cb
    _9251b0587d82 = _422982f9baff()
    _805fafa82b91 = _f99492ca5fe7()
    _46a4332c0d99 = _e49435915afd()
    _92c2d6b9183f = _9251b0587d82._2886a4cd2e0a(_f95ea8fbf383._de67feb14bde)
    _779095aa4de9 = _805fafa82b91._b9d6332859f0(_92c2d6b9183f)
    _5bdee1e8c255 = _50c0a5af0992()
    _b25616402d7f = _f95ea8fbf383._b25616402d7f
    _779095aa4de9._d9c193ad708e(f"App initialized!! on {_5bdee1e8c255}")

    # Load pretrained embedding
    _e0ab28febe6e = _92c2d6b9183f._10bc379327a1._e0ab28febe6e
    _ad2598448d19 = os._2b6fce35cff6._d9c2565fb2dd(_92c2d6b9183f._36f3968b95ef._e079ea263fe1,
                                                       _e0ab28febe6e)
    _46a4332c0d99._3131ce433186(_ad2598448d19)
    if _e0ab28febe6e:
        if _46a4332c0d99._5192bfb7fb5f(_ad2598448d19):
            _7ed2bf2e2b98 = _c628641ef769._f65f2096c490(_ad2598448d19)
            _779095aa4de9._d9c193ad708e(f"Config of pretrained embedding used {_7ed2bf2e2b98}")
            _779095aa4de9._d9c193ad708e(f"Loading {_e0ab28febe6e} embeddings from {_ad2598448d19}")
            _e2b481b280fe = _c72b01caf957._f65f2096c490(
                _ad1c28656c1b=_ad2598448d19)
            _8e2bbb5c8cad = _5a55be9533f3._f65f2096c490(
                _ad1c28656c1b=_ad2598448d19)
        else:
            _7ed2bf2e2b98 = _c628641ef769._f65f2096c490(_e0ab28febe6e)
            _779095aa4de9._d9c193ad708e(f"config of pretrained embedding used {_7ed2bf2e2b98}")
            _779095aa4de9._d9c193ad708e(f"Downloading {_e0ab28febe6e} embeddings from transformers package")
            _e2b481b280fe = _c72b01caf957._f65f2096c490(
                _ad1c28656c1b=_e0ab28febe6e)
            _8e2bbb5c8cad = _5a55be9533f3._f65f2096c490(
                _ad1c28656c1b=_e0ab28febe6e)
            _e2b481b280fe._87ccefb7a48c(_ad2598448d19)
            _8e2bbb5c8cad._87ccefb7a48c(_ad2598448d19)

    # Test Dataset
    _d378f40670cb = os._2b6fce35cff6._d9c2565fb2dd(_92c2d6b9183f._36f3968b95ef._6fc11a8a9bae, _92c2d6b9183f._4889da4620fa._ab4e3db9436b._6fc11a8a9bae)
    _1184ed3eb769 = os._2b6fce35cff6._d9c2565fb2dd(_92c2d6b9183f._36f3968b95ef._6fc11a8a9bae, _92c2d6b9183f._4889da4620fa._875ebef5c428._6fc11a8a9bae)
    _142cc791d341 = os._2b6fce35cff6._d9c2565fb2dd(_92c2d6b9183f._36f3968b95ef._6fc11a8a9bae, _92c2d6b9183f._4889da4620fa._89f3520816ad._6fc11a8a9bae)
    _5fcf83b6784b = _92c2d6b9183f._4889da4620fa._5fcf83b6784b
    _71f3c0aa209c = _4d3ccb78f590(_6fc11a8a9bae=_d378f40670cb, _aa767a4e1743=_5fcf83b6784b,
                                                  _779095aa4de9=_779095aa4de9, _05cf68e4f3b1=_8e2bbb5c8cad,
                                                  _05a443c0acb7=300,
                                                  _211357986565="config/classes_config.json",
                                                  _46fa965438af=_6a20e858b0f9)
    _e379bd1b093b = _4d3ccb78f590(_6fc11a8a9bae=_1184ed3eb769, _aa767a4e1743=_5fcf83b6784b,
                                                _779095aa4de9=_779095aa4de9, _05cf68e4f3b1=_8e2bbb5c8cad,
                                                _05a443c0acb7=300,
                                                _211357986565="config/classes_config.json",
                                                _46fa965438af=_e4217414592b)
    _8b9e61721e04 = _4d3ccb78f590(_6fc11a8a9bae=_142cc791d341, _aa767a4e1743=_5fcf83b6784b,
                                                 _779095aa4de9=_779095aa4de9, _05cf68e4f3b1=_8e2bbb5c8cad,
                                                 _05a443c0acb7=300,
                                                 _211357986565="config/classes_config.json",
                                                 _46fa965438af=_e4217414592b)

    _779095aa4de9._d9c193ad708e(f"Number of training data samples {_71f3c0aa209c._de7077fe2eb9()}")
    _779095aa4de9._d9c193ad708e(f"Number of validation samples {_e379bd1b093b._de7077fe2eb9()}")
    _779095aa4de9._d9c193ad708e(f"Number of test samples {_8b9e61721e04._de7077fe2eb9()}")

    _2d1fa25b8e70 = _71f3c0aa209c._306227e87662()
    _9f65f03e5e94 = [_71f3c0aa209c._614522e69aec(_b913e8532029) for _b913e8532029 in _71f3c0aa209c._9f65f03e5e94._585d47d35773()]
    _f88ab8f0f363 = _71f3c0aa209c._f88ab8f0f363
    _779095aa4de9._d9c193ad708e(f"{_2d1fa25b8e70} classes in training data with classes {_9f65f03e5e94} and weights {_f88ab8f0f363}")

    _861ddc35651f = _64d2b07685db(_37c52ead944e=_92c2d6b9183f._10bc379327a1._37c52ead944e,
                                                              _71f3c0aa209c=_71f3c0aa209c,
                                                              _e379bd1b093b=_e379bd1b093b,
                                                              _8b9e61721e04=_8b9e61721e04)

    # Load Custom Model
    _10bc379327a1 = _2fdabb7127a0(_eef81cdb7640=_e2b481b280fe,
                                             _2d1fa25b8e70=_2d1fa25b8e70,
                                             _118bb7aa9d7f=_92c2d6b9183f._10bc379327a1._e229d6a8123b,
                                             _28db01476124=_92c2d6b9183f._10bc379327a1._28db01476124,
                                             _f88ab8f0f363=_f88ab8f0f363,
                                             _5bdee1e8c255=_5bdee1e8c255,
                                             _8fecd512c389=2,
                                             _d54fa63aab79="weighted_cross_entropy",
                                             _53766cb0c39a=3,
                                             _c92cd5f7d897="relu",
                                             _7813464850f4=_6a20e858b0f9)
    if _042fc9057e28._60b68761a02a() is _e4217414592b:
        _779095aa4de9._d9c193ad708e(f"Setting model to cuda:{_999176ed09e0}")
        _10bc379327a1 = _10bc379327a1._9e299989f6fa(_62d459093f5f=f"cuda:{_999176ed09e0}")
    _b4aa4ab27aff = _44033133d456()
    for _60d72a0932ff, _96e88f086ba0 in _10bc379327a1._a67e58497043():
        # print(f"Param {name} device {p.data.get_device()}")
        if not _96e88f086ba0._dbdff9eb2a49:
            _b4aa4ab27aff._43783fd97eda(_96e88f086ba0)
    _90e1165580e3 = _46f7123a22d8(_3524ad8ab36e=_b4aa4ab27aff)
    # callbacks
    # fit model
    _82cd23c06e7a = _92c2d6b9183f._36f3968b95ef._82cd23c06e7a
    # Create an instance of the CustomMetricsCallback
    _cbe270c4045f = 'gpu' if _f0577c765eb3._db5d67da5031._4b89cef3da17() else 'cpu'
    _668e65e281cf = {}
    # model_config_name = props.app.model_config_name
    _668e65e281cf['model_name'] = _82cd23c06e7a
    # metrics_summary_dict['config'] = yaml_config_data
    _668e65e281cf['max_epochs'] = _92c2d6b9183f._10bc379327a1._f2c34f4227a8
    _9e026a0e768a = _d0288ee50e07._7dd356ca4f3d(_6e39a04d9f82=1)
    _dbe3de224912 = "metrics/{}"._5f76f536fe9a(_82cd23c06e7a)
    _728b3daf14fa = "epoch_training_metrics.csv"
    _08a9d3edf0ec = "model_training_summary_metrics.csv"
    _35afeab2e9e2 = _4ff2a70e50ac(_779095aa4de9,
                                   _9e026a0e768a=_9e026a0e768a,
                                   _668e65e281cf=_668e65e281cf,
                                   _56dc291e3a40=_dbe3de224912,
                                   _49db0d8d087d=_728b3daf14fa,
                                   _50e88dd21ce8=_08a9d3edf0ec)
    _cca541265821 = os._2b6fce35cff6._d9c2565fb2dd(_92c2d6b9183f._36f3968b95ef._fa6eca820e99, _82cd23c06e7a)
    _046bae342221 = _d0288ee50e07._3d603b5443d0(_6a26777c28ef=_cca541265821,
                                                    _f9c89c87f7a6="{epoch}-{train_loss:.2f}-{val_loss:.2f}",
                                                    _3bd2db20cc19=2,
                                                    _76360487f7f8=_6a20e858b0f9,
                                                    _197c8bbcd8b3="val_loss",
                                                    _336402cde054="min")
    _7ea18ac509e7 = _d0288ee50e07._285756bbf16f(_197c8bbcd8b3="val_loss",
                                                      _336402cde054="min",
                                                      _40ec61242a40=0.001,
                                                      _2cd072f3a91f=5)
    _cbd7b9773eef = _d0288ee50e07._549ba5a533c6(_6bdf205b91c5='step')

    _3ab9524c276b = _42795800b4ba(_61935f13aaaf=_cbe270c4045f,
                    _7e45f85c318f=-1 if _cbe270c4045f == "gpu" else 1,
                    _b25616402d7f=_b25616402d7f,
                    _20bf5573d3af=_90e1165580e3 if _cbe270c4045f == "gpu" else "auto",
                    # strategy="ddp",
                    _f2c34f4227a8=_92c2d6b9183f._10bc379327a1._f2c34f4227a8,
                    _abb722409358=_6a20e858b0f9,
                    _465e6b2867b3=_6a20e858b0f9,
                    _d7dd30f6ec38=_6a20e858b0f9,
                    _ac41cc8aff6b=8,
                    _70cb3d4bf1b9=0.1,
                    _0343bee04c32=0.1,
                    _8b0082189c60='16-mixed',
                    _d0288ee50e07=[_35afeab2e9e2, _046bae342221, _7ea18ac509e7, _cbd7b9773eef],
                    )
    
    _3ab9524c276b._20bf5573d3af._b25616402d7f=_b25616402d7f

    _6c1e9f5479a7 = os._2b6fce35cff6._d9c2565fb2dd(_cca541265821, "last.ckpt")
    _779095aa4de9._d9c193ad708e(f"Model : {_10bc379327a1}")

    
    if os._2b6fce35cff6._fa79e23c6fe3(_6c1e9f5479a7):
        _3ab9524c276b._14fd2a259af7(_10bc379327a1, _b887311ded3b=_861ddc35651f, _480cbc07b32a=_6c1e9f5479a7, )
    else:
        _3ab9524c276b._14fd2a259af7(_10bc379327a1, _b887311ded3b=_861ddc35651f, )


if __name__ == "__main__":
    _662db1dde60a = _ba69858c84e0._9757d2d0618f(_1a635dd94e68=
                                     'App to train and manage language identification models')
    _662db1dde60a._1c4a04437ee5('--config_file_path', _169bd4379fa0=_369cccfc5f2a,
                        _616752659ecb=_6a20e858b0f9, _d585b10079f5='Pass the config file path')
    _662db1dde60a._1c4a04437ee5('--num_nodes', _169bd4379fa0=_bd0b04d1fa0d, _29a2abcc59c3=1,
                        _616752659ecb=_e4217414592b, _d585b10079f5='Pass the num gpus')
    _662db1dde60a._1c4a04437ee5('--local-rank', _169bd4379fa0=_bd0b04d1fa0d,
                        _616752659ecb=_e4217414592b, _d585b10079f5='Pass the gpu rank')
    _662db1dde60a._1c4a04437ee5('--backend', _169bd4379fa0=_369cccfc5f2a, _29a2abcc59c3="gloo", _fe7fcd6a7459=['gloo','mpi','nccl'],
                        _616752659ecb=_e4217414592b, _d585b10079f5='optional gloo, mpi or nccl for distributed training')
    try:
        _f2cf10bde68c = _662db1dde60a._cc5599ae200f()
        _bfc82cb2f836(_f2cf10bde68c)
    except _ba69858c84e0._7f2bdd4518b0 as _cbca4709c537:
        _cb6c0edb49e7(f"Error: {_cbca4709c537}")
        _662db1dde60a._503aeeb67281()
