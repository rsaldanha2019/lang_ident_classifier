# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : lang_ident_app
# @Time             : 18/12/23 8:59 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import socket
import cpuinfo
import argparse
from collections import OrderedDict
import os
from typing import Any, Dict
from lang_ident_classifier.language.callbacks.custom_log_callback import LoggingCallback
import lightning as pl
import torch
from torch import Tensor
from lightning import Trainer
from lightning.pytorch import callbacks
from transformers import AutoConfig, AutoModel, AutoTokenizer
from lightning.pytorch.strategies import FSDPStrategy
from lightning.pytorch.strategies.fsdp import FullyShardedDataParallel
from torch.distributed.fsdp import StateDictType, FullStateDictConfig
from torch.distributed.fsdp.api import FullOptimStateDictConfig
from torch.optim import Optimizer
from lightning.pytorch.plugins.environments import SLURMEnvironment
from lang_ident_classifier.language.dataset.language_identification_data_module import LanguageIdentificationDataModule
from lang_ident_classifier.language.net.language_identification_classifier import LanguageIdentificationClassifier
from lang_ident_classifier.language.utils.property_utils import PropertyUtils
from lang_ident_classifier.language.utils.log_utils import LogUtils
from lang_ident_classifier.language.utils.file_dir_utils import FileDirUtils
from lang_ident_classifier.language.dataset.language_identification_dataset import LanguageIdentificationDataset
pl.seed_everything(20)

    
class CustomFSDPStrategy(FSDPStrategy):
    def __init__(self, ig_params):
        super().__init__()
        # self.cpu_offload = False
        self.kwargs = {"use_orig_params": True, "ignored_parameters": ig_params}

    @property
    def lightning_restore_optimizer(self) -> bool:
        """Override to disable Lightning restoring optimizers/schedulers.

        This is useful for plugins which manage restoring optimizers/schedulers.
        """
        return False

    def lightning_module_state_dict(self) -> Dict[str, Any]:
        assert self.model is not None

        with FullyShardedDataParallel.state_dict_type(
                module=self.model,
                state_dict_type=StateDictType.FULL_STATE_DICT,
                state_dict_config=FullStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
                optim_state_dict_config=FullOptimStateDictConfig(offload_to_cpu=(self.world_size > 1), rank0_only=True),
        ):
            # state_dict = self.model.state_dict()
            state_dict = OrderedDict([(k.replace("_forward_module.",""), v) if k.__contains__('_forward_module') else (k, v)
                                      for k, v in self.model.state_dict().items()])

            # for key in state_dict:
            #     print(f"state dict {key} :: {state_dict[key].shape}")
            return state_dict

    def optimizer_state(self, optimizer: Optimizer) -> Dict[str, Tensor]:
        return FullyShardedDataParallel.full_optim_state_dict(self.model, optim=optimizer, rank0_only=True)



def adjust_local_gpu_rank():
    cuda_device = torch.cuda.device_count()
    local_rank = 0
    if cuda_device == 1:
        local_rank = os.environ.get('CUDA_VISIBLE_DEVICES', 0)
    else:
        local_rank = os.environ.get('LOCAL_RANK', '0')
    return local_rank

def get_device_info():
    device_dict = dict()
    num_nodes = 1
    if SLURMEnvironment.detect() and torch.cuda.is_available():
        device_dict['gpu_world_size'] = str(SLURMEnvironment.world_size(pl))
        device_dict['gpu_global_rank'] = str(SLURMEnvironment.global_rank(pl))
        device_dict['gpu_local_rank'] = str(SLURMEnvironment.local_rank(pl))
    elif SLURMEnvironment.detect() is False and torch.cuda.is_available():
        device_dict['gpu_world_size'] = str(os.environ.get('WORLD_SIZE', '1')) # get WORLD_SIZE or set value to 1
        device_dict['gpu_global_rank'] = str(os.environ.get('RANK', '0'))
        device_dict['gpu_local_rank'] = str(adjust_local_gpu_rank())
    elif SLURMEnvironment.detect() and torch.cuda.is_available() is False:
        device_dict['gpu_world_size'] = str(SLURMEnvironment.world_size(pl))
        device_dict['gpu_global_rank'] = str(SLURMEnvironment.global_rank(pl))
        device_dict['gpu_local_rank'] = -1
    else:
        device_dict['gpu_world_size'] = -1
        device_dict['gpu_global_rank'] = -1
        device_dict['gpu_local_rank'] = -1
    device_dict['node_name'] = socket.gethostname()
    device_dict['cpu_info'] = "CPU :: {} COUNT :: {}".format(cpuinfo.get_cpu_info()['brand_raw'], os.cpu_count())
    return device_dict


def main(args) -> None:
    """
    Launch method for the lang ident classifier app
    :param args: takes command line arguments
    :return: None
    """
    local_rank = 0
    if SLURMEnvironment.detect() is False and torch.cuda.is_available():
        local_rank = int(adjust_local_gpu_rank())
        global_rank = int(os.environ.get('RANK', '0'))
        world_size = int(os.environ.get('WORLD_SIZE', '1'))
        torch.distributed.init_process_group(backend=args.backend, rank=global_rank, world_size=world_size)
    pretrained_embedding_tokenizer = None
    pretrained_embedding = None
    pu = PropertyUtils()
    lu = LogUtils()
    fdu = FileDirUtils()
    props = pu.get_yaml_config_properties(args.config_file_path)
    log = lu.get_time_rotated_log(props)
    device_dict = get_device_info()
    num_nodes = args.num_nodes
    log.info(f"App initialized!! on {device_dict}")

    # Load pretrained embedding
    pretrained_embedding_name = props.model.pretrained_embedding_name
    pretrained_embedding_model_dir_path = os.path.join(props.app.pretrained_embeddings_dir,
                                                       pretrained_embedding_name)
    fdu.create_dir(pretrained_embedding_model_dir_path)
    if pretrained_embedding_name:
        if fdu.is_dir_empty(pretrained_embedding_model_dir_path):
            pretrained_embedding_config = AutoConfig.from_pretrained(pretrained_embedding_model_dir_path)
            log.info(f"Config of pretrained embedding used {pretrained_embedding_config}")
            log.info(f"Loading {pretrained_embedding_name} embeddings from {pretrained_embedding_model_dir_path}")
            pretrained_embedding = AutoModel.from_pretrained(
                pretrained_model_name_or_path=pretrained_embedding_model_dir_path)
            pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                pretrained_model_name_or_path=pretrained_embedding_model_dir_path)
        else:
            pretrained_embedding_config = AutoConfig.from_pretrained(pretrained_embedding_name)
            log.info(f"config of pretrained embedding used {pretrained_embedding_config}")
            log.info(f"Downloading {pretrained_embedding_name} embeddings from transformers package")
            pretrained_embedding = AutoModel.from_pretrained(
                pretrained_model_name_or_path=pretrained_embedding_name)
            pretrained_embedding_tokenizer = AutoTokenizer.from_pretrained(
                pretrained_model_name_or_path=pretrained_embedding_name)
            pretrained_embedding.save_pretrained(pretrained_embedding_model_dir_path)
            pretrained_embedding_tokenizer.save_pretrained(pretrained_embedding_model_dir_path)

    # Test Dataset
    train_data_dir = os.path.join(props.app.data_dir, props.dataset.train.data_dir)
    val_data_dir = os.path.join(props.app.data_dir, props.dataset.val.data_dir)
    test_data_dir = os.path.join(props.app.data_dir, props.dataset.test.data_dir)
    files_have_header = props.dataset.files_have_header
    train_dataset = LanguageIdentificationDataset(data_dir=train_data_dir, files_have__header=files_have_header,
                                                  log=log, embedding_tokenizer=pretrained_embedding_tokenizer,
                                                  max_output_length=300,
                                                  classes_config_path="config/classes_config.json",
                                                  is_train=True)
    val_dataset = LanguageIdentificationDataset(data_dir=val_data_dir, files_have__header=files_have_header,
                                                log=log, embedding_tokenizer=pretrained_embedding_tokenizer,
                                                max_output_length=300,
                                                classes_config_path="config/classes_config.json",
                                                is_train=False)
    test_dataset = LanguageIdentificationDataset(data_dir=test_data_dir, files_have__header=files_have_header,
                                                 log=log, embedding_tokenizer=pretrained_embedding_tokenizer,
                                                 max_output_length=300,
                                                 classes_config_path="config/classes_config.json",
                                                 is_train=False)

    log.info(f"Number of training data samples {train_dataset.__len__()}")
    log.info(f"Number of validation samples {val_dataset.__len__()}")
    log.info(f"Number of test samples {test_dataset.__len__()}")

    num_classes = train_dataset.get_num_classes()
    classes = [train_dataset._get_lang_code_from_class_id(key) for key in train_dataset.classes.keys()]
    class_weights = train_dataset.class_weights
    log.info(f"{num_classes} classes in training data with classes {classes} and weights {class_weights}")

    lang_ident_data_module = LanguageIdentificationDataModule(batch_size=props.model.batch_size,
                                                              train_dataset=train_dataset,
                                                              val_dataset=val_dataset,
                                                              test_dataset=test_dataset)

    # Load Custom Model
    model = LanguageIdentificationClassifier(pretrained_embedding_model=pretrained_embedding,
                                             num_classes=num_classes,
                                             lr=props.model.learning_rate,
                                             optimizer=props.model.optimizer,
                                             class_weights=class_weights,
                                             device_dict=device_dict,
                                             num_embedding_layers_unfrozen=2,
                                             loss_type="weighted_cross_entropy",
                                             num_fc_layers=3,
                                             activation_function_for_layer="relu",
                                             add_dropout_after_embedding=True)
    if SLURMEnvironment.detect() is False:
        log.info(f"Setting model to cuda:{local_rank}")
        model = model.to(device=f"cuda:{local_rank}")
    ignored_params = list()
    for name, p in model.named_parameters():
        # print(f"Param {name} device {p.data.get_device()}")
        if not p.requires_grad:
            ignored_params.append(p)
    custom_fsdp = CustomFSDPStrategy(ig_params=ignored_params)
    # callbacks
    # fit model
    model_config_name = props.app.model_config_name
    # Create an instance of the CustomMetricsCallback
    DEVICE = 'gpu' if torch.cuda.is_available() else 'cpu'
    metrics_summary_dict = {}
    # model_config_name = props.app.model_config_name
    metrics_summary_dict['model_name'] = model_config_name
    # metrics_summary_dict['config'] = yaml_config_data
    metrics_summary_dict['max_epochs'] = props.model.max_epochs
    model_summary_callback = callbacks.ModelSummary(max_depth=1)
    METRICS_DIR = "metrics/{}".format(model_config_name)
    MODEL_EPOCH_METRICS_FILE = "epoch_training_metrics.csv"
    MODEL_METRICS_SUMMARY_FILE = "model_training_summary_metrics.csv"
    logging_callback = LoggingCallback(log,
                                   model_summary_callback=model_summary_callback,
                                   metrics_summary_dict=metrics_summary_dict,
                                   metrics_dir=METRICS_DIR,
                                   model_epoch_metrics_file=MODEL_EPOCH_METRICS_FILE,
                                   model_metrics_summary_file=MODEL_METRICS_SUMMARY_FILE)
    CKPTS_DIR = os.path.join(props.app.checkpoints_dir, model_config_name)
    model_ckpt_callback = callbacks.ModelCheckpoint(dirpath=CKPTS_DIR,
                                                    filename="{epoch}-{train_loss:.2f}-{val_loss:.2f}",
                                                    save_top_k=2,
                                                    save_last=True,
                                                    monitor="val_loss",
                                                    mode="min")
    early_stopping_callback = callbacks.EarlyStopping(monitor="val_loss",
                                                      mode="min",
                                                      min_delta=0.001,
                                                      patience=5)
    lr_monitor_callback = callbacks.LearningRateMonitor(logging_interval='step')

    trainer = Trainer(accelerator=DEVICE,
                    devices=-1 if DEVICE == "gpu" else 1,
                    num_nodes=num_nodes,
                    strategy=custom_fsdp if DEVICE == "gpu" else "auto",
                    # strategy="ddp",
                    max_epochs=props.model.max_epochs,
                    deterministic=True,
                    enable_progress_bar=True,
                    enable_model_summary=True,
                    accumulate_grad_batches=8,
                    limit_train_batches=0.1,
                    limit_val_batches=0.1,
                    precision='16-mixed',
                    callbacks=[logging_callback, model_ckpt_callback, early_stopping_callback, lr_monitor_callback],
                    )
    
    trainer.strategy.num_nodes=num_nodes

    checkpoint_path = os.path.join(CKPTS_DIR, "last.ckpt")
    log.info(f"Model : {model}")

    
    if os.path.exists(checkpoint_path):
        trainer.fit(model, datamodule=lang_ident_data_module, ckpt_path=checkpoint_path, )
    else:
        trainer.fit(model, datamodule=lang_ident_data_module, )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=
                                     'App to train and manage language identification models')
    parser.add_argument('--config_file_path', type=str,
                        required=True, help='Pass the config file path')
    parser.add_argument('--num_nodes', type=int, default=1,
                        required=False, help='Pass the num gpus')
    parser.add_argument('--local-rank', type=int,
                        required=False, help='Pass the gpu rank')
    parser.add_argument('--backend', type=str, default="gloo", choices=['gloo','mpi','nccl'],
                        required=False, help='optional gloo, mpi or nccl for distributed training')
    try:
        parsed_args = parser.parse_args()
        main(parsed_args)
    except argparse.ArgumentError as e:
        print(f"Error: {e}")
        parser.print_help()
