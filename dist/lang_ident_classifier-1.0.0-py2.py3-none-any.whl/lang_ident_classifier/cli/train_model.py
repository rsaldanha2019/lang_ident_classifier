# -*- coding: utf-8 -*-
"""
---------------------------------------------------------
# @Project          : pylight_lang_ident_classifier
# @File             : lang_ident_app
# @Time             : 18/12/23 8:59 am IST
# @CodeCheck        : 
14 11 12 11 42 15 14 54 23 32 34 42 21 11 23 33 11 14 31 11 43 14 42 11 23 13 24 42
# Contact the author if you intend to use this package
# for commercial purposes
---------------------------------------------------------
"""
import _1c89b48ce9e8
import _12872107172e
import _d969f69fe73d
from collections import _575c6340bbd8
import os
from typing import _a93d72d9a966, _fac05b59f221
from _1588357995f1._36b769e19c72._baaf8c2b4920._bd3a240660c8 import _d940157bf0f0
import _08dbb80e29f1 as _a5e5d1536772
import _8cd3401da3c3
from _8cd3401da3c3 import _11be6b361859
from _08dbb80e29f1 import _f92b30325e55
from _08dbb80e29f1._3120ce614748 import _baaf8c2b4920
from _3ae03921dd36 import _6ff4248c6a82, _8cad3618e565, _6d1977780343
from _08dbb80e29f1._3120ce614748._80b12e34852f import _fc7dd79572af
from _08dbb80e29f1._3120ce614748._80b12e34852f._ff0ca2394873 import _08717e9aaef4
from _8cd3401da3c3._6c0ee12b8b16._ff0ca2394873 import _b5f4673e8aae, _82a113d2089a
from _8cd3401da3c3._6c0ee12b8b16._ff0ca2394873._311529bc7b85 import _6f0e8cb09a88
from _8cd3401da3c3._0c1bcd340799 import _f4e7eda1c025
from _08dbb80e29f1._3120ce614748._ffd296ee23b8._42e66a86a101 import _33b31b40092f
from _1588357995f1._36b769e19c72._eccf001134ae._d82c30a45cb0 import _f0b3b956decf
from _1588357995f1._36b769e19c72._fdf536b45e82._8130e159fcbc import _daade7fb3537
from _1588357995f1._36b769e19c72._840a094b1319._b7942bf9759e import _3ab3cd1ae0b1
from _1588357995f1._36b769e19c72._840a094b1319._d929a9815fd5 import _527a3cc9e49e
from _1588357995f1._36b769e19c72._840a094b1319._ad18902043ff import _9b88d73ccf3b
from _1588357995f1._36b769e19c72._eccf001134ae._46eee3df4b42 import _ef7b30e82377
_a5e5d1536772._1fff1d89ada2(20)

    
class _d164233765d1(_fc7dd79572af):
    def _7264cd64928e(self, _1a7f2115cd4a):
        _efadde982bf1()._e6246f902400()
        # self.cpu_offload = False
        self._f7e4aa35c394 = {"use_orig_params": _519fa2e42b45, "ignored_parameters": _1a7f2115cd4a}

    @_b3cf903f6651
    def _58374ca152c5(self) -> _5c52e73566c4:
        """Override to disable Lightning restoring optimizers/schedulers.

        This is useful for plugins which manage restoring optimizers/schedulers.
        """
        return _a78967c33116

    def _79d67c596f53(self) -> _fac05b59f221[_9c479a52a7fc, _a93d72d9a966]:
        assert self._950f860695c7 is not _5dcfe3c04b49

        with _08717e9aaef4._a2104d16c823(
                _acb67c818e40=self._950f860695c7,
                _a2104d16c823=_b5f4673e8aae._8dfe6c9660f2,
                _0221bac7a2d1=_82a113d2089a(_44f4acec2f1c=(self._3c32ae15a44e > 1), _5a201310c3c0=_519fa2e42b45),
                _151b76adab55=_6f0e8cb09a88(_44f4acec2f1c=(self._3c32ae15a44e > 1), _5a201310c3c0=_519fa2e42b45),
        ):
            # state_dict = self.model.state_dict()
            _facbbb6417ca = _575c6340bbd8([(_3e9e1995dce9._1c48115710dd("_forward_module.",""), _9f0efc99e199) if _3e9e1995dce9._1fa179ec4030('_forward_module') else (_3e9e1995dce9, _9f0efc99e199)
                                      for _3e9e1995dce9, _9f0efc99e199 in self._950f860695c7._facbbb6417ca()._7be277fc5dc3()])

            # for key in state_dict:
            #     print(f"state dict {key} :: {state_dict[key].shape}")
            return _facbbb6417ca

    def _4557b8ce98c4(self, _c685e375bfa8: _f4e7eda1c025) -> _fac05b59f221[_9c479a52a7fc, _11be6b361859]:
        return _08717e9aaef4._3fa73fb6b4de(self._950f860695c7, _0c1bcd340799=_c685e375bfa8, _5a201310c3c0=_519fa2e42b45)



def _ba4d736c2b3b():
    _9225e2ee5ac3 = _8cd3401da3c3._5a7a7a15515a._325774130f70()
    _d900c39c8167 = 0
    if _9225e2ee5ac3 == 1:
        _d900c39c8167 = os._d6cfd1fb6b80._69fe05e1a1c7('CUDA_VISIBLE_DEVICES', 0)
    else:
        _d900c39c8167 = os._d6cfd1fb6b80._69fe05e1a1c7('LOCAL_RANK', '0')
    return _d900c39c8167

def _dcb5f66286da():
    _5fb383eee13e = _9c52abbc8d29()
    _cf2065791cb1 = 1
    if _33b31b40092f._5cf4cf1bb494() and _8cd3401da3c3._5a7a7a15515a._fa3744b1e4ed():
        _5fb383eee13e['gpu_world_size'] = _9c479a52a7fc(_33b31b40092f._3c32ae15a44e(_a5e5d1536772))
        _5fb383eee13e['gpu_global_rank'] = _9c479a52a7fc(_33b31b40092f._cb24d10d09fa(_a5e5d1536772))
        _5fb383eee13e['gpu_local_rank'] = _9c479a52a7fc(_33b31b40092f._d900c39c8167(_a5e5d1536772))
    elif _33b31b40092f._5cf4cf1bb494() is _a78967c33116 and _8cd3401da3c3._5a7a7a15515a._fa3744b1e4ed():
        _5fb383eee13e['gpu_world_size'] = _9c479a52a7fc(os._d6cfd1fb6b80._69fe05e1a1c7('WORLD_SIZE', '1')) # get WORLD_SIZE or set value to 1
        _5fb383eee13e['gpu_global_rank'] = _9c479a52a7fc(os._d6cfd1fb6b80._69fe05e1a1c7('RANK', '0'))
        _5fb383eee13e['gpu_local_rank'] = _9c479a52a7fc(_994a45392fc8())
    elif _33b31b40092f._5cf4cf1bb494() and _8cd3401da3c3._5a7a7a15515a._fa3744b1e4ed() is _a78967c33116:
        _5fb383eee13e['gpu_world_size'] = _9c479a52a7fc(_33b31b40092f._3c32ae15a44e(_a5e5d1536772))
        _5fb383eee13e['gpu_global_rank'] = _9c479a52a7fc(_33b31b40092f._cb24d10d09fa(_a5e5d1536772))
        _5fb383eee13e['gpu_local_rank'] = -1
    else:
        _5fb383eee13e['gpu_world_size'] = -1
        _5fb383eee13e['gpu_global_rank'] = -1
        _5fb383eee13e['gpu_local_rank'] = -1
    _5fb383eee13e['node_name'] = _1c89b48ce9e8._1908b58cfd91()
    _5fb383eee13e['cpu_info'] = "CPU :: {} COUNT :: {}"._cd17b039979d(_12872107172e._c646235a44f9()['brand_raw'], os._0fcdca9c25b8())
    return _5fb383eee13e


def _035413860959(_b2f4cd276e40) -> _5dcfe3c04b49:
    """
    Launch method for the lang ident classifier app
    :param args: takes command line arguments
    :return: None
    """
    _d900c39c8167 = 0
    if _33b31b40092f._5cf4cf1bb494() is _a78967c33116 and _8cd3401da3c3._5a7a7a15515a._fa3744b1e4ed():
        _d900c39c8167 = _7a6cab5a6183(_994a45392fc8())
        _cb24d10d09fa = _7a6cab5a6183(os._d6cfd1fb6b80._69fe05e1a1c7('RANK', '0'))
        _3c32ae15a44e = _7a6cab5a6183(os._d6cfd1fb6b80._69fe05e1a1c7('WORLD_SIZE', '1'))
        _8cd3401da3c3._6c0ee12b8b16._8cb69b435e23(_d92966fa78b8=_b2f4cd276e40._d92966fa78b8, _729e6b559d00=_cb24d10d09fa, _3c32ae15a44e=_3c32ae15a44e)
    _7b9720be022a = _5dcfe3c04b49
    _a2b9afa00c21 = _5dcfe3c04b49
    _725b6ba90df4 = _3ab3cd1ae0b1()
    _eca9040347ce = _527a3cc9e49e()
    _74d8123c0678 = _9b88d73ccf3b()
    _0e4726de0cdc = _725b6ba90df4._15d971892e7d(_b2f4cd276e40._b64f3ba8d7b1)
    _2fedf253ee30 = _eca9040347ce._527da83acac9(_0e4726de0cdc)
    _5fb383eee13e = _aca0ccda1bd1()
    _cf2065791cb1 = _b2f4cd276e40._cf2065791cb1
    _2fedf253ee30._68f29e3a1f1b(f"App initialized!! on {_5fb383eee13e}")

    # Load pretrained embedding
    _ec91693394dc = _0e4726de0cdc._950f860695c7._ec91693394dc
    _624f8f75433f = os._5ccc2a5952c3._0c678d8a6902(_0e4726de0cdc._5720863f4192._ef4e3179c71a,
                                                       _ec91693394dc)
    _74d8123c0678._4a7f8b7b7dc0(_624f8f75433f)
    if _ec91693394dc:
        if _74d8123c0678._f3cb68716585(_624f8f75433f):
            _3dc19c4667c6 = _6ff4248c6a82._ce2ea9517037(_624f8f75433f)
            _2fedf253ee30._68f29e3a1f1b(f"Config of pretrained embedding used {_3dc19c4667c6}")
            _2fedf253ee30._68f29e3a1f1b(f"Loading {_ec91693394dc} embeddings from {_624f8f75433f}")
            _a2b9afa00c21 = _8cad3618e565._ce2ea9517037(
                _011eea8849c0=_624f8f75433f)
            _7b9720be022a = _6d1977780343._ce2ea9517037(
                _011eea8849c0=_624f8f75433f)
        else:
            _3dc19c4667c6 = _6ff4248c6a82._ce2ea9517037(_ec91693394dc)
            _2fedf253ee30._68f29e3a1f1b(f"config of pretrained embedding used {_3dc19c4667c6}")
            _2fedf253ee30._68f29e3a1f1b(f"Downloading {_ec91693394dc} embeddings from transformers package")
            _a2b9afa00c21 = _8cad3618e565._ce2ea9517037(
                _011eea8849c0=_ec91693394dc)
            _7b9720be022a = _6d1977780343._ce2ea9517037(
                _011eea8849c0=_ec91693394dc)
            _a2b9afa00c21._9996f0d0ea86(_624f8f75433f)
            _7b9720be022a._9996f0d0ea86(_624f8f75433f)

    # Test Dataset
    _4dee256e881a = os._5ccc2a5952c3._0c678d8a6902(_0e4726de0cdc._5720863f4192._0f0dca538b19, _0e4726de0cdc._eccf001134ae._100cb3e9a776._0f0dca538b19)
    _a13cf8e30118 = os._5ccc2a5952c3._0c678d8a6902(_0e4726de0cdc._5720863f4192._0f0dca538b19, _0e4726de0cdc._eccf001134ae._4d03d0835197._0f0dca538b19)
    _d542d6dd9e86 = os._5ccc2a5952c3._0c678d8a6902(_0e4726de0cdc._5720863f4192._0f0dca538b19, _0e4726de0cdc._eccf001134ae._d90685c7c2c5._0f0dca538b19)
    _8aa564291ba3 = _0e4726de0cdc._eccf001134ae._8aa564291ba3
    _9c59b7183efe = _ef7b30e82377(_0f0dca538b19=_4dee256e881a, _19357b54ee14=_8aa564291ba3,
                                                  _2fedf253ee30=_2fedf253ee30, _c90fb0a6e1dd=_7b9720be022a,
                                                  _eae20be06663=300,
                                                  _1b2290481684="config/classes_config.json",
                                                  _e5f611cc2bd4=_519fa2e42b45)
    _b92586756f10 = _ef7b30e82377(_0f0dca538b19=_a13cf8e30118, _19357b54ee14=_8aa564291ba3,
                                                _2fedf253ee30=_2fedf253ee30, _c90fb0a6e1dd=_7b9720be022a,
                                                _eae20be06663=300,
                                                _1b2290481684="config/classes_config.json",
                                                _e5f611cc2bd4=_a78967c33116)
    _fec7b43907ab = _ef7b30e82377(_0f0dca538b19=_d542d6dd9e86, _19357b54ee14=_8aa564291ba3,
                                                 _2fedf253ee30=_2fedf253ee30, _c90fb0a6e1dd=_7b9720be022a,
                                                 _eae20be06663=300,
                                                 _1b2290481684="config/classes_config.json",
                                                 _e5f611cc2bd4=_a78967c33116)

    _2fedf253ee30._68f29e3a1f1b(f"Number of training data samples {_9c59b7183efe._c9a5f5904b06()}")
    _2fedf253ee30._68f29e3a1f1b(f"Number of validation samples {_b92586756f10._c9a5f5904b06()}")
    _2fedf253ee30._68f29e3a1f1b(f"Number of test samples {_fec7b43907ab._c9a5f5904b06()}")

    _6c437a3cb278 = _9c59b7183efe._82f999ce400b()
    _fa39c0514591 = [_9c59b7183efe._e552cac20ad3(_972e26fdb9ea) for _972e26fdb9ea in _9c59b7183efe._fa39c0514591._a2a07e67ae5d()]
    _cd944a9de272 = _9c59b7183efe._cd944a9de272
    _2fedf253ee30._68f29e3a1f1b(f"{_6c437a3cb278} classes in training data with classes {_fa39c0514591} and weights {_cd944a9de272}")

    _d661504e0268 = _f0b3b956decf(_5a7f02546c21=_0e4726de0cdc._950f860695c7._5a7f02546c21,
                                                              _9c59b7183efe=_9c59b7183efe,
                                                              _b92586756f10=_b92586756f10,
                                                              _fec7b43907ab=_fec7b43907ab)

    # Load Custom Model
    _950f860695c7 = _daade7fb3537(_ad22ddb7751f=_a2b9afa00c21,
                                             _6c437a3cb278=_6c437a3cb278,
                                             _6eb794463026=_0e4726de0cdc._950f860695c7._caf4da0f0b83,
                                             _c685e375bfa8=_0e4726de0cdc._950f860695c7._c685e375bfa8,
                                             _cd944a9de272=_cd944a9de272,
                                             _5fb383eee13e=_5fb383eee13e,
                                             _5095f9bc5917=2,
                                             _eeb6a3bdd3bd="weighted_cross_entropy",
                                             _98c399c6c109=3,
                                             _4ddcb2ece48b="relu",
                                             _75dfed6c5d77=_519fa2e42b45)
    if _33b31b40092f._5cf4cf1bb494() is _a78967c33116:
        _2fedf253ee30._68f29e3a1f1b(f"Setting model to cuda:{_d900c39c8167}")
        _950f860695c7 = _950f860695c7._24800e9dc697(_d1d70864718c=f"cuda:{_d900c39c8167}")
    _aead07920765 = _5815e32d8fdc()
    for _b76d90de93f7, _bb66499179af in _950f860695c7._b3b8f02b8c5a():
        # print(f"Param {name} device {p.data.get_device()}")
        if not _bb66499179af._8b1b14d86e7e:
            _aead07920765._209f9560f54d(_bb66499179af)
    _607e90b83829 = _98c2be06253b(_1a7f2115cd4a=_aead07920765)
    # callbacks
    # fit model
    _26e7a85caced = _0e4726de0cdc._5720863f4192._26e7a85caced
    # Create an instance of the CustomMetricsCallback
    _c9b60e3150b7 = 'gpu' if _8cd3401da3c3._5a7a7a15515a._fa3744b1e4ed() else 'cpu'
    _ede1219fe040 = {}
    # model_config_name = props.app.model_config_name
    _ede1219fe040['model_name'] = _26e7a85caced
    # metrics_summary_dict['config'] = yaml_config_data
    _ede1219fe040['max_epochs'] = _0e4726de0cdc._950f860695c7._fb272679079a
    _e31391ff0629 = _baaf8c2b4920._618c1c8f678f(_e565406011a4=1)
    _396d256e7a7e = "metrics/{}"._cd17b039979d(_26e7a85caced)
    _9ee858810459 = "epoch_training_metrics.csv"
    _8e5dd36b2b20 = "model_training_summary_metrics.csv"
    _960e002463db = _d940157bf0f0(_2fedf253ee30,
                                   _e31391ff0629=_e31391ff0629,
                                   _ede1219fe040=_ede1219fe040,
                                   _9f640366ac5e=_396d256e7a7e,
                                   _cf2381756856=_9ee858810459,
                                   _d03e935cdddb=_8e5dd36b2b20)
    _7075a5a19bb4 = os._5ccc2a5952c3._0c678d8a6902(_0e4726de0cdc._5720863f4192._cacace660096, _26e7a85caced)
    _47e37cc73941 = _baaf8c2b4920._3cd6e297aaa9(_3332a7cf7d02=_7075a5a19bb4,
                                                    _55e1bfed3513="{epoch}-{train_loss:.2f}-{val_loss:.2f}",
                                                    _12f8ffb00008=2,
                                                    _1396f04a2e36=_519fa2e42b45,
                                                    _43ed35351807="val_loss",
                                                    _9ee9df43bd5f="min")
    _a1a94ec7f474 = _baaf8c2b4920._4e252543039d(_43ed35351807="val_loss",
                                                      _9ee9df43bd5f="min",
                                                      _a4033b85cb2d=0.001,
                                                      _55a9db7eb86c=5)
    _5cf29e7fdf38 = _baaf8c2b4920._4dbcace5bcc3(_b70f476594f0='step')

    _9550510e085a = _f92b30325e55(_82537482d560=_c9b60e3150b7,
                    _bd8f6c3b801c=-1 if _c9b60e3150b7 == "gpu" else 1,
                    _cf2065791cb1=_cf2065791cb1,
                    _4e10b1108a9f=_607e90b83829 if _c9b60e3150b7 == "gpu" else "auto",
                    # strategy="ddp",
                    _fb272679079a=_0e4726de0cdc._950f860695c7._fb272679079a,
                    _95a3812166ce=_519fa2e42b45,
                    _92404a103917=_519fa2e42b45,
                    _158f24b8b40d=_519fa2e42b45,
                    _60ab175a9e24=8,
                    _baa05d4a09f6=0.1,
                    _cf5126f86c57=0.1,
                    _1d21fc9b36c0='16-mixed',
                    _baaf8c2b4920=[_960e002463db, _47e37cc73941, _a1a94ec7f474, _5cf29e7fdf38],
                    )
    
    _9550510e085a._4e10b1108a9f._cf2065791cb1=_cf2065791cb1

    _ed100ac00a87 = os._5ccc2a5952c3._0c678d8a6902(_7075a5a19bb4, "last.ckpt")
    _2fedf253ee30._68f29e3a1f1b(f"Model : {_950f860695c7}")

    
    if os._5ccc2a5952c3._c663fbd25928(_ed100ac00a87):
        _9550510e085a._a41c81acd8db(_950f860695c7, _568c6826a1a0=_d661504e0268, _6ccf381ccb8d=_ed100ac00a87, )
    else:
        _9550510e085a._a41c81acd8db(_950f860695c7, _568c6826a1a0=_d661504e0268, )


if __name__ == "__main__":
    _adceac80b6c8 = _d969f69fe73d._e68f7561efd4(_08c7d00cc8d4=
                                     'App to train and manage language identification models')
    _adceac80b6c8._a0fd890e787f('--config_file_path', _ea7304d58f49=_9c479a52a7fc,
                        _a4671db35de7=_519fa2e42b45, _c525fff818bd='Pass the config file path')
    _adceac80b6c8._a0fd890e787f('--num_nodes', _ea7304d58f49=_7a6cab5a6183, _5308509eb4b8=1,
                        _a4671db35de7=_a78967c33116, _c525fff818bd='Pass the num gpus')
    _adceac80b6c8._a0fd890e787f('--local-rank', _ea7304d58f49=_7a6cab5a6183,
                        _a4671db35de7=_a78967c33116, _c525fff818bd='Pass the gpu rank')
    _adceac80b6c8._a0fd890e787f('--backend', _ea7304d58f49=_9c479a52a7fc, _5308509eb4b8="gloo", _3aa377d01294=['gloo','mpi','nccl'],
                        _a4671db35de7=_a78967c33116, _c525fff818bd='optional gloo, mpi or nccl for distributed training')
    try:
        _ef32bb391486 = _adceac80b6c8._687e820c2ef2()
        _522a706800ba(_ef32bb391486)
    except _d969f69fe73d._73bb4a17627a as _44e8878042c2:
        _65c21dbc4b4d(f"Error: {_44e8878042c2}")
        _adceac80b6c8._7502f1ee9ab6()
