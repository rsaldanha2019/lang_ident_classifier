#!/usr/bin/env python3
import sys, hashlib, marshal, base64

_enc = base64.b64decode('xIqbXjXjvKZhEro2015VyJ8cERsL8MBtrlnK90gx1aHd5tjCgQsQur4cCtq0IAGBRaKWj+4jP7h6rXT+/oJl4E5Qm9zyoj9U2sMr0DUvc9KII9AYqKPV8Ve98UgDOKqbzAUvu5SfEvQRrJqHBx/auWYHyMcROx2S9GDOPnlPMqzsc9aGxmFarZb9BSk5/RQVPD1thg45KJuMxxywXqJLCK7h37SbltOyo/pHxIt0PYwiZwr+pDIGVtEyUmwf71e2OGA2ByIvN3GICbe+7ieAJc5LuOUbzvb9amAHbmzdGZqvW80I3K5burndJWQMCWEX6p7wNWy4Gp5G3jCLOXw2WTHH6tANqiOqSQ==')
_nonce = base64.b64decode('8n57aR8lIWO9eQze')
_tag = base64.b64decode('JYn0SvRjv/ViLwn/8BityA==')

def _sha_stream(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

h = hashlib.sha256()
h.update(b"__main__|")
h.update(repr(globals().get("__file__", "")).encode())
seed = h.digest()

km = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(seed + _nonce).digest(),
    _nonce,
    300000,
    32
)

blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(km + b"blob").digest(),
    _nonce,
    60000,
    32
)

if hashlib.sha256(blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_stream(blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals(), globals())
