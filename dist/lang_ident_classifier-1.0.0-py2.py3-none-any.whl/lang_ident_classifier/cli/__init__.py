# lang_ident_classifier/cli/__init__.py

# package init left intentionally light-weight
_b74d5ad1b8c8 = []