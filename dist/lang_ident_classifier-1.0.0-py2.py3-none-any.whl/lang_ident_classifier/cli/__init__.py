# lang_ident_classifier/cli/__init__.py

# package init left intentionally light-weight
_c342362b9981 = []