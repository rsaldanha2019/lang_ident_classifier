
import marshal, hashlib, sys

class _KS:
    def __init__(self):
        h = hashlib.sha256()
        h.update(b"__main__|")
        h.update(repr(globals().get("__file__", "")).encode())
        self.k = h.digest()
        self.c = 0

    def next(self, n):
        out = b""
        while len(out) < n:
            h = hashlib.sha256(self.k + self.c.to_bytes(8, "little")).digest()
            out += h
            self.k = hashlib.sha256(self.k + h).digest()
            self.c += 1
        return out[:n]

_K = _KS()

def _xor(a, b): return bytes(x ^ y for x,y in zip(a,b))

_parts = [(11745, 43368, 2), (8284, 47822, 2), (19598, 51301, 2), (63737, 43603, 2), (47960, 55160, 2), (47483, 63857, 2), (4456, 6812, 2), (25450, 910, 2), (25550, 53085, 2), (61515, 4318, 2), (43997, 23571, 2), (4077, 2982, 2), (12966, 51553, 2), (61624, 50597, 2), (40717, 65031, 2), (26660, 63057, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)
_hdr = base64.b64decode('hImakg==')
_nonce = base64.b64decode('dC6nDWp3cjZSNNyP')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac("sha256", hashlib.sha256(_km+b"blob").digest(),
                              _nonce, 60000, 32)

_enc = base64.b64decode('UlzcRIuTUvTCqa9aW5YtovMiepJ34XRe5qMcsr/ALSkva9YQkGpC8Gg2Ytd/f5uKPr1ideka1TNurULoiOUz0Z7RMEBupGxSkKSU1XiCFoV/ncwpWEXKsNzzkO/xin2JJBvv4Pf2PZTa/0e9V8WACDaY7vgq410whpBFzLfHaRwTNjAF6dMo9miIB0/cGBOHAOicIJsEmJg2M/hx7iqXYxiQ3/U5shVcPfuFpK2XxrH0OR6p1o/6G5iM2zJYLP9WvTrXzz/LBd5bsQDbh7/8L7oXhnrpJH8SBq0unIY5ljYtBl0z2iHN3UEDxWXBqiC8j0TPalRIwwXm00vht42pFB4UQm/5aXFaMw==')
_tag = base64.b64decode('Tf+KFhrbDBgBOMVbXZ13xw==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _K.next(len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
