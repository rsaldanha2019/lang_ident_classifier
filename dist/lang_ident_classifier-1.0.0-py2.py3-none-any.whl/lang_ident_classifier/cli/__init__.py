#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(60209, 47609, 2), (46588, 10512, 2), (14227, 41975, 2), (37698, 3438, 2), (28749, 41423, 2), (17367, 11230, 2), (4697, 39812, 2), (50114, 13725, 2), (8252, 1148, 2), (57877, 55080, 2), (40786, 37685, 2), (27432, 49629, 2), (1144, 1553, 2), (60603, 49576, 2), (27918, 33699, 2), (15829, 42557, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('Usic7A==')
_nonce = base64.b64decode('sekS5ErRM1oTHCEH')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('Bh1TCyiDLAP2z/rHB9ElgcI4XtWqrwvxOGv8RK2JKZAxNcsXg3gdaj5ndwrkl/R9MAP5ytqeQIixaArpS1j9lRm6y2xXerZcDQ0hANx06YxoTWZhNI/rahljagZkfqjfw7N9/3P1xMR+DrnEY69p59hkYxBLymNXDTT4JuT6wkjbqFwXQDgRMgzBLhIwy7rpbHS7tZJqRDQQqwdBAJAgmA0EQzz0kQzkAKLy9LTHTFGkBoHnIJ1YtOYyfaVqe2Zf/QlfgDZz+PyQKRT8kaunvu8xbatkcuMTbocxl/YhTeU7nQWQGaBRjtZJUlUpsyQDJgsHPgnIkvvbBs4AHOMghXD6a2xkabOvAQ==')
_tag = base64.b64decode('qwyr6PW5F0sv9ChwvM07/A==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
