#!/usr/bin/env python3
import base64, hashlib, marshal, sys

def _sha_blocks(seed, n):
    out = b""
    c = 0
    while len(out) < n:
        out += hashlib.sha256(seed + c.to_bytes(4, "little")).digest()
        c += 1
    return out[:n]

def _xor(a, b):
    return bytes(x ^ y for x, y in zip(a, b))

_parts = [(44059, 37460, 2), (16610, 46741, 2), (436, 64122, 2), (19241, 4818, 2), (448, 36593, 2), (13091, 4890, 2), (31858, 55338, 2), (24580, 53483, 2), (33357, 53478, 2), (14478, 1393, 2), (55675, 29838, 2), (20866, 22778, 2), (56361, 33527, 2), (4023, 57190, 2), (9925, 52425, 2), (42022, 3331, 2), (0, 0, 0), (0, 0, 0)]
_key = b''.join((v ^ m).to_bytes(l, 'big') for v,m,l in _parts if l)

_hdr = base64.b64decode('Pk/2dw==')
_nonce = base64.b64decode('smNNTVAXtP7/Iyko')

_seed = hashlib.sha256(_key + _hdr + _nonce).digest()
_km = hashlib.pbkdf2_hmac("sha256", _seed, _nonce, 300000, 32)

_blob_k = hashlib.pbkdf2_hmac(
    "sha256",
    hashlib.sha256(_km + b"blob").digest(),
    _nonce,
    60000,
    32
)

_enc = base64.b64decode('3kZf767Fq5EDsAdF8gGKZA2ohqQeyjxyGC7fvkcspjsLwtnj5RFiG/IIYHBFYQ7ljtwBqhphE62aYEIb43mw8K+ahtIK1hnUn4HQG3xLiiAvipf0z4wCwGRDr66EJVPjZh4AdVPYhUCmf+haXc7Ha13HiM77ZG8SaO1MO6L4wvpQegZ6svsg9cTidbHfnta9Osq1aCSwcujIuXDOT6WfQzqd13vo852h64jlksu4rgIL7qOgkRcw3MZ0YFcIdz6kVhOtzaNUzBFqPjZxvD2LQ9xkqxuqMtA97WSx9YsFr+gqvQzTZ/JcHvSHNuTYXLYNSuBVta1h/EL5n115mFxpC7K1bJLNi6Kghg==')
_tag = base64.b64decode('JjpiQY5BxquobOar3mql3w==')

if hashlib.sha256(_blob_k + _enc).digest()[:len(_tag)] != _tag:
    raise RuntimeError("integrity")

raw = _xor(_enc, _sha_blocks(_blob_k, len(_enc)))
code = marshal.loads(raw)
exec(code, globals())
